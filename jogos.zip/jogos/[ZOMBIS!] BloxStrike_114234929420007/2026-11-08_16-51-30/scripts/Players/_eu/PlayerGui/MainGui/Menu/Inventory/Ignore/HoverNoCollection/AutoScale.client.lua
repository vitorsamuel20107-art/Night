-- NIGHT Analyzer | Players.jejekwwkwiwi.PlayerGui.MainGui.Menu.Inventory.Ignore.HoverNoCollection.AutoScale
-- LocalScript | 44 linhas | 1154 bytes | hash b2e4ebc0

local v1 = script.Parent
local v_u_2 = v1:WaitForChild("UIScale")
local v_u_3 = workspace.CurrentCamera
v_u_3:GetPropertyChangedSignal("ViewportSize"):Connect(function() -- name: updateScale
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	v_u_2.Scale = v_u_3.ViewportSize.X / 1920
end)
v_u_2.Scale = v_u_3.ViewportSize.X / 1920
local v_u_4 = v1:FindFirstChild("Information")
if v_u_4 then
	v_u_4 = v_u_4:FindFirstChild("Rarity")
end
local v_u_5
if v_u_4 then
	v_u_5 = v_u_4:FindFirstChild("Label")
else
	v_u_5 = v_u_4
end
local v_u_6 = v1:FindFirstChild("RarityBar")
local v_u_7 = v1:FindFirstChild("ItemName")
if v_u_7 then
	v_u_7 = v_u_7:FindFirstChild("RarityGlow")
end
local function v10() -- name: tint
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_7, (copy) v_u_4
	if v_u_5 then
		local v8 = v_u_5.TextColor3
		if v_u_6 then
			v_u_6.BackgroundColor3 = v8
		end
		if v_u_7 then
			v_u_7.ImageColor3 = v8
		end
		local v9 = v_u_4:FindFirstChild("PillStroke")
		if v9 then
			v9.Color = v8
		end
		v_u_4.BackgroundColor3 = v8:Lerp(Color3.new(0, 0, 0), 0.82)
	end
end
if v_u_5 then
	v_u_5:GetPropertyChangedSignal("TextColor3"):Connect(v10)
end
v10()
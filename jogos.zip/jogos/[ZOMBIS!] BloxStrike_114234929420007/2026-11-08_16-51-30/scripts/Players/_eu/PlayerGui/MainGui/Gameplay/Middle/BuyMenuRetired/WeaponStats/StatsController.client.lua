-- NIGHT Analyzer | Players.jejekwwkwiwi.PlayerGui.MainGui.Gameplay.Middle.BuyMenuRetired.WeaponStats.StatsController
-- LocalScript | 86 linhas | 2977 bytes | hash e8e4955f

local v_u_1 = script.Parent
local v_u_2 = {
	"Damage",
	"FireRate",
	"Accuracy",
	"RecoilControl"
}
local v_u_3 = {
	["Grey"] = Color3.fromRGB(176, 195, 217),
	["Blue"] = Color3.fromRGB(75, 105, 255),
	["Purple"] = Color3.fromRGB(136, 71, 255),
	["Pink"] = Color3.fromRGB(211, 44, 230),
	["Red"] = Color3.fromRGB(235, 75, 75),
	["Gold"] = Color3.fromRGB(226, 196, 34)
}
local v_u_4 = Color3.fromRGB(205, 75, 60)
local v_u_5 = Color3.fromRGB(225, 180, 60)
local v_u_6 = Color3.fromRGB(110, 200, 75)
local v_u_7 = Color3.fromRGB(12, 12, 14)
local v_u_8 = Color3.fromRGB(203, 203, 203)
local function v_u_29() -- name: refresh
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_2, (copy) v_u_4, (copy) v_u_5, (copy) v_u_6, (copy) v_u_7, (copy) v_u_8
	local v9 = v_u_1:GetAttribute("Magazine")
	local v10 = v_u_1:GetAttribute("Reserve")
	local v11 = v_u_1:GetAttribute("Ammo")
	if v11 and v11 ~= "" then
		v9, v10 = string.match(v11, "(%d+)%s*/%s*(%d+)")
	end
	local v12 = v_u_1.Render
	v12.WeaponName.Text = v_u_1:GetAttribute("WeaponName") or ""
	local v13 = string.upper(v_u_1:GetAttribute("Category") or "")
	local v14 = string.upper(v_u_1:GetAttribute("SkinName") or "")
	local v15 = v_u_3[v_u_1:GetAttribute("Rarity") or ""] or v_u_3.Grey
	local v16 = string.format("#%02X%02X%02X", v15.R * 255, v15.G * 255, v15.B * 255)
	local v17 = v14 == "" and "" or ("<font color=\"" .. v16 .. "\">" .. v14 .. "</font>" or "")
	v12.Category.Text = v13 ~= "" and v14 ~= "" and v13 .. "  \226\128\162  " .. v17 or v13 .. v17
	v12.Glow.ImageColor3 = v15
	v12.Price.Value.Text = v_u_1:GetAttribute("Price") or ""
	v12.Price.Visible = (v_u_1:GetAttribute("Price") or "") ~= ""
	v12.Icon.Image = v_u_1:GetAttribute("Icon") or ""
	v_u_1.Info.Magazine.Value.Text = v9 or "-"
	v_u_1.Info.Reserve.Value.Text = v10 or "-"
	v_u_1.Info.Special.Value.Text = v_u_1:GetAttribute("Special") or "None"
	for _, v18 in ipairs(v_u_2) do
		local v19 = v_u_1.Stats[v18]
		local v20 = v_u_1:GetAttribute(v18) or 0
		local v21 = math.clamp(v20, 0, 10)
		local v22 = v19.Value
		local v23 = v21 + 0.5
		local v24 = math.floor(v23)
		v22.Text = tostring(v24)
		v19.Track.Fill.Size = UDim2.fromScale(v21 / 10, 1)
		local v25 = v21 / 10
		local v26
		if v25 < 0.5 then
			v26 = v_u_4:Lerp(v_u_5, v25 * 2)
		else
			v26 = v_u_5:Lerp(v_u_6, (v25 - 0.5) * 2)
		end
		v19.Track.Fill.BackgroundColor3 = v26
		v19.Track.Fill.Glow.ImageColor3 = v26
		v19.Value.TextColor3 = v26
		for _, v27 in ipairs(v19.Track:GetChildren()) do
			if v27.Name ~= "Tick" then
				continue
			end
			local v28 = v27.Position.X.Scale < v21 / 10
			v27.ZIndex = 7
			v27.BackgroundColor3 = v28 and v_u_7 or v_u_8
			v27.BackgroundTransparency = v28 and 0 or 0.8
		end
	end
end
local v_u_30 = false
v_u_1.AttributeChanged:Connect(function()
	-- upvalues: (ref) v_u_30, (copy) v_u_29
	if not v_u_30 then
		v_u_30 = true
		task.defer(function()
			-- upvalues: (ref) v_u_30, (ref) v_u_29
			v_u_30 = false
			v_u_29()
		end)
	end
end)
v_u_29()
-- NIGHT Analyzer | Players.jejekwwkwiwi.PlayerScripts.PlayerModule.CameraModule.VRCamera
-- ModuleScript | 300 linhas | 10121 bytes | hash 61c51843

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("VRService")
UserSettings():GetService("UserGameSettings")
local v3 = game:GetService("ReplicatedStorage")
require(script.Parent:WaitForChild("CameraInput"))
require(script.Parent:WaitForChild("CameraUtils"))
local v_u_4 = require(v3.Components.Common.CharacterResolver)
local v_u_5 = require(script.Parent:WaitForChild("VRBaseCamera"))
local v_u_6 = setmetatable({}, v_u_5)
v_u_6.__index = v_u_6
function v_u_6.new() -- name: new
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_1
	local v7 = v_u_5.new()
	local v8 = v_u_6
	local v9 = setmetatable(v7, v8)
	v9.lastUpdate = tick()
	v9.focusOffset = CFrame.new()
	v9:Reset()
	v9.controlModule = require(v_u_1.LocalPlayer:WaitForChild("PlayerScripts").PlayerModule:WaitForChild("ControlModule"))
	v9.savedAutoRotate = true
	return v9
end
function v_u_6.Reset(p10) -- name: Reset
	-- upvalues: (copy) v_u_5
	p10.needsReset = true
	p10.needsBlackout = true
	p10.motionDetTime = 0
	p10.blackOutTimer = 0
	p10.lastCameraResetPosition = nil
	v_u_5.Reset(p10)
end
function v_u_6.Update(p11, p12) -- name: Update
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v13 = workspace.CurrentCamera
	local v14 = v13.CFrame
	local v15 = v13.Focus
	local v16 = v_u_1.LocalPlayer
	p11:GetHumanoid()
	local _ = v13.CameraSubject
	if p11.lastUpdate == nil or p12 > 1 then
		p11.lastCameraTransform = nil
	end
	p11:UpdateFadeFromBlack(p12)
	p11:UpdateEdgeBlur(v16, p12)
	local v17 = p11.lastSubjectPosition
	local v18 = p11:GetSubjectPosition()
	if p11.needsBlackout then
		p11:StartFadeFromBlack()
		local v19 = math.clamp(p12, 0.0001, 0.1)
		p11.blackOutTimer = p11.blackOutTimer + v19
		if p11.blackOutTimer > 0.1 and game:IsLoaded() then
			p11.needsBlackout = false
			p11.needsReset = true
		end
	end
	if v18 and (v16 and v13) then
		local v20 = p11:GetVRFocus(v18, p12)
		if p11:IsInFirstPerson() then
			if v_u_2.AvatarGestures then
				v14, v15 = p11:UpdateImmersionCamera(p12, v14, v20, v17, v18)
			else
				v14, v15 = p11:UpdateFirstPersonTransform(p12, v14, v20, v17, v18)
			end
		elseif v_u_2.ThirdPersonFollowCamEnabled then
			v14, v15 = p11:UpdateThirdPersonFollowTransform(p12, v14, v20, v17, v18)
		else
			v14, v15 = p11:UpdateThirdPersonComfortTransform(p12, v14, v20, v17, v18)
		end
		p11.lastCameraTransform = v14
		p11.lastCameraFocus = v15
	end
	p11.lastUpdate = tick()
	return v14, v15
end
function v_u_6.GetAvatarFeetWorldYValue(_) -- name: GetAvatarFeetWorldYValue
	local v21 = workspace.CurrentCamera.CameraSubject
	if not v21 then
		return nil
	end
	if not (v21:IsA("Humanoid") and v21.RootPart) then
		return nil
	end
	local v22 = v21.RootPart
	return v22.Position.Y - v22.Size.Y / 2 - v21.HipHeight
end
function v_u_6.UpdateFirstPersonTransform(p23, p24, _, p25, p26, p27) -- name: UpdateFirstPersonTransform
	-- upvalues: (copy) v_u_1
	if p23.needsReset then
		p23:StartFadeFromBlack()
		p23.needsReset = false
	end
	local v28 = v_u_1.LocalPlayer
	if (p26 - p27).magnitude > 0.01 then
		p23:StartVREdgeBlur(v28)
	end
	local v29 = p25.p
	local v30 = p23:GetCameraLookVector()
	local v31 = v30.X
	local v32 = v30.Z
	local v33 = Vector3.new(v31, 0, v32).Unit
	local v34 = p23:getRotation(p24)
	local v35 = p23:CalculateNewLookVectorFromArg(v33, Vector2.new(v34, 0))
	return CFrame.new(v29 - 0.5 * v35, v29), p25
end
function v_u_6.UpdateImmersionCamera(p36, p37, _, _, _, p38) -- name: UpdateImmersionCamera
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_1
	local v39 = p36:GetSubjectCFrame()
	local v40 = workspace.CurrentCamera
	local v41 = v_u_4.getLocalCharacter()
	local v42 = p36:GetHumanoid()
	if not (v42 and v41) then
		return v40.CFrame, v40.Focus
	end
	local v43 = v41:FindFirstChild("HumanoidRootPart")
	if not v43 then
		return v40.CFrame, v40.Focus
	end
	p36.characterOrientation = v43:FindFirstChild("CharacterAlignOrientation")
	if not p36.characterOrientation then
		local v44 = v43:FindFirstChild("RootAttachment")
		if not v44 then
			return
		end
		p36.characterOrientation = Instance.new("AlignOrientation")
		p36.characterOrientation.Name = "CharacterAlignOrientation"
		p36.characterOrientation.Mode = Enum.OrientationAlignmentMode.OneAttachment
		p36.characterOrientation.Attachment0 = v44
		p36.characterOrientation.RigidityEnabled = true
		p36.characterOrientation.Parent = v43
	end
	if p36.characterOrientation.Enabled == false then
		p36.characterOrientation.Enabled = true
	end
	if p36.needsReset then
		p36.needsReset = false
		p36.savedAutoRotate = v42.AutoRotate
		v42.AutoRotate = false
		if p36.NoRecenter then
			p36.NoRecenter = false
			v_u_2:RecenterUserHeadCFrame()
		end
		p36:StartFadeFromBlack()
	elseif v42.Sit then
		if (v39.Position - v40.CFrame.Position).Magnitude > 0.01 then
			p36:StartVREdgeBlur(v_u_1.LocalPlayer)
		end
	else
		local v45 = p36.controlModule:GetEstimatedVRTorsoFrame()
		p36.characterOrientation.CFrame = v40.CFrame * v45
		if p36.controlModule.inputMoveVector.Magnitude > 0 then
			p36.motionDetTime = 0.1
		end
		if p36.controlModule.inputMoveVector.Magnitude > 0 or p36.motionDetTime > 0 then
			p36.motionDetTime = p36.motionDetTime - p37
			p36:StartVREdgeBlur(v_u_1.LocalPlayer)
			local v46 = v_u_2:GetUserCFrame(Enum.UserCFrame.Head)
			local v47 = v46.Rotation + v46.Position * v40.HeadScale
			local v48 = v41.HumanoidRootPart
			local v49 = -0.7 * v48.Size.Y / 2
			local v50 = v40.CFrame * v47 * CFrame.new(0, v49, 0)
			local v51 = v48.CFrame.LookVector
			local v52 = v51.X
			local v53 = v51.Z
			local v54 = p38 - (v50 - Vector3.new(v52, 0, v53).Unit * v48.Size.Y * 0.125).Position + v40.CFrame.Position
			local v55 = v54.X
			local v56 = p38.Y
			local v57 = v54.Z
			local v58 = Vector3.new(v55, v56, v57)
			v39 = v40.CFrame.Rotation + v58
		else
			local v59 = v40.CFrame.Rotation
			local v60 = v40.CFrame.Position.X
			local v61 = p38.Y
			local v62 = v40.CFrame.Position.Z
			v39 = v59 + Vector3.new(v60, v61, v62)
		end
		local v63 = p36:getRotation(p37)
		if math.abs(v63) > 0 then
			local v64 = v_u_2:GetUserCFrame(Enum.UserCFrame.Head)
			local v65 = v64.Rotation + v64.Position * v40.HeadScale
			local v66 = v39 * v65
			local v67 = CFrame.new(v66.Position)
			local v68 = CFrame.Angles
			local v69 = v63 * 90
			v39 = v67 * v68(0, -math.rad(v69), 0) * v66.Rotation * v65:Inverse()
		end
	end
	return v39, v39 * CFrame.new(0, 0, -0.5)
end
function v_u_6.UpdateThirdPersonComfortTransform(p70, p71, p72, p73, p74, p75) -- name: UpdateThirdPersonComfortTransform
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v76 = p70:GetCameraToSubjectDistance()
	local v77 = v76 < 0.5 and 0.5 or v76
	if p74 ~= nil and p70.lastCameraFocus ~= nil then
		local _ = v_u_1.LocalPlayer
		local v78 = p74 - p75
		local v79 = p70.controlModule:GetMoveVector()
		local v80 = v78.magnitude > 0.01 and true or v79.magnitude > 0.01
		if v80 then
			p70.motionDetTime = 0.1
		end
		p70.motionDetTime = p70.motionDetTime - p71
		if (p70.motionDetTime > 0 and true or v80) and not p70.needsReset then
			local v81 = p70.lastCameraFocus
			p70.VRCameraFocusFrozen = true
			return p72, v81
		end
		local v82 = p70.lastCameraResetPosition == nil and true or (p75 - p70.lastCameraResetPosition).Magnitude > 1
		local v83 = p70:getRotation(p71)
		if math.abs(v83) > 0 then
			local v84 = p73:ToObjectSpace(p72)
			p72 = p73 * CFrame.Angles(0, -v83, 0) * v84
		end
		if p70.VRCameraFocusFrozen and v82 or p70.needsReset then
			v_u_2:RecenterUserHeadCFrame()
			p70.VRCameraFocusFrozen = false
			p70.needsReset = false
			p70.lastCameraResetPosition = p75
			p70:ResetZoom()
			p70:StartFadeFromBlack()
			local v85 = p70:GetHumanoid()
			local v86 = v85.Torso and v85.Torso.CFrame.lookVector or Vector3.new(1, 0, 0)
			local v87 = v86.X
			local v88 = v86.Z
			local v89 = Vector3.new(v87, 0, v88)
			local v90 = p73.Position - v89 * v77
			local v91 = p73.Position.X
			local v92 = v90.Y
			local v93 = p73.Position.Z
			local v94 = Vector3.new(v91, v92, v93)
			p72 = CFrame.new(v90, v94)
		end
	end
	return p72, p73
end
function v_u_6.UpdateThirdPersonFollowTransform(p95, p96, _, _, p97, p98) -- name: UpdateThirdPersonFollowTransform
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v99 = workspace.CurrentCamera
	local v100 = p95:GetCameraToSubjectDistance()
	local v101 = p95:GetVRFocus(p98, p96)
	if p95.needsReset then
		p95.needsReset = false
		v_u_2:RecenterUserHeadCFrame()
		p95:ResetZoom()
		p95:StartFadeFromBlack()
	end
	if p95.recentered then
		local v102 = p95:GetSubjectCFrame()
		if not v102 then
			return v99.CFrame, v99.Focus
		end
		local v103 = v101 * v102.Rotation * CFrame.new(0, 0, v100)
		p95.focusOffset = v101:ToObjectSpace(v103)
		p95.recentered = false
		return v103, v101
	end
	local v104 = v101:ToWorldSpace(p95.focusOffset)
	local _ = v_u_1.LocalPlayer
	local v105 = p97 - p98
	local v106 = p95.controlModule
	local v107 = v106:GetMoveVector()
	if v105.magnitude > 0.01 or v107.magnitude > 0 then
		local v108 = v106:GetEstimatedVRTorsoFrame()
		local v109 = v108.Rotation + v108.Position * v99.HeadScale
		local v110 = v99.CFrame * v109
		local v111 = v110.LookVector
		local v112 = v111.X
		local v113 = v111.Z
		local v114 = Vector3.new(v112, 0, v113).Unit * v100
		local v115 = v101.Position - v114
		v104 = v104:Lerp(CFrame.new(v99.CFrame.Position + v115 - v110.Position) * v104.Rotation, 0.01)
	end
	local v116 = p95:getRotation(p96)
	if math.abs(v116) > 0 then
		local v117 = v101:ToObjectSpace(v104)
		v104 = v101 * CFrame.Angles(0, -v116, 0) * v117
	end
	p95.focusOffset = v101:ToObjectSpace(v104)
	local v118 = v104 * CFrame.new(0, 0, -v100)
	if (v118.Position - v99.Focus.Position).Magnitude > 0.01 then
		p95:StartVREdgeBlur(v_u_1.LocalPlayer)
	end
	return v104, v118
end
function v_u_6.LeaveFirstPerson(p119) -- name: LeaveFirstPerson
	-- upvalues: (copy) v_u_5
	v_u_5.LeaveFirstPerson(p119)
	p119.needsReset = true
	if p119.VRBlur then
		p119.VRBlur.Visible = false
	end
	if p119.characterOrientation then
		p119.characterOrientation.Enabled = false
	end
	local v120 = p119:GetHumanoid()
	if v120 then
		v120.AutoRotate = p119.savedAutoRotate
	end
end
return v_u_6
-- NIGHT Analyzer | Players.jejekwwkwiwi.PlayerScripts.Startup
-- LocalScript | 153 linhas | 4508 bytes | hash 58517f24

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("RunService")
game:GetService("StarterGui"):SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false)
local v_u_3 = require(v1.Shared.Profiler)
local v_u_4 = {}
local v_u_5 = 1
local v_u_6 = 0
local v_u_7 = false
local function v_u_9(p8) -- name: getTraceback
	return debug.traceback(tostring(p8), 2)
end
local function v_u_24(p10, p11, p12, p13) -- name: runStartupThread
	-- upvalues: (ref) v_u_6, (copy) v_u_4, (ref) v_u_7, (ref) v_u_5, (copy) v_u_3, (copy) v_u_9, (copy) v_u_2
	v_u_6 = v_u_6 + 1
	local v14 = v_u_4
	local v15 = v_u_6
	local v16 = {}
	if p11 then
		p10 = ("%*.%*"):format(p10, p11)
	end
	v16.label = p10
	v16.profileLabel = p12
	v16.callback = p13
	v14[v15] = v16
	if not v_u_7 then
		v_u_7 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_4, (ref) v_u_3, (ref) v_u_9, (ref) v_u_2, (ref) v_u_7
			local v17 = os.clock()
			local v18 = 0
			while v_u_5 <= v_u_6 do
				local v_u_19 = v_u_4[v_u_5]
				v_u_4[v_u_5] = nil
				v_u_5 = v_u_5 + 1
				v18 = v18 + 1
				task.spawn(function()
					-- upvalues: (copy) v_u_19, (ref) v_u_3, (ref) v_u_9
					debug.setmemorycategory((("Startup.%*"):format(v_u_19.label)))
					v_u_3.mark(v_u_19.profileLabel)
					local v20 = v_u_19.callback
					local v21 = v_u_9
					local v22, v23 = xpcall(v20, v21)
					if not v22 then
						warn((("[Startup] %* failed:\n%*"):format(v_u_19.label, v23)))
					end
				end)
				if v_u_5 > v_u_6 or v18 < 1 and os.clock() - v17 < 0.0015 then
					continue
				end
				v_u_2.Heartbeat:Wait()
				v17 = os.clock()
				v18 = 0
			end
			table.clear(v_u_4)
			v_u_5 = 1
			v_u_6 = 0
			v_u_7 = false
		end)
	end
end
local function v_u_31(p25, p26, p27, ...) -- name: runPhase
	-- upvalues: (copy) v_u_3, (copy) v_u_9
	v_u_3.mark((("Startup.Phase.%*"):format(p25)))
	local v28 = v_u_9
	local v29 = table.pack(xpcall(p27, v28, ...))
	if v29[1] then
		local v30 = v29.n
		return true, table.unpack(v29, 2, v30)
	end
	if p26 then
		p25 = ("%*.%*"):format(p25, p26)
	end
	warn((("[Startup] %* failed:\n%*"):format(p25, v29[2])))
	return false
end
for _, v_u_32 in ipairs(v1.Controllers:GetChildren()) do
	if not v_u_32:IsA("ModuleScript") then
		continue
	end
	local v_u_33 = v_u_3.getInstancePath(v_u_32, v1)
	local v_u_34 = ("Startup.Module.%*"):format(v_u_33)
	v_u_24("Controller", v_u_33, v_u_34, function()
		-- upvalues: (copy) v_u_31, (copy) v_u_33, (copy) v_u_32, (copy) v_u_34, (copy) v_u_24
		local v35, v36 = v_u_31("Require", v_u_33, require, v_u_32)
		if v35 then
			local v37 = v_u_33
			local v38
			if typeof(v36) == "table" then
				local v39 = v36.Initialize
				v38 = not v39 and true or v_u_31("Initialize", v37, v39)
			else
				v38 = false
			end
			if v38 then
				local v_u_40 = v_u_33
				local v41 = v_u_34
				if typeof(v36) ~= "table" then
					return
				end
				local v_u_42 = v36.Start
				if v_u_42 then
					v_u_24("Start", v_u_40, v41, function()
						-- upvalues: (ref) v_u_31, (copy) v_u_40, (copy) v_u_42
						v_u_31("Start", v_u_40, v_u_42)
					end)
				end
			end
		end
	end)
end
for _, v_u_43 in ipairs(v1.Controllers.Observers:GetChildren()) do
	if v_u_43:IsA("ModuleScript") then
		local v_u_44 = v_u_3.getInstancePath(v_u_43, v1)
		v_u_24("Observer", v_u_44, ("Startup.Module.%*"):format(v_u_44), function()
			-- upvalues: (copy) v_u_44, (copy) v_u_31, (copy) v_u_43
			debug.setmemorycategory((("Startup.Observer.%*"):format(v_u_44)))
			v_u_31("Require", v_u_44, require, v_u_43)
		end)
	else
		if not v_u_43:IsA("Folder") then
			continue
		end
		for _, v_u_45 in ipairs(v_u_43:GetChildren()) do
			if not v_u_45:IsA("ModuleScript") then
				continue
			end
			local v_u_46 = v_u_3.getInstancePath(v_u_45, v1)
			v_u_24("Observer", v_u_46, ("Startup.Module.%*"):format(v_u_46), function()
				-- upvalues: (copy) v_u_46, (copy) v_u_31, (copy) v_u_45
				debug.setmemorycategory((("Startup.Observer.%*"):format(v_u_46)))
				v_u_31("Require", v_u_46, require, v_u_45)
			end)
		end
	end
end
local v_u_47 = v1:WaitForChild("Interface")
v_u_24("Interface", nil, "Startup.Module.Interface", function()
	-- upvalues: (copy) v_u_31, (copy) v_u_47
	local v48, v49 = v_u_31("Require", "Interface", require, v_u_47)
	if v48 then
		if typeof(v49) == "table" then
			if not v49.Initialize or v_u_31("Initialize", "Interface", v49.Initialize) then
				if v49.Start then
					v_u_31("Start", "Interface", v49.Start)
				end
			end
		else
			return
		end
	else
		return
	end
end)
-- NIGHT Analyzer | Players.jejekwwkwiwi.PlayerScripts.PlayerModule.ControlModule
-- ModuleScript | 572 linhas | 19714 bytes | hash 6f8560ed

local v_u_1 = {}
v_u_1.__index = v_u_1
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = game:GetService("GuiService")
local v_u_6 = game:GetService("Workspace")
local v7 = game:GetService("ReplicatedStorage")
local v_u_8 = UserSettings():GetService("UserGameSettings")
local v_u_9 = game:GetService("VRService")
local v_u_10 = require(v7.Components.Common.CharacterResolver)
script.Parent:WaitForChild("CommonUtils")
local v_u_11 = require(script:WaitForChild("Keyboard"))
local v_u_12 = require(script:WaitForChild("Gamepad"))
local v_u_13 = require(script:WaitForChild("DynamicThumbstick"))
local v14, v15 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserDynamicThumbstickSafeAreaUpdate")
end)
local v_u_16 = v14 and v15
local v_u_17 = require(script:WaitForChild("TouchThumbstick"))
local v_u_18 = require(script:WaitForChild("ClickToMoveController"))
local v_u_19 = require(script:WaitForChild("TouchJump"))
local v_u_20 = require(script:WaitForChild("VehicleController"))
local v_u_21 = Enum.ContextActionPriority.Medium.Value
local v_u_22 = {
	[Enum.TouchMovementMode.DPad] = v_u_13,
	[Enum.DevTouchMovementMode.DPad] = v_u_13,
	[Enum.TouchMovementMode.Thumbpad] = v_u_13,
	[Enum.DevTouchMovementMode.Thumbpad] = v_u_13,
	[Enum.TouchMovementMode.Thumbstick] = v_u_17,
	[Enum.DevTouchMovementMode.Thumbstick] = v_u_17,
	[Enum.TouchMovementMode.DynamicThumbstick] = v_u_13,
	[Enum.DevTouchMovementMode.DynamicThumbstick] = v_u_13,
	[Enum.TouchMovementMode.Default] = v_u_13,
	[Enum.ComputerMovementMode.Default] = v_u_11,
	[Enum.ComputerMovementMode.KeyboardMouse] = v_u_11,
	[Enum.DevComputerMovementMode.KeyboardMouse] = v_u_11,
	[Enum.DevComputerMovementMode.Scriptable] = nil,
	[Enum.ComputerMovementMode.ClickToMove] = v_u_18,
	[Enum.DevComputerMovementMode.ClickToMove] = v_u_18
}
local v_u_23 = {
	[Enum.UserInputType.Keyboard] = v_u_11,
	[Enum.UserInputType.MouseButton1] = v_u_11,
	[Enum.UserInputType.MouseButton2] = v_u_11,
	[Enum.UserInputType.MouseButton3] = v_u_11,
	[Enum.UserInputType.MouseWheel] = v_u_11,
	[Enum.UserInputType.MouseMovement] = v_u_11,
	[Enum.UserInputType.Gamepad1] = v_u_12,
	[Enum.UserInputType.Gamepad2] = v_u_12,
	[Enum.UserInputType.Gamepad3] = v_u_12,
	[Enum.UserInputType.Gamepad4] = v_u_12,
	[Enum.UserInputType.Gamepad5] = v_u_12,
	[Enum.UserInputType.Gamepad6] = v_u_12,
	[Enum.UserInputType.Gamepad7] = v_u_12,
	[Enum.UserInputType.Gamepad8] = v_u_12
}
local v_u_24 = nil
function v_u_1.new() -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_20, (copy) v_u_21, (copy) v_u_10, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (copy) v_u_5
	local v25 = v_u_1
	local v_u_26 = setmetatable({}, v25)
	v_u_26.controllers = {}
	v_u_26.activeControlModule = nil
	v_u_26.activeController = nil
	v_u_26.touchJumpController = nil
	v_u_26.moveFunction = v_u_2.LocalPlayer.Move
	v_u_26.character = nil
	v_u_26.humanoid = nil
	v_u_26.customCharacterMotor = nil
	v_u_26.lastInputType = Enum.UserInputType.None
	v_u_26.controlsEnabled = true
	v_u_26.humanoidSeatedConn = nil
	v_u_26.vehicleController = nil
	v_u_26.touchControlFrame = nil
	v_u_26.currentTorsoAngle = 0
	v_u_26.inputMoveVector = Vector3.new(0, 0, 0)
	v_u_26.vehicleController = v_u_20.new(v_u_21)
	v_u_26.presentedCharacterDisconnect = v_u_10.observeCharacter(v_u_2.LocalPlayer, function(p27, p28)
		-- upvalues: (copy) v_u_26
		if p28 and p28 ~= p27 then
			v_u_26:OnCharacterRemoving(p28)
		end
		if p27 then
			v_u_26:OnCharacterAdded(p27)
		end
		return function() end
	end)
	v_u_3:BindToRenderStep("ControlScriptRenderstep", Enum.RenderPriority.Input.Value, function(p29)
		-- upvalues: (copy) v_u_26
		v_u_26:OnRenderStepped(p29)
	end)
	v_u_4.LastInputTypeChanged:Connect(function(p30)
		-- upvalues: (copy) v_u_26
		v_u_26:OnLastInputTypeChanged(p30)
	end)
	v_u_8:GetPropertyChangedSignal("TouchMovementMode"):Connect(function()
		-- upvalues: (copy) v_u_26
		v_u_26:OnTouchMovementModeChange()
	end)
	v_u_2.LocalPlayer:GetPropertyChangedSignal("DevTouchMovementMode"):Connect(function()
		-- upvalues: (copy) v_u_26
		v_u_26:OnTouchMovementModeChange()
	end)
	v_u_8:GetPropertyChangedSignal("ComputerMovementMode"):Connect(function()
		-- upvalues: (copy) v_u_26
		v_u_26:OnComputerMovementModeChange()
	end)
	v_u_2.LocalPlayer:GetPropertyChangedSignal("DevComputerMovementMode"):Connect(function()
		-- upvalues: (copy) v_u_26
		v_u_26:OnComputerMovementModeChange()
	end)
	v_u_26.playerGui = nil
	v_u_26.touchGui = nil
	v_u_26.playerGuiAddedConn = nil
	v_u_5:GetPropertyChangedSignal("TouchControlsEnabled"):Connect(function()
		-- upvalues: (copy) v_u_26
		v_u_26:UpdateTouchGuiVisibility()
		v_u_26:UpdateActiveControlModuleEnabled()
	end)
	if not v_u_4.TouchEnabled then
		v_u_26:OnLastInputTypeChanged(v_u_4:GetLastInputType())
		return v_u_26
	end
	v_u_26.playerGui = v_u_2.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	if not v_u_26.playerGui then
		v_u_26.playerGuiAddedConn = v_u_2.LocalPlayer.ChildAdded:Connect(function(p31)
			-- upvalues: (copy) v_u_26, (ref) v_u_4
			if p31:IsA("PlayerGui") then
				v_u_26.playerGui = p31
				v_u_26:CreateTouchGuiContainer()
				v_u_26.playerGuiAddedConn:Disconnect()
				v_u_26.playerGuiAddedConn = nil
				v_u_26:OnLastInputTypeChanged(v_u_4:GetLastInputType())
			end
		end)
		return v_u_26
	end
	v_u_26:CreateTouchGuiContainer()
	v_u_26:OnLastInputTypeChanged(v_u_4:GetLastInputType())
	return v_u_26
end
function v_u_1.GetMoveVector(p32) -- name: GetMoveVector
	return not p32.activeController and Vector3.new(0, 0, 0) or p32.activeController:GetMoveVector()
end
function v_u_1.GetEstimatedVRTorsoFrame(p33) -- name: GetEstimatedVRTorsoFrame
	-- upvalues: (copy) v_u_9
	local v34 = v_u_9:GetUserCFrame(Enum.UserCFrame.Head)
	local _, v35, _ = v34:ToEulerAnglesYXZ()
	local v36 = -v35
	if v_u_9:GetUserCFrameEnabled(Enum.UserCFrame.RightHand) and v_u_9:GetUserCFrameEnabled(Enum.UserCFrame.LeftHand) then
		local v37 = v_u_9:GetUserCFrame(Enum.UserCFrame.LeftHand)
		local v38 = v_u_9:GetUserCFrame(Enum.UserCFrame.RightHand)
		local v39 = v34.Position - v37.Position
		local v40 = v34.Position - v38.Position
		local v41 = v39.X
		local v42 = v39.Z
		local v43 = -math.atan2(v41, v42)
		local v44 = v40.X
		local v45 = v40.Z
		local v46 = (-math.atan2(v44, v45) - v43 + 12.566370614359172) % 6.283185307179586
		if v46 > 3.141592653589793 then
			v46 = v46 - 6.283185307179586
		end
		local v47 = (v43 + v46 / 2 + 12.566370614359172) % 6.283185307179586
		if v47 > 3.141592653589793 then
			v47 = v47 - 6.283185307179586
		end
		local v48 = (v36 - p33.currentTorsoAngle + 12.566370614359172) % 6.283185307179586
		if v48 > 3.141592653589793 then
			v48 = v48 - 6.283185307179586
		end
		local v49 = (v47 - p33.currentTorsoAngle + 12.566370614359172) % 6.283185307179586
		if v49 > 3.141592653589793 then
			v49 = v49 - 6.283185307179586
		end
		local v50
		if v49 > -1.5707963267948966 then
			v50 = v49 < 1.5707963267948966
		else
			v50 = false
		end
		if not v50 then
			v49 = v48
		end
		local v51 = math.min(v49, v48)
		local v52 = math.max(v49, v48)
		local v53 = 0
		if v51 > 0 then
			v52 = v51
		elseif v52 >= 0 then
			v52 = v53
		end
		p33.currentTorsoAngle = v52 + p33.currentTorsoAngle
	else
		p33.currentTorsoAngle = v36
	end
	return CFrame.new(v34.Position) * CFrame.fromEulerAnglesYXZ(0, -p33.currentTorsoAngle, 0)
end
function v_u_1.GetActiveController(p54) -- name: GetActiveController
	return p54.activeController
end
function v_u_1.UpdateActiveControlModuleEnabled(p_u_55) -- name: UpdateActiveControlModuleEnabled
	-- upvalues: (copy) v_u_2, (copy) v_u_18, (copy) v_u_17, (copy) v_u_13, (copy) v_u_19, (copy) v_u_5, (copy) v_u_4
	local function v56()
		-- upvalues: (copy) p_u_55, (ref) v_u_18, (ref) v_u_17, (ref) v_u_13, (ref) v_u_19, (ref) v_u_2
		if p_u_55.touchControlFrame and (p_u_55.activeControlModule == v_u_18 or (p_u_55.activeControlModule == v_u_17 or p_u_55.activeControlModule == v_u_13)) then
			if not p_u_55.controllers[v_u_19] then
				p_u_55.controllers[v_u_19] = v_u_19.new()
			end
			p_u_55.touchJumpController = p_u_55.controllers[v_u_19]
			p_u_55.touchJumpController:Enable(true, p_u_55.touchControlFrame)
		elseif p_u_55.touchJumpController then
			p_u_55.touchJumpController:Enable(false)
		end
		if p_u_55.activeControlModule == v_u_18 then
			p_u_55.activeController:Enable(true, v_u_2.LocalPlayer.DevComputerMovementMode == Enum.DevComputerMovementMode.UserChoice, p_u_55.touchJumpController)
			return
		elseif p_u_55.touchControlFrame then
			p_u_55.activeController:Enable(true, p_u_55.touchControlFrame)
		else
			p_u_55.activeController:Enable(true)
		end
	end
	if p_u_55.activeController then
		if p_u_55.controlsEnabled then
			if v_u_5.TouchControlsEnabled or (not v_u_4.TouchEnabled or p_u_55.activeControlModule ~= v_u_18 and (p_u_55.activeControlModule ~= v_u_17 and p_u_55.activeControlModule ~= v_u_13)) then
				v56()
			else
				p_u_55.activeController:Enable(false)
				if p_u_55.touchJumpController then
					p_u_55.touchJumpController:Enable(false)
				end
				if p_u_55.moveFunction then
					p_u_55.moveFunction(v_u_2.LocalPlayer, Vector3.new(0, 0, 0), true)
				end
			end
		else
			p_u_55.activeController:Enable(false)
			if p_u_55.touchJumpController then
				p_u_55.touchJumpController:Enable(false)
			end
			if p_u_55.moveFunction then
				p_u_55.moveFunction(v_u_2.LocalPlayer, Vector3.new(0, 0, 0), true)
			end
			return
		end
	else
		return
	end
end
function v_u_1.Enable(p57, p58) -- name: Enable
	local v59 = p58 == nil and true or p58
	if p57.controlsEnabled == v59 then
		return
	else
		p57.controlsEnabled = v59
		if p57.activeController then
			p57:UpdateActiveControlModuleEnabled()
		end
	end
end
function v_u_1.Disable(p60) -- name: Disable
	p60:Enable(false)
end
function v_u_1.SelectComputerMovementModule(_) -- name: SelectComputerMovementModule
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_23, (ref) v_u_24, (copy) v_u_8, (copy) v_u_11, (copy) v_u_18, (copy) v_u_22
	if v_u_4.KeyboardEnabled or v_u_4.GamepadEnabled then
		local v61 = v_u_2.LocalPlayer.DevComputerMovementMode
		local v62
		if v61 == Enum.DevComputerMovementMode.UserChoice then
			v62 = v_u_23[v_u_24]
			if v_u_8.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove and v62 == v_u_11 then
				v62 = v_u_18
			end
		else
			v62 = v_u_22[v61]
			if not v62 and v61 ~= Enum.DevComputerMovementMode.Scriptable then
				warn("No character control module is associated with DevComputerMovementMode ", v61)
			end
		end
		if v62 then
			return v62, true
		elseif v61 == Enum.DevComputerMovementMode.Scriptable then
			return nil, true
		else
			return nil, false
		end
	else
		return nil, false
	end
end
function v_u_1.SelectTouchModule(_) -- name: SelectTouchModule
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_8, (copy) v_u_13, (copy) v_u_22
	if not v_u_4.TouchEnabled then
		return nil, false
	end
	local v63 = v_u_2.LocalPlayer.DevTouchMovementMode
	local v64
	if v63 == Enum.DevTouchMovementMode.UserChoice then
		local v65 = v_u_8.TouchMovementMode
		if v65 == Enum.TouchMovementMode.ClickToMove then
			v64 = v_u_13
		else
			v64 = v_u_22[v65] or v_u_13
		end
	else
		if v63 == Enum.DevTouchMovementMode.Scriptable then
			return nil, true
		end
		if v63 == Enum.DevTouchMovementMode.ClickToMove then
			v64 = v_u_13
		else
			v64 = v_u_22[v63] or v_u_13
		end
	end
	return v64, true
end
local function v_u_68() -- name: getGamepadRightThumbstickPosition
	-- upvalues: (copy) v_u_4
	local v66 = v_u_4:GetGamepadState(Enum.UserInputType.Gamepad1)
	for _, v67 in pairs(v66) do
		if v67.KeyCode ~= Enum.KeyCode.Thumbstick2 then
			continue
		end
		return v67.Position
	end
	return Vector3.new(0, 0, 0)
end
function v_u_1.calculateRawMoveVector(p69, p70, p71) -- name: calculateRawMoveVector
	-- upvalues: (copy) v_u_6, (copy) v_u_9, (copy) v_u_68
	local v72 = v_u_6.CurrentCamera
	if not v72 then
		return p71
	end
	local v73 = v72.CFrame
	if v_u_9.VREnabled and p70.RootPart then
		v_u_9:GetUserCFrame(Enum.UserCFrame.Head)
		local v74 = p69:GetEstimatedVRTorsoFrame()
		if (v72.Focus.Position - v73.Position).Magnitude < 3 then
			v73 = v73 * v74
		else
			v73 = v72.CFrame * (v74.Rotation + v74.Position * v72.HeadScale)
		end
	end
	if p70:GetState() ~= Enum.HumanoidStateType.Swimming then
		local _, _, _, v79, v76, v77, _, _, v78, _, _, v79 = v73:GetComponents()
		if v78 >= 1 or v78 <= -1 then
			v77 = -v76 * math.sign(v78)
		end
		local v80 = v79 * v79 + v77 * v77
		local v81 = math.sqrt(v80)
		local v82 = (v79 * p71.X + v77 * p71.Z) / v81
		local v83 = (v79 * p71.Z - v77 * p71.X) / v81
		return Vector3.new(v82, 0, v83)
	end
	if not v_u_9.VREnabled then
		return v73:VectorToWorldSpace(p71)
	end
	local v84 = p71.X
	local v85 = p71.Z
	local v86 = Vector3.new(v84, 0, v85)
	if v86.Magnitude < 0.01 then
		return Vector3.new(0, 0, 0)
	end
	local v87 = -v_u_68().Y * 1.3962634015954636
	local v88 = -v86.X
	local v89 = -v86.Z
	local v90 = math.atan2(v88, v89)
	local _, v91, _ = v73:ToEulerAnglesYXZ()
	local v92 = v90 + v91
	return CFrame.fromEulerAnglesYXZ(v87, v92, 0).LookVector
end
function v_u_1.OnRenderStepped(p93, p94) -- name: OnRenderStepped
	-- upvalues: (copy) v_u_18, (copy) v_u_12, (copy) v_u_9, (copy) v_u_2
	if p93.activeController and (p93.activeController.enabled and p93.humanoid) then
		local v95 = p93.activeController:GetMoveVector()
		local v96 = p93.activeController:IsMoveVectorCameraRelative()
		local v97 = p93.controllers[v_u_18]
		if p93.activeControlModule == v_u_18 then
			(v97 or p93:GetClickToMoveController()):OnRenderStepped(p94)
		elseif v97 then
			if v95.magnitude > 0 then
				v97:CleanupPath()
			else
				v97:OnRenderStepped(p94)
				v95 = v97:GetMoveVector()
				v96 = v97:IsMoveVectorCameraRelative()
			end
		end
		if p93.vehicleController and p93.vehicleController.vehicleSeat then
			local v98
			v95, v98 = p93.vehicleController:Update(v95, v96, p93.activeControlModule == v_u_12)
		end
		if v96 and (v_u_9.VREnabled or v95.Magnitude > 0) then
			v95 = p93:calculateRawMoveVector(p93.humanoid, v95)
		end
		p93.inputMoveVector = v95
		if v_u_9.VREnabled then
			v95 = p93:updateVRMoveVector(v95)
		end
		p93.moveFunction(v_u_2.LocalPlayer, v95, false)
	end
end
function v_u_1.updateVRMoveVector(p99, p100) -- name: updateVRMoveVector
	-- upvalues: (copy) v_u_9
	local v101 = workspace.CurrentCamera
	local v102 = (v101.Focus.Position - v101.CFrame.Position).Magnitude < 5
	if p100.Magnitude ~= 0 or (not v102 or (not v_u_9.AvatarGestures or (not p99.humanoid or p99.humanoid.Sit))) then
		return p100
	end
	local v103 = v_u_9:GetUserCFrame(Enum.UserCFrame.Head)
	local v104 = v103.Rotation + v103.Position * v101.HeadScale
	local v105 = -0.7 * p99.humanoid.RootPart.Size.Y / 2
	local v106 = (v101.CFrame * v104 * CFrame.new(0, v105, 0)).Position - p99.humanoid.RootPart.CFrame.Position
	local v107 = v106.x
	local v108 = v106.z
	return Vector3.new(v107, 0, v108)
end
function v_u_1.OnHumanoidSeated(p109, p110, p111) -- name: OnHumanoidSeated
	-- upvalues: (copy) v_u_21
	if p110 then
		if p111 and p111:IsA("VehicleSeat") then
			if not p109.vehicleController then
				p109.vehicleController = p109.vehicleController.new(v_u_21)
			end
			p109.vehicleController:Enable(true, p111)
			return
		end
	elseif p109.vehicleController then
		p109.vehicleController:Enable(false, p111)
	end
end
function v_u_1.OnCharacterAdded(p_u_112, p113) -- name: OnCharacterAdded
	-- upvalues: (copy) v_u_10
	p_u_112.customCharacterMotor = nil
	p_u_112.character = p113
	p_u_112.humanoid = p113:FindFirstChildOfClass("Humanoid")
	if not p_u_112.humanoid and v_u_10.resolve(p113) then
		p_u_112.customCharacterMotor = {
			["RootPart"] = nil,
			["Sit"] = false,
			["GetState"] = nil,
			["RootPart"] = v_u_10.getRootPart(p113),
			["GetState"] = function() -- name: GetState
				return Enum.HumanoidStateType.Running
			end
		}
		p_u_112.humanoid = p_u_112.customCharacterMotor
	end
	p_u_112:UpdateTouchGuiVisibility()
	if p_u_112.humanoidSeatedConn then
		p_u_112.humanoidSeatedConn:Disconnect()
		p_u_112.humanoidSeatedConn = nil
	end
	if p_u_112.humanoid and (p_u_112.humanoid.Seated and p_u_112.humanoid.Seated.Connect) then
		p_u_112.humanoidSeatedConn = p_u_112.humanoid.Seated:Connect(function(p114, p115)
			-- upvalues: (copy) p_u_112
			p_u_112:OnHumanoidSeated(p114, p115)
		end)
	end
end
function v_u_1.OnCharacterRemoving(p116, p117) -- name: OnCharacterRemoving
	if p116.character == p117 then
		p116.character = nil
		p116.humanoid = nil
		p116.customCharacterMotor = nil
		p116:UpdateTouchGuiVisibility()
	end
end
function v_u_1.UpdateTouchGuiVisibility(p118) -- name: UpdateTouchGuiVisibility
	-- upvalues: (copy) v_u_5
	if p118.touchGui then
		local v119 = p118.humanoid
		if v119 then
			v119 = v_u_5.TouchControlsEnabled
		end
		p118.touchGui.Enabled = v119 and true or false
	end
end
function v_u_1.SwitchToController(p120, p121) -- name: SwitchToController
	-- upvalues: (copy) v_u_21
	if p121 then
		if not p120.controllers[p121] then
			p120.controllers[p121] = p121.new(v_u_21)
		end
		if p120.activeController == p120.controllers[p121] then
			if not p120.activeController.enabled then
				p120:UpdateActiveControlModuleEnabled()
			end
		else
			if p120.activeController then
				p120.activeController:Enable(false)
			end
			p120.activeController = p120.controllers[p121]
			p120.activeControlModule = p121
			p120:UpdateActiveControlModuleEnabled()
		end
	else
		if p120.activeController then
			p120.activeController:Enable(false)
		end
		p120.activeController = nil
		p120.activeControlModule = nil
		return
	end
end
function v_u_1.OnLastInputTypeChanged(p122, p123) -- name: OnLastInputTypeChanged
	-- upvalues: (ref) v_u_24, (copy) v_u_23
	if v_u_24 == p123 then
		warn("LastInputType Change listener called with current type.")
	end
	v_u_24 = p123
	if v_u_24 == Enum.UserInputType.Touch then
		local v124, v125 = p122:SelectTouchModule()
		if v125 then
			while not p122.touchControlFrame do
				wait()
			end
			p122:SwitchToController(v124)
		end
	elseif v_u_23[v_u_24] ~= nil then
		local v126 = p122:SelectComputerMovementModule()
		if v126 then
			p122:SwitchToController(v126)
		end
	end
	p122:UpdateTouchGuiVisibility()
end
function v_u_1.OnComputerMovementModeChange(p127) -- name: OnComputerMovementModeChange
	local v128, v129 = p127:SelectComputerMovementModule()
	if v129 then
		p127:SwitchToController(v128)
	end
end
function v_u_1.OnTouchMovementModeChange(p130) -- name: OnTouchMovementModeChange
	local v131, v132 = p130:SelectTouchModule()
	if v132 then
		while not p130.touchControlFrame do
			wait()
		end
		p130:SwitchToController(v131)
	end
end
function v_u_1.CreateTouchGuiContainer(p133) -- name: CreateTouchGuiContainer
	-- upvalues: (ref) v_u_16
	if p133.touchGui then
		p133.touchGui:Destroy()
	end
	p133.touchGui = Instance.new("ScreenGui")
	p133.touchGui.Name = "TouchGui"
	p133.touchGui.ResetOnSpawn = false
	p133.touchGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	p133:UpdateTouchGuiVisibility()
	if v_u_16 then
		p133.touchGui.ClipToDeviceSafeArea = false
	end
	p133.touchControlFrame = Instance.new("Frame")
	p133.touchControlFrame.Name = "TouchControlFrame"
	p133.touchControlFrame.Size = UDim2.new(1, 0, 1, 0)
	p133.touchControlFrame.BackgroundTransparency = 1
	p133.touchControlFrame.Parent = p133.touchGui
	p133.touchGui.Parent = p133.playerGui
end
function v_u_1.GetClickToMoveController(p134) -- name: GetClickToMoveController
	-- upvalues: (copy) v_u_18, (copy) v_u_21
	if not p134.controllers[v_u_18] then
		p134.controllers[v_u_18] = v_u_18.new(v_u_21)
	end
	return p134.controllers[v_u_18]
end
return v_u_1.new()
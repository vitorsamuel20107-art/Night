-- NIGHT Analyzer | Players.jejekwwkwiwi.PlayerScripts.PlayerModule.CommonUtils.FlagUtil
-- ModuleScript | 9 linhas | 213 bytes | hash 49cf6fbc

return {
	["getUserFlag"] = function(p_u_1) -- name: getUserFlag
		local v2, v3 = pcall(function()
			-- upvalues: (copy) p_u_1
			return UserSettings():IsUserFeatureEnabled(p_u_1)
		end)
		return v2 and v3
	end
}
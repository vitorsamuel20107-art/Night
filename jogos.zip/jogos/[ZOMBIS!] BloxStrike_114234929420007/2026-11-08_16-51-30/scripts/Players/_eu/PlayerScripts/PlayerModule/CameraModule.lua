-- NIGHT Analyzer | Players.jejekwwkwiwi.PlayerScripts.PlayerModule.CameraModule
-- ModuleScript | 497 linhas | 17911 bytes | hash 74666c26

local v_u_1 = {}
v_u_1.__index = v_u_1
local v_u_2 = {
	"CameraMinZoomDistance",
	"CameraMaxZoomDistance",
	"CameraMode",
	"DevCameraOcclusionMode",
	"DevComputerCameraMode",
	"DevTouchCameraMode",
	"DevComputerMovementMode",
	"DevTouchMovementMode",
	"DevEnableMouseLock"
}
local v_u_3 = {
	"ComputerCameraMovementMode",
	"ComputerMovementMode",
	"ControlMode",
	"GamepadCameraSensitivity",
	"MouseSensitivity",
	"RotationType",
	"TouchCameraMovementMode",
	"TouchMovementMode"
}
local v_u_4 = game:GetService("Players")
local v_u_5 = game:GetService("RunService")
local v_u_6 = game:GetService("UserInputService")
local v_u_7 = game:GetService("VRService")
local v_u_8 = UserSettings():GetService("UserGameSettings")
local v9 = game:GetService("ReplicatedStorage")
local v10 = script.Parent:WaitForChild("CommonUtils")
local v_u_11 = require(v10:WaitForChild("ConnectionUtil"))
local v12 = require(v10:WaitForChild("FlagUtil"))
local v_u_13 = require(script:WaitForChild("CameraUtils"))
local v_u_14 = require(script:WaitForChild("CameraInput"))
local v_u_15 = require(script:WaitForChild("ClassicCamera"))
local v_u_16 = require(script:WaitForChild("OrbitalCamera"))
local v_u_17 = require(script:WaitForChild("LegacyCamera"))
local v_u_18 = require(script:WaitForChild("VehicleCamera"))
local v_u_19 = require(script:WaitForChild("VRCamera"))
local v_u_20 = require(script:WaitForChild("VRVehicleCamera"))
local v_u_21 = require(script:WaitForChild("Invisicam"))
local v_u_22 = require(script:WaitForChild("Poppercam"))
local v_u_23 = require(script:WaitForChild("TransparencyController"))
local v_u_24 = require(script:WaitForChild("MouseLockController"))
local v_u_25 = require(v9.Components.Common.CharacterResolver)
local v_u_26 = {}
local v_u_27 = {}
if not v_u_4.LocalPlayer then
	return {}
end
local v28 = v_u_4.LocalPlayer
assert(v28, "Strict typing check")
local v29 = v_u_4.LocalPlayer:WaitForChild("PlayerScripts")
v29:RegisterTouchCameraMovementMode(Enum.TouchCameraMovementMode.Default)
v29:RegisterTouchCameraMovementMode(Enum.TouchCameraMovementMode.Follow)
v29:RegisterTouchCameraMovementMode(Enum.TouchCameraMovementMode.Classic)
v29:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.Default)
v29:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.Follow)
v29:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.Classic)
v29:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.CameraToggle)
local v_u_30 = v12.getUserFlag("UserRespectLegacyCameraOptions")
v12.getUserFlag("UserPlayerConnectionMemoryLeak")
function v_u_1.new() -- name: new
	-- upvalues: (copy) v_u_23, (copy) v_u_11, (copy) v_u_1, (copy) v_u_4, (copy) v_u_6, (copy) v_u_24, (copy) v_u_30, (copy) v_u_5, (copy) v_u_2, (copy) v_u_3, (copy) v_u_8
	local v31 = {
		["activeTransparencyController"] = v_u_23.new(),
		["connectionUtil"] = v_u_11.new()
	}
	local v32 = v_u_1
	local v_u_33 = setmetatable(v31, v32)
	v_u_33.activeCameraController = nil
	v_u_33.activeOcclusionModule = nil
	v_u_33.activeMouseLockController = nil
	v_u_33.currentComputerCameraMovementMode = nil
	v_u_33.cameraSubjectChangedConn = nil
	v_u_33.cameraTypeChangedConn = nil
	v_u_33.renderStepName = "cameraRenderUpdate"
	for _, v34 in pairs(v_u_4:GetPlayers()) do
		v_u_33:OnPlayerAdded(v34)
	end
	v_u_33.connectionUtil:trackConnection("Players.PlayerAdded", v_u_4.PlayerAdded:Connect(function(p35)
		-- upvalues: (copy) v_u_33
		v_u_33:OnPlayerAdded(p35)
	end))
	v_u_33.connectionUtil:trackConnection("Players.PlayerRemoving", v_u_4.PlayerRemoving:Connect(function(p36)
		-- upvalues: (copy) v_u_33
		v_u_33:OnPlayerRemoving(p36)
	end))
	v_u_33.activeTransparencyController:Enable(true)
	if not v_u_6.TouchEnabled then
		v_u_33.activeMouseLockController = v_u_24.new()
		local v37 = v_u_33.activeMouseLockController
		assert(v37, "Strict typing check")
		local v38 = v_u_33.activeMouseLockController:GetBindableToggleEvent()
		if v38 then
			v_u_33.connectionUtil:trackConnection("MouseLockToggleEvent", v38:Connect(function()
				-- upvalues: (copy) v_u_33
				v_u_33:OnMouseLockToggled()
			end))
		end
	end
	if v_u_30 then
		v_u_33:ActivateCameraController()
	else
		v_u_33:ActivateCameraController(v_u_33:GetCameraControlChoice())
	end
	v_u_33:ActivateOcclusionModule(v_u_4.LocalPlayer.DevCameraOcclusionMode)
	v_u_33:OnCurrentCameraChanged()
	v_u_5:BindToRenderStep(v_u_33.renderStepName, Enum.RenderPriority.Camera.Value, function(p39)
		-- upvalues: (copy) v_u_33
		v_u_33:Update(p39)
	end)
	for _, v_u_40 in pairs(v_u_2) do
		v_u_33.connectionUtil:trackConnection(("LocalPlayer.%*"):format(v_u_40), v_u_4.LocalPlayer:GetPropertyChangedSignal(v_u_40):Connect(function()
			-- upvalues: (copy) v_u_33, (copy) v_u_40
			v_u_33:OnLocalPlayerCameraPropertyChanged(v_u_40)
		end))
	end
	for _, v_u_41 in pairs(v_u_3) do
		v_u_33.connectionUtil:trackConnection(("UserGameSettings.%*"):format(v_u_41), v_u_8:GetPropertyChangedSignal(v_u_41):Connect(function()
			-- upvalues: (copy) v_u_33, (copy) v_u_41
			v_u_33:OnUserGameSettingsPropertyChanged(v_u_41)
		end))
	end
	v_u_33.connectionUtil:trackConnection("Workspace.CurrentCamera", workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
		-- upvalues: (copy) v_u_33
		v_u_33:OnCurrentCameraChanged()
	end))
	return v_u_33
end
function v_u_1.GetCameraMovementModeFromSettings(_) -- name: GetCameraMovementModeFromSettings
	-- upvalues: (copy) v_u_4, (copy) v_u_13, (copy) v_u_6, (copy) v_u_8
	if v_u_4.LocalPlayer.CameraMode == Enum.CameraMode.LockFirstPerson then
		return v_u_13.ConvertCameraModeEnumToStandard(Enum.ComputerCameraMovementMode.Classic)
	else
		local v42, v43
		if v_u_6.TouchEnabled then
			v42 = v_u_13.ConvertCameraModeEnumToStandard(v_u_4.LocalPlayer.DevTouchCameraMode)
			v43 = v_u_13.ConvertCameraModeEnumToStandard(v_u_8.TouchCameraMovementMode)
		else
			v42 = v_u_13.ConvertCameraModeEnumToStandard(v_u_4.LocalPlayer.DevComputerCameraMode)
			v43 = v_u_13.ConvertCameraModeEnumToStandard(v_u_8.ComputerCameraMovementMode)
		end
		if v42 == Enum.DevComputerCameraMovementMode.UserChoice then
			return v43
		else
			return v42
		end
	end
end
function v_u_1.ActivateOcclusionModule(p44, p45) -- name: ActivateOcclusionModule
	-- upvalues: (copy) v_u_22, (copy) v_u_21, (copy) v_u_27, (copy) v_u_25, (copy) v_u_4
	local v46
	if p45 == Enum.DevCameraOcclusionMode.Zoom then
		v46 = v_u_22
	else
		if p45 ~= Enum.DevCameraOcclusionMode.Invisicam then
			warn("CameraScript ActivateOcclusionModule called with unsupported mode")
			return
		end
		v46 = v_u_21
	end
	p44.occlusionMode = p45
	if p44.activeOcclusionModule and p44.activeOcclusionModule:GetOcclusionMode() == p45 then
		if not p44.activeOcclusionModule:GetEnabled() then
			p44.activeOcclusionModule:Enable(true)
		end
	else
		local v47 = p44.activeOcclusionModule
		p44.activeOcclusionModule = v_u_27[v46]
		if not p44.activeOcclusionModule then
			p44.activeOcclusionModule = v46.new()
			if p44.activeOcclusionModule then
				v_u_27[v46] = p44.activeOcclusionModule
			end
		end
		if p44.activeOcclusionModule then
			if p44.activeOcclusionModule:GetOcclusionMode() ~= p45 then
				warn("CameraScript ActivateOcclusionModule mismatch: ", p44.activeOcclusionModule:GetOcclusionMode(), "~=", p45)
			end
			if v47 then
				if v47 == p44.activeOcclusionModule then
					warn("CameraScript ActivateOcclusionModule failure to detect already running correct module")
				else
					v47:Enable(false)
				end
			end
			if p45 == Enum.DevCameraOcclusionMode.Invisicam then
				local v48 = v_u_25.getPlayerCharacter(v_u_4.LocalPlayer)
				if v48 then
					p44.activeOcclusionModule:CharacterAdded(v48, v_u_4.LocalPlayer)
				end
			else
				for _, v49 in pairs(v_u_4:GetPlayers()) do
					local v50
					if v49 then
						v50 = v_u_25.getPlayerCharacter(v49)
					else
						v50 = v49
					end
					if not v50 then
						continue
					end
					p44.activeOcclusionModule:CharacterAdded(v50, v49)
				end
				p44.activeOcclusionModule:OnCameraSubjectChanged(workspace.CurrentCamera.CameraSubject)
			end
			p44.activeOcclusionModule:Enable(true)
		end
	end
end
function v_u_1.ShouldUseVehicleCamera(p51) -- name: ShouldUseVehicleCamera
	local v52 = workspace.CurrentCamera
	if not v52 then
		return false
	end
	local v53 = v52.CameraType
	local v54 = v52.CameraSubject
	local v55 = v53 == Enum.CameraType.Custom and true or v53 == Enum.CameraType.Follow
	local v56 = v54 and v54:IsA("VehicleSeat") or false
	local v57 = p51.occlusionMode ~= Enum.DevCameraOcclusionMode.Invisicam
	if v56 then
		if not v55 then
			v57 = v55
		end
	else
		v57 = v56
	end
	return v57
end
function v_u_1.ActivateCameraController(p58, p59, p60) -- name: ActivateCameraController
	-- upvalues: (copy) v_u_30, (copy) v_u_17, (copy) v_u_7, (copy) v_u_19, (copy) v_u_15, (copy) v_u_16, (copy) v_u_20, (copy) v_u_18, (copy) v_u_26
	if v_u_30 then
		p60 = workspace.CurrentCamera.CameraType
		p59 = p58:GetCameraMovementModeFromSettings()
	end
	local v61 = nil
	if v_u_30 and true or p60 ~= nil then
		if p60 == Enum.CameraType.Scriptable then
			if p58.activeCameraController then
				p58.activeCameraController:Enable(false)
				p58.activeCameraController = nil
			end
			return
		end
		if p60 == Enum.CameraType.Custom then
			p59 = p58:GetCameraMovementModeFromSettings()
		elseif p60 == Enum.CameraType.Track then
			p59 = Enum.ComputerCameraMovementMode.Classic
		elseif p60 == Enum.CameraType.Follow then
			p59 = Enum.ComputerCameraMovementMode.Follow
		elseif p60 == Enum.CameraType.Orbital then
			p59 = Enum.ComputerCameraMovementMode.Orbital
		elseif p60 == Enum.CameraType.Attach or (p60 == Enum.CameraType.Watch or p60 == Enum.CameraType.Fixed) then
			v61 = v_u_17
		else
			warn("CameraScript encountered an unhandled Camera.CameraType value: ", p60)
		end
	end
	if not v61 then
		if v_u_7.VREnabled then
			v61 = v_u_19
		elseif p59 == Enum.ComputerCameraMovementMode.Classic or (p59 == Enum.ComputerCameraMovementMode.Follow or (p59 == Enum.ComputerCameraMovementMode.Default or p59 == Enum.ComputerCameraMovementMode.CameraToggle)) then
			v61 = v_u_15
		else
			if p59 ~= Enum.ComputerCameraMovementMode.Orbital then
				warn("ActivateCameraController did not select a module.")
				return
			end
			v61 = v_u_16
		end
	end
	if p58:ShouldUseVehicleCamera() then
		if v_u_7.VREnabled then
			v61 = v_u_20
		else
			v61 = v_u_18
		end
	end
	local v62
	if v_u_26[v61] then
		v62 = v_u_26[v61]
		if v62.Reset then
			v62:Reset()
		end
	else
		v62 = v61.new()
		v_u_26[v61] = v62
	end
	if p58.activeCameraController then
		if p58.activeCameraController == v62 then
			if not p58.activeCameraController:GetEnabled() then
				p58.activeCameraController:Enable(true)
			end
		else
			p58.activeCameraController:Enable(false)
			p58.activeCameraController = v62
			p58.activeCameraController:Enable(true)
		end
	elseif v62 ~= nil then
		p58.activeCameraController = v62
		local v63 = p58.activeCameraController
		assert(v63, "Strict typing check")
		p58.activeCameraController:Enable(true)
	end
	if p58.activeCameraController then
		if v_u_30 then
			p58.activeCameraController:SetCameraMovementMode(p59)
			p58.activeCameraController:SetCameraType(p60)
			return
		end
		if p59 ~= nil then
			p58.activeCameraController:SetCameraMovementMode(p59)
			return
		end
		if p60 ~= nil then
			p58.activeCameraController:SetCameraType(p60)
		end
	end
end
function v_u_1.OnCameraSubjectChanged(p64) -- name: OnCameraSubjectChanged
	local v65 = workspace.CurrentCamera
	local v66
	if v65 then
		v66 = v65.CameraSubject
	else
		v66 = nil
	end
	if p64.activeTransparencyController then
		p64.activeTransparencyController:SetSubject(v66)
	end
	if p64.activeOcclusionModule then
		p64.activeOcclusionModule:OnCameraSubjectChanged(v66)
	end
	local v67 = nil
	local v68
	if v65 then
		v68 = v65.CameraType
	else
		v68 = nil
	end
	p64:ActivateCameraController(v67, v68)
end
function v_u_1.OnCameraTypeChanged(p69, p70) -- name: OnCameraTypeChanged
	-- upvalues: (copy) v_u_6, (copy) v_u_13
	if p70 == Enum.CameraType.Scriptable and v_u_6.MouseBehavior == Enum.MouseBehavior.LockCenter then
		v_u_13.restoreMouseBehavior()
	end
	p69:ActivateCameraController(nil, p70)
end
function v_u_1.OnCurrentCameraChanged(p_u_71) -- name: OnCurrentCameraChanged
	local v_u_72 = workspace.CurrentCamera
	if v_u_72 then
		if p_u_71.cameraSubjectChangedConn then
			p_u_71.cameraSubjectChangedConn:Disconnect()
		end
		if p_u_71.cameraTypeChangedConn then
			p_u_71.cameraTypeChangedConn:Disconnect()
		end
		p_u_71.cameraSubjectChangedConn = v_u_72:GetPropertyChangedSignal("CameraSubject"):Connect(function()
			-- upvalues: (copy) p_u_71
			p_u_71:OnCameraSubjectChanged()
		end)
		p_u_71.cameraTypeChangedConn = v_u_72:GetPropertyChangedSignal("CameraType"):Connect(function()
			-- upvalues: (copy) p_u_71, (copy) v_u_72
			p_u_71:OnCameraTypeChanged(v_u_72.CameraType)
		end)
		p_u_71:OnCameraSubjectChanged()
		p_u_71:OnCameraTypeChanged(v_u_72.CameraType)
	end
end
function v_u_1.OnLocalPlayerCameraPropertyChanged(p73, p74) -- name: OnLocalPlayerCameraPropertyChanged
	-- upvalues: (copy) v_u_4, (copy) v_u_13
	if p74 == "CameraMode" then
		if v_u_4.LocalPlayer.CameraMode ~= Enum.CameraMode.LockFirstPerson then
			if v_u_4.LocalPlayer.CameraMode == Enum.CameraMode.Classic then
				local v75 = p73:GetCameraMovementModeFromSettings()
				p73:ActivateCameraController(v_u_13.ConvertCameraModeEnumToStandard(v75))
			else
				warn("Unhandled value for property player.CameraMode: ", v_u_4.LocalPlayer.CameraMode)
			end
		end
		if not p73.activeCameraController or p73.activeCameraController:GetModuleName() ~= "ClassicCamera" then
			p73:ActivateCameraController(v_u_13.ConvertCameraModeEnumToStandard(Enum.DevComputerCameraMovementMode.Classic))
		end
		if p73.activeCameraController then
			p73.activeCameraController:UpdateForDistancePropertyChange()
			return
		end
	else
		if p74 == "DevComputerCameraMode" or p74 == "DevTouchCameraMode" then
			local v76 = p73:GetCameraMovementModeFromSettings()
			p73:ActivateCameraController(v_u_13.ConvertCameraModeEnumToStandard(v76))
			return
		end
		if p74 == "DevCameraOcclusionMode" then
			p73:ActivateOcclusionModule(v_u_4.LocalPlayer.DevCameraOcclusionMode)
			return
		end
		if p74 == "CameraMinZoomDistance" or p74 == "CameraMaxZoomDistance" then
			if p73.activeCameraController then
				p73.activeCameraController:UpdateForDistancePropertyChange()
				return
			end
		else
			if p74 == "DevTouchMovementMode" then
				return
			end
			if p74 == "DevComputerMovementMode" then
				return
			end
			local _ = p74 == "DevEnableMouseLock"
		end
	end
end
function v_u_1.OnUserGameSettingsPropertyChanged(p77, p78) -- name: OnUserGameSettingsPropertyChanged
	-- upvalues: (copy) v_u_13
	if p78 == "ComputerCameraMovementMode" then
		local v79 = p77:GetCameraMovementModeFromSettings()
		p77:ActivateCameraController(v_u_13.ConvertCameraModeEnumToStandard(v79))
	end
end
function v_u_1.Update(p80, p81) -- name: Update
	-- upvalues: (copy) v_u_14
	if p80.activeCameraController then
		p80.activeCameraController:UpdateMouseBehavior()
		local v82, v83 = p80.activeCameraController:Update(p81)
		if p80.activeOcclusionModule then
			v82, v83 = p80.activeOcclusionModule:Update(p81, v82, v83)
		end
		local v84 = workspace.CurrentCamera
		v84.CFrame = v82
		v84.Focus = v83
		if p80.activeTransparencyController then
			p80.activeTransparencyController:Update(p81)
		end
		if v_u_14.getInputEnabled() then
			v_u_14.resetInputForFrameEnd()
		end
	end
end
function v_u_1.GetCameraControlChoice(_) -- name: GetCameraControlChoice
	-- upvalues: (copy) v_u_30, (copy) v_u_6, (copy) v_u_4, (copy) v_u_13, (copy) v_u_8
	local v85 = not v_u_30
	assert(v85, "CameraModule:GetCameraControlChoice should not be called when FFlagUserRespectLegacyCameraOptions is enabled")
	if v_u_6:GetLastInputType() == Enum.UserInputType.Touch or v_u_6.TouchEnabled then
		if v_u_4.LocalPlayer.DevTouchCameraMode == Enum.DevTouchCameraMovementMode.UserChoice then
			return v_u_13.ConvertCameraModeEnumToStandard(v_u_8.TouchCameraMovementMode)
		else
			return v_u_13.ConvertCameraModeEnumToStandard(v_u_4.LocalPlayer.DevTouchCameraMode)
		end
	else
		if v_u_4.LocalPlayer.DevComputerCameraMode ~= Enum.DevComputerCameraMovementMode.UserChoice then
			return v_u_13.ConvertCameraModeEnumToStandard(v_u_4.LocalPlayer.DevComputerCameraMode)
		end
		local v86 = v_u_13.ConvertCameraModeEnumToStandard(v_u_8.ComputerCameraMovementMode)
		return v_u_13.ConvertCameraModeEnumToStandard(v86)
	end
end
function v_u_1.OnCharacterAdded(p87, p88, p89) -- name: OnCharacterAdded
	if p87.activeOcclusionModule then
		p87.activeOcclusionModule:CharacterAdded(p88, p89)
	end
end
function v_u_1.OnCharacterRemoving(p90, p91, p92) -- name: OnCharacterRemoving
	if p90.activeOcclusionModule then
		p90.activeOcclusionModule:CharacterRemoving(p91, p92)
	end
end
function v_u_1.OnPlayerAdded(p_u_93, p_u_94) -- name: OnPlayerAdded
	-- upvalues: (copy) v_u_25
	p_u_93.connectionUtil:trackBoundFunction(("%*CharacterObserver"):format(p_u_94.UserId), v_u_25.observeCharacter(p_u_94, function(p95, p96)
		-- upvalues: (copy) p_u_93, (copy) p_u_94
		if p96 and p96 ~= p95 then
			p_u_93:OnCharacterRemoving(p96, p_u_94)
		end
		if p95 then
			p_u_93:OnCharacterAdded(p95, p_u_94)
		end
		return function() end
	end))
end
function v_u_1.OnPlayerRemoving(p97, p98) -- name: OnPlayerRemoving
	p97.connectionUtil:disconnect((("%*CharacterObserver"):format(p98.UserId)))
end
function v_u_1.OnMouseLockToggled(p99) -- name: OnMouseLockToggled
	if p99.activeMouseLockController then
		local v100 = p99.activeMouseLockController:GetIsMouseLocked()
		local v101 = p99.activeMouseLockController:GetMouseLockOffset()
		if p99.activeCameraController then
			p99.activeCameraController:SetIsMouseLocked(v100)
			p99.activeCameraController:SetMouseLockOffset(v101)
		end
	end
end
v_u_1.new()
return {}
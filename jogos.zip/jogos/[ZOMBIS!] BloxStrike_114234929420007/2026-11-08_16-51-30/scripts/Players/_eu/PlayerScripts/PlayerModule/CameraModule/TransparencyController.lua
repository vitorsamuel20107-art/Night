-- NIGHT Analyzer | Players.jejekwwkwiwi.PlayerScripts.PlayerModule.CameraModule.TransparencyController
-- ModuleScript | 246 linhas | 7141 bytes | hash 04064e82

local v_u_1 = game:GetService("VRService")
local v_u_2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = {
	"BasePart",
	"Decal",
	"Beam",
	"ParticleEmitter",
	"Trail",
	"Fire",
	"Smoke",
	"Sparkles",
	"Explosion"
}
local v_u_5 = {
	[Enum.AccessoryType.Hat] = true,
	[Enum.AccessoryType.Hair] = true,
	[Enum.AccessoryType.Face] = true,
	[Enum.AccessoryType.Eyebrow] = true,
	[Enum.AccessoryType.Eyelash] = true
}
local v_u_6 = require(script.Parent:WaitForChild("CameraUtils"))
local v_u_7 = require(v3.Components.Common.CharacterResolver)
local v8, v9 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserHideCharacterParticlesInFirstPerson")
end)
local v_u_10 = v8 and v9
local v_u_11 = {}
v_u_11.__index = v_u_11
local function v_u_15(p12) -- name: resolveSubjectCharacter
	if not p12 then
		return nil
	end
	if p12:IsA("Humanoid") then
		local v13 = p12.Parent
		if v13 and v13:IsA("Model") then
			return v13
		end
	elseif p12:IsA("VehicleSeat") and p12.Occupant then
		local v14 = p12.Occupant.Parent
		if v14 and v14:IsA("Model") then
			return v14
		end
	else
		if p12:IsA("BasePart") then
			return p12:FindFirstAncestorOfClass("Model")
		end
		if p12:IsA("Model") then
			return p12
		end
	end
	return nil
end
function v_u_11.new() -- name: new
	-- upvalues: (copy) v_u_11
	local v16 = v_u_11
	local v17 = setmetatable({}, v16)
	v17.transparencyDirty = false
	v17.enabled = false
	v17.lastTransparency = nil
	v17.descendantAddedConn = nil
	v17.descendantRemovingConn = nil
	v17.toolDescendantAddedConns = {}
	v17.toolDescendantRemovingConns = {}
	v17.cachedParts = {}
	v17.character = nil
	return v17
end
function v_u_11.HasToolAncestor(p18, p19) -- name: HasToolAncestor
	if p19.Parent == nil then
		return false
	end
	local v20 = p19.Parent
	assert(v20, "")
	return p19.Parent:IsA("Tool") or p18:HasToolAncestor(p19.Parent)
end
function v_u_11.IsValidPartToModify(p21, p22) -- name: IsValidPartToModify
	-- upvalues: (ref) v_u_10, (copy) v_u_4
	if v_u_10 then
		for _, v23 in v_u_4 do
			if not p22:IsA(v23) then
				continue
			end
			return not p21:HasToolAncestor(p22)
		end
	elseif p22:IsA("BasePart") or p22:IsA("Decal") then
		return not p21:HasToolAncestor(p22)
	end
	return false
end
function v_u_11.CachePartsRecursive(p24, p25) -- name: CachePartsRecursive
	if p25 then
		if p24:IsValidPartToModify(p25) then
			p24.cachedParts[p25] = true
			p24.transparencyDirty = true
		end
		for _, v26 in pairs(p25:GetChildren()) do
			p24:CachePartsRecursive(v26)
		end
	end
end
function v_u_11.TeardownTransparency(p27) -- name: TeardownTransparency
	-- upvalues: (copy) v_u_2
	local v28 = p27.character and (p27.character:GetAttribute("Dead") ~= true and v_u_2.LocalPlayer)
	if v28 then
		if v_u_2.LocalPlayer.Character == p27.character then
			v28 = v_u_2.LocalPlayer:GetAttribute("IsSpectating") == true
		else
			v28 = false
		end
	end
	for v29, _ in pairs(p27.cachedParts) do
		v29.LocalTransparencyModifier = v28 and 1 or 0
	end
	p27.cachedParts = {}
	p27.character = nil
	p27.transparencyDirty = true
	p27.lastTransparency = nil
	if p27.descendantAddedConn then
		p27.descendantAddedConn:disconnect()
		p27.descendantAddedConn = nil
	end
	if p27.descendantRemovingConn then
		p27.descendantRemovingConn:disconnect()
		p27.descendantRemovingConn = nil
	end
	for v30, v31 in pairs(p27.toolDescendantAddedConns) do
		v31:Disconnect()
		p27.toolDescendantAddedConns[v30] = nil
	end
	for v32, v33 in pairs(p27.toolDescendantRemovingConns) do
		v33:Disconnect()
		p27.toolDescendantRemovingConns[v32] = nil
	end
end
function v_u_11.SetupTransparency(p_u_34, p_u_35) -- name: SetupTransparency
	p_u_34:TeardownTransparency()
	p_u_34.character = p_u_35
	if p_u_34.descendantAddedConn then
		p_u_34.descendantAddedConn:disconnect()
	end
	p_u_34.descendantAddedConn = p_u_35.DescendantAdded:Connect(function(p36)
		-- upvalues: (copy) p_u_34, (copy) p_u_35
		if p_u_34:IsValidPartToModify(p36) then
			p_u_34.cachedParts[p36] = true
			p_u_34.transparencyDirty = true
		elseif p36:IsA("Tool") then
			if p_u_34.toolDescendantAddedConns[p36] then
				p_u_34.toolDescendantAddedConns[p36]:Disconnect()
			end
			p_u_34.toolDescendantAddedConns[p36] = p36.DescendantAdded:Connect(function(p37)
				-- upvalues: (ref) p_u_34
				p_u_34.cachedParts[p37] = nil
				if p37:IsA("BasePart") or p37:IsA("Decal") then
					p37.LocalTransparencyModifier = 0
				end
			end)
			if p_u_34.toolDescendantRemovingConns[p36] then
				p_u_34.toolDescendantRemovingConns[p36]:disconnect()
			end
			p_u_34.toolDescendantRemovingConns[p36] = p36.DescendantRemoving:Connect(function(p38)
				-- upvalues: (ref) p_u_35, (ref) p_u_34
				wait()
				if p_u_35 and (p38 and (p38:IsDescendantOf(p_u_35) and p_u_34:IsValidPartToModify(p38))) then
					p_u_34.cachedParts[p38] = true
					p_u_34.transparencyDirty = true
				end
			end)
		end
	end)
	if p_u_34.descendantRemovingConn then
		p_u_34.descendantRemovingConn:disconnect()
	end
	p_u_34.descendantRemovingConn = p_u_35.DescendantRemoving:connect(function(p39)
		-- upvalues: (copy) p_u_34
		if p_u_34.cachedParts[p39] then
			p_u_34.cachedParts[p39] = nil
			p39.LocalTransparencyModifier = 0
		end
	end)
	p_u_34:CachePartsRecursive(p_u_35)
end
function v_u_11.Enable(p40, p41) -- name: Enable
	if p40.enabled ~= p41 then
		p40.enabled = p41
	end
end
function v_u_11.SetSubject(p42, p43) -- name: SetSubject
	-- upvalues: (copy) v_u_15, (copy) v_u_7
	local v44 = v_u_15(p43)
	if v44 and not v_u_7.getPlayerFromCharacter(v44) then
		v44 = nil
	end
	if v44 then
		p42:SetupTransparency(v44)
	else
		p42:TeardownTransparency()
	end
end
function v_u_11.Update(p45, p46) -- name: Update
	-- upvalues: (copy) v_u_15, (copy) v_u_7, (copy) v_u_2, (copy) v_u_6, (copy) v_u_1, (copy) v_u_5
	local v47 = workspace.CurrentCamera
	if v47 and p45.enabled then
		local v48 = v_u_15(v47.CameraSubject)
		local v49 = v_u_7.getLocalCharacter()
		local v50
		if v48 == nil or v49 ~= v48 then
			v50 = false
		else
			v50 = v_u_2.LocalPlayer.CameraMode == Enum.CameraMode.LockFirstPerson
		end
		local v51 = (v47.Focus.p - v47.CoordinateFrame.p).magnitude
		local v52 = v50 and 1 or (v51 < 2 and 1 - (v51 - 0.5) / 1.5 or 0)
		local v53 = v52 < 0.5 and 0 or v52
		if p45.lastTransparency and (v53 < 1 and p45.lastTransparency < 0.95) then
			local v54 = v53 - p45.lastTransparency
			local v55 = 2.8 * p46
			local v56 = -v55
			local v57 = math.clamp(v54, v56, v55)
			v53 = p45.lastTransparency + v57
		end
		local v58 = v_u_6.Round(v53, 2)
		local v59 = math.clamp(v58, 0, 1)
		if p45.transparencyDirty or p45.lastTransparency ~= v59 then
			local v60 = v_u_1.VREnabled
			if v60 then
				v60 = v_u_1.AvatarGestures
			end
			for v61, _ in pairs(p45.cachedParts) do
				if v60 then
					local v62 = v61.Parent
					if v62 and (v62:IsA("Accessory") and v_u_5[v62.AccessoryType]) or v61.Name == "Head" then
						v61.LocalTransparencyModifier = v59
					else
						v61.LocalTransparencyModifier = 0
					end
				else
					v61.LocalTransparencyModifier = v59
				end
			end
			p45.transparencyDirty = false
			p45.lastTransparency = v59
		end
	end
end
return v_u_11
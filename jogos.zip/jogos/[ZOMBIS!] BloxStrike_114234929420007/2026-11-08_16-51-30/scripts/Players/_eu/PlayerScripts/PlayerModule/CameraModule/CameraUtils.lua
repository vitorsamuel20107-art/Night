-- NIGHT Analyzer | Players.jejekwwkwiwi.PlayerScripts.PlayerModule.CameraModule.CameraUtils
-- ModuleScript | 225 linhas | 7059 bytes | hash be338352

local v_u_1 = game:GetService("UserInputService")
local v_u_2 = UserSettings():GetService("UserGameSettings")
local v_u_3 = {}
local v_u_4 = {}
v_u_4.__index = v_u_4
function v_u_4.new(p5, p6) -- name: new
	-- upvalues: (copy) v_u_4
	local v7 = v_u_4
	return setmetatable({
		["freq"] = nil,
		["goal"] = nil,
		["pos"] = nil,
		["vel"] = 0,
		["freq"] = p5,
		["goal"] = p6,
		["pos"] = p6
	}, v7)
end
function v_u_4.step(p8, p9) -- name: step
	local v10 = p8.freq * 2 * 3.141592653589793
	local v11 = p8.goal
	local v12 = p8.pos
	local v13 = p8.vel
	local v14 = v12 - v11
	local v15 = -v10 * p9
	local v16 = math.exp(v15)
	local v17 = (v14 * (v10 * p9 + 1) + v13 * p9) * v16 + v11
	local v18 = (v13 * (1 - v10 * p9) - v14 * (v10 * v10 * p9)) * v16
	p8.pos = v17
	p8.vel = v18
	return v17
end
v_u_3.Spring = v_u_4
function v_u_3.map(p19, p20, p21, p22, p23) -- name: map
	return (p19 - p20) * (p23 - p22) / (p21 - p20) + p22
end
function v_u_3.mapClamp(p24, p25, p26, p27, p28) -- name: mapClamp
	local v29 = (p24 - p25) * (p28 - p27) / (p26 - p25) + p27
	local v30 = math.min(p27, p28)
	local v31 = math.max(p27, p28)
	return math.clamp(v29, v30, v31)
end
function v_u_3.getLooseBoundingSphere(p32) -- name: getLooseBoundingSphere
	local v33 = table.create(#p32)
	for v34, v35 in pairs(p32) do
		v33[v34] = v35.Position
	end
	local v36 = v33[1]
	local v37 = v36
	local v38 = 0
	for _, v39 in ipairs(v33) do
		local v40 = (v39 - v36).Magnitude
		if v38 >= v40 then
			continue
		end
		v37 = v39
		v38 = v40
	end
	local v41 = v37
	local v42 = 0
	for _, v43 in ipairs(v33) do
		local v44 = (v43 - v37).Magnitude
		if v42 >= v44 then
			continue
		end
		v41 = v43
		v42 = v44
	end
	local v45 = (v37 + v41) * 0.5
	local v46 = (v37 - v41).Magnitude * 0.5
	for _, v47 in ipairs(v33) do
		local v48 = (v47 - v45).Magnitude
		if v46 >= v48 then
			continue
		end
		v45 = v45 + (v48 - v46) * 0.5 * (v47 - v45).Unit
		v46 = (v48 + v46) * 0.5
	end
	return v45, v46
end
function v_u_3.sanitizeAngle(p49) -- name: sanitizeAngle
	return (p49 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
end
function v_u_3.Round(p50, p51) -- name: Round
	local v52 = 10 ^ p51
	local v53 = p50 * v52 + 0.5
	return math.floor(v53) / v52
end
function v_u_3.IsFinite(p54) -- name: IsFinite
	local v55
	if p54 == p54 and p54 ~= (1 / 0) then
		v55 = p54 ~= (-1 / 0)
	else
		v55 = false
	end
	return v55
end
function v_u_3.IsFiniteVector3(p56) -- name: IsFiniteVector3
	-- upvalues: (copy) v_u_3
	local v57 = v_u_3.IsFinite(p56.X) and v_u_3.IsFinite(p56.Y)
	if v57 then
		v57 = v_u_3.IsFinite(p56.Z)
	end
	return v57
end
function v_u_3.GetAngleBetweenXZVectors(p58, p59) -- name: GetAngleBetweenXZVectors
	local v60 = p59.X * p58.Z - p59.Z * p58.X
	local v61 = p59.X * p58.X + p59.Z * p58.Z
	return math.atan2(v60, v61)
end
function v_u_3.RotateVectorByAngleAndRound(p62, p63, p64) -- name: RotateVectorByAngleAndRound
	if p62.Magnitude <= 0 then
		return 0
	end
	local v65 = p62.Unit
	local v66 = v65.Z
	local v67 = v65.X
	local v68 = math.atan2(v66, v67)
	local v69 = v65.Z
	local v70 = v65.X
	local v71 = (math.atan2(v69, v70) + p63) / p64 + 0.5
	return math.floor(v71) * p64 - v68
end
function v_u_3.GamepadLinearToCurve(p72) -- name: GamepadLinearToCurve
	local v73 = Vector2.new
	local v74 = p72.X
	local v75 = v74 < 0 and -1 or 1
	local v76 = math.abs(v74)
	local v77 = (math.abs(v76) * 2 - 1) * 1.1 - 0.1
	local v78 = math.clamp(v77, -1, 1)
	local v79
	if v78 >= 0 then
		v79 = v78 * 0.35 / (0.35 - v78 + 1)
	else
		v79 = -(-v78 * 0.8 / (v78 + 0.8 + 1))
	end
	local v80 = (v79 / 2 + 0.5) * v75
	local v81 = math.clamp(v80, -1, 1)
	local v82 = p72.Y
	local v83 = v82 < 0 and -1 or 1
	local v84 = math.abs(v82)
	local v85 = (math.abs(v84) * 2 - 1) * 1.1 - 0.1
	local v86 = math.clamp(v85, -1, 1)
	local v87
	if v86 >= 0 then
		v87 = v86 * 0.35 / (0.35 - v86 + 1)
	else
		v87 = -(-v86 * 0.8 / (v86 + 0.8 + 1))
	end
	local v88 = (v87 / 2 + 0.5) * v83
	return v73(v81, (math.clamp(v88, -1, 1)))
end
function v_u_3.ConvertCameraModeEnumToStandard(p89) -- name: ConvertCameraModeEnumToStandard
	if p89 == Enum.TouchCameraMovementMode.Default then
		return Enum.ComputerCameraMovementMode.Follow
	elseif p89 == Enum.ComputerCameraMovementMode.Default then
		return Enum.ComputerCameraMovementMode.Classic
	elseif p89 == Enum.TouchCameraMovementMode.Classic or (p89 == Enum.DevTouchCameraMovementMode.Classic or (p89 == Enum.DevComputerCameraMovementMode.Classic or p89 == Enum.ComputerCameraMovementMode.Classic)) then
		return Enum.ComputerCameraMovementMode.Classic
	elseif p89 == Enum.TouchCameraMovementMode.Follow or (p89 == Enum.DevTouchCameraMovementMode.Follow or (p89 == Enum.DevComputerCameraMovementMode.Follow or p89 == Enum.ComputerCameraMovementMode.Follow)) then
		return Enum.ComputerCameraMovementMode.Follow
	elseif p89 == Enum.TouchCameraMovementMode.Orbital or (p89 == Enum.DevTouchCameraMovementMode.Orbital or (p89 == Enum.DevComputerCameraMovementMode.Orbital or p89 == Enum.ComputerCameraMovementMode.Orbital)) then
		return Enum.ComputerCameraMovementMode.Orbital
	elseif p89 == Enum.ComputerCameraMovementMode.CameraToggle or p89 == Enum.DevComputerCameraMovementMode.CameraToggle then
		return Enum.ComputerCameraMovementMode.CameraToggle
	elseif p89 == Enum.DevTouchCameraMovementMode.UserChoice or p89 == Enum.DevComputerCameraMovementMode.UserChoice then
		return Enum.DevComputerCameraMovementMode.UserChoice
	else
		return Enum.ComputerCameraMovementMode.Classic
	end
end
local v_u_90 = ""
local v_u_91 = nil
function v_u_3.setMouseIconOverride(p92) -- name: setMouseIconOverride
	-- upvalues: (copy) v_u_1, (ref) v_u_91, (ref) v_u_90
	if v_u_1.MouseIcon ~= v_u_91 then
		v_u_90 = v_u_1.MouseIcon
	end
	v_u_1.MouseIcon = p92
	v_u_91 = p92
end
function v_u_3.restoreMouseIcon() -- name: restoreMouseIcon
	-- upvalues: (ref) v_u_91, (copy) v_u_1, (ref) v_u_90
	if v_u_91 ~= nil then
		if v_u_1.MouseIcon == v_u_91 then
			v_u_1.MouseIcon = v_u_90
		end
		v_u_91 = nil
	end
end
local v_u_93 = Enum.MouseBehavior.Default
local v_u_94 = nil
function v_u_3.setMouseBehaviorOverride(p95) -- name: setMouseBehaviorOverride
	-- upvalues: (copy) v_u_1, (ref) v_u_94, (ref) v_u_93
	if v_u_1.MouseBehavior ~= v_u_94 then
		v_u_93 = v_u_1.MouseBehavior
	end
	v_u_1.MouseBehavior = p95
	v_u_94 = p95
end
function v_u_3.restoreMouseBehavior() -- name: restoreMouseBehavior
	-- upvalues: (copy) v_u_1, (ref) v_u_94, (ref) v_u_93
	if v_u_1.MouseBehavior == v_u_94 then
		v_u_1.MouseBehavior = v_u_93
	end
	v_u_94 = nil
end
local v_u_96 = Enum.RotationType.MovementRelative
local v_u_97 = nil
function v_u_3.setRotationTypeOverride(p98) -- name: setRotationTypeOverride
	-- upvalues: (copy) v_u_2, (ref) v_u_97, (ref) v_u_96
	if v_u_2.RotationType ~= v_u_97 then
		v_u_96 = v_u_2.RotationType
	end
	v_u_2.RotationType = p98
	v_u_97 = p98
end
function v_u_3.restoreRotationType() -- name: restoreRotationType
	-- upvalues: (copy) v_u_2, (ref) v_u_97, (ref) v_u_96
	if v_u_2.RotationType == v_u_97 then
		v_u_2.RotationType = v_u_96
	end
	v_u_97 = nil
end
return v_u_3
-- NIGHT Analyzer | Players.jejekwwkwiwi.PlayerScripts.PlayerModule.CameraModule.CameraInput
-- ModuleScript | 461 linhas | 13492 bytes | hash f0e74f3c

local v_u_1 = game:GetService("ContextActionService")
local v_u_2 = game:GetService("UserInputService")
local v3 = game:GetService("Players")
local v4 = game:GetService("RunService")
local v_u_5 = UserSettings():GetService("UserGameSettings")
local v_u_6 = game:GetService("VRService")
local v7 = script.Parent.Parent:WaitForChild("CommonUtils")
local v_u_8 = require(v7:WaitForChild("FlagUtil")).getUserFlag("UserCameraInputDt")
local v_u_9 = v3.LocalPlayer
local v_u_10 = Enum.ContextActionPriority.Medium.Value
local v_u_11 = Vector2.new(1, 0.77) * 0.06981317007977318
local v_u_12 = Vector2.new(1, 0.77) * 0.008726646259971648
local v_u_13 = Vector2.new(1, 0.77) * 0.12217304763960307
local v_u_14 = Vector2.new(1, 0.66) * 0.017453292519943295
if v_u_8 then
	v_u_11 = v_u_11 * 60
end
local v15, v16 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserResetTouchStateOnMenuOpen")
end)
local v_u_17 = v15 and v16
local v18, v19 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserClearPanOnCameraDisable")
end)
local v_u_20 = v18 and v19
local v_u_21 = Instance.new("BindableEvent")
local v_u_22 = Instance.new("BindableEvent")
local v_u_23 = v_u_21.Event
local v_u_24 = v_u_22.Event
v_u_2.InputBegan:Connect(function(p25, p26)
	-- upvalues: (copy) v_u_21
	if not p26 and p25.UserInputType == Enum.UserInputType.MouseButton2 then
		v_u_21:Fire()
	end
end)
v_u_2.InputEnded:Connect(function(p27, _)
	-- upvalues: (copy) v_u_22
	if p27.UserInputType == Enum.UserInputType.MouseButton2 then
		v_u_22:Fire()
	end
end)
local function v_u_31(p28) -- name: thumbstickCurve
	local v29 = (math.abs(p28) - 0.1) / 0.9 * 2
	local v30 = (math.exp(v29) - 1) / 6.38905609893065
	return math.sign(p28) * math.clamp(v30, 0, 1)
end
local function v_u_36(p32) -- name: adjustTouchPitchSensitivity
	local v33 = workspace.CurrentCamera
	if not v33 then
		return p32
	end
	local v34 = v33.CFrame:ToEulerAnglesYXZ()
	if p32.Y * v34 >= 0 then
		return p32
	end
	local v35 = (1 - (math.abs(v34) * 2 / 3.141592653589793) ^ 0.75) * 0.75 + 0.25
	return Vector2.new(1, v35) * p32
end
local function v_u_43(p37) -- name: isInDynamicThumbstickArea
	-- upvalues: (copy) v_u_9
	local v38 = v_u_9:FindFirstChildOfClass("PlayerGui")
	if v38 then
		v38 = v38:FindFirstChild("TouchGui")
	end
	local v39
	if v38 then
		v39 = v38:FindFirstChild("TouchControlFrame")
	else
		v39 = v38
	end
	if v39 then
		v39 = v39:FindFirstChild("DynamicThumbstickFrame")
	end
	if not v39 then
		return false
	end
	if not v38.Enabled then
		return false
	end
	local v40 = v39.AbsolutePosition
	local v41 = v40 + v39.AbsoluteSize
	local v42
	if p37.X >= v40.X and (p37.Y >= v40.Y and p37.X <= v41.X) then
		v42 = p37.Y <= v41.Y
	else
		v42 = false
	end
	return v42
end
local v_u_44 = 0.016666666666666666
v4.Stepped:Connect(function(_, p45)
	-- upvalues: (ref) v_u_44
	v_u_44 = p45
end)
local v46 = {}
local v_u_47 = {}
local v_u_48 = 0
local v_u_49 = 1
local v_u_50 = 1
local v_u_51 = {
	["Thumbstick2"] = Vector2.new()
}
local v_u_52 = {
	["Left"] = 0,
	["Right"] = 0,
	["I"] = 0,
	["O"] = 0
}
local v_u_53 = {
	["Movement"] = nil,
	["Wheel"] = 0,
	["Pan"] = nil,
	["Pinch"] = 0,
	["Movement"] = Vector2.new(),
	["Pan"] = Vector2.new()
}
local v_u_54 = {
	["Move"] = nil,
	["Pinch"] = 0,
	["Move"] = Vector2.new()
}
local v_u_55 = Instance.new("BindableEvent")
v46.gamepadZoomPress = v_u_55.Event
local v_u_56 = v_u_6.VREnabled and Instance.new("BindableEvent") or nil
if v_u_6.VREnabled then
	v46.gamepadReset = v_u_56.Event
end
function v46.getRotationActivated() -- name: getRotationActivated
	-- upvalues: (ref) v_u_48, (copy) v_u_51
	return v_u_48 > 0 and true or v_u_51.Thumbstick2.Magnitude > 0
end
function v46.addTouchMove(p57) -- name: addTouchMove
	-- upvalues: (copy) v_u_54
	local v58 = v_u_54
	v58.Move = v58.Move + p57
end
function v46.setTouchSensitivity(p59) -- name: setTouchSensitivity
	-- upvalues: (ref) v_u_49
	v_u_49 = math.clamp(p59 or 1, 0.1, 10)
end
function v46.setGamepadAssistMultiplier(p60) -- name: setGamepadAssistMultiplier
	-- upvalues: (ref) v_u_50
	v_u_50 = math.clamp(p60 or 1, 0, 1)
end
function v46.getRotation(p61, p62) -- name: getRotation
	-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_52, (ref) v_u_44, (copy) v_u_51, (ref) v_u_50, (copy) v_u_53, (copy) v_u_36, (copy) v_u_54, (ref) v_u_11, (copy) v_u_12, (copy) v_u_13, (copy) v_u_14, (ref) v_u_49
	local v63 = Vector2.new(1, v_u_5:GetCameraYInvertValue())
	local v64
	if v_u_8 then
		v64 = Vector2.new(v_u_52.Right - v_u_52.Left, 0) * p61
	else
		v64 = Vector2.new(v_u_52.Right - v_u_52.Left, 0) * v_u_44
	end
	local v65 = v_u_51.Thumbstick2 * v_u_5.GamepadCameraSensitivity * v_u_50
	if v_u_8 then
		v65 = v65 * p61
	end
	local v66 = v_u_53.Movement
	local v67 = v_u_53.Pan
	local v68 = v_u_36(v_u_54.Move)
	if p62 then
		v64 = Vector2.new()
	end
	return (v64 * 2.0943951023931953 + v65 * v_u_11 + v66 * v_u_12 + v67 * v_u_13 + v68 * v_u_14 * v_u_49) * v63
end
function v46.getZoomDelta() -- name: getZoomDelta
	-- upvalues: (copy) v_u_52, (copy) v_u_53, (copy) v_u_54
	local v69 = v_u_52.O - v_u_52.I
	local v70 = -v_u_53.Wheel + v_u_53.Pinch
	local v71 = -v_u_54.Pinch
	return v69 * 0.1 + v70 * 1 + v71 * 0.04
end
local function v_u_74(_, _, p72) -- name: thumbstick
	-- upvalues: (copy) v_u_51, (ref) v_u_31
	local v73 = p72.Position
	v_u_51[p72.KeyCode.Name] = Vector2.new(v_u_31(v73.X), -v_u_31(v73.Y))
	return Enum.ContextActionResult.Pass
end
local function v_u_77(_, p75, p76) -- name: keypress
	-- upvalues: (copy) v_u_52
	v_u_52[p76.KeyCode.Name] = p75 == Enum.UserInputState.Begin and 1 or 0
end
local function v_u_79(_, p78, _) -- name: gamepadZoomPress
	-- upvalues: (copy) v_u_55
	if p78 == Enum.UserInputState.Begin then
		v_u_55:Fire()
	end
end
local function v_u_81(_, p80, _) -- name: gamepadReset
	-- upvalues: (copy) v_u_56
	if p80 == Enum.UserInputState.Begin then
		v_u_56:Fire()
	end
end
local function v_u_86() -- name: resetInputDevices
	-- upvalues: (copy) v_u_51, (copy) v_u_52, (copy) v_u_53, (copy) v_u_54, (ref) v_u_20, (ref) v_u_48
	local v82 = {
		v_u_51,
		v_u_52,
		v_u_53,
		v_u_54
	}
	for _, v83 in pairs(v82) do
		for v84, v85 in pairs(v83) do
			if type(v85) == "boolean" then
				v83[v84] = false
			else
				v83[v84] = v83[v84] * 0
			end
		end
	end
	if v_u_20 then
		v_u_48 = 0
	end
end
local v_u_87 = {}
local v_u_88 = nil
local v_u_89 = nil
local function v_u_95(p90, p91) -- name: touchBegan
	-- upvalues: (ref) v_u_88, (copy) v_u_43, (ref) v_u_48, (ref) v_u_87
	local v92 = p90.UserInputType == Enum.UserInputType.Touch
	assert(v92)
	local v93 = p90.UserInputState == Enum.UserInputState.Begin
	assert(v93)
	if v_u_88 == nil and (v_u_43(p90.Position) and not p91) then
		v_u_88 = p90
	else
		if not p91 then
			local v94 = v_u_48 + 1
			v_u_48 = math.max(0, v94)
		end
		v_u_87[p90] = p91
	end
end
local function v_u_100(p96, _) -- name: touchEnded
	-- upvalues: (ref) v_u_88, (ref) v_u_87, (ref) v_u_89, (ref) v_u_48
	local v97 = p96.UserInputType == Enum.UserInputType.Touch
	assert(v97)
	local v98 = p96.UserInputState == Enum.UserInputState.End
	assert(v98)
	if p96 == v_u_88 then
		v_u_88 = nil
	end
	if v_u_87[p96] == false then
		v_u_89 = nil
		local v99 = v_u_48 - 1
		v_u_48 = math.max(0, v99)
	end
	v_u_87[p96] = nil
end
local function v_u_112(p101, p102) -- name: touchChanged
	-- upvalues: (ref) v_u_88, (ref) v_u_87, (copy) v_u_54, (ref) v_u_89
	local v103 = p101.UserInputType == Enum.UserInputType.Touch
	assert(v103)
	local v104 = p101.UserInputState == Enum.UserInputState.Change
	assert(v104)
	if p101 == v_u_88 then
		return
	else
		if v_u_87[p101] == nil then
			v_u_87[p101] = p102
		end
		local v105 = {}
		for v106, v107 in pairs(v_u_87) do
			if v107 then
				continue
			end
			table.insert(v105, v106)
		end
		if #v105 == 1 and v_u_87[p101] == false then
			local v108 = p101.Delta
			local v109 = v_u_54
			v109.Move = v109.Move + Vector2.new(v108.X, v108.Y)
		end
		if #v105 == 2 then
			local v110 = (v105[1].Position - v105[2].Position).Magnitude
			if v_u_89 then
				local v111 = v_u_54
				v111.Pinch = v111.Pinch + (v110 - v_u_89)
			end
			v_u_89 = v110
		else
			v_u_89 = nil
		end
	end
end
local function v_u_113() -- name: resetTouchState
	-- upvalues: (ref) v_u_87, (ref) v_u_88, (ref) v_u_89, (ref) v_u_17, (ref) v_u_48
	v_u_87 = {}
	v_u_88 = nil
	v_u_89 = nil
	if v_u_17 then
		v_u_48 = 0
	end
end
local function v_u_118(p114, p115, p116, p117) -- name: pointerAction
	-- upvalues: (copy) v_u_53
	if not p117 then
		v_u_53.Wheel = p114
		v_u_53.Pan = p115
		v_u_53.Pinch = -p116
	end
end
local function v_u_122(p119, p120) -- name: inputBegan
	-- upvalues: (ref) v_u_95, (ref) v_u_48
	if p119.UserInputType == Enum.UserInputType.Touch then
		v_u_95(p119, p120)
	elseif p119.UserInputType == Enum.UserInputType.MouseButton2 and not p120 then
		local v121 = v_u_48 + 1
		v_u_48 = math.max(0, v121)
	end
end
local function v_u_126(p123, p124) -- name: inputChanged
	-- upvalues: (ref) v_u_112, (copy) v_u_53
	if p123.UserInputType == Enum.UserInputType.Touch then
		v_u_112(p123, p124)
	elseif p123.UserInputType == Enum.UserInputType.MouseMovement then
		local v125 = p123.Delta
		v_u_53.Movement = Vector2.new(v125.X, v125.Y)
	end
end
local function v_u_130(p127, p128) -- name: inputEnded
	-- upvalues: (ref) v_u_100, (ref) v_u_48
	if p127.UserInputType == Enum.UserInputType.Touch then
		v_u_100(p127, p128)
	elseif p127.UserInputType == Enum.UserInputType.MouseButton2 then
		local v129 = v_u_48 - 1
		v_u_48 = math.max(0, v129)
	end
end
local v_u_131 = false
function v46.setInputEnabled(p132) -- name: setInputEnabled
	-- upvalues: (ref) v_u_131, (copy) v_u_86, (ref) v_u_113, (copy) v_u_1, (copy) v_u_74, (copy) v_u_10, (copy) v_u_77, (copy) v_u_6, (copy) v_u_81, (copy) v_u_79, (ref) v_u_47, (copy) v_u_2, (copy) v_u_122, (copy) v_u_126, (copy) v_u_130, (copy) v_u_118, (ref) v_u_17
	if v_u_131 ~= p132 then
		v_u_131 = p132
		v_u_86()
		v_u_113()
		if v_u_131 then
			v_u_1:BindActionAtPriority("RbxCameraThumbstick", v_u_74, false, v_u_10, Enum.KeyCode.Thumbstick2)
			v_u_1:BindActionAtPriority("RbxCameraKeypress", v_u_77, false, v_u_10, Enum.KeyCode.I)
			if v_u_6.VREnabled then
				v_u_1:BindAction("RbxCameraGamepadReset", v_u_81, false, Enum.KeyCode.ButtonL3)
			end
			v_u_1:BindAction("RbxCameraGamepadZoom", v_u_79, false, Enum.KeyCode.ButtonR3)
			local v133 = v_u_47
			local v134 = v_u_2.InputBegan
			local v135 = v_u_122
			table.insert(v133, v134:Connect(v135))
			local v136 = v_u_47
			local v137 = v_u_2.InputChanged
			local v138 = v_u_126
			table.insert(v136, v137:Connect(v138))
			local v139 = v_u_47
			local v140 = v_u_2.InputEnded
			local v141 = v_u_130
			table.insert(v139, v140:Connect(v141))
			local v142 = v_u_47
			local v143 = v_u_2.PointerAction
			local v144 = v_u_118
			table.insert(v142, v143:Connect(v144))
			if v_u_17 then
				local v145 = v_u_47
				local v146 = game:GetService("GuiService").MenuOpened
				local v147 = v_u_113
				table.insert(v145, v146:connect(v147))
				return
			end
		else
			v_u_1:UnbindAction("RbxCameraThumbstick")
			v_u_1:UnbindAction("RbxCameraMouseMove")
			v_u_1:UnbindAction("RbxCameraMouseWheel")
			v_u_1:UnbindAction("RbxCameraKeypress")
			v_u_1:UnbindAction("RbxCameraGamepadZoom")
			if v_u_6.VREnabled then
				v_u_1:UnbindAction("RbxCameraGamepadReset")
			end
			for _, v148 in pairs(v_u_47) do
				v148:Disconnect()
			end
			v_u_47 = {}
		end
	end
end
function v46.getInputEnabled() -- name: getInputEnabled
	-- upvalues: (ref) v_u_131
	return v_u_131
end
function v46.resetInputForFrameEnd() -- name: resetInputForFrameEnd
	-- upvalues: (copy) v_u_53, (copy) v_u_54
	v_u_53.Movement = Vector2.new()
	v_u_54.Move = Vector2.new()
	v_u_54.Pinch = 0
	v_u_53.Wheel = 0
	v_u_53.Pan = Vector2.new()
	v_u_53.Pinch = 0
end
v_u_2.WindowFocused:Connect(v_u_86)
v_u_2.WindowFocusReleased:Connect(v_u_86)
local v_u_149 = false
local v_u_150 = false
local v_u_151 = 0
function v46.getHoldPan() -- name: getHoldPan
	-- upvalues: (ref) v_u_149
	return v_u_149
end
function v46.getTogglePan() -- name: getTogglePan
	-- upvalues: (ref) v_u_150
	return v_u_150
end
function v46.getPanning() -- name: getPanning
	-- upvalues: (ref) v_u_150, (ref) v_u_149
	return v_u_150 or v_u_149
end
function v46.setTogglePan(p152) -- name: setTogglePan
	-- upvalues: (ref) v_u_150
	v_u_150 = p152
end
local v_u_153 = false
local v_u_154 = nil
local v_u_155 = nil
function v46.enableCameraToggleInput() -- name: enableCameraToggleInput
	-- upvalues: (ref) v_u_153, (ref) v_u_149, (ref) v_u_150, (ref) v_u_154, (ref) v_u_155, (ref) v_u_23, (ref) v_u_151, (ref) v_u_24, (copy) v_u_2
	if not v_u_153 then
		v_u_153 = true
		v_u_149 = false
		v_u_150 = false
		if v_u_154 then
			v_u_154:Disconnect()
		end
		if v_u_155 then
			v_u_155:Disconnect()
		end
		v_u_154 = v_u_23:Connect(function()
			-- upvalues: (ref) v_u_149, (ref) v_u_151
			v_u_149 = true
			v_u_151 = tick()
		end)
		v_u_155 = v_u_24:Connect(function()
			-- upvalues: (ref) v_u_149, (ref) v_u_151, (ref) v_u_150, (ref) v_u_2
			v_u_149 = false
			if tick() - v_u_151 < 0.3 and (v_u_150 or v_u_2:GetMouseDelta().Magnitude < 2) then
				v_u_150 = not v_u_150
			end
		end)
	end
end
function v46.disableCameraToggleInput() -- name: disableCameraToggleInput
	-- upvalues: (ref) v_u_153, (ref) v_u_154, (ref) v_u_155
	if v_u_153 then
		v_u_153 = false
		if v_u_154 then
			v_u_154:Disconnect()
			v_u_154 = nil
		end
		if v_u_155 then
			v_u_155:Disconnect()
			v_u_155 = nil
		end
	end
end
return v46
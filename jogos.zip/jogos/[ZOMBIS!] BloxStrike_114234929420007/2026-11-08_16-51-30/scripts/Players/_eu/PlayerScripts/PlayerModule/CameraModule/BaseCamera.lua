-- NIGHT Analyzer | Players.jejekwwkwiwi.PlayerScripts.PlayerModule.CameraModule.BaseCamera
-- ModuleScript | 617 linhas | 19674 bytes | hash c4bdb919

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("VRService")
local v_u_4 = UserSettings():GetService("UserGameSettings")
local v5 = script.Parent.Parent:WaitForChild("CommonUtils")
local v_u_6 = require(v5:WaitForChild("ConnectionUtil"))
local v7 = require(v5:WaitForChild("FlagUtil"))
local v_u_8 = require(script.Parent:WaitForChild("CameraUtils"))
local v_u_9 = require(script.Parent:WaitForChild("ZoomController"))
local v_u_10 = require(script.Parent:WaitForChild("CameraToggleStateController"))
local v_u_11 = require(script.Parent:WaitForChild("CameraInput"))
local v_u_12 = require(script.Parent:WaitForChild("CameraUI"))
local v_u_13 = v1.LocalPlayer
local v14, v15 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserFixGamepadMaxZoom")
end)
local v_u_16 = v14 and v15
local v_u_17 = v7.getUserFlag("UserFixCameraCameraCharacterUpdates")
Vector2.new(0, 0)
local v_u_18 = {}
v_u_18.__index = v_u_18
function v_u_18.new() -- name: new
	-- upvalues: (copy) v_u_18, (copy) v_u_6, (copy) v_u_13, (copy) v_u_17, (copy) v_u_4
	local v19 = v_u_18
	local v20 = setmetatable({}, v19)
	v20._connections = v_u_6.new()
	v20.gamepadZoomLevels = { 0, 10, 20 }
	v20.FIRST_PERSON_DISTANCE_THRESHOLD = 1
	v20.cameraType = nil
	v20.cameraMovementMode = nil
	v20.lastCameraTransform = nil
	v20.lastUserPanCamera = tick()
	v20.humanoidRootPart = nil
	v20.humanoidCache = {}
	v20.lastSubject = nil
	v20.lastSubjectPosition = Vector3.new(0, 5, 0)
	v20.lastSubjectCFrame = CFrame.new(v20.lastSubjectPosition)
	local v21 = v_u_13.CameraMinZoomDistance
	local v22 = v_u_13.CameraMaxZoomDistance
	v20.currentSubjectDistance = math.clamp(12.5, v21, v22)
	v20.inFirstPerson = false
	v20.inMouseLockedMode = false
	v20.portraitMode = false
	v20.isSmallTouchScreen = false
	v20.resetCameraAngle = true
	v20.enabled = false
	if not v_u_17 then
		v20.PlayerGui = nil
	end
	v20.cameraChangedConn = nil
	v20.viewportSizeChangedConn = nil
	v20.shouldUseVRRotation = false
	v20.VRRotationIntensityAvailable = false
	v20.lastVRRotationIntensityCheckTime = 0
	v20.lastVRRotationTime = 0
	v20.vrRotateKeyCooldown = {}
	v20.cameraTranslationConstraints = Vector3.new(1, 1, 1)
	v20.humanoidJumpOrigin = nil
	v20.trackingHumanoid = nil
	v20.cameraFrozen = false
	v20.subjectStateChangedConn = nil
	v20.gamepadZoomPressConnection = nil
	v20.mouseLockOffset = Vector3.new(0, 0, 0)
	v_u_4:SetCameraYInvertVisible()
	v_u_4:SetGamepadCameraSensitivityVisible()
	return v20
end
function v_u_18.GetModuleName(_) -- name: GetModuleName
	return "BaseCamera"
end
function v_u_18._setUpConfigurations(p_u_23) -- name: _setUpConfigurations
	-- upvalues: (copy) v_u_13, (copy) v_u_17
	p_u_23._connections:trackConnection("CHARACTER_ADDED", v_u_13.CharacterAdded:Connect(function(p24)
		-- upvalues: (copy) p_u_23
		p_u_23:OnCharacterAdded(p24)
	end))
	if v_u_17 then
		p_u_23.humanoidRootPart = nil
	elseif v_u_13.Character then
		p_u_23:OnCharacterAdded(v_u_13.Character)
	end
	p_u_23._connections:trackConnection("CAMERA_MODE_CHANGED", v_u_13:GetPropertyChangedSignal("CameraMode"):Connect(function()
		-- upvalues: (copy) p_u_23
		p_u_23:OnPlayerCameraPropertyChange()
	end))
	p_u_23._connections:trackConnection("CAMERA_MIN_DISTANCE_CHANGED", v_u_13:GetPropertyChangedSignal("CameraMinZoomDistance"):Connect(function()
		-- upvalues: (copy) p_u_23
		p_u_23:OnPlayerCameraPropertyChange()
	end))
	p_u_23._connections:trackConnection("CAMERA_MAX_DISTANCE_CHANGED", v_u_13:GetPropertyChangedSignal("CameraMaxZoomDistance"):Connect(function()
		-- upvalues: (copy) p_u_23
		p_u_23:OnPlayerCameraPropertyChange()
	end))
	p_u_23:OnPlayerCameraPropertyChange()
end
function v_u_18.OnCharacterAdded(p_u_25, p26) -- name: OnCharacterAdded
	-- upvalues: (copy) v_u_17, (copy) v_u_2, (copy) v_u_13
	p_u_25.resetCameraAngle = p_u_25.resetCameraAngle or p_u_25:GetEnabled()
	p_u_25.humanoidRootPart = nil
	if not v_u_17 and v_u_2.TouchEnabled then
		p_u_25.PlayerGui = v_u_13:WaitForChild("PlayerGui")
		for _, v27 in ipairs(p26:GetChildren()) do
			if not v27:IsA("Tool") then
				continue
			end
			p_u_25.isAToolEquipped = true
		end
		p_u_25._connections:trackConnection("char.ChildAdded", p26.ChildAdded:Connect(function(p28)
			-- upvalues: (copy) p_u_25
			if p28:IsA("Tool") then
				p_u_25.isAToolEquipped = true
			end
		end))
		p_u_25._connections:trackConnection("char.ChildRemoved", p26.ChildRemoved:Connect(function(p29)
			-- upvalues: (copy) p_u_25
			if p29:IsA("Tool") then
				p_u_25.isAToolEquipped = false
			end
		end))
	end
end
function v_u_18.GetHumanoidRootPart(p30) -- name: GetHumanoidRootPart
	-- upvalues: (copy) v_u_13
	local v31 = (not p30.humanoidRootPart and v_u_13.Character and true or false) and v_u_13.Character:FindFirstChildOfClass("Humanoid")
	if v31 then
		p30.humanoidRootPart = v31.RootPart
	end
	return p30.humanoidRootPart
end
function v_u_18.GetBodyPartToFollow(_, p32, _) -- name: GetBodyPartToFollow
	if p32:GetState() == Enum.HumanoidStateType.Dead then
		local v33 = p32.Parent
		if v33 and v33:IsA("Model") then
			return v33:FindFirstChild("Head") or p32.RootPart
		end
	end
	return p32.RootPart
end
function v_u_18.GetSubjectCFrame(p34) -- name: GetSubjectCFrame
	local v35 = p34.lastSubjectCFrame
	local v36 = workspace.CurrentCamera
	if v36 then
		v36 = v36.CameraSubject
	end
	if not v36 then
		return v35
	end
	if v36:IsA("Humanoid") then
		local v37 = v36:GetState() == Enum.HumanoidStateType.Dead
		local v38 = v36.CameraOffset
		if p34:GetIsMouseLocked() then
			v38 = Vector3.new()
		end
		local v39 = v36.RootPart
		if v37 and (v36.Parent and v36.Parent:IsA("Model")) then
			v39 = v36.Parent:FindFirstChild("Head") or v39
		end
		if v39 and v39:IsA("BasePart") then
			local v40
			if v36.RigType == Enum.HumanoidRigType.R15 then
				if v36.AutomaticScalingEnabled then
					v40 = Vector3.new(0, 1.5, 0)
					local v41 = v36.RootPart
					if v39 == v41 then
						local v42 = (v41.Size.Y - 2) / 2
						v40 = v40 + Vector3.new(0, v42, 0)
					end
				else
					v40 = Vector3.new(0, 2, 0)
				end
			else
				v40 = Vector3.new(0, 1.5, 0)
			end
			v35 = v39.CFrame * CFrame.new((v37 and Vector3.new(0, 0, 0) or v40) + v38)
		end
	elseif v36:IsA("BasePart") then
		v35 = v36.CFrame
	elseif v36:IsA("Model") then
		if v36.PrimaryPart then
			v35 = v36:GetPrimaryPartCFrame()
		else
			v35 = CFrame.new()
		end
	end
	if v35 then
		p34.lastSubjectCFrame = v35
	end
	return v35
end
function v_u_18.GetSubjectVelocity(_) -- name: GetSubjectVelocity
	local v43 = workspace.CurrentCamera
	if v43 then
		v43 = v43.CameraSubject
	end
	if not v43 then
		return Vector3.new(0, 0, 0)
	end
	if v43:IsA("BasePart") then
		return v43.Velocity
	end
	if v43:IsA("Humanoid") then
		local v44 = v43.RootPart
		if v44 then
			return v44.Velocity
		end
	else
		local v45 = v43:IsA("Model") and v43.PrimaryPart
		if v45 then
			return v45.Velocity
		end
	end
	return Vector3.new(0, 0, 0)
end
function v_u_18.GetSubjectRotVelocity(_) -- name: GetSubjectRotVelocity
	local v46 = workspace.CurrentCamera
	if v46 then
		v46 = v46.CameraSubject
	end
	if not v46 then
		return Vector3.new(0, 0, 0)
	end
	if v46:IsA("BasePart") then
		return v46.RotVelocity
	end
	if v46:IsA("Humanoid") then
		local v47 = v46.RootPart
		if v47 then
			return v47.RotVelocity
		end
	else
		local v48 = v46:IsA("Model") and v46.PrimaryPart
		if v48 then
			return v48.RotVelocity
		end
	end
	return Vector3.new(0, 0, 0)
end
function v_u_18.StepZoom(p49) -- name: StepZoom
	-- upvalues: (copy) v_u_11, (copy) v_u_9
	local v50 = p49.currentSubjectDistance
	local v51 = v_u_11.getZoomDelta()
	if math.abs(v51) > 0 then
		local v52
		if v51 > 0 then
			local v53 = v50 + v51 * (v50 * 0.5 + 1)
			local v54 = p49.FIRST_PERSON_DISTANCE_THRESHOLD
			v52 = math.max(v53, v54)
		else
			local v55 = (v50 + v51) / (1 - v51 * 0.5)
			v52 = math.max(v55, 0)
		end
		p49:SetCameraToSubjectDistance(v52 < p49.FIRST_PERSON_DISTANCE_THRESHOLD and 0 or v52)
	end
	return v_u_9.GetZoomRadius()
end
function v_u_18.GetSubjectPosition(p56) -- name: GetSubjectPosition
	local v57 = p56.lastSubjectPosition
	local v58 = workspace.CurrentCamera
	if v58 then
		v58 = v58.CameraSubject
	end
	if not v58 then
		return nil
	end
	if v58:IsA("Humanoid") then
		local v59 = v58:GetState() == Enum.HumanoidStateType.Dead
		local v60 = v58.CameraOffset
		if p56:GetIsMouseLocked() then
			v60 = Vector3.new()
		end
		local v61 = v58.RootPart
		if v59 and (v58.Parent and v58.Parent:IsA("Model")) then
			v61 = v58.Parent:FindFirstChild("Head") or v61
		end
		if v61 and v61:IsA("BasePart") then
			local v62
			if v58.RigType == Enum.HumanoidRigType.R15 then
				if v58.AutomaticScalingEnabled then
					v62 = Vector3.new(0, 1.5, 0)
					if v61 == v58.RootPart then
						local v63 = v58.RootPart.Size.Y / 2 - 1
						v62 = v62 + Vector3.new(0, v63, 0)
					end
				else
					v62 = Vector3.new(0, 2, 0)
				end
			else
				v62 = Vector3.new(0, 1.5, 0)
			end
			v57 = v61.CFrame.p + v61.CFrame:vectorToWorldSpace((v59 and Vector3.new(0, 0, 0) or v62) + v60)
		end
	elseif v58:IsA("VehicleSeat") then
		v57 = v58.CFrame.p + v58.CFrame:vectorToWorldSpace(Vector3.new(0, 5, 0))
	elseif v58:IsA("SkateboardPlatform") then
		v57 = v58.CFrame.p + Vector3.new(0, 5, 0)
	elseif v58:IsA("BasePart") then
		v57 = v58.CFrame.p
	elseif v58:IsA("Model") then
		if v58.PrimaryPart then
			v57 = v58:GetPrimaryPartCFrame().p
		else
			v57 = v58:GetModelCFrame().p
		end
	end
	p56.lastSubject = v58
	p56.lastSubjectPosition = v57
	return v57
end
function v_u_18.OnViewportSizeChanged(p64) -- name: OnViewportSizeChanged
	-- upvalues: (copy) v_u_2
	local v65 = workspace.CurrentCamera.ViewportSize
	p64.portraitMode = v65.X < v65.Y
	local v66 = v_u_2.TouchEnabled
	if v66 then
		v66 = v65.Y < 500 and true or v65.X < 700
	end
	p64.isSmallTouchScreen = v66
end
function v_u_18.OnCurrentCameraChanged(p_u_67) -- name: OnCurrentCameraChanged
	-- upvalues: (copy) v_u_2
	if v_u_2.TouchEnabled then
		if p_u_67.viewportSizeChangedConn then
			p_u_67.viewportSizeChangedConn:Disconnect()
			p_u_67.viewportSizeChangedConn = nil
		end
		local v68 = workspace.CurrentCamera
		if v68 then
			p_u_67:OnViewportSizeChanged()
			p_u_67.viewportSizeChangedConn = v68:GetPropertyChangedSignal("ViewportSize"):Connect(function()
				-- upvalues: (copy) p_u_67
				p_u_67:OnViewportSizeChanged()
			end)
		end
	end
	if p_u_67.cameraSubjectChangedConn then
		p_u_67.cameraSubjectChangedConn:Disconnect()
		p_u_67.cameraSubjectChangedConn = nil
	end
	local v69 = workspace.CurrentCamera
	if v69 then
		p_u_67.cameraSubjectChangedConn = v69:GetPropertyChangedSignal("CameraSubject"):Connect(function()
			-- upvalues: (copy) p_u_67
			p_u_67:OnNewCameraSubject()
		end)
		p_u_67:OnNewCameraSubject()
	end
end
function v_u_18.OnPlayerCameraPropertyChange(p70) -- name: OnPlayerCameraPropertyChange
	p70:SetCameraToSubjectDistance(p70.currentSubjectDistance)
end
function v_u_18.InputTranslationToCameraAngleChange(_, p71, p72) -- name: InputTranslationToCameraAngleChange
	return p71 * p72
end
function v_u_18.GamepadZoomPress(p73) -- name: GamepadZoomPress
	-- upvalues: (copy) v_u_13, (ref) v_u_16
	local v74 = p73:GetCameraToSubjectDistance()
	local v75 = v_u_13.CameraMaxZoomDistance
	for v76 = #p73.gamepadZoomLevels, 1, -1 do
		local v77 = p73.gamepadZoomLevels[v76]
		if v75 < v77 then
			continue
		end
		if v77 < v_u_13.CameraMinZoomDistance then
			v77 = v_u_13.CameraMinZoomDistance
			if v_u_16 and v75 == v77 then
				break
			end
		end
		if not v_u_16 and v75 == v77 then
			break
		end
		if v77 + (v75 - v77) / 2 < v74 then
			p73:SetCameraToSubjectDistance(v77)
			return
		end
		v75 = v77
	end
	p73:SetCameraToSubjectDistance(p73.gamepadZoomLevels[#p73.gamepadZoomLevels])
end
function v_u_18.Enable(p78, p79) -- name: Enable
	if p78.enabled ~= p79 then
		p78.enabled = p79
		p78:OnEnabledChanged()
	end
end
function v_u_18.OnEnabledChanged(p_u_80) -- name: OnEnabledChanged
	-- upvalues: (copy) v_u_11, (copy) v_u_13
	if p_u_80.enabled then
		p_u_80:_setUpConfigurations()
		v_u_11.setInputEnabled(true)
		p_u_80.gamepadZoomPressConnection = v_u_11.gamepadZoomPress:Connect(function()
			-- upvalues: (copy) p_u_80
			p_u_80:GamepadZoomPress()
		end)
		if v_u_13.CameraMode == Enum.CameraMode.LockFirstPerson then
			p_u_80.currentSubjectDistance = 0
			if not p_u_80.inFirstPerson then
				p_u_80:EnterFirstPerson()
			end
		end
		if p_u_80.cameraChangedConn then
			p_u_80.cameraChangedConn:Disconnect()
			p_u_80.cameraChangedConn = nil
		end
		p_u_80.cameraChangedConn = workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
			-- upvalues: (copy) p_u_80
			p_u_80:OnCurrentCameraChanged()
		end)
		p_u_80:OnCurrentCameraChanged()
	else
		p_u_80._connections:disconnectAll()
		v_u_11.setInputEnabled(false)
		if p_u_80.gamepadZoomPressConnection then
			p_u_80.gamepadZoomPressConnection:Disconnect()
			p_u_80.gamepadZoomPressConnection = nil
		end
		p_u_80:Cleanup()
	end
end
function v_u_18.GetEnabled(p81) -- name: GetEnabled
	return p81.enabled
end
function v_u_18.Cleanup(p82) -- name: Cleanup
	-- upvalues: (copy) v_u_8
	if p82.subjectStateChangedConn then
		p82.subjectStateChangedConn:Disconnect()
		p82.subjectStateChangedConn = nil
	end
	if p82.viewportSizeChangedConn then
		p82.viewportSizeChangedConn:Disconnect()
		p82.viewportSizeChangedConn = nil
	end
	if p82.cameraChangedConn then
		p82.cameraChangedConn:Disconnect()
		p82.cameraChangedConn = nil
	end
	p82.lastCameraTransform = nil
	p82.lastSubjectCFrame = nil
	v_u_8.restoreMouseBehavior()
end
function v_u_18.UpdateMouseBehavior(p83) -- name: UpdateMouseBehavior
	-- upvalues: (copy) v_u_4, (copy) v_u_12, (copy) v_u_11, (copy) v_u_10, (copy) v_u_8
	local v84 = v_u_4.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove
	if p83.isCameraToggle and v84 == false then
		v_u_12.setCameraModeToastEnabled(true)
		v_u_11.enableCameraToggleInput()
		v_u_10(p83.inFirstPerson)
		return
	else
		v_u_12.setCameraModeToastEnabled(false)
		v_u_11.disableCameraToggleInput()
		if p83.inFirstPerson or p83.inMouseLockedMode then
			v_u_8.setRotationTypeOverride(Enum.RotationType.CameraRelative)
			v_u_8.setMouseBehaviorOverride(Enum.MouseBehavior.LockCenter)
			return
		else
			v_u_8.restoreRotationType()
			if v_u_11.getRotationActivated() then
				v_u_8.setMouseBehaviorOverride(Enum.MouseBehavior.LockCurrentPosition)
			else
				v_u_8.restoreMouseBehavior()
			end
		end
	end
end
function v_u_18.UpdateForDistancePropertyChange(p85) -- name: UpdateForDistancePropertyChange
	p85:SetCameraToSubjectDistance(p85.currentSubjectDistance)
end
function v_u_18.SetCameraToSubjectDistance(p86, p87) -- name: SetCameraToSubjectDistance
	-- upvalues: (copy) v_u_13, (copy) v_u_9
	local v88 = p86.currentSubjectDistance
	if v_u_13.CameraMode == Enum.CameraMode.LockFirstPerson then
		p86.currentSubjectDistance = 0
		if not p86.inFirstPerson then
			p86:EnterFirstPerson()
		end
	else
		local v89 = v_u_13.CameraMinZoomDistance
		local v90 = v_u_13.CameraMaxZoomDistance
		local v91 = math.clamp(p87, v89, v90)
		if v91 < 1 then
			p86.currentSubjectDistance = 0
			if not p86.inFirstPerson then
				p86:EnterFirstPerson()
			end
		else
			p86.currentSubjectDistance = v91
			if p86.inFirstPerson then
				p86:LeaveFirstPerson()
			end
		end
	end
	local v92 = v_u_9.SetZoomParameters
	local v93 = p86.currentSubjectDistance
	local v94 = p87 - v88
	v92(v93, (math.sign(v94)))
	return p86.currentSubjectDistance
end
function v_u_18.SetCameraType(p95, p96) -- name: SetCameraType
	p95.cameraType = p96
end
function v_u_18.GetCameraType(p97) -- name: GetCameraType
	return p97.cameraType
end
function v_u_18.SetCameraMovementMode(p98, p99) -- name: SetCameraMovementMode
	p98.cameraMovementMode = p99
end
function v_u_18.GetCameraMovementMode(p100) -- name: GetCameraMovementMode
	return p100.cameraMovementMode
end
function v_u_18.SetIsMouseLocked(p101, p102) -- name: SetIsMouseLocked
	p101.inMouseLockedMode = p102
end
function v_u_18.GetIsMouseLocked(p103) -- name: GetIsMouseLocked
	return p103.inMouseLockedMode
end
function v_u_18.SetMouseLockOffset(p104, p105) -- name: SetMouseLockOffset
	p104.mouseLockOffset = p105
end
function v_u_18.GetMouseLockOffset(p106) -- name: GetMouseLockOffset
	return p106.mouseLockOffset
end
function v_u_18.InFirstPerson(p107) -- name: InFirstPerson
	return p107.inFirstPerson
end
function v_u_18.EnterFirstPerson(p108) -- name: EnterFirstPerson
	p108.inFirstPerson = true
	p108:UpdateMouseBehavior()
end
function v_u_18.LeaveFirstPerson(p109) -- name: LeaveFirstPerson
	p109.inFirstPerson = false
	p109:UpdateMouseBehavior()
end
function v_u_18.GetCameraToSubjectDistance(p110) -- name: GetCameraToSubjectDistance
	return p110.currentSubjectDistance
end
function v_u_18.GetMeasuredDistanceToFocus(_) -- name: GetMeasuredDistanceToFocus
	local v111 = workspace.CurrentCamera
	if v111 then
		return (v111.CoordinateFrame.p - v111.Focus.p).magnitude
	else
		return nil
	end
end
function v_u_18.GetCameraLookVector(_) -- name: GetCameraLookVector
	return workspace.CurrentCamera and workspace.CurrentCamera.CFrame.LookVector or Vector3.new(0, 0, 1)
end
function v_u_18.CalculateNewLookCFrameFromArg(p112, p113, p114) -- name: CalculateNewLookCFrameFromArg
	local v115 = p113 or p112:GetCameraLookVector()
	local v116 = v115.Y
	local v117 = math.asin(v116)
	local v118 = p114.Y
	local v119 = v117 + -1.3962634015954636
	local v120 = v117 + 1.3962634015954636
	local v121 = math.clamp(v118, v119, v120)
	local v122 = Vector2.new(p114.X, v121)
	local v123 = CFrame.new(Vector3.new(0, 0, 0), v115)
	return CFrame.Angles(0, -v122.X, 0) * v123 * CFrame.Angles(-v122.Y, 0, 0)
end
function v_u_18.CalculateNewLookVectorFromArg(p124, p125, p126) -- name: CalculateNewLookVectorFromArg
	return p124:CalculateNewLookCFrameFromArg(p125, p126).LookVector
end
function v_u_18.CalculateNewLookVectorVRFromArg(p127, p128) -- name: CalculateNewLookVectorVRFromArg
	local v129 = ((p127:GetSubjectPosition() - workspace.CurrentCamera.CFrame.p) * Vector3.new(1, 0, 1)).unit
	local v130 = Vector2.new(p128.X, 0)
	local v131 = CFrame.new(Vector3.new(0, 0, 0), v129)
	return ((CFrame.Angles(0, -v130.X, 0) * v131 * CFrame.Angles(-v130.Y, 0, 0)).LookVector * Vector3.new(1, 0, 1)).unit
end
function v_u_18.GetHumanoid(p132) -- name: GetHumanoid
	-- upvalues: (copy) v_u_13
	local v133 = v_u_13
	if v133 then
		v133 = v_u_13.Character
	end
	if not v133 then
		return nil
	end
	local v134 = p132.humanoidCache[v_u_13]
	if v134 and v134.Parent == v133 then
		return v134
	end
	p132.humanoidCache[v_u_13] = nil
	local v135 = v133:FindFirstChildOfClass("Humanoid")
	if v135 then
		p132.humanoidCache[v_u_13] = v135
	end
	return v135
end
function v_u_18.GetHumanoidPartToFollow(_, p136, p137) -- name: GetHumanoidPartToFollow
	if p137 == Enum.HumanoidStateType.Dead then
		local v138 = p136.Parent
		if v138 then
			return v138:FindFirstChild("Head") or p136.Torso
		else
			return p136.Torso
		end
	else
		return p136.Torso
	end
end
function v_u_18.OnNewCameraSubject(p139) -- name: OnNewCameraSubject
	if p139.subjectStateChangedConn then
		p139.subjectStateChangedConn:Disconnect()
		p139.subjectStateChangedConn = nil
	end
end
function v_u_18.IsInFirstPerson(p140) -- name: IsInFirstPerson
	return p140.inFirstPerson
end
function v_u_18.Update(_, _) -- name: Update
	error("BaseCamera:Update() This is a virtual function that should never be getting called.", 2)
end
function v_u_18.GetCameraHeight(p141) -- name: GetCameraHeight
	-- upvalues: (copy) v_u_3
	return (not v_u_3.VREnabled or p141.inFirstPerson) and 0 or 0.25881904510252074 * p141.currentSubjectDistance
end
return v_u_18
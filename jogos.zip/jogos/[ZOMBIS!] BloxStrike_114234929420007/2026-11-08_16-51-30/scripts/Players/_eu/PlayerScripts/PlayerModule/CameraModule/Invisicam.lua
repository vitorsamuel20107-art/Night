-- NIGHT Analyzer | Players.jejekwwkwiwi.PlayerScripts.PlayerModule.CameraModule.Invisicam
-- ModuleScript | 494 linhas | 15394 bytes | hash bf23529b

local v_u_1 = game:GetService("Players")
local v2 = script.Parent.Parent:WaitForChild("CommonUtils")
local v_u_3 = require(v2:WaitForChild("FlagUtil")).getUserFlag("UserRaycastUpdateAPI")
local v_u_4 = {
	["LIMBS"] = 2,
	["MOVEMENT"] = 3,
	["CORNERS"] = 4,
	["CIRCLE1"] = 5,
	["CIRCLE2"] = 6,
	["LIMBMOVE"] = 7,
	["SMART_CIRCLE"] = 8,
	["CHAR_OUTLINE"] = 9
}
local v_u_5 = {
	["Head"] = true,
	["Left Arm"] = true,
	["Right Arm"] = true,
	["Left Leg"] = true,
	["Right Leg"] = true,
	["LeftLowerArm"] = true,
	["RightLowerArm"] = true,
	["LeftUpperLeg"] = true,
	["RightUpperLeg"] = true
}
local v_u_6 = {
	Vector3.new(1, 1, -1),
	Vector3.new(1, -1, -1),
	Vector3.new(-1, -1, -1),
	Vector3.new(-1, 1, -1)
}
local v_u_7 = RaycastParams.new()
v_u_7.FilterType = Enum.RaycastFilterType.Exclude
local v_u_8 = RaycastParams.new()
v_u_8.FilterType = Enum.RaycastFilterType.Include
local function v_u_16(p9, ...) -- name: AssertTypes
	local v10 = {}
	local v11 = ""
	for _, v12 in pairs({ ... }) do
		v10[v12] = true
		v11 = v11 .. (v11 == "" and "" or " or ") .. v12
	end
	local v13 = type(p9)
	local v14 = v10[v13]
	local v15 = v11 .. " type expected, got: " .. v13
	assert(v14, v15)
end
local function v_u_52(p17, p18, p19, p20) -- name: RayIntersection
	local v21 = p18:Cross(p20)
	local v22 = p19.X - p17.X
	local v23 = p19.Y - p17.Y
	local v24 = p19.Z - p17.Z
	local v25 = p18.X
	local v26 = -p20.X
	local v27 = v21.X
	local v28 = p18.Y
	local v29 = -p20.Y
	local v30 = v21.Y
	local v31 = p18.Z
	local v32 = -p20.Z
	local v33 = v21.Z
	local v34 = v25 * (v29 * v33 - v30 * v32) - v26 * (v28 * v33 - v30 * v31) + v27 * (v28 * v32 - v29 * v31)
	if v34 == 0 then
		return Vector3.new(0, 0, 0)
	end
	local v35 = -p20.X
	local v36 = v21.X
	local v37 = -p20.Y
	local v38 = v21.Y
	local v39 = -p20.Z
	local v40 = v21.Z
	local v41 = (v22 * (v37 * v40 - v38 * v39) - v35 * (v23 * v40 - v38 * v24) + v36 * (v23 * v39 - v37 * v24)) / v34
	local v42 = p18.X
	local v43 = v21.X
	local v44 = p18.Y
	local v45 = v21.Y
	local v46 = p18.Z
	local v47 = v21.Z
	local v48 = (v42 * (v23 * v47 - v45 * v24) - v22 * (v44 * v47 - v45 * v46) + v43 * (v44 * v24 - v23 * v46)) / v34
	local v49 = p17 + v41 * p18
	local v50 = p19 + v48 * p20
	local v51 = v49 + (v50 - v49) * 0.5
	return (v50 - v49).Magnitude >= 0.25 and Vector3.new(0, 0, 0) or v51
end
local v_u_53 = require(script.Parent:WaitForChild("BaseOcclusion"))
local v_u_54 = setmetatable({}, v_u_53)
v_u_54.__index = v_u_54
function v_u_54.new() -- name: new
	-- upvalues: (copy) v_u_53, (copy) v_u_54, (copy) v_u_4
	local v55 = v_u_53.new()
	local v56 = v_u_54
	local v57 = setmetatable(v55, v56)
	v57.char = nil
	v57.humanoidRootPart = nil
	v57.torsoPart = nil
	v57.headPart = nil
	v57.childAddedConn = nil
	v57.childRemovedConn = nil
	v57.ancestryChangedConn = nil
	v57.behaviors = {}
	v57.behaviors[v_u_4.LIMBS] = v57.LimbBehavior
	v57.behaviors[v_u_4.MOVEMENT] = v57.MoveBehavior
	v57.behaviors[v_u_4.CORNERS] = v57.CornerBehavior
	v57.behaviors[v_u_4.CIRCLE1] = v57.CircleBehavior
	v57.behaviors[v_u_4.CIRCLE2] = v57.CircleBehavior
	v57.behaviors[v_u_4.LIMBMOVE] = v57.LimbMoveBehavior
	v57.behaviors[v_u_4.SMART_CIRCLE] = v57.SmartCircleBehavior
	v57.behaviors[v_u_4.CHAR_OUTLINE] = v57.CharacterOutlineBehavior
	v57.mode = v_u_4.SMART_CIRCLE
	v57.behaviorFunction = v57.SmartCircleBehavior
	v57.savedHits = {}
	v57.trackedLimbs = {}
	v57.camera = workspace.CurrentCamera
	v57.enabled = false
	return v57
end
function v_u_54.Enable(p58, p59) -- name: Enable
	p58.enabled = p59
	if not p59 then
		p58:Cleanup()
		if p58.ancestryChangedConn then
			p58.ancestryChangedConn:Disconnect()
			p58.ancestryChangedConn = nil
		end
	end
end
function v_u_54.GetOcclusionMode(_) -- name: GetOcclusionMode
	return Enum.DevCameraOcclusionMode.Invisicam
end
function v_u_54.LimbBehavior(p60, p61) -- name: LimbBehavior
	for v62, _ in pairs(p60.trackedLimbs) do
		p61[#p61 + 1] = v62.Position
	end
end
function v_u_54.MoveBehavior(p63, p64) -- name: MoveBehavior
	for v65 = 1, 3 do
		local v66 = p63.humanoidRootPart.Position
		local v67 = p63.humanoidRootPart.Velocity
		local v68 = v67.X
		local v69 = v67.Z
		local v70 = Vector3.new(v68, 0, v69).Magnitude / 2
		local v71 = (v65 - 1) * p63.humanoidRootPart.CFrame.lookVector * v70
		p64[#p64 + 1] = v66 + v71
	end
end
function v_u_54.CornerBehavior(p72, p73) -- name: CornerBehavior
	-- upvalues: (copy) v_u_6
	local v74 = p72.humanoidRootPart.CFrame
	local v75 = v74.Position
	local v76 = v74 - v75
	local v77 = p72.char:GetExtentsSize() / 2
	p73[#p73 + 1] = v75
	for v78 = 1, #v_u_6 do
		p73[#p73 + 1] = v75 + v76 * (v77 * v_u_6[v78])
	end
end
function v_u_54.CircleBehavior(p79, p80) -- name: CircleBehavior
	-- upvalues: (copy) v_u_4
	local v81
	if p79.mode == v_u_4.CIRCLE1 then
		v81 = p79.humanoidRootPart.CFrame
	else
		local v82 = p79.camera.CoordinateFrame
		v81 = v82 - v82.Position + p79.humanoidRootPart.Position
	end
	p80[#p80 + 1] = v81.Position
	for v83 = 0, 9 do
		local v84 = 0.6283185307179586 * v83
		local v85 = math.cos(v84)
		local v86 = math.sin(v84)
		local v87 = Vector3.new(v85, v86, 0) * 3
		p80[#p80 + 1] = v81 * v87
	end
end
function v_u_54.LimbMoveBehavior(p88, p89) -- name: LimbMoveBehavior
	p88:LimbBehavior(p89)
	p88:MoveBehavior(p89)
end
function v_u_54.CharacterOutlineBehavior(p90, p91) -- name: CharacterOutlineBehavior
	-- upvalues: (copy) v_u_3, (copy) v_u_8
	local v92 = p90.torsoPart.CFrame.upVector.unit
	local v93 = p90.torsoPart.CFrame.rightVector.unit
	p91[#p91 + 1] = p90.torsoPart.CFrame.p
	p91[#p91 + 1] = p90.torsoPart.CFrame.p + v92
	p91[#p91 + 1] = p90.torsoPart.CFrame.p - v92
	p91[#p91 + 1] = p90.torsoPart.CFrame.p + v93
	p91[#p91 + 1] = p90.torsoPart.CFrame.p - v93
	if p90.headPart then
		p91[#p91 + 1] = p90.headPart.CFrame.p
	end
	local v94 = CFrame.new
	local v95 = p90.camera.CoordinateFrame.lookVector.X
	local v96 = p90.camera.CoordinateFrame.lookVector.Z
	local v97 = v94(Vector3.new(0, 0, 0), (Vector3.new(v95, 0, v96)))
	local v98 = p90.torsoPart and p90.torsoPart.Position or p90.humanoidRootPart.Position
	local v99 = { p90.torsoPart }
	if p90.headPart then
		v99[#v99 + 1] = p90.headPart
	end
	for v100 = 1, 24 do
		local v101 = 6.283185307179586 * v100 / 24
		local v102 = math.cos(v101)
		local v103 = math.sin(v101)
		local v104 = v97 * (Vector3.new(v102, v103, 0) * 3)
		local v105 = v104.X
		local v106 = v104.Y
		local v107 = math.max(v106, -2.25)
		local v108 = v104.Z
		local v109 = Vector3.new(v105, v107, v108)
		if v_u_3 then
			v_u_8.FilterDescendantsInstances = v99
			local v110 = workspace:Raycast(v98 + v109, -3 * v109, v_u_8)
			if not v110 then
				continue
			end
			local v111 = v110.Position
			p91[#p91 + 1] = v111 + 0.2 * (v98 - v111).unit
		else
			local v112 = Ray.new(v98 + v109, -3 * v109)
			local v113, v114 = workspace:FindPartOnRayWithWhitelist(v112, v99, false)
			if not v113 then
				continue
			end
			p91[#p91 + 1] = v114 + 0.2 * (v98 - v114).unit
		end
	end
end
function v_u_54.SmartCircleBehavior(p115, p116) -- name: SmartCircleBehavior
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_52
	local v117 = p115.torsoPart.CFrame.upVector.unit
	local v118 = p115.torsoPart.CFrame.rightVector.unit
	p116[#p116 + 1] = p115.torsoPart.CFrame.p
	p116[#p116 + 1] = p115.torsoPart.CFrame.p + v117
	p116[#p116 + 1] = p115.torsoPart.CFrame.p - v117
	p116[#p116 + 1] = p115.torsoPart.CFrame.p + v118
	p116[#p116 + 1] = p115.torsoPart.CFrame.p - v118
	if p115.headPart then
		p116[#p116 + 1] = p115.headPart.CFrame.p
	end
	local v119 = p115.camera.CFrame - p115.camera.CFrame.p
	local v120 = Vector3.new(0, 0.5, 0) + (p115.torsoPart and p115.torsoPart.Position or p115.humanoidRootPart.Position)
	for v121 = 1, 24 do
		local v122 = 0.2617993877991494 * v121 - 1.5707963267948966
		local v123 = math.cos(v122)
		local v124 = math.sin(v122)
		local v125 = v120 + v119 * (Vector3.new(v123, v124, 0) * 2.5)
		local v126 = v125 - p115.camera.CFrame.p
		if v_u_3 then
			v_u_7.FilterDescendantsInstances = { p115.char }
			local v127 = workspace:Raycast(v120, v125 - v120, v_u_7)
			if v127 then
				local v128 = v127.Position
				local v129 = v127.Normal
				local v130 = v128 + 0.1 * v129.unit
				local v131 = v130 - v120
				local v132 = v131:Cross(v126).unit:Cross(v129).unit
				local v133 = (v130 - p115.camera.CFrame.p).unit
				if v131.unit:Dot(-v132) < v131.unit:Dot(v133) then
					v125 = v_u_52(v130, v132, v125, v126)
					if v125.Magnitude > 0 then
						local v134 = workspace:Raycast(v130, v125 - v130, v_u_7)
						if v134 then
							v125 = v134.Position + 0.1 * v134.Normal.Unit
						end
					else
						v125 = v130
					end
				else
					v125 = v130
				end
				local v135 = workspace:Raycast(v120, v125 - v120, v_u_7)
				if v135 then
					v125 = v135.Position - 0.1 * (v125 - v120).unit
				end
			end
			p116[#p116 + 1] = v125
		else
			local v136 = Ray.new(v120, v125 - v120)
			local v137, v138, v139 = workspace:FindPartOnRayWithIgnoreList(v136, { p115.char }, false, false)
			if v137 then
				local v140 = v138 + 0.1 * v139.unit
				local v141 = v140 - v120
				local v142 = v141:Cross(v126).unit:Cross(v139).unit
				local v143 = (v140 - p115.camera.CFrame.p).unit
				if v141.unit:Dot(-v142) < v141.unit:Dot(v143) then
					v125 = v_u_52(v140, v142, v125, v126)
					if v125.Magnitude > 0 then
						local v144 = Ray.new(v140, v125 - v140)
						local v145, v146, v147 = workspace:FindPartOnRayWithIgnoreList(v144, { p115.char }, false, false)
						if v145 then
							v125 = v146 + 0.1 * v147.unit
						end
					else
						v125 = v140
					end
				else
					v125 = v140
				end
				local v148 = Ray.new(v120, v125 - v120)
				local v149, v150, _ = workspace:FindPartOnRayWithIgnoreList(v148, { p115.char }, false, false)
				if v149 then
					v125 = v150 - 0.1 * (v125 - v120).unit
				end
			end
			p116[#p116 + 1] = v125
		end
	end
end
function v_u_54.CheckTorsoReference(p151) -- name: CheckTorsoReference
	if p151.char then
		p151.torsoPart = p151.char:FindFirstChild("Torso")
		if not p151.torsoPart then
			p151.torsoPart = p151.char:FindFirstChild("UpperTorso")
			if not p151.torsoPart then
				p151.torsoPart = p151.char:FindFirstChild("HumanoidRootPart")
			end
		end
		p151.headPart = p151.char:FindFirstChild("Head")
	end
end
function v_u_54.CharacterAdded(p_u_152, p153, p154) -- name: CharacterAdded
	-- upvalues: (copy) v_u_1, (copy) v_u_5
	if p154 == v_u_1.LocalPlayer then
		if p_u_152.childAddedConn then
			p_u_152.childAddedConn:Disconnect()
			p_u_152.childAddedConn = nil
		end
		if p_u_152.childRemovedConn then
			p_u_152.childRemovedConn:Disconnect()
			p_u_152.childRemovedConn = nil
		end
		if p_u_152.ancestryChangedConn then
			p_u_152.ancestryChangedConn:Disconnect()
			p_u_152.ancestryChangedConn = nil
		end
		p_u_152.char = p153
		p_u_152.trackedLimbs = {}
		local function v156(p155) -- name: childAdded
			-- upvalues: (ref) v_u_5, (copy) p_u_152
			if p155:IsA("BasePart") then
				if v_u_5[p155.Name] then
					p_u_152.trackedLimbs[p155] = true
				end
				if p155.Name == "Torso" or p155.Name == "UpperTorso" then
					p_u_152.torsoPart = p155
				end
				if p155.Name == "Head" then
					p_u_152.headPart = p155
				end
			end
		end
		p_u_152.childAddedConn = p153.ChildAdded:Connect(v156)
		p_u_152.childRemovedConn = p153.ChildRemoved:Connect(function(p157) -- name: childRemoved
			-- upvalues: (copy) p_u_152
			p_u_152.trackedLimbs[p157] = nil
			p_u_152:CheckTorsoReference()
		end)
		for _, v158 in pairs(p_u_152.char:GetChildren()) do
			if not v158:IsA("BasePart") then
				continue
			end
			if v_u_5[v158.Name] then
				p_u_152.trackedLimbs[v158] = true
			end
			if v158.Name == "Torso" or v158.Name == "UpperTorso" then
				p_u_152.torsoPart = v158
			end
			if v158.Name ~= "Head" then
				continue
			end
			p_u_152.headPart = v158
		end
	end
end
function v_u_54.SetMode(p159, p160) -- name: SetMode
	-- upvalues: (copy) v_u_16, (copy) v_u_4
	v_u_16(p160, "number")
	for _, v161 in pairs(v_u_4) do
		if v161 ~= p160 then
			continue
		end
		p159.mode = p160
		p159.behaviorFunction = p159.behaviors[p159.mode]
		return
	end
	error("Invalid mode number")
end
function v_u_54.GetObscuredParts(p162) -- name: GetObscuredParts
	return p162.savedHits
end
function v_u_54.Cleanup(p163) -- name: Cleanup
	for v164, v165 in pairs(p163.savedHits) do
		v164.LocalTransparencyModifier = v165
	end
end
function v_u_54.Update(p_u_166, _, p167, p168) -- name: Update
	if not (p_u_166.enabled and p_u_166.char) then
		return p167, p168
	end
	p_u_166.camera = workspace.CurrentCamera
	if not p_u_166.humanoidRootPart then
		local v169 = p_u_166.char:FindFirstChildOfClass("Humanoid")
		if v169 and v169.RootPart then
			p_u_166.humanoidRootPart = v169.RootPart
		else
			p_u_166.humanoidRootPart = p_u_166.char:FindFirstChild("HumanoidRootPart")
			if not p_u_166.humanoidRootPart then
				return p167, p168
			end
		end
		if p_u_166.ancestryChangedConn then
			p_u_166.ancestryChangedConn:Disconnect()
			p_u_166.ancestryChangedConn = nil
		end
		p_u_166.ancestryChangedConn = p_u_166.humanoidRootPart.AncestryChanged:Connect(function(p170, p171)
			-- upvalues: (copy) p_u_166
			if p170 == p_u_166.humanoidRootPart and not p171 then
				p_u_166.humanoidRootPart = nil
				if p_u_166.ancestryChangedConn and p_u_166.ancestryChangedConn.Connected then
					p_u_166.ancestryChangedConn:Disconnect()
					p_u_166.ancestryChangedConn = nil
				end
			end
		end)
	end
	if not p_u_166.torsoPart then
		p_u_166:CheckTorsoReference()
		if not p_u_166.torsoPart then
			return p167, p168
		end
	end
	local v172 = {}
	p_u_166.behaviorFunction(p_u_166, v172)
	local v173 = { p_u_166.char }
	local v174 = p_u_166.headPart and p_u_166.headPart.CFrame.p or v172[1]
	local v175 = p_u_166.torsoPart and p_u_166.torsoPart.CFrame.p or v172[2]
	local v176 = p_u_166.camera:GetPartsObscuringTarget({ v174, v175 }, v173)
	local v177 = 0
	local v178 = {}
	local v179 = 0.75
	local v180 = {}
	local v181 = 0.75
	for v182 = 1, #v176 do
		local v183 = v176[v182]
		v177 = v177 + 1
		v178[v183] = true
		for _, v184 in pairs(v183:GetChildren()) do
			if not (v184:IsA("Decal") or v184:IsA("Texture")) then
				continue
			end
			v177 = v177 + 1
		end
	end
	if v177 > 0 then
		local v185 = 0.375 / v177 + 0.375
		local v186 = 1 / v177
		v179 = math.pow(v185, v186)
		local v187 = 0.25 / v177 + 0.25
		local v188 = 1 / v177
		v181 = math.pow(v187, v188)
	end
	local v189 = p_u_166.camera:GetPartsObscuringTarget(v172, v173)
	local v190 = {}
	for v191 = 1, #v189 do
		local v192 = v189[v191]
		v190[v192] = v178[v192] and v179 and v179 or v181
		if v192.Transparency < v190[v192] then
			v180[v192] = true
			if not p_u_166.savedHits[v192] then
				p_u_166.savedHits[v192] = v192.LocalTransparencyModifier
			end
		end
		for _, v193 in pairs(v192:GetChildren()) do
			if not (v193:IsA("Decal") or v193:IsA("Texture")) or v193.Transparency >= v190[v192] then
				continue
			end
			v190[v193] = v190[v192]
			v180[v193] = true
			if p_u_166.savedHits[v193] then
				continue
			end
			p_u_166.savedHits[v193] = v193.LocalTransparencyModifier
		end
	end
	for v194, v195 in pairs(p_u_166.savedHits) do
		if v180[v194] then
			v194.LocalTransparencyModifier = v194.Transparency < 1 and ((v190[v194] - v194.Transparency) / (1 - v194.Transparency) or 0) or 0
		else
			v194.LocalTransparencyModifier = v195
			p_u_166.savedHits[v194] = nil
		end
	end
	return p167, p168
end
return v_u_54
-- NIGHT Analyzer | Players.jejekwwkwiwi.PlayerScripts.PlayerModule.ControlModule.TouchJump
-- ModuleScript | 146 linhas | 4927 bytes | hash 0351749b

game:GetService("Players")
local v_u_1 = game:GetService("GuiService")
local v2 = script.Parent.Parent:WaitForChild("CommonUtils")
local v_u_3 = require(v2:WaitForChild("ConnectionUtil"))
local v_u_4 = require(v2:WaitForChild("CharacterUtil"))
local v_u_5 = require(script.Parent:WaitForChild("BaseCharacterController"))
local v_u_6 = setmetatable({}, v_u_5)
v_u_6.__index = v_u_6
function v_u_6.new() -- name: new
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_3
	local v7 = v_u_5.new()
	local v8 = v_u_6
	local v9 = setmetatable(v7, v8)
	v9.parentUIFrame = nil
	v9.jumpButton = nil
	v9.externallyEnabled = false
	v9.isJumping = false
	v9._active = false
	v9._connectionUtil = v_u_3.new()
	return v9
end
function v_u_6._reset(p10) -- name: _reset
	p10.isJumping = false
	p10.touchObject = nil
	if p10.jumpButton then
		p10.jumpButton.ImageRectOffset = Vector2.new(1, 146)
	end
end
function v_u_6.EnableButton(p_u_11, p12) -- name: EnableButton
	-- upvalues: (copy) v_u_1
	if p12 == p_u_11._active then
		p_u_11:_reset()
	else
		if p12 then
			if not p_u_11.jumpButton then
				p_u_11:Create()
			end
			p_u_11.jumpButton.Visible = false
			p_u_11._connectionUtil:trackConnection("JUMP_INPUT_ENDED", p_u_11.jumpButton.InputEnded:Connect(function(p13)
				-- upvalues: (copy) p_u_11
				if p13 == p_u_11.touchObject then
					p_u_11:_reset()
				end
			end))
			p_u_11._connectionUtil:trackConnection("MENU_OPENED", v_u_1.MenuOpened:Connect(function()
				-- upvalues: (copy) p_u_11
				if p_u_11.touchObject then
					p_u_11:_reset()
				end
			end))
		else
			if p_u_11.jumpButton then
				p_u_11.jumpButton.Visible = false
			end
			p_u_11._connectionUtil:disconnect("JUMP_INPUT_ENDED")
			p_u_11._connectionUtil:disconnect("MENU_OPENED")
		end
		p_u_11:_reset()
		p_u_11._active = p12
	end
end
function v_u_6.UpdateEnabled(p14) -- name: UpdateEnabled
	-- upvalues: (copy) v_u_4
	local v15 = v_u_4.getChild("Humanoid", "Humanoid")
	if v15 and (p14.externallyEnabled and (v15.JumpPower > 0 and v15:GetStateEnabled(Enum.HumanoidStateType.Jumping))) then
		p14:EnableButton(true)
	else
		p14:EnableButton(false)
	end
end
function v_u_6._setupConfigurations(p_u_16) -- name: _setupConfigurations
	-- upvalues: (copy) v_u_4
	local function v_u_17() -- name: update
		-- upvalues: (copy) p_u_16
		p_u_16:UpdateEnabled()
	end
	local v21 = v_u_4.onChild("Humanoid", "Humanoid", function(p18)
		-- upvalues: (copy) p_u_16, (copy) v_u_17
		p_u_16:UpdateEnabled()
		p_u_16._connectionUtil:trackConnection("HUMANOID_JUMP_POWER", p18:GetPropertyChangedSignal("JumpPower"):Connect(v_u_17))
		p_u_16._connectionUtil:trackConnection("HUMANOID_STATE_ENABLED_CHANGED", p18.StateEnabledChanged:Connect(function(p19, p20)
			-- upvalues: (ref) p_u_16
			if p19 == Enum.HumanoidStateType.Jumping and p20 ~= p_u_16._active then
				p_u_16:UpdateEnabled()
			end
		end))
	end)
	p_u_16._connectionUtil:trackConnection("HUMANOID", v21)
end
function v_u_6.Enable(p22, p23, p24) -- name: Enable
	if p24 then
		p22.parentUIFrame = p24
	end
	if p22.externallyEnabled == p23 then
		return
	else
		p22.externallyEnabled = p23
		p22:UpdateEnabled()
		if p23 then
			p22:_setupConfigurations()
		else
			p22._connectionUtil:disconnectAll()
		end
	end
end
function v_u_6.Create(p_u_25) -- name: Create
	if p_u_25.parentUIFrame then
		if p_u_25.jumpButton then
			p_u_25.jumpButton:Destroy()
			p_u_25.jumpButton = nil
		end
		if p_u_25.absoluteSizeChangedConn then
			p_u_25.absoluteSizeChangedConn:Disconnect()
			p_u_25.absoluteSizeChangedConn = nil
		end
		p_u_25.jumpButton = Instance.new("ImageButton")
		p_u_25.jumpButton.Name = "JumpButton"
		p_u_25.jumpButton.Visible = false
		p_u_25.jumpButton.BackgroundTransparency = 1
		p_u_25.jumpButton.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
		p_u_25.jumpButton.ImageRectOffset = Vector2.new(1, 146)
		p_u_25.jumpButton.ImageRectSize = Vector2.new(144, 144)
		local function v30() -- name: ResizeJumpButton
			-- upvalues: (copy) p_u_25
			local v26 = p_u_25.parentUIFrame.AbsoluteSize.x
			local v27 = p_u_25.parentUIFrame.AbsoluteSize.y
			local v28 = math.min(v26, v27) <= 500
			local v29 = v28 and 70 or 120
			p_u_25.jumpButton.Size = UDim2.new(0, v29, 0, v29)
			p_u_25.jumpButton.Position = v28 and UDim2.new(1, -(v29 * 1.5 - 10), 1, -v29 - 20) or UDim2.new(1, -(v29 * 1.5 - 10), 1, -v29 * 1.75)
		end
		v30()
		p_u_25.absoluteSizeChangedConn = p_u_25.parentUIFrame:GetPropertyChangedSignal("AbsoluteSize"):Connect(v30)
		p_u_25.touchObject = nil
		p_u_25.jumpButton.InputBegan:connect(function(p31)
			-- upvalues: (copy) p_u_25
			if not p_u_25.touchObject and (p31.UserInputType == Enum.UserInputType.Touch and p31.UserInputState == Enum.UserInputState.Begin) then
				p_u_25.touchObject = p31
				p_u_25.jumpButton.ImageRectOffset = Vector2.new(146, 146)
				p_u_25.isJumping = true
			end
		end)
		p_u_25.jumpButton.Parent = p_u_25.parentUIFrame
	end
end
return v_u_6
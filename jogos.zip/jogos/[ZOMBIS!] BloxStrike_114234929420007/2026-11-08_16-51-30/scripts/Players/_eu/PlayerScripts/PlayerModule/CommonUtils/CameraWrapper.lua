-- NIGHT Analyzer | Players.jejekwwkwiwi.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper
-- ModuleScript | 60 linhas | 1688 bytes | hash 8e93c481

local v_u_1 = require(script.Parent.ConnectionUtil)
local v_u_2 = {}
v_u_2.__index = v_u_2
function v_u_2.new() -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v3 = {
		["_camera"] = nil,
		["_callbacks"] = nil,
		["_connectionUtil"] = nil,
		["_enabled"] = false,
		["_camera"] = workspace.CurrentCamera,
		["_callbacks"] = {},
		["_connectionUtil"] = v_u_1.new()
	}
	local v4 = v_u_2
	return setmetatable(v3, v4)
end
function v_u_2._connectCallbacks(p5) -- name: _connectCallbacks
	p5._camera = workspace.CurrentCamera
	if p5._camera then
		for v6, v7 in p5._callbacks do
			p5._connectionUtil:trackConnection(v6, p5._camera:GetPropertyChangedSignal(v6):Connect(v7))
			v7()
		end
	end
end
function v_u_2.Enable(p_u_8) -- name: Enable
	if not p_u_8._enabled then
		p_u_8._enabled = true
		p_u_8._cameraChangedConnection = workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
			-- upvalues: (copy) p_u_8
			p_u_8:_connectCallbacks()
		end)
		p_u_8:_connectCallbacks()
	end
end
function v_u_2.Disable(p9) -- name: Disable
	if p9._enabled then
		p9._enabled = false
		if p9._cameraChangedConnection then
			p9._cameraChangedConnection:Disconnect()
			p9._cameraChangedConnection = nil
		end
		p9._connectionUtil:disconnectAll()
	end
end
function v_u_2.Connect(p10, p11, p12) -- name: Connect
	p10._callbacks[p11] = p12
	if p10._camera then
		p10._connectionUtil:trackConnection(p11, p10._camera:GetPropertyChangedSignal(p11):Connect(p12))
	end
end
function v_u_2.Disconnect(p13, p14) -- name: Disconnect
	p13._connectionUtil:disconnect(p14)
	p13._callbacks[p14] = nil
end
function v_u_2.getCamera(p15) -- name: getCamera
	return p15._camera
end
return v_u_2
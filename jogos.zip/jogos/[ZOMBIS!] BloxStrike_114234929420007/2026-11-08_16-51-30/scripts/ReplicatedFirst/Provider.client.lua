-- NIGHT Analyzer | ReplicatedFirst.Provider
-- LocalScript | 153 linhas | 4674 bytes | hash 6ec0f2b7

local v_u_1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("ReplicatedFirst")
local v_u_3 = game:GetService("ContentProvider")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game:GetService("RunService")
local v_u_6 = game:GetService("StarterGui")
local v_u_7 = game:GetService("Players").LocalPlayer
local v_u_8 = require(v_u_1:WaitForChild("Shared"):WaitForChild("Janitor"))
local v_u_9 = v_u_7:WaitForChild("PlayerGui")
v_u_9.ScreenOrientation = Enum.ScreenOrientation.LandscapeSensor
local v_u_10 = script:WaitForChild("Loader")
local v_u_11 = "Loading Profile"
local v_u_12 = 0
local v_u_13 = 0
local v_u_14 = false
local v_u_15 = 0
local v_u_16 = Instance.new("Frame")
v_u_16.Name = "InputBlocker"
v_u_16.Size = UDim2.new(1, 0, 1, 0)
v_u_16.Position = UDim2.new(0, 0, 0, 0)
v_u_16.BackgroundTransparency = 1
v_u_16.Active = true
v_u_16.ZIndex = 6767
v_u_16.Parent = v_u_10
local v_u_17 = {
	["TextLabel"] = "TextTransparency",
	["ImageLabel"] = "ImageTransparency",
	["Frame"] = "BackgroundTransparency"
}
v2:RemoveDefaultLoadingScreen()
v_u_10.Parent = v_u_9
local function v_u_22(p_u_18) -- name: ProcessFinished
	-- upvalues: (copy) v_u_1, (copy) v_u_6, (ref) v_u_14, (copy) v_u_9, (copy) v_u_10, (copy) v_u_17, (copy) v_u_4
	local v19 = v_u_1:WaitForChild("Assets"):WaitForChild("UI"):FindFirstChild("MainGui") or v_u_6:FindFirstChild("MainGui")
	if not v_u_14 then
		v_u_14 = true
		if v19 then
			v19.Parent = v_u_9
		end
		for _, v20 in ipairs(v_u_10:GetDescendants()) do
			local v21 = v_u_17[v20.ClassName]
			if not v21 or (not v20.Visible or v20[v21] >= 1) then
				continue
			end
			v_u_4:Create(v20, TweenInfo.new(0.95), {
				[v21] = 1
			}):Play()
		end
		task.delay(1, function()
			-- upvalues: (copy) p_u_18
			p_u_18:Destroy()
		end)
	end
end
task.spawn(function()
	-- upvalues: (copy) v_u_3, (copy) v_u_10
	v_u_3:PreloadAsync(v_u_10:GetDescendants())
end)
task.spawn(function()
	-- upvalues: (copy) v_u_8, (copy) v_u_16, (copy) v_u_10, (copy) v_u_5, (ref) v_u_13, (ref) v_u_11, (ref) v_u_12, (ref) v_u_15, (copy) v_u_7, (copy) v_u_22, (copy) v_u_1, (copy) v_u_3
	local v23 = v_u_8.new()
	v23:Add(v_u_16)
	v23:Add(v_u_10)
	local v_u_24 = tick()
	local v_u_25 = -1
	local v_u_26 = tick()
	local v_u_27 = 0
	local v_u_28 = ""
	v23:Add(v_u_5.Heartbeat:Connect(function(p29)
		-- upvalues: (ref) v_u_13, (ref) v_u_11, (ref) v_u_12, (ref) v_u_26, (ref) v_u_28, (ref) v_u_10, (ref) v_u_25, (ref) v_u_27, (ref) v_u_24, (ref) v_u_15
		local v30 = 25
		local v31 = tick()
		if v_u_13 > 0 and v_u_11 == "Loading Assets" then
			local v32 = v_u_12
			local v33 = v_u_13
			local v34 = math.min(v32, v33)
			local v35 = v31 - v_u_26
			local v36 = v34 / v_u_13
			local v37 = ("Loading Assets (%*/%*)"):format(v34, v_u_13)
			if v37 ~= v_u_28 then
				v_u_10.LoadingScreen.Title.Text = v37
				v_u_28 = v37
			end
			if v34 ~= v_u_25 then
				v_u_10.LoadingScreen.Title.TextTransparency = 1 - v36
				v_u_10.LoadingScreen.Icon.ImageTransparency = 1 - v36
				v_u_25 = v34
			end
			if v35 > 0 then
				local v38 = 25 + (v_u_12 - v_u_27) / v35 * 2
				v30 = math.min(v38, 95)
			end
			v_u_27 = v_u_12
			v_u_26 = v31
		else
			if v31 - v_u_24 >= 0.35 then
				v_u_15 = (v_u_15 + 1) % 3
				v_u_24 = v31
			end
			local v39 = "Loading Profile" .. string.rep(".", v_u_15 + 1)
			if v39 ~= v_u_28 then
				v_u_10.LoadingScreen.Title.Text = v39
				v_u_28 = v39
			end
			if v_u_10.LoadingScreen.Title.TextTransparency ~= 0 then
				v_u_10.LoadingScreen.Title.TextTransparency = 0
			end
		end
		v_u_10.LoadingScreen.Extra.Progress.Rotation = v_u_10.LoadingScreen.Extra.Progress.Rotation + p29 * v30
	end))
	repeat
		task.wait()
	until v_u_7:GetAttribute("DataLoaded")
	task.delay(4, v_u_22, v23)
	task.spawn(function()
		-- upvalues: (ref) v_u_1, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (ref) v_u_3
		local v40 = v_u_1:WaitForChild("Assets")
		local v41 = {}
		for _, v42 in { "UI", "TradingUI" } do
			local v43 = v40:FindFirstChild(v42)
			if not v43 then
				continue
			end
			for _, v44 in v43:GetDescendants() do
				table.insert(v41, v44)
			end
		end
		local v45 = v_u_1:WaitForChild("Sounds", 10)
		if v45 then
			for _, v46 in v45:GetDescendants() do
				table.insert(v41, v46)
			end
		end
		v_u_11 = "Loading Assets"
		v_u_12 = 0
		v_u_13 = #v41
		for v47 = 1, v_u_13, 64 do
			local v48 = v47 + 64 - 1
			local v49 = v_u_13
			local v50 = math.min(v48, v49)
			local v51 = table.create(v50 - v47 + 1)
			for v52 = v47, v50 do
				local v53 = v41[v52]
				table.insert(v51, v53)
			end
			v_u_3:PreloadAsync(v51, function()
				-- upvalues: (ref) v_u_12
				v_u_12 = v_u_12 + 1
			end)
			task.wait()
		end
	end)
end)
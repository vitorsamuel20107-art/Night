-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.Stiletto Knife
-- ModuleScript | 66 linhas | 1252 bytes | hash 6a6c791f

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 112217575637504 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Equip = v3
local v4 = {
	["Identifiers"] = { 81734984370986 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.HitOne = v4
local v5 = {
	["Identifiers"] = { 105560097678167 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.HitTwo = v5
local v6 = {
	["Identifiers"] = { 133015880124851 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.HitThree = v6
local v7 = {
	["Identifiers"] = { 139973941520045 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BackStab = v7
local v8 = {
	["Identifiers"] = { 116631884985433 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Inspect = v8
local v9 = {
	["Identifiers"] = { 0 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Inspect2 = v9
return v1(v2)
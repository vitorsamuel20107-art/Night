-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Grenade
-- ModuleScript | 76 linhas | 1511 bytes | hash b83667c3

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 137688232237801 },
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Bounce = v3
local v4 = {
	["Identifiers"] = { 137688232237801 },
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["Bounce HE"] = v4
local v5 = {
	["Identifiers"] = { 122995971386641 },
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["Bounce Smoke"] = v5
local v6 = {
	["Identifiers"] = { 122995971386641 },
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["Bounce Flashbang"] = v6
local v7 = {
	["Identifiers"] = { 87139857125840 },
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["Bounce Decoy"] = v7
local v8 = {
	["Identifiers"] = { 106867061518032 },
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["Bounce Incendiary"] = v8
local v9 = {
	["Identifiers"] = { 72443011611855 },
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["Bounce Molotov"] = v9
local v10 = {
	["Identifiers"] = { 104773847198928 },
	["Properties"] = {
		["RollOffMaxDistance"] = 115,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1,
		["Looped"] = true
	}
}
v2.Flames = v10
return v1(v2)
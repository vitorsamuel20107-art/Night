-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.Other
-- ModuleScript | 75 linhas | 1478 bytes | hash 10ba9824

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 82636267605216 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 2
	}
}
v2["Low Ammo Fire"] = v3
local v4 = {
	["Identifiers"] = { 94166866648466 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["Switch Fire Mode"] = v4
local v5 = {
	["Identifiers"] = { 108319593190654 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["Scope In"] = v5
local v6 = {
	["Identifiers"] = { 71209771528337 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["Scope Out"] = v6
local v7 = {
	["Identifiers"] = { 71332262366168 },
	["Properties"] = {
		["RollOffMaxDistance"] = 45,
		["RollOffMinDistance"] = 15,
		["Volume"] = 1
	}
}
v2["Toggle Scope"] = v7
local v8 = {
	["Identifiers"] = { 103611016763577 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["No Ammo"] = v8
local v9 = {
	["Identifiers"] = { 81585020866984 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Ping = v9
local v10 = {
	["Identifiers"] = { 94530388095663 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.5
	}
}
v2["Danger Ping"] = v10
return v1(v2)
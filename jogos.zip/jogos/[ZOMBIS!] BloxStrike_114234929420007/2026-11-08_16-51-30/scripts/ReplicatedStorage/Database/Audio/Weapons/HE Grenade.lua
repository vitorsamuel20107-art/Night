-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.HE Grenade
-- ModuleScript | 48 linhas | 971 bytes | hash e6ad61ab

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 81230559191344, 98108904149618, 117608836989336 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Start = v3
local v4 = {
	["Identifiers"] = { 106988361631252 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Clip = v4
local v5 = {
	["Identifiers"] = { 137767863113944 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Throw = v5
local v6 = {
	["Identifiers"] = { 74854763405520 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v6
local v7 = {
	["Identifiers"] = { 134617846246204, 91153272601218, 73493528515194 },
	["Properties"] = {
		["RollOffMaxDistance"] = 160,
		["RollOffMinDistance"] = 10,
		["Volume"] = 5
	}
}
v2.Explode = v7
return v1(v2)
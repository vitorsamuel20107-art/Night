-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.MP9
-- ModuleScript | 57 linhas | 1093 bytes | hash 14f12069

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 95092672998546 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v3
local v4 = {
	["Identifiers"] = { 116011180822245 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagIn = v4
local v5 = {
	["Identifiers"] = { 96352786063360 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagOut = v5
local v6 = {
	["Identifiers"] = { 122609602711596 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltForward = v6
local v7 = {
	["Identifiers"] = { 87332350712194 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltBack = v7
local v8 = {
	["Identifiers"] = { 116767970332192 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 35,
		["Volume"] = 0.85
	}
}
v2.Shoot = v8
return v1(v2)
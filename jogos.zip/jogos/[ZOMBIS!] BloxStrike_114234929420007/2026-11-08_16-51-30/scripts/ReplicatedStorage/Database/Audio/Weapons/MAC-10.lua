-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.MAC-10
-- ModuleScript | 57 linhas | 1127 bytes | hash a1ae8f52

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 136117333761749 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v3
local v4 = {
	["Identifiers"] = { 117652286948547 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagIn = v4
local v5 = {
	["Identifiers"] = { 127734199644932 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagOut = v5
local v6 = {
	["Identifiers"] = { 74054296541379 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltForward = v6
local v7 = {
	["Identifiers"] = { 97849841886499 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltBack = v7
local v8 = {
	["Identifiers"] = { 70409924258043, 140159960028734, 129790454341214 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 35,
		["Volume"] = 0.85
	}
}
v2.Shoot = v8
return v1(v2)
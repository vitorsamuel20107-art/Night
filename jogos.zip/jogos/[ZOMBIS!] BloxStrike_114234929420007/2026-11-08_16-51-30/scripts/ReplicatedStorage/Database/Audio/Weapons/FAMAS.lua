-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.FAMAS
-- ModuleScript | 66 linhas | 1257 bytes | hash dfd46aec

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 87491031818475 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagOut = v3
local v4 = {
	["Identifiers"] = { 94946391444484 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagIn = v4
local v5 = {
	["Identifiers"] = { 100856467348108 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltForward = v5
local v6 = {
	["Identifiers"] = { 116523016553161 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltBack = v6
local v7 = {
	["Identifiers"] = { 119520085561418 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v7
local v8 = {
	["Identifiers"] = { 81453331638041 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Tap = v8
local v9 = {
	["Identifiers"] = { 100717486977524 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 40,
		["Volume"] = 0.85
	}
}
v2.Shoot = v9
return v1(v2)
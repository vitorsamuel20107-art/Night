-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.FloorSounds
-- ModuleScript | 411 linhas | 7575 bytes | hash 1ab4952f

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 130033887072507 },
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.Jump = v3
local v4 = {
	["Identifiers"] = { 99466596855280 },
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.LandingConcrete = v4
local v5 = {
	["Identifiers"] = { 109412011545778 },
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.LandingDirt = v5
local v6 = {
	["Identifiers"] = { 78202018185923 },
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.LandingGlass = v6
local v7 = {
	["Identifiers"] = { 85183136145127 },
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.LandingGravel = v7
local v8 = {
	["Identifiers"] = { 99500002704168 },
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.LandingRubber = v8
local v9 = {
	["Identifiers"] = { 131233593992285 },
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.LandingSand = v9
local v10 = {
	["Identifiers"] = { 139175770184993 },
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.LandingGrass = v10
local v11 = {
	["Identifiers"] = { 139199167465543 },
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.LandingMetal = v11
local v12 = {
	["Identifiers"] = {
		91270542470564,
		95450755411619,
		126077546481604,
		106089093282448
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2. = v12
local v13 = {
	["Identifiers"] = {
		86763671272950,
		99698900896048,
		133733089175300,
		110116982062863
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2["Corroded Metal"] = v13
local v14 = {
	["Identifiers"] = {
		139049619848734,
		122667752106706,
		74820994047981,
		140693504749560
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.CeramicTiles = v14
local v15 = {
	["Identifiers"] = {
		71749773883678,
		84386012548210,
		96512401528849,
		137001957542905
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.Wood = v15
local v16 = {
	["Identifiers"] = {
		71749773883678,
		84386012548210,
		96512401528849,
		137001957542905
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.WoodPlanks = v16
local v17 = {
	["Identifiers"] = {
		113025048649331,
		109535294973923,
		106553181590103,
		100894963043342,
		84129898008532
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.375
	}
}
v2.Sand = v17
local v18 = {
	["Identifiers"] = {
		92210103823936,
		106250319626363,
		75564029984801,
		117230662284020
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.Metal = v18
local v19 = {
	["Identifiers"] = {
		128234973744087,
		89775371942579,
		85300133579049,
		122811017896680
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.Grass = v19
local v20 = {
	["Identifiers"] = {
		127473850154616,
		73964462740950,
		136772332152394,
		127960498426913
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.Ground = v20
local v21 = {
	["Identifiers"] = {
		127473850154616,
		73964462740950,
		136772332152394,
		127960498426913
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.Plastic = v21
local v22 = {
	["Identifiers"] = {
		127473850154616,
		73964462740950,
		136772332152394,
		127960498426913
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.Cardboard = v22
local v23 = {
	["Identifiers"] = {
		115402880444139,
		83949758218010,
		123531746508204,
		74830944093292
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.Concrete = v23
local v24 = {
	["Identifiers"] = {
		115402880444139,
		83949758218010,
		123531746508204,
		74830944093292
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.Pebble = v24
local v25 = {
	["Identifiers"] = {
		92210103823936,
		106250319626363,
		75564029984801,
		117230662284020
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.DiamondPlate = v25
local v26 = {
	["Identifiers"] = {
		105229370614051,
		117740430438823,
		129507165489163,
		117335205768047,
		110886985361817
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.Carpet = v26
local v27 = {
	["Identifiers"] = {
		105229370614051,
		117740430438823,
		129507165489163,
		117335205768047,
		110886985361817
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.Fabric = v27
local v28 = {
	["Identifiers"] = {
		119308548749944,
		76505615864286,
		108881600833897,
		99907470734259,
		129742848897554
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.Snow = v28
local v29 = {
	["Identifiers"] = {
		119308548749944,
		76505615864286,
		108881600833897,
		99907470734259,
		129742848897554
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.Mud = v29
local v30 = {
	["Identifiers"] = {
		115402880444139,
		83949758218010,
		123531746508204,
		74830944093292
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 10,
		["TimePosition"] = 0,
		["Looped"] = false,
		["Volume"] = 0.675
	}
}
v2.Asphalt = v30
return v1(v2)
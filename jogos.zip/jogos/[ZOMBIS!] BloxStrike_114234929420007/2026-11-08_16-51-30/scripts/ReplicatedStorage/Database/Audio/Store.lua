-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Store
-- ModuleScript | 293 linhas | 5339 bytes | hash cf5583ac

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 76198811077974 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Transaction Failed"] = v3
local v4 = {
	["Identifiers"] = { 105681920256526 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Successful Purchase"] = v4
local v5 = {
	["Identifiers"] = { 76537644589472 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Case Opening"] = v5
local v6 = {
	["Identifiers"] = { 76276535816710 },
	["Properties"] = {
		["Volume"] = 0.5,
		["Looped"] = true
	}
}
v2["Console Reel Spin"] = v6
local v7 = {
	["Identifiers"] = { 121166165216372 },
	["Properties"] = {
		["Volume"] = 3
	}
}
v2["Console Enter Animation"] = v7
local v8 = {
	["Identifiers"] = { 102275856674665 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Console Open Animation"] = v8
local v9 = {
	["Identifiers"] = { 129010536762296 },
	["Properties"] = {
		["Volume"] = 2.5
	}
}
v2["Console Connect 1"] = v9
local v10 = {
	["Identifiers"] = { 102081089733993 },
	["Properties"] = {
		["Volume"] = 2.5
	}
}
v2["Console Connect 2"] = v10
local v11 = {
	["Identifiers"] = { 112196627053254 },
	["Properties"] = {
		["Volume"] = 2.5
	}
}
v2["Console Connect 3"] = v11
local v12 = {
	["Identifiers"] = { 122098113437619 },
	["Properties"] = {
		["Volume"] = 2.5
	}
}
v2["Console Connect 4"] = v12
local v13 = {
	["Identifiers"] = { 100300790248880 },
	["Properties"] = {
		["Volume"] = 2.5
	}
}
v2["Console Connect 5"] = v13
local v14 = {
	["Identifiers"] = { 133752959723511 },
	["Properties"] = {
		["Volume"] = 2.5
	}
}
v2["Console Connect 6"] = v14
local v15 = {
	["Identifiers"] = { 78794280023206 },
	["Properties"] = {
		["Volume"] = 2.5
	}
}
v2["Console Connect 7"] = v15
local v16 = {
	["Identifiers"] = { 89224310081958 },
	["Properties"] = {
		["Volume"] = 2.5
	}
}
v2["Console Connect 8"] = v16
local v17 = {
	["Identifiers"] = { 81661113218084 },
	["Properties"] = {
		["Volume"] = 2.5
	}
}
v2["Console 10-Column Connect 1"] = v17
local v18 = {
	["Identifiers"] = { 102884904397712 },
	["Properties"] = {
		["Volume"] = 2.5
	}
}
v2["Console 10-Column Connect 2"] = v18
local v19 = {
	["Identifiers"] = { 97277812599103 },
	["Properties"] = {
		["Volume"] = 2.5
	}
}
v2["Console 10-Column Connect 3"] = v19
local v20 = {
	["Identifiers"] = { 92002289589164 },
	["Properties"] = {
		["Volume"] = 2.5
	}
}
v2["Console 10-Column Connect 4"] = v20
local v21 = {
	["Identifiers"] = { 127418183948439 },
	["Properties"] = {
		["Volume"] = 2.5
	}
}
v2["Console 10-Column Connect 5"] = v21
local v22 = {
	["Identifiers"] = { 118143605463064 },
	["Properties"] = {
		["Volume"] = 2.5
	}
}
v2["Console 10-Column Connect 6"] = v22
local v23 = {
	["Identifiers"] = { 101545842662907 },
	["Properties"] = {
		["Volume"] = 2.5
	}
}
v2["Console 10-Column Connect 7"] = v23
local v24 = {
	["Identifiers"] = { 88770554839811 },
	["Properties"] = {
		["Volume"] = 2.5
	}
}
v2["Console 10-Column Connect 8"] = v24
local v25 = {
	["Identifiers"] = { 137696458309932 },
	["Properties"] = {
		["Volume"] = 2.5
	}
}
v2["Console 10-Column Connect 9"] = v25
local v26 = {
	["Identifiers"] = { 116400759956650 },
	["Properties"] = {
		["Volume"] = 2.5
	}
}
v2["Console 10-Column Connect 10"] = v26
local v27 = {
	["Identifiers"] = { 91284252358061 },
	["Properties"] = {
		["Volume"] = 1,
		["Looped"] = true
	}
}
v2["Console Pink Tease Melody"] = v27
local v28 = {
	["Identifiers"] = { 136668891011022 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["Console Fail"] = v28
local v29 = {
	["Identifiers"] = { 73905462058647 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Case Close"] = v29
local v30 = {
	["Identifiers"] = { 79386102211506 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Drop Blue"] = v30
local v31 = {
	["Identifiers"] = { 131282996158246 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Drop Purple"] = v31
local v32 = {
	["Identifiers"] = { 76290554213801 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Drop Pink"] = v32
local v33 = {
	["Identifiers"] = { 93202525197790 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Drop Red"] = v33
local v34 = {
	["Identifiers"] = { 129865051671047 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Drop Gold"] = v34
local v35 = {
	["Identifiers"] = { 120962643765888 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Case Roll Tick"] = v35
local v36 = {
	["Identifiers"] = { 109653502187519 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Case Fall"] = v36
local v37 = {
	["Identifiers"] = { 118053561399536 },
	["Properties"] = {
		["Volume"] = 2
	}
}
v2["Charm Drag Start"] = v37
local v38 = {
	["Identifiers"] = { 122392709028764 },
	["Properties"] = {
		["Volume"] = 2,
		["Looped"] = false
	}
}
v2["Charm Drag Loop"] = v38
local v39 = {
	["Identifiers"] = { 81801736236778 },
	["Properties"] = {
		["Volume"] = 2
	}
}
v2["Package Drop"] = v39
local v40 = {
	["Identifiers"] = { 96074431590029 },
	["Properties"] = {
		["Volume"] = 2
	}
}
v2["Package Right Tape"] = v40
local v41 = {
	["Identifiers"] = { 71576549453097 },
	["Properties"] = {
		["Volume"] = 2
	}
}
v2["Package Left Tape"] = v41
local v42 = {
	["Identifiers"] = { 139940823424719 },
	["Properties"] = {
		["Volume"] = 2
	}
}
v2["Package Front Lid"] = v42
local v43 = {
	["Identifiers"] = { 87092023166122 },
	["Properties"] = {
		["Volume"] = 2
	}
}
v2["Package Final Open"] = v43
return v1(v2)
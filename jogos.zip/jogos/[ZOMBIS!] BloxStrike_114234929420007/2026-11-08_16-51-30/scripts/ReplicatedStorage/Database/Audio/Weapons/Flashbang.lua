-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.Flashbang
-- ModuleScript | 58 linhas | 1129 bytes | hash 56ef5423

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 81230559191344, 98108904149618, 117608836989336 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Start = v3
local v4 = {
	["Identifiers"] = { 106988361631252 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Clip = v4
local v5 = {
	["Identifiers"] = { 137767863113944 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Throw = v5
local v6 = {
	["Identifiers"] = { 74854763405520 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v6
local v7 = {
	["Identifiers"] = { 89603851678751 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Flash = v7
local v8 = {
	["Identifiers"] = { 125697513023074 },
	["Properties"] = {
		["RollOffMaxDistance"] = 0,
		["RollOffMinDistance"] = 0,
		["Volume"] = 2,
		["Looped"] = false
	}
}
v2.Flashed = v8
return v1(v2)
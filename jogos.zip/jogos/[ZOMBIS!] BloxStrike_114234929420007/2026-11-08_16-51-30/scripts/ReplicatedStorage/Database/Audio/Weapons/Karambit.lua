-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.Karambit
-- ModuleScript | 66 linhas | 1270 bytes | hash 61a10a87

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 134745018481603 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Equip = v3
local v4 = {
	["Identifiers"] = { 81266173817845 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1.9
	}
}
v2.HitOne = v4
local v5 = {
	["Identifiers"] = { 105579415089102 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1.9
	}
}
v2.HitTwo = v5
local v6 = {
	["Identifiers"] = { 85020825130566 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1.9
	}
}
v2.HitThree = v6
local v7 = {
	["Identifiers"] = { 139973941520045 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BackStab = v7
local v8 = {
	["Identifiers"] = { 78497440790307 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Inspect = v8
local v9 = {
	["Identifiers"] = { 86866127517719 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Handling2 = v9
return v1(v2)
-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.MAG-7
-- ModuleScript | 57 linhas | 1099 bytes | hash 01cba169

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 76487787030168 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Draw = v3
local v4 = {
	["Identifiers"] = { 89271875943042 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagOut = v4
local v5 = {
	["Identifiers"] = { 134303871621323 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 40,
		["Volume"] = 1.7
	}
}
v2.MagIn = v5
local v6 = {
	["Identifiers"] = { 88590451809623 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 40,
		["Volume"] = 0.85
	}
}
v2.PumpBack = v6
local v7 = {
	["Identifiers"] = { 117135677787054 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 40,
		["Volume"] = 0.85
	}
}
v2.PumpForward = v7
local v8 = {
	["Identifiers"] = { 78273678410885 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 40,
		["Volume"] = 0.85
	}
}
v2.Shoot = v8
return v1(v2)
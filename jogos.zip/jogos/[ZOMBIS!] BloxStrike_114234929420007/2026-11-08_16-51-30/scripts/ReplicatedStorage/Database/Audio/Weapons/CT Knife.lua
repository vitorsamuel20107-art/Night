-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.CT Knife
-- ModuleScript | 66 linhas | 1239 bytes | hash b6726c61

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 108280677329530 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.5
	}
}
v2.Equip = v3
local v4 = {
	["Identifiers"] = { 70427279100225 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.HitOne = v4
local v5 = {
	["Identifiers"] = { 70427279100225 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.HitTwo = v5
local v6 = {
	["Identifiers"] = { 70427279100225 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.HitThree = v6
local v7 = {
	["Identifiers"] = { 114744686361499 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BackStab = v7
local v8 = {
	["Identifiers"] = { 0 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Handling1 = v8
local v9 = {
	["Identifiers"] = { 0 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Handling2 = v9
return v1(v2)
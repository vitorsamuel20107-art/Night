-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.Butterfly Knife
-- ModuleScript | 75 linhas | 1465 bytes | hash 772ac698

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 95518099847763, 135171334586558 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Equip = v3
local v4 = {
	["Identifiers"] = { 90037151202748 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.HitOne = v4
local v5 = {
	["Identifiers"] = { 115326647964513 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.HitTwo = v5
local v6 = {
	["Identifiers"] = { 133078063183810 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.HitThree = v6
local v7 = {
	["Identifiers"] = { 139973941520045 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BackStab = v7
local v8 = {
	["Identifiers"] = { 94071915637636 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Handling1 = v8
local v9 = {
	["Identifiers"] = { 98872879099190 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Handling2 = v9
local v10 = {
	["Identifiers"] = { 99621166219319 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.SecondInspect = v10
return v1(v2)
-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.Negev
-- ModuleScript | 75 linhas | 1452 bytes | hash a1ff1c62

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 76994429900891 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v3
local v4 = {
	["Identifiers"] = { 115817458501784 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagIn = v4
local v5 = {
	["Identifiers"] = { 96729444440429 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagOut = v5
local v6 = {
	["Identifiers"] = { 126310515698564 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Bolt = v6
local v7 = {
	["Identifiers"] = { 103199185086775 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.CoverUp = v7
local v8 = {
	["Identifiers"] = { 82592681619308 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.CoverDown = v8
local v9 = {
	["Identifiers"] = { 119412986409975 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Chain = v9
local v10 = {
	["Identifiers"] = { 129396735228885, 129289869856620 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 40,
		["Volume"] = 0.85
	}
}
v2.Shoot = v10
return v1(v2)
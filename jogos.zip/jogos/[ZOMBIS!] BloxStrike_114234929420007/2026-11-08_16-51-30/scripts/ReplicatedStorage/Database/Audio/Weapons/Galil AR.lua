-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.Galil AR
-- ModuleScript | 57 linhas | 1110 bytes | hash 9da55175

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 135126098875969 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagOut = v3
local v4 = {
	["Identifiers"] = { 127195596080257 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagIn = v4
local v5 = {
	["Identifiers"] = { 86207494187133 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltForward = v5
local v6 = {
	["Identifiers"] = { 128995898238398 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltBack = v6
local v7 = {
	["Identifiers"] = { 86979896741106 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v7
local v8 = {
	["Identifiers"] = { 79032793562410, 116883869613039 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 40,
		["Volume"] = 0.75
	}
}
v2.Shoot = v8
return v1(v2)
-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Cutout
-- ModuleScript | 12 linhas | 241 bytes | hash 1977b3f5

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 110968051883842, 107920536060314 },
	["Properties"] = {
		["RollOffMaxDistance"] = 100,
		["RollOffMinDistance"] = 5,
		["Volume"] = 0.7
	}
}
v2.Raise = v3
return v1(v2)
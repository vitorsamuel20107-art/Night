-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Hostage
-- ModuleScript | 40 linhas | 816 bytes | hash dbd84999

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 79712382141071 },
	["Properties"] = {
		["RollOffMaxDistance"] = 25,
		["RollOffMinDistance"] = 5,
		["Looped"] = true,
		["Volume"] = 0.75
	}
}
v2["Hostage Idle"] = v3
local v4 = {
	["Identifiers"] = { 74099362693580 },
	["Properties"] = {
		["RollOffMaxDistance"] = 60,
		["RollOffMinDistance"] = 5,
		["Volume"] = 0.4
	}
}
v2["Generic Hostage Pickup"] = v4
local v5 = {
	["Identifiers"] = { 91391248595937 },
	["Properties"] = {
		["RollOffMaxDistance"] = 60,
		["RollOffMinDistance"] = 5,
		["Volume"] = 0.4
	}
}
v2["Hostage Kit Pickup"] = v5
local v6 = {
	["Identifiers"] = { 115533578916157 },
	["Properties"] = {
		["RollOffMaxDistance"] = 60,
		["RollOffMinDistance"] = 5,
		["Volume"] = 0.4
	}
}
v2["Hostage Pickup"] = v6
return v1(v2)
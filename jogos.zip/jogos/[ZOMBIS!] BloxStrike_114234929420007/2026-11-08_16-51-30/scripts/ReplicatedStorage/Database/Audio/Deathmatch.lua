-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Deathmatch
-- ModuleScript | 105 linhas | 1847 bytes | hash f3680083

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 98820262583245 },
	["Properties"] = {
		["RollOffMaxDistance"] = 115,
		["RollOffMinDistance"] = 5,
		["Volume"] = 1.33
	}
}
v2["Deathmatch Character Spawned"] = v3
local v4 = {
	["Identifiers"] = { 79494830572923 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["Deathmatch Character Died"] = v4
local v5 = {
	["Identifiers"] = { 117094641731981 },
	["Properties"] = {
		["Volume"] = 0.8
	}
}
v2["Deathmatch Death"] = v5
local v6 = {
	["Identifiers"] = { 135267577747216 },
	["Properties"] = {
		["Volume"] = 1.65
	}
}
v2["Deathmatch HP Bonus"] = v6
local v7 = {
	["Identifiers"] = { 117986623333910 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Monster Kill"] = v7
local v8 = {
	["Identifiers"] = { 125672036257817 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2.KillSpree = v8
local v9 = {
	["Identifiers"] = { 117305837058312 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2.Dominating = v9
local v10 = {
	["Identifiers"] = { 88805023581261 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2.Headshot = v10
local v11 = {
	["Identifiers"] = { 91481995230906 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2.Rampage = v11
local v12 = {
	["Identifiers"] = { 100913143709992 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2.Godlike = v12
local v13 = {
	["Identifiers"] = { 103755686676274 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2.MultiKill = v13
local v14 = {
	["Identifiers"] = { 125530693046064 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2.LudicrusKill = v14
local v15 = {
	["Identifiers"] = { 131043459721673 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2.Humiliation = v15
local v16 = {
	["Identifiers"] = { 88049235177774 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2.Unstoppable = v16
return v1(v2)
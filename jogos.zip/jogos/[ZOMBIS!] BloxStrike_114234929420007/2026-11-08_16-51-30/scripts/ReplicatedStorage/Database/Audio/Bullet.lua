-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Bullet
-- ModuleScript | 274 linhas | 5704 bytes | hash 0e87ee39

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 125321912363999 },
	["Properties"] = {
		["RollOffMaxDistance"] = 115,
		["RollOffMinDistance"] = 5,
		["Volume"] = 1.2
	}
}
v2["Helmet Headshot"] = v3
local v4 = {
	["Identifiers"] = {
		84662543261717,
		96415536708514,
		126151297003763,
		139434370539625,
		77334097595513
	},
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2.Whizz = v4
local v5 = {
	["Identifiers"] = {
		109001457067748,
		132217235664144,
		134238109611527,
		107873869943020
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 150,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1.2
	}
}
v2.Headshot = v5
local v6 = {
	["Identifiers"] = {
		107667789878316,
		124912612009209,
		92566163061648,
		117996590042443
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 150,
		["RollOffMinDistance"] = 50,
		["Volume"] = 1.15
	}
}
v2["Blood Splatter"] = v6
local v7 = {
	["Identifiers"] = { 93523702106264, 127025375550877, 118336424664776 },
	["Properties"] = {
		["RollOffMaxDistance"] = 115,
		["RollOffMinDistance"] = 15,
		["Volume"] = 1.2
	}
}
v2["Glass Shattered"] = v7
local v8 = {
	["Identifiers"] = { 97520306766475 },
	["Properties"] = {
		["RollOffMaxDistance"] = 60,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.35
	}
}
v2["Break Flower Pot"] = v8
local v9 = {
	["Identifiers"] = { 86749587479310 },
	["Properties"] = {
		["RollOffMaxDistance"] = 60,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.5
	}
}
v2["Break Metal Vent"] = v9
local v10 = {
	["Identifiers"] = { 110664241505472 },
	["Properties"] = {
		["RollOffMaxDistance"] = 60,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.35
	}
}
v2["Break Market Window"] = v10
local v11 = {
	["Identifiers"] = { 111027018509631 },
	["Properties"] = {
		["RollOffMaxDistance"] = 200,
		["RollOffMinDistance"] = 30,
		["Volume"] = 1.6
	}
}
v2.Bell1 = v11
local v12 = {
	["Identifiers"] = { 111027018509631 },
	["Properties"] = {
		["RollOffMaxDistance"] = 200,
		["RollOffMinDistance"] = 30,
		["Volume"] = 1.6,
		["Pitch"] = 1.05
	}
}
v2.Bell2 = v12
local v13 = {
	["Identifiers"] = { 111027018509631 },
	["Properties"] = {
		["RollOffMaxDistance"] = 200,
		["RollOffMinDistance"] = 30,
		["Volume"] = 1.6,
		["Pitch"] = 1.1
	}
}
v2.Bell3 = v13
local v14 = {
	["Identifiers"] = { 111027018509631 },
	["Properties"] = {
		["RollOffMaxDistance"] = 200,
		["RollOffMinDistance"] = 30,
		["Volume"] = 1.6,
		["Pitch"] = 1.15
	}
}
v2.Bell4 = v14
local v15 = {
	["Identifiers"] = { 111027018509631 },
	["Properties"] = {
		["RollOffMaxDistance"] = 200,
		["RollOffMinDistance"] = 30,
		["Volume"] = 1.6,
		["Pitch"] = 1.2
	}
}
v2.Bell5 = v15
local v16 = {
	["Identifiers"] = { 111027018509631 },
	["Properties"] = {
		["RollOffMaxDistance"] = 200,
		["RollOffMinDistance"] = 30,
		["Volume"] = 1.6,
		["Pitch"] = 1.25
	}
}
v2.Bell6 = v16
local v17 = {
	["Identifiers"] = { 101337223479947, 132874154038453, 116780567744545 },
	["Properties"] = {
		["RollOffMaxDistance"] = 35,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.5
	}
}
v2.Basalt = v17
local v18 = {
	["Identifiers"] = { 116882851736734, 78994860032877 },
	["Properties"] = {
		["RollOffMaxDistance"] = 35,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.5
	}
}
v2.Sand = v18
local v19 = {
	["Identifiers"] = { 84287180554352, 126580242242107, 99594419304288 },
	["Properties"] = {
		["RollOffMaxDistance"] = 35,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.5
	}
}
v2.Metal = v19
local v20 = {
	["Identifiers"] = { 90501168775606 },
	["Properties"] = {
		["RollOffMaxDistance"] = 35,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.5
	}
}
v2.Concrete = v20
local v21 = {
	["Identifiers"] = { 114796589756122, 117026408833237, 137556513607191 },
	["Properties"] = {
		["RollOffMaxDistance"] = 35,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.5
	}
}
v2.Fabric = v21
local v22 = {
	["Identifiers"] = { 134535666679403, 119925791840774, 90850154491305 },
	["Properties"] = {
		["RollOffMaxDistance"] = 35,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.5
	}
}
v2.Glass = v22
local v23 = {
	["Identifiers"] = { 114796589756122, 117026408833237, 137556513607191 },
	["Properties"] = {
		["RollOffMaxDistance"] = 35,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.5
	}
}
v2.Ground = v23
local v24 = {
	["Identifiers"] = { 90519346846361, 127522536498186, 84569787534340 },
	["Properties"] = {
		["RollOffMaxDistance"] = 35,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.5
	}
}
v2.Wood = v24
local v25 = {
	["Identifiers"] = { 90519346846361, 127522536498186, 84569787534340 },
	["Properties"] = {
		["RollOffMaxDistance"] = 35,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.5
	}
}
v2.WoodPlanks = v25
local v26 = {
	["Identifiers"] = { 138282986322870, 123605779448509, 108443295126150 },
	["Properties"] = {
		["RollOffMaxDistance"] = 35,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.5
	}
}
v2.CeramicTiles = v26
local v27 = {
	["Identifiers"] = { 74195352401130 },
	["Properties"] = {
		["RollOffMaxDistance"] = 55,
		["RollOffMinDistance"] = 5,
		["Volume"] = 0.75
	}
}
v2.Water = v27
local v28 = {
	["Identifiers"] = { 103580430698474, 140589304787966, 83899099249452 },
	["Properties"] = {
		["RollOffMaxDistance"] = 35,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.5
	}
}
v2.Cardboard = v28
local v29 = {
	["Identifiers"] = { 121077532378628, 70530737839629, 124091485730047 },
	["Properties"] = {
		["RollOffMaxDistance"] = 35,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.5
	}
}
v2.CorrodedMetal = v29
local v30 = {
	["Identifiers"] = { 89115248724907, 111362079945579, 138223638241538 },
	["Properties"] = {
		["RollOffMaxDistance"] = 35,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.5
	}
}
v2.Pebble = v30
return v1(v2)
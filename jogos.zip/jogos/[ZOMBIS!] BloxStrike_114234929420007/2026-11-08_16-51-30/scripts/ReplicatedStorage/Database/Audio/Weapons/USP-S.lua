-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.USP-S
-- ModuleScript | 120 linhas | 2361 bytes | hash 3807a0e5

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 125571824025435 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 35,
		["Volume"] = 0.75
	}
}
v2.Silencer = v3
local v4 = {
	["Identifiers"] = { 98572006947055 },
	["Properties"] = {
		["RollOffMaxDistance"] = 100,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.55
	}
}
v2.ScrewStart = v4
local v5 = {
	["Identifiers"] = { 104890047448099 },
	["Properties"] = {
		["RollOffMaxDistance"] = 100,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.55
	}
}
v2.ScrewOn1 = v5
local v6 = {
	["Identifiers"] = { 139432961729330 },
	["Properties"] = {
		["RollOffMaxDistance"] = 100,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.55
	}
}
v2.ScrewOn2 = v6
local v7 = {
	["Identifiers"] = { 131443473057876 },
	["Properties"] = {
		["RollOffMaxDistance"] = 100,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.55
	}
}
v2.ScrewOn3 = v7
local v8 = {
	["Identifiers"] = { 139432961729330 },
	["Properties"] = {
		["RollOffMaxDistance"] = 100,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.55
	}
}
v2.ScrewOn4 = v8
local v9 = {
	["Identifiers"] = { 131443473057876 },
	["Properties"] = {
		["RollOffMaxDistance"] = 100,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.55
	}
}
v2.ScrewOn5 = v9
local v10 = {
	["Identifiers"] = { 131443473057876 },
	["Properties"] = {
		["RollOffMaxDistance"] = 100,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.55
	}
}
v2.ScrewOnEnd = v10
local v11 = {
	["Identifiers"] = { 91670240864405 },
	["Properties"] = {
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 25,
		["Volume"] = 0.7
	}
}
v2.Shoot = v11
local v12 = {
	["Identifiers"] = { 98755126356947 },
	["Properties"] = {
		["RollOffMaxDistance"] = 100,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.75
	}
}
v2.MagIn = v12
local v13 = {
	["Identifiers"] = { 90969598010170 },
	["Properties"] = {
		["RollOffMaxDistance"] = 100,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1.25
	}
}
v2.MagOut = v13
local v14 = {
	["Identifiers"] = { 108732491364154 },
	["Properties"] = {
		["RollOffMaxDistance"] = 100,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.75
	}
}
v2.Bolt = v14
local v15 = {
	["Identifiers"] = { 93226589921777 },
	["Properties"] = {
		["RollOffMaxDistance"] = 100,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.6
	}
}
v2.Handling = v15
return v1(v2)
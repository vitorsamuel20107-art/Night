-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.Zeus x27
-- ModuleScript | 21 linhas | 395 bytes | hash bbbd807a

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 134011675599955 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Equip = v3
local v4 = {
	["Identifiers"] = { 112663279059173 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Shoot = v4
return v1(v2)
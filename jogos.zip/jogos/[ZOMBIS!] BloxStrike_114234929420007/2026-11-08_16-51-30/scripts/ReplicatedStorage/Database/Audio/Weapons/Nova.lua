-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.Nova
-- ModuleScript | 39 linhas | 739 bytes | hash 3437007a

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 120040980303141 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 40,
		["Volume"] = 0.85
	}
}
v2.Shoot = v3
local v4 = {
	["Identifiers"] = { 123643677445236 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagIn = v4
local v5 = {
	["Identifiers"] = { 93859208090987 },
	["Properties"] = {
		["RollOffMaxDistance"] = 165,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Pump = v5
local v6 = {
	["Identifiers"] = { 95050949519714 },
	["Properties"] = {
		["RollOffMaxDistance"] = 165,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v6
return v1(v2)
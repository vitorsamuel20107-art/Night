-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.P90
-- ModuleScript | 66 linhas | 1273 bytes | hash 15036683

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 133456441212285 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagOut = v3
local v4 = {
	["Identifiers"] = { 92927438494992 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagIn = v4
local v5 = {
	["Identifiers"] = { 122983309211249 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Tap = v5
local v6 = {
	["Identifiers"] = { 96158367755546 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltBack = v6
local v7 = {
	["Identifiers"] = { 111937410952901 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltForward = v7
local v8 = {
	["Identifiers"] = { 139075635115160 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v8
local v9 = {
	["Identifiers"] = { 93444438747180, 73266589498757 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 35,
		["Volume"] = 0.85
	}
}
v2.Shoot = v9
return v1(v2)
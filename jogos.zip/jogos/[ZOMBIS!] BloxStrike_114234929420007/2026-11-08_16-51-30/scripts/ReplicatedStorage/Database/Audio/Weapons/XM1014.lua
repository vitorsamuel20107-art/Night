-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.XM1014
-- ModuleScript | 30 linhas | 568 bytes | hash 8903c73d

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 98974289876379 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v3
local v4 = {
	["Identifiers"] = { 108565766785232 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagIn = v4
local v5 = {
	["Identifiers"] = { 72242477698431 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 40,
		["Volume"] = 0.85
	}
}
v2.Shoot = v5
return v1(v2)
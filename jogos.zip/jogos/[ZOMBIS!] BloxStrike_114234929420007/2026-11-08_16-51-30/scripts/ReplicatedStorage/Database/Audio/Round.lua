-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Round
-- ModuleScript | 49 linhas | 871 bytes | hash 9642f844

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 106852418809066 },
	["Properties"] = {
		["Volume"] = 1.5
	}
}
v2["Round Start Countdown"] = v3
local v4 = {
	["Identifiers"] = { 123965984428799 },
	["Properties"] = {
		["Volume"] = 0.4,
		["Looped"] = false
	}
}
v2["Buy Phase"] = v4
local v5 = {
	["Identifiers"] = { 140006209772214 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2.Draw = v5
local v6 = {
	["Identifiers"] = { 122096021663409 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Counter-Terrorists Win"] = v6
local v7 = {
	["Identifiers"] = { 107650241796316 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Terrorists Win"] = v7
local v8 = {
	["Identifiers"] = { 95976833351497 },
	["Properties"] = {
		["RollOffMaxDistance"] = 0,
		["RollOffMinDistance"] = 0,
		["Volume"] = 0.333,
		["Looped"] = false
	}
}
v2.MVP = v8
return v1(v2)
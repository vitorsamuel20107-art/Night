-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.Glock-18
-- ModuleScript | 57 linhas | 1095 bytes | hash efc0d9af

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 138329781819375 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagOut = v3
local v4 = {
	["Identifiers"] = { 86741480729826 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagIn = v4
local v5 = {
	["Identifiers"] = { 131792395124469 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltPull = v5
local v6 = {
	["Identifiers"] = { 131792395124469 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltRelease = v6
local v7 = {
	["Identifiers"] = { 116721189534177 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v7
local v8 = {
	["Identifiers"] = { 129263398905118 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 35,
		["Volume"] = 0.85
	}
}
v2.Shoot = v8
return v1(v2)
-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.AWP
-- ModuleScript | 75 linhas | 1443 bytes | hash 8d7dd4a9

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 75969953466902 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 40,
		["Volume"] = 1
	}
}
v2.Shoot = v3
local v4 = {
	["Identifiers"] = { 122730633571709 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.8
	}
}
v2.Draw = v4
local v5 = {
	["Identifiers"] = { 82629690706318 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.8
	}
}
v2.MagOut = v5
local v6 = {
	["Identifiers"] = { 119166747433534 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.MagIn = v6
local v7 = {
	["Identifiers"] = { 96661102024055 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagIn2 = v7
local v8 = {
	["Identifiers"] = { 112869813289892 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltBack = v8
local v9 = {
	["Identifiers"] = { 117097054023518 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.25
	}
}
v2.BoltForward = v9
local v10 = {
	["Identifiers"] = { 74482956854085 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Zoom = v10
return v1(v2)
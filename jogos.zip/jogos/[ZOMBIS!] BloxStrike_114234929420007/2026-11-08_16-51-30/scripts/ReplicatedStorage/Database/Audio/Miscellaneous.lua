-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Miscellaneous
-- ModuleScript | 33 linhas | 733 bytes | hash 7049ae73

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 113908883188966 },
	["Properties"] = {
		["RollOffMaxDistance"] = 60,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["Open Garage"] = v3
local v4 = {
	["Identifiers"] = { 108976400967979 },
	["Properties"] = {
		["RollOffMaxDistance"] = 60,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["Close Garage"] = v4
local v5 = {
	["Identifiers"] = { 79873000109115, 102584329392475, 120727679421473 },
	["Properties"] = {
		["RollOffMode"] = Enum.RollOffMode.InverseTapered,
		["RollOffMaxDistance"] = 110,
		["RollOffMinDistance"] = 6,
		["Volume"] = 0.5,
		["Persistent"] = true,
		["WarmOnUse"] = true
	}
}
v2["Electricity Zap"] = v5
return v1(v2)
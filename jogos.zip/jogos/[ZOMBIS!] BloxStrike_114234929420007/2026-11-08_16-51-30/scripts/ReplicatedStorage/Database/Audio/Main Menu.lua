-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Main Menu
-- ModuleScript | 11 linhas | 196 bytes | hash b83cf8a1

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 105001316378655 },
	["Properties"] = {
		["Looped"] = true,
		["Volume"] = 0.2
	}
}
v2["Main Menu Music"] = v3
return v1(v2)
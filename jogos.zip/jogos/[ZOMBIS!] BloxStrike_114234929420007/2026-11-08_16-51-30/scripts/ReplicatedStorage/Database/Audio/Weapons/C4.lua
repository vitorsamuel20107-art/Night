-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.C4
-- ModuleScript | 120 linhas | 2436 bytes | hash e8babaff

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 96197427670107, 106053408588344 },
	["Properties"] = {
		["RollOffMaxDistance"] = 105,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["7"] = v3
local v4 = {
	["Identifiers"] = { 96197427670107, 106053408588344 },
	["Properties"] = {
		["RollOffMaxDistance"] = 105,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["73"] = v4
local v5 = {
	["Identifiers"] = { 96197427670107, 106053408588344 },
	["Properties"] = {
		["RollOffMaxDistance"] = 105,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["735"] = v5
local v6 = {
	["Identifiers"] = { 96197427670107, 106053408588344 },
	["Properties"] = {
		["RollOffMaxDistance"] = 105,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["7355"] = v6
local v7 = {
	["Identifiers"] = { 96197427670107, 106053408588344 },
	["Properties"] = {
		["RollOffMaxDistance"] = 105,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["73556"] = v7
local v8 = {
	["Identifiers"] = { 96197427670107, 106053408588344 },
	["Properties"] = {
		["RollOffMaxDistance"] = 105,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["735560"] = v8
local v9 = {
	["Identifiers"] = { 96197427670107, 106053408588344 },
	["Properties"] = {
		["RollOffMaxDistance"] = 105,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["7355608"] = v9
local v10 = {
	["Identifiers"] = { 79681018087442 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v10
local v11 = {
	["Identifiers"] = { 95365518713925 },
	["Properties"] = {
		["RollOffMaxDistance"] = 105,
		["RollOffMinDistance"] = 10,
		["Volume"] = 2.2
	}
}
v2.Planting = v11
local v12 = {
	["Identifiers"] = { 104816011091831 },
	["Properties"] = {
		["RollOffMaxDistance"] = 350,
		["RollOffMinDistance"] = 100,
		["Volume"] = 1.3
	}
}
v2.Beep = v12
local v13 = {
	["Identifiers"] = { 81516735555573 },
	["Properties"] = {
		["RollOffMaxDistance"] = 150,
		["RollOffMinDistance"] = 20,
		["Volume"] = 2
	}
}
v2.Explosion = v13
local v14 = {
	["Identifiers"] = { 140380495972795 },
	["Properties"] = {
		["RollOffMaxDistance"] = 500,
		["RollOffMinDistance"] = 50,
		["Volume"] = 2
	}
}
v2.Boom = v14
local v15 = {
	["Identifiers"] = { 116209203633664 },
	["Properties"] = {
		["RollOffMaxDistance"] = 105,
		["RollOffMinDistance"] = 12,
		["Volume"] = 2.2
	}
}
v2.Defusing = v15
return v1(v2)
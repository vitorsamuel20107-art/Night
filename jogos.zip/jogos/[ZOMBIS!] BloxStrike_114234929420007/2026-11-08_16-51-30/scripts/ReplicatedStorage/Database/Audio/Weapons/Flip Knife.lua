-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.Flip Knife
-- ModuleScript | 66 linhas | 1267 bytes | hash 301a2560

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 79788214377558 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Equip = v3
local v4 = {
	["Identifiers"] = { 108355773920883 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.HitOne = v4
local v5 = {
	["Identifiers"] = { 124741675328738 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.HitTwo = v5
local v6 = {
	["Identifiers"] = { 136418246990630 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.HitThree = v6
local v7 = {
	["Identifiers"] = { 139973941520045 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BackStab = v7
local v8 = {
	["Identifiers"] = { 115341727423736 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Inspect = v8
local v9 = {
	["Identifiers"] = { 118376702285638 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Handling2 = v9
return v1(v2)
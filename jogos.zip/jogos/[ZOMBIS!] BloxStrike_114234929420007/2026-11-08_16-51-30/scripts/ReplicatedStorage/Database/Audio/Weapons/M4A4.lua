-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.M4A4
-- ModuleScript | 66 linhas | 1284 bytes | hash 07b86c92

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 123118360474955, 87048948830319, 70902707285906 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 40,
		["Volume"] = 1
	}
}
v2.Shoot = v3
local v4 = {
	["Identifiers"] = { 84697199081304 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagOut = v4
local v5 = {
	["Identifiers"] = { 117713607717356 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagIn = v5
local v6 = {
	["Identifiers"] = { 92968387066818 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltRelease = v6
local v7 = {
	["Identifiers"] = { 99852757469810 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltPull = v7
local v8 = {
	["Identifiers"] = { 96457762026396 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v8
local v9 = {
	["Identifiers"] = { 91264677067592 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Tap = v9
return v1(v2)
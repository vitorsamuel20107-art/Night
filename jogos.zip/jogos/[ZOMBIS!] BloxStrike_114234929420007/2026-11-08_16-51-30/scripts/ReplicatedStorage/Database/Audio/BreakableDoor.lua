-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.BreakableDoor
-- ModuleScript | 57 linhas | 1112 bytes | hash 4050c0f9

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 87933839694208 },
	["Properties"] = {
		["RollOffMaxDistance"] = 60,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.6
	}
}
v2.Open = v3
local v4 = {
	["Identifiers"] = { 85555122718997 },
	["Properties"] = {
		["RollOffMaxDistance"] = 60,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.6
	}
}
v2.Close = v4
local v5 = {
	["Identifiers"] = { 137182840978586 },
	["Properties"] = {
		["RollOffMaxDistance"] = 60,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.55
	}
}
v2.OpenImpact = v5
local v6 = {
	["Identifiers"] = { 112092922112440 },
	["Properties"] = {
		["RollOffMaxDistance"] = 60,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.55
	}
}
v2.CloseImpact = v6
local v7 = {
	["Identifiers"] = { 128936827166279 },
	["Properties"] = {
		["RollOffMaxDistance"] = 60,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.5
	}
}
v2.Break = v7
local v8 = {
	["Identifiers"] = { 128936827166279 },
	["Properties"] = {
		["RollOffMaxDistance"] = 45,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.4
	}
}
v2["Part Hit Ground"] = v8
return v1(v2)
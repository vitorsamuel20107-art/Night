-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.Dual Berettas
-- ModuleScript | 75 linhas | 1434 bytes | hash 7833d183

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 130319416623558 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagOut = v3
local v4 = {
	["Identifiers"] = { 74475884383433 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagInRIGHT = v4
local v5 = {
	["Identifiers"] = { 122478130173986 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagInLEFT = v5
local v6 = {
	["Identifiers"] = { 73592056417107 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Bolt = v6
local v7 = {
	["Identifiers"] = { 120031964444724 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v7
local v8 = {
	["Identifiers"] = { 94337423663604 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Tap = v8
local v9 = {
	["Identifiers"] = { 108508645677337 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Flip = v9
local v10 = {
	["Identifiers"] = { 86593118062277 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 35,
		["Volume"] = 0.85
	}
}
v2.Shoot = v10
return v1(v2)
-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.Sawed-Off
-- ModuleScript | 39 linhas | 789 bytes | hash b07ccea0

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 75539311638723 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Draw = v3
local v4 = {
	["Identifiers"] = { 123066862865418, 97214857758776 },
	["Properties"] = {
		["RollOffMaxDistance"] = 130,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Insert = v4
local v5 = {
	["Identifiers"] = { 80662425274516 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 40,
		["Volume"] = 0.85
	}
}
v2.Pump = v5
local v6 = {
	["Identifiers"] = { 79019339248233, 73770073099104, 76695723095051 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 40,
		["Volume"] = 0.85
	}
}
v2.Shoot = v6
return v1(v2)
-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.Molotov
-- ModuleScript | 48 linhas | 973 bytes | hash 3b5e7c57

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 81230559191344, 98108904149618, 117608836989336 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Start = v3
local v4 = {
	["Identifiers"] = { 106988361631252 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Clip = v4
local v5 = {
	["Identifiers"] = { 137767863113944 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Throw = v5
local v6 = {
	["Identifiers"] = { 73623953518293 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v6
local v7 = {
	["Identifiers"] = { 112272402810859, 122260089260282, 123801491911390 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Explode = v7
return v1(v2)
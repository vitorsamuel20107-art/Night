-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.ZombieSurvival
-- ModuleScript | 192 linhas | 3946 bytes | hash 7f435ceb

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 123196956169306 },
	["Properties"] = table.freeze({
		["Volume"] = 1.3
	})
}
v2["Max Ammo"] = v3
local v4 = {
	["Identifiers"] = { 81443284188091, 108467569068674, 86252221168580 },
	["Properties"] = table.freeze({
		["Volume"] = 3.2
	})
}
v2["Health Kit"] = v4
local v5 = {
	["Identifiers"] = { 128484098204416, 88023510272592 },
	["Properties"] = table.freeze({
		["Volume"] = 5.4
	})
}
v2["Health Kit Close Call"] = v5
local v6 = {
	["Identifiers"] = { 82136318988389 },
	["Properties"] = table.freeze({
		["Volume"] = 3.8
	})
}
v2["Generator A Under Attack"] = v6
local v7 = {
	["Identifiers"] = { 117109794852490 },
	["Properties"] = table.freeze({
		["Volume"] = 4.2
	})
}
v2["Generator B Under Attack"] = v7
local v8 = {
	["Identifiers"] = { 83526962319242 },
	["Properties"] = table.freeze({
		["Volume"] = 2.7
	})
}
v2["Generator A Failing"] = v8
local v9 = {
	["Identifiers"] = { 112286330095095 },
	["Properties"] = table.freeze({
		["Volume"] = 2.7
	})
}
v2["Generator B Failing"] = v9
local v10 = {
	["Identifiers"] = { 107833531824085 },
	["Properties"] = table.freeze({
		["Volume"] = 1.7
	})
}
v2["Generator A Offline"] = v10
local v11 = {
	["Identifiers"] = { 89376036508063 },
	["Properties"] = table.freeze({
		["Volume"] = 3
	})
}
v2["Generator B Offline"] = v11
local v12 = {
	["Identifiers"] = { 102865474015217 },
	["Properties"] = table.freeze({
		["Volume"] = 2.5
	})
}
v2["One Generator Left"] = v12
local v13 = {
	["Identifiers"] = { 117749920201597, 101970927897059 },
	["Properties"] = table.freeze({
		["Volume"] = 1.9
	})
}
v2.Surrounded = v13
local v14 = {
	["Identifiers"] = { 139417776245786 },
	["Properties"] = table.freeze({
		["Volume"] = 1.2
	})
}
v2.Reloading = v14
local v15 = {
	["Identifiers"] = { 71358369254010 },
	["Properties"] = table.freeze({
		["Volume"] = 3.5
	})
}
v2["Headshot Streak"] = v15
local v16 = {
	["Identifiers"] = { 101243377638862 },
	["Properties"] = table.freeze({
		["Volume"] = 2.6
	})
}
v2["Double Kill"] = v16
local v17 = {
	["Identifiers"] = { 91349775780191 },
	["Properties"] = table.freeze({
		["Volume"] = 1.1
	})
}
v2["Triple Kill"] = v17
local v18 = {
	["Identifiers"] = { 97748853505199 },
	["Properties"] = table.freeze({
		["Volume"] = 3.2
	})
}
v2.Massacre = v18
local v19 = {
	["Identifiers"] = { 105405206625918, 113149541079058, 113153711874987 },
	["Properties"] = table.freeze({
		["Volume"] = 1.8
	})
}
v2["Buy Period Start"] = v19
local v20 = {
	["Identifiers"] = { 136872256828999 },
	["Properties"] = table.freeze({
		["Volume"] = 3
	})
}
v2["Upgrade Reminder"] = v20
local v21 = {
	["Identifiers"] = { 87910112695007, 79104883139632 },
	["Properties"] = table.freeze({
		["Volume"] = 1.4
	})
}
v2["Buy Period End"] = v21
local v22 = {
	["Identifiers"] = { 101902075450934, 89149387108623 },
	["Properties"] = table.freeze({
		["Volume"] = 2.5
	})
}
v2["Weapon Bought"] = v22
local v23 = {
	["Identifiers"] = { 85660115031929 },
	["Properties"] = table.freeze({
		["Volume"] = 3.1
	})
}
v2["First Big Purchase"] = v23
local v24 = {
	["Identifiers"] = { 76579918101479 },
	["Properties"] = table.freeze({
		["Volume"] = 1.6
	})
}
v2["Armor Bought"] = v24
local v25 = {
	["Identifiers"] = { 102692723380362 },
	["Properties"] = table.freeze({
		["Volume"] = 2.9
	})
}
v2["Ammo Bought"] = v25
local v26 = {
	["Identifiers"] = { 129010936720704 },
	["Properties"] = table.freeze({
		["Volume"] = 1.9
	})
}
v2["Captain Flaming Wave"] = v26
local v27 = {
	["Identifiers"] = { 127655353190667 },
	["Properties"] = table.freeze({
		["Volume"] = 2.5
	})
}
v2["Captain Laugh Horde"] = v27
local v28 = {
	["Identifiers"] = { 127586009713716 },
	["Properties"] = table.freeze({
		["Volume"] = 1.9
	})
}
v2["Captain Laugh Gasp"] = v28
local v29 = {
	["Identifiers"] = { 86289205360331 },
	["Properties"] = table.freeze({
		["Volume"] = 1.5
	})
}
v2["Captain Laugh Hysterical"] = v29
return v1(v2)
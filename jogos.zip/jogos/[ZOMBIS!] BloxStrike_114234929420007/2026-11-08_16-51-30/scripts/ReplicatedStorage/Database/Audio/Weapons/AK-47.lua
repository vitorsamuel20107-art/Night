-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.AK-47
-- ModuleScript | 48 linhas | 926 bytes | hash 4957bc65

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 105895740050720 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagOut = v3
local v4 = {
	["Identifiers"] = { 99110846823726 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagIn = v4
local v5 = {
	["Identifiers"] = { 84356538600576 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Bolt = v5
local v6 = {
	["Identifiers"] = { 77480808991354 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v6
local v7 = {
	["Identifiers"] = { 92989811154380, 92943704247952 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 40,
		["Volume"] = 0.85
	}
}
v2.Shoot = v7
return v1(v2)
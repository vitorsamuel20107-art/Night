-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Survival
-- ModuleScript | 153 linhas | 3350 bytes | hash c6e91950

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 140196859686551, 73327931479157, 91285231993094 },
	["Properties"] = {
		["RollOffMode"] = Enum.RollOffMode.InverseTapered,
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 8,
		["Volume"] = 0.55
	}
}
v2["Zombie Idle"] = v3
local v4 = {
	["Identifiers"] = { 107858660209501, 103842574188559, 93530458072522 },
	["Properties"] = {
		["RollOffMode"] = Enum.RollOffMode.InverseTapered,
		["RollOffMaxDistance"] = 80,
		["RollOffMinDistance"] = 8,
		["Volume"] = 0.8
	}
}
v2["Zombie Pain"] = v4
local v5 = {
	["Identifiers"] = {
		125278947519214,
		79960604279581,
		103275707113955,
		118390573943285
	},
	["Properties"] = {
		["RollOffMode"] = Enum.RollOffMode.InverseTapered,
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 8,
		["Volume"] = 0.65
	}
}
v2["Zombie Attack"] = v5
local v6 = {
	["Identifiers"] = { 17651838635 },
	["Properties"] = {
		["RollOffMode"] = Enum.RollOffMode.InverseTapered,
		["RollOffMaxDistance"] = 45,
		["RollOffMinDistance"] = 5,
		["Volume"] = 0.18,
		["Looped"] = true
	}
}
v2["Generator Hum"] = v6
local v7 = {
	["Identifiers"] = { 17651840629 },
	["Properties"] = {
		["RollOffMaxDistance"] = 220,
		["RollOffMinDistance"] = 15,
		["Volume"] = 1
	}
}
v2["Generator Destroyed"] = v7
local v8 = {
	["Identifiers"] = { 84287180554352, 126580242242107, 99594419304288 },
	["Properties"] = {
		["RollOffMode"] = Enum.RollOffMode.InverseTapered,
		["RollOffMaxDistance"] = 85,
		["RollOffMinDistance"] = 8,
		["Volume"] = 0.5
	}
}
v2["Generator Hit"] = v8
local v9 = {
	["Identifiers"] = { 79873000109115, 102584329392475, 120727679421473 },
	["Properties"] = {
		["RollOffMode"] = Enum.RollOffMode.InverseTapered,
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 8,
		["Volume"] = 0.6
	}
}
v2["Buy Station Glitch"] = v9
local v10 = {
	["Identifiers"] = { 98820262583245 },
	["Properties"] = {
		["RollOffMaxDistance"] = 140,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1.1,
		["Pitch"] = 0.75
	}
}
v2["Buy Station Depart"] = v10
local v11 = {
	["Identifiers"] = { 98820262583245 },
	["Properties"] = {
		["RollOffMaxDistance"] = 140,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1.2
	}
}
v2["Buy Station Arrive"] = v11
local v12 = {
	["Identifiers"] = { 92363036217037 },
	["Properties"] = {
		["Volume"] = 0.35,
		["Looped"] = true
	}
}
v2.Music = v12
local v13 = {
	["Identifiers"] = { 75047663774558 },
	["Properties"] = {
		["Volume"] = 0.8
	}
}
v2["Wave Incoming"] = v13
local v14 = {
	["Identifiers"] = { 135063738424928 },
	["Properties"] = {
		["Volume"] = 0.8
	}
}
v2["Wave Survived"] = v14
local v15 = {
	["Identifiers"] = { 9126072453 },
	["Properties"] = {
		["RollOffMode"] = Enum.RollOffMode.InverseTapered,
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 25,
		["Volume"] = 1.2
	}
}
v2["Candy Burst"] = v15
local v16 = {
	["Identifiers"] = { 9126073644 },
	["Properties"] = {
		["RollOffMode"] = Enum.RollOffMode.InverseTapered,
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 25,
		["Volume"] = 1.1
	}
}
v2["Candy Piece"] = v16
local v17 = {
	["Identifiers"] = { 15675012262 },
	["Properties"] = {
		["Volume"] = 0.6
	}
}
v2["Candy Vacuum"] = v17
local v18 = {
	["Identifiers"] = { 15675059323 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["Candy Collect"] = v18
return v1(v2)
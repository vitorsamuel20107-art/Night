-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.SSG 08
-- ModuleScript | 66 linhas | 1261 bytes | hash a5acb7bc

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 96164445933231 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagOut = v3
local v4 = {
	["Identifiers"] = { 100762793621431 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagIn = v4
local v5 = {
	["Identifiers"] = { 90890357500954 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltForward = v5
local v6 = {
	["Identifiers"] = { 84102205569613 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltBack = v6
local v7 = {
	["Identifiers"] = { 97398089915476 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v7
local v8 = {
	["Identifiers"] = { 112272409157787 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 40,
		["Volume"] = 0.85
	}
}
v2.Shoot = v8
local v9 = {
	["Identifiers"] = { 97529947502311 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Tap = v9
return v1(v2)
-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.SG 553
-- ModuleScript | 57 linhas | 1109 bytes | hash 7f89d7ee

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 130554583484724, 72722920866979 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 40,
		["Volume"] = 0.85
	}
}
v2.Shoot = v3
local v4 = {
	["Identifiers"] = { 133928408144506 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagOut = v4
local v5 = {
	["Identifiers"] = { 102301183576093 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagIn = v5
local v6 = {
	["Identifiers"] = { 85820586372381 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltForward = v6
local v7 = {
	["Identifiers"] = { 81874359340168 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltBack = v7
local v8 = {
	["Identifiers"] = { 92786183257964 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v8
return v1(v2)
-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.R8 Revolver
-- ModuleScript | 75 linhas | 1469 bytes | hash fd8d8929

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 80736804225662 },
	["Properties"] = {
		["RollOffMaxDistance"] = 60,
		["RollOffMinDistance"] = 10,
		["Volume"] = 2
	}
}
v2.Equip = v3
local v4 = {
	["Identifiers"] = { 94494496016800 },
	["Properties"] = {
		["RollOffMaxDistance"] = 60,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagIn = v4
local v5 = {
	["Identifiers"] = { 83310300941485 },
	["Properties"] = {
		["RollOffMaxDistance"] = 60,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagOut = v5
local v6 = {
	["Identifiers"] = { 110142001427374 },
	["Properties"] = {
		["RollOffMaxDistance"] = 40,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.SideIn = v6
local v7 = {
	["Identifiers"] = { 132574937025510 },
	["Properties"] = {
		["RollOffMaxDistance"] = 40,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.SideRelease = v7
local v8 = {
	["Identifiers"] = { 123733015335413, 103607891868774, 73516335461374 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 35,
		["Volume"] = 0.9
	}
}
v2.Shoot = v8
local v9 = {
	["Identifiers"] = { 114472444034537 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 35,
		["Volume"] = 0.9
	}
}
v2.Hammer = v9
local v10 = {
	["Identifiers"] = { 86307159825026 },
	["Properties"] = {
		["RollOffMaxDistance"] = 30,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Prepare = v10
return v1(v2)
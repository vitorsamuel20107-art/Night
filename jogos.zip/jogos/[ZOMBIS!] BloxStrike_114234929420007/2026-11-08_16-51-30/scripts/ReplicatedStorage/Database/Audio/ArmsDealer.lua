-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.ArmsDealer
-- ModuleScript | 227 linhas | 3777 bytes | hash 26732283

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 83784843438214 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Open 1"] = v3
local v4 = {
	["Identifiers"] = { 98790265203165 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Open 3"] = v4
local v5 = {
	["Identifiers"] = { 88272495459107 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Open 4"] = v5
local v6 = {
	["Identifiers"] = { 74697823020815 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Open 5"] = v6
local v7 = {
	["Identifiers"] = { 71653300860732 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Open 6"] = v7
local v8 = {
	["Identifiers"] = { 137928749668582 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Blue 1"] = v8
local v9 = {
	["Identifiers"] = { 109885756116522 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Blue 2"] = v9
local v10 = {
	["Identifiers"] = { 113620090187082 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Purple 2"] = v10
local v11 = {
	["Identifiers"] = { 87694706582785 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Pink 1"] = v11
local v12 = {
	["Identifiers"] = { 87118573803632 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Pink 2"] = v12
local v13 = {
	["Identifiers"] = { 76006526162497 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Red 1"] = v13
local v14 = {
	["Identifiers"] = { 110026755943000 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Red 2"] = v14
local v15 = {
	["Identifiers"] = { 81201326843458 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Gold 1"] = v15
local v16 = {
	["Identifiers"] = { 71722248343771 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Gold 3"] = v16
local v17 = {
	["Identifiers"] = { 79286539611874 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Purchase 1"] = v17
local v18 = {
	["Identifiers"] = { 97469251711564 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Purchase 3"] = v18
local v19 = {
	["Identifiers"] = { 74711209048661 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Purchase 4"] = v19
local v20 = {
	["Identifiers"] = { 127941415082968 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Purchase 5"] = v20
local v21 = {
	["Identifiers"] = { 126668136075373 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Purchase 6"] = v21
local v22 = {
	["Identifiers"] = { 70483060330147 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Declined 1"] = v22
local v23 = {
	["Identifiers"] = { 79659680666014 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Declined 2"] = v23
local v24 = {
	["Identifiers"] = { 85952359766093 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Declined 3"] = v24
local v25 = {
	["Identifiers"] = { 118817211824941 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Declined 5"] = v25
local v26 = {
	["Identifiers"] = { 118589137824364 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Refresh 1"] = v26
local v27 = {
	["Identifiers"] = { 114417795379125 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Refresh 2"] = v27
local v28 = {
	["Identifiers"] = { 137361925270759 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Refresh 3"] = v28
local v29 = {
	["Identifiers"] = { 97936190208247 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Refresh 4"] = v29
local v30 = {
	["Identifiers"] = { 112269907916840 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Refresh 5"] = v30
local v31 = {
	["Identifiers"] = { 105230581706812 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Refresh 6"] = v31
local v32 = {
	["Identifiers"] = { 126114785207573 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Discontinued 1"] = v32
local v33 = {
	["Identifiers"] = { 123592995001713 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Discontinued 2"] = v33
local v34 = {
	["Identifiers"] = { 99448227060185 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Discontinued 3"] = v34
return v1(v2)
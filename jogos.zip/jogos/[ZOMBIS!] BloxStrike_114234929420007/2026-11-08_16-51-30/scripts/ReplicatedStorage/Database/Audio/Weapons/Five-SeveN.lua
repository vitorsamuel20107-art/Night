-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.Five-SeveN
-- ModuleScript | 57 linhas | 1088 bytes | hash cce523f0

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 135351886962120 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagOut = v3
local v4 = {
	["Identifiers"] = { 94284126936572 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagIn = v4
local v5 = {
	["Identifiers"] = { 106888117322797 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltRelease = v5
local v6 = {
	["Identifiers"] = { 88655570604142 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.PullBack = v6
local v7 = {
	["Identifiers"] = { 73961652856125 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v7
local v8 = {
	["Identifiers"] = { 128045874478319 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 35,
		["Volume"] = 0.85
	}
}
v2.Shoot = v8
return v1(v2)
-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Interface
-- ModuleScript | 169 linhas | 2986 bytes | hash f059f28c

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 100963371018337 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["Countdown Timer"] = v3
local v4 = {
	["Identifiers"] = { 72315850035802 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["UI Settings Click"] = v4
local v5 = {
	["Identifiers"] = { 111207632919524 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["UI Inventory Click"] = v5
local v6 = {
	["Identifiers"] = { 91816417148938 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["UI Play Click"] = v6
local v7 = {
	["Identifiers"] = { 93054950840645 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["UI Dashboard Click"] = v7
local v8 = {
	["Identifiers"] = { 86919772875161 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["UI Loadout Click"] = v8
local v9 = {
	["Identifiers"] = { 86919772875161 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["UI Store Click"] = v9
local v10 = {
	["Identifiers"] = { 86919772875161 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["UI Gamemodes Click"] = v10
local v11 = {
	["Identifiers"] = { 128542537508033 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["UI Highlight"] = v11
local v12 = {
	["Identifiers"] = { 86919772875161 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["UI Click"] = v12
local v13 = {
	["Identifiers"] = { 134998174688363 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["Successful Buy Menu Purchase"] = v13
local v14 = {
	["Identifiers"] = {
		118300411050031,
		119808895784111,
		70390929498223,
		126483742517495
	},
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["Halloween Wheel Tick"] = v14
local v15 = {
	["Identifiers"] = { 92737314376950 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["New Item Reveal"] = v15
local v16 = {
	["Identifiers"] = { 139279533555596 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["TradeUp Contract Slide"] = v16
local v17 = {
	["Identifiers"] = { 105067129475591 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["TradeUp Approved"] = v17
local v18 = {
	["Identifiers"] = { 99439656617348 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["TradeUp Type 1"] = v18
local v19 = {
	["Identifiers"] = { 106193435474495 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["TradeUp Type 2"] = v19
local v20 = {
	["Identifiers"] = { 90998900151715 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["TradeUp Type 3"] = v20
local v21 = {
	["Identifiers"] = { 84091803404257 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["Notification Error"] = v21
local v22 = {
	["Identifiers"] = { 98360775959854 },
	["Properties"] = {
		["Volume"] = 0.5
	}
}
v2["Notification Success"] = v22
local v23 = {
	["Identifiers"] = { 89062677258924 },
	["Properties"] = {
		["Volume"] = 3
	}
}
v2["Mission Completed"] = v23
local v24 = {
	["Identifiers"] = { 119205674023715 },
	["Properties"] = {
		["Volume"] = 0.75
	}
}
v2["XP Bar Fill"] = v24
local v25 = {
	["Identifiers"] = { 0 },
	["Properties"] = {
		["Volume"] = 0.75
	}
}
v2["Level Up"] = v25
return v1(v2)
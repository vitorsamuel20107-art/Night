-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Character
-- ModuleScript | 44 linhas | 881 bytes | hash b33cba11

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 96077875667242 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 2,
		["Volume"] = 1
	}
}
v2["Fall Damage"] = v3
local v4 = {
	["Identifiers"] = { 79494830572923 },
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 2.25
	}
}
v2["Character Killed"] = v4
local v5 = {
	["Identifiers"] = { 94141667493613, 75636280774479, 73096326509225 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["Character Death Grunt"] = v5
local v6 = {
	["Identifiers"] = {
		99240460301381,
		101859383657555,
		139730338159040,
		72794099968301
	},
	["Properties"] = {
		["RollOffMaxDistance"] = 90,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2["Character Damaged"] = v6
return v1(v2)
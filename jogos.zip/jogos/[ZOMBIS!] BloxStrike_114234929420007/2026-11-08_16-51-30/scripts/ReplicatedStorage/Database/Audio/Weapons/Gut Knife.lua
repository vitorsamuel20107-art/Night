-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.Gut Knife
-- ModuleScript | 66 linhas | 1268 bytes | hash 5cc93f64

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 112957806482618 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Equip = v3
local v4 = {
	["Identifiers"] = { 129823041185142 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.HitOne = v4
local v5 = {
	["Identifiers"] = { 102883547697009 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.HitTwo = v5
local v6 = {
	["Identifiers"] = { 107100833141403 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.HitThree = v6
local v7 = {
	["Identifiers"] = { 139973941520045 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BackStab = v7
local v8 = {
	["Identifiers"] = { 139735742874575 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Inspect = v8
local v9 = {
	["Identifiers"] = { 104913414188509 },
	["Properties"] = {
		["RollOffMaxDistance"] = 50,
		["RollOffMinDistance"] = 10,
		["Volume"] = 0.9
	}
}
v2.Handling2 = v9
return v1(v2)
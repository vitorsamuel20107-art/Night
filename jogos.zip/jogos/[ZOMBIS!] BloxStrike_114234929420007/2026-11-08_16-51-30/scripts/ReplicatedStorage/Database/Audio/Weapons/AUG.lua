-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Weapons.AUG
-- ModuleScript | 66 linhas | 1265 bytes | hash bd0aa246

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 113134515321338 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagOut = v3
local v4 = {
	["Identifiers"] = { 117121194499994 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.MagIn = v4
local v5 = {
	["Identifiers"] = { 133614806361216 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Tap = v5
local v6 = {
	["Identifiers"] = { 80842335543779 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltPull = v6
local v7 = {
	["Identifiers"] = { 122184930621285 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.BoltRelease = v7
local v8 = {
	["Identifiers"] = { 130930590102592 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 10,
		["Volume"] = 1
	}
}
v2.Equip = v8
local v9 = {
	["Identifiers"] = { 110239422771918 },
	["Properties"] = {
		["RollOffMaxDistance"] = 300,
		["RollOffMinDistance"] = 40,
		["Volume"] = 0.85
	}
}
v2.Shoot = v9
return v1(v2)
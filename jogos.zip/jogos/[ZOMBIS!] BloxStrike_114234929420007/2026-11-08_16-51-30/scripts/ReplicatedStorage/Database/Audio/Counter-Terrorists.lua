-- NIGHT Analyzer | ReplicatedStorage.Database.Audio.Counter-Terrorists
-- ModuleScript | 111 linhas | 2270 bytes | hash 7119e434

local v1 = table.freeze
local v2 = {}
local v3 = {
	["Identifiers"] = { 101586878683210 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Hostage Rescue In Progress"] = v3
local v4 = {
	["Identifiers"] = { 81686027478887 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Hostage Dropped"] = v4
local v5 = {
	["Identifiers"] = { 77421233475337 },
	["Properties"] = {
		["Volume"] = 1
	}
}
v2["Hostage Rescued"] = v5
local v6 = {
	["Identifiers"] = { 108771688148602 },
	["Properties"] = {
		["Volume"] = 1.3
	}
}
v2["Bomb Planted"] = v6
local v7 = {
	["Identifiers"] = { 107497407873326 },
	["Properties"] = {
		["RollOffMaxDistance"] = 0,
		["RollOffMinDistance"] = 0,
		["Volume"] = 0.22,
		["Looped"] = false
	}
}
v2["Bomb Planted Music"] = v7
local v8 = {
	["Identifiers"] = { 129335569065669 },
	["Properties"] = {
		["Volume"] = 1.3
	}
}
v2["Bomb Defused"] = v8
local v9 = {
	["Identifiers"] = { 135379143040468, 84285453336239 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 25,
		["Volume"] = 1
	}
}
v2["Throwing Smoke Grenade"] = v9
local v10 = {
	["Identifiers"] = { 91021017124685, 104534030742266 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 25,
		["Volume"] = 1
	}
}
v2["Throwing Flashbang"] = v10
local v11 = {
	["Identifiers"] = { 115884192706975, 126592229993563 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 25,
		["Volume"] = 1
	}
}
v2["Throwing HE Grenade"] = v11
local v12 = {
	["Identifiers"] = { 118084208137962 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 25,
		["Volume"] = 1
	}
}
v2["Throwing Incendiary Grenade"] = v12
local v13 = {
	["Identifiers"] = { 83666590558608 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 25,
		["Volume"] = 1
	}
}
v2["Throwing Molotov"] = v13
local v14 = {
	["Identifiers"] = { 97340126821311, 88715148224021 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 25,
		["Volume"] = 1
	}
}
v2["Throwing Decoy Grenade"] = v14
local v15 = {
	["Identifiers"] = { 79494830572923 },
	["Properties"] = {
		["RollOffMaxDistance"] = 120,
		["RollOffMinDistance"] = 25,
		["Volume"] = 1.1
	}
}
v2.Death = v15
return v1(v2)
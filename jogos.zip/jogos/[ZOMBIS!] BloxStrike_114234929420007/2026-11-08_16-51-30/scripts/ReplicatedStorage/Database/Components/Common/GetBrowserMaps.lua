-- NIGHT Analyzer | ReplicatedStorage.Database.Components.Common.GetBrowserMaps
-- ModuleScript | 24 linhas | 661 bytes | hash 9c324e75

local v_u_1 = game:GetService("ReplicatedStorage").Database.Custom.GameStats
local v_u_2 = table.freeze({ "Casual", "Competitive", "Deathmatch" })
return function()
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v3 = {}
	for _, v4 in v_u_2 do
		for _, v5 in require((v_u_1.Gamemodes:FindFirstChild(v4))).Maps do
			if table.find(v3, v5) then
				continue
			end
			local v6 = v_u_1.Maps:FindFirstChild(v5)
			if not (v6 and v6:IsA("ModuleScript")) then
				continue
			end
			local v7 = require
			local v8, v9 = pcall(v7, v6)
			if v8 and (typeof(v9) == "table" and v9.Hidden == true) then
				continue
			end
			table.insert(v3, v5)
		end
	end
	return v3
end
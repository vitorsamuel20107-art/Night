-- NIGHT Analyzer | ReplicatedStorage.Database.Components.Libraries.Skins
-- ModuleScript | 1035 linhas | 25974 bytes | hash b6f1d739

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("HttpService")
local v_u_4 = game:GetService("Players")
require(v_u_2.Database.Custom.Types)
require(script:WaitForChild("Types"))
local v_u_5 = require(v_u_2.Components.Common.GetWeaponProperties)
local v_u_6 = nil
local v7 = require(v_u_2.Packages.Signal)
local v_u_8 = v_u_2:WaitForChild("Assets")
local v_u_9 = v_u_8:WaitForChild("Weapons")
local v_u_10 = v_u_8:WaitForChild("Skins")
local v_u_11 = v7.new()
v_u_1.OnItemStockSchemasUpdated = v_u_11
local v_u_12 = {}
local v_u_13 = {}
local v_u_14 = {
	{
		["max"] = 0.07,
		["wear"] = "Factory New"
	},
	{
		["max"] = 0.15,
		["wear"] = "Minimal Wear"
	},
	{
		["max"] = 0.38,
		["wear"] = "Field-Tested"
	},
	{
		["max"] = 0.45,
		["wear"] = "Well-Worn"
	},
	{
		["max"] = 1,
		["wear"] = "Battle-Scarred"
	}
}
local v_u_15 = table.freeze({
	["Weapon"] = true,
	["WeaponL"] = true,
	["WeaponR"] = true,
	["CharmBase"] = true,
	["KillTrak"] = true,
	["KillTrackKnife"] = true,
	["NamePlate"] = true
})
local v_u_16 = table.freeze({
	["ScopeSplit"] = true,
	["Lighter"] = true,
	["Ammo"] = true,
	["Bullet"] = true,
	["Shell"] = true,
	["EmptyShell"] = true,
	["ReadyShell"] = true,
	["Casing"] = true,
	["Speedloader"] = true,
	["RigPoints"] = true,
	["ViewmodelLight"] = true
})
local v_u_17 = {
	["Factory New"] = "Mint Condition",
	["Minimal Wear"] = "Near-Mint",
	["Field-Tested"] = "Standard-Grade",
	["Well-Worn"] = "Combat-Worn",
	["Battle-Scarred"] = "War-Torn"
}
local function v_u_26(p18) -- name: ResolveCharmFromId
	-- upvalues: (ref) v_u_6, (copy) v_u_2, (copy) v_u_4
	if not v_u_6 then
		local function v19()
			-- upvalues: (ref) v_u_2
			return require(v_u_2.Controllers.DataController)
		end
		local v20, v21 = pcall(v19)
		if v20 then
			v_u_6 = v21
		end
	end
	local v22 = v_u_6
	if not v22 then
		return nil
	end
	local v23 = v_u_4.LocalPlayer
	if not v23 then
		return nil
	end
	local v24 = v22.Get(v23, "Inventory")
	if not v24 or typeof(v24) ~= "table" then
		return nil
	end
	for _, v25 in ipairs(v24) do
		if v25._id ~= p18 or v25.Type ~= "Charm" then
			continue
		end
		return {
			["Skin"] = v25.Skin,
			["Pattern"] = v25.Pattern
		}
	end
	return nil
end
local function v_u_29(p27) -- name: CreateSyntheticStockSchema
	-- upvalues: (copy) v_u_5
	local v28 = v_u_5(p27)
	return v28 and {
		["paintId"] = "stock",
		["type"] = nil,
		["name"] = nil,
		["skin"] = "Stock",
		["rarity"] = "Stock",
		["floatRange"] = nil,
		["floatChances"] = nil,
		["charmImages"] = nil,
		["wearImages"] = nil,
		["supportsStatTrak"] = false,
		["statTrakChance"] = 0,
		["isEnabled"] = true,
		["isMarketplaceVisible"] = false,
		["collection"] = nil,
		["description"] = "Standard issue finish.",
		["caseRarity"] = "Stock",
		["imageAssetId"] = nil,
		["type"] = v28.Class,
		["name"] = p27,
		["floatRange"] = {
			["min"] = 0,
			["max"] = 0.07
		},
		["floatChances"] = {
			{
				["wear"] = "Factory New",
				["chance"] = 100
			}
		},
		["charmImages"] = {},
		["wearImages"] = {},
		["imageAssetId"] = v28.Icon or v28.ReverseIcon
	} or nil
end
local function v_u_41(p30, p31) -- name: GetKillTrackValue
	-- upvalues: (copy) v_u_5
	local v32 = p30 or 0
	local v33 = typeof(v32) == "number"
	assert(v33, "KillCount must be a number")
	local v34 = v_u_5
	local v35, v36 = pcall(v34, p31)
	if v35 and v36 then
		if v36.Class == "Melee" then
			local v37 = math.floor(v32)
			local v38 = math.clamp(v37, 0, 9999)
			return tostring(v38)
		else
			local v39 = string.format
			local v40 = math.floor(v32)
			return v39("%06d", (math.clamp(v40, 0, 999999)))
		end
	else
		return nil
	end
end
local function v_u_48(p42, p43, p44) -- name: GetSkinTextureFolder
	-- upvalues: (copy) v_u_10
	local v45 = v_u_10:FindFirstChild(p42)
	if v45 then
		if p44 and p42 == "Smoke Grenade" then
			local v46 = v45:FindFirstChild(p44)
			if v46 and v46:IsA("Folder") then
				return v46
			end
		end
		local v47 = v45:FindFirstChild(p43)
		if v47 and v47:IsA("Folder") then
			return v47
		else
			return nil
		end
	else
		return nil
	end
end
local function v_u_58(p49, p50) -- name: GetWearFromFloat
	-- upvalues: (copy) v_u_14, (copy) v_u_17
	local v51 = p49.floatRange.min
	local v52 = p49.floatRange.max - 1e-12
	local v53 = math.max(v51, v52)
	local v54 = p49.floatRange.min
	local v55 = math.clamp(p50, v54, v53)
	local v56 = math.clamp(v55, 0, 1)
	for _, v57 in ipairs(v_u_14) do
		if v56 >= v57.max then
			continue
		end
		return v57.wear, v_u_17[v57.wear]
	end
	return "Battle-Scarred", "War-Torn"
end
local function v_u_65(p59, p60, p61) -- name: GetWearTextureFolder
	-- upvalues: (copy) v_u_58, (copy) v_u_14
	if not (p59 and p59:IsA("Folder")) then
		return nil
	end
	local v62 = v_u_58(p60, p61)
	if v62 then
		v62 = p59:FindFirstChild(v62)
	end
	if v62 and v62:IsA("Folder") then
		return v62
	end
	for _, v63 in ipairs(v_u_14) do
		local v64 = p59:FindFirstChild(v63.wear)
		if not (v64 and v64:IsA("Folder")) then
			continue
		end
		return v64
	end
	return nil
end
local function v_u_71(p66, p67) -- name: ApplySkinTextures
	if p67 then
		for _, v68 in ipairs(p67:GetChildren()) do
			if not v68:IsA("SurfaceAppearance") then
				continue
			end
			for _, v69 in ipairs(p66:GetDescendants()) do
				if not v69:IsA("MeshPart") or v69.Name ~= v68.Name then
					continue
				end
				local v70 = v69:FindFirstChildOfClass("SurfaceAppearance")
				if v70 then
					v70:Destroy()
				end
				v68:Clone().Parent = v69
			end
		end
	end
end
local function v_u_77(p72, p73, ...) -- name: ForEachWeaponPart
	local v74 = p72:FindFirstChild("Weapon")
	if v74 then
		p73(p72, v74, ...)
	else
		local v75 = p72:FindFirstChild("WeaponL")
		local v76 = p72:FindFirstChild("WeaponR")
		if v75 then
			p73(p72, v75, ...)
		end
		if v76 then
			p73(p72, v76, ...)
		end
	end
end
local function v_u_93(p78, p79, p80, p81, p82) -- name: AttachStatTrakToWeapon
	-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_41
	local v83 = v_u_5
	local v84, v85 = pcall(v83, p81)
	local v86 = v84 and (v85 and v85.Class == "Melee") and "KillTrackKnife" or "KillTrak"
	local v87 = v_u_8.Other[v86]:Clone()
	local v88 = p79.PrimaryPart
	local v89
	if v88 then
		v89 = p79:FindFirstChild("KillTrack", true)
	else
		v89 = v88
	end
	if v89 then
		local v90 = v87.PrimaryPart
		local v91 = Instance.new("WeldConstraint")
		v91.Part0 = v90
		v91.Part1 = v88
		v91.Parent = v90
		v87:PivotTo(v89.WorldCFrame)
		local v92 = v87.Screen.SurfaceGui
		v92.TextLabel.Text = v_u_41(p80, p81)
		if p82 then
			v92.SizingMode = Enum.SurfaceGuiSizingMode.FixedSize
			v92.CanvasSize = Vector2.new(100, 25)
			v92.TextLabel.TextSize = 29
			v92.TextLabel.Size = UDim2.fromScale(1, 1)
		end
		v87.Parent = p78
	else
		v87:Destroy()
	end
end
local function v_u_104(p94, p95, p96, p97) -- name: AttachNameTagToWeapon
	-- upvalues: (copy) v_u_8
	local v98 = v_u_8.Other.NamePlate:Clone()
	local v99 = p95.PrimaryPart
	local v100
	if v99 then
		v100 = v99:FindFirstChild("Nametag")
	else
		v100 = v99
	end
	if v100 then
		local v101 = v98.PrimaryPart
		local v102 = Instance.new("WeldConstraint")
		v102.Part0 = v101
		v102.Part1 = v99
		v102.Parent = v101
		v98:PivotTo(v100.WorldCFrame)
		local v103 = v98.Screen.SurfaceGui
		v103.TextLabel.Text = tostring(p96)
		if p97 then
			v103.SizingMode = Enum.SurfaceGuiSizingMode.FixedSize
			v103.CanvasSize = Vector2.new(100, 8)
			v103.TextLabel.TextSize = 8.98
			v103.TextLabel.Size = UDim2.fromScale(0.95, 1)
			v103.TextLabel.Position = UDim2.fromOffset(5, 0)
		end
		v98.Parent = p94
	else
		v98:Destroy()
	end
end
local function v_u_110(p105, p106) -- name: FindCharmModels
	-- upvalues: (copy) v_u_8
	local v107 = v_u_8:FindFirstChild("Charms")
	local v108
	if v107 then
		v108 = v107:FindFirstChild("CharmBase")
	else
		v108 = v107
	end
	if v108 and v108:IsA("Model") then
		local v109 = v107:FindFirstChild(p105)
		if v109 then
			v109 = v109:FindFirstChild((tostring(p106)))
		end
		if v109 and v109:IsA("Model") then
			return v108, v109
		else
			return v108, nil
		end
	else
		return nil, nil
	end
end
local function v_u_117(p111, p112) -- name: MountSpecificCharm
	local v113 = p112:Clone()
	v113.Parent = p111
	local v114 = p111:FindFirstChild("Part")
	if v114 and v114:IsA("BasePart") then
		v113:PivotTo(v114.CFrame)
		v114:Destroy()
	end
	local v115 = p111:FindFirstChild("HingeConstraint", true)
	local v116 = v115 and (v113.PrimaryPart and v113.PrimaryPart:FindFirstChild("Attachment"))
	if v116 then
		v115.Attachment1 = v116
	end
end
local function v_u_130(p118, p119, p120, p121, p122) -- name: AttachCharmToWeapon
	-- upvalues: (copy) v_u_110, (copy) v_u_117
	local v123, v124 = v_u_110(p119, p120)
	if v123 then
		if v124 then
			local v125 = p118:FindFirstChild("Charm" .. p121, true)
			if v125 then
				local v126 = v125.Parent
				if v126 and v126:IsA("BasePart") then
					local v127 = v123:Clone()
					v127.Parent = p118
					v127:PivotTo(v125.WorldCFrame)
					if v127.PrimaryPart then
						local v128 = v127.PrimaryPart
						local v129 = Instance.new("WeldConstraint")
						v129.Part0 = v128
						v129.Part1 = v126
						v129.Parent = v128
					end
					v_u_117(v127, v124)
				end
			else
				if not p122 then
					print("Charm attachment not found for weapon:", p118.Name, p121)
				end
				return
			end
		else
			if not p122 then
				warn("Specific charm not found for weapon:", p118.Name, p119, p120)
			end
			return
		end
	else
		if not p122 then
			warn("Charm base not found for weapon:", p118.Name)
		end
		return
	end
end
local function v_u_140(p131, p132, p133) -- name: AttachCharm
	-- upvalues: (copy) v_u_26, (copy) v_u_130
	if typeof(p132) == "table" then
		if p132._id and p132.Position then
			local v134 = p132.Position
			local v135, v136
			if p132.Skin and p132.Pattern then
				v135 = p132.Skin
				v136 = p132.Pattern
			else
				local v137 = v_u_26(p132._id)
				if not v137 then
					return
				end
				v135 = v137.Skin
				v136 = v137.Pattern
			end
			if v135 and v136 then
				if p131:FindFirstChild("Weapon") then
					v_u_130(p131, v135, v136, v134, p133)
				else
					local v138 = p131:FindFirstChild("WeaponL")
					local v139 = p131:FindFirstChild("WeaponR")
					if v138 then
						v_u_130(p131, v135, v136, v134, p133)
					end
					if p133 and v139 then
						v_u_130(p131, v135, v136, v134, p133)
					end
				end
			else
				return
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_150(p141, p142, p143, p144, p145, p146, p147, p148, p149) -- name: DecorateModel
	-- upvalues: (copy) v_u_71, (copy) v_u_65, (copy) v_u_77, (copy) v_u_93, (copy) v_u_104, (copy) v_u_140
	v_u_71(p141, (v_u_65(p142, p143, p144 or p143.floatRange.max)))
	if p146 then
		v_u_77(p141, v_u_93, p146, p145, p149)
	end
	if p147 then
		v_u_77(p141, v_u_104, p147, p149)
	end
	if p148 then
		v_u_140(p141, p148, p149)
	end
	return p141
end
function v_u_1.GetCharmModel(p151, p152) -- name: GetCharmModel
	-- upvalues: (copy) v_u_110, (copy) v_u_117
	local v153, v154 = v_u_110(p151, p152)
	if not v153 then
		warn((("Skins.GetCharmModel: Charm base not found for charm \"%*\" with pattern \"%*\""):format(p151, p152)))
		return nil
	end
	if not v154 then
		warn((("Skins.GetCharmModel: Specific charm not found for charm \"%*\" with pattern \"%*\""):format(p151, p152)))
		return nil
	end
	local v155 = v153:Clone()
	v155.Name = p151
	v_u_117(v155, v154)
	return v155
end
function v_u_1.GetBadgeModel(p156) -- name: GetBadgeModel
	-- upvalues: (copy) v_u_8
	local v157 = v_u_8:FindFirstChild("Badges")
	if not v157 then
		warn((("Skins.GetBadgeModel: Badges folder not found for badge \"%*\""):format(p156)))
		return nil
	end
	local v158 = v157:FindFirstChild(p156)
	if v158 and v158:IsA("Model") then
		return v158:Clone()
	end
	warn((("Skins.GetBadgeModel: Badge model not found for \"%*\""):format(p156)))
	return nil
end
function v_u_1.GetWearNameForFloat(p159, p160) -- name: GetWearNameForFloat
	-- upvalues: (copy) v_u_58
	return v_u_58(p159, p160)
end
function v_u_1.GetAbbreviatedWearName(p161) -- name: GetAbbreviatedWearName
	return string.gsub(p161, "[^A-Z]", "")
end
function v_u_1.ObserveItemStockSchemas(p162) -- name: ObserveItemStockSchemas
	-- upvalues: (copy) v_u_11, (ref) v_u_12
	local v_u_163 = v_u_11:Connect(p162)
	if next(v_u_12) ~= nil then
		p162(v_u_12)
	end
	return function()
		-- upvalues: (copy) v_u_163
		if v_u_163.Connected then
			v_u_163:Disconnect()
		end
	end
end
v_u_1.GetKillTrackValue = v_u_41
function v_u_1.GetMagazine(p164, p165, p166) -- name: GetMagazine
	-- upvalues: (copy) v_u_1, (ref) v_u_12, (copy) v_u_11, (copy) v_u_9, (copy) v_u_10, (copy) v_u_71, (copy) v_u_65
	local v167
	if typeof(p164) == "string" and (typeof(p165) == "string" and p164 ~= "") then
		v167 = p165 ~= ""
	else
		v167 = false
	end
	if not v167 then
		return nil
	end
	local v168 = v_u_1.GetSkinInformation(p164, p165)
	if not v168 and next(v_u_12) == nil then
		v_u_11:Wait()
		v168 = v_u_1.GetSkinInformation(p164, p165)
	end
	if not v168 then
		return nil
	end
	local v169 = v_u_9:FindFirstChild(p164)
	if not (v169 and v169:IsA("Folder")) then
		v169 = nil
	end
	if v169 then
		v169 = v169:FindFirstChild("Character")
	end
	if not (v169 and v169:IsA("Model")) then
		return nil
	end
	local v170 = {}
	for _, v171 in ipairs(v169:GetDescendants()) do
		if not (v171:IsA("BasePart") and v171:HasTag("CharacterMagazine")) then
			continue
		end
		table.insert(v170, v171)
	end
	if #v170 == 0 then
		return nil
	end
	local v172 = Instance.new("Model")
	v172.Name = "Magazine"
	for _, v173 in ipairs(v170) do
		local v174 = v173:Clone()
		v174.Parent = v172
		if v172.PrimaryPart then
			continue
		end
		v172.PrimaryPart = v174
	end
	local v175 = v_u_10:FindFirstChild(p164)
	local v176
	if v175 then
		v176 = v175:FindFirstChild(p165)
		if not (v176 and v176:IsA("Folder")) then
			v176 = nil
		end
	else
		v176 = nil
	end
	if v176 then
		v176 = v176:FindFirstChild("Character")
	end
	v_u_71(v172, (v_u_65(v176, v168, p166 or v168.floatRange.min)))
	return v172
end
local function v_u_183(p177, p178) -- name: GetGloveSourceParts
	local v179
	if p178 then
		v179 = p177:FindFirstChild("Character")
	else
		v179 = nil
	end
	local v180 = {}
	for _, v181 in ipairs(p177:GetChildren()) do
		if not v181:IsA("BasePart") then
			continue
		end
		local v182
		if v179 then
			v182 = v179:FindFirstChild(v181.Name)
		else
			v182 = v179
		end
		if v182 then
			if not v182:IsA("BasePart") then
				v182 = v181
			end
		else
			v182 = v181
		end
		table.insert(v180, v182)
	end
	return v180
end
local function v_u_195(p184, p185, p186, p187) -- name: BuildGloves
	-- upvalues: (copy) v_u_1, (ref) v_u_12, (copy) v_u_11, (copy) v_u_9, (copy) v_u_183, (copy) v_u_10, (copy) v_u_71, (copy) v_u_65
	local v188
	if typeof(p184) == "string" and (typeof(p185) == "string" and p184 ~= "") then
		v188 = p185 ~= ""
	else
		v188 = false
	end
	if not v188 then
		return nil
	end
	local v189 = v_u_1.GetSkinInformation(p184, p185)
	if not v189 and next(v_u_12) == nil then
		v_u_11:Wait()
		v189 = v_u_1.GetSkinInformation(p184, p185)
	end
	if not v189 then
		return nil
	end
	local v190 = v_u_9:FindFirstChild(p184)
	if not (v190 and v190:IsA("Folder")) then
		v190 = nil
	end
	if not v190 then
		return nil
	end
	local v191 = Instance.new("Model")
	v191.Name = p184
	for _, v192 in v_u_183(v190, p187) do
		v192:Clone().Parent = v191
	end
	local v193 = v_u_10:FindFirstChild(p184)
	local v194
	if v193 then
		v194 = v193:FindFirstChild(p185)
		if not (v194 and v194:IsA("Folder")) then
			v194 = nil
		end
	else
		v194 = nil
	end
	if v194 then
		v194 = v194:FindFirstChild("Camera")
	end
	v_u_71(v191, (v_u_65(v194, v189, p186 or v189.floatRange.min)))
	return v191
end
function v_u_1.GetGloves(p196, p197, p198) -- name: GetGloves
	-- upvalues: (copy) v_u_195
	return v_u_195(p196, p197, p198, false)
end
function v_u_1.GetCharacterGloves(p199, p200, p201) -- name: GetCharacterGloves
	-- upvalues: (copy) v_u_195
	return v_u_195(p199, p200, p201, true)
end
function v_u_1.GetCharacterGloveParts(p202) -- name: GetCharacterGloveParts
	-- upvalues: (copy) v_u_9, (copy) v_u_183
	local v203 = v_u_9:FindFirstChild(p202)
	if not (v203 and v203:IsA("Folder")) then
		v203 = nil
	end
	if v203 then
		return v_u_183(v203, true)
	else
		return nil
	end
end
function v_u_1.GetCharacterModel(p204, p205, p206, p207, p208, p209, _, p210) -- name: GetCharacterModel
	-- upvalues: (copy) v_u_1, (ref) v_u_12, (copy) v_u_11, (copy) v_u_9, (copy) v_u_48, (copy) v_u_150
	local v211
	if typeof(p204) == "string" and (typeof(p205) == "string" and p204 ~= "") then
		v211 = p205 ~= ""
	else
		v211 = false
	end
	if not v211 then
		return nil
	end
	local v212 = v_u_1.GetSkinInformation(p204, p205)
	if not v212 and next(v_u_12) == nil then
		v_u_11:Wait()
		v212 = v_u_1.GetSkinInformation(p204, p205)
	end
	if not v212 then
		warn((("SkinHandler.GetCharacterModel: Skin \"%*\" not found for weapon \"%*\""):format(p205, p204)))
		return nil
	end
	local v213 = v_u_9:FindFirstChild(p204)
	if not (v213 and v213:IsA("Folder")) then
		v213 = nil
	end
	if v213 then
		v213 = v213:FindFirstChild("Character")
	end
	if not (v213 and v213:IsA("Model")) then
		warn((("SkinHandler.GetCharacterModel: Base character model not found for weapon \"%*\""):format(p204)))
		return nil
	end
	local v214 = v213:Clone()
	local v215 = v_u_48(p204, p205, p210)
	if v215 then
		v215 = v215:FindFirstChild("Character")
	end
	return v_u_150(v214, v215, v212, p206, p204, p207, p208, p209, false)
end
function v_u_1.GetWorldModel(p216, p217, p218, p219, p220, p221, _) -- name: GetWorldModel
	-- upvalues: (copy) v_u_1, (ref) v_u_12, (copy) v_u_11, (copy) v_u_9, (copy) v_u_10, (copy) v_u_150
	local v222
	if typeof(p216) == "string" and (typeof(p217) == "string" and p216 ~= "") then
		v222 = p217 ~= ""
	else
		v222 = false
	end
	if not v222 then
		return nil
	end
	local v223 = v_u_1.GetSkinInformation(p216, p217)
	if not v223 and next(v_u_12) == nil then
		v_u_11:Wait()
		v223 = v_u_1.GetSkinInformation(p216, p217)
	end
	if not v223 then
		return nil
	end
	local v224 = v_u_9:FindFirstChild(p216)
	if not (v224 and v224:IsA("Folder")) then
		v224 = nil
	end
	if v224 then
		v224 = v224:FindFirstChild("Other")
	end
	if v224 then
		v224 = v224:FindFirstChild("World")
	end
	if not (v224 and v224:IsA("Model")) then
		return nil
	end
	local v225 = v224:Clone()
	local v226 = v_u_10:FindFirstChild(p216)
	local v227
	if v226 then
		v227 = v226:FindFirstChild(p217)
		if not (v227 and v227:IsA("Folder")) then
			v227 = nil
		end
	else
		v227 = nil
	end
	if v227 then
		v227 = v227:FindFirstChild("Character")
	end
	return v_u_150(v225, v227, v223, p218, p216, p219, p220, p221, false)
end
function v_u_1.GetCameraModel(p228, p229, p230, p231, p232, p233, _, p234) -- name: GetCameraModel
	-- upvalues: (copy) v_u_1, (ref) v_u_12, (copy) v_u_11, (copy) v_u_9, (copy) v_u_48, (copy) v_u_150
	local v235
	if typeof(p228) == "string" and (typeof(p229) == "string" and p228 ~= "") then
		v235 = p229 ~= ""
	else
		v235 = false
	end
	if not v235 then
		return nil
	end
	local v236 = v_u_1.GetSkinInformation(p228, p229)
	if not v236 and next(v_u_12) == nil then
		v_u_11:Wait()
		v236 = v_u_1.GetSkinInformation(p228, p229)
	end
	if not v236 then
		return nil
	end
	local v237 = v_u_9:FindFirstChild(p228)
	if not (v237 and v237:IsA("Folder")) then
		v237 = nil
	end
	if v237 then
		v237 = v237:FindFirstChild("Camera")
	end
	if not (v237 and v237:IsA("Model")) then
		return nil
	end
	local v238 = v237:Clone()
	local v239 = v_u_48(p228, p229, p234)
	if v239 then
		v239 = v239:FindFirstChild("Camera")
	end
	return v_u_150(v238, v239, v236, p230, p228, p231, p232, p233, true)
end
local function v_u_244(p240) -- name: GetSourceMeshPlacement
	local v241 = p240:GetAttribute("SourceMeshId")
	local v242 = p240:GetAttribute("SourceSize")
	local v243 = p240:GetAttribute("SourceOffset")
	if typeof(v241) ~= "string" then
		v241 = p240.MeshId
	end
	if typeof(v242) ~= "Vector3" then
		v242 = p240.Size
	end
	if typeof(v243) == "CFrame" then
		return v241, v242, p240.CFrame * v243
	else
		return v241, v242, p240.CFrame
	end
end
function v_u_1.GetInspectModel(p245, p246, p247, p248, p249, p250, p251) -- name: GetInspectModel
	-- upvalues: (copy) v_u_9, (copy) v_u_1, (copy) v_u_15, (copy) v_u_16, (copy) v_u_244
	local v252 = v_u_9:FindFirstChild(p245)
	if not (v252 and v252:IsA("Folder")) then
		v252 = nil
	end
	if v252 then
		v252 = v252:FindFirstChild("Character")
	end
	local v253
	if v252 and v252:IsA("Model") then
		v253 = v_u_1.GetCameraModel(p245, p246, p247, p248, p249, p250, p251)
	else
		v253 = nil
	end
	if not (v253 and (v252 and v252:IsA("Model"))) then
		return v_u_1.GetCharacterModel(p245, p246, p247, p248, p249, p250, p251)
	end
	local v254 = Instance.new("Model")
	v254.Name = p245
	for _, v255 in v253:GetChildren() do
		if not v_u_15[v255.Name] then
			continue
		end
		v255.Parent = v254
	end
	v253:Destroy()
	for _, v256 in v254:GetDescendants() do
		if not (v256.Parent and v_u_16[string.gsub(v256.Name, "%.%d+$", "")]) then
			continue
		end
		v256:Destroy()
	end
	local v257 = {}
	for _, v258 in v252:GetDescendants() do
		if not v258:IsA("MeshPart") then
			continue
		end
		v257[v_u_244(v258)] = v258
	end
	local v259 = CFrame.identity
	local v260 = Vector3.new(0, 0, 0)
	local v261 = nil
	for _, v262 in v254:GetDescendants() do
		local v263
		if v262:IsA("MeshPart") then
			v263 = v257[v262.MeshId]
		else
			v263 = nil
		end
		if not v263 then
			continue
		end
		local _, v264, v265 = v_u_244(v263)
		if v264.Magnitude <= v260.Magnitude then
			continue
		end
		v259 = v265
		v261 = v262
		v260 = v264
	end
	if not v261 then
		v254:Destroy()
		return v_u_1.GetCharacterModel(p245, p246, p247, p248, p249, p250, p251)
	end
	v254.WorldPivot = v261.CFrame
	v254:ScaleTo(v260.Magnitude / v261.Size.Magnitude)
	v254:PivotTo(v259)
	v254.WorldPivot = v252:GetPivot()
	local v266 = v252:FindFirstChild("InspectPivot", true)
	if v266 and v266:IsA("Attachment") then
		local v267 = Instance.new("Attachment")
		v267.Name = "InspectPivot"
		v267.Parent = v261
		v267.WorldCFrame = v266.WorldCFrame
	end
	return v254
end
function v_u_1.GetSkinInformation(p268, p269) -- name: GetSkinInformation
	-- upvalues: (ref) v_u_12, (copy) v_u_13, (copy) v_u_29
	local v270
	if typeof(p268) == "string" and (typeof(p269) == "string" and p268 ~= "") then
		v270 = p269 ~= ""
	else
		v270 = false
	end
	if not v270 then
		return nil
	end
	local v271 = v_u_12[p268]
	if v271 and v271[p269] then
		return v271[p269]
	end
	if p269 ~= "Stock" then
		return nil
	end
	local v272 = v_u_13[p268] or v_u_29(p268)
	v_u_13[p268] = v272
	return v272
end
function v_u_1.IsSkinAvailable(p273, p274) -- name: IsSkinAvailable
	-- upvalues: (copy) v_u_1, (copy) v_u_10
	local v275 = v_u_1.GetSkinInformation(p273, p274)
	if not v275 then
		return false
	end
	if v275.type ~= "Weapon" and (v275.type ~= "Melee" and (v275.type ~= "Glove" and v275.type ~= "Zeus x27")) then
		return true
	end
	local v276 = v_u_10:FindFirstChild(p273)
	if not (v276 and v276:IsA("Folder")) then
		return false
	end
	local v277 = v_u_10:FindFirstChild(p273)
	local v278
	if v277 then
		v278 = v277:FindFirstChild(p274)
		if not (v278 and v278:IsA("Folder")) then
			v278 = nil
		end
	else
		v278 = nil
	end
	return v278 ~= nil
end
function v_u_1.HasSkinTextures(p279, p280) -- name: HasSkinTextures
	-- upvalues: (copy) v_u_10
	local v281
	if typeof(p279) == "string" and (typeof(p280) == "string" and p279 ~= "") then
		v281 = p280 ~= ""
	else
		v281 = false
	end
	if not v281 then
		return false
	end
	local v282 = v_u_10:FindFirstChild(p279)
	if not (v282 and v282:IsA("Folder")) then
		return true
	end
	local v283 = v_u_10:FindFirstChild(p279)
	local v284
	if v283 then
		v284 = v283:FindFirstChild(p280)
		if not (v284 and v284:IsA("Folder")) then
			v284 = nil
		end
	else
		v284 = nil
	end
	return v284 ~= nil
end
function v_u_1.GetAllSkinsForWeapon(p285) -- name: GetAllSkinsForWeapon
	-- upvalues: (ref) v_u_12
	if typeof(p285) ~= "string" or p285 == "" then
		return nil
	end
	local v286 = v_u_12[p285]
	if not v286 then
		return nil
	end
	local v287 = {}
	for _, v288 in pairs(v286) do
		table.insert(v287, v288)
	end
	return v287
end
function v_u_1.GetWearImageForFloat(p289, p290) -- name: GetWearImageForFloat
	-- upvalues: (copy) v_u_58
	local v291 = v_u_58(p289, p290)
	if not v291 then
		return nil
	end
	for _, v292 in ipairs(p289.wearImages) do
		if v292.wear ~= v291 then
			continue
		end
		return v292.assetId
	end
	return nil
end
function v_u_1.GetItemIconImage(p293, p294) -- name: GetItemIconImage
	-- upvalues: (copy) v_u_1
	local v295
	if p294.Type == "Charm" or p294.Name == "Charm" then
		local v296 = p294.Pattern or 1
		for _, v297 in p293.charmImages or {} do
			if v297.pattern ~= v296 then
				continue
			end
			v295 = v297.assetId
		end
		v295 = nil
	else
		v295 = v_u_1.GetWearImageForFloat(p293, p294.Float or 0)
	end
	return v295 or p293.imageAssetId or ""
end
function v_u_1.GetBaseWeaponModel(p298, p299) -- name: GetBaseWeaponModel
	-- upvalues: (copy) v_u_9
	if typeof(p298) == "string" and p298 ~= "" then
		local v300 = v_u_9:FindFirstChild(p298)
		if not (v300 and v300:IsA("Folder")) then
			v300 = nil
		end
		if v300 then
			local v301 = v300:FindFirstChild(p299)
			if v301 and v301:IsA("Model") then
				return v301:Clone()
			else
				return nil
			end
		else
			return nil
		end
	else
		return nil
	end
end
local function v303() -- name: SyncAvailableSkins
	-- upvalues: (copy) v_u_2, (ref) v_u_12, (copy) v_u_3, (copy) v_u_11
	local v302 = v_u_2:GetAttribute("AvaiableSkins")
	if v302 then
		v_u_12 = v_u_3:JSONDecode(v302)
		if #v_u_11:GetConnections() > 0 then
			v_u_11:Fire(v_u_12)
		end
	end
end
local v304 = v_u_2:GetAttribute("AvaiableSkins")
if v304 then
	v_u_12 = v_u_3:JSONDecode(v304)
	if #v_u_11:GetConnections() > 0 then
		v_u_11:Fire(v_u_12)
	end
end
v_u_2:GetAttributeChangedSignal("AvaiableSkins"):Connect(v303)
return v_u_1
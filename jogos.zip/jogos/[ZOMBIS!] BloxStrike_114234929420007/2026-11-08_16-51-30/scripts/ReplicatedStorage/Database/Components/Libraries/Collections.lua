-- NIGHT Analyzer | ReplicatedStorage.Database.Components.Libraries.Collections
-- ModuleScript | 50 linhas | 1389 bytes | hash 5be2385c

local v1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("HttpService")
require(v_u_2.Database.Custom.Types)
local v_u_4 = require(v_u_2.Packages.Signal).new()
v1.OnAvailableCollectionsUpdated = v_u_4
local v_u_5 = {}
local v_u_6 = false
function v1.GetCollectionByName(p7) -- name: GetCollectionByName
	-- upvalues: (ref) v_u_5
	for _, v8 in ipairs(v_u_5) do
		if v8.name ~= p7 then
			continue
		end
		return v8
	end
	return nil
end
function v1.GetAllCollections() -- name: GetAllCollections
	-- upvalues: (ref) v_u_5
	return v_u_5
end
function v1.ObserveAvailableCollections(p9) -- name: ObserveAvailableCollections
	-- upvalues: (copy) v_u_4, (ref) v_u_6, (ref) v_u_5
	local v_u_10 = v_u_4:Connect(p9)
	if v_u_6 then
		p9(v_u_5)
	end
	return function()
		-- upvalues: (copy) v_u_10
		v_u_10:Disconnect()
	end
end
local function v12() -- name: SyncAvailableCollections
	-- upvalues: (copy) v_u_2, (ref) v_u_5, (copy) v_u_3, (ref) v_u_6, (copy) v_u_4
	local v11 = v_u_2:GetAttribute("AvailableCollections")
	if typeof(v11) == "string" then
		v_u_5 = v_u_3:JSONDecode(v11)
		v_u_6 = true
		v_u_4:Fire(v_u_5)
	end
end
local v13 = v_u_2:GetAttribute("AvailableCollections")
if typeof(v13) == "string" then
	v_u_5 = v_u_3:JSONDecode(v13)
	v_u_6 = true
	v_u_4:Fire(v_u_5)
end
v_u_2:GetAttributeChangedSignal("AvailableCollections"):Connect(v12)
return v1
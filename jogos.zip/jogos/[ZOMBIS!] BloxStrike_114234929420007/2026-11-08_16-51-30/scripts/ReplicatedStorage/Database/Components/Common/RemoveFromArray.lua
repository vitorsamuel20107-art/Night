-- NIGHT Analyzer | ReplicatedStorage.Database.Components.Common.RemoveFromArray
-- ModuleScript | 13 linhas | 204 bytes | hash 77c3d082

return function(p1, p2)
	local v3 = {}
	for v4 = 1, #p1 do
		if not p2(v4, p1[v4]) then
			continue
		end
		table.insert(v3, v4)
	end
	for v5 = #v3, 1, -1 do
		table.remove(p1, v3[v5])
	end
	return p1
end
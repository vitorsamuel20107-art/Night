-- NIGHT Analyzer | ReplicatedStorage.Database.Components.Common.IsInBuyArea
-- ModuleScript | 90 linhas | 2084 bytes | hash baedb58b

local v1 = game:GetService("CollectionService")
local v2 = game:GetService("ReplicatedStorage")
require(v2.Database.Custom.Types)
local v_u_3 = require(v2.Components.Common.CharacterResolver)
local v_u_4 = require(v2.Components.Common.TutorialPurchaseLock)
local v_u_5 = require(v2.Components.Common.IsSurvivalMode)
local v_u_6 = v1:GetTagged("BuyArea")
v1:GetInstanceAddedSignal("BuyArea"):Connect(function(p7)
	-- upvalues: (copy) v_u_6
	local v8 = v_u_6
	table.insert(v8, p7)
end)
v1:GetInstanceRemovedSignal("BuyArea"):Connect(function(p9)
	-- upvalues: (copy) v_u_6
	local v10 = table.find(v_u_6, p9)
	if v10 then
		table.remove(v_u_6, v10)
	end
end)
local function v_u_20(p11, p12) -- name: IsInTeamBuyArea
	-- upvalues: (copy) v_u_6
	for _, v13 in ipairs(v_u_6) do
		if v13:GetAttribute("Team") ~= p12 or not v13:IsDescendantOf(workspace) then
			continue
		end
		local v14 = v13.Size
		local v15 = v13.CFrame:PointToObjectSpace(p11)
		local v16 = v15.X
		local v17
		if math.abs(v16) <= v14.X / 2 then
			local v18 = v15.Y
			if math.abs(v18) <= v14.Y / 2 then
				local v19 = v15.Z
				v17 = math.abs(v19) <= v14.Z / 2
			else
				v17 = false
			end
		else
			v17 = false
		end
		if not v17 then
			continue
		end
		return true
	end
	return false
end
return function(p21, p22)
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_20, (copy) v_u_3
	if workspace:GetAttribute("Gamemode") == "Deathmatch" or v_u_5() then
		return true
	end
	if v_u_4.getRequiredItems(p21) ~= nil then
		return true
	end
	local v23 = p21:GetAttribute("Team")
	if not p21:IsA("Player") then
		local v24
		if p22 then
			v24 = p22(p21)
		else
			v24 = nil
		end
		local v25
		if v24 == nil then
			v25 = false
		else
			v25 = v_u_20(v24, v23)
		end
		return v25
	end
	local v26 = p21.Character
	if not (v26 and v26:IsDescendantOf(workspace)) then
		return false
	end
	local v27
	if p22 then
		v27 = p22(p21)
	else
		v27 = nil
	end
	if not v27 then
		local v28 = v26.PrimaryPart or v_u_3.getRootPart(v26)
		if not v28 then
			return false
		end
		v27 = v28.Position
	end
	return v_u_20(v27, v23)
end
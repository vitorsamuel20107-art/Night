-- NIGHT Analyzer | ReplicatedStorage.Database.Components.Finishers
-- ModuleScript | 126 linhas | 4127 bytes | hash 177168e5

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Players")
require(v_u_2.Database.Custom.Types)
local v_u_4 = require(v_u_2.Components.Common.CharacterGeneration)
local v_u_5 = require(v_u_2.Components.Common.ClientCharacterPresentation)
local v_u_6 = require(v_u_2.Components.Common.IsTutorialMode)
local v_u_7 = v_u_3.LocalPlayer
local v_u_8 = {}
local v_u_9 = {}
local v_u_10 = {}
local function v_u_15(p11) -- name: findTutorialDummy
	-- upvalues: (copy) v_u_6
	if not v_u_6() then
		return nil
	end
	for _, v12 in workspace:GetChildren() do
		if v12.Name ~= "Debris" then
			if not v12:IsA("Folder") then
				continue
			end
			local v13 = v12.Name
			if string.sub(v13, 1, 8) ~= "Tutorial" then
				continue
			end
		end
		for _, v14 in v12:GetChildren() do
			if not v14:IsA("Model") or (v14:GetAttribute("TutorialDummy") ~= true or v14:GetAttribute("DummyUserId") ~= p11) then
				continue
			end
			return v14
		end
	end
	return nil
end
function v_u_1.ResolveVictimCharacter(p16) -- name: ResolveVictimCharacter
	-- upvalues: (copy) v_u_15, (copy) v_u_2, (copy) v_u_3, (copy) v_u_5, (copy) v_u_4
	if p16.Generation == 0 then
		return v_u_15(p16.Victim)
	end
	local v17
	if p16.Victim <= -1000 then
		v17 = require(v_u_2.Controllers.CharacterController.BotCharacters).TakeCorpse(-p16.Victim - 1000, p16.Generation, p16.Position, p16.LookYaw)
	else
		local v18 = v_u_3:GetPlayerByUserId(p16.Victim)
		if v18 == nil then
			return nil
		end
		v17 = v_u_5.Create(v18, p16.Generation)
	end
	if v17 == nil or not v_u_4.Matches(v17, p16.Generation) then
		return nil
	end
	v17:PivotTo(CFrame.new(p16.Position) * CFrame.Angles(0, p16.LookYaw, 0))
	v17:SetAttribute("Health", 0)
	v17:SetAttribute("Dead", true)
	return v17
end
function v_u_1.IsFinisherValidForReplication(p19) -- name: IsFinisherValidForReplication
	-- upvalues: (copy) v_u_10, (copy) v_u_7
	local v20 = v_u_10[p19.Finisher]
	local v21 = ("\"%*\" is not a valid member of database.custom.finishers"):format(p19.Finisher)
	assert(v20, v21)
	local v22 = v_u_7.UserId
	return v20.Replication == "Killer" and p19.Killer == v22 and true or (v20.Replication == "Victim" and p19.Victim == v22 and true or (v20.Replication == "Both" and (p19.Killer == v22 or p19.Victim == v22) and true or v20.Replication == "All"))
end
function v_u_1.ExecuteFinisher(p_u_23) -- name: ExecuteFinisher
	-- upvalues: (copy) v_u_1, (copy) v_u_10, (copy) v_u_9, (copy) v_u_8
	if v_u_1.IsFinisherValidForReplication(p_u_23) then
		local v_u_24 = v_u_10[p_u_23.Finisher]
		local v25 = ("\"%*\" is not a valid member of database.custom.finishers"):format(p_u_23.Finisher)
		assert(v_u_24, v25)
		local function v35()
			-- upvalues: (ref) v_u_1, (copy) p_u_23, (ref) v_u_9, (ref) v_u_8, (copy) v_u_24
			local v26 = v_u_1.ResolveVictimCharacter(p_u_23)
			if not v26 then
				warn((("Failed to execute finisher \"%*\": missing victim character \"%*\""):format(p_u_23.Finisher, p_u_23.Victim)))
				return nil
			end
			v26.Archivable = true
			local v27 = p_u_23.Victim
			local v_u_28 = tostring(v27)
			local v29 = v_u_9[v_u_28]
			if v29 then
				v29.Destroy()
			end
			while #v_u_8 >= 8 do
				local v30 = table.remove(v_u_8, 1)
				if not v30 then
					continue
				end
				v30.Destroy()
			end
			local v_u_31 = v_u_24.Finisher(v26, p_u_23)
			local v_u_32 = {
				["Name"] = v_u_28,
				["Destroy"] = function() -- name: Destroy
					-- upvalues: (ref) v_u_9, (copy) v_u_28, (copy) v_u_31
					v_u_9[v_u_28] = nil
					v_u_31.Destroy()
				end
			}
			v_u_9[v_u_28] = v_u_31
			local v33 = v_u_8
			table.insert(v33, v_u_32)
			v_u_31.OnDestroy:Once(function()
				-- upvalues: (ref) v_u_8, (copy) v_u_32
				local v34 = table.find(v_u_8, v_u_32)
				if v34 then
					table.remove(v_u_8, v34)
				end
			end)
		end
		local v36, v37 = pcall(v35)
		if not v36 then
			warn((("Failed to execute finisher \"%*\": %*"):format(p_u_23.Finisher, v37)))
		end
	end
end
for _, v38 in ipairs(v_u_2.Database.Custom.Finishers:GetChildren()) do
	if not v38:IsA("ModuleScript") then
		continue
	end
	v_u_10[v38.Name] = require(v38)
end
return v_u_1
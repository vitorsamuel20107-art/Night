-- NIGHT Analyzer | ReplicatedStorage.Database.Components.CharacterActions
-- ModuleScript | 49 linhas | 833 bytes | hash f45c98a9

local v_u_1 = table.freeze({
	"Shoot",
	"NoSuppressorShoot",
	"ShootRight",
	"ShootLeft",
	"SlamFire",
	"Reload",
	"Inspect",
	"Switch Fire Mode",
	"Add Suppressor",
	"Remove Suppressor",
	"RevolverChargeStart",
	"RevolverChargeCancel",
	"RevolverChargeRelease",
	"Use",
	"Cancel Plant",
	"StartThrow",
	"Throw",
	"CancelThrow",
	"Swing1",
	"Swing2",
	"Heavy Swing",
	"BackStab",
	"ReloadStart",
	"ReloadEnd"
})
local v_u_2 = {}
for v3, v4 in ipairs(v_u_1) do
	v_u_2[v4] = v3
end
return table.freeze({
	["Names"] = v_u_1,
	["ToId"] = function(p5) -- name: ToId
		-- upvalues: (copy) v_u_2
		if typeof(p5) == "string" then
			return v_u_2[p5]
		else
			return nil
		end
	end,
	["ToName"] = function(p6) -- name: ToName
		-- upvalues: (copy) v_u_1
		if typeof(p6) == "number" then
			return v_u_1[p6]
		else
			return nil
		end
	end
})
-- NIGHT Analyzer | ReplicatedStorage.Database.Components.MarketPlacePrices
-- ModuleScript | 58 linhas | 1759 bytes | hash 8f69cd34

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("HttpService")
require(v_u_2.Database.Custom.Types)
local v_u_4 = require(v_u_2.Database.Components.Libraries.Skins)
local v_u_5 = false
local v_u_6 = nil
local v_u_7 = {}
local function v_u_8() -- name: WaitForMarketPlacePrices
	-- upvalues: (ref) v_u_5, (copy) v_u_2
	while not v_u_5 do
		v_u_2:GetAttributeChangedSignal("MarketPlacePrices"):Wait()
	end
end
local function v_u_11(p9) -- name: UpdateMarketPlacePrices
	-- upvalues: (ref) v_u_6, (copy) v_u_3, (copy) v_u_7, (ref) v_u_5
	v_u_6 = v_u_3:JSONDecode(p9)
	table.clear(v_u_7)
	for _, v10 in v_u_6.items do
		v_u_7[("%*\0%*"):format(v10.itemName, v10.itemSkin)] = v10
	end
	v_u_5 = true
end
function v_u_1.IsLoaded() -- name: IsLoaded
	-- upvalues: (ref) v_u_5
	return v_u_5
end
function v_u_1.GetItemPrice(p12, p13, p14, p15) -- name: GetItemPrice
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v16 = v_u_4.GetSkinInformation(p12, p13)
	if v16 then
		v16 = v_u_4.GetWearNameForFloat(v16, p14)
	end
	local v17 = v_u_1.GetMarketPlaceItem(p12, p13)
	if v17 and v16 then
		return (p15 and v17.statTrack or v17.standard)[v16]
	else
		return nil
	end
end
function v_u_1.GetMarketPlaceItem(p18, p19) -- name: GetMarketPlaceItem
	-- upvalues: (copy) v_u_8, (copy) v_u_7
	v_u_8()
	return v_u_7[("%*\0%*"):format(p18, p19)]
end
local function v21() -- name: SyncMarketPlacePrices
	-- upvalues: (copy) v_u_2, (copy) v_u_11
	local v20 = v_u_2:GetAttribute("MarketPlacePrices")
	if typeof(v20) == "string" then
		v_u_11(v20)
	end
end
local v22 = v_u_2:GetAttribute("MarketPlacePrices")
if typeof(v22) == "string" then
	v_u_11(v22)
end
v_u_2:GetAttributeChangedSignal("MarketPlacePrices"):Connect(v21)
return v_u_1
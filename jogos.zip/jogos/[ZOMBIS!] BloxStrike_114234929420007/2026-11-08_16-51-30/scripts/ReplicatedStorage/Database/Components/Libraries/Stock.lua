-- NIGHT Analyzer | ReplicatedStorage.Database.Components.Libraries.Stock
-- ModuleScript | 149 linhas | 2846 bytes | hash 34cef0b3

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
require(v_u_2.Database.Custom.Types)
local v_u_3 = {
	"USP-S",
	"Glock-18",
	"P250",
	"Desert Eagle",
	"Tec-9",
	"CZ75-Auto",
	"Five-SeveN",
	"Dual Berettas",
	"R8 Revolver",
	"MAC-10",
	"MP9",
	"MP7",
	"MP5-SD",
	"UMP-45",
	"P90",
	"PP-Bizon",
	"AK-47",
	"M4A1-S",
	"M4A4",
	"AUG",
	"SG 553",
	"FAMAS",
	"Galil AR",
	"AWP",
	"SSG 08",
	"SCAR-20",
	"G3SG1",
	"XM1014",
	"Nova",
	"MAG-7",
	"Sawed-Off",
	"Negev",
	"M249",
	"CT Knife",
	"T Knife",
	"CT Glove",
	"T Glove",
	"Molotov",
	"Incendiary Grenade",
	"HE Grenade",
	"Flashbang",
	"Smoke Grenade",
	"Decoy Grenade",
	"C4",
	"Zeus x27"
}
local v_u_4 = {
	["Weapon"] = true,
	["Melee"] = true,
	["Glove"] = true,
	["Grenade"] = true,
	["C4"] = true
}
local function v_u_10(p5) -- name: CreateStockItem
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v6 = {
		["_id"] = nil,
		["Type"] = nil,
		["Serial"] = 0,
		["Name"] = nil,
		["Skin"] = "Stock",
		["Float"] = 0,
		["StatTrack"] = false,
		["IsTradeable"] = false,
		["NameTag"] = false,
		["Charm"] = false,
		["Stickers"] = nil,
		["MetaData"] = nil,
		["_id"] = p5 .. "_Stock"
	}
	local v7
	if p5 == "Zeus x27" or p5 == "C4" then
		v7 = p5
	else
		local v8 = v_u_2.Database.Custom.Weapons:FindFirstChild(p5)
		if v8 then
			local v9 = require(v8).Class
			v7 = not v_u_4[v9] and "Weapon" or v9
		else
			v7 = "Weapon"
		end
	end
	v6.Type = v7
	v6.Name = p5
	v6.Stickers = {}
	v6.MetaData = {
		["LastTradeAt"] = 0,
		["CreatedAt"] = 0,
		["TradeHistory"] = nil,
		["OriginalOwner"] = 0,
		["Owner"] = 0,
		["Origin"] = "Stock",
		["TradeHistory"] = {}
	}
	return v6
end
function v_u_1.IsStockIdentifier(p11) -- name: IsStockIdentifier
	return string.sub(p11, -6) == "_Stock"
end
function v_u_1.GetWeaponNameFromStockId(p12) -- name: GetWeaponNameFromStockId
	-- upvalues: (copy) v_u_1
	if v_u_1.IsStockIdentifier(p12) then
		return string.sub(p12, 1, -7)
	else
		return nil
	end
end
function v_u_1.GetStockInventoryItem(p13) -- name: GetStockInventoryItem
	-- upvalues: (copy) v_u_3, (copy) v_u_10
	if table.find(v_u_3, p13) then
		return v_u_10(p13)
	else
		return nil
	end
end
function v_u_1.GenerateStockInventoryItems() -- name: GenerateStockInventoryItems
	-- upvalues: (copy) v_u_3, (copy) v_u_10
	local v14 = {}
	for _, v15 in ipairs(v_u_3) do
		local v16 = v_u_10(v15)
		table.insert(v14, v16)
	end
	return v14
end
function v_u_1.InjectStockItems(p17) -- name: InjectStockItems
	-- upvalues: (copy) v_u_1
	local v18 = v_u_1.GenerateStockInventoryItems()
	local v19 = {}
	local v20 = {}
	for _, v21 in ipairs(p17) do
		v19[v21._id] = true
		if v21.Skin ~= "Stock" then
			continue
		end
		v20[v21.Name] = true
	end
	for _, v22 in ipairs(v18) do
		if v19[v22._id] or v20[v22.Name] then
			continue
		end
		table.insert(p17, v22)
	end
	return p17
end
return v_u_1
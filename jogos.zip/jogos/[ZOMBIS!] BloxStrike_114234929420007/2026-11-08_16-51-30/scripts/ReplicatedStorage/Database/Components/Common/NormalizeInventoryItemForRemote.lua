-- NIGHT Analyzer | ReplicatedStorage.Database.Components.Common.NormalizeInventoryItemForRemote
-- ModuleScript | 55 linhas | 1142 bytes | hash 5179c53d

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Packages.Sift)
local v_u_3 = {
	"_id",
	"Type",
	"Name",
	"Skin",
	"Rarity",
	"OriginalOwner"
}
local v_u_4 = { "LastTradeAt", "CreatedAt" }
local v_u_5 = {
	"OriginalOwner",
	"Owner",
	"Origin",
	"GlobalMarketPlaceListingReference"
}
return function(p6)
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5
	if typeof(p6) ~= "table" then
		return p6
	end
	local v7 = v_u_2.Dictionary.copyDeep(p6)
	for _, v8 in v_u_3 do
		local v9 = v7[v8]
		if typeof(v9) ~= "number" then
			continue
		end
		local v10 = v7[v8]
		v7[v8] = tostring(v10)
	end
	local v11 = v7.MetaData
	if typeof(v11) == "table" then
		for _, v12 in v_u_4 do
			local v13 = v11[v12]
			if typeof(v13) ~= "string" then
				continue
			end
			local v14 = v11[v12]
			v11[v12] = tonumber(v14)
		end
		if v11.GlobalMarketPlaceListingReference == false then
			v11.GlobalMarketPlaceListingReference = nil
		end
		for _, v15 in v_u_5 do
			local v16 = v11[v15]
			if typeof(v16) ~= "number" then
				continue
			end
			local v17 = v11[v15]
			v11[v15] = tostring(v17)
		end
	end
	return v7
end
-- NIGHT Analyzer | ReplicatedStorage.Database.Components.ServerBrowser
-- ModuleScript | 62 linhas | 1797 bytes | hash ec505463

local v_u_1 = {}
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("HttpService")
local v_u_4 = game:GetService("RunService")
require(v2.Database.Custom.Types)
local v_u_5 = require(v2.Database.Components.Common.RemoveFromArray)
local v6 = require(v2.Database.Security.Remotes)
local v_u_7 = require(v2.Packages.Signal).new()
v_u_1.OnServerBrowserUpdated = v_u_7
local v_u_8 = {}
local v_u_9 = {}
function v_u_1.GetServerNameFromMatchId(p10) -- name: GetServerNameFromMatchId
	return p10:gsub("[^%a]", ""):upper()
end
function v_u_1.GetActiveGameServers() -- name: GetActiveGameServers
	-- upvalues: (ref) v_u_9
	return v_u_9
end
function v_u_1.GetServerByMatchId(p11) -- name: GetServerByMatchId
	-- upvalues: (copy) v_u_8
	return v_u_8[p11]
end
function v_u_1.UpdateActiveGameServers(p12) -- name: UpdateActiveGameServers
	-- upvalues: (copy) v_u_5, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9, (copy) v_u_7
	local v14 = v_u_5(v_u_3:JSONDecode(p12 or "[]"), function(_, p13)
		-- upvalues: (ref) v_u_4
		return not v_u_4:IsStudio() and p13.JobId == "Studio" and true or false
	end)
	local v15 = {}
	for _, v16 in ipairs(v14) do
		v15[v16.MatchId] = v16
	end
	for v17 in v_u_8 do
		if v15[v17] then
			continue
		end
		v_u_8[v17] = nil
	end
	for v18, v19 in v15 do
		v_u_8[v18] = v19
	end
	v_u_9 = v14
	v_u_7:Fire(v_u_9)
end
function v_u_1.ObserverServerBrowser(p20) -- name: ObserverServerBrowser
	-- upvalues: (copy) v_u_7, (ref) v_u_9
	local v_u_21 = v_u_7:Connect(p20)
	if #v_u_9 > 0 then
		p20(v_u_9)
	end
	return function()
		-- upvalues: (copy) v_u_21
		if v_u_21 and v_u_21.Connected then
			v_u_21:Disconnect()
		end
	end
end
v6.Modes.FetchServers.Listen(function(p22)
	-- upvalues: (copy) v_u_1
	v_u_1.UpdateActiveGameServers(p22)
end)
return v_u_1
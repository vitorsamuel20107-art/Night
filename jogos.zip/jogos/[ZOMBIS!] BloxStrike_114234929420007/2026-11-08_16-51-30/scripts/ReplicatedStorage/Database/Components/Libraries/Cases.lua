-- NIGHT Analyzer | ReplicatedStorage.Database.Components.Libraries.Cases
-- ModuleScript | 401 linhas | 8788 bytes | hash eed7b6a0

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("HttpService")
local v4 = game:GetService("RunService")
local v_u_5 = game:GetService("Workspace")
require(v_u_2.Database.Custom.Types)
local v_u_6 = require(v_u_2.Database.Components.Common.RemoveFromArray)
local v_u_7 = require(v_u_2.Packages.Signal).new()
v_u_1.OnCasesUpdated = v_u_7
local v_u_8 = v4:IsStudio()
local v_u_9 = {}
local v_u_10 = {}
local v_u_11 = 0
local function v_u_23() -- name: GetNextCaseBoundaryTimestamp
	-- upvalues: (copy) v_u_5, (ref) v_u_9
	local v12 = v_u_5:GetServerTimeNow()
	local v13 = math.floor(v12)
	local v14 = nil
	for _, v15 in ipairs(v_u_9) do
		local v16 = v15.releaseDate
		local v17
		if v16 == nil then
			v17 = nil
		else
			local v18 = tonumber(v16)
			if v18 then
				if v18 > 10000000000 then
					local v19 = v18 / 1000
					v17 = math.floor(v19)
				else
					v17 = math.floor(v18)
				end
			else
				v17 = DateTime.fromIsoDate(v16)
				if v17 then
					v17 = v17.UnixTimestamp
				end
			end
		end
		if not v17 or (v13 >= v17 or v14 ~= nil and v17 >= v14) then
			v17 = v14
		end
		local v20 = v15.discontinueDate
		if v20 == nil then
			v14 = nil
		else
			local v21 = tonumber(v20)
			if v21 then
				if v21 > 10000000000 then
					local v22 = v21 / 1000
					v14 = math.floor(v22)
				else
					v14 = math.floor(v21)
				end
			else
				v14 = DateTime.fromIsoDate(v20)
				if v14 then
					v14 = v14.UnixTimestamp
				end
			end
		end
		if v14 and (v13 < v14 and (v17 == nil or v14 < v17)) then
			continue
		end
		v14 = v17
	end
	return v14
end
local function v_u_30() -- name: ScheduleCasesUpdateAtNextBoundary
	-- upvalues: (copy) v_u_8, (ref) v_u_11, (copy) v_u_5, (copy) v_u_23, (copy) v_u_7, (ref) v_u_9, (copy) v_u_30
	if v_u_8 then
		return
	else
		v_u_11 = v_u_11 + 1
		local v_u_24 = v_u_11
		local v25 = v_u_5:GetServerTimeNow()
		local v26 = math.floor(v25)
		local v27 = v_u_23()
		if v27 then
			local v28 = v27 - v26
			local v29 = math.max(v28, 0)
			task.delay(v29, function()
				-- upvalues: (copy) v_u_24, (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_30
				if v_u_24 == v_u_11 then
					if #v_u_7:GetConnections() > 0 then
						v_u_7:Fire(v_u_9)
					end
					v_u_30()
				end
			end)
		end
	end
end
local function v_u_43(p31, p32) -- name: IsCaseEnabled
	-- upvalues: (copy) v_u_5, (copy) v_u_8
	local v33 = v_u_5:GetServerTimeNow()
	local v34 = math.floor(v33)
	if v_u_8 and not p32 then
		return true
	end
	if p31.status == "inactive" or (p31.status == "discontinued" or not p31.isEnabled) then
		return false
	end
	local v35 = p31.releaseDate
	if v35 then
		local v36 = p31.releaseDate
		if v36 == nil then
			v35 = nil
		else
			local v37 = tonumber(v36)
			if v37 then
				if v37 > 10000000000 then
					local v38 = v37 / 1000
					v35 = math.floor(v38)
				else
					v35 = math.floor(v37)
				end
			else
				v35 = DateTime.fromIsoDate(v36)
				if v35 then
					v35 = v35.UnixTimestamp
				end
			end
		end
	end
	if v35 and v34 < v35 then
		return false
	end
	local v39 = p31.discontinueDate
	if v39 then
		local v40 = p31.discontinueDate
		if v40 == nil then
			v39 = nil
		else
			local v41 = tonumber(v40)
			if v41 then
				if v41 > 10000000000 then
					local v42 = v41 / 1000
					v39 = math.floor(v42)
				else
					v39 = math.floor(v41)
				end
			else
				v39 = DateTime.fromIsoDate(v40)
				if v39 then
					v39 = v39.UnixTimestamp
				end
			end
		end
	end
	return (not v39 or v39 > v34) and true or false
end
local v_u_44 = {
	["Charm Capsule"] = true,
	["Package"] = true,
	["Console"] = true
}
local function v_u_47(p45, p46) -- name: SortByDisplayOrder
	-- upvalues: (ref) v_u_10
	if p45.displayOrder == p46.displayOrder then
		return (v_u_10[p45] or 0) < (v_u_10[p46] or 0)
	else
		return p45.displayOrder < p46.displayOrder
	end
end
local function v_u_51(p48) -- name: UpdateAvailableCases
	-- upvalues: (ref) v_u_9, (copy) v_u_3, (ref) v_u_10, (copy) v_u_30, (copy) v_u_7
	v_u_9 = v_u_3:JSONDecode(p48)
	v_u_10 = {}
	for v49, v50 in ipairs(v_u_9) do
		v_u_10[v50] = v49
	end
	v_u_30()
	if #v_u_7:GetConnections() > 0 then
		v_u_7:Fire(v_u_9)
	end
end
function v_u_1.GetCreationTimestamp(p52) -- name: GetCreationTimestamp
	local v53 = p52.createdAt
	local v54
	if v53 == nil then
		v54 = nil
	else
		local v55 = tonumber(v53)
		if v55 then
			if v55 > 10000000000 then
				local v56 = v55 / 1000
				v54 = math.floor(v56)
			else
				v54 = math.floor(v55)
			end
		else
			v54 = DateTime.fromIsoDate(v53)
			if v54 then
				v54 = v54.UnixTimestamp
			end
		end
	end
	if not v54 then
		local v57 = p52.releaseDate
		if v57 == nil then
			return nil
		end
		local v58 = tonumber(v57)
		if v58 then
			if v58 <= 10000000000 then
				return math.floor(v58)
			end
			local v59 = v58 / 1000
			return math.floor(v59)
		end
		v54 = DateTime.fromIsoDate(v57)
		if v54 then
			v54 = v54.UnixTimestamp
		end
	end
	return v54
end
function v_u_1.IsLimited(p60) -- name: IsLimited
	local v61 = p60.discontinueDate
	local v62
	if v61 == nil then
		v62 = nil
	else
		local v63 = tonumber(v61)
		if v63 then
			if v63 > 10000000000 then
				local v64 = v63 / 1000
				v62 = math.floor(v64)
			else
				v62 = math.floor(v63)
			end
		else
			v62 = DateTime.fromIsoDate(v61)
			if v62 then
				v62 = v62.UnixTimestamp
			end
		end
	end
	return v62 ~= nil
end
function v_u_1.GetBackendOrder(p65) -- name: GetBackendOrder
	-- upvalues: (ref) v_u_10
	return v_u_10[p65] or (1 / 0)
end
function v_u_1.IsCaseEnabled(p66) -- name: IsCaseEnabled
	-- upvalues: (copy) v_u_1, (copy) v_u_43
	local v67 = v_u_1.GetCase(p66)
	local v68
	if v67 == nil then
		v68 = false
	else
		v68 = v_u_43(v67)
	end
	return v68
end
function v_u_1.IsCaseForSale(p69) -- name: IsCaseForSale
	-- upvalues: (copy) v_u_1, (copy) v_u_43
	local v70 = v_u_1.GetCase(p69)
	local v71
	if v70 == nil then
		v71 = false
	else
		v71 = v_u_43(v70, true)
	end
	return v71
end
function v_u_1.HasCaseModel(p72) -- name: HasCaseModel
	-- upvalues: (copy) v_u_1, (copy) v_u_44, (copy) v_u_2
	local v73 = v_u_1.GetCase(p72)
	local v74
	if v73 == nil then
		v74 = false
	else
		if v_u_44[v73.caseType] then
			return true
		end
		local v75 = v_u_2:FindFirstChild("Assets")
		if v75 then
			v75 = v75:FindFirstChild("CaseModels")
		end
		if v75 == nil then
			v74 = false
		else
			v74 = v75:FindFirstChild(v73.name) ~= nil
		end
	end
	return v74
end
function v_u_1.GetCaseByName(p76) -- name: GetCaseByName
	-- upvalues: (ref) v_u_9
	if not v_u_9 then
		return nil
	end
	for _, v77 in ipairs(v_u_9) do
		if v77.name ~= p76 then
			continue
		end
		return v77
	end
	return nil
end
function v_u_1.GetCase(p78) -- name: GetCase
	-- upvalues: (ref) v_u_9
	if not v_u_9 then
		return nil
	end
	for _, v79 in ipairs(v_u_9) do
		if v79.caseId ~= p78 then
			continue
		end
		return v79
	end
	return nil
end
function v_u_1.GetFeaturedCases(p_u_80) -- name: GetFeaturedCases
	-- upvalues: (ref) v_u_9, (copy) v_u_43, (copy) v_u_44, (copy) v_u_2, (copy) v_u_47, (copy) v_u_6
	local v81 = {}
	for _, v82 in ipairs(v_u_9) do
		if not (v82.isFeatured and v_u_43(v82)) then
			continue
		end
		local v83
		if v_u_44[v82.caseType] then
			v83 = true
		else
			local v84 = v_u_2:FindFirstChild("Assets")
			if v84 then
				v84 = v84:FindFirstChild("CaseModels")
			end
			if v84 == nil then
				v83 = false
			else
				v83 = v84:FindFirstChild(v82.name) ~= nil
			end
		end
		if not v83 then
			continue
		end
		table.insert(v81, v82)
	end
	table.sort(v81, v_u_47)
	v_u_6(v81, function(p85, _)
		-- upvalues: (copy) p_u_80
		return p_u_80 < p85
	end)
	return v81
end
function v_u_1.GetCases() -- name: GetCases
	-- upvalues: (ref) v_u_9, (copy) v_u_43, (copy) v_u_44, (copy) v_u_2, (copy) v_u_47
	local v86 = {}
	for _, v87 in ipairs(v_u_9) do
		if not v_u_43(v87) then
			continue
		end
		local v88
		if v_u_44[v87.caseType] then
			v88 = true
		else
			local v89 = v_u_2:FindFirstChild("Assets")
			if v89 then
				v89 = v89:FindFirstChild("CaseModels")
			end
			if v89 == nil then
				v88 = false
			else
				v88 = v89:FindFirstChild(v87.name) ~= nil
			end
		end
		if not v88 then
			continue
		end
		table.insert(v86, v87)
	end
	table.sort(v86, v_u_47)
	return v86
end
function v_u_1.ObserveAvailableCases(p90) -- name: ObserveAvailableCases
	-- upvalues: (copy) v_u_7, (ref) v_u_9
	local v_u_91 = v_u_7:Connect(p90)
	if v_u_9 then
		p90(v_u_9)
	end
	return function()
		-- upvalues: (copy) v_u_91
		v_u_91:Disconnect()
	end
end
local function v93() -- name: SyncAvailableCases
	-- upvalues: (copy) v_u_2, (copy) v_u_51
	local v92 = v_u_2:GetAttribute("AvaiableCases")
	if v92 then
		v_u_51(v92)
	end
end
local v94 = v_u_2:GetAttribute("AvaiableCases")
if v94 then
	v_u_51(v94)
end
v_u_2:GetAttributeChangedSignal("AvaiableCases"):Connect(v93)
return v_u_1
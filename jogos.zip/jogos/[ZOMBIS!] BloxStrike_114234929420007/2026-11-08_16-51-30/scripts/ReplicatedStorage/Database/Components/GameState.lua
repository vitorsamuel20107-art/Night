-- NIGHT Analyzer | ReplicatedStorage.Database.Components.GameState
-- ModuleScript | 93 linhas | 3242 bytes | hash 6c6cb6fc

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("RunService")
require(v1.Database.Custom.Types)
local v_u_3 = require(v1.Packages.Observers)
local v_u_4 = {
	"Map Voting",
	"Game Ending",
	"Warmup",
	"Round In Progress",
	"Buy Period",
	"Intermission"
}
return {
	["GetState"] = function() -- name: GetState
		return workspace:GetAttribute("GameState")
	end,
	["GetStateAtTime"] = function(p5) -- name: GetStateAtTime
		-- upvalues: (copy) v_u_4
		local v6 = workspace:GetAttribute("GameState")
		local v7 = workspace:GetAttribute("ScheduledGameState")
		local v8 = workspace:GetAttribute("ScheduledGameStateServerTime")
		if typeof(p5) == "number" and (p5 == p5 and (typeof(v8) == "number" and (v8 <= p5 and (typeof(v7) == "string" and table.find(v_u_4, v7) ~= nil)))) then
			return v7
		else
			local v9 = workspace:GetAttribute("GameStateTransitionServerTime")
			local v10 = workspace:GetAttribute("PreviousGameState")
			if typeof(p5) == "number" and (p5 == p5 and (typeof(v9) == "number" and (p5 < v9 and (typeof(v10) == "string" and table.find(v_u_4, v10) ~= nil)))) then
				return v10
			else
				return v6
			end
		end
	end,
	["SetState"] = function(p11) -- name: SetState
		-- upvalues: (copy) v_u_2, (copy) v_u_4
		local v12 = v_u_2:IsServer()
		assert(v12, "This method is only available to the server.")
		local v13 = table.find(v_u_4, p11)
		local v14 = ("\"%*\" is not a valid state!"):format(p11)
		assert(v13, v14)
		if true then
			local v15 = workspace:GetAttribute("GameState")
			if v15 == p11 then
				return
			end
			local v16 = workspace:GetAttribute("ScheduledGameState")
			local v17 = workspace:GetAttribute("ScheduledGameStateServerTime")
			if v16 ~= p11 or typeof(v17) ~= "number" then
				v17 = workspace:GetServerTimeNow()
			end
			workspace:SetAttribute("PreviousGameState", v15)
			workspace:SetAttribute("GameStateTransitionServerTime", v17)
			workspace:SetAttribute("GameState", p11)
			workspace:SetAttribute("ScheduledGameState", nil)
			workspace:SetAttribute("ScheduledGameStateServerTime", nil)
		end
	end,
	["ScheduleState"] = function(p18, p19) -- name: ScheduleState
		-- upvalues: (copy) v_u_2, (copy) v_u_4
		local v20 = v_u_2:IsServer()
		assert(v20, "This method is only available to the server.")
		local v21
		if p19 == p19 and p19 > (-1 / 0) then
			v21 = p19 < (1 / 0)
		else
			v21 = false
		end
		assert(v21)
		local v22 = table.find(v_u_4, p18)
		local v23 = ("\"%*\" is not a valid state!"):format(p18)
		assert(v22, v23)
		if true then
			workspace:SetAttribute("ScheduledGameStateServerTime", p19)
			workspace:SetAttribute("ScheduledGameState", p18)
		end
	end,
	["CancelScheduledState"] = function() -- name: CancelScheduledState
		-- upvalues: (copy) v_u_2
		local v24 = v_u_2:IsServer()
		assert(v24, "This method is only available to the server.")
		workspace:SetAttribute("ScheduledGameState", nil)
		workspace:SetAttribute("ScheduledGameStateServerTime", nil)
	end,
	["ListenToState"] = function(p_u_25) -- name: ListenToState
		-- upvalues: (copy) v_u_3
		local v_u_26 = nil
		return v_u_3.observeAttribute(workspace, "GameState", function(p27)
			-- upvalues: (copy) p_u_25, (ref) v_u_26
			p_u_25(v_u_26, p27)
			v_u_26 = p27
		end)
	end
}
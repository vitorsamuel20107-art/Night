-- NIGHT Analyzer | ReplicatedStorage.Database.Components.Common.Roblox.CanPlayerUseChatService
-- ModuleScript | 14 linhas | 351 bytes | hash 1f1839fd

local v_u_1 = game:GetService("TextChatService")
return function(p_u_2)
	-- upvalues: (copy) v_u_1
	local function v3()
		-- upvalues: (ref) v_u_1, (copy) p_u_2
		return v_u_1:CanUserChatAsync(p_u_2.UserId)
	end
	local v4, v5 = pcall(v3)
	if v4 then
		return v5
	end
	warn("[CanUserUseChat] Failed to check if user can use chat", v5)
	return false
end
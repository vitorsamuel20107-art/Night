-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Maps.Surf Utopia
-- ModuleScript | 36 linhas | 855 bytes | hash e7dfa9f4

local v1 = game:GetService("ReplicatedStorage")
require(v1.Database.Custom.Types)
local v2 = table.freeze
local v3 = {
	["Icon"] = "rbxassetid://77199368053431",
	["Gamemode"] = {
		["Deathmatch"] = false,
		["Competitive"] = false,
		["Casual"] = false,
		["Surf"] = "Surf"
	},
	["Characters"] = {
		["Counter-Terrorists"] = "IDF",
		["Terrorists"] = "Anarchist"
	},
	["Lighting"] = {
		["Properties"] = require(script:WaitForChild("Properties")),
		["Assets"] = v1.Assets.Lighting.Skyline
	}
}
local v4 = {
	["Position"] = Vector3.new(0, 0, 0),
	["Terrain"] = nil,
	["Resolution"] = 0,
	["Properties"] = {
		["WaterColor"] = Color3.fromRGB(12, 84, 92),
		["WaterTransparency"] = 0.3,
		["WaterReflectance"] = 1,
		["WaterWaveSpeed"] = 10,
		["WaterWaveSize"] = 0.15,
		["Decoration"] = false,
		["MaterialColors"] = {}
	}
}
v3.Terrain = v4
return v2(v3)
-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Get 15 Headshots
-- ModuleScript | 16 linhas | 371 bytes | hash 1322eca5

return table.freeze({
	["MissionId"] = "Get 15 Headshots",
	["DisplayName"] = "Get 15 Headshots In Bomb Defusal Or Hostage Rescue",
	["Target"] = 15,
	["Type"] = "daily",
	["Gamemodes"] = nil,
	["Category"] = "headshots",
	["Rewards"] = nil,
	["Gamemodes"] = { "Bomb Defusal", "Hostage Rescue" },
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 28
		}
	}
})
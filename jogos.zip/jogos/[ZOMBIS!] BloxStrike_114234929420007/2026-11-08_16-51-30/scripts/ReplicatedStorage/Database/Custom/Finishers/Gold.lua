-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.Finishers.Gold
-- ModuleScript | 46 linhas | 1226 bytes | hash bbaac0a2

local v1 = game:GetService("ReplicatedStorage")
require(v1.Classes.Ragdoll.Types)
local v2 = require(v1.Classes.Sound)
local v_u_3 = require(v1.Classes.Ragdoll)
local v_u_4 = v2.new("Finishers")
local function v_u_7(p5, _) -- name: Activate
	-- upvalues: (copy) v_u_4
	v_u_4:play({
		["Parent"] = nil,
		["Name"] = "Gold",
		["Parent"] = p5.CharacterModel
	})
	if p5.CharacterModel:FindFirstChild("CharacterArmor") then
		p5.CharacterModel.CharacterArmor:Destroy()
	end
	for _, v6 in ipairs(p5.CharacterModel:GetDescendants()) do
		if v6:IsA("Shirt") or v6:IsA("Pants") then
			v6:Destroy()
		else
			if not v6:IsA("BasePart") then
				continue
			end
			v6.Color = Color3.fromRGB(255, 170, 0)
			v6.Material = Enum.Material.Metal
		end
	end
end
return {
	["Replication"] = "All",
	["Finisher"] = nil,
	["Finisher"] = function(p8, p_u_9) -- name: Finisher
		-- upvalues: (copy) v_u_3, (copy) v_u_7
		local v_u_10 = v_u_3.new(p8, p_u_9)
		v_u_10:OnceAppearanceReady(function()
			-- upvalues: (ref) v_u_7, (copy) v_u_10, (copy) p_u_9
			v_u_7(v_u_10, p_u_9)
		end)
		return {
			["OnDestroy"] = v_u_10.OnDestroy,
			["Destroy"] = function() -- name: Destroy
				-- upvalues: (copy) v_u_10
				v_u_10:Destroy()
			end
		}
	end
}
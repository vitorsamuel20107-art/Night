-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Maps.Stronghold.Properties
-- ModuleScript | 18 linhas | 550 bytes | hash 1038cb8f

return table.freeze({
	["Ambient"] = nil,
	["Brightness"] = 1,
	["ColorShift_Bottom"] = nil,
	["ColorShift_Top"] = nil,
	["EnvironmentDiffuseScale"] = 0.2,
	["EnvironmentSpecularScale"] = 1,
	["GlobalShadows"] = true,
	["OutdoorAmbient"] = nil,
	["ShadowSoftness"] = 0.2,
	["ClockTime"] = 13.42,
	["GeographicLatitude"] = 0,
	["ExposureCompensation"] = 0,
	["Ambient"] = Color3.fromRGB(17, 19, 29),
	["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0),
	["ColorShift_Top"] = Color3.fromRGB(158, 195, 255),
	["OutdoorAmbient"] = Color3.fromRGB(0, 0, 0)
})
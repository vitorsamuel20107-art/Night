-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Finish Top 3 In Deathmatch 12 Times
-- ModuleScript | 15 linhas | 305 bytes | hash 9544f247

return table.freeze({
	["MissionId"] = "Finish Top 3 In Deathmatch 12 Times",
	["Target"] = 12,
	["Type"] = "weekly",
	["Gamemodes"] = nil,
	["Category"] = "deathmatch_top_3",
	["Rewards"] = nil,
	["Gamemodes"] = { "Deathmatch" },
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 85
		}
	}
})
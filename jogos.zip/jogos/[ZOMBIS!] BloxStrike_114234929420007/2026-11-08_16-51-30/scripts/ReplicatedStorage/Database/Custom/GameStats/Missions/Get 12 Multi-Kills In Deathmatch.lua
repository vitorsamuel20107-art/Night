-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Get 12 Multi-Kills In Deathmatch
-- ModuleScript | 15 linhas | 296 bytes | hash a98d8724

return table.freeze({
	["MissionId"] = "Get 12 Multi-Kills In Deathmatch",
	["Target"] = 12,
	["Type"] = "weekly",
	["Gamemodes"] = nil,
	["Category"] = "multikills",
	["Rewards"] = nil,
	["Gamemodes"] = { "Deathmatch" },
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 90
		}
	}
})
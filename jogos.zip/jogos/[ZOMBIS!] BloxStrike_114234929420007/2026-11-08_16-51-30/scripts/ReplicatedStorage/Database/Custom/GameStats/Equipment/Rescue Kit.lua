-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Equipment.Rescue Kit
-- ModuleScript | 4 linhas | 84 bytes | hash 0b6b5418

return table.freeze({
	["Icon"] = "rbxassetid://116726858713748",
	["Cost"] = 400
})
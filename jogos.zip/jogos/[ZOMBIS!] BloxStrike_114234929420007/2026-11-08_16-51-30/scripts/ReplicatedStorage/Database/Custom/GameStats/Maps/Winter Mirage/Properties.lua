-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Maps.Winter Mirage.Properties
-- ModuleScript | 18 linhas | 556 bytes | hash 1683ab73

return table.freeze({
	["Ambient"] = nil,
	["Brightness"] = 1.4,
	["ColorShift_Bottom"] = nil,
	["ColorShift_Top"] = nil,
	["EnvironmentDiffuseScale"] = 1,
	["EnvironmentSpecularScale"] = 1,
	["GlobalShadows"] = true,
	["OutdoorAmbient"] = nil,
	["ShadowSoftness"] = 0.1,
	["ClockTime"] = 13,
	["GeographicLatitude"] = 50,
	["ExposureCompensation"] = 0,
	["Ambient"] = Color3.fromRGB(115, 135, 157),
	["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0),
	["ColorShift_Top"] = Color3.fromRGB(160, 196, 255),
	["OutdoorAmbient"] = Color3.fromRGB(98, 131, 179)
})
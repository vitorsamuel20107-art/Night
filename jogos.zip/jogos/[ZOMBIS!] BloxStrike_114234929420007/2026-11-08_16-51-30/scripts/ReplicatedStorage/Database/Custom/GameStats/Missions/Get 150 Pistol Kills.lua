-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Get 150 Pistol Kills
-- ModuleScript | 13 linhas | 232 bytes | hash 053abdf3

return table.freeze({
	["MissionId"] = "Get 150 Pistol Kills",
	["Target"] = 150,
	["Type"] = "monthly",
	["Category"] = "pistol_kills",
	["Rewards"] = nil,
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 240
		}
	}
})
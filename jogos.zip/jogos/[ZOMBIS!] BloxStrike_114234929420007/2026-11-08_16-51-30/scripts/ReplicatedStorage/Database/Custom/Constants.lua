-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.Constants
-- ModuleScript | 356 linhas | 8113 bytes | hash 48af9d0e

local v1 = game:GetService("RunService")
local v2 = v1:IsStudio()
local v3 = not v1:IsServer() and 0 or game.PrivateServerOwnerId
local v_u_4 = table.freeze({
	["UnrankedComp"] = 89844875164241,
	["Deathmatch"] = 107028954108065,
	["Defusal"] = 100334860793031,
	["Tutorial"] = 0,
	["Survival"] = 0
})
local v_u_5 = table.freeze({
	["UnrankedComp"] = 108194354348181,
	["Deathmatch"] = 135434213652028,
	["Defusal"] = 114234929420007,
	["Tutorial"] = 135154320945903,
	["Survival"] = 84731941097645
})
local v_u_6 = table.freeze({
	["Mobile"] = table.freeze({
		["UnrankedComp"] = 128037611684480,
		["Deathmatch"] = 103953226898816,
		["Defusal"] = 75364289796924
	}),
	["Console"] = table.freeze({
		["UnrankedComp"] = 132331296438894,
		["Deathmatch"] = 122102693569834,
		["Defusal"] = 86299871106535
	})
})
local v7 = game.PlaceId
local v8 = v_u_6.Mobile
local function v14(p9, p10) -- name: getDeviceServerPlaceId
	-- upvalues: (copy) v_u_6, (copy) v_u_5
	local v11 = v_u_6[p9]
	if not v11 then
		return nil
	end
	for v12, v13 in pairs(v_u_5) do
		if v13 ~= p10 or not v11[v12] then
			continue
		end
		return v11[v12]
	end
	return nil
end
local function v18(p15, p16) -- name: getActiveGamemodeSubplaceIds
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_6
	if p15 == "Dev" then
		return v_u_4
	end
	if not p16 then
		return v_u_5
	end
	local v17 = v_u_6[p16]
	return table.freeze({
		["UnrankedComp"] = v17.UnrankedComp,
		["Deathmatch"] = v17.Deathmatch,
		["Defusal"] = v17.Defusal,
		["Tutorial"] = v_u_5.Tutorial,
		["Survival"] = v_u_5.Survival
	})
end
for _, v19 in pairs(v8) do
	if v19 ~= v7 then
		continue
	end
	v20 = true
end
local v20 = false
local v21
if v20 then
	v21 = "Mobile"
else
	local v22 = v_u_6.Console
	for _, v23 in pairs(v22) do
		if v23 ~= v7 then
			continue
		end
		v24 = true
	end
	local v24 = false
	if v24 then
		v21 = "Console"
	else
		v21 = nil
	end
end
local v25 = game.PlaceId
for _, v26 in pairs(v_u_4) do
	if v26 ~= v25 then
		continue
	end
	v27 = true
end
local v27 = false
local v28
if v27 then
	v28 = "Dev"
else
	for _, v29 in pairs(v_u_5) do
		if v29 ~= v25 then
			continue
		end
		v30 = true
	end
	local v30 = false
	if v30 then
		v28 = "Prod"
	else
		local v31 = v_u_6.Mobile
		for _, v32 in pairs(v31) do
			if v32 ~= v25 then
				continue
			end
			v33 = true
		end
		local v33 = false
		local v34
		if v33 then
			v34 = "Mobile"
		else
			local v35 = v_u_6.Console
			for _, v36 in pairs(v35) do
				if v36 ~= v25 then
					continue
				end
				v37 = true
			end
			local v37 = false
			if v37 then
				v34 = "Console"
			else
				v34 = nil
			end
		end
		if v34 == nil and game.GameId ~= 7633926880 then
			v28 = "Dev"
		else
			v28 = "Prod"
		end
	end
end
local v_u_38 = v18(v28, v21)
local v39 = v_u_38.Defusal
local v40 = v_u_38.UnrankedComp
local v_u_41 = (v40 == v39 or not v40) and 0 or v40
local function v_u_44(p42) -- name: getActiveGamemode
	-- upvalues: (copy) v_u_38, (copy) v_u_41, (copy) v_u_4, (copy) v_u_5
	if p42 == 101836176558619 then
		return "trading"
	end
	if p42 == v_u_38.Deathmatch then
		return "deathmatch"
	end
	if p42 == v_u_38.Defusal then
		return "casual"
	end
	if v_u_41 ~= 0 and p42 == v_u_41 then
		return "competitive"
	end
	if v_u_38.Tutorial ~= 0 and p42 == v_u_38.Tutorial then
		return "tutorial"
	end
	for _, v43 in { v_u_4, v_u_5 } do
		if p42 == v43.Deathmatch then
			return "deathmatch"
		end
		if p42 == v43.Defusal then
			return "casual"
		end
		if v43.UnrankedComp ~= v43.Defusal and p42 == v43.UnrankedComp then
			return "competitive"
		end
		if v43.Tutorial == 0 or p42 ~= v43.Tutorial then
			continue
		end
		return "tutorial"
	end
	return "casual"
end
local v_u_45 = table.freeze({
	["Competitive"] = "competitive",
	["Deathmatch"] = "deathmatch",
	["Casual"] = "casual"
})
local v46 = table.freeze
local v48 = {
	["SHOP_VERSION"] = "1.0.1",
	["VERSION"] = "1.4",
	["MINIMUM_CREDITS_FOR_SPECIAL_CREDITS_OPTION"] = 100000,
	["MARKETPLACE_MAX_LISTING_PRICE"] = 100000000,
	["MARKET_TAX_PERCENT"] = 5,
	["ITEM_CATEGORIES"] = nil,
	["MARKETPLACE_SORTING_OPTIONS"] = nil,
	["INVENTORY_SORTING_OPTIONS"] = nil,
	["DEFAULT_CAMERA_FOV"] = 70,
	["ACTIVE_EVENTS"] = nil,
	["EVENT_END_TIMES"] = nil,
	["GetGamemodeFromServerGamemode"] = nil,
	["SESSION_DATA"] = nil,
	["VIP_MENU_PANEL_WHITELIST"] = nil,
	["AIM_ASSIST_CONFIGS"] = nil,
	["PROMOTIONAL_REWARD_CREDITS"] = nil,
	["PRODUCTION_UNIVERSE_ID"] = 7633926880,
	["ACTIVE_PLACE_ENVIRONMENT"] = nil,
	["GAMEMODE_SUBPLACE_IDS"] = nil,
	["ACTIVE_GAMEMODE_SUBPLACE_IDS"] = nil,
	["GAMEMODE_PLACE_IDS"] = nil,
	["TRADING_PLACE_ID"] = 101836176558619,
	["DEVICE_GAMEMODE_SUBPLACE_IDS"] = nil,
	["ACTIVE_DEVICE_PLATFORM"] = nil,
	["IS_DEVICE_SERVER"] = nil,
	["GetDeviceServerPlaceId"] = nil,
	["TUTORIAL_ENABLED"] = false,
	["STORE_FOREVER_PACK_ENABLED"] = false,
	["STORE_GAMEPASSES_ENABLED"] = false,
	["BLACK_MARKET_ENABLED"] = true,
	["FUSER_ENABLED"] = false,
	["ITEM_CATEGORIES"] = table.freeze({
		"All",
		"Pistol",
		"SMG",
		"Rifle",
		"Heavy",
		"Equipment",
		"Miscellaneous"
	}),
	["MARKETPLACE_SORTING_OPTIONS"] = table.freeze({
		"Quality",
		"RAP",
		"Newest",
		"Alphabetical",
		"Collection",
		"Type",
		"Float"
	}),
	["INVENTORY_SORTING_OPTIONS"] = table.freeze({
		"Quality",
		"RAP",
		"Newest",
		"Alphabetical",
		"Collection",
		"Equipped",
		"Type",
		"Float",
		"Serial"
	}),
	["ACTIVE_EVENTS"] = {
		["MEDAL.TV"] = false
	},
	["EVENT_END_TIMES"] = {
		["MEDAL.TV"] = os.time({
			["year"] = 2026,
			["month"] = 3,
			["day"] = 1,
			["hour"] = 0,
			["min"] = 0,
			["sec"] = 0
		})
	},
	["GetGamemodeFromServerGamemode"] = function(p47) -- name: getGamemodeFromServerGamemode
		-- upvalues: (copy) v_u_45, (copy) v_u_44
		if typeof(p47) == "string" and v_u_45[p47] then
			return v_u_45[p47]
		else
			return v_u_44(game.PlaceId)
		end
	end,
	["SESSION_DATA"] = {
		["VIP_SERVER_OWNER"] = v3 > 0 and v3 and v3 or nil,
		["PRIVATE_SERVER_ID"] = v2 and "Studio" or game.PrivateServerId,
		["JOB_ID"] = v2 and "Studio" or game.JobId,
		["GAMEMODE"] = v_u_44(game.PlaceId),
		["UNIVERSE_ID"] = game.GameId,
		["PLACE_ID"] = game.PlaceId
	},
	["VIP_MENU_PANEL_WHITELIST"] = {
		363101315,
		3659308968,
		1243042178,
		107643044,
		9236102964,
		38260227,
		40222641,
		3436218611,
		9678116347
	},
	["AIM_ASSIST_CONFIGS"] = {
		["PLAYER"] = {
			["TargetSelection"] = {
				["Enabled"] = true,
				["MaxDistance"] = 125,
				["MaxAngle"] = 0.5235987755982988
			},
			["Friction"] = {
				["Enabled"] = true,
				["BubbleRadius"] = 2.4,
				["MinSensitivity"] = 0.5,
				["MaxSensitivity"] = 1
			},
			["Magnetism"] = {
				["Enabled"] = true,
				["MaxAngleHorizontal"] = 0.20943951023931956,
				["MaxAngleVertical"] = 0.10471975511965978,
				["PullStrength"] = 0.11344640137963143,
				["StopThreshold"] = 0.008726646259971648,
				["MaxDistance"] = 125
			},
			["VerticalMagnetism"] = {
				["Enabled"] = true,
				["MaxAngleHorizontal"] = 0.20943951023931956,
				["MaxAngleVertical"] = 0.10471975511965978,
				["PullStrength"] = 0.11344640137963143,
				["StopThreshold"] = 0.008726646259971648,
				["MaxDistance"] = 125
			},
			["RecoilAssist"] = {
				["Enabled"] = true,
				["ReductionAmount"] = 0.5,
				["HorizontalReductionAmount"] = 0.85,
				["RequiresTarget"] = false
			}
		}
	},
	["PROMOTIONAL_REWARD_CREDITS"] = table.freeze({
		["Notifications"] = 15,
		["FavoriteGame"] = 15,
		["InviteFriend"] = 15,
		["JoinGroup"] = 15,
		["LikeGame"] = 15
	}),
	["ACTIVE_PLACE_ENVIRONMENT"] = v28,
	["GAMEMODE_SUBPLACE_IDS"] = {
		["Prod"] = v_u_5,
		["Dev"] = v_u_4
	},
	["ACTIVE_GAMEMODE_SUBPLACE_IDS"] = v_u_38,
	["GAMEMODE_PLACE_IDS"] = {
		["Deathmatch"] = nil,
		["Casual"] = nil,
		["Competitive"] = nil,
		["Tutorial"] = nil,
		["Survival"] = nil,
		["Trading"] = 101836176558619,
		["Deathmatch"] = v_u_38.Deathmatch,
		["Casual"] = v_u_38.Defusal,
		["Competitive"] = v_u_41,
		["Tutorial"] = v_u_38.Tutorial,
		["Survival"] = v_u_38.Survival
	},
	["DEVICE_GAMEMODE_SUBPLACE_IDS"] = v_u_6,
	["ACTIVE_DEVICE_PLATFORM"] = v21,
	["IS_DEVICE_SERVER"] = v21 ~= nil,
	["GetDeviceServerPlaceId"] = v14
}
return v46(v48)
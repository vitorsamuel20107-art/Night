-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Maps.Dizzy.Properties
-- ModuleScript | 18 linhas | 560 bytes | hash 3c8a7784

return table.freeze({
	["Ambient"] = nil,
	["Brightness"] = 4,
	["ColorShift_Bottom"] = nil,
	["ColorShift_Top"] = nil,
	["EnvironmentDiffuseScale"] = 1,
	["EnvironmentSpecularScale"] = 1,
	["GlobalShadows"] = true,
	["OutdoorAmbient"] = nil,
	["ShadowSoftness"] = 0.1,
	["ClockTime"] = 10.473,
	["GeographicLatitude"] = 38.958,
	["ExposureCompensation"] = 0,
	["Ambient"] = Color3.fromRGB(48, 46, 41),
	["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0),
	["ColorShift_Top"] = Color3.fromRGB(255, 215, 146),
	["OutdoorAmbient"] = Color3.fromRGB(165, 141, 125)
})
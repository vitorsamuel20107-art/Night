-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Maps.Launch Site.Properties
-- ModuleScript | 18 linhas | 558 bytes | hash 10906c64

return table.freeze({
	["Ambient"] = nil,
	["Brightness"] = 2.5,
	["ColorShift_Bottom"] = nil,
	["ColorShift_Top"] = nil,
	["EnvironmentDiffuseScale"] = 1,
	["EnvironmentSpecularScale"] = 1,
	["GlobalShadows"] = true,
	["OutdoorAmbient"] = nil,
	["ShadowSoftness"] = 0.2,
	["ClockTime"] = 13.8,
	["GeographicLatitude"] = 29,
	["ExposureCompensation"] = 0,
	["Ambient"] = Color3.fromRGB(93, 125, 135),
	["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0),
	["ColorShift_Top"] = Color3.fromRGB(255, 255, 255),
	["OutdoorAmbient"] = Color3.fromRGB(151, 178, 179)
})
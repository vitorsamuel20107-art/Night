-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Maps.Reactor.Properties
-- ModuleScript | 18 linhas | 552 bytes | hash 86ef1621

return table.freeze({
	["Ambient"] = nil,
	["Brightness"] = 4,
	["ColorShift_Bottom"] = nil,
	["ColorShift_Top"] = nil,
	["EnvironmentDiffuseScale"] = 1,
	["EnvironmentSpecularScale"] = 1,
	["GlobalShadows"] = true,
	["OutdoorAmbient"] = nil,
	["ShadowSoftness"] = 0.15,
	["ClockTime"] = 8.5,
	["GeographicLatitude"] = 45,
	["ExposureCompensation"] = 0,
	["Ambient"] = Color3.fromRGB(67, 67, 67),
	["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0),
	["ColorShift_Top"] = Color3.fromRGB(216, 175, 114),
	["OutdoorAmbient"] = Color3.fromRGB(115, 95, 66)
})
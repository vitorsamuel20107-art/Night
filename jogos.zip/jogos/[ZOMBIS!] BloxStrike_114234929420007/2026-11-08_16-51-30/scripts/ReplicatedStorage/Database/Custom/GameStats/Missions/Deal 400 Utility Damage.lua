-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Deal 400 Utility Damage
-- ModuleScript | 16 linhas | 391 bytes | hash da5ab688

return table.freeze({
	["MissionId"] = "Deal 400 Utility Damage",
	["DisplayName"] = "Deal 400 Utility Damage In Bomb Defusal Or Hostage Rescue",
	["Target"] = 400,
	["Type"] = "daily",
	["Gamemodes"] = nil,
	["Category"] = "utility_damage",
	["Rewards"] = nil,
	["Gamemodes"] = { "Bomb Defusal", "Hostage Rescue" },
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 26
		}
	}
})
-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.Finishers.Melted
-- ModuleScript | 39 linhas | 1186 bytes | hash 9ea7d9e9

local v1 = game:GetService("ReplicatedStorage")
require(v1.Classes.Ragdoll.Types)
local v_u_2 = require(v1.Classes.Ragdoll)
local v_u_3 = require(v1.Classes.Ragdoll.Rig)
local v_u_4 = v1.Assets.Finishers.Goop
local function v_u_13(p5, _) -- name: Activate
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v6 = p5.CharacterModel:FindFirstChild("LowerTorso")
	if v6 then
		v_u_3.DisableJoint(p5.CharacterModel, "Waist")
		local v7 = p5.CharacterModel:FindFirstChild("UpperTorso")
		if v7 and v7:IsA("BasePart") then
			local v8 = v7.AssemblyLinearVelocity
			local v9 = math.random(-3, 3)
			local v10 = math.random(0, 3)
			local v11 = math.random
			v7.AssemblyLinearVelocity = v8 + Vector3.new(v9, v10, v11(-3, 3))
		end
		local v12 = v_u_4:Clone()
		v12.Weld.Part1 = v6
		v12.Parent = p5.CharacterModel
	end
end
return {
	["Replication"] = "All",
	["Finisher"] = nil,
	["Finisher"] = function(p14, p15) -- name: Finisher
		-- upvalues: (copy) v_u_2, (copy) v_u_13
		local v_u_16 = v_u_2.new(p14, p15)
		v_u_13(v_u_16, p15)
		return {
			["OnDestroy"] = v_u_16.OnDestroy,
			["Destroy"] = function() -- name: Destroy
				-- upvalues: (copy) v_u_16
				v_u_16:Destroy()
			end
		}
	end
}
-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Earn 250 MVPs
-- ModuleScript | 13 linhas | 216 bytes | hash b9a306c9

return table.freeze({
	["MissionId"] = "Earn 250 MVPs",
	["Target"] = 250,
	["Type"] = "monthly",
	["Category"] = "mvp",
	["Rewards"] = nil,
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 266
		}
	}
})
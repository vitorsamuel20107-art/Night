-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Deal 4000 Damage In Deathmatch
-- ModuleScript | 15 linhas | 291 bytes | hash 359f0bb6

return table.freeze({
	["MissionId"] = "Deal 4000 Damage In Deathmatch",
	["Target"] = 4000,
	["Type"] = "daily",
	["Gamemodes"] = nil,
	["Category"] = "damage",
	["Rewards"] = nil,
	["Gamemodes"] = { "Deathmatch" },
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 22
		}
	}
})
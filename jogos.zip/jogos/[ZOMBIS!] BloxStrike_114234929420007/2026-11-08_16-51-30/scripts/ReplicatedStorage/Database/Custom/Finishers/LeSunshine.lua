-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.Finishers.LeSunshine
-- ModuleScript | 43 linhas | 1202 bytes | hash 91d97917

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
require(v1.Classes.Ragdoll.Types)
local v_u_3 = v2.LocalPlayer
local v4 = require(v1.Classes.Sound)
local v_u_5 = require(v1.Classes.Ragdoll)
local v_u_6 = v4.new("Finishers")
local function v_u_9(p_u_7, _) -- name: Activate
	-- upvalues: (copy) v_u_3, (copy) v_u_6
	p_u_7.Janitor:Add(script.FinisherGui:Clone(), "Destroy", "FinisherGui").Parent = v_u_3.PlayerGui
	local v8 = v_u_6:play({
		["Parent"] = nil,
		["Name"] = "LeSunshine",
		["Parent"] = v_u_3.PlayerGui
	})
	if v8 then
		p_u_7.Janitor:Add(v8.Ended:Once(function()
			-- upvalues: (copy) p_u_7
			p_u_7.Janitor:Remove("FinisherGui")
		end))
	end
end
return {
	["Replication"] = "All",
	["Finisher"] = nil,
	["Finisher"] = function(p10, p11) -- name: Finisher
		-- upvalues: (copy) v_u_5, (copy) v_u_3, (copy) v_u_9
		local v_u_12 = v_u_5.new(p10, p11)
		local v13 = p11.Victim
		local v14 = tostring(v13)
		local v15 = v_u_3.UserId
		if v14 == tostring(v15) then
			v_u_9(v_u_12, p11)
		end
		return {
			["OnDestroy"] = v_u_12.OnDestroy,
			["Destroy"] = function() -- name: Destroy
				-- upvalues: (copy) v_u_12
				v_u_12:Destroy()
			end
		}
	end
}
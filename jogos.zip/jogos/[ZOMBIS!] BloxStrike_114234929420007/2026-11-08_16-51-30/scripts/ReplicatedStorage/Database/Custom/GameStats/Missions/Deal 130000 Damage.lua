-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Deal 130000 Damage
-- ModuleScript | 13 linhas | 227 bytes | hash e7823d2e

return table.freeze({
	["MissionId"] = "Deal 130000 Damage",
	["Target"] = 130000,
	["Type"] = "monthly",
	["Category"] = "damage",
	["Rewards"] = nil,
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 220
		}
	}
})
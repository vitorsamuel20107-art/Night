-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Finish Top 3 In Deathmatch 3 Times
-- ModuleScript | 15 linhas | 302 bytes | hash c8aa4284

return table.freeze({
	["MissionId"] = "Finish Top 3 In Deathmatch 3 Times",
	["Target"] = 3,
	["Type"] = "daily",
	["Gamemodes"] = nil,
	["Category"] = "deathmatch_top_3",
	["Rewards"] = nil,
	["Gamemodes"] = { "Deathmatch" },
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 26
		}
	}
})
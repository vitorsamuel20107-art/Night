-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Gamemodes.Surf
-- ModuleScript | 3 linhas | 54 bytes | hash 567ab1da

return table.freeze({
	["Maps"] = { "Surf Utopia" }
})
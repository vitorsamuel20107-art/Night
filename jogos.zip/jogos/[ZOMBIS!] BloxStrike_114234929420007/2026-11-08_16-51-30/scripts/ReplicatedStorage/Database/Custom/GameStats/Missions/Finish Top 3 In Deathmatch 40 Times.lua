-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Finish Top 3 In Deathmatch 40 Times
-- ModuleScript | 15 linhas | 307 bytes | hash 5f9ccded

return table.freeze({
	["MissionId"] = "Finish Top 3 In Deathmatch 40 Times",
	["Target"] = 40,
	["Type"] = "monthly",
	["Gamemodes"] = nil,
	["Category"] = "deathmatch_top_3",
	["Rewards"] = nil,
	["Gamemodes"] = { "Deathmatch" },
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 250
		}
	}
})
-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.InventorySchemas.Deathmatch
-- ModuleScript | 19 linhas | 293 bytes | hash 85c62bc8

local v1 = {
	["MaxInventorySpace"] = 3,
	["InventorySlots"] = nil,
	["InventorySlots"] = {
		{
			["MaxSlotSpace"] = 1,
			["Type"] = "Primary"
		},
		{
			["MaxSlotSpace"] = 1,
			["Type"] = "Secondary"
		},
		{
			["MaxSlotSpace"] = 2,
			["Type"] = "Melee"
		}
	}
}
return table.freeze(v1)
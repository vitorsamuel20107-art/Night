-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.ConsoleTypes
-- ModuleScript | 1 linhas | 9 bytes | hash 021ac67d

return {}
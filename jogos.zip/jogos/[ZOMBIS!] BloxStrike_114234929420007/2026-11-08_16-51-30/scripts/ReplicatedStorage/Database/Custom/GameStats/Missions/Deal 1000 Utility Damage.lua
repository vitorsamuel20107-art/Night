-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Deal 1000 Utility Damage
-- ModuleScript | 13 linhas | 238 bytes | hash 6d708592

return table.freeze({
	["MissionId"] = "Deal 1000 Utility Damage",
	["Target"] = 1000,
	["Type"] = "weekly",
	["Category"] = "utility_damage",
	["Rewards"] = nil,
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 100
		}
	}
})
-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Get 125 Rifle Kills
-- ModuleScript | 13 linhas | 228 bytes | hash ae779521

return table.freeze({
	["MissionId"] = "Get 125 Rifle Kills",
	["Target"] = 125,
	["Type"] = "weekly",
	["Category"] = "rifle_kills",
	["Rewards"] = nil,
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 75
		}
	}
})
-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Deal 1000 Damage
-- ModuleScript | 13 linhas | 220 bytes | hash 4adf4462

return table.freeze({
	["MissionId"] = "Deal 1000 Damage",
	["Target"] = 1000,
	["Type"] = "hourly",
	["Category"] = "damage",
	["Rewards"] = nil,
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 6
		}
	}
})
-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.Finishers.Charred
-- ModuleScript | 44 linhas | 1247 bytes | hash 06e4542a

local v1 = game:GetService("ReplicatedStorage")
require(v1.Classes.Ragdoll.Types)
local v_u_2 = require(v1.Classes.Ragdoll)
local v_u_3 = Instance.new("Fire", nil)
v_u_3.Color = Color3.fromRGB(235, 135, 65)
v_u_3.Heat = 12
v_u_3.Size = 10
local function v_u_6(p4, _) -- name: Activate
	-- upvalues: (copy) v_u_3
	p4.Janitor:Add(v_u_3:Clone()).Parent = p4.CharacterModel.PrimaryPart
	if p4.CharacterModel:FindFirstChild("CharacterArmor") then
		p4.CharacterModel.CharacterArmor:Destroy()
	end
	for _, v5 in ipairs(p4.CharacterModel:GetDescendants()) do
		if v5:IsA("Shirt") or v5:IsA("Pants") then
			v5:Destroy()
		else
			if not v5:IsA("BasePart") then
				continue
			end
			v5.Material = Enum.Material.CorrodedMetal
			v5.Color = Color3.fromRGB(60, 30, 5)
		end
	end
end
return {
	["Replication"] = "All",
	["Finisher"] = nil,
	["Finisher"] = function(p7, p_u_8) -- name: Finisher
		-- upvalues: (copy) v_u_2, (copy) v_u_6
		local v_u_9 = v_u_2.new(p7, p_u_8)
		v_u_9:OnceAppearanceReady(function()
			-- upvalues: (ref) v_u_6, (copy) v_u_9, (copy) p_u_8
			v_u_6(v_u_9, p_u_8)
		end)
		return {
			["OnDestroy"] = v_u_9.OnDestroy,
			["Destroy"] = function() -- name: Destroy
				-- upvalues: (copy) v_u_9
				v_u_9:Destroy()
			end
		}
	end
}
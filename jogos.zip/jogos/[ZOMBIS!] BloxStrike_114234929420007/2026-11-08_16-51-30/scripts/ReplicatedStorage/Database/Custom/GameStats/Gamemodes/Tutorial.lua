-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Gamemodes.Tutorial
-- ModuleScript | 3 linhas | 57 bytes | hash d469f249

return table.freeze({
	["Maps"] = { "Tutorial Range" }
})
-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Equipment.Health
-- ModuleScript | 4 linhas | 83 bytes | hash 9e8bb778

return table.freeze({
	["Icon"] = "rbxassetid://75231721186446",
	["Cost"] = 500
})
-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Earn 12 MVPs
-- ModuleScript | 16 linhas | 357 bytes | hash 79da2f3c

return table.freeze({
	["MissionId"] = "Earn 12 MVPs",
	["DisplayName"] = "Earn 12 MVPs In Bomb Defusal Or Hostage Rescue",
	["Target"] = 12,
	["Type"] = "daily",
	["Gamemodes"] = nil,
	["Category"] = "mvp",
	["Rewards"] = nil,
	["Gamemodes"] = { "Bomb Defusal", "Hostage Rescue" },
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 26
		}
	}
})
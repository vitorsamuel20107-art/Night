-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Get 1200 Kills
-- ModuleScript | 13 linhas | 220 bytes | hash d0961f79

return table.freeze({
	["MissionId"] = "Get 1200 Kills",
	["Target"] = 1200,
	["Type"] = "monthly",
	["Category"] = "kills",
	["Rewards"] = nil,
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 250
		}
	}
})
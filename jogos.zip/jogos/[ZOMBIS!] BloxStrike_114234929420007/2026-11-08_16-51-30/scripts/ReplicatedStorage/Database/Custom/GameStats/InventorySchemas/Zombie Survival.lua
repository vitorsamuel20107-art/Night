-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.InventorySchemas.Zombie Survival
-- ModuleScript | 23 linhas | 351 bytes | hash 7c9e32f1

local v1 = {
	["MaxInventorySpace"] = 4,
	["InventorySlots"] = nil,
	["InventorySlots"] = {
		{
			["MaxSlotSpace"] = 1,
			["Type"] = "Primary"
		},
		{
			["MaxSlotSpace"] = 1,
			["Type"] = "Secondary"
		},
		{
			["MaxSlotSpace"] = 2,
			["Type"] = "Melee"
		},
		{
			["MaxSlotSpace"] = 4,
			["Type"] = "Grenade"
		}
	}
}
return table.freeze(v1)
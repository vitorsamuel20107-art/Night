-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Deal 6000 Damage
-- ModuleScript | 16 linhas | 370 bytes | hash 82338a3f

return table.freeze({
	["MissionId"] = "Deal 6000 Damage",
	["DisplayName"] = "Deal 6000 Damage In Bomb Defusal Or Hostage Rescue",
	["Target"] = 6000,
	["Type"] = "daily",
	["Gamemodes"] = nil,
	["Category"] = "damage",
	["Rewards"] = nil,
	["Gamemodes"] = { "Bomb Defusal", "Hostage Rescue" },
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 22
		}
	}
})
-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Maps.Seaside.Properties
-- ModuleScript | 18 linhas | 545 bytes | hash d523714f

return table.freeze({
	["Ambient"] = nil,
	["Brightness"] = 4,
	["ColorShift_Bottom"] = nil,
	["ColorShift_Top"] = nil,
	["EnvironmentDiffuseScale"] = 1,
	["EnvironmentSpecularScale"] = 1,
	["GlobalShadows"] = true,
	["OutdoorAmbient"] = nil,
	["ShadowSoftness"] = 0.2,
	["ClockTime"] = 9.8,
	["GeographicLatitude"] = 7,
	["ExposureCompensation"] = 0,
	["Ambient"] = Color3.fromRGB(90, 86, 77),
	["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0),
	["ColorShift_Top"] = Color3.fromRGB(0, 0, 0),
	["OutdoorAmbient"] = Color3.fromRGB(129, 118, 72)
})
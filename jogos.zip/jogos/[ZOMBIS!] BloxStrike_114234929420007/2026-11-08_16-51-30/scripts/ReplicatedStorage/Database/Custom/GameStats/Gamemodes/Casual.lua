-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Gamemodes.Casual
-- ModuleScript | 8 linhas | 94 bytes | hash 49c527f3

return table.freeze({
	["Maps"] = {
		"Oasis",
		"Hellena",
		"Reactor",
		"Launch Site"
	}
})
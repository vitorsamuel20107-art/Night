-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Maps.Seaside.Terrain.15
-- ModuleScript | 14002 linhas | 191827 bytes | hash d74be127

return {
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 37,
		["material"] = "Ground",
		["occupancy"] = 0.01
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 99,
		["material"] = "Ground",
		["occupancy"] = 0.15
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 100,
		["material"] = "Ground",
		["occupancy"] = 0.3
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 101,
		["material"] = "Ground",
		["occupancy"] = 0.7
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 102,
		["material"] = "Ground",
		["occupancy"] = 0.96
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 103,
		["material"] = "Ground",
		["occupancy"] = 0.8
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 104,
		["material"] = "Ground",
		["occupancy"] = 0.51
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 105,
		["material"] = "Ground",
		["occupancy"] = 0.43
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 106,
		["material"] = "Ground",
		["occupancy"] = 0.46
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 107,
		["material"] = "Ground",
		["occupancy"] = 0.63
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 108,
		["material"] = "Ground",
		["occupancy"] = 0.73
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 109,
		["material"] = "Ground",
		["occupancy"] = 0.82
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 110,
		["material"] = "Ground",
		["occupancy"] = 0.9
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 111,
		["material"] = "Ground",
		["occupancy"] = 0.61
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 112,
		["material"] = "Ground",
		["occupancy"] = 0.54
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 113,
		["material"] = "Ground",
		["occupancy"] = 0.24
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 114,
		["material"] = "Ground",
		["occupancy"] = 0.04
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 119,
		["material"] = "Ground",
		["occupancy"] = 0.14
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 120,
		["material"] = "Ground",
		["occupancy"] = 0.68
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 121,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 122,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 123,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 124,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 130,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 143,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 14,
		["z"] = 144,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 102,
		["material"] = "Ground",
		["occupancy"] = 0.06
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 108,
		["material"] = "Ground",
		["occupancy"] = 0.01
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 121,
		["material"] = "Ground",
		["occupancy"] = 0.14
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 122,
		["material"] = "Ground",
		["occupancy"] = 0.85
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 123,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 124,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 130,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 143,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 15,
		["z"] = 144,
		["material"] = "Sand",
		["occupancy"] = 0.73
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 123,
		["material"] = "Sand",
		["occupancy"] = 0.58
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 124,
		["material"] = "Sand",
		["occupancy"] = 0.62
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 125,
		["material"] = "Sand",
		["occupancy"] = 0.62
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 130,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 142,
		["material"] = "Sand",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 16,
		["z"] = 143,
		["material"] = "Sand",
		["occupancy"] = 0.88
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 11,
		["material"] = "Grass",
		["occupancy"] = 0.09
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 0.88
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.59
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 125,
		["material"] = "Sand",
		["occupancy"] = 0.44
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 0.75
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 130,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 142,
		["material"] = "Sand",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 17,
		["z"] = 143,
		["material"] = "Sand",
		["occupancy"] = 0.04
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 11,
		["material"] = "Grass",
		["occupancy"] = 0.09
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 0.88
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.59
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 130,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 140,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 141,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 18,
		["z"] = 142,
		["material"] = "Rock",
		["occupancy"] = 0.24
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 11,
		["material"] = "Grass",
		["occupancy"] = 0.07
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 0.87
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.59
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 0.04
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 131,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 138,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 139,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 140,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 19,
		["z"] = 141,
		["material"] = "Rock",
		["occupancy"] = 0.79
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 0.83
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.59
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 0.3
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 131,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 132,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 136,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 137,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 138,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 139,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 140,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 20,
		["z"] = 141,
		["material"] = "Rock",
		["occupancy"] = 0.25
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 0.66
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.57
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 0.08
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 0.49
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 131,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 132,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 133,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 134,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 135,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 136,
		["material"] = "Rock",
		["occupancy"] = 0.97
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 137,
		["material"] = "Rock",
		["occupancy"] = 0.93
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 138,
		["material"] = "Rock",
		["occupancy"] = 0.79
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 139,
		["material"] = "Rock",
		["occupancy"] = 0.71
	},
	{
		["x"] = 34,
		["y"] = 21,
		["z"] = 140,
		["material"] = "Rock",
		["occupancy"] = 0.34
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 0.5
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 0.95
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 0.96
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.51
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 131,
		["material"] = "Rock",
		["occupancy"] = 0.41
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 132,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 133,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 22,
		["z"] = 134,
		["material"] = "Rock",
		["occupancy"] = 0.71
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 0.61
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 0.81
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 0.33
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 0.06
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 20,
		["material"] = "Rock",
		["occupancy"] = 0.45
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 22,
		["material"] = "Rock",
		["occupancy"] = 0.55
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 24,
		["material"] = "Rock",
		["occupancy"] = 0.19
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 25,
		["material"] = "Rock",
		["occupancy"] = 0.62
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 26,
		["material"] = "Rock",
		["occupancy"] = 0.91
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 27,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 28,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 29,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 30,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 0
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 0.06
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.13
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 132,
		["material"] = "Rock",
		["occupancy"] = 0.1
	},
	{
		["x"] = 34,
		["y"] = 23,
		["z"] = 133,
		["material"] = "Rock",
		["occupancy"] = 0.25
	},
	{
		["x"] = 34,
		["y"] = 24,
		["z"] = 14,
		["material"] = "Rock",
		["occupancy"] = 0.29
	},
	{
		["x"] = 34,
		["y"] = 24,
		["z"] = 15,
		["material"] = "Rock",
		["occupancy"] = 0.58
	},
	{
		["x"] = 34,
		["y"] = 24,
		["z"] = 16,
		["material"] = "Rock",
		["occupancy"] = 0.23
	},
	{
		["x"] = 34,
		["y"] = 24,
		["z"] = 26,
		["material"] = "Rock",
		["occupancy"] = 0.59
	},
	{
		["x"] = 34,
		["y"] = 24,
		["z"] = 27,
		["material"] = "Rock",
		["occupancy"] = 0.39
	},
	{
		["x"] = 34,
		["y"] = 24,
		["z"] = 28,
		["material"] = "Rock",
		["occupancy"] = 0.4
	},
	{
		["x"] = 34,
		["y"] = 24,
		["z"] = 29,
		["material"] = "Rock",
		["occupancy"] = 0.38
	},
	{
		["x"] = 34,
		["y"] = 24,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 0.31
	},
	{
		["x"] = 34,
		["y"] = 24,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 0.13
	},
	{
		["x"] = 35,
		["y"] = 9,
		["z"] = 12,
		["material"] = "Ground",
		["occupancy"] = 0.02
	},
	{
		["x"] = 35,
		["y"] = 9,
		["z"] = 122,
		["material"] = "Rock",
		["occupancy"] = 0.24
	},
	{
		["x"] = 35,
		["y"] = 9,
		["z"] = 123,
		["material"] = "Rock",
		["occupancy"] = 0.18
	},
	{
		["x"] = 35,
		["y"] = 9,
		["z"] = 124,
		["material"] = "Rock",
		["occupancy"] = 0.01
	},
	{
		["x"] = 35,
		["y"] = 9,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 0.26
	},
	{
		["x"] = 35,
		["y"] = 9,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 0.61
	},
	{
		["x"] = 35,
		["y"] = 9,
		["z"] = 143,
		["material"] = "Grass",
		["occupancy"] = 0.04
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 11,
		["material"] = "Ground",
		["occupancy"] = 0.02
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 0.88
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 0.64
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 0.28
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 0.48
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.73
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 102,
		["material"] = "Sand",
		["occupancy"] = 0.01
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 120,
		["material"] = "Rock",
		["occupancy"] = 0.03
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 121,
		["material"] = "Rock",
		["occupancy"] = 0.76
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 122,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 123,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 124,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 0.82
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 0.7
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 127,
		["material"] = "Grass",
		["occupancy"] = 0.71
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 128,
		["material"] = "Grass",
		["occupancy"] = 0.39
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 129,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 130,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 0.28
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 0.7
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 143,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 10,
		["z"] = 144,
		["material"] = "Grass",
		["occupancy"] = 0.3
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 11,
		["material"] = "Ground",
		["occupancy"] = 0.52
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 38,
		["material"] = "Ground",
		["occupancy"] = 0.3
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 101,
		["material"] = "Sand",
		["occupancy"] = 0.43
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 102,
		["material"] = "Sand",
		["occupancy"] = 0.55
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 103,
		["material"] = "Sand",
		["occupancy"] = 0.5
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 104,
		["material"] = "Sand",
		["occupancy"] = 0.11
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 119,
		["material"] = "Rock",
		["occupancy"] = 0.11
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 120,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 121,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 122,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 123,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 124,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 128,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 129,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 130,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 143,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 11,
		["z"] = 144,
		["material"] = "Grass",
		["occupancy"] = 0.96
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 11,
		["material"] = "Ground",
		["occupancy"] = 0.37
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 38,
		["material"] = "Ground",
		["occupancy"] = 0.2
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 100,
		["material"] = "Ground",
		["occupancy"] = 0.13
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 101,
		["material"] = "Ground",
		["occupancy"] = 0.44
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 102,
		["material"] = "Ground",
		["occupancy"] = 0.52
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 103,
		["material"] = "Ground",
		["occupancy"] = 0.48
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 104,
		["material"] = "Ground",
		["occupancy"] = 0.07
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 105,
		["material"] = "Ground",
		["occupancy"] = 0.05
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 106,
		["material"] = "Ground",
		["occupancy"] = 0.02
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 108,
		["material"] = "Ground",
		["occupancy"] = 0.03
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 109,
		["material"] = "Ground",
		["occupancy"] = 0.05
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 110,
		["material"] = "Ground",
		["occupancy"] = 0.04
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 119,
		["material"] = "Ground",
		["occupancy"] = 0.36
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 120,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 121,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 122,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 123,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 124,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 129,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 130,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 143,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 144,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 12,
		["z"] = 145,
		["material"] = "Grass",
		["occupancy"] = 0.14
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 12,
		["material"] = "Ground",
		["occupancy"] = 0.43
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 37,
		["material"] = "Ground",
		["occupancy"] = 0.4
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 100,
		["material"] = "Ground",
		["occupancy"] = 0.04
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 101,
		["material"] = "Ground",
		["occupancy"] = 0.29
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 102,
		["material"] = "Ground",
		["occupancy"] = 0.29
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 103,
		["material"] = "Ground",
		["occupancy"] = 0.29
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 104,
		["material"] = "Ground",
		["occupancy"] = 0.13
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 107,
		["material"] = "Ground",
		["occupancy"] = 0.01
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 108,
		["material"] = "Ground",
		["occupancy"] = 0.02
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 109,
		["material"] = "Ground",
		["occupancy"] = 0.13
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 110,
		["material"] = "Ground",
		["occupancy"] = 0.16
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 111,
		["material"] = "Ground",
		["occupancy"] = 0.02
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 119,
		["material"] = "Ground",
		["occupancy"] = 0.09
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 120,
		["material"] = "Ground",
		["occupancy"] = 0.72
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 121,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 122,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 123,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 124,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 130,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 143,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 144,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 13,
		["z"] = 145,
		["material"] = "Grass",
		["occupancy"] = 0.26
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 12,
		["material"] = "Ground",
		["occupancy"] = 0.12
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 37,
		["material"] = "Ground",
		["occupancy"] = 0.04
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 121,
		["material"] = "Ground",
		["occupancy"] = 0.5
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 122,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 123,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 124,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 143,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 144,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 14,
		["z"] = 145,
		["material"] = "Ground",
		["occupancy"] = 0.18
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 122,
		["material"] = "Ground",
		["occupancy"] = 0.09
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 123,
		["material"] = "Ground",
		["occupancy"] = 0.8
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 124,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 143,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 15,
		["z"] = 144,
		["material"] = "Sand",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 124,
		["material"] = "Sand",
		["occupancy"] = 0.2
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 125,
		["material"] = "Sand",
		["occupancy"] = 0.66
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 143,
		["material"] = "Sand",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 16,
		["z"] = 144,
		["material"] = "Sand",
		["occupancy"] = 0.42
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 0.63
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.59
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 0.94
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 140,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 141,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 142,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 17,
		["z"] = 143,
		["material"] = "Sand",
		["occupancy"] = 0.33
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 0.63
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.59
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 0.78
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 130,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 140,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 141,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 18,
		["z"] = 142,
		["material"] = "Rock",
		["occupancy"] = 0.37
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 0.63
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.59
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 0.54
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 131,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 132,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 137,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 138,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 139,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 140,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 19,
		["z"] = 141,
		["material"] = "Rock",
		["occupancy"] = 0.51
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 0.48
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.59
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 0.19
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 0.66
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 131,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 132,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 133,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 134,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 135,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 136,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 137,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 138,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 139,
		["material"] = "Rock",
		["occupancy"] = 0.96
	},
	{
		["x"] = 35,
		["y"] = 20,
		["z"] = 140,
		["material"] = "Rock",
		["occupancy"] = 0.76
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 0.14
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.5
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 131,
		["material"] = "Rock",
		["occupancy"] = 0.41
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 132,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 133,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 134,
		["material"] = "Rock",
		["occupancy"] = 0.84
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 135,
		["material"] = "Rock",
		["occupancy"] = 0.42
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 136,
		["material"] = "Rock",
		["occupancy"] = 0.23
	},
	{
		["x"] = 35,
		["y"] = 21,
		["z"] = 137,
		["material"] = "Rock",
		["occupancy"] = 0.05
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 0.94
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 0.97
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 0.73
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.32
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 132,
		["material"] = "Rock",
		["occupancy"] = 0.41
	},
	{
		["x"] = 35,
		["y"] = 22,
		["z"] = 133,
		["material"] = "Rock",
		["occupancy"] = 0.74
	},
	{
		["x"] = 35,
		["y"] = 23,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 0.68
	},
	{
		["x"] = 35,
		["y"] = 23,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 23,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 23,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 0.48
	},
	{
		["x"] = 35,
		["y"] = 23,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 0.53
	},
	{
		["x"] = 35,
		["y"] = 23,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 0.79
	},
	{
		["x"] = 35,
		["y"] = 23,
		["z"] = 22,
		["material"] = "Rock",
		["occupancy"] = 0.82
	},
	{
		["x"] = 35,
		["y"] = 23,
		["z"] = 24,
		["material"] = "Rock",
		["occupancy"] = 0.24
	},
	{
		["x"] = 35,
		["y"] = 23,
		["z"] = 25,
		["material"] = "Rock",
		["occupancy"] = 0.89
	},
	{
		["x"] = 35,
		["y"] = 23,
		["z"] = 26,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 23,
		["z"] = 27,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 23,
		["z"] = 28,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 35,
		["y"] = 23,
		["z"] = 29,
		["material"] = "Rock",
		["occupancy"] = 0.88
	},
	{
		["x"] = 35,
		["y"] = 23,
		["z"] = 30,
		["material"] = "Rock",
		["occupancy"] = 0.45
	},
	{
		["x"] = 35,
		["y"] = 23,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 0.38
	},
	{
		["x"] = 35,
		["y"] = 23,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 0.86
	},
	{
		["x"] = 35,
		["y"] = 23,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 0.88
	},
	{
		["x"] = 35,
		["y"] = 23,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 0.38
	},
	{
		["x"] = 35,
		["y"] = 24,
		["z"] = 15,
		["material"] = "Rock",
		["occupancy"] = 0.06
	},
	{
		["x"] = 35,
		["y"] = 24,
		["z"] = 26,
		["material"] = "Rock",
		["occupancy"] = 0.13
	},
	{
		["x"] = 35,
		["y"] = 24,
		["z"] = 27,
		["material"] = "Rock",
		["occupancy"] = 0.22
	},
	{
		["x"] = 35,
		["y"] = 24,
		["z"] = 28,
		["material"] = "Rock",
		["occupancy"] = 0.27
	},
	{
		["x"] = 36,
		["y"] = 9,
		["z"] = 12,
		["material"] = "Ground",
		["occupancy"] = 0.13
	},
	{
		["x"] = 36,
		["y"] = 9,
		["z"] = 124,
		["material"] = "Rock",
		["occupancy"] = 0.02
	},
	{
		["x"] = 36,
		["y"] = 9,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 0.04
	},
	{
		["x"] = 36,
		["y"] = 9,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 0.18
	},
	{
		["x"] = 36,
		["y"] = 9,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 0.39
	},
	{
		["x"] = 36,
		["y"] = 9,
		["z"] = 143,
		["material"] = "Grass",
		["occupancy"] = 0.07
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 11,
		["material"] = "Ground",
		["occupancy"] = 0.23
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 0.72
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 0.27
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 0.29
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 0.45
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.78
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 122,
		["material"] = "Rock",
		["occupancy"] = 0.45
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 123,
		["material"] = "Rock",
		["occupancy"] = 0.52
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 124,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 0.96
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 128,
		["material"] = "Grass",
		["occupancy"] = 0.42
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 129,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 130,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 0.26
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 0.68
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 143,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 10,
		["z"] = 144,
		["material"] = "Grass",
		["occupancy"] = 0.26
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 11,
		["material"] = "Ground",
		["occupancy"] = 0.46
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 38,
		["material"] = "Ground",
		["occupancy"] = 0.41
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 120,
		["material"] = "Rock",
		["occupancy"] = 0.02
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 121,
		["material"] = "Rock",
		["occupancy"] = 0.77
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 122,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 123,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 124,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 129,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 130,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 143,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 11,
		["z"] = 144,
		["material"] = "Grass",
		["occupancy"] = 0.79
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 11,
		["material"] = "Ground",
		["occupancy"] = 0.26
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 38,
		["material"] = "Ground",
		["occupancy"] = 0.33
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 120,
		["material"] = "Ground",
		["occupancy"] = 0.2
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 121,
		["material"] = "Ground",
		["occupancy"] = 0.96
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 122,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 123,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 124,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 130,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 143,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 12,
		["z"] = 144,
		["material"] = "Ground",
		["occupancy"] = 0.95
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 12,
		["material"] = "Ground",
		["occupancy"] = 0.52
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 37,
		["material"] = "Ground",
		["occupancy"] = 0.52
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 121,
		["material"] = "Ground",
		["occupancy"] = 0.37
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 122,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 123,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 124,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 130,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 143,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 144,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 13,
		["z"] = 145,
		["material"] = "Ground",
		["occupancy"] = 0.41
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 12,
		["material"] = "Ground",
		["occupancy"] = 0.16
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 37,
		["material"] = "Ground",
		["occupancy"] = 0.11
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 122,
		["material"] = "Ground",
		["occupancy"] = 0.53
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 123,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 124,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 143,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 144,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 14,
		["z"] = 145,
		["material"] = "Ground",
		["occupancy"] = 0.77
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 123,
		["material"] = "Ground",
		["occupancy"] = 0.2
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 124,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 125,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 143,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 144,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 15,
		["z"] = 145,
		["material"] = "Sand",
		["occupancy"] = 0.8
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 124,
		["material"] = "Sand",
		["occupancy"] = 0.09
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 125,
		["material"] = "Sand",
		["occupancy"] = 0.63
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 126,
		["material"] = "Sand",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 143,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 144,
		["material"] = "Sand",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 16,
		["z"] = 145,
		["material"] = "Sand",
		["occupancy"] = 0.21
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 0.41
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.59
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 126,
		["material"] = "Sand",
		["occupancy"] = 0.96
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 140,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 141,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 142,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 143,
		["material"] = "Rock",
		["occupancy"] = 0.86
	},
	{
		["x"] = 36,
		["y"] = 17,
		["z"] = 144,
		["material"] = "Sand",
		["occupancy"] = 0.41
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 0.41
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.59
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 0.66
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 139,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 140,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 141,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 18,
		["z"] = 142,
		["material"] = "Rock",
		["occupancy"] = 0.45
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 0.4
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.59
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 0.03
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 0.76
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 131,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 132,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 133,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 134,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 135,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 136,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 137,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 138,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 139,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 140,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 19,
		["z"] = 141,
		["material"] = "Rock",
		["occupancy"] = 0.43
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 0.17
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.58
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 0.68
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 131,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 132,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 133,
		["material"] = "Rock",
		["occupancy"] = 0.94
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 134,
		["material"] = "Rock",
		["occupancy"] = 0.7
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 135,
		["material"] = "Rock",
		["occupancy"] = 0.52
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 136,
		["material"] = "Rock",
		["occupancy"] = 0.42
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 137,
		["material"] = "Rock",
		["occupancy"] = 0.34
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 138,
		["material"] = "Rock",
		["occupancy"] = 0.34
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 139,
		["material"] = "Rock",
		["occupancy"] = 0.27
	},
	{
		["x"] = 36,
		["y"] = 20,
		["z"] = 140,
		["material"] = "Rock",
		["occupancy"] = 0.12
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 0.8
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.38
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 131,
		["material"] = "Rock",
		["occupancy"] = 0.3
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 132,
		["material"] = "Rock",
		["occupancy"] = 0.3
	},
	{
		["x"] = 36,
		["y"] = 21,
		["z"] = 133,
		["material"] = "Rock",
		["occupancy"] = 0.12
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 0.55
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 0.87
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 0.94
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 0.96
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 0.98
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 0.69
	},
	{
		["x"] = 36,
		["y"] = 22,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.14
	},
	{
		["x"] = 36,
		["y"] = 23,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 0.39
	},
	{
		["x"] = 36,
		["y"] = 23,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 0.68
	},
	{
		["x"] = 36,
		["y"] = 23,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 0.54
	},
	{
		["x"] = 36,
		["y"] = 23,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 0.66
	},
	{
		["x"] = 36,
		["y"] = 23,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 0.82
	},
	{
		["x"] = 36,
		["y"] = 23,
		["z"] = 21,
		["material"] = "Rock",
		["occupancy"] = 0.34
	},
	{
		["x"] = 36,
		["y"] = 23,
		["z"] = 22,
		["material"] = "Rock",
		["occupancy"] = 0.99
	},
	{
		["x"] = 36,
		["y"] = 23,
		["z"] = 25,
		["material"] = "Rock",
		["occupancy"] = 0.48
	},
	{
		["x"] = 36,
		["y"] = 23,
		["z"] = 26,
		["material"] = "Rock",
		["occupancy"] = 0.44
	},
	{
		["x"] = 36,
		["y"] = 23,
		["z"] = 27,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 36,
		["y"] = 23,
		["z"] = 28,
		["material"] = "Rock",
		["occupancy"] = 0.64
	},
	{
		["x"] = 36,
		["y"] = 23,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 0.63
	},
	{
		["x"] = 36,
		["y"] = 23,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 9,
		["z"] = 12,
		["material"] = "Ground",
		["occupancy"] = 0.16
	},
	{
		["x"] = 37,
		["y"] = 9,
		["z"] = 13,
		["material"] = "Ground",
		["occupancy"] = 0.14
	},
	{
		["x"] = 37,
		["y"] = 9,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 0.16
	},
	{
		["x"] = 37,
		["y"] = 9,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 0.13
	},
	{
		["x"] = 37,
		["y"] = 9,
		["z"] = 127,
		["material"] = "Grass",
		["occupancy"] = 0.1
	},
	{
		["x"] = 37,
		["y"] = 9,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 0.18
	},
	{
		["x"] = 37,
		["y"] = 9,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 0.44
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 11,
		["material"] = "Ground",
		["occupancy"] = 0.2
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 0.81
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 0.32
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 0.26
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 0.27
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 0.29
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 0.33
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 0.35
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 0.33
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 0.29
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 0.28
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 0.29
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 0.47
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 0.77
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 123,
		["material"] = "Rock",
		["occupancy"] = 0.06
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 124,
		["material"] = "Rock",
		["occupancy"] = 0.83
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 128,
		["material"] = "Grass",
		["occupancy"] = 0.48
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 129,
		["material"] = "Grass",
		["occupancy"] = 0.27
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 130,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 0.25
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 0.57
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 10,
		["z"] = 143,
		["material"] = "Grass",
		["occupancy"] = 0.94
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 11,
		["material"] = "Ground",
		["occupancy"] = 0.33
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 38,
		["material"] = "Ground",
		["occupancy"] = 0.43
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 122,
		["material"] = "Rock",
		["occupancy"] = 0.52
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 123,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 124,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 129,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 130,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 143,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 11,
		["z"] = 144,
		["material"] = "Grass",
		["occupancy"] = 0.51
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 11,
		["material"] = "Ground",
		["occupancy"] = 0.12
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 37,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 38,
		["material"] = "Ground",
		["occupancy"] = 0.43
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 122,
		["material"] = "Ground",
		["occupancy"] = 0.64
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 123,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 124,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 130,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 143,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 12,
		["z"] = 144,
		["material"] = "Grass",
		["occupancy"] = 0.93
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 12,
		["material"] = "Ground",
		["occupancy"] = 0.1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 13,
		["material"] = "Ground",
		["occupancy"] = 0.46
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 37,
		["material"] = "Ground",
		["occupancy"] = 0.59
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 122,
		["material"] = "Ground",
		["occupancy"] = 0.16
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 123,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 124,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 125,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 143,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 144,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 13,
		["z"] = 145,
		["material"] = "Ground",
		["occupancy"] = 0.97
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 13,
		["material"] = "Ground",
		["occupancy"] = 0.04
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 37,
		["material"] = "Ground",
		["occupancy"] = 0.2
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 123,
		["material"] = "Ground",
		["occupancy"] = 0.43
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 124,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 125,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 126,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 143,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 144,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 145,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 14,
		["z"] = 146,
		["material"] = "Ground",
		["occupancy"] = 0.32
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 37,
		["material"] = "Ground",
		["occupancy"] = 0.01
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 124,
		["material"] = "Ground",
		["occupancy"] = 0.57
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 125,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 126,
		["material"] = "Ground",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 143,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 144,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 145,
		["material"] = "Sand",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 15,
		["z"] = 146,
		["material"] = "Sand",
		["occupancy"] = 0.36
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 23,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 24,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 25,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 26,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 27,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 28,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 29,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 30,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 31,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 32,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 33,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 34,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 35,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 36,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 125,
		["material"] = "Sand",
		["occupancy"] = 0.43
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 126,
		["material"] = "Sand",
		["occupancy"] = 0.82
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 127,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 128,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 129,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 130,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 131,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 132,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 133,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 134,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 135,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 136,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 137,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 138,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 139,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 140,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 141,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 142,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 143,
		["material"] = "Rock",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 144,
		["material"] = "Sand",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 16,
		["z"] = 145,
		["material"] = "Sand",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 17,
		["z"] = 12,
		["material"] = "Grass",
		["occupancy"] = 0.14
	},
	{
		["x"] = 37,
		["y"] = 17,
		["z"] = 13,
		["material"] = "Grass",
		["occupancy"] = 0.87
	},
	{
		["x"] = 37,
		["y"] = 17,
		["z"] = 14,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 17,
		["z"] = 15,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 17,
		["z"] = 16,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 17,
		["z"] = 17,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 17,
		["z"] = 18,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 17,
		["z"] = 19,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 17,
		["z"] = 20,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 17,
		["z"] = 21,
		["material"] = "Grass",
		["occupancy"] = 1
	},
	{
		["x"] = 37,
		["y"] = 17,
		["z"] = 22,
		["material"] = "Grass",
		["occupancy"] = 1
	}
}
-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Maps.Hellena.Properties
-- ModuleScript | 18 linhas | 557 bytes | hash 267e350f

return table.freeze({
	["Ambient"] = nil,
	["Brightness"] = 3,
	["ColorShift_Bottom"] = nil,
	["ColorShift_Top"] = nil,
	["EnvironmentDiffuseScale"] = 1,
	["EnvironmentSpecularScale"] = 1,
	["GlobalShadows"] = true,
	["OutdoorAmbient"] = nil,
	["ShadowSoftness"] = 0.2,
	["ClockTime"] = 10.995,
	["GeographicLatitude"] = -6.734,
	["ExposureCompensation"] = 0,
	["Ambient"] = Color3.fromRGB(40, 36, 35),
	["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0),
	["ColorShift_Top"] = Color3.fromRGB(227, 150, 69),
	["OutdoorAmbient"] = Color3.fromRGB(107, 97, 81)
})
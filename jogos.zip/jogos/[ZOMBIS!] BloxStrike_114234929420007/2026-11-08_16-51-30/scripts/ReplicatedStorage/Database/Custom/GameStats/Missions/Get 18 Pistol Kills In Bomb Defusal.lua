-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Get 18 Pistol Kills In Bomb Defusal
-- ModuleScript | 15 linhas | 302 bytes | hash e9f44023

return table.freeze({
	["MissionId"] = "Get 18 Pistol Kills In Bomb Defusal",
	["Target"] = 18,
	["Type"] = "daily",
	["Gamemodes"] = nil,
	["Category"] = "pistol_kills",
	["Rewards"] = nil,
	["Gamemodes"] = { "Bomb Defusal" },
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 24
		}
	}
})
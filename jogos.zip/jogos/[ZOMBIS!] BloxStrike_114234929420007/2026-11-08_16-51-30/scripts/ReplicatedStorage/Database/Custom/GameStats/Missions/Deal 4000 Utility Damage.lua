-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Deal 4000 Utility Damage
-- ModuleScript | 13 linhas | 239 bytes | hash 4f53d25f

return table.freeze({
	["MissionId"] = "Deal 4000 Utility Damage",
	["Target"] = 4000,
	["Type"] = "monthly",
	["Category"] = "utility_damage",
	["Rewards"] = nil,
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 275
		}
	}
})
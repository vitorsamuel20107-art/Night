-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Get 15 Assists
-- ModuleScript | 16 linhas | 365 bytes | hash 632114f8

return table.freeze({
	["MissionId"] = "Get 15 Assists",
	["DisplayName"] = "Get 15 Assists In Bomb Defusal Or Hostage Rescue",
	["Target"] = 15,
	["Type"] = "daily",
	["Gamemodes"] = nil,
	["Category"] = "assists",
	["Rewards"] = nil,
	["Gamemodes"] = { "Bomb Defusal", "Hostage Rescue" },
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 26
		}
	}
})
-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Maps.Skyline.Properties
-- ModuleScript | 18 linhas | 560 bytes | hash a4114c0f

return table.freeze({
	["Ambient"] = nil,
	["Brightness"] = 4,
	["ColorShift_Bottom"] = nil,
	["ColorShift_Top"] = nil,
	["EnvironmentDiffuseScale"] = 1,
	["EnvironmentSpecularScale"] = 1,
	["GlobalShadows"] = true,
	["OutdoorAmbient"] = nil,
	["ShadowSoftness"] = 0.1,
	["ClockTime"] = 10.473,
	["GeographicLatitude"] = 38.958,
	["ExposureCompensation"] = 0,
	["Ambient"] = Color3.fromRGB(99, 84, 71),
	["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0),
	["ColorShift_Top"] = Color3.fromRGB(255, 215, 146),
	["OutdoorAmbient"] = Color3.fromRGB(165, 141, 125)
})
-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.MissionStars
-- ModuleScript | 9 linhas | 59 bytes | hash b0395d4b

return table.freeze({
	13,
	26,
	39,
	65,
	77,
	91,
	130
})
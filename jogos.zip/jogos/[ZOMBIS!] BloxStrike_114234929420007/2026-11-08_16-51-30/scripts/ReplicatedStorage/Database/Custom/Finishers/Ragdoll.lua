-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.Finishers.Ragdoll
-- ModuleScript | 18 linhas | 452 bytes | hash d2499aca

local v1 = game:GetService("ReplicatedStorage")
require(v1.Classes.Ragdoll.Types)
local v_u_2 = require(v1.Classes.Ragdoll)
return {
	["Replication"] = "All",
	["Finisher"] = nil,
	["Finisher"] = function(p3, p4) -- name: Finisher
		-- upvalues: (copy) v_u_2
		local v_u_5 = v_u_2.new(p3, p4)
		return {
			["OnDestroy"] = v_u_5.OnDestroy,
			["Destroy"] = function() -- name: Destroy
				-- upvalues: (copy) v_u_5
				v_u_5:Destroy()
			end
		}
	end
}
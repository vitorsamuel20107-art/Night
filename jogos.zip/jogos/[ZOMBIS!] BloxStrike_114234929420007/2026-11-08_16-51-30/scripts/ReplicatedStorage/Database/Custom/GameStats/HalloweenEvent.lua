-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.HalloweenEvent
-- ModuleScript | 4 linhas | 93 bytes | hash cd73e3f0

return table.freeze({
	["CANDY_FIELD"] = "Halloween2026Candy",
	["SPIN_CANDY_PRICE"] = 500
})
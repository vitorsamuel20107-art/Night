-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Maps.Oasis.Properties
-- ModuleScript | 18 linhas | 556 bytes | hash db4bfeed

return table.freeze({
	["Ambient"] = nil,
	["Brightness"] = 4.77,
	["ColorShift_Bottom"] = nil,
	["ColorShift_Top"] = nil,
	["EnvironmentDiffuseScale"] = 1,
	["EnvironmentSpecularScale"] = 1,
	["GlobalShadows"] = true,
	["OutdoorAmbient"] = nil,
	["ShadowSoftness"] = 0.1,
	["ClockTime"] = 13.6,
	["GeographicLatitude"] = 50,
	["ExposureCompensation"] = 0,
	["Ambient"] = Color3.fromRGB(84, 77, 76),
	["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0),
	["ColorShift_Top"] = Color3.fromRGB(255, 181, 120),
	["OutdoorAmbient"] = Color3.fromRGB(132, 100, 36)
})
-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Equipment.Kevlar
-- ModuleScript | 4 linhas | 83 bytes | hash a4d19b12

return table.freeze({
	["Icon"] = "rbxassetid://77092909095947",
	["Cost"] = 650
})
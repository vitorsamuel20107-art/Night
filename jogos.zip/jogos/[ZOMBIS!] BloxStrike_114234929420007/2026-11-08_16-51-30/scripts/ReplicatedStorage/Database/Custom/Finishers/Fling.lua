-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.Finishers.Fling
-- ModuleScript | 32 linhas | 835 bytes | hash 762feb4d

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
require(v1.Classes.Ragdoll.Types)
local v_u_3 = v2.LocalPlayer
local v4 = require(v1.Classes.Sound)
local v_u_5 = require(v1.Classes.Ragdoll)
local v_u_6 = v4.new("Finishers")
return {
	["Replication"] = "All",
	["Finisher"] = nil,
	["Finisher"] = function(p7, p8) -- name: Finisher
		-- upvalues: (copy) v_u_5, (copy) v_u_3, (copy) v_u_6
		local v_u_9 = v_u_5.new(p7, p8)
		local v10 = p8.Victim
		local v11 = tostring(v10)
		local v12 = v_u_3.UserId
		if v11 == tostring(v12) then
			v_u_6:play({
				["Parent"] = nil,
				["Name"] = "Fling",
				["Parent"] = v_u_3.PlayerGui
			})
		end
		return {
			["OnDestroy"] = v_u_9.OnDestroy,
			["Destroy"] = function() -- name: Destroy
				-- upvalues: (copy) v_u_9
				v_u_9:Destroy()
			end
		}
	end
}
-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Earn 3 MVPs
-- ModuleScript | 13 linhas | 209 bytes | hash c37a9d11

return table.freeze({
	["MissionId"] = "Earn 3 MVPs",
	["Target"] = 3,
	["Type"] = "hourly",
	["Category"] = "mvp",
	["Rewards"] = nil,
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 6
		}
	}
})
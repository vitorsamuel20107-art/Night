-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Character.Attachments
-- ModuleScript | 8 linhas | 173 bytes | hash 5b1f06e6

return table.freeze({
	["DEFAULT_JOINT_PART"] = "RightHand",
	["WEAPON_JOINT_PARTS"] = nil,
	["WEAPON_JOINT_PARTS"] = {
		["AWP"] = "UpperTorso",
		["C4"] = "LeftHand"
	}
})
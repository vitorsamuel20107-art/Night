-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Grenades
-- ModuleScript | 8 linhas | 159 bytes | hash f607760e

return table.freeze({
	["Decoy Grenade"] = 1,
	["Smoke Grenade"] = 1,
	["HE Grenade"] = 1,
	["Flashbang"] = 2,
	["Molotov"] = 1,
	["Incendiary Grenade"] = 1
})
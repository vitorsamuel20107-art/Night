-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Equipment.Ammo
-- ModuleScript | 4 linhas | 83 bytes | hash a5958371

return table.freeze({
	["Icon"] = "rbxassetid://75943599658491",
	["Cost"] = 300
})
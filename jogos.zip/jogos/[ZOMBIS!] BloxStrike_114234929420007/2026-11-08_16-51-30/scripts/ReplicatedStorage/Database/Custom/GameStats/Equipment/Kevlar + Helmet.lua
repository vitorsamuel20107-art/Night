-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Equipment.Kevlar + Helmet
-- ModuleScript | 4 linhas | 84 bytes | hash 504c010e

return table.freeze({
	["Icon"] = "rbxassetid://80903717317993",
	["Cost"] = 1000
})
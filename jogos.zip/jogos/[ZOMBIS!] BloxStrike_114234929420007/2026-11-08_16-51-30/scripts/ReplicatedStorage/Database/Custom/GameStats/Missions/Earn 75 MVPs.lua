-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Earn 75 MVPs
-- ModuleScript | 13 linhas | 212 bytes | hash ad58c8aa

return table.freeze({
	["MissionId"] = "Earn 75 MVPs",
	["Target"] = 75,
	["Type"] = "weekly",
	["Category"] = "mvp",
	["Rewards"] = nil,
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 96
		}
	}
})
-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Deal 35000 Damage
-- ModuleScript | 13 linhas | 223 bytes | hash c401c394

return table.freeze({
	["MissionId"] = "Deal 35000 Damage",
	["Target"] = 35000,
	["Type"] = "weekly",
	["Category"] = "damage",
	["Rewards"] = nil,
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 75
		}
	}
})
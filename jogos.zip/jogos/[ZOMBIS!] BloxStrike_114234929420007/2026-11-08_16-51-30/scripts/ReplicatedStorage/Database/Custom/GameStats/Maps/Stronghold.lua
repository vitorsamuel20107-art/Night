-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Maps.Stronghold
-- ModuleScript | 38 linhas | 910 bytes | hash b140d71a

local v1 = game:GetService("ReplicatedStorage")
require(v1.Database.Custom.Types)
local v2 = table.freeze
local v3 = {
	["Hidden"] = false,
	["Icon"] = "rbxassetid://93651340552187",
	["Radar"] = "",
	["Gamemode"] = {
		["Competitive"] = false,
		["Deathmatch"] = false,
		["Casual"] = false,
		["Survival"] = "Zombie Survival"
	},
	["Characters"] = {
		["Counter-Terrorists"] = "IDF",
		["Terrorists"] = "Anarchist"
	},
	["Lighting"] = {
		["Properties"] = require(script:WaitForChild("Properties")),
		["Assets"] = v1.Assets.Lighting.Stronghold
	}
}
local v4 = {
	["Position"] = Vector3.new(0, 0, 0),
	["Terrain"] = nil,
	["Resolution"] = 0,
	["Properties"] = {
		["WaterColor"] = Color3.fromRGB(12, 84, 92),
		["WaterTransparency"] = 0.3,
		["WaterReflectance"] = 1,
		["WaterWaveSpeed"] = 10,
		["WaterWaveSize"] = 0.15,
		["Decoration"] = true,
		["MaterialColors"] = {}
	}
}
v3.Terrain = v4
return v2(v3)
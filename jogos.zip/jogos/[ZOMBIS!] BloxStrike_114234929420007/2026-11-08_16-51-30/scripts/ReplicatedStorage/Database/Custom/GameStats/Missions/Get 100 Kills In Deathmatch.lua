-- NIGHT Analyzer | ReplicatedStorage.Database.Custom.GameStats.Missions.Get 100 Kills In Deathmatch
-- ModuleScript | 15 linhas | 287 bytes | hash 6054383d

return table.freeze({
	["MissionId"] = "Get 100 Kills In Deathmatch",
	["Target"] = 100,
	["Type"] = "weekly",
	["Gamemodes"] = nil,
	["Category"] = "kills",
	["Rewards"] = nil,
	["Gamemodes"] = { "Deathmatch" },
	["Rewards"] = {
		{
			["type"] = "Credits",
			["amount"] = 90
		}
	}
})
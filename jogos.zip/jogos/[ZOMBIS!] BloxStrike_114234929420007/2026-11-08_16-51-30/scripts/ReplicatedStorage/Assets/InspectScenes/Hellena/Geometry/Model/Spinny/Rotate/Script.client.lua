-- NIGHT Analyzer | ReplicatedStorage.Assets.InspectScenes.Hellena.Geometry.Model.Spinny.Rotate.Script
-- Script | 10 linhas | 348 bytes | hash 0a5168e0

local v1 = game:GetService("RunService")
local v_u_2 = script.Parent
local v_u_3 = v_u_2.CFrame
local v_u_4 = CFrame.Angles
v1.Heartbeat:Connect(function()
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_4
	if v_u_2:IsDescendantOf(workspace) then
		v_u_2.CFrame = v_u_3 * v_u_4(0, 0, 0.17453292519943295 * time() % 6.283185307179586)
	end
end)
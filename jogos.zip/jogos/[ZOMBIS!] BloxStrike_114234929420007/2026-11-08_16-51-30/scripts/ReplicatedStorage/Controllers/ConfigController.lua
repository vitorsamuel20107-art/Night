-- NIGHT Analyzer | ReplicatedStorage.Controllers.ConfigController
-- ModuleScript | 93 linhas | 2324 bytes | hash bd432376

local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v3 = game:GetService("RunService")
local v_u_4 = require(v2.Database.Custom.ConfigKeys)
local v_u_5 = v3:IsServer()
local v_u_6 = v3:IsStudio()
local v_u_7 = v1.LocalPlayer
local v_u_8 = {}
local v_u_9 = nil
local function v_u_14() -- name: getSnapshot
	-- upvalues: (copy) v_u_5, (ref) v_u_9
	if not v_u_5 then
		return nil
	end
	if v_u_9 then
		return v_u_9
	end
	local v10, v_u_11 = pcall(function()
		return game:GetService("ConfigService"):GetConfigAsync()
	end)
	if not (v10 and v_u_11) then
		return nil
	end
	v_u_9 = v_u_11
	v_u_11.UpdateAvailable:Connect(function()
		-- upvalues: (copy) v_u_11
		local v12 = v_u_11.Refresh
		local v13 = v_u_11
		pcall(v12, v13)
	end)
	return v_u_9
end
function v_u_8.Get(p15) -- name: Get
	-- upvalues: (copy) v_u_6, (copy) v_u_4, (copy) v_u_5, (copy) v_u_14, (copy) v_u_7
	if v_u_6 and v_u_4.Defaults[p15] ~= nil then
		return v_u_4.Defaults[p15]
	elseif v_u_5 then
		local v16 = v_u_14()
		if v16 then
			local v17 = v16.GetValue
			local v18, v19 = pcall(v17, v16, p15)
			if v18 then
				return v19
			else
				return nil
			end
		else
			return nil
		end
	else
		return v_u_7:GetAttribute(p15)
	end
end
function v_u_8.GetRewardMultiplier(p20) -- name: GetRewardMultiplier
	-- upvalues: (copy) v_u_8, (copy) v_u_4
	local v21 = v_u_8.Get
	local v22 = tonumber(v21(p20)) or (v_u_4.Defaults[p20] or 1)
	return math.max(0, v22)
end
function v_u_8.OnChanged(p_u_23, p_u_24) -- name: OnChanged
	-- upvalues: (copy) v_u_5, (copy) v_u_14, (copy) v_u_7
	if v_u_5 then
		local v_u_25 = v_u_14()
		if v_u_25 then
			local v26 = v_u_25.GetValueChangedSignal
			local v27, v28 = pcall(v26, v_u_25, p_u_23)
			if v27 and v28 then
				return v28:Connect(function()
					-- upvalues: (copy) v_u_25, (copy) p_u_23, (copy) p_u_24
					local v29 = v_u_25.GetValue
					local v30 = v_u_25
					local v31 = p_u_23
					local v32, v33 = pcall(v29, v30, v31)
					local v34 = p_u_24
					if not v32 then
						v33 = nil
					end
					v34(v33)
				end)
			else
				return nil
			end
		else
			return nil
		end
	else
		return v_u_7:GetAttributeChangedSignal(p_u_23):Connect(function()
			-- upvalues: (copy) p_u_24, (ref) v_u_7, (copy) p_u_23
			p_u_24(v_u_7:GetAttribute(p_u_23))
		end)
	end
end
return v_u_8
-- NIGHT Analyzer | ReplicatedStorage.Controllers.EndScreenController
-- ModuleScript | 2093 linhas | 60691 bytes | hash 0aeee6e8

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("Players")
local v5 = require(v_u_2.Shared.Janitor)
local v_u_6 = require(v_u_2.Database.Security.Remotes)
local v_u_7 = require(v_u_2.Database.Components.Libraries.Skins)
local v_u_8 = require(v_u_2.Database.Components.Libraries.Cases)
local v_u_9 = require(v_u_2.Controllers.CameraController)
local v_u_10 = require(v_u_2.Controllers.SpectateController)
local v_u_11 = require(v_u_2.Controllers.DataController)
local v_u_12 = require(v_u_2.Controllers.RunServiceController)
local v_u_13 = require(v_u_2.Database.Security.Router)
local v_u_14 = require(v_u_2.Interface.MenuState)
local v_u_15 = require(v_u_2.Shared.CloseButtonRegistry)
local v_u_16 = require(v_u_2.Database.Components.GameState)
local v_u_17 = require(v_u_2.Database.Custom.GameStats.Rarities)
local v_u_18 = require(v_u_2.Database.Custom.GameStats.LevelsIcon)
local v_u_19 = require(v_u_2.Classes.Sound)
local v_u_20 = require(v_u_2.Components.Common.InterfaceAnimations.ActivateButton)
local v_u_21 = require(v_u_2.Components.Common.GetRankTitle)
local v_u_22 = require(v_u_2.Components.Common.CharacterResolver)
local v_u_23 = require(v_u_2.Components.Common.ClientCharacterPresentation)
local v_u_24 = require(v_u_2.Components.Common.IsPlayingTeam)
local v_u_25 = require(v_u_2.Database.Components.Common.AttachGlovesToCharacter)
local v_u_26 = require(v_u_2.Interface.Screens.Gameplay.Middle.Halftime)
local v_u_27 = require(v_u_2.Components.Common.EndScreenTiming)
local v_u_28 = require(v_u_2.Components.Common.CatmullRomPath)
local v_u_29 = UDim2.fromScale(0.5, 0.62)
local v_u_30 = {
	["GuiObject"] = { "BackgroundTransparency" },
	["TextLabel"] = { "TextTransparency", "TextStrokeTransparency" },
	["TextButton"] = { "TextTransparency", "TextStrokeTransparency" },
	["ImageLabel"] = { "ImageTransparency" },
	["ImageButton"] = { "ImageTransparency" },
	["ScrollingFrame"] = { "ScrollBarImageTransparency" },
	["UIStroke"] = { "Transparency" }
}
local v_u_31 = {
	3,
	2,
	4,
	1,
	5
}
local v_u_32 = { "st", "nd", "rd" }
local v_u_33 = CFrame.new(-0.251, 0.806, -0.406) * CFrame.Angles(0, -1.5707963267948966, 1.5707963267948966)
local v_u_34 = v_u_4.LocalPlayer
local v_u_35 = v_u_34:WaitForChild("PlayerGui")
local v_u_36 = workspace.CurrentCamera
local v_u_37 = v_u_2.Assets.Characters
local v_u_38 = {
	{
		["Entrance"] = "rbxassetid://100747011940776",
		["Idle"] = "rbxassetid://100747011940776"
	},
	{
		["Entrance"] = "rbxassetid://103701913618746",
		["Idle"] = "rbxassetid://100955283476946"
	},
	{
		["Entrance"] = "rbxassetid://91396952135880",
		["Idle"] = "rbxassetid://120200138438261"
	},
	{
		["Entrance"] = "rbxassetid://136102955582599",
		["Idle"] = "rbxassetid://74544097369437"
	},
	{
		["Entrance"] = "rbxassetid://71439100344953",
		["Idle"] = "rbxassetid://122693948164334"
	}
}
local v_u_39 = {
	["CT"] = {
		["Character"] = "IDF",
		["Weapon"] = "M4A1-S",
		["Glove"] = "CT Glove"
	},
	["T"] = {
		["Character"] = "Anarchist",
		["Weapon"] = "AK-47",
		["Glove"] = "T Glove"
	}
}
local v_u_40 = {
	["Counter-Terrorists"] = "CT",
	["Terrorists"] = "T"
}
local v_u_41 = v5.new()
local v_u_42 = false
local v_u_43 = false
local v_u_44 = 0
local v_u_45 = true
local v_u_46 = "EndScreen"
local v_u_47 = nil
local v_u_48 = nil
local v_u_49 = {
	["RoundWonCT"] = true,
	["RoundWonT"] = true,
	["RoundLost"] = true,
	["PlayerMVPCT"] = true,
	["PlayerMVPT"] = true,
	["MissionCompleted"] = true
}
local v_u_50 = {
	["MobileButtons"] = true
}
local function v_u_55(p51) -- name: collectPlayingPlayers
	-- upvalues: (copy) v_u_24
	local v52 = {}
	for v53, v54 in pairs(p51) do
		if not v_u_24(v54.Team) then
			continue
		end
		table.insert(v52, {
			["userId"] = v53,
			["data"] = v54
		})
	end
	return v52
end
local function v_u_59() -- name: cleanupDebris
	-- upvalues: (copy) v_u_4, (copy) v_u_23
	local v56 = workspace:FindFirstChild("Debris")
	if v56 then
		for _, v57 in v56:GetChildren() do
			v57:Destroy()
		end
	end
	for _, v58 in v_u_4:GetPlayers() do
		v_u_23.Release(v58, v58.Character)
	end
end
local function v_u_61(p60) -- name: getTransparencyProperty
	return (p60:IsA("TextLabel") or p60:IsA("TextButton")) and "TextTransparency" or ((p60:IsA("ImageLabel") or p60:IsA("ImageButton")) and "ImageTransparency" or (p60:IsA("Frame") and "BackgroundTransparency" or (p60:IsA("UIStroke") and "Transparency" or nil)))
end
local function v_u_65(p62, p63) -- name: tweenElementTransparency
	-- upvalues: (copy) v_u_61, (copy) v_u_3
	local v64 = v_u_61(p62)
	if v64 then
		v_u_3:Create(p62, TweenInfo.new(0.5), {
			[v64] = p63
		}):Play()
	end
end
local function v_u_68(p66) -- name: shouldSkipFade
	if p66:GetAttribute("SkipFade") then
		return true
	end
	local v67 = p66.Parent
	while v67 and v67:IsA("GuiObject") do
		if v67:GetAttribute("SkipFade") then
			return true
		end
		v67 = v67.Parent
	end
	return false
end
local function v_u_73(p69, p70) -- name: fadeFrame
	-- upvalues: (copy) v_u_68, (copy) v_u_3, (copy) v_u_65
	local v71
	if v_u_68(p69) then
		v71 = nil
	else
		v71 = v_u_3:Create(p69, TweenInfo.new(0.5), {
			["BackgroundTransparency"] = p70
		})
	end
	for _, v72 in p69:GetDescendants() do
		if v_u_68(v72) then
			continue
		end
		v_u_65(v72, p70)
	end
	if v71 then
		v71:Play()
	end
	return v71
end
local function v_u_77(p74) -- name: fadeInFrame
	-- upvalues: (copy) v_u_68, (copy) v_u_61, (copy) v_u_73
	if not v_u_68(p74) then
		p74.BackgroundTransparency = 1
	end
	for _, v75 in p74:GetDescendants() do
		if v_u_68(v75) then
			continue
		end
		local v76 = v_u_61(v75)
		if not v76 then
			continue
		end
		v75[v76] = 1
	end
	p74.Visible = true
	return v_u_73(p74, 0)
end
local function v_u_81(p78) -- name: storeFrameTransparency
	local v79 = {}
	for _, v80 in p78:GetDescendants() do
		if not v80:IsA("UIStroke") then
			continue
		end
		v79[v80] = v80.Transparency
	end
	return {
		["BackgroundTransparency"] = p78.BackgroundTransparency,
		["Strokes"] = v79
	}
end
local function v_u_102(p82) -- name: populateLevelFrame
	-- upvalues: (copy) v_u_35, (ref) v_u_48, (copy) v_u_11, (copy) v_u_34, (copy) v_u_21, (copy) v_u_18, (copy) v_u_81
	local v83 = v_u_35:FindFirstChild("MainGui")
	if v83 then
		v83 = v83:FindFirstChild("Gameplay")
	end
	if v83 then
		v83 = v83:FindFirstChild("Middle")
	end
	if v83 then
		v83 = v83:FindFirstChild("EndScreen")
	end
	if not v83 then
		return nil
	end
	local v84 = v83:FindFirstChild("Level")
	if not v84 then
		return nil
	end
	local v85 = v_u_48 or v_u_11.Get(v_u_34, "Level")
	if not v85 then
		return nil
	end
	local v86 = v85.Level or 1
	local v87 = v85.Experience or 0
	local v88 = v85.NextExperienceRequirement or 1000
	local v89 = ("[%* Rank %*]"):format(v_u_21(v86), v86)
	local v90 = v84:FindFirstChild("TextLabel")
	if v90 then
		v90.Text = v89
	end
	local v91 = v84:FindFirstChild("Rank")
	if v91 then
		v91.Image = v_u_18[tostring(v86)] or ""
	end
	local v92 = v84:FindFirstChild("LevelBar")
	if not v92 then
		return nil
	end
	local v93 = v92:FindFirstChild("Current")
	local v94 = v92:FindFirstChild("Earned")
	if not (v93 and v94) then
		return nil
	end
	local v95 = v84:FindFirstChild("CurrentInfo", true)
	local v96 = v84:FindFirstChild("EarnedInfo", true)
	if not (v95 and v96) then
		return nil
	end
	for _, v97 in {
		v93,
		v94,
		v95,
		v96
	} do
		v97:SetAttribute("SkipFade", true)
	end
	local v98 = ("%*xp"):format(v87)
	local v99 = v95:FindFirstChild("Amount")
	if v99 then
		v99.Text = v98
	end
	local v100 = ("+%*xp"):format(p82)
	local v101 = v96:FindFirstChild("Amount")
	if v101 then
		v101.Text = v100
	end
	return {
		["currentXP"] = v87,
		["xpEarned"] = p82,
		["nextLevelXP"] = math.max(v88, 1),
		["currentLevel"] = v86,
		["barHeight"] = v93.Size.Y,
		["levelBar"] = v92,
		["levelFrame"] = v84,
		["currentBar"] = v93,
		["earnedBar"] = v94,
		["currentInfo"] = v95,
		["earnedInfo"] = v96,
		["currentInfoTransparency"] = v_u_81(v95),
		["earnedInfoTransparency"] = v_u_81(v96)
	}
end
local function v_u_113(p103, p104, p105, p106) -- name: tweenInfoToBarEnd
	-- upvalues: (copy) v_u_3
	local v107 = p103.Position
	local v108 = p104.AbsolutePosition.X + p105 * p104.AbsoluteSize.X
	local v109 = p103.Parent
	local v110 = v109 and v109.AbsolutePosition.X or 0
	local v111 = p103.AnchorPoint.X * p103.AbsoluteSize.X
	local v112 = v108 - v110 + v111
	return v_u_3:Create(p103, p106, {
		["Position"] = UDim2.new(0, v112, v107.Y.Scale, v107.Y.Offset)
	})
end
local function v_u_123(p114, p115, p116, p117, p118, p119) -- name: playBarTween
	-- upvalues: (copy) v_u_3, (copy) v_u_19, (copy) v_u_36
	local v120 = v_u_3:Create(p114, p116, {
		["Size"] = p115
	})
	if p118 then
		local v121 = {
			["Parent"] = nil,
			["Name"] = "XP Bar Fill",
			["Parent"] = v_u_36
		}
		local v122 = v_u_19.new("Interface"):play(v121)
		if v122 and p119 then
			v122.PlaybackSpeed = p119
		end
	end
	v120:Play()
	p117:Play()
	v120.Completed:Wait()
end
local function v_u_142(p124, p125, p126, p127, p128) -- name: tweenInfoToBarEndWithOverlapCheck
	-- upvalues: (copy) v_u_3
	local v129 = p126.AbsolutePosition.X + p127 * p126.AbsoluteSize.X
	local v130 = p124.Parent
	local v131 = v130 and v130.AbsolutePosition.X or 0
	local v132 = p124.AnchorPoint.X * p124.AbsoluteSize.X
	local v133 = v129 - v131 + v132
	local v134 = p125.AbsolutePosition.Y
	local v135 = p125.AbsolutePosition.X + p125.AbsoluteSize.X
	local v136 = p124.Parent.AbsolutePosition.X
	local v137 = p124.AnchorPoint.X * p124.AbsoluteSize.X
	if v136 + v133 - v137 < v135 + 5 then
		v134 = v134 + p125.AbsoluteSize.Y + -2
	end
	local v138 = UDim2.new
	local v139 = p124.Parent
	local v140 = v139 and v139.AbsolutePosition.Y or 0
	local v141 = p124.AnchorPoint.Y * p124.AbsoluteSize.Y
	return v_u_3:Create(p124, p128, {
		["Position"] = v138(0, v133, 0, v134 - v140 + v141)
	})
end
local function v_u_242(p143) -- name: animateLevelBar
	-- upvalues: (ref) v_u_42, (copy) v_u_113, (copy) v_u_123, (copy) v_u_142, (copy) v_u_19, (copy) v_u_36, (copy) v_u_21, (copy) v_u_18, (copy) v_u_3
	if v_u_42 then
		local v144 = p143.currentXP / p143.nextLevelXP
		local v145 = math.clamp(v144, 0, 1)
		local v146 = p143.currentXP + p143.xpEarned
		local v147 = v146 / p143.nextLevelXP
		local v148 = math.clamp(v147, 0, 1)
		local v149 = p143.nextLevelXP <= v146
		p143.currentBar.Visible = false
		p143.earnedBar.Visible = false
		local v150 = p143.currentBar
		local v151 = p143.barHeight
		v150.Size = UDim2.new(0, 0, v151.Scale, v151.Offset)
		local v152 = p143.earnedBar
		local v153 = p143.barHeight
		v152.Size = UDim2.new(0, 0, v153.Scale, v153.Offset)
		p143.currentInfo.Visible = false
		p143.earnedInfo.Visible = false
		local v154 = p143.currentInfo
		local v155 = p143.currentInfoTransparency
		v154.BackgroundTransparency = v155.BackgroundTransparency
		for v156, v157 in pairs(v155.Strokes) do
			if not (v156 and v156.Parent) then
				continue
			end
			v156.Transparency = v157
		end
		local v158 = p143.earnedInfo
		local v159 = p143.earnedInfoTransparency
		v158.BackgroundTransparency = v159.BackgroundTransparency
		for v160, v161 in pairs(v159.Strokes) do
			if not (v160 and v160.Parent) then
				continue
			end
			v160.Transparency = v161
		end
		local v162 = p143.levelBar
		local v163 = p143.currentInfo
		local v164 = v162.AbsolutePosition.X + 0 * v162.AbsoluteSize.X
		local v165 = v163.Parent
		local v166 = v165 and v165.AbsolutePosition.X or 0
		local v167 = v163.AnchorPoint.X * v163.AbsoluteSize.X
		local v168 = v164 - v166 + v167
		local v169 = p143.levelBar
		local v170 = p143.earnedInfo
		local v171 = v169.AbsolutePosition.X + 0 * v169.AbsoluteSize.X
		local v172 = v170.Parent
		local v173 = v172 and v172.AbsolutePosition.X or 0
		local v174 = v170.AnchorPoint.X * v170.AbsoluteSize.X
		local v175 = v171 - v173 + v174
		local v176 = p143.currentInfo.Position
		local v177 = p143.earnedInfo.Position
		p143.currentInfo.Position = UDim2.new(0, v168, v176.Y.Scale, v176.Y.Offset)
		p143.earnedInfo.Position = UDim2.new(0, v175, v177.Y.Scale, v177.Y.Offset)
		task.wait(0.5)
		if v_u_42 then
			p143.currentBar.Visible = true
			p143.currentInfo.Visible = true
			if v145 > 0 then
				local v178 = TweenInfo.new(0.75, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
				local v179 = v_u_113(p143.currentInfo, p143.levelBar, v145, v178)
				local v180 = v_u_123
				local v181 = p143.currentBar
				local v182 = p143.barHeight
				v180(v181, UDim2.new(v145, 0, v182.Scale, v182.Offset), v178, v179, true)
				if not v_u_42 then
					return
				end
			end
			if p143.xpEarned <= 0 then
				return
			else
				task.wait(0.6)
				if v_u_42 then
					local v183 = p143.earnedBar
					local v184 = p143.barHeight
					v183.Size = UDim2.new(v145, 0, v184.Scale, v184.Offset)
					p143.earnedBar.Visible = true
					p143.earnedInfo.Visible = true
					local v185 = p143.levelBar
					local v186 = p143.earnedInfo
					local v187 = v185.AbsolutePosition.X + v145 * v185.AbsoluteSize.X
					local v188 = v186.Parent
					local v189 = v188 and v188.AbsolutePosition.X or 0
					local v190 = v186.AnchorPoint.X * v186.AbsoluteSize.X
					local v191 = v187 - v189 + v190
					local v192 = p143.currentInfo
					local v193 = p143.earnedInfo
					local v194 = v192.AbsolutePosition.Y
					local v195 = v192.AbsolutePosition.X + v192.AbsoluteSize.X
					local v196 = v193.Parent.AbsolutePosition.X
					local v197 = v193.AnchorPoint.X * v193.AbsoluteSize.X
					if v196 + v191 - v197 < v195 + 5 then
						v194 = v194 + v192.AbsoluteSize.Y + -2
					end
					local v198 = UDim2.new
					local v199 = v193.Parent
					local v200 = v199 and v199.AbsolutePosition.Y or 0
					local v201 = v193.AnchorPoint.Y * v193.AbsoluteSize.Y
					local v202 = v198(0, v191, 0, v194 - v200 + v201)
					p143.earnedInfo.Position = v202
					if v149 then
						local v203 = TweenInfo.new(0.375, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
						local v204 = v_u_142(p143.earnedInfo, p143.currentInfo, p143.levelBar, 1, v203)
						local v205 = v_u_123
						local v206 = p143.earnedBar
						local v207 = p143.barHeight
						v205(v206, UDim2.new(1, 0, v207.Scale, v207.Offset), v203, v204, true, 1.15)
						if v_u_42 then
							local v208 = {
								["Parent"] = nil,
								["Name"] = "Level Up",
								["Parent"] = v_u_36
							}
							v_u_19.new("Interface"):play(v208)
							local v209 = (v146 - p143.nextLevelXP) / p143.nextLevelXP
							local v210 = math.clamp(v209, 0, 1)
							local v211 = p143.levelFrame
							local v212 = p143.currentLevel + 1
							local v213 = ("[%* Rank %*]"):format(v_u_21(v212), v212)
							local v214 = v211:FindFirstChild("TextLabel")
							if v214 then
								v214.Text = v213
							end
							local v215 = v211:FindFirstChild("Rank")
							if v215 then
								v215.Image = v_u_18[tostring(v212)] or ""
							end
							local v216 = p143.currentBar
							local v217 = p143.barHeight
							v216.Size = UDim2.new(0, 0, v217.Scale, v217.Offset)
							local v218 = p143.earnedBar
							local v219 = p143.barHeight
							v218.Size = UDim2.new(0, 0, v219.Scale, v219.Offset)
							p143.currentInfo.Visible = false
							local v220 = p143.levelBar
							local v221 = p143.earnedInfo
							local v222 = v220.AbsolutePosition.X + 0 * v220.AbsoluteSize.X
							local v223 = v221.Parent
							local v224 = v223 and v223.AbsolutePosition.X or 0
							local v225 = v221.AnchorPoint.X * v221.AbsoluteSize.X
							local v226 = v222 - v224 + v225
							local v227 = p143.earnedInfo
							local v228 = p143.currentInfo.AbsolutePosition.Y
							local v229 = v227.Parent
							local v230 = v229 and v229.AbsolutePosition.Y or 0
							local v231 = v227.AnchorPoint.Y * v227.AbsoluteSize.Y
							local v232 = v228 - v230 + v231
							p143.earnedInfo.Position = UDim2.new(0, v226, 0, v232)
							local v233 = v_u_113(p143.earnedInfo, p143.levelBar, v210, v203)
							local v234 = p143.earnedBar
							local v235 = p143.barHeight
							local v236 = v_u_3:Create(v234, v203, {
								["Size"] = UDim2.new(v210, 0, v235.Scale, v235.Offset)
							})
							v236:Play()
							v233:Play()
							v236.Completed:Wait()
						end
					else
						local v237 = TweenInfo.new(0.75, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
						local v238 = v_u_142(p143.earnedInfo, p143.currentInfo, p143.levelBar, v148, v237)
						local v239 = v_u_123
						local v240 = p143.earnedBar
						local v241 = p143.barHeight
						v239(v240, UDim2.new(v148, 0, v241.Scale, v241.Offset), v237, v238, true, 1.15)
						return
					end
				else
					return
				end
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_248(p243) -- name: getItemIcon
	-- upvalues: (copy) v_u_8, (copy) v_u_7
	local v244 = not p243.Type and "" or string.lower(p243.Type)
	local v245 = p243.Name
	if v244 == "credits" then
		return "rbxassetid://115958498634807"
	end
	if v244 == "case" or (v244 == "sticker capsule" or (v244 == "charm pack" or v244 == "charm capsule")) then
		local v246 = v_u_8.GetCaseByName(v245)
		if v246 and v246.imageAssetId then
			return v246.imageAssetId
		end
	end
	local v247 = p243.Skin and (v245 and v_u_7.GetSkinInformation(v245, p243.Skin))
	if v247 then
		if v247.wearImages and v247.wearImages[1] then
			return v247.wearImages[1].assetId
		end
		if v247.charmImages and v247.charmImages[1] then
			return v247.charmImages[1].assetId
		end
		if v247.imageAssetId then
			return v247.imageAssetId
		end
	end
	return "rbxassetid://18822070027"
end
local function v_u_251(p249) -- name: clearDropItems
	for _, v250 in p249:GetChildren() do
		if not v250:IsA("Frame") or v250.Name == "ItemTemplate" then
			continue
		end
		v250:Destroy()
	end
end
local function v_u_274(p252) -- name: displayDrops
	-- upvalues: (ref) v_u_42, (copy) v_u_35, (copy) v_u_251, (copy) v_u_248, (copy) v_u_17, (copy) v_u_77, (copy) v_u_3, (copy) v_u_41
	if v_u_42 and (p252 and #p252 ~= 0) then
		local v253 = v_u_35:FindFirstChild("MainGui")
		if v253 then
			v253 = v253:FindFirstChild("Gameplay")
		end
		if v253 then
			v253 = v253:FindFirstChild("Middle")
		end
		if v253 then
			v253 = v253:FindFirstChild("EndScreen")
		end
		if v253 then
			local v254 = v253:FindFirstChild("Drops")
			local v255
			if v254 then
				v255 = v254:FindFirstChild("Container")
			else
				v255 = v254
			end
			local v256
			if v255 then
				v256 = v255:FindFirstChild("ItemTemplate")
			else
				v256 = v255
			end
			if v256 then
				v255:SetAttribute("SkipFade", true)
				v256.Visible = false
				v_u_251(v255)
				v254.Visible = false
				task.wait(0.8)
				if v_u_42 then
					local v257 = {}
					for v258, v259 in ipairs(p252) do
						local v260 = v259.reward
						local v261 = v260.type == "credits"
						local v262 = v260.inventoryItem
						if not (v261 or v262) then
							continue
						end
						local v263 = v256:Clone()
						v263.Name = "Drop_" .. v258
						v263.Visible = false
						v263.Parent = v255
						local v264 = v263:FindFirstChild("Content")
						if v264 then
							local v265 = v264:FindFirstChild("Icon")
							if v265 then
								v265.Image = v261 and "rbxassetid://115958498634807" or v_u_248(v262)
							end
							local v266 = v264:FindFirstChild("amount") or v264:FindFirstChild("Amount")
							if v266 then
								if v261 and v260.amount then
									v266.Visible = true
									v266.Text = ("x%*"):format(v260.amount)
								else
									v266.Visible = false
								end
							end
							local v267 = v264:FindFirstChild("RarityFrame")
							if v267 then
								v267 = v267:FindFirstChild("UIGradient")
							end
							if v267 then
								if v261 then
									v262 = "Rare"
								elseif v262 then
									v262 = v262.Rarity
								end
								if v262 then
									v262 = v_u_17[v262]
								end
								if v262 and v262.ColorSequence then
									v267.Color = v262.ColorSequence
								end
							end
							local v268 = v264.Size
							v264.Size = UDim2.new(v268.X.Scale * 1.25, v268.X.Offset * 1.25, v268.Y.Scale * 1.25, v268.Y.Offset * 1.25)
							local v269 = v263:FindFirstChild("Player", true)
							if v269 and v259.userId > 0 then
								v269.Image = ("rbxthumb://type=AvatarHeadShot&id=%*&w=150&h=150"):format(v259.userId)
							end
							table.insert(v257, {
								["item"] = v263,
								["content"] = v264,
								["originalSize"] = v268
							})
						else
							v263:Destroy()
						end
					end
					if #v257 == 0 then
						return
					else
						v_u_77(v254)
						task.wait(0.5)
						if v_u_42 then
							local v_u_270 = TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
							for v271, v_u_272 in ipairs(v257) do
								task.delay((v271 - 1) * 0.35, function()
									-- upvalues: (ref) v_u_42, (copy) v_u_272, (ref) v_u_3, (copy) v_u_270, (ref) v_u_41
									if v_u_42 then
										v_u_272.item.Visible = true
										local v273 = v_u_3:Create(v_u_272.content, v_u_270, {
											["Size"] = v_u_272.originalSize
										})
										v_u_41:Add(v273, "Cancel")
										v273:Play()
									end
								end)
							end
						end
					end
				else
					return
				end
			else
				return
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_278(p275, p276) -- name: recordPanelVisibility
	if p275 then
		for _, v277 in p275:GetChildren() do
			if not (v277:IsA("Frame") or v277:IsA("CanvasGroup")) then
				continue
			end
			p276[v277.Name] = v277.Visible
		end
	end
end
local function v_u_284(p279, p280, p281) -- name: applyPanelVisibility
	for _, v282 in p279:GetChildren() do
		if not (v282:IsA("Frame") or v282:IsA("CanvasGroup")) then
			continue
		end
		local v283 = p280[v282.Name]
		if v283 == nil or p281 and p281[v282.Name] then
			continue
		end
		v282.Visible = v283
	end
end
local function v_u_291(p285) -- name: captureVisibilitySnapshot
	-- upvalues: (copy) v_u_278, (ref) v_u_47
	local v286 = p285:FindFirstChild("Gameplay")
	local v287 = p285:FindFirstChild("Menu")
	local v288
	if v286 then
		v288 = v286:FindFirstChild("Middle") or nil
	else
		v288 = nil
	end
	local v289 = {}
	local v290
	if v286 then
		v290 = v286.Visible or false
	else
		v290 = false
	end
	v289.GameplayVisible = v290
	v289.MenuVisible = v287 and v287.Visible or false
	v289.GameplayChildren = {}
	v289.MiddleChildren = {}
	v_u_278(v286, v289.GameplayChildren)
	v_u_278(v288, v289.MiddleChildren)
	v_u_47 = v289
end
local function v_u_300(p292, p293) -- name: restoreVisibilitySnapshot
	-- upvalues: (ref) v_u_47, (copy) v_u_284, (copy) v_u_50, (copy) v_u_49
	if v_u_47 then
		local v294 = v_u_47
		v_u_47 = nil
		local v295 = p292:FindFirstChild("Gameplay")
		local v296 = p292:FindFirstChild("Menu")
		local v297
		if v295 then
			v297 = v295:FindFirstChild("Middle") or nil
		else
			v297 = nil
		end
		if v296 then
			v296.Visible = v294.MenuVisible
		end
		if v295 then
			v295.Visible = v294.GameplayVisible
			v_u_284(v295, v294.GameplayChildren)
		end
		if v297 then
			v_u_284(v297, v294.MiddleChildren, v_u_50)
			if p293 then
				for v298 in pairs(v_u_49) do
					local v299 = v297:FindFirstChild(v298)
					if not (v299 and (v299:IsA("Frame") or v299:IsA("CanvasGroup"))) then
						continue
					end
					v299.Visible = false
				end
			end
		end
	end
end
local function v_u_309(p301) -- name: enforceEndScreenVisibility
	-- upvalues: (ref) v_u_46, (copy) v_u_14
	local v302 = v_u_46 == "Halftime"
	if p301:FindFirstChild("Menu") then
		v_u_14.HideMenu()
	end
	local v303 = p301:FindFirstChild("Gameplay")
	if v303 then
		local v304 = v303:FindFirstChild("Middle")
		local v305
		if v304 then
			v305 = v304:FindFirstChild("EndScreen") or nil
		else
			v305 = nil
		end
		local v306
		if v304 then
			v306 = v304:FindFirstChild("Halftime") or nil
		else
			v306 = nil
		end
		v303.Visible = true
		for _, v307 in v303:GetChildren() do
			if not (v307:IsA("Frame") or v307:IsA("CanvasGroup")) then
				continue
			end
			v307.Visible = v307 == v304
		end
		if v304 then
			v304.Visible = true
			for _, v308 in v304:GetChildren() do
				if not (v308:IsA("Frame") or v308:IsA("CanvasGroup")) then
					continue
				end
				if v308 == v305 then
					v308.Visible = not v302
				elseif v308 == v306 then
					v308.Visible = v302
				else
					v308.Visible = false
				end
			end
			if v305 then
				v305.Visible = not v302
			end
			if v306 then
				v306.Visible = v302
			end
		end
	else
		return
	end
end
local v_u_310 = {
	["Victory"] = {
		["Background"] = Color3.fromRGB(11, 97, 31),
		["Glow"] = Color3.fromRGB(46, 158, 78),
		["Pattern"] = Color3.fromRGB(134, 255, 78),
		["Stroke"] = Color3.fromRGB(48, 127, 48)
	},
	["Defeat"] = {
		["Background"] = Color3.fromRGB(83, 9, 9),
		["Glow"] = Color3.fromRGB(158, 14, 14),
		["Pattern"] = Color3.fromRGB(255, 53, 53),
		["Stroke"] = Color3.fromRGB(127, 48, 48)
	}
}
local function v_u_325(p311, p312, p313, p314, p315) -- name: setupResultFrame
	-- upvalues: (copy) v_u_61
	if p311 then
		p311.BackgroundTransparency = 0
		for _, v316 in p311:GetDescendants() do
			local v317 = v_u_61(v316)
			if not v317 then
				continue
			end
			v316[v317] = 0
		end
		p311.Visible = p312
		local v318 = p311:FindFirstChild("Score")
		if v318 then
			v318.Visible = p314 ~= nil
			v318.BackgroundColor3 = p313.Background
			local v319 = v318:FindFirstChild("Glow")
			if v319 and v319:IsA("ImageLabel") then
				v319.ImageColor3 = p313.Glow
			end
			local v320 = v318:FindFirstChild("Pattern")
			if v320 and v320:IsA("ImageLabel") then
				v320.ImageColor3 = p313.Pattern
			end
			local v321 = v318:FindFirstChildOfClass("UIStroke")
			if v321 then
				v321.Color = p313.Stroke
			end
			local v322 = v318:FindFirstChild("TextLabel")
			if v322 and p314 then
				v322.Text = p314
			end
		end
		local v323 = p311:FindFirstChild("TextLabel")
		if v323 then
			v323.Text = p315
			local v324 = v323:GetAttribute("AuthoredPosition")
			if not v324 then
				v324 = v323.Position
				v323:SetAttribute("AuthoredPosition", v324)
			end
			if not p314 then
				v324 = UDim2.new(v324.X, UDim.new(0.5, 0))
			end
			v323.Position = v324
		end
	end
end
local function v_u_350(p326) -- name: showEndScreenUI
	-- upvalues: (copy) v_u_35, (copy) v_u_291, (copy) v_u_9, (copy) v_u_24, (copy) v_u_26, (copy) v_u_41, (copy) v_u_12, (copy) v_u_309, (copy) v_u_325, (copy) v_u_310
	local v327 = p326.isDraw
	local v328 = p326.didWin
	local v_u_329 = v_u_35:FindFirstChild("MainGui")
	if v_u_329 then
		v_u_291(v_u_329)
		v_u_9.setForceLockOverride("EndScreen", true)
		v_u_9.setPerspective(false, true)
		local v330 = v_u_329:FindFirstChild("Menu")
		if v330 then
			v330.Visible = false
			v_u_9.setForceLockOverride("Menu", false)
		end
		local v331 = v_u_329:FindFirstChild("Gameplay")
		if v331 then
			v331.Visible = true
			for _, v332 in v331:GetChildren() do
				if not (v332:IsA("Frame") or v332:IsA("CanvasGroup")) then
					continue
				end
				v332.Visible = false
			end
			local v333 = v331:FindFirstChild("Middle")
			if v333 then
				for _, v334 in v333:GetChildren() do
					if not (v334:IsA("Frame") or v334:IsA("CanvasGroup")) then
						continue
					end
					v334.Visible = false
				end
				v333.Visible = true
				local v335 = v333:FindFirstChild("EndScreen")
				if p326.overlayMode == "Halftime" then
					if v335 then
						v335.Visible = false
					end
					if v333:FindFirstChild("Halftime") and v_u_24(p326.halftimeTeam) then
						v_u_26.Show(p326.halftimeTeam)
					else
						v_u_26.Hide()
					end
					v_u_41:Add(v_u_12.BindToRenderStep("EndScreenController.VisibilityLock", function()
						-- upvalues: (ref) v_u_309, (copy) v_u_329
						v_u_309(v_u_329)
					end), "Disconnect", "EndScreenVisibilityLock")
					return
				else
					v_u_26.Hide()
					if v335 then
						local v336 = v335:FindFirstChild("MapVote")
						if v336 then
							v336.Visible = false
						end
						local v337 = v335:FindFirstChild("Top")
						if v337 then
							v337.Visible = false
						end
						v335.Visible = true
						local v338 = p326.tScore
						local v339 = p326.ctScore
						if v327 or p326.winningTeam == "Counter-Terrorists" then
							v338 = p326.ctScore
							v339 = p326.tScore
						end
						local v340
						if p326.hideScore then
							v340 = nil
						else
							v340 = p326.scoreTextOverride or ("<b>%*</b> - %*"):format(v338, v339)
						end
						v_u_325(v335:FindFirstChild("Victory"), v327 or v328, v_u_310.Victory, v340, v327 and "Draw" or "Victory")
						local v341 = v_u_325
						local v342 = v335:FindFirstChild("Defeat")
						local v343 = not v327
						if v343 then
							v343 = not v328
						end
						v341(v342, v343, v_u_310.Defeat, v340, v327 and "Draw" or "Defeat")
						local v344 = p326.showAccolades
						local v345 = v335:FindFirstChild("MVP")
						if v345 then
							v345.Visible = v344
						end
						local v346 = p326.returnToMenu
						local v347 = v335:FindFirstChild("Close")
						if v347 then
							v347.Visible = v346
						end
						local v348 = v335:FindFirstChild("Level")
						if v348 then
							v348.Visible = false
						end
						local v349 = v335:FindFirstChild("Drops")
						if v349 then
							v349.Visible = false
						end
						v_u_41:Add(v_u_12.BindToRenderStep("EndScreenController.VisibilityLock", function()
							-- upvalues: (ref) v_u_309, (copy) v_u_329
							v_u_309(v_u_329)
						end), "Disconnect", "EndScreenVisibilityLock")
					end
				end
			else
				return
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_354(p351) -- name: hideMvpSlots
	for v352 = 1, 5 do
		local v353 = p351:FindFirstChild((tostring(v352)))
		if not v353 then
			continue
		end
		v353.Visible = false
	end
end
local function v_u_369() -- name: hideEndScreenUI
	-- upvalues: (copy) v_u_35, (copy) v_u_26, (copy) v_u_354, (copy) v_u_251
	local v355 = v_u_35:FindFirstChild("MainGui")
	if v355 then
		v355 = v355:FindFirstChild("Gameplay")
	end
	if v355 then
		v355 = v355:FindFirstChild("Middle")
	end
	if v355 then
		v355 = v355:FindFirstChild("EndScreen")
	end
	if v355 then
		v355.Visible = false
		v_u_26.Hide()
		local v356 = v355:FindFirstChild("Victory")
		if v356 then
			v356.Visible = false
		end
		local v357 = v355:FindFirstChild("Defeat")
		if v357 then
			v357.Visible = false
		end
		local v358 = v355:FindFirstChild("Level")
		if v358 then
			v358.Visible = false
			local v359 = v358:FindFirstChild("LevelBar")
			if v359 then
				local v360 = v359:FindFirstChild("Current")
				if v360 then
					v360:SetAttribute("SkipFade", nil)
				end
				local v361 = v359:FindFirstChild("Earned")
				if v361 then
					v361:SetAttribute("SkipFade", nil)
				end
			end
			local v362 = v358:FindFirstChild("CurrentInfo", true)
			if v362 then
				v362:SetAttribute("SkipFade", nil)
			end
			local v363 = v358:FindFirstChild("EarnedInfo", true)
			if v363 then
				v363:SetAttribute("SkipFade", nil)
			end
		end
		local v364 = v355:FindFirstChild("MVP")
		if v364 then
			v364.Visible = false
			v_u_354(v364)
		end
		local v365 = v355:FindFirstChild("Drops")
		if v365 then
			v365.Visible = false
			local v366 = v365:FindFirstChild("Container")
			if v366 then
				v366:SetAttribute("SkipFade", nil)
				v_u_251(v366)
			end
		end
		local v367 = v355:FindFirstChild("MapVote")
		if v367 then
			v367.Visible = true
		end
		local v368 = v355:FindFirstChild("Top")
		if v368 then
			v368.Visible = true
		end
	end
end
local function v_u_373(p370) -- name: findInventoryItem
	-- upvalues: (copy) v_u_11, (copy) v_u_34
	local v371 = v_u_11.Get(v_u_34, "Inventory")
	if type(v371) ~= "table" then
		return nil
	end
	for _, v372 in ipairs(v371) do
		if not v372 or v372._id ~= p370 then
			continue
		end
		return v372
	end
	return nil
end
local function v_u_388(p374, p375, p376) -- name: attachGlovesToCharacter
	-- upvalues: (copy) v_u_11, (copy) v_u_34, (copy) v_u_373, (copy) v_u_39, (copy) v_u_7, (copy) v_u_25
	local v377 = nil
	local v378 = nil
	local v379 = nil
	if p376 then
		v377 = p376.Name
		v378 = p376.Skin
		v379 = p376.Float
	else
		local v380 = v_u_11.Get(v_u_34, "Loadout")
		local v381
		if type(v380) == "table" then
			v381 = v380[p375 == "CT" and "Counter-Terrorists" or "Terrorists"]
			if type(v381) ~= "table" then
				v381 = nil
			end
		else
			v381 = nil
		end
		local v382 = v381 and v381.Equipped
		if v382 then
			v382 = v381.Equipped["Equipped Gloves"]
		end
		if type(v382) ~= "string" or v382 == "" then
			v382 = nil
		end
		if v382 then
			local v383 = v_u_373(v382)
			if v383 then
				v377 = v383.Name
				v378 = v383.Skin
				v379 = v383.Float
			end
		end
	end
	local v384 = v377 or v_u_39[p375].Glove
	local v385
	if v378 and (v378 ~= "" and v379 ~= nil) then
		v385 = v_u_7.GetCharacterGloves(v384, v378, v379) or nil
	else
		v385 = nil
	end
	local v386
	if v385 then
		v386 = v385:GetChildren()
	else
		v386 = v_u_7.GetCharacterGloveParts(v384)
		if not v386 then
			return
		end
	end
	local v387 = p374:FindFirstChild("CharacterArmor") or Instance.new("Folder")
	v387.Name = "CharacterArmor"
	v387.Parent = p374
	v_u_25(v386, p374, v387)
end
local function v_u_398(p389, p390) -- name: getEquippedWeaponFromLoadout
	-- upvalues: (copy) v_u_11, (copy) v_u_34
	local v391 = v_u_11.Get(v_u_34, "Loadout")
	local v392
	if type(v391) == "table" then
		v392 = v391[p389 == "CT" and "Counter-Terrorists" or "Terrorists"]
		if type(v392) ~= "table" then
			v392 = nil
		end
	else
		v392 = nil
	end
	local v393 = v392 and v392.Loadout
	if v393 then
		v393 = v392.Loadout.Rifles
	end
	if v393 then
		local v394 = v393.Options
		if type(v394) == "table" then
			local v395 = v_u_11.Get(v_u_34, "Inventory")
			if type(v395) ~= "table" then
				return nil
			end
			for _, v396 in ipairs(v393.Options) do
				if type(v396) ~= "string" or v396 == "" then
					continue
				end
				for _, v397 in ipairs(v395) do
					if not v397 or (v397._id ~= v396 or v397.Name ~= p390) then
						continue
					end
					return {
						["Skin"] = v397.Skin,
						["Float"] = v397.Float,
						["StatTrack"] = v397.StatTrack,
						["NameTag"] = v397.NameTag
					}
				end
			end
			return nil
		end
	end
	return nil
end
local function v_u_412(p399, p400, p401) -- name: attachWeaponToCharacter
	-- upvalues: (copy) v_u_39, (copy) v_u_398, (copy) v_u_7, (copy) v_u_33
	local v402 = v_u_39[p400].Weapon
	local v403 = nil
	if not p401 or (not p401.Skin or p401.Skin == "") then
		p401 = v_u_398(p400, v402)
	end
	if p401 and (p401.Skin and p401.Skin ~= "") then
		v403 = v_u_7.GetCharacterModel(v402, p401.Skin, p401.Float, p401.StatTrack, p401.NameTag)
	end
	local v404 = v403 or v_u_7.GetBaseWeaponModel(v402, "Character")
	if v404 then
		v404.Name = v402
		local v405 = p399:FindFirstChild("RightHand")
		if v405 then
			if not v404.PrimaryPart then
				local v406 = v404:FindFirstChild("Weapon")
				if v406 then
					v406 = v406:FindFirstChild("Insert")
				end
				if not v406 then
					v404:Destroy()
					return
				end
				v404.PrimaryPart = v406
			end
			for _, v407 in v404:GetDescendants() do
				if not v407:IsA("BasePart") then
					continue
				end
				v407.CanCollide = false
				v407.CanQuery = false
				v407.CanTouch = false
				v407.Anchored = false
				v407.Massless = true
			end
			v404.Parent = p399
			local v408 = Instance.new("Motor6D")
			v408.Name = "WeaponAttachment"
			v408.Part0 = v405
			v408.Part1 = v404.PrimaryPart
			v408.Parent = v405
			if v402 == "AK-47" then
				v408.C0 = v_u_33
			else
				local v409 = v404:FindFirstChild("Properties")
				if v409 then
					local v410 = v409:FindFirstChild("C0")
					local v411 = v409:FindFirstChild("C1")
					if v410 then
						v408.C0 = v410.Value
					end
					if v411 then
						v408.C1 = v411.Value
					end
				end
			end
		else
			v404:Destroy()
			return
		end
	else
		return
	end
end
local function v_u_420(p413, p414) -- name: getEquippedBadgeIcon
	-- upvalues: (copy) v_u_11, (copy) v_u_7
	local v415, v416 = v_u_11.Get(p413, "Loadout", "Inventory")
	if v415 then
		if v416 then
			v415 = v415[p414]
		else
			v415 = v416
		end
	end
	local v417 = v415 and v415.Equipped
	if v417 then
		v417 = v415.Equipped["Equipped Badge"]
	end
	if not v417 or v417 == "" then
		return ""
	end
	for _, v418 in ipairs(v416) do
		if v418._id ~= v417 then
			continue
		end
		local v419 = v_u_7.GetSkinInformation(v418.Name, v418.Skin)
		return v419 and v419.imageAssetId or ""
	end
	return ""
end
local function v_u_454(p421) -- name: populateMVPFrame
	-- upvalues: (copy) v_u_35, (copy) v_u_354, (copy) v_u_31, (copy) v_u_4, (copy) v_u_420
	local v422 = v_u_35:FindFirstChild("MainGui")
	if v422 then
		v422 = v422:FindFirstChild("Gameplay")
	end
	if v422 then
		v422 = v422:FindFirstChild("Middle")
	end
	if v422 then
		v422 = v422:FindFirstChild("EndScreen")
	end
	if v422 then
		local v423 = v422:FindFirstChild("MVP")
		if v423 then
			v_u_354(v423)
			for v424, v425 in ipairs(p421) do
				local v426 = v_u_31[v424]
				local v427 = v423:FindFirstChild((tostring(v426)))
				if not v427 then
					continue
				end
				local v428 = v425.data
				local v429 = v425.userId
				local v430 = tonumber(v429)
				local v431
				if v430 then
					v431 = v_u_4:GetPlayerByUserId(v430)
				else
					v431 = nil
				end
				local v432 = v428.Name or (v431 and v431.Name or ("Player_%*"):format(v429))
				local v433 = v427:FindFirstChild("Username")
				if v433 then
					v433.Text = v432
				end
				local v434 = ("%*-%*-%*"):format(v428.Kills or 0, v428.Deaths or 0, v428.Assists or 0)
				local v435 = v427:FindFirstChild("KDA")
				if v435 then
					v435.Text = v434
				end
				local v436 = v428.Kills or 0
				local v437 = v428.Headshots or 0
				local v438
				if v436 <= 0 then
					v438 = "0%"
				else
					local v439 = v437 / v436 * 100
					v438 = ("%*%%"):format((math.floor(v439)))
				end
				local v440 = v427:FindFirstChild("HSP")
				if v440 then
					v440.Text = v438
				end
				local v441 = v428.ADR or 0
				local v442 = math.floor(v441)
				local v443 = tostring(v442)
				local v444 = v427:FindFirstChild("APR")
				if v444 then
					v444.Text = v443
				end
				local v445 = v427:FindFirstChild("Score")
				if not v445 then
					for _, v446 in v427:GetChildren() do
						if not v446:IsA("TextLabel") or (v446.Name ~= "NameScore" or v446.Text == "SCORE") then
							continue
						end
						v445 = v446
					end
				end
				if v445 then
					local v447 = v428.Score or 0
					v445.Text = tostring(v447)
				end
				local v448 = v428.Accolade or "Participant"
				local v449 = v427:FindFirstChild("Category")
				if v449 then
					v449.Text = v448
				end
				local v450 = v427:FindFirstChild("Player")
				local v451 = v450 and v450:FindFirstChild("Avatar")
				if v451 then
					v451.Image = ("rbxthumb://type=AvatarHeadShot&id=%*&w=150&h=150"):format(v428.AvatarUserId or v429)
				end
				local v452 = v427:FindFirstChild("Pin")
				if v452 then
					local v453 = not (v431 and v428.Team) and "" or v_u_420(v431, v428.Team)
					if v453 ~= "" then
						v452.Image = v453
					end
					v452.Visible = v453 ~= ""
				end
				v427.Visible = true
			end
		end
	else
		return
	end
end
local function v_u_465(p455, p456, p457) -- name: positionCharacterOnGround
	p455:PivotTo(p457.CFrame)
	local v458, v459 = p455:GetBoundingBox()
	local v460 = p456.Position.Y - (v458.Position.Y - v459.Y / 2)
	local v461 = RaycastParams.new()
	v461.FilterType = Enum.RaycastFilterType.Exclude
	v461.FilterDescendantsInstances = { p455, p457 }
	v461.RespectCanCollide = true
	local v462 = p456.Position + Vector3.new(0, 16, 0)
	local v463 = workspace:Raycast(v462, Vector3.new(-0, -128, -0), v461)
	if not v463 then
		return false
	end
	local v464 = v463.Position.Y + v460 - p456.Position.Y
	p455:PivotTo(p455:GetPivot() + Vector3.new(0, v464, 0))
	return true
end
local function v_u_472(p466, p467, p468, p469) -- name: playPodiumAnimation
	-- upvalues: (copy) v_u_41
	local v470 = Instance.new("Animation")
	v470.AnimationId = p467
	local v471 = p466:LoadAnimation(v470)
	v471.Looped = p468
	v471.Priority = p469
	v471:Play()
	v_u_41:Add(v470)
	v_u_41:Add(v471)
end
local function v_u_492(p473, p474) -- name: spawnEndScreenCharacters
	-- upvalues: (copy) v_u_454, (copy) v_u_31, (copy) v_u_40, (copy) v_u_37, (copy) v_u_39, (copy) v_u_22, (copy) v_u_465, (copy) v_u_388, (copy) v_u_412, (copy) v_u_38, (copy) v_u_472, (copy) v_u_41
	local v475 = workspace:FindFirstChild("TutorialEndScreenScene")
	if v475 then
		v475 = v475:FindFirstChild("EndScreen")
	end
	local v476 = not v475 and workspace:FindFirstChild("Map")
	if v476 then
		v476 = workspace.Map:FindFirstChild("EndScreen")
	end
	if not v476 then
		return {}
	end
	local v477 = #p473
	local v478 = {}
	for v479 = 1, math.min(5, v477) do
		local v480 = p473[v479]
		table.insert(v478, v480)
	end
	if p474 then
		v_u_454(v478)
	end
	local v481 = {}
	for v482, v483 in ipairs(v478) do
		local v484 = v_u_31[v482]
		local v485 = v476:FindFirstChild((tostring(v484)))
		if not v485 then
			continue
		end
		local v486 = v_u_40[v483.data.Team]
		if not v486 then
			continue
		end
		local v487 = v_u_37:FindFirstChild(v_u_39[v486].Character)
		if not v487 then
			continue
		end
		local v488 = v487:Clone()
		v488.Name = "EndScreenCharacter_" .. v483.userId
		local v489 = v_u_22.getRootPart(v488)
		if v489 then
			v489.Anchored = true
			if not v_u_465(v488, v489, v485) then
				warn((("[EndScreen] No ground found below position %*; using the position marker height"):format(v484)))
			end
			v488.Parent = v476
			v_u_388(v488, v486, v483.data.Gloves)
			v_u_412(v488, v486, v483.data.Weapon)
			local v490 = v_u_22.getOrCreateAnimator(v488)
			local v491 = v_u_38[v484]
			if v490 and v491 then
				v_u_472(v490, v491.Entrance, false, Enum.AnimationPriority.Action)
				v_u_472(v490, v491.Idle, true, Enum.AnimationPriority.Idle)
			end
			v_u_41:Add(v488, "Destroy")
			table.insert(v481, v488)
		else
			warn((("[EndScreen] Character template %* is missing a HumanoidRootPart"):format(v487.Name)))
			v488:Destroy()
		end
	end
	return v481
end
local function v_u_508(p493) -- name: buildCameraPath
	-- upvalues: (copy) v_u_28
	local v494 = {}
	local v495 = {}
	while true do
		local v496 = #v494 + 1
		local v497 = p493:FindFirstChild((tostring(v496)))
		if not (v497 and v497:IsA("BasePart")) then
			break
		end
		local v498 = v497.Position
		table.insert(v494, v498)
		local v499 = v497.CFrame.LookVector
		table.insert(v495, v499)
	end
	if #v494 < 2 then
		return nil
	end
	local v500 = {
		["Alpha"] = 0,
		["SamplesPerSpan"] = 24
	}
	local v501 = v_u_28.spline(v494, v500)
	local v502 = v_u_28.spline(v495, v500)
	for v503, v504 in v502 do
		v502[v503] = v504.Unit
	end
	local v505, v506, v507 = v_u_28.resample(v501, 0.25, nil, v502)
	return {
		["Positions"] = v505,
		["Looks"] = v507,
		["Total"] = v506
	}
end
local function v_u_517(p509, p510) -- name: sampleCameraPath
	-- upvalues: (copy) v_u_28
	local v511 = p509.Total * math.clamp(p510, 0, 1)
	local v512, v513, v514 = v_u_28.locate(#p509.Positions, 0.25, v511)
	local v515 = p509.Positions[v512]:Lerp(p509.Positions[v513], v514)
	local v516 = p509.Looks[v512]:Lerp(p509.Looks[v513], v514)
	return CFrame.lookAt(v515, v515 + v516)
end
local function v_u_519(p518) -- name: takeEndScreenCamera
	-- upvalues: (copy) v_u_36, (copy) v_u_9, (copy) v_u_41
	v_u_36.CameraType = Enum.CameraType.Scriptable
	v_u_36.CFrame = p518
	v_u_36.Focus = p518
	v_u_36.FieldOfView = 60
	v_u_9.setMouseEnabled(true)
	v_u_41:Add(v_u_36:GetPropertyChangedSignal("CameraType"):Connect(function()
		-- upvalues: (ref) v_u_36
		if v_u_36.CameraType ~= Enum.CameraType.Scriptable then
			v_u_36.CameraType = Enum.CameraType.Scriptable
		end
	end))
end
local function v_u_528() -- name: animateCamera
	-- upvalues: (copy) v_u_508, (copy) v_u_519, (copy) v_u_517, (copy) v_u_41, (copy) v_u_12, (copy) v_u_27, (copy) v_u_36, (copy) v_u_3
	local v520 = workspace:FindFirstChild("TutorialEndScreenScene")
	if v520 then
		v520 = v520:FindFirstChild("EndScreen")
	end
	local v521 = not v520 and workspace:FindFirstChild("Map")
	if v521 then
		v521 = workspace.Map:FindFirstChild("EndScreen")
	end
	if v521 then
		local v_u_522 = v521:FindFirstChild("CameraPath")
		if v_u_522 then
			v_u_522 = v_u_508(v_u_522)
		end
		if v_u_522 then
			v_u_519(v_u_517(v_u_522, 0))
			local v_u_523 = os.clock()
			v_u_41:Add(v_u_12.BindToRenderStep("EndScreenController.CameraPath", Enum.RenderPriority.Camera.Value + 1, function()
				-- upvalues: (ref) v_u_517, (copy) v_u_522, (copy) v_u_523, (ref) v_u_27, (ref) v_u_36
				local v524 = v_u_517(v_u_522, (os.clock() - v_u_523) / v_u_27.DURATION)
				v_u_36.CFrame = v524
				v_u_36.Focus = v524
			end), "Disconnect")
			return
		else
			local v525 = v521:FindFirstChild("Start")
			local v526 = v521:FindFirstChild("End")
			if v525 and v526 then
				v_u_519(v525.CFrame)
				local v527 = v_u_3:Create(v_u_36, TweenInfo.new(v_u_27.DURATION, Enum.EasingStyle.Linear), {
					["CFrame"] = v526.CFrame
				})
				v527:Play()
				v_u_41:Add(v527, "Cancel")
			else
				warn("[EndScreen] Missing Start or End part!")
			end
		end
	else
		return
	end
end
local function v_u_539(p529) -- name: collectSnapshotFadeTargets
	-- upvalues: (copy) v_u_30
	local v_u_530 = {}
	local function v537(p531) -- name: add
		-- upvalues: (ref) v_u_30, (copy) v_u_530
		for v532, v533 in v_u_30 do
			if not p531:IsA(v532) then
				continue
			end
			for _, v534 in v533 do
				local v535 = v_u_530
				local v536 = {
					["Instance"] = p531,
					["Property"] = v534,
					["Base"] = p531[v534]
				}
				table.insert(v535, v536)
			end
		end
	end
	v537(p529)
	for _, v538 in p529:GetDescendants() do
		v537(v538)
	end
	return v_u_530
end
local function v_u_548(p_u_540, p541, p542) -- name: fadeLeaderboardSnapshot
	-- upvalues: (copy) v_u_41, (copy) v_u_3
	local v543 = Instance.new("NumberValue")
	v543.Value = p541
	local function v546(p544) -- name: apply
		-- upvalues: (copy) p_u_540
		for _, v545 in p_u_540 do
			v545.Instance[v545.Property] = v545.Base + (1 - v545.Base) * p544
		end
	end
	for _, v547 in p_u_540 do
		v547.Instance[v547.Property] = v547.Base + (1 - v547.Base) * p541
	end
	v543.Changed:Connect(v546)
	v_u_41:Add(v543, "Destroy")
	v_u_3:Create(v543, TweenInfo.new(0.5), {
		["Value"] = p542
	}):Play()
end
local function v_u_552(p549) -- name: showLeaderboardSnapshot
	-- upvalues: (copy) v_u_13, (copy) v_u_29, (copy) v_u_539, (copy) v_u_41, (copy) v_u_548
	local v550 = v_u_13.broadcastRouter("CreateLeaderboardSnapshot")
	if not v550 then
		return nil
	end
	v550.Name = "LeaderboardSnapshot"
	v550.AnchorPoint = Vector2.new(0.5, 0.5)
	v550.Position = v_u_29
	v550.Size = UDim2.fromScale(v550.Size.X.Scale * 0.9, v550.Size.Y.Scale * 0.9)
	v550.ZIndex = 2
	local v551 = v_u_539(v550)
	v550.Parent = p549
	v_u_41:Add(v550, "Destroy")
	v_u_548(v551, 1, 0)
	return v551
end
local function v_u_557() -- name: closeAllActiveScenes
	-- upvalues: (copy) v_u_14, (copy) v_u_13, (copy) v_u_35, (copy) v_u_9, (copy) v_u_2
	v_u_14.SetBlurEnabled(false)
	if v_u_14.IsCaseSceneActive() then
		v_u_13.broadcastRouter("CaseSceneCloseForGameEnd")
	end
	if v_u_14.IsInspectActive() then
		v_u_13.broadcastRouter("WeaponInspectCloseForGameEnd")
	end
	if v_u_14.IsTradeUpActive() then
		return
	else
		local v553 = v_u_35:FindFirstChild("MainGui")
		if v553 then
			v553 = v553:FindFirstChild("Menu")
		end
		if v553 then
			if v553.Visible then
				v_u_14.HideMenu()
				v_u_9.setForceLockOverride("Menu", false)
			end
			v553.BackgroundTransparency = 1
		end
		local v554 = v_u_35:FindFirstChild("MainGui")
		if v554 then
			v554 = v554:FindFirstChild("Gameplay")
		end
		if v554 then
			v554 = v554:FindFirstChild("Middle")
		end
		if v554 then
			local v555 = v554:FindFirstChild("BuyMenu")
			if v555 and v555.Visible then
				require(v_u_2.Interface.Screens.Gameplay.Middle.BuyMenu).closeFrame()
			end
			local v556 = v554:FindFirstChild("TeamSelection")
			if v556 and v556.Visible then
				require(v_u_2.Interface.Screens.Gameplay.Middle.TeamSelection).closeFrame()
			end
		end
	end
end
function v_u_1.IsActive() -- name: IsActive
	-- upvalues: (ref) v_u_42
	return v_u_42
end
local function v_u_561() -- name: showMainMenuAfterEndScreen
	-- upvalues: (copy) v_u_2, (copy) v_u_35, (copy) v_u_9
	local v558 = require(v_u_2.Controllers.MenuSceneController)
	local v559 = require(v_u_2.Interface.Screens.Menu.Top)
	v558.ShowMenuScene()
	v559.ResetToMainMenu()
	local v560 = v_u_35:FindFirstChild("MainGui")
	if v560 then
		v_u_9.setForceLockOverride("Menu", true)
		v_u_9.setPerspective(true, true)
		v560.Menu.Visible = true
		v560.Gameplay.Visible = false
		v560.Gameplay.Bottom.Visible = false
	end
end
function v_u_1.ExitMapVoteToMenu() -- name: ExitMapVoteToMenu
	-- upvalues: (ref) v_u_43, (copy) v_u_14, (ref) v_u_42, (copy) v_u_1, (copy) v_u_9, (copy) v_u_369, (copy) v_u_561, (ref) v_u_47, (ref) v_u_45
	if v_u_43 then
		return
	else
		v_u_14.SetWantsMainMenu(true)
		if v_u_42 then
			v_u_1._finishSequence(true)
		else
			v_u_9.setForceLockOverride("EndScreen", false)
			v_u_369()
			v_u_9.SetEnabled(true)
			v_u_561()
			v_u_47 = nil
			v_u_45 = true
		end
	end
end
function v_u_1._runSequence(p_u_562) -- name: _runSequence
	-- upvalues: (ref) v_u_44, (ref) v_u_45, (ref) v_u_46, (ref) v_u_43, (copy) v_u_59, (copy) v_u_350, (copy) v_u_35, (copy) v_u_552, (copy) v_u_492, (copy) v_u_528, (copy) v_u_102, (copy) v_u_73, (copy) v_u_548, (copy) v_u_77, (copy) v_u_242, (copy) v_u_274, (copy) v_u_27, (copy) v_u_1
	v_u_44 = v_u_44 + 1
	local v_u_563 = v_u_44
	v_u_45 = p_u_562.returnToMenu
	v_u_46 = p_u_562.overlayMode
	v_u_43 = p_u_562.locked
	v_u_59()
	v_u_350(p_u_562)
	local v564 = v_u_35:FindFirstChild("MainGui")
	if v564 then
		v564 = v564:FindFirstChild("Gameplay")
	end
	if v564 then
		v564 = v564:FindFirstChild("Middle")
	end
	if v564 then
		v564 = v564:FindFirstChild("EndScreen")
	end
	local v565
	if v564 then
		v565 = v564:FindFirstChild("Close")
	else
		v565 = v564
	end
	if v565 then
		v565.Visible = not p_u_562.locked
	end
	local v_u_566
	if p_u_562.showLeaderboard and v564 then
		v_u_566 = v_u_552(v564)
	else
		v_u_566 = nil
	end
	if not p_u_562.showLeaderboard then
		local v567 = v_u_492
		local v568 = p_u_562.displayPlayers
		local v569 = p_u_562.showAccolades
		local v570, v571 = pcall(v567, v568, v569)
		if not v570 then
			warn((("[EndScreen] Podium failed: %*"):format(v571)))
		end
	end
	v_u_528()
	if p_u_562.showProgression then
		task.delay(p_u_562.showLeaderboard and 6 or 4, function()
			-- upvalues: (copy) v_u_563, (ref) v_u_44, (ref) v_u_35, (ref) v_u_102, (copy) p_u_562, (ref) v_u_73, (copy) v_u_566, (ref) v_u_548, (ref) v_u_77, (ref) v_u_242, (ref) v_u_274
			if v_u_563 == v_u_44 then
				local v572 = v_u_35:FindFirstChild("MainGui")
				if v572 then
					v572 = v572:FindFirstChild("Gameplay")
				end
				if v572 then
					v572 = v572:FindFirstChild("Middle")
				end
				if v572 then
					v572 = v572:FindFirstChild("EndScreen")
				end
				if v572 then
					local v_u_573 = v572:FindFirstChild("Victory")
					local v_u_574 = v572:FindFirstChild("Defeat")
					local v_u_575 = v572:FindFirstChild("Level")
					local v_u_576 = v_u_102(p_u_562.xpEarned)
					local v577 = p_u_562.isDraw and v_u_573 and v_u_573 or (p_u_562.didWin and v_u_573 and v_u_573 or v_u_574)
					if v577 and v577.Visible then
						v_u_73(v577, 1)
					end
					if v_u_566 then
						v_u_548(v_u_566, 0, 1)
					end
					task.delay(0.5, function()
						-- upvalues: (ref) v_u_563, (ref) v_u_44, (copy) v_u_573, (copy) v_u_574, (copy) v_u_575, (ref) v_u_77, (copy) v_u_576, (ref) v_u_242, (ref) v_u_274, (ref) p_u_562
						if v_u_563 == v_u_44 then
							if v_u_573 then
								v_u_573.Visible = false
							end
							if v_u_574 then
								v_u_574.Visible = false
							end
							if v_u_575 then
								v_u_77(v_u_575)
								task.spawn(function()
									-- upvalues: (ref) v_u_576, (ref) v_u_242, (ref) v_u_274, (ref) p_u_562
									if v_u_576 then
										v_u_242(v_u_576)
									end
									v_u_274(p_u_562.levelRewards)
								end)
							end
						end
					end)
				end
			else
				return
			end
		end)
	end
	if not p_u_562.locked then
		local v578 = p_u_562.sequenceDuration or (p_u_562.showProgression and v_u_27.DURATION or 4)
		task.delay(v578, function()
			-- upvalues: (copy) v_u_563, (ref) v_u_44, (ref) v_u_1, (copy) p_u_562
			if v_u_563 == v_u_44 then
				v_u_1._finishSequence(p_u_562.returnToMenu)
			end
		end)
	end
end
function v_u_1._finishSequence(p579) -- name: _finishSequence
	-- upvalues: (ref) v_u_43, (ref) v_u_45, (ref) v_u_44, (ref) v_u_46, (ref) v_u_42, (copy) v_u_9, (copy) v_u_41, (copy) v_u_369, (copy) v_u_35, (ref) v_u_47, (copy) v_u_300, (copy) v_u_14, (copy) v_u_561, (copy) v_u_11, (copy) v_u_34, (ref) v_u_48
	if not v_u_43 then
		if p579 == nil then
			p579 = v_u_45
		end
		if typeof(p579) ~= "boolean" then
			p579 = p579 and true or v_u_45
		end
		v_u_44 = v_u_44 + 1
		v_u_46 = "EndScreen"
		v_u_42 = false
		v_u_9.setForceLockOverride("EndScreen", false)
		v_u_41:Cleanup()
		v_u_369()
		v_u_9.SetEnabled(true)
		local v580 = v_u_35:FindFirstChild("MainGui")
		if p579 or not (v580 and v_u_47) then
			v_u_561()
			v_u_47 = nil
			v_u_45 = true
		else
			v_u_300(v580, true)
			v_u_14.HideMenu()
			v580.Gameplay.Visible = true
			v_u_9.setPerspective(true, false)
		end
		local v581 = v_u_11.Get(v_u_34, "Level")
		if v581 then
			v_u_48 = {
				["Level"] = v581.Level,
				["Experience"] = v581.Experience,
				["NextExperienceRequirement"] = v581.NextExperienceRequirement
			}
		end
	end
end
function v_u_1.Begin(p582) -- name: Begin
	-- upvalues: (ref) v_u_43, (ref) v_u_42, (copy) v_u_1, (copy) v_u_14, (copy) v_u_13, (copy) v_u_34, (copy) v_u_24, (copy) v_u_55, (copy) v_u_32, (copy) v_u_557, (copy) v_u_10, (copy) v_u_9
	if v_u_43 then
		return
	else
		local v583 = p582.Halftime == true and "Halftime" or "EndScreen"
		if v_u_42 then
			warn("[EndScreen] Interrupting active sequence for new end screen")
			local v584 = v_u_1._finishSequence
			local v585, v586 = pcall(v584, false)
			if not v585 then
				warn("[EndScreen] _finishSequence error during interrupt: " .. tostring(v586))
			end
			v_u_42 = false
		end
		if v_u_14.IsTradeUpActive() then
			return
		elseif not v_u_14.IsCaseSceneActive() or v_u_13.broadcastRouter("IsCaseSceneRolling") ~= true then
			local v587 = workspace:GetAttribute("Gamemode") == "Deathmatch"
			local v588
			if p582.Players then
				local v589 = p582.Players
				local v590 = v_u_34.UserId
				v588 = v589[tostring(v590)] or nil
			else
				v588 = nil
			end
			if not v588 then
				local v591 = warn
				local v592 = v_u_34.UserId
				local v593 = tostring(v592)
				local v594 = v_u_34
				local v595 = tostring(v594:GetAttribute("Team"))
				local v596 = p582.WinningTeam
				v591(("[EndScreen] Local player missing from payload (userId=%s, teamAttr=%s, winningTeam=%s)"):format(v593, v595, (tostring(v596))))
				if not v_u_24(v_u_34:GetAttribute("Team")) or v587 then
					return
				end
			end
			local v597 = v588 and v588.Team or v_u_34:GetAttribute("Team")
			local v598 = p582.Cooperative == true
			local v599 = not v598
			if v599 then
				v599 = p582.WinningTeam == "Draw"
			end
			local v600 = nil
			local v601, v602
			if v587 then
				if not (v588 and v_u_24(v588.Team)) then
					local v603 = warn
					local v604 = "[EndScreen] Begin skipped for Deathmatch: invalid team data (team=%s)"
					if v588 then
						v588 = v588.Team
					end
					v603(v604:format((tostring(v588))))
					return
				end
				v601 = v_u_55(p582.Players)
				table.sort(v601, function(p605, p606)
					if (p605.data.Score or 0) ~= (p606.data.Score or 0) then
						return (p605.data.Score or 0) > (p606.data.Score or 0)
					end
					if (p605.data.Kills or 0) ~= (p606.data.Kills or 0) then
						return (p605.data.Kills or 0) > (p606.data.Kills or 0)
					end
					if (p605.data.Assists or 0) ~= (p606.data.Assists or 0) then
						return (p605.data.Assists or 0) > (p606.data.Assists or 0)
					end
					local v607 = p605.userId
					local v608 = tonumber(v607) or (1 / 0)
					local v609 = p606.userId
					return v608 < (tonumber(v609) or (1 / 0))
				end)
				if #v601 == 0 then
					warn("[EndScreen] Begin skipped for Deathmatch: no eligible ranked players")
					return
				end
				local v610 = nil
				for v611, v612 in ipairs(v601) do
					local v613 = v612.userId
					local v614 = v_u_34.UserId
					if v613 ~= tostring(v614) then
						continue
					end
					v610 = v611
				end
				if not v610 then
					local v615 = warn
					local v616 = v_u_34.UserId
					v615(("[EndScreen] Begin skipped for Deathmatch: local player missing from ranked list (userId=%s)"):format((tostring(v616))))
					return
				end
				v602 = v610 == 1
				local v617 = v610 % 100
				v600 = ("You placed %*"):format((("%*%*"):format(v610, v617 >= 11 and v617 <= 13 and "th" or (v_u_32[v610 % 10] or "th"))))
			else
				if not v_u_24(v597) then
					local v618 = warn
					local v619 = tostring(v597)
					local v620 = v_u_34
					local v621 = tostring(v620:GetAttribute("Team"))
					local v622 = p582.WinningTeam
					v618(("[EndScreen] Begin skipped: invalid team (team=%s, teamAttr=%s, winningTeam=%s)"):format(v619, v621, (tostring(v622))))
					return
				end
				if v598 then
					v602 = p582.CooperativeVictory == true
				else
					v602 = not v599
					if v602 then
						v602 = p582.WinningTeam == v597
					end
				end
				local v623 = {}
				for v624, v625 in pairs(p582.Players) do
					if v625.Team ~= v597 then
						continue
					end
					v623[v624] = v625
				end
				v601 = v_u_55(v623)
				table.sort(v601, function(p626, p627)
					if (p626.data.ADR or 0) ~= (p627.data.ADR or 0) then
						return (p626.data.ADR or 0) > (p627.data.ADR or 0)
					end
					if (p626.data.Score or 0) ~= (p627.data.Score or 0) then
						return (p626.data.Score or 0) > (p627.data.Score or 0)
					end
					local v628 = p626.userId
					local v629 = tonumber(v628) or (1 / 0)
					local v630 = p627.userId
					return v629 < (tonumber(v630) or (1 / 0))
				end)
			end
			v_u_557()
			v_u_10.Stop(false, true)
			v_u_9.SetEnabled(false)
			v_u_42 = true
			local v631 = {}
			for v632 in pairs(p582.Players) do
				local v633 = tonumber(v632)
				if not v633 then
					continue
				end
				table.insert(v631, v633)
			end
			table.sort(v631)
			local v634 = {}
			for _, v635 in ipairs(v631) do
				local v636 = p582.Players[tostring(v635)]
				if v636 then
					v636 = v636.LevelRewards
				end
				if not v636 then
					continue
				end
				for _, v637 in ipairs(v636) do
					table.insert(v634, {
						["userId"] = v635,
						["reward"] = v637
					})
				end
			end
			v_u_1._runSequence({
				["displayPlayers"] = v601,
				["didWin"] = v602,
				["isDraw"] = v599,
				["winningTeam"] = p582.WinningTeam,
				["xpEarned"] = v588 and v588.ExperienceEarned or 0,
				["levelRewards"] = v634,
				["ctScore"] = p582.CTScore or 0,
				["tScore"] = p582.TScore or 0,
				["scoreTextOverride"] = v600,
				["hideScore"] = v598,
				["showAccolades"] = p582.ShowAccolades ~= false,
				["showLeaderboard"] = v598,
				["showProgression"] = p582.ShowProgression ~= false,
				["sequenceDuration"] = p582.SequenceDuration,
				["returnToMenu"] = p582.ReturnToMenu ~= false,
				["overlayMode"] = v583,
				["halftimeTeam"] = v597,
				["locked"] = p582.Locked == true
			})
		end
	end
end
function v_u_1.Initialize() -- name: Initialize
	-- upvalues: (copy) v_u_13, (copy) v_u_1, (copy) v_u_35, (copy) v_u_20, (copy) v_u_15, (ref) v_u_42, (copy) v_u_14, (copy) v_u_16, (copy) v_u_11, (copy) v_u_34, (ref) v_u_48, (copy) v_u_6
	v_u_13.observerRouter("IsEndScreenActive", v_u_1.IsActive)
	local v638 = v_u_35:FindFirstChild("MainGui")
	if v638 then
		v638 = v638:FindFirstChild("Gameplay")
	end
	if v638 then
		v638 = v638:FindFirstChild("Middle")
	end
	if v638 then
		v638 = v638:FindFirstChild("EndScreen")
	end
	if v638 then
		local v639 = v638:FindFirstChild("Drops")
		if v639 then
			v639.Visible = false
		end
		local v640 = v638:FindFirstChild("Close")
		if v640 then
			v_u_20(v640)
			v_u_15.Add(v638, v640, function()
				-- upvalues: (ref) v_u_42, (ref) v_u_14, (ref) v_u_1, (ref) v_u_16
				if v_u_42 then
					v_u_14.SetWantsMainMenu(true)
					v_u_1._finishSequence(true)
				elseif v_u_16.GetState() == "Map Voting" then
					v_u_1.ExitMapVoteToMenu()
				end
			end)
		end
	end
	v_u_11.CreateListener(v_u_34, "Level", function(p641)
		-- upvalues: (ref) v_u_48
		if v_u_48 == nil and p641 then
			v_u_48 = {
				["Level"] = p641.Level,
				["Experience"] = p641.Experience,
				["NextExperienceRequirement"] = p641.NextExperienceRequirement
			}
		end
	end)
	v_u_6.Match.EndScreen.Listen(function(p642)
		-- upvalues: (ref) v_u_1
		v_u_1.Begin(p642)
	end)
end
return v_u_1
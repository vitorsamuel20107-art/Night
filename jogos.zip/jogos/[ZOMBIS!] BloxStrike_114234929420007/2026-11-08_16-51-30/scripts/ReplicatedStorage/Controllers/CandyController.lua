-- NIGHT Analyzer | ReplicatedStorage.Controllers.CandyController
-- ModuleScript | 1089 linhas | 33076 bytes | hash e21bb204

local v1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("ContentProvider")
local v_u_4 = game:GetService("AssetService")
local v_u_5 = game:GetService("SoundService")
local v_u_6 = game:GetService("Workspace")
local v7 = game:GetService("Players")
local v_u_8 = require(v_u_2.Controllers.RunServiceController)
local v_u_9 = require(v_u_2.Controllers.HordeController)
local v10 = require(v_u_2.Components.Common.HordeProtocol)
local v_u_11 = require(v_u_2.Components.Common.SurvivalCandy)
local v_u_12 = require(v_u_2.Components.Common.SurvivalDowned)
local v_u_13 = require(v_u_2.Components.Common.SurvivalBuyRules)
local v_u_14 = require(v_u_2.Components.Common.CharacterResolver)
local v_u_15 = require(v_u_2.Components.Common.GetRayIgnore)
local v_u_16 = require(v_u_2.Shared.ObjectPool)
local v17 = require(v_u_2.Components.Common.FarThrottle)
local v_u_18 = require(script.PickupFeed)
local v_u_19 = require(v_u_2.Database.Security.Remotes)
local v_u_20 = { 26, 32 }
local v_u_21 = { 4, 8 }
local v_u_22 = { 30, 38 }
local v_u_23 = { 4, 8 }
local v_u_24 = { 6.283185307179586, 12.566370614359172 }
local v_u_25 = { 3, 12 }
local v_u_26 = table.freeze({ "Characters", v10.SHELL_FOLDER, v10.HITBOX_FOLDER })
local v_u_27 = {
	["CandyCorn"] = {
		["Size"] = 1.5,
		["Weight"] = 45,
		["Trail"] = nil,
		["CenterY"] = 0.5,
		["Trail"] = ColorSequence.new(Color3.fromRGB(255, 226, 92), Color3.fromRGB(255, 128, 24))
	},
	["HardCandy"] = {
		["Size"] = 1.8,
		["Weight"] = 35,
		["Trail"] = nil,
		["CenterY"] = 0,
		["Trail"] = ColorSequence.new(Color3.fromRGB(176, 120, 255), Color3.fromRGB(255, 140, 40))
	},
	["ChocolateBar"] = {
		["Size"] = 1.7,
		["Weight"] = 20,
		["Trail"] = nil,
		["CenterY"] = 0.5,
		["Trail"] = ColorSequence.new(Color3.fromRGB(255, 160, 70), Color3.fromRGB(110, 62, 34))
	}
}
local v_u_28 = v7.LocalPlayer
local v_u_29 = Random.new()
local v_u_30 = {}
local v_u_31 = {}
local v_u_32 = {}
local v_u_33 = nil
local v_u_34 = v17.new()
local v_u_35 = RaycastParams.new()
v_u_35.FilterType = Enum.RaycastFilterType.Exclude
v_u_35.IgnoreWater = true
local v_u_36 = (-1 / 0)
local v_u_37 = {}
local v_u_38 = {}
local v_u_39 = {}
local v_u_40 = nil
local v_u_41 = nil
local v_u_42 = nil
local v_u_43 = nil
local v_u_44 = nil
local v_u_45 = false
local v_u_46 = false
local function v_u_51(p47, p48, p49) -- name: makeSparkles
	local v50 = Instance.new("ParticleEmitter")
	v50.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	v50.Color = p48
	v50.LightEmission = 1
	v50.LightInfluence = 0
	v50.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.3, p49), NumberSequenceKeypoint.new(1, 0) })
	v50.Transparency = NumberSequence.new(0.1)
	v50.Lifetime = NumberRange.new(0.35, 0.6)
	v50.Rotation = NumberRange.new(0, 360)
	v50.RotSpeed = NumberRange.new(-180, 180)
	v50.Speed = NumberRange.new(0)
	v50.Enabled = false
	v50.Parent = p47
	return v50
end
local function v_u_62() -- name: buildFx
	-- upvalues: (copy) v_u_6, (copy) v_u_51, (ref) v_u_40, (ref) v_u_41, (ref) v_u_42, (ref) v_u_43, (copy) v_u_5, (ref) v_u_44, (copy) v_u_3
	local v52 = Instance.new("Part")
	v52.Name = "CandyBurst"
	v52.Anchored = true
	v52.CanCollide = false
	v52.CanQuery = false
	v52.CanTouch = false
	v52.Transparency = 1
	v52.Size = Vector3.new(0.2, 0.2, 0.2)
	v52.CollisionGroup = "Debris"
	v52:SetAttribute("PersistentDebris", true)
	v52.Parent = v_u_6:FindFirstChild("Debris") or v_u_6
	local v53 = Instance.new("Attachment")
	v53.Parent = v52
	local v54 = v_u_51(v53, ColorSequence.new(Color3.fromRGB(255, 236, 190)), 1.4)
	v54.Name = "Stars"
	v54.Speed = NumberRange.new(4, 10)
	v54.SpreadAngle = Vector2.new(180, 180)
	v54.Drag = 4
	local v55 = Instance.new("ParticleEmitter")
	v55.Name = "Confetti"
	v55.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 136, 28)), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 220, 80)), ColorSequenceKeypoint.new(1, Color3.fromRGB(150, 90, 255)) })
	v55.LightEmission = 0.3
	v55.Size = NumberSequence.new(0.18, 0.05)
	v55.Lifetime = NumberRange.new(0.6, 1)
	v55.Speed = NumberRange.new(10, 18)
	v55.SpreadAngle = Vector2.new(60, 60)
	v55.EmissionDirection = Enum.NormalId.Top
	v55.Acceleration = Vector3.new(0, -40, 0)
	v55.Drag = 2
	v55.Rotation = NumberRange.new(0, 360)
	v55.RotSpeed = NumberRange.new(-400, 400)
	v55.Enabled = false
	v55.Parent = v53
	local v56 = Instance.new("Sound")
	v56.SoundId = "rbxassetid://9126072453"
	v56.Volume = 1.2
	v56.RollOffMode = Enum.RollOffMode.InverseTapered
	v56.RollOffMinDistance = 25
	v56.RollOffMaxDistance = 120
	v56.Parent = v52
	v56.Name = "Burst"
	v_u_40 = v52
	v_u_41 = v54
	v_u_42 = v55
	v_u_43 = v56
	local v_u_57 = { v52 }
	local v58 = Instance.new("Sound")
	v58.SoundId = "rbxassetid://15675012262"
	v58.Volume = 0.6
	v58.Parent = v_u_5
	v_u_44 = v58
	v_u_57[#v_u_57 + 1] = v58
	task.spawn(function()
		-- upvalues: (ref) v_u_3, (copy) v_u_57
		local v59 = v_u_3.PreloadAsync
		local v60 = v_u_3
		local v61 = v_u_57
		pcall(v59, v60, v61)
	end)
end
local function v_u_68(p_u_63) -- name: getSourcePart
	-- upvalues: (copy) v_u_2, (copy) v_u_11, (copy) v_u_4
	local v64 = v_u_2:FindFirstChild("Assets")
	if v64 then
		v64 = v64:FindFirstChild(v_u_11.TEMPLATE_FOLDER)
	end
	if v64 then
		v64 = v64:FindFirstChild(p_u_63)
	end
	if v64 and v64:IsA("MeshPart") then
		return v64:Clone()
	else
		local function v65()
			-- upvalues: (ref) v_u_4, (ref) v_u_11, (copy) p_u_63
			return v_u_4:CreateMeshPartAsync(Content.fromAssetId(v_u_11.MESH_IDS[p_u_63]))
		end
		local v66, v67 = pcall(v65)
		if v66 and v67 then
			v67.TextureID = ("rbxassetid://%*"):format(v_u_11.COLOR_MAP_ID)
			return v67
		else
			warn((("[CandyController] no template for %*: %*"):format(p_u_63, v67)))
			return nil
		end
	end
end
local function v_u_70(p69) -- name: resetPart
	p69.Trail.Enabled = false
	p69.Glint.Enabled = false
	p69.Transparency = 0
end
local function v_u_88(p71) -- name: buildTemplate
	-- upvalues: (copy) v_u_27, (copy) v_u_68, (copy) v_u_51, (copy) v_u_31
	local v72 = v_u_27[p71]
	local v73 = v_u_68(p71)
	if not v73 then
		return nil
	end
	local v74 = v73.Size
	local v75 = v72.Size
	local v76 = v74.X
	local v77 = v74.Y
	local v78 = v74.Z
	local v79 = v75 / math.max(v76, v77, v78)
	v73.Name = ("Candy%*"):format(p71)
	v73.Size = v74 * v79
	v73.Anchored = true
	v73.CanCollide = false
	v73.CanQuery = false
	v73.CanTouch = false
	v73.CastShadow = true
	v73.CollisionGroup = "Debris"
	v73.Massless = true
	local v80 = v73.Size.Y * v72.CenterY
	local v81 = Instance.new("Attachment")
	v81.Name = "TrailTop"
	local v82 = v80 + 0.22
	v81.Position = Vector3.new(0, v82, 0)
	v81.Parent = v73
	local v83 = Instance.new("Attachment")
	v83.Name = "TrailBottom"
	local v84 = v80 - 0.22
	v83.Position = Vector3.new(0, v84, 0)
	v83.Parent = v73
	local v85 = Instance.new("Trail")
	v85.Name = "Trail"
	v85.Attachment0 = v81
	v85.Attachment1 = v83
	v85.FaceCamera = true
	v85.Lifetime = 0.35
	v85.MinLength = 0.05
	v85.WidthScale = NumberSequence.new(1, 0)
	v85.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.15), NumberSequenceKeypoint.new(0.6, 0.6), NumberSequenceKeypoint.new(1, 1) })
	v85.LightEmission = 0.6
	v85.LightInfluence = 0
	v85.Color = v72.Trail
	v85.Enabled = false
	v85.Parent = v73
	local v86 = v_u_51(v73, ColorSequence.new(Color3.fromRGB(255, 244, 214)), 0.8)
	v86.Name = "Glint"
	v86.Rate = 0.7
	v86.LockedToPart = true
	local v87 = Instance.new("Sound")
	v87.SoundId = "rbxassetid://9126073644"
	v87.Volume = 1.1
	v87.RollOffMode = Enum.RollOffMode.InverseTapered
	v87.RollOffMinDistance = 25
	v87.RollOffMaxDistance = 120
	v87.Parent = v73
	v87.Name = "Pop"
	v_u_31[p71] = v73.Size
	return v73
end
local function v_u_95() -- name: buildPools
	-- upvalues: (copy) v_u_27, (copy) v_u_88, (copy) v_u_30, (copy) v_u_16, (copy) v_u_70, (copy) v_u_3, (copy) v_u_18, (ref) v_u_45
	for v89 in v_u_27 do
		local v_u_90 = v_u_88(v89)
		if not v_u_90 then
			continue
		end
		local v91 = {
			["InitialSize"] = 6,
			["MaxRetained"] = 40,
			["Reset"] = nil,
			["Reset"] = v_u_70
		}
		v_u_30[v89] = v_u_16.new(v_u_90, v91)
		task.spawn(function()
			-- upvalues: (ref) v_u_3, (copy) v_u_90
			local v92 = v_u_3.PreloadAsync
			local v93 = v_u_3
			local v94 = { v_u_90.Pop }
			pcall(v92, v93, v94)
		end)
	end
	v_u_18.Preload()
	v_u_45 = next(v_u_30) ~= nil
end
local function v_u_102() -- name: pickKind
	-- upvalues: (copy) v_u_27, (copy) v_u_30, (copy) v_u_29
	local v96 = 0
	for v97, v98 in v_u_27 do
		if not v_u_30[v97] then
			continue
		end
		v96 = v96 + v98.Weight
	end
	local v99 = v_u_29:NextNumber() * v96
	for v100, v101 in v_u_27 do
		if not v_u_30[v100] then
			continue
		end
		v99 = v99 - v101.Weight
		if v99 > 0 then
			continue
		end
		return v100
	end
	return next(v_u_30)
end
local function v_u_107(p103) -- name: refreshFilter
	-- upvalues: (ref) v_u_36, (copy) v_u_15, (copy) v_u_26, (copy) v_u_6, (copy) v_u_35
	if p103 - v_u_36 >= 1 then
		v_u_36 = p103
		local v104 = v_u_15()
		for _, v105 in v_u_26 do
			local v106 = v_u_6:FindFirstChild(v105)
			if not v106 then
				continue
			end
			v104[#v104 + 1] = v106
		end
		v_u_35.FilterDescendantsInstances = v104
	end
end
local function v_u_115(p108, p109, p110) -- name: floatFrame
	local v111 = p110 + p108.FloatPhase
	local v112 = v111 * 0.6 * 2 * 3.141592653589793
	local v113 = math.sin(v112) * 0.25
	local v114 = v111 * 2.6179938779914944
	return CFrame.new(p109 + Vector3.new(0, v113, 0)) * CFrame.Angles(0, v114, 0) * CFrame.Angles(0.3141592653589793, 0, 0) * CFrame.Angles(0, v111 * 2.0943951023931953 - v114, 0)
end
local function v_u_118() -- name: flushClaims
	-- upvalues: (copy) v_u_37, (copy) v_u_19
	for v116, v117 in v_u_37 do
		v_u_19.Survival.CollectCandy.Send({
			["Drop"] = v116,
			["Mask"] = v117
		})
	end
	table.clear(v_u_37)
end
local function v_u_148(p119, p120) -- name: tryBrake
	-- upvalues: (copy) v_u_6, (copy) v_u_35
	local v121 = p119.Position
	local v122 = p119.Velocity
	local v123 = -v122.Y
	if v123 <= 0 then
		return false
	end
	local v124 = p119.BaseSize
	local v125 = v124.X
	local v126 = v124.Y
	local v127 = v124.Z
	local v128 = math.max(v125, v126, v127) * 0.5 + 0.6
	local v129 = v128 + v123 * v123 / 320 + 1
	local v130 = v_u_6
	local v131 = -v129
	local v132 = v130:Raycast(v121, Vector3.new(0, v131, 0), v_u_35)
	if not v132 or v132.Normal.Y < 0.6 then
		v132 = nil
	end
	if not v132 then
		return false
	end
	local v133 = v121.Y - (v132.Position.Y + v128)
	if v133 <= 0 then
		local v134 = v121.X
		local v135 = v132.Position.Y + v128
		local v136 = v121.Z
		p119.FloatCenter = Vector3.new(v134, v135, v136)
		p119.SettleFrom = CFrame.new(p119.Position) * p119.Rotation
		p119.Velocity = Vector3.new(0, 0, 0)
		p119.Part.Trail.Enabled = false
		p119.State = "Settle"
		p119.StateAt = p120
		return true
	end
	if v123 * v123 / (2 * v133) < 160 then
		return false
	end
	local v137 = v121 + v122 * (v133 / v123)
	local v138 = v137.X
	local v139 = v121.Y
	local v140 = v137.Z
	local v141 = Vector3.new(v138, v139, v140)
	local v142 = v137.Y - v121.Y
	local v143 = v_u_6
	local v144 = -(v129 + math.abs(v142))
	local v145 = v143:Raycast(v141, Vector3.new(0, v144, 0), v_u_35)
	if not v145 or v145.Normal.Y < 0.6 then
		v145 = nil
	end
	if v145 then
		v133 = v121.Y - (v145.Position.Y + v128)
		if v133 <= 0 then
			return false
		end
	end
	local v146 = 2 * v133 / v123
	local v147 = v121 + v122 * (v146 / 2)
	if v_u_6:Raycast(v121, v147 - v121, v_u_35) then
		return false
	end
	p119.FloatCenter = v147
	p119.BrakeFrom = v121
	p119.BrakeVelocity = v122
	p119.BrakeSeconds = v146
	p119.State = "Brake"
	p119.StateAt = p120
	return true
end
local function v_u_155(p149, p150, p151) -- name: stepBrake
	local v152 = p149.BrakeSeconds
	local v153 = p151 - p149.StateAt
	local v154 = math.min(v153, v152)
	p149.Position = p149.BrakeFrom + p149.BrakeVelocity * (v154 - v154 * v154 / (v152 * 2))
	p149.Velocity = p149.BrakeVelocity * (1 - v154 / v152)
	p149.Rotation = CFrame.fromAxisAngle(p149.SpinAxis, p149.SpinSpeed * (1 - v154 / v152) * p150) * p149.Rotation
	return v152 <= v154
end
local function v_u_174(p156, p157, p158) -- name: stepFlight
	-- upvalues: (copy) v_u_6, (copy) v_u_35, (copy) v_u_148
	local v159 = p156.Velocity
	local v160 = p157 * 90
	local v161 = v159 - Vector3.new(0, v160, 0)
	local v162 = (v159 + v161) * 0.5 * p157
	p156.Velocity = v161
	p156.Rotation = CFrame.fromAxisAngle(p156.SpinAxis, p156.SpinSpeed * p157) * p156.Rotation
	local v163 = v162.Magnitude
	if v163 < 0.0001 then
		return
	else
		local v164 = v_u_6:Raycast(p156.Position, v162.Unit * (v163 + 0.3), v_u_35)
		if v164 then
			local v165 = v164.Normal
			local v166 = p156.Velocity:Dot(v165)
			if v165.Y >= 0.6 then
				p156.Bounces = p156.Bounces + 1
				local v167 = -v166 * 0.35
				if p156.Bounces > 2 or v167 < 6 then
					local v168 = v164.Position
					local v169 = p156.BaseSize
					local v170 = v169.X
					local v171 = v169.Y
					local v172 = v169.Z
					local v173 = math.max(v170, v171, v172) * 0.5 + 0.6
					p156.FloatCenter = v168 + Vector3.new(0, v173, 0)
					p156.SettleFrom = CFrame.new(p156.Position) * p156.Rotation
					p156.Velocity = Vector3.new(0, 0, 0)
					p156.Part.Trail.Enabled = false
					p156.State = "Settle"
					p156.StateAt = p158
					return
				end
				p156.Velocity = (p156.Velocity - v165 * v166) * 0.6 + v165 * v167
				p156.SpinSpeed = p156.SpinSpeed * 0.6
			else
				p156.Velocity = (p156.Velocity - v165 * v166 * 1.4) * 0.8
			end
			p156.Position = v164.Position + v165 * 0.3
			return
		else
			p156.Position = p156.Position + v162
			if p156.Position.Y < p156.Origin.Y - 60 then
				p156.Velocity = p156.Velocity * 0.3 + Vector3.new(0, 12, 0)
				p156.MagnetAt = p158
				p156.Part.Transparency = 0
				p156.Part.Glint.Enabled = false
				p156.Part.Trail.Enabled = true
				p156.State = "Magnet"
				p156.StateAt = p158
			else
				v_u_148(p156, p158)
			end
		end
	end
end
local function v_u_183(p175, p176, p177) -- name: stepMagnet
	-- upvalues: (copy) v_u_6
	local v178 = p177 - p175.MagnetAt
	if v178 >= 0.14 then
		return true
	end
	local v179 = v_u_6.CurrentCamera
	if v179 then
		local v180 = v179.CFrame.Position - p175.Position
		if v180.Magnitude > 0.001 then
			p175.Velocity = p175.Velocity + v180.Unit * 150 * p176
		end
	end
	p175.Position = p175.Position + p175.Velocity * p176
	p175.Rotation = CFrame.fromAxisAngle(p175.SpinAxis, p175.SpinSpeed * 1.5 * p176) * p175.Rotation
	local v181 = v178 / 0.14
	local v182 = math.min(v181, 1) * 3.141592653589793 / 2
	p175.Scale = math.sin(v182) * 0.19999999999999996 + 1
	return false
end
local function v_u_232(p184) -- name: update
	-- upvalues: (copy) v_u_107, (copy) v_u_14, (copy) v_u_28, (copy) v_u_12, (copy) v_u_38, (copy) v_u_39, (copy) v_u_34, (copy) v_u_32, (copy) v_u_30, (copy) v_u_27, (copy) v_u_6, (copy) v_u_174, (copy) v_u_11, (copy) v_u_155, (copy) v_u_115, (copy) v_u_25, (copy) v_u_183, (copy) v_u_37, (copy) v_u_18, (copy) v_u_118, (ref) v_u_33
	local v185 = os.clock()
	v_u_107(v185)
	local v186 = v_u_14.getRootPart(v_u_14.getLocalCharacter())
	local v187
	if v186 then
		v187 = v186.Position
	else
		v187 = nil
	end
	local v188 = v187 ~= nil and v_u_14.isAlivePlayer(v_u_28)
	if v188 then
		v188 = not v_u_12.IsDowned(v_u_28)
	end
	table.clear(v_u_38)
	table.clear(v_u_39)
	v_u_34:Begin()
	local v189 = 1
	while true do
		local v190, v191
		while true do
			while true do
				while true do
					while true do
						while true do
							while true do
								if v189 > #v_u_32 then
									if #v_u_38 > 0 then
										v_u_6:BulkMoveTo(v_u_38, v_u_39, Enum.BulkMoveMode.FireCFrameChanged)
									end
									v_u_118()
									if #v_u_32 == 0 and v_u_33 then
										v_u_33:Disconnect()
										v_u_33 = nil
									end
									return
								end
								local v192 = v_u_32[v189]
								local v193 = v192.Part
								local v194 = v192.State
								v212 = false
								if v194 == "Wait" or v193.Parent ~= nil then
									break
								end
								local v195 = v_u_32[v189]
								v_u_32[v189] = v_u_32[#v_u_32]
								v_u_32[#v_u_32] = nil
								local v196 = v_u_30[v195.Kind]
								v195.Part.Size = v195.BaseSize
								if v196 then
									v196:Release(v195.Part, v195.Lease)
								else
									v195.Part:Destroy()
								end
							end
							if v194 ~= "Wait" then
								break
							end
							if v192.LaunchAt <= v185 then
								local v197 = v192.BaseSize.Y * v_u_27[v192.Kind].CenterY
								v193.CFrame = CFrame.new(v192.Position) * v192.Rotation * CFrame.new(0, -v197, 0)
								v193.Parent = v_u_6:FindFirstChild("Debris") or v_u_6
								v193.Trail:Clear()
								v193.Trail.Enabled = true
								v192.State = "Fly"
								v192.StateAt = v185
								if v192.Vacuum then
									v192.Velocity = v192.Velocity * 0.3 + Vector3.new(0, 12, 0)
									v192.MagnetAt = v185
									v192.Part.Transparency = 0
									v192.Part.Glint.Enabled = false
									v192.Part.Trail.Enabled = true
									v192.State = "Magnet"
									v192.StateAt = v185
								else
									v193.Pop.PlaybackSpeed = v192.Pitch
									v193.Pop:Play()
								end
							end
							if v192.State ~= "Wait" and not v212 then
								v190 = v192.BaseSize * v192.Scale
								if v193.Size ~= v190 then
									v193.Size = v190
								end
								v_u_38[#v_u_38 + 1] = v193
								v191 = v190.Y * v_u_27[v192.Kind].CenterY
								v_u_39[#v_u_39 + 1] = CFrame.new(v192.Position) * v192.Rotation * CFrame.new(0, -v191, 0)
							end
							v189 = v189 + 1
						end
						if v194 ~= "Fly" then
							break
						end
						v_u_174(v192, p184, v185)
						if v192.State == "Fly" and (v188 and (v187 and (v185 - v192.StateAt >= 0.35 and v192.Velocity.Y < 0))) then
							local v198 = v192.Position - v187
							local v199 = v198.Y
							local v200
							if math.abs(v199) <= v_u_11.MAGNET_VERTICAL then
								v200 = Vector2.new(v198.X, v198.Z).Magnitude <= v_u_11.MAGNET_RADIUS
							else
								v200 = false
							end
							if v200 then
								v192.Velocity = v192.Velocity * 0.3 + Vector3.new(0, 12, 0)
								v192.MagnetAt = v185
								v192.Part.Transparency = 0
								v192.Part.Glint.Enabled = false
								v192.Part.Trail.Enabled = true
								v192.State = "Magnet"
								v192.StateAt = v185
							end
						end
						if v192.State ~= "Wait" and not v212 then
							v190 = v192.BaseSize * v192.Scale
							if v193.Size ~= v190 then
								v193.Size = v190
							end
							v_u_38[#v_u_38 + 1] = v193
							v191 = v190.Y * v_u_27[v192.Kind].CenterY
							v_u_39[#v_u_39 + 1] = CFrame.new(v192.Position) * v192.Rotation * CFrame.new(0, -v191, 0)
						end
						v189 = v189 + 1
					end
					if v194 ~= "Brake" then
						break
					end
					if v_u_155(v192, p184, v185) then
						v192.SettleFrom = CFrame.new(v192.Position) * v192.Rotation
						v192.Velocity = Vector3.new(0, 0, 0)
						v192.Part.Trail.Enabled = false
						v192.State = "Settle"
						v192.StateAt = v185
					end
					if v188 and v187 then
						local v201 = v192.Position - v187
						local v202 = v201.Y
						local v203
						if math.abs(v202) <= v_u_11.MAGNET_VERTICAL then
							v203 = Vector2.new(v201.X, v201.Z).Magnitude <= v_u_11.MAGNET_RADIUS
						else
							v203 = false
						end
						if v203 then
							v192.Velocity = v192.Velocity * 0.3 + Vector3.new(0, 12, 0)
							v192.MagnetAt = v185
							v192.Part.Transparency = 0
							v192.Part.Glint.Enabled = false
							v192.Part.Trail.Enabled = true
							v192.State = "Magnet"
							v192.StateAt = v185
						end
					end
					if v192.State ~= "Wait" and not v212 then
						v190 = v192.BaseSize * v192.Scale
						if v193.Size ~= v190 then
							v193.Size = v190
						end
						v_u_38[#v_u_38 + 1] = v193
						v191 = v190.Y * v_u_27[v192.Kind].CenterY
						v_u_39[#v_u_39 + 1] = CFrame.new(v192.Position) * v192.Rotation * CFrame.new(0, -v191, 0)
					end
					v189 = v189 + 1
				end
				if v194 ~= "Settle" then
					break
				end
				local v204 = (v185 - v192.StateAt) / 0.45
				local v205 = math.clamp(v204, 0, 1)
				local v206 = v205 * v205 * (3 - v205 * 2)
				local v207 = v192.SettleFrom:Lerp(v_u_115(v192, v192.FloatCenter, v185), v206)
				v192.Rotation = v207.Rotation
				v192.Position = v207.Position
				if v205 >= 1 then
					v193.Glint.Enabled = true
					v192.State = "Rest"
					v192.StateAt = v185
				end
				if v188 and v187 then
					local v208 = v192.Position - v187
					local v209 = v208.Y
					local v210
					if math.abs(v209) <= v_u_11.MAGNET_VERTICAL then
						v210 = Vector2.new(v208.X, v208.Z).Magnitude <= v_u_11.MAGNET_RADIUS
					else
						v210 = false
					end
					if v210 then
						v192.Velocity = v192.Velocity * 0.3 + Vector3.new(0, 12, 0)
						v192.MagnetAt = v185
						v192.Part.Transparency = 0
						v192.Part.Glint.Enabled = false
						v192.Part.Trail.Enabled = true
						v192.State = "Magnet"
						v192.StateAt = v185
					end
				end
				if v192.State ~= "Wait" and not v212 then
					v190 = v192.BaseSize * v192.Scale
					if v193.Size ~= v190 then
						v193.Size = v190
					end
					v_u_38[#v_u_38 + 1] = v193
					v191 = v190.Y * v_u_27[v192.Kind].CenterY
					v_u_39[#v_u_39 + 1] = CFrame.new(v192.Position) * v192.Rotation * CFrame.new(0, -v191, 0)
				end
				v189 = v189 + 1
			end
			if v194 ~= "Rest" then
				break
			end
			local v211 = v192.FloatCenter
			local v212 = v_u_34:Skips(v211, v189)
			if not v212 then
				local v213 = v_u_115(v192, v211, v185)
				v192.Rotation = v213.Rotation
				v192.Position = v213.Position
			end
			local v214, v215
			if v188 and v187 then
				local v216 = v192.Position - v187
				local v217 = v216.Y
				local v218
				if math.abs(v217) <= v_u_11.MAGNET_VERTICAL then
					v218 = Vector2.new(v216.X, v216.Z).Magnitude <= v_u_11.MAGNET_RADIUS
				else
					v218 = false
				end
				if v218 then
					v192.Velocity = v192.Velocity * 0.3 + Vector3.new(0, 12, 0)
					v192.MagnetAt = v185
					v192.Part.Transparency = 0
					v192.Part.Glint.Enabled = false
					v192.Part.Trail.Enabled = true
					v192.State = "Magnet"
					v192.StateAt = v185
					if v192.State ~= "Wait" and not v212 then
						v190 = v192.BaseSize * v192.Scale
						if v193.Size ~= v190 then
							v193.Size = v190
						end
						v_u_38[#v_u_38 + 1] = v193
						v191 = v190.Y * v_u_27[v192.Kind].CenterY
						v_u_39[#v_u_39 + 1] = CFrame.new(v192.Position) * v192.Rotation * CFrame.new(0, -v191, 0)
					end
					v189 = v189 + 1
				else
					if v192.ExpiresAt <= v185 then
						v193.Glint.Enabled = false
						v193.Transparency = 0
						v192.State = "Shrink"
						v192.StateAt = v185
					elseif v192.ExpiresAt - 5 <= v185 then
						v214 = 1 - (v192.ExpiresAt - v185) / 5
						v215 = v_u_25[1] + (v_u_25[2] - v_u_25[1]) * v214
						v193.Transparency = (v185 - (v192.ExpiresAt - 5)) * v215 % 1 < 0.5 and 0 or 0.75
					end
					if v192.State ~= "Wait" and not v212 then
						v190 = v192.BaseSize * v192.Scale
						if v193.Size ~= v190 then
							v193.Size = v190
						end
						v_u_38[#v_u_38 + 1] = v193
						v191 = v190.Y * v_u_27[v192.Kind].CenterY
						v_u_39[#v_u_39 + 1] = CFrame.new(v192.Position) * v192.Rotation * CFrame.new(0, -v191, 0)
					end
					v189 = v189 + 1
				end
			else
				if v192.ExpiresAt <= v185 then
					v193.Glint.Enabled = false
					v193.Transparency = 0
					v192.State = "Shrink"
					v192.StateAt = v185
				elseif v192.ExpiresAt - 5 <= v185 then
					v214 = 1 - (v192.ExpiresAt - v185) / 5
					v215 = v_u_25[1] + (v_u_25[2] - v_u_25[1]) * v214
					v193.Transparency = (v185 - (v192.ExpiresAt - 5)) * v215 % 1 < 0.5 and 0 or 0.75
				end
				if v192.State ~= "Wait" and not v212 then
					v190 = v192.BaseSize * v192.Scale
					if v193.Size ~= v190 then
						v193.Size = v190
					end
					v_u_38[#v_u_38 + 1] = v193
					v191 = v190.Y * v_u_27[v192.Kind].CenterY
					v_u_39[#v_u_39 + 1] = CFrame.new(v192.Position) * v192.Rotation * CFrame.new(0, -v191, 0)
				end
				v189 = v189 + 1
			end
		end
		if v194 == "Shrink" then
			local v219 = v192.FloatCenter
			if v219 then
				local v220 = v_u_115(v192, v219, v185)
				v192.Rotation = v220.Rotation
				v192.Position = v220.Position
			end
			local v221 = (v185 - v192.StateAt) / 0.25
			local v222 = 1 - v221
			v192.Scale = math.max(v222, 0)
			if v221 >= 1 then
				local v223 = v_u_32[v189]
				v_u_32[v189] = v_u_32[#v_u_32]
				v_u_32[#v_u_32] = nil
				local v224 = v_u_30[v223.Kind]
				v223.Part.Size = v223.BaseSize
				if v224 then
					v224:Release(v223.Part, v223.Lease)
				else
					v223.Part:Destroy()
				end
			else
				if v192.State ~= "Wait" and not v212 then
					v190 = v192.BaseSize * v192.Scale
					if v193.Size ~= v190 then
						v193.Size = v190
					end
					v_u_38[#v_u_38 + 1] = v193
					v191 = v190.Y * v_u_27[v192.Kind].CenterY
					v_u_39[#v_u_39 + 1] = CFrame.new(v192.Position) * v192.Rotation * CFrame.new(0, -v191, 0)
				end
				v189 = v189 + 1
			end
		elseif v194 == "Magnet" and v_u_183(v192, p184, v185) then
			local v225 = v_u_32[v189]
			if not v225.Vacuum then
				local v226 = v_u_37
				local v227 = v225.Drop
				local v228 = v_u_37[v225.Drop] or 0
				local v229 = v225.Bit
				v226[v227] = bit32.bor(v228, v229)
			end
			v_u_18.Collect()
			local v230 = v_u_32[v189]
			v_u_32[v189] = v_u_32[#v_u_32]
			v_u_32[#v_u_32] = nil
			local v231 = v_u_30[v230.Kind]
			v230.Part.Size = v230.BaseSize
			if v231 then
				v231:Release(v230.Part, v230.Lease)
			else
				v230.Part:Destroy()
			end
		else
			if v192.State ~= "Wait" and not v212 then
				v190 = v192.BaseSize * v192.Scale
				if v193.Size ~= v190 then
					v193.Size = v190
				end
				v_u_38[#v_u_38 + 1] = v193
				v191 = v190.Y * v_u_27[v192.Kind].CenterY
				v_u_39[#v_u_39 + 1] = CFrame.new(v192.Position) * v192.Rotation * CFrame.new(0, -v191, 0)
			end
			v189 = v189 + 1
		end
	end
end
local function v_u_235(p233, p234) -- name: byExpiry
	return p233.ExpiresAt < p234.ExpiresAt
end
local function v_u_242(p236) -- name: trimOverflow
	-- upvalues: (copy) v_u_32, (copy) v_u_235
	local v237 = #v_u_32 - 60
	if v237 > 0 then
		local v238 = {}
		for _, v239 in v_u_32 do
			if v239.State ~= "Rest" or v239.ExpiresAt <= p236 + 1.5 then
				continue
			end
			v238[#v238 + 1] = v239
		end
		table.sort(v238, v_u_235)
		local v240 = #v238
		for v241 = 1, math.min(v237, v240) do
			v238[v241].ExpiresAt = p236 + 1.5
		end
	end
end
local function v_u_272(p243) -- name: spawnDrop
	-- upvalues: (ref) v_u_45, (copy) v_u_9, (ref) v_u_40, (ref) v_u_41, (ref) v_u_42, (ref) v_u_43, (copy) v_u_29, (copy) v_u_22, (copy) v_u_20, (copy) v_u_23, (copy) v_u_21, (copy) v_u_11, (copy) v_u_30, (copy) v_u_102, (copy) v_u_32, (copy) v_u_18, (copy) v_u_24, (copy) v_u_31, (copy) v_u_242, (ref) v_u_33, (copy) v_u_8, (copy) v_u_232
	if v_u_45 then
		debug.profilebegin("Survival.Candy.Drop")
		local v244 = os.clock()
		local v245 = p243.Origin
		local v246 = v_u_9.GetBodyPosition(p243.Zombie)
		if v246 then
			if (v246 - v245).Magnitude > 6 then
				v246 = v245
			end
		else
			v246 = v245
		end
		local v247 = v_u_40
		local v248 = v_u_41
		local v249 = v_u_42
		local v250 = v_u_43
		if v247 and (v248 and (v249 and v250)) then
			v247.CFrame = CFrame.new(v246)
			v248:Emit(p243.Heavy and 14 or 8)
			v249:Emit(p243.Heavy and 24 or 12)
			v250.PlaybackSpeed = v_u_29:NextNumber(1, 1.08)
			v250.TimePosition = 0.25
			v250:Play()
		end
		local v251
		if p243.Heavy then
			v251 = v_u_22
		else
			v251 = v_u_20
		end
		local v252
		if p243.Heavy then
			v252 = v_u_23
		else
			v252 = v_u_21
		end
		local v253 = p243.Direction
		local v254 = p243.Count
		local v255 = v_u_11.MAX_PIECES
		for v256 = 1, math.min(v254, v255) do
			local v257 = p243.Heavy and (v256 == 1 and v_u_30.ChocolateBar) and "ChocolateBar" or v_u_102()
			local v258, v259 = v_u_30[v257]:Acquire()
			v258.Trail.Enabled = false
			v258.Glint.Enabled = false
			v258.Transparency = 0
			local v260 = v_u_29:NextNumber(0, 6.283185307179586)
			local v261 = v_u_29:NextNumber(v252[1], v252[2])
			local v262 = math.cos(v260) * v261
			local v263 = v_u_29:NextNumber(v251[1], v251[2])
			local v264 = math.sin(v260) * v261
			local v265 = Vector3.new(v262, v263, v264) + v253 * (v261 * 0.2 + 1.5)
			local v266 = v_u_29:NextUnitVector()
			local v267 = v_u_32
			local v268 = #v_u_32 + 1
			local v269 = {
				["Kind"] = nil,
				["Part"] = nil,
				["Lease"] = nil,
				["Drop"] = nil,
				["Bit"] = nil,
				["State"] = "Wait",
				["StateAt"] = nil,
				["LaunchAt"] = nil,
				["Pitch"] = nil,
				["ExpiresAt"] = nil,
				["Origin"] = nil,
				["Position"] = nil,
				["Velocity"] = nil,
				["Rotation"] = nil,
				["SpinAxis"] = nil,
				["SpinSpeed"] = nil,
				["Bounces"] = 0,
				["SettleFrom"] = nil,
				["FloatCenter"] = nil,
				["FloatPhase"] = nil,
				["BrakeFrom"] = Vector3.new(0, 0, 0),
				["BrakeVelocity"] = Vector3.new(0, 0, 0),
				["BrakeSeconds"] = 0,
				["BaseSize"] = nil,
				["Scale"] = 1,
				["Vacuum"] = false,
				["MagnetAt"] = 0,
				["Kind"] = v257,
				["Part"] = v258,
				["Lease"] = v259,
				["Drop"] = p243.Drop
			}
			local v270 = v256 - 1
			v269.Bit = bit32.lshift(1, v270)
			v269.StateAt = v244
			v269.LaunchAt = v244 + (v256 - 1) * 0.035
			v269.Pitch = v_u_18.LadderPitch(v256 - 1)
			v269.ExpiresAt = v244 + v_u_11.LIFETIME
			v269.Origin = v246
			v269.Position = v246 + v_u_29:NextUnitVector() * 0.3
			v269.Velocity = v265
			v269.Rotation = CFrame.fromAxisAngle(v_u_29:NextUnitVector(), v_u_29:NextNumber(0, 6.283185307179586))
			v269.SpinAxis = v266
			local v271 = v_u_24
			v269.SpinSpeed = v_u_29:NextNumber(v271[1], v271[2])
			v269.FloatPhase = v_u_29:NextNumber(0, 10)
			v269.BaseSize = v_u_31[v257]
			v267[v268] = v269
		end
		v_u_242(v244)
		if not v_u_33 then
			v_u_33 = v_u_8.BindToRenderSteppedEvent("Survival.Candy", v_u_232)
		end
		debug.profileend()
	end
end
local function v_u_285() -- name: vacuum
	-- upvalues: (copy) v_u_6, (copy) v_u_14, (copy) v_u_32, (ref) v_u_44, (ref) v_u_33, (copy) v_u_8, (copy) v_u_232
	local v273 = v_u_6.CurrentCamera
	local v274 = v_u_14.getRootPart(v_u_14.getLocalCharacter())
	local v_u_275
	if v274 then
		v_u_275 = v274.Position
	else
		v_u_275 = nil
	end
	if not v_u_275 then
		if v273 then
			v_u_275 = v273.CFrame.Position
		else
			v_u_275 = nil
		end
	end
	if v_u_275 then
		local v276 = {}
		for _, v277 in v_u_32 do
			if v277.State == "Magnet" or v277.State == "Shrink" then
				continue
			end
			v277.Vacuum = true
			v276[#v276 + 1] = v277
		end
		if #v276 ~= 0 then
			table.sort(v276, function(p278, p279)
				-- upvalues: (copy) v_u_275
				return (p278.Position - v_u_275).Magnitude < (p279.Position - v_u_275).Magnitude
			end)
			for v280, v_u_281 in v276 do
				if v_u_281.State == "Wait" then
					continue
				end
				task.delay((v280 - 1) * 0.05, function()
					-- upvalues: (ref) v_u_32, (copy) v_u_281
					if table.find(v_u_32, v_u_281) and (v_u_281.State ~= "Magnet" and v_u_281.State ~= "Shrink") then
						local v282 = v_u_281
						local v283 = os.clock()
						v282.Velocity = v282.Velocity * 0.3 + Vector3.new(0, 12, 0)
						v282.MagnetAt = v283
						v282.Part.Transparency = 0
						v282.Part.Glint.Enabled = false
						v282.Part.Trail.Enabled = true
						v282.State = "Magnet"
						v282.StateAt = v283
					end
				end)
			end
			local v284 = v_u_44
			if v284 then
				v284:Play()
			end
			if not v_u_33 then
				v_u_33 = v_u_8.BindToRenderSteppedEvent("Survival.Candy", v_u_232)
			end
		end
	else
		return
	end
end
local function v_u_289() -- name: clearAll
	-- upvalues: (copy) v_u_32, (copy) v_u_30, (copy) v_u_37, (copy) v_u_18
	while #v_u_32 > 0 do
		local v286 = #v_u_32
		local v287 = v_u_32[v286]
		v_u_32[v286] = v_u_32[#v_u_32]
		v_u_32[#v_u_32] = nil
		local v288 = v_u_30[v287.Kind]
		v287.Part.Size = v287.BaseSize
		if v288 then
			v288:Release(v287.Part, v287.Lease)
		else
			v287.Part:Destroy()
		end
	end
	table.clear(v_u_37)
	v_u_18.Clear()
end
function v1.GetPieceCount() -- name: GetPieceCount
	-- upvalues: (copy) v_u_32
	return #v_u_32
end
function v1.Start() -- name: Start
	-- upvalues: (ref) v_u_46, (copy) v_u_13, (copy) v_u_62, (copy) v_u_95, (copy) v_u_19, (copy) v_u_272, (copy) v_u_285, (copy) v_u_6, (copy) v_u_289
	if not v_u_46 and v_u_13.IsSurvival() then
		v_u_46 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_62, (ref) v_u_95
			v_u_62()
			v_u_95()
		end)
	end
	v_u_19.Survival.CandyDrop.Listen(function(p290)
		-- upvalues: (ref) v_u_13, (ref) v_u_272
		if type(p290) == "table" and v_u_13.IsSurvival() then
			task.delay(0.12, v_u_272, p290)
		end
	end)
	v_u_19.Survival.CandyVacuum.Listen(v_u_285)
	v_u_6:GetAttributeChangedSignal("Gamemode"):Connect(function()
		-- upvalues: (ref) v_u_13, (ref) v_u_289, (ref) v_u_46, (ref) v_u_62, (ref) v_u_95
		if not v_u_13.IsSurvival() then
			v_u_289()
		end
		if not v_u_46 then
			if not v_u_13.IsSurvival() then
				return
			end
			v_u_46 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_62, (ref) v_u_95
				v_u_62()
				v_u_95()
			end)
		end
	end)
end
return v1
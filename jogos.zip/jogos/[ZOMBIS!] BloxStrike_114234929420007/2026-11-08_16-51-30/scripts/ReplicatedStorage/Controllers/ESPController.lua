-- NIGHT Analyzer | ReplicatedStorage.Controllers.ESPController
-- ModuleScript | 115 linhas | 2833 bytes | hash ef9b07da

local v1 = {}
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = v2.LocalPlayer
local v_u_6 = require(v3.Components.Common.Participants)
local v_u_7 = Color3.fromRGB(255, 70, 70)
local v_u_8 = Color3.fromRGB(255, 255, 255)
local v_u_9 = {}
local v_u_10 = nil
local v_u_11 = false
local function v_u_15(p12) -- name: isEnemy
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_4
	if p12 == v_u_5 or not v_u_6.IsAlive(p12) then
		return false
	end
	if v_u_4:GetAttribute("Gamemode") == "Deathmatch" then
		return true
	end
	local v13 = p12:GetAttribute("Team")
	local v14
	if v13 == "Terrorists" or v13 == "Counter-Terrorists" then
		v14 = v13 ~= v_u_5:GetAttribute("Team")
	else
		v14 = false
	end
	return v14
end
local function v_u_24() -- name: refresh
	-- upvalues: (copy) v_u_6, (copy) v_u_15, (copy) v_u_4, (copy) v_u_9, (copy) v_u_7, (copy) v_u_8, (ref) v_u_10
	local v16 = {}
	for _, v17 in v_u_6.GetAll() do
		if not v_u_15(v17) then
			continue
		end
		local v18 = v_u_6.Character(v17)
		if not (v18 and v18:IsDescendantOf(v_u_4)) then
			continue
		end
		v16[v18] = true
	end
	for v19, v20 in v_u_9 do
		if v16[v19] then
			continue
		end
		v20:Destroy()
		v_u_9[v19] = nil
	end
	for v21 in v16 do
		if v_u_9[v21] ~= nil then
			continue
		end
		local v22 = Instance.new("Highlight")
		v22.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
		v22.FillColor = v_u_7
		v22.FillTransparency = 0.55
		v22.OutlineColor = v_u_8
		v22.OutlineTransparency = 0
		v22.Adornee = v21
		local v23
		if v_u_10 and v_u_10.Parent then
			v23 = v_u_10
		else
			v23 = Instance.new("Folder")
			v23.Name = "VIPESP"
			v23.Parent = v_u_4.CurrentCamera
			v_u_10 = v23
		end
		v22.Parent = v23
		v_u_9[v21] = v22
	end
end
function v1.Start() -- name: Start
	-- upvalues: (copy) v_u_5, (ref) v_u_11, (copy) v_u_24, (copy) v_u_9
	v_u_5:GetAttributeChangedSignal("VIPESP"):Connect(function()
		-- upvalues: (ref) v_u_5, (ref) v_u_11, (ref) v_u_24, (ref) v_u_9
		if v_u_5:GetAttribute("VIPESP") == true then
			if v_u_11 then
				return
			end
			v_u_11 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_5, (ref) v_u_24, (ref) v_u_9, (ref) v_u_11
				while v_u_5:GetAttribute("VIPESP") == true do
					v_u_24()
					task.wait(0.25)
				end
				for _, v25 in v_u_9 do
					v25:Destroy()
				end
				table.clear(v_u_9)
				v_u_11 = false
			end)
		end
	end)
	if v_u_5:GetAttribute("VIPESP") == true then
		if v_u_11 then
			return
		end
		v_u_11 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_5, (ref) v_u_24, (ref) v_u_9, (ref) v_u_11
			while v_u_5:GetAttribute("VIPESP") == true do
				v_u_24()
				task.wait(0.25)
			end
			for _, v26 in v_u_9 do
				v26:Destroy()
			end
			table.clear(v_u_9)
			v_u_11 = false
		end)
	end
end
return v1
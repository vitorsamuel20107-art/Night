-- NIGHT Analyzer | ReplicatedStorage.Controllers.BlackMarketSceneController
-- ModuleScript | 1228 linhas | 35941 bytes | hash 1af5a392

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("Lighting")
local v_u_5 = game:GetService("Players")
local v6 = require(v_u_2.Shared.Janitor)
local v_u_7 = require(v_u_2.Shared.BakedViewmodelMirror)
local v_u_8 = require(v_u_2.Components.Common.SceneParking)
local v_u_9 = require(v_u_2.Components.Common.CharacterResolver)
v_u_1.OnActiveChanged = require(v_u_2.Packages.Signal).new()
local v_u_10 = require(v_u_2.Database.Security.Router)
local v_u_11 = require(v_u_2.Controllers.RunServiceController)
local v_u_12 = require(v_u_2.Controllers.CameraController)
local v_u_13 = require(v_u_2.Database.Custom.Constants)
local v_u_14 = require(script.DealerLines)
local v_u_15 = Enum.RenderPriority.Camera.Value + 10
local v_u_16 = Enum.EasingStyle.Sine
local v_u_17 = Random.new()
local v_u_18 = Enum.EasingStyle.Cubic
local v_u_19 = Enum.EasingStyle.Back
local v_u_20 = {
	["Ambient"] = nil,
	["OutdoorAmbient"] = nil,
	["ColorShift_Bottom"] = nil,
	["ColorShift_Top"] = nil,
	["Brightness"] = 4.5,
	["EnvironmentDiffuseScale"] = 1,
	["EnvironmentSpecularScale"] = 1,
	["GlobalShadows"] = true,
	["ShadowSoftness"] = 0.06,
	["ClockTime"] = 9.8,
	["GeographicLatitude"] = 50,
	["ExposureCompensation"] = 0,
	["FogStart"] = 100000,
	["FogEnd"] = 100000,
	["Ambient"] = Color3.fromRGB(68, 68, 68),
	["OutdoorAmbient"] = Color3.fromRGB(120, 128, 143),
	["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0),
	["ColorShift_Top"] = Color3.fromRGB(208, 168, 108)
}
local v_u_21 = workspace.CurrentCamera
local v_u_22 = nil
local v_u_23 = {}
local v_u_24 = {}
local v_u_25 = {}
local v_u_26 = {}
local v_u_27 = {}
local v_u_28 = {}
local v_u_29 = {}
local v_u_30 = {}
local v_u_31 = nil
local v_u_32 = nil
local v_u_33 = 1
local v_u_34 = {}
local v_u_35 = {}
local v_u_36 = false
local v_u_37 = false
local v_u_38 = v6.new()
local v_u_39 = false
local v_u_40 = false
local v_u_41 = false
local v_u_42 = {}
local v_u_43 = true
local v_u_44 = 0
local v_u_45 = nil
local v_u_46 = {}
local v_u_47 = nil
local v_u_48 = nil
local v_u_49 = nil
local v_u_50 = nil
local v_u_51 = nil
local v_u_52 = nil
local v_u_53 = nil
local v_u_54 = 0
local v_u_55 = nil
local v_u_56 = nil
local function v_u_60() -- name: applySceneLighting
	-- upvalues: (copy) v_u_20, (copy) v_u_4
	for v57, v58 in v_u_20 do
		v_u_4[v57] = v58
	end
	for _, v59 in v_u_4:GetChildren() do
		if v59.Name == "Menu" then
			continue
		end
		v59:Destroy()
	end
end
local function v_u_63(p61) -- name: setPerspectiveSinksInput
	-- upvalues: (copy) v_u_5
	local v62 = v_u_5.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	if v62 then
		v62 = v62:FindFirstChild("MainGui")
	end
	if v62 then
		v62 = v62:FindFirstChild("CameraPerspective")
	end
	if not (v62 and v62:IsA("GuiButton")) then
		warn("[BlackMarketSceneController]: MainGui.CameraPerspective was not found, card clicks may be swallowed")
		return false
	end
	v62.Active = p61
	v62.Interactable = p61
	return true
end
local v_u_64 = {}
local v_u_65 = {}
local function v_u_68(p66) -- name: hideInstance
	-- upvalues: (copy) v_u_64, (copy) v_u_65
	if p66:IsA("BasePart") or p66:IsA("Decal") then
		if v_u_64[p66] == nil then
			v_u_64[p66] = p66.LocalTransparencyModifier
		end
		p66.LocalTransparencyModifier = 1
	elseif p66:IsA("SurfaceGui") and p66.Enabled then
		p66.Enabled = false
		local v67 = v_u_65
		table.insert(v67, p66)
	end
end
local function v_u_72() -- name: showViewmodels
	-- upvalues: (copy) v_u_64, (copy) v_u_65
	for v69, v70 in v_u_64 do
		if not v69.Parent then
			continue
		end
		v69.LocalTransparencyModifier = v70
	end
	table.clear(v_u_64)
	for _, v71 in v_u_65 do
		if not v71.Parent then
			continue
		end
		v71.Enabled = true
	end
	table.clear(v_u_65)
end
local function v_u_76(p73, p74) -- name: applyCardVisibility
	for _, v75 in p73:GetChildren() do
		if not v75:IsA("SurfaceGui") then
			continue
		end
		v75.Enabled = p74
	end
end
local function v_u_80() -- name: captureGameplayAim
	-- upvalues: (copy) v_u_9, (copy) v_u_21, (copy) v_u_5
	local v77 = v_u_9.getLocalCharacter()
	if not (v77 and v_u_9.isAliveCharacter(v77)) then
		return nil
	end
	local v78 = v_u_21.CameraSubject
	local v79 = v_u_9.getCameraPart(v77)
	return v_u_21.CameraType == Enum.CameraType.Custom and (v78 and (v78:IsDescendantOf(v77) and (v79 and (v_u_21.CFrame.Position - v79.Position).Magnitude <= v_u_5.LocalPlayer.CameraMaxZoomDistance + 4))) and {
		["Character"] = v77,
		["Rotation"] = v_u_21.CFrame.Rotation
	} or nil
end
local function v_u_85() -- name: restoreGameplayAim
	-- upvalues: (ref) v_u_55, (copy) v_u_9, (copy) v_u_21, (copy) v_u_12
	local v81 = v_u_55
	v_u_55 = nil
	if v81 then
		local v82 = v81.Character
		if v82 == v_u_9.getLocalCharacter() and v_u_9.isAliveCharacter(v82) then
			local v83 = v_u_9.getCameraPart(v82)
			local v84
			if v83 then
				v84 = v83.Position
			else
				v84 = v_u_21.CFrame.Position
			end
			v_u_21.CFrame = CFrame.new(v84) * v81.Rotation
			v_u_21.Focus = v_u_21.CFrame
			v_u_12.setBaseCameraCFrame(v_u_21.CFrame)
		end
	else
		return
	end
end
local v_u_86 = {
	["face"] = "TopMost",
	["Cube.002"] = "Tie",
	["Cube.012"] = "UpperBody.001",
	["UpperTorso"] = "UpperBody.001",
	["Cube.003"] = "UpperLeg.L"
}
local function v_u_95(p87) -- name: attachUnskinnedParts
	-- upvalues: (copy) v_u_86
	for v88, v89 in v_u_86 do
		local v90 = p87:FindFirstChild(v88)
		local v91 = p87:FindFirstChild(v89, true)
		if not v90 or (not v90:IsA("MeshPart") or (not v91 or (not v91:IsA("Bone") or v90.HasSkinnedMesh))) then
			continue
		end
		for _, v92 in v90:GetChildren() do
			if not v92:IsA("Motor6D") or v92.Part1 ~= v90 then
				continue
			end
			v92.Enabled = false
		end
		local v93 = Instance.new("Attachment")
		v93.Name = "BoneFollow"
		v93.CFrame = v90.CFrame:ToObjectSpace(v91.WorldCFrame)
		v93.Parent = v90
		local v94 = Instance.new("RigidConstraint")
		v94.Name = "BoneFollow"
		v94.Attachment0 = v93
		v94.Attachment1 = v91
		v94.Parent = v90
		v90.Anchored = false
	end
end
local function v_u_98() -- name: stopCurrentLine
	-- upvalues: (ref) v_u_49, (ref) v_u_48
	local v96 = v_u_49
	v_u_49 = nil
	if v96 and v96.Parent then
		v96:Stop()
		if v96:GetAttribute("Persistent") ~= true then
			v96:Destroy()
		end
	end
	local v97 = v_u_48
	v_u_48 = nil
	if v97 and v97.IsPlaying then
		v97:Stop(0.15)
	end
end
local function v_u_107(p99) -- name: playDealerLine
	-- upvalues: (copy) v_u_14, (copy) v_u_98, (ref) v_u_50, (copy) v_u_10, (ref) v_u_49, (ref) v_u_45, (copy) v_u_46, (ref) v_u_48
	local v100 = v_u_14.Pick(p99)
	if not v100 then
		return nil
	end
	v_u_98()
	local v101 = v_u_50
	v_u_50 = nil
	if v101 and v101.IsPlaying then
		v101:Stop(0.15)
	end
	local v102 = v_u_10.broadcastRouter("RunArmsDealerSound", v100.Sound)
	if typeof(v102) == "Instance" and v102:IsA("Sound") then
		v_u_49 = v102
	end
	local v103 = v100.Animation
	local v104 = v_u_45
	local v105 = not v104 or v_u_46[v103]
	if not v105 then
		local v106 = Instance.new("Animation")
		v106.AnimationId = v103
		v105 = v104:LoadAnimation(v106)
		v_u_46[v103] = v105
	end
	if v105 then
		v105.Looped = false
		v105.Priority = Enum.AnimationPriority.Action
		v105:Stop(0)
		v105:Play(0.15)
		v_u_48 = v105
	end
	return v_u_49
end
local function v_u_116(p108, p109) -- name: setCardScale
	-- upvalues: (copy) v_u_29, (copy) v_u_30
	local v110 = v_u_29[p108]
	if v110 then
		local v111 = v110.X * p109
		local v112 = v110.Y * p109
		local v113 = v110.Z
		p108.Size = Vector3.new(v111, v112, v113)
		for _, v114 in p108:GetChildren() do
			if not v114:IsA("SurfaceGui") then
				continue
			end
			local v115 = v_u_30[v114]
			if not v115 then
				continue
			end
			v114.PixelsPerStud = v115 / p109
		end
	end
end
local function v_u_123(p_u_117) -- name: getCardSpin
	-- upvalues: (ref) v_u_26, (ref) v_u_25, (ref) v_u_24
	local v118 = v_u_26[p_u_117]
	if v118 then
		return v118
	end
	local v119 = Instance.new("NumberValue")
	v119.Value = v_u_25[p_u_117] and 0 or 3.141592653589793
	local v_u_120 = {
		["Angle"] = nil,
		["Target"] = nil,
		["IsTurning"] = false,
		["Direction"] = -1,
		["Angle"] = v119,
		["Target"] = v119.Value
	}
	v119.Changed:Connect(function(p121)
		-- upvalues: (ref) v_u_24, (copy) p_u_117, (copy) v_u_120
		local v122 = v_u_24[p_u_117]
		if v_u_120.IsTurning and v122 then
			p_u_117.CFrame = v122 * CFrame.Angles(0, p121, 0)
		end
	end)
	v_u_26[p_u_117] = v_u_120
	return v_u_120
end
local function v_u_154(p124, p125) -- name: getDealPose
	-- upvalues: (ref) v_u_34, (copy) v_u_29, (ref) v_u_33, (ref) v_u_25, (ref) v_u_51, (copy) v_u_21, (copy) v_u_3, (copy) v_u_18, (copy) v_u_19, (ref) v_u_32
	local v126 = v_u_34[p124]
	local v127 = v_u_29[p124]
	if not (v126 and v127) then
		return nil, v_u_33
	end
	if not v_u_25[p124] then
		v126 = v126 * CFrame.Angles(0, 3.141592653589793, 0)
	end
	local v128 = v127 * v_u_33
	local v129 = v_u_51 or v_u_21.CFrame
	local v130 = v129.RightVector.X
	local v131 = v129.RightVector.Z
	local v132 = Vector3.new(v130, 0, v131)
	local v133 = v132.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v132.Unit
	local v134 = (Vector3.new(0, 1, 0)):Cross(v133)
	local v135 = v126.Position
	local v136 = -v133 * (v128.X * 1.4) + v134 * 3
	local v137 = v135 - Vector3.new(0, 4, 0) + v136
	local v138 = v_u_3:GetValue(p125, v_u_18, Enum.EasingDirection.Out)
	local v139 = v_u_3
	local v140 = v138 / 0.4
	local v141 = v139:GetValue(math.min(v140, 1), Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	local v142 = (v138 - 0.3) / 0.7
	local v143 = v_u_3:GetValue(math.clamp(v142, 0, 1), Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
	local v144 = v128.Y * 0.3
	local v145 = 3.141592653589793 * v143
	local v146 = v144 * math.sin(v145)
	local v147 = v137 + Vector3.new(0, 1, 0) * (4 * v141 + v146) - v136 * v143
	local v148 = 1 - v_u_3:GetValue(p125, v_u_19, Enum.EasingDirection.Out)
	local v149 = CFrame.fromAxisAngle(v134, -0.4188790204786391 * v148) * CFrame.fromAxisAngle(Vector3.new(0, 1, 0), -0.6108652381980153 * v148)
	local v150 = (v138 - 0.4) / 0.6
	local v151 = math.clamp(v150, 0, 1) * -0.30000000000000004 + 1
	local v152 = CFrame.new(v147) * v149 * v126.Rotation
	local v153 = v_u_32
	if v153 then
		v152 = v152 - v152.Position + (v153 + (v152.Position - v153) * v151)
	end
	return v152, v_u_33 * v151
end
local function v_u_160() -- name: settleDeal
	-- upvalues: (ref) v_u_44, (ref) v_u_40, (ref) v_u_41, (ref) v_u_23, (copy) v_u_38, (ref) v_u_27, (ref) v_u_24, (ref) v_u_25, (copy) v_u_116, (ref) v_u_33, (copy) v_u_42, (copy) v_u_76, (ref) v_u_35, (ref) v_u_36, (ref) v_u_37
	v_u_44 = v_u_44 + 1
	v_u_40 = false
	v_u_41 = false
	for _, v155 in v_u_23 do
		v_u_38:Remove((("CardDeal_%*"):format(v_u_27[v155] or 0)))
		local v156 = v_u_24[v155]
		if v156 then
			if not v_u_25[v155] then
				v156 = v156 * CFrame.Angles(0, 3.141592653589793, 0)
			end
		else
			v156 = nil
		end
		if v156 then
			v_u_116(v155, v_u_33 * 0.7)
			v155.CFrame = v156
		end
		v_u_42[v155] = true
	end
	for _, v157 in v_u_23 do
		local v158 = v_u_76
		local v159
		if v_u_35[v157] == true and not (v_u_36 or v_u_37) then
			v159 = not (v_u_40 or v_u_41) or v_u_42[v157] == true
		else
			v159 = false
		end
		v158(v157, v159)
	end
end
local function v_u_179() -- name: runDeal
	-- upvalues: (ref) v_u_44, (ref) v_u_43, (ref) v_u_40, (ref) v_u_41, (ref) v_u_23, (copy) v_u_42, (copy) v_u_154, (copy) v_u_116, (copy) v_u_76, (ref) v_u_35, (ref) v_u_36, (ref) v_u_37, (copy) v_u_107, (copy) v_u_14, (ref) v_u_24, (ref) v_u_25, (copy) v_u_3, (copy) v_u_38, (ref) v_u_27, (copy) v_u_160
	v_u_44 = v_u_44 + 1
	local v_u_161 = v_u_44
	local v_u_162 = v_u_43
	v_u_40 = true
	v_u_41 = false
	v_u_43 = true
	for _, v163 in v_u_23 do
		v_u_42[v163] = false
		local v164, v165 = v_u_154(v163, 0)
		if not v164 then
			continue
		end
		v_u_116(v163, v165)
		v163.CFrame = v164
	end
	for _, v166 in v_u_23 do
		local v167 = v_u_76
		local v168
		if v_u_35[v166] == true and not (v_u_36 or v_u_37) then
			v168 = not (v_u_40 or v_u_41) or v_u_42[v166] == true
		else
			v168 = false
		end
		v167(v166, v168)
	end
	task.spawn(function()
		-- upvalues: (copy) v_u_162, (ref) v_u_107, (ref) v_u_14, (ref) v_u_44, (copy) v_u_161, (ref) v_u_23, (ref) v_u_24, (ref) v_u_25, (ref) v_u_42, (ref) v_u_76, (ref) v_u_35, (ref) v_u_36, (ref) v_u_37, (ref) v_u_40, (ref) v_u_41, (ref) v_u_154, (ref) v_u_116, (ref) v_u_3, (ref) v_u_38, (ref) v_u_27, (ref) v_u_160
		if v_u_162 then
			v_u_107(v_u_14.Open)
		end
		task.wait(0.25)
		if v_u_44 == v_u_161 then
			for v169, v_u_170 in v_u_23 do
				if v_u_44 ~= v_u_161 then
					return
				end
				local v171 = v_u_24[v_u_170]
				if v171 then
					if not v_u_25[v_u_170] then
						v171 = v171 * CFrame.Angles(0, 3.141592653589793, 0)
					end
				else
					v171 = nil
				end
				if v171 then
					v_u_42[v_u_170] = true
					local v172 = v_u_76
					local v173
					if v_u_35[v_u_170] == true and not (v_u_36 or v_u_37) then
						v173 = not (v_u_40 or v_u_41) or v_u_42[v_u_170] == true
					else
						v173 = false
					end
					v172(v_u_170, v173)
					local v_u_174 = Instance.new("NumberValue")
					v_u_174.Changed:Connect(function(p175)
						-- upvalues: (ref) v_u_154, (copy) v_u_170, (ref) v_u_116
						local v176, v177 = v_u_154(v_u_170, p175)
						if v176 then
							v_u_116(v_u_170, v177)
							v_u_170.CFrame = v176
						end
					end)
					local v_u_178 = v_u_3:Create(v_u_174, TweenInfo.new(0.8, Enum.EasingStyle.Linear), {
						["Value"] = 1
					})
					v_u_38:Add(function()
						-- upvalues: (copy) v_u_178, (copy) v_u_174
						v_u_178:Destroy()
						v_u_174:Destroy()
					end, true, (("CardDeal_%*"):format(v_u_27[v_u_170] or v169)))
					v_u_178:Play()
				end
				if v169 >= #v_u_23 then
					continue
				end
				task.wait(0.14)
			end
			task.wait(0.8)
			if v_u_44 == v_u_161 then
				v_u_160()
			end
		else
			return
		end
	end)
end
local function v_u_182() -- name: startDealIfReady
	-- upvalues: (ref) v_u_41, (ref) v_u_39, (ref) v_u_36, (ref) v_u_37, (ref) v_u_23, (ref) v_u_35, (copy) v_u_179
	if v_u_41 and (v_u_39 and not (v_u_36 or v_u_37)) then
		local v180 = false
		for _, v181 in v_u_23 do
			if v_u_35[v181] ~= true then
				continue
			end
			v180 = true
		end
		if v180 then
			v_u_179()
		end
	else
		return
	end
end
local function v_u_186(p183) -- name: makeSceneInert
	local v184 = p183:FindFirstChild("Cards")
	for _, v185 in p183:GetDescendants() do
		if not v185:IsA("BasePart") then
			continue
		end
		v185.CanCollide = false
		v185.CanTouch = false
		v185.CanQuery = v185.Parent == v184
	end
end
local function v_u_193() -- name: captureDesignRow
	-- upvalues: (ref) v_u_23, (copy) v_u_28, (copy) v_u_29, (copy) v_u_30, (ref) v_u_31, (ref) v_u_22, (ref) v_u_32
	for _, v187 in v_u_23 do
		if v_u_28[v187] then
			continue
		end
		v_u_28[v187] = v187.CFrame
		v_u_29[v187] = v187.Size
		for _, v188 in v187:GetChildren() do
			if not v188:IsA("SurfaceGui") then
				continue
			end
			v_u_30[v188] = v188.PixelsPerStud
		end
	end
	local v189 = v_u_23[1]
	local v190 = v_u_23[#v_u_23]
	local v191
	if v189 then
		v191 = v_u_28[v189]
	else
		v191 = v189
	end
	if v190 then
		v190 = v_u_28[v190]
	end
	if v191 and v190 then
		v_u_31 = (v191.Position + v190.Position) / 2 - v191.UpVector * (v_u_29[v189].Y / 2)
		local v192 = v_u_22
		if v192 then
			v192 = v192:FindFirstChild("Camera")
		end
		if v192 then
			v192 = v192:FindFirstChild("Cards")
		end
		if not (v192 and (v192:IsA("BasePart") and v192)) then
			v192 = nil
		end
		if v192 then
			v192 = v192.Position
		end
		v_u_32 = v192
	else
		v_u_31 = nil
	end
end
local function v_u_206() -- name: applyRowFit
	-- upvalues: (ref) v_u_31, (copy) v_u_21, (ref) v_u_33, (ref) v_u_23, (copy) v_u_28, (ref) v_u_34, (ref) v_u_32, (ref) v_u_24, (ref) v_u_27, (copy) v_u_38, (ref) v_u_26, (ref) v_u_25, (copy) v_u_116, (copy) v_u_76, (ref) v_u_35, (ref) v_u_36, (ref) v_u_37, (ref) v_u_40, (ref) v_u_41, (copy) v_u_42
	local v194 = v_u_31
	if v194 then
		local v195 = v_u_21.ViewportSize
		if v195.Y > 0 then
			local v196 = v195.X / v195.Y / 1.7777777777777777
			local v197 = math.min(1, v196)
			v_u_33 = v197
			for _, v198 in v_u_23 do
				local v199 = v_u_28[v198]
				if not v199 then
					continue
				end
				local v200 = v199 - v199.Position + (v194 + (v199.Position - v194) * v197)
				v_u_34[v198] = v200
				local v201 = v_u_32
				if v201 then
					v200 = v200 - v200.Position + (v201 + (v200.Position - v201) * 0.7)
				end
				v_u_24[v198] = v200
				local v202 = v_u_27[v198] or 0
				v_u_38:Remove((("CardFlip_%*"):format(v_u_27[v198] or 0)))
				local v203 = v_u_26[v198]
				if v203 then
					v203.IsTurning = false
					v203.Target = v_u_25[v198] and 0 or 3.141592653589793
					v203.Angle.Value = v203.Target
				end
				v_u_38:Remove((("CardDeal_%*"):format(v202)))
				v_u_116(v198, v197 * 0.7)
				if not v_u_25[v198] then
					v200 = v200 * CFrame.Angles(0, 3.141592653589793, 0)
				end
				v198.CFrame = v200
				local v204 = v_u_76
				local v205
				if v_u_35[v198] == true and not (v_u_36 or v_u_37) then
					v205 = not (v_u_40 or v_u_41) or v_u_42[v198] == true
				else
					v205 = false
				end
				v204(v198, v205)
			end
		end
	else
		return
	end
end
local function v_u_216(p207) -- name: collectCards
	-- upvalues: (ref) v_u_23, (ref) v_u_24, (ref) v_u_34, (ref) v_u_25, (ref) v_u_26, (ref) v_u_35, (ref) v_u_27, (copy) v_u_193, (copy) v_u_206
	v_u_23 = {}
	v_u_24 = {}
	v_u_34 = {}
	v_u_25 = {}
	for _, v208 in v_u_26 do
		v208.Angle:Destroy()
	end
	v_u_26 = {}
	v_u_35 = {}
	v_u_27 = {}
	local v209 = p207:FindFirstChild("Cards")
	if v209 then
		for _, v210 in v209:GetChildren() do
			if not v210:IsA("BasePart") then
				continue
			end
			local v211 = v_u_23
			table.insert(v211, v210)
		end
		table.sort(v_u_23, function(p212, p213)
			return p212.Position.Z < p213.Position.Z
		end)
		for v214, v215 in v_u_23 do
			v_u_27[v215] = v214
		end
		v_u_193()
		v_u_206()
	else
		warn("[BlackMarketSceneController]: scene is missing its Cards folder")
	end
end
function v_u_1.IsActive() -- name: IsActive
	-- upvalues: (ref) v_u_39
	return v_u_39
end
function v_u_1.GetCards() -- name: GetCards
	-- upvalues: (ref) v_u_23
	return v_u_23
end
function v_u_1.GetCardFaces(p217) -- name: GetCardFaces
	local v218 = p217:FindFirstChild("Back")
	local v219 = p217:FindFirstChild("Front")
	if v218 then
		v218 = v218:FindFirstChild("Main")
	end
	if v219 then
		v219 = v219:FindFirstChild("Main")
	end
	return v218, v219
end
function v_u_1.IsCardFaceUp(p220) -- name: IsCardFaceUp
	-- upvalues: (ref) v_u_25
	return v_u_25[p220] == true
end
function v_u_1.SetCardFaceUp(p_u_221, p222, p223) -- name: SetCardFaceUp
	-- upvalues: (ref) v_u_24, (ref) v_u_25, (ref) v_u_40, (ref) v_u_41, (copy) v_u_38, (ref) v_u_27, (ref) v_u_26, (copy) v_u_76, (ref) v_u_35, (ref) v_u_36, (ref) v_u_37, (copy) v_u_42, (copy) v_u_123, (copy) v_u_17, (copy) v_u_3
	local v224 = v_u_24[p_u_221]
	if v224 then
		if v_u_25[p_u_221] == p222 then
			return
		elseif p223 and (v_u_40 or v_u_41) then
			return
		elseif p223 then
			local v_u_225 = v_u_123(p_u_221)
			local v226 = v_u_225.IsTurning
			if not v226 then
				v_u_225.Angle.Value = v_u_25[p_u_221] and 0 or 3.141592653589793
				v_u_225.Target = v_u_225.Angle.Value
				v_u_225.Direction = v_u_17:NextInteger(0, 1) == 0 and -1 or 1
			end
			v_u_225.Target = v_u_225.Target + v_u_225.Direction * 3.141592653589793
			local v227 = v_u_225.Target - v_u_225.Angle.Value
			local v228 = math.abs(v227)
			local v229 = v_u_3
			local v230 = v_u_225.Angle
			local v231 = TweenInfo.new
			local v232 = v228 * 0.42 / 3.141592653589793
			local v233 = Enum.EasingStyle.Quad
			local v234
			if v226 then
				v234 = Enum.EasingDirection.Out
			else
				v234 = Enum.EasingDirection.InOut
			end
			local v235 = v229:Create(v230, v231(v232, v233, v234), {
				["Value"] = v_u_225.Target
			})
			v235.Completed:Once(function(p236)
				-- upvalues: (copy) v_u_225, (ref) v_u_25, (copy) p_u_221
				if p236 == Enum.PlaybackState.Completed then
					v_u_225.IsTurning = false
					v_u_225.Target = v_u_25[p_u_221] and 0 or 3.141592653589793
					v_u_225.Angle.Value = v_u_225.Target
				end
			end)
			v_u_38:Add(v235, "Destroy", (("CardFlip_%*"):format(v_u_27[p_u_221] or 0)))
			v_u_25[p_u_221] = p222
			v_u_225.IsTurning = true
			v235:Play()
		else
			v_u_25[p_u_221] = p222
			v_u_38:Remove((("CardFlip_%*"):format(v_u_27[p_u_221] or 0)))
			local v237 = v_u_26[p_u_221]
			if v237 then
				v237.IsTurning = false
				v237.Target = v_u_25[p_u_221] and 0 or 3.141592653589793
				v237.Angle.Value = v237.Target
			end
			if not p222 then
				v224 = v224 * CFrame.Angles(0, 3.141592653589793, 0)
			end
			p_u_221.CFrame = v224
			local v238 = v_u_76
			local v239
			if v_u_35[p_u_221] == true and not (v_u_36 or v_u_37) then
				v239 = not (v_u_40 or v_u_41) or v_u_42[p_u_221] == true
			else
				v239 = false
			end
			v238(p_u_221, v239)
		end
	else
		return
	end
end
function v_u_1.ResetCards() -- name: ResetCards
	-- upvalues: (ref) v_u_23, (ref) v_u_26, (copy) v_u_38, (ref) v_u_27, (ref) v_u_25, (ref) v_u_24, (copy) v_u_1
	for _, v240 in v_u_23 do
		local v241 = v_u_26[v240]
		if v241 and v241.IsTurning then
			v_u_38:Remove((("CardFlip_%*"):format(v_u_27[v240] or 0)))
			local v242 = v_u_26[v240]
			if v242 then
				v242.IsTurning = false
				v242.Target = v_u_25[v240] and 0 or 3.141592653589793
				v242.Angle.Value = v242.Target
			end
			local v243 = v_u_24[v240]
			if v243 then
				if not v_u_25[v240] then
					v243 = v243 * CFrame.Angles(0, 3.141592653589793, 0)
				end
			else
				v243 = nil
			end
			if v243 then
				v240.CFrame = v243
			end
		end
		v_u_1.SetCardFaceUp(v240, false, false)
	end
end
function v_u_1.SetCardVisible(p244, p245) -- name: SetCardVisible
	-- upvalues: (ref) v_u_35, (copy) v_u_76, (ref) v_u_36, (ref) v_u_37, (ref) v_u_40, (ref) v_u_41, (copy) v_u_42
	v_u_35[p244] = p245
	local v246 = v_u_76
	local v247
	if v_u_35[p244] == true and not (v_u_36 or v_u_37) then
		v247 = not (v_u_40 or v_u_41) or v_u_42[p244] == true
	else
		v247 = false
	end
	v246(p244, v247)
end
function v_u_1.IsCardShown(p248) -- name: IsCardShown
	-- upvalues: (ref) v_u_35, (ref) v_u_36, (ref) v_u_37, (ref) v_u_40, (ref) v_u_41, (copy) v_u_42
	if v_u_35[p248] == true and not (v_u_36 or v_u_37) then
		return not (v_u_40 or v_u_41) or v_u_42[p248] == true
	else
		return false
	end
end
function v_u_1.SetRevealHeld(p249) -- name: SetRevealHeld
	-- upvalues: (ref) v_u_37, (ref) v_u_23, (copy) v_u_76, (ref) v_u_35, (ref) v_u_36, (ref) v_u_40, (ref) v_u_41, (copy) v_u_42, (copy) v_u_182
	if v_u_37 ~= p249 then
		v_u_37 = p249
		for _, v250 in v_u_23 do
			local v251 = v_u_76
			local v252
			if v_u_35[v250] == true and not (v_u_36 or v_u_37) then
				v252 = not (v_u_40 or v_u_41) or v_u_42[v250] == true
			else
				v252 = false
			end
			v251(v250, v252)
		end
		v_u_182()
	end
end
function v_u_1.ReplayIntro() -- name: ReplayIntro
	-- upvalues: (ref) v_u_39, (copy) v_u_1, (ref) v_u_36, (ref) v_u_41, (ref) v_u_43, (copy) v_u_42, (ref) v_u_23, (copy) v_u_76, (ref) v_u_35, (ref) v_u_37, (ref) v_u_40, (ref) v_u_22, (ref) v_u_51, (ref) v_u_52, (ref) v_u_53, (ref) v_u_54, (copy) v_u_14, (ref) v_u_45, (copy) v_u_46, (ref) v_u_50
	if v_u_39 then
		v_u_1.ResetCards()
		v_u_36 = true
		v_u_41 = true
		v_u_43 = true
		table.clear(v_u_42)
		for _, v253 in v_u_23 do
			local v254 = v_u_76
			local v255
			if v_u_35[v253] == true and not (v_u_36 or v_u_37) then
				v255 = not (v_u_40 or v_u_41) or v_u_42[v253] == true
			else
				v255 = false
			end
			v254(v253, v255)
		end
		local v256 = v_u_22
		if v256 then
			v256 = v256:FindFirstChild("Camera")
		end
		if v256 then
			v256 = v256:FindFirstChild("Cards")
		end
		if not (v256 and (v256:IsA("BasePart") and v256)) then
			v256 = nil
		end
		if v256 then
			v_u_51 = v256.CFrame
			v_u_52 = nil
			v_u_53 = nil
		else
			warn("[BlackMarketSceneController]: scene is missing Camera.Cards")
		end
		local v257 = v_u_51
		if v257 then
			v_u_52 = -v257.LookVector * 6
			v_u_53 = Vector3.new(0, 4, 0)
			v_u_54 = os.clock()
		end
		local v258 = v_u_14.INTRO_ANIMATION
		local v259 = v_u_45
		local v260 = not v259 or v_u_46[v258]
		if not v260 then
			local v261 = Instance.new("Animation")
			v261.AnimationId = v258
			v260 = v259:LoadAnimation(v261)
			v_u_46[v258] = v260
		end
		if v260 then
			local v262 = v_u_50
			v_u_50 = nil
			if v262 and v262.IsPlaying then
				v262:Stop(0.15)
			end
			v260.Looped = false
			v260.Priority = Enum.AnimationPriority.Movement
			v260:Stop(0)
			v260:Play(0.15)
			v_u_50 = v260
		end
	else
		return
	end
end
function v_u_1.Redeal() -- name: Redeal
	-- upvalues: (ref) v_u_39, (copy) v_u_1, (ref) v_u_44, (ref) v_u_23, (copy) v_u_38, (ref) v_u_27, (ref) v_u_40, (ref) v_u_41, (ref) v_u_43, (copy) v_u_42, (copy) v_u_76, (ref) v_u_35, (ref) v_u_36, (ref) v_u_37
	if v_u_39 then
		v_u_1.ResetCards()
		v_u_44 = v_u_44 + 1
		for _, v263 in v_u_23 do
			v_u_38:Remove((("CardDeal_%*"):format(v_u_27[v263] or 0)))
		end
		v_u_40 = false
		v_u_41 = true
		v_u_43 = false
		table.clear(v_u_42)
		for _, v264 in v_u_23 do
			local v265 = v_u_76
			local v266
			if v_u_35[v264] == true and not (v_u_36 or v_u_37) then
				v266 = not (v_u_40 or v_u_41) or v_u_42[v264] == true
			else
				v266 = false
			end
			v265(v264, v266)
		end
	end
end
function v_u_1.SkipIntro() -- name: SkipIntro
	-- upvalues: (ref) v_u_39, (ref) v_u_22, (ref) v_u_51, (ref) v_u_52, (ref) v_u_53, (ref) v_u_36, (ref) v_u_23, (copy) v_u_76, (ref) v_u_35, (ref) v_u_37, (ref) v_u_40, (ref) v_u_41, (copy) v_u_42, (copy) v_u_182
	if v_u_39 then
		local v267 = v_u_22
		if v267 then
			v267 = v267:FindFirstChild("Camera")
		end
		if v267 then
			v267 = v267:FindFirstChild("Cards")
		end
		if not (v267 and (v267:IsA("BasePart") and v267)) then
			v267 = nil
		end
		if v267 then
			v_u_51 = v267.CFrame
			v_u_52 = nil
			v_u_53 = nil
		else
			warn("[BlackMarketSceneController]: scene is missing Camera.Cards")
		end
		v_u_36 = false
		for _, v268 in v_u_23 do
			local v269 = v_u_76
			local v270
			if v_u_35[v268] == true and not (v_u_36 or v_u_37) then
				v270 = not (v_u_40 or v_u_41) or v_u_42[v268] == true
			else
				v270 = false
			end
			v269(v268, v270)
		end
		v_u_182()
	end
end
function v_u_1.IsPresenting() -- name: IsPresenting
	-- upvalues: (ref) v_u_36, (ref) v_u_40, (ref) v_u_41
	return v_u_36 or (v_u_40 or v_u_41)
end
function v_u_1.SkipPresentation() -- name: SkipPresentation
	-- upvalues: (ref) v_u_39, (ref) v_u_36, (ref) v_u_52, (ref) v_u_22, (ref) v_u_51, (ref) v_u_53, (copy) v_u_160
	if v_u_39 then
		if v_u_36 or v_u_52 then
			local v271 = v_u_22
			if v271 then
				v271 = v271:FindFirstChild("Camera")
			end
			if v271 then
				v271 = v271:FindFirstChild("Cards")
			end
			if not (v271 and (v271:IsA("BasePart") and v271)) then
				v271 = nil
			end
			if v271 then
				v_u_51 = v271.CFrame
				v_u_52 = nil
				v_u_53 = nil
			else
				warn("[BlackMarketSceneController]: scene is missing Camera.Cards")
			end
			v_u_36 = false
		end
		v_u_160()
	end
end
function v_u_1.PlayPurchaseLine() -- name: PlayPurchaseLine
	-- upvalues: (copy) v_u_107, (copy) v_u_14
	v_u_107(v_u_14.Purchase)
end
function v_u_1.PlayDeclineLine() -- name: PlayDeclineLine
	-- upvalues: (copy) v_u_107, (copy) v_u_14
	v_u_107(v_u_14.Declined)
end
function v_u_1.PlayRefreshLine() -- name: PlayRefreshLine
	-- upvalues: (copy) v_u_107, (copy) v_u_14
	v_u_107(v_u_14.Refresh)
end
function v_u_1.PlayDiscontinuedLine() -- name: PlayDiscontinuedLine
	-- upvalues: (copy) v_u_107, (copy) v_u_14
	v_u_107(v_u_14.Discontinued)
end
function v_u_1.PlayRarityLine(p272) -- name: PlayRarityLine
	-- upvalues: (copy) v_u_107, (copy) v_u_14
	if typeof(p272) == "string" then
		v_u_107(v_u_14.Rarity[p272])
	end
end
function v_u_1.NotifyDealRendered() -- name: NotifyDealRendered
	-- upvalues: (copy) v_u_182
	v_u_182()
end
function v_u_1.Show(p273) -- name: Show
	-- upvalues: (ref) v_u_39, (ref) v_u_22, (copy) v_u_8, (ref) v_u_37, (copy) v_u_216, (copy) v_u_1, (ref) v_u_23, (copy) v_u_76, (ref) v_u_35, (ref) v_u_36, (ref) v_u_40, (ref) v_u_41, (copy) v_u_42, (copy) v_u_60, (copy) v_u_14, (ref) v_u_45, (copy) v_u_46, (ref) v_u_47, (ref) v_u_43, (ref) v_u_55, (ref) v_u_56, (copy) v_u_80, (copy) v_u_21, (copy) v_u_12, (copy) v_u_63, (ref) v_u_51, (ref) v_u_52, (ref) v_u_53, (ref) v_u_54, (ref) v_u_50, (copy) v_u_11, (copy) v_u_15, (copy) v_u_3, (copy) v_u_16, (copy) v_u_182, (copy) v_u_38, (copy) v_u_206, (copy) v_u_7, (copy) v_u_68
	if v_u_39 then
		return
	else
		local v274 = v_u_22
		if v274 then
			v_u_8.Unpark(v274)
			v_u_39 = true
			v_u_37 = false
			v_u_216(v274)
			v_u_1.ResetCards()
			for _, v275 in v_u_23 do
				local v276 = v_u_76
				local v277
				if v_u_35[v275] == true and not (v_u_36 or v_u_37) then
					v277 = not (v_u_40 or v_u_41) or v_u_42[v275] == true
				else
					v277 = false
				end
				v276(v275, v277)
			end
			v_u_60()
			local v278 = v_u_14.IDLE_ANIMATION
			local v279 = v_u_45
			local v280 = not v279 or v_u_46[v278]
			if not v280 then
				local v281 = Instance.new("Animation")
				v281.AnimationId = v278
				v280 = v279:LoadAnimation(v281)
				v_u_46[v278] = v280
			end
			if v280 then
				v280.Looped = true
				v280.Priority = Enum.AnimationPriority.Idle
				if not v280.IsPlaying then
					v280:Play(0.15)
				end
				v_u_47 = v280
			end
			v_u_41 = not p273
			v_u_43 = true
			table.clear(v_u_42)
			if not p273 then
				v_u_55 = nil
				v_u_56 = nil
			end
			v_u_55 = v_u_80() or v_u_55
			v_u_56 = v_u_56 or v_u_21.CameraType
			v_u_21.CameraType = Enum.CameraType.Scriptable
			v_u_12.setFOVLock("BlackMarketScene", true, 70)
			v_u_12.setForceLockOverride("BlackMarketScene", true)
			v_u_63(false)
			v_u_36 = not p273
			local v282 = v_u_22
			if v282 then
				v282 = v282:FindFirstChild("Camera")
			end
			if v282 then
				v282 = v282:FindFirstChild("Cards")
			end
			if not (v282 and (v282:IsA("BasePart") and v282)) then
				v282 = nil
			end
			if v282 then
				v_u_51 = v282.CFrame
				v_u_52 = nil
				v_u_53 = nil
			else
				warn("[BlackMarketSceneController]: scene is missing Camera.Cards")
			end
			if not p273 then
				local v283 = v_u_51
				if v283 then
					v_u_52 = -v283.LookVector * 6
					v_u_53 = Vector3.new(0, 4, 0)
					v_u_54 = os.clock()
				end
				local v284 = v_u_14.INTRO_ANIMATION
				local v285 = v_u_45
				local v286 = not v285 or v_u_46[v284]
				if not v286 then
					local v287 = Instance.new("Animation")
					v287.AnimationId = v284
					v286 = v285:LoadAnimation(v287)
					v_u_46[v284] = v286
				end
				if v286 then
					local v288 = v_u_50
					v_u_50 = nil
					if v288 and v288.IsPlaying then
						v288:Stop(0.15)
					end
					v286.Looped = false
					v286.Priority = Enum.AnimationPriority.Movement
					v286:Stop(0)
					v286:Play(0.15)
					v_u_50 = v286
				end
			end
			v_u_11.BindToRenderStep("BlackMarketSceneController.CameraUpdate", v_u_15, function()
				-- upvalues: (ref) v_u_51, (ref) v_u_21, (ref) v_u_52, (ref) v_u_53, (ref) v_u_54, (ref) v_u_3, (ref) v_u_16, (ref) v_u_36, (ref) v_u_23, (ref) v_u_76, (ref) v_u_35, (ref) v_u_37, (ref) v_u_40, (ref) v_u_41, (ref) v_u_42, (ref) v_u_182
				local v289 = v_u_51
				if v289 then
					v_u_21.CameraType = Enum.CameraType.Scriptable
					local v290 = v_u_52
					local v291 = v_u_53
					if v290 and v291 then
						local v292 = (os.clock() - v_u_54 - 0.2) / 1.4
						local v293 = math.clamp(v292, 0, 1)
						local v294 = 1.5707963267948966 * v_u_3:GetValue(v293, v_u_16, Enum.EasingDirection.InOut)
						v_u_21.CFrame = v289 + v290 * math.cos(v294) + v291 * (1 - math.sin(v294))
						if v293 >= 1 then
							v_u_52 = nil
							v_u_53 = nil
							if v_u_36 then
								v_u_36 = false
								for _, v295 in v_u_23 do
									local v296 = v_u_76
									local v297
									if v_u_35[v295] == true and not (v_u_36 or v_u_37) then
										v297 = not (v_u_40 or v_u_41) or v_u_42[v295] == true
									else
										v297 = false
									end
									v296(v295, v297)
								end
								v_u_182()
							end
						end
					else
						v_u_21.CFrame = v289
					end
					v_u_21.Focus = v_u_21.CFrame
				end
			end)
			v_u_38:Add(function()
				-- upvalues: (ref) v_u_11
				v_u_11.UnbindFromRenderStep("BlackMarketSceneController.CameraUpdate")
			end, true, "CameraUpdate")
			v_u_38:Add(v_u_21:GetPropertyChangedSignal("ViewportSize"):Connect(v_u_206), "Disconnect", "ViewportFit")
			v_u_7.SetSuppressed(true)
			for _, v298 in v_u_21:GetChildren() do
				if not (v298:IsA("Model") or v298:IsA("BasePart")) then
					continue
				end
				v_u_68(v298)
				for _, v299 in v298:GetDescendants() do
					v_u_68(v299)
				end
			end
			v_u_38:Add(v_u_21.ChildAdded:Connect(function(p300)
				-- upvalues: (ref) v_u_68
				if p300:IsA("Model") or p300:IsA("BasePart") then
					v_u_68(p300)
					for _, v301 in p300:GetDescendants() do
						v_u_68(v301)
					end
				end
			end), "Disconnect", "ViewmodelListener")
			v_u_1.OnActiveChanged:Fire(true)
		else
			warn("[BlackMarketSceneController]: scene was never staged")
		end
	end
end
function v_u_1.Hide() -- name: Hide
	-- upvalues: (ref) v_u_39, (ref) v_u_36, (ref) v_u_37, (ref) v_u_44, (ref) v_u_40, (ref) v_u_41, (copy) v_u_98, (ref) v_u_50, (ref) v_u_47, (copy) v_u_38, (ref) v_u_51, (ref) v_u_52, (ref) v_u_53, (copy) v_u_2, (copy) v_u_85, (ref) v_u_56, (copy) v_u_21, (copy) v_u_12, (copy) v_u_13, (copy) v_u_63, (copy) v_u_72, (copy) v_u_7, (ref) v_u_22, (copy) v_u_8, (copy) v_u_1
	if v_u_39 then
		v_u_39 = false
		v_u_36 = false
		v_u_37 = false
		v_u_44 = v_u_44 + 1
		v_u_40 = false
		v_u_41 = false
		v_u_98()
		local v302 = v_u_50
		v_u_50 = nil
		if v302 and v302.IsPlaying then
			v302:Stop(0.15)
		end
		if v_u_47 then
			v_u_47:Stop(0.15)
			v_u_47 = nil
		end
		v_u_38:Cleanup()
		v_u_51 = nil
		v_u_52 = nil
		v_u_53 = nil
		local v303 = require(v_u_2.Controllers.MenuSceneController)
		local v304 = require(v_u_2.Interface.MenuState)
		local v305 = require(v_u_2.Controllers.SpectateController)
		local v306 = Enum.CameraType.Custom
		if not v304.IsInspectActive() then
			v_u_85()
			if v_u_56 and v305.IsSpectatingNow() then
				v306 = v_u_56
			end
			v_u_56 = nil
		end
		v_u_21.CameraType = v306
		v_u_12.setFOVLock("BlackMarketScene", false)
		v_u_12.updateCameraFOV(v_u_13.DEFAULT_CAMERA_FOV)
		local v307 = v305.GetCurrentSpectateInstance()
		if v307 then
			v307:UpdateScopeState()
		end
		v_u_12.setForceLockOverride("BlackMarketScene", false)
		v_u_63(true)
		v_u_72()
		v_u_7.SetSuppressed(false)
		if not v304.IsInspectActive() then
			if workspace:FindFirstChild("Map") then
				v303.ApplyMapLighting()
			else
				v303.ApplyMenuSceneLighting()
			end
		end
		if v_u_22 then
			v_u_8.Park(v_u_22)
		end
		v_u_1.OnActiveChanged:Fire(false)
	end
end
function v_u_1.Initialize() -- name: Initialize
	-- upvalues: (copy) v_u_13, (copy) v_u_2, (copy) v_u_8, (ref) v_u_22, (copy) v_u_186, (ref) v_u_45, (copy) v_u_95, (copy) v_u_216, (copy) v_u_1
	if v_u_13.BLACK_MARKET_ENABLED then
		local v308 = v_u_2.Assets:FindFirstChild("BlackMarketScene")
		if v308 then
			local v309 = v308:FindFirstChildOfClass("Model")
			if v309 then
				local v310 = v309:Clone()
				v310.Name = "BlackMarketScene"
				v_u_8.Park(v310)
				v_u_22 = v310
				v_u_186(v310)
				local v311 = v310:FindFirstChildWhichIsA("AnimationController", true)
				local v312
				if v311 then
					v312 = v311:FindFirstChildOfClass("Animator")
				else
					v312 = v311
				end
				if v312 then
					v_u_45 = v312
					v_u_95(v311.Parent)
				else
					warn("[BlackMarketSceneController]: the scene\'s dealer has no Animator, so he will not move")
				end
				v_u_216(v310)
				v_u_1.ResetCards()
			else
				warn("[BlackMarketSceneController]: no model inside Assets.BlackMarketScene")
			end
		else
			warn("[BlackMarketSceneController]: Assets.BlackMarketScene is missing")
			return
		end
	else
		return
	end
end
return v_u_1
-- NIGHT Analyzer | ReplicatedStorage.Controllers.GraphicsQualityController
-- ModuleScript | 254 linhas | 6222 bytes | hash ce099861

local v1 = {}
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("MaterialService")
local v_u_4 = game:GetService("Lighting")
local v5 = game:GetService("Players")
local v_u_6 = game:GetService("Workspace")
local v_u_7 = require(v2.Controllers.DataController)
local v_u_8 = require(script.PotatoColors)
local v_u_9 = {
	["BloomEffect"] = true,
	["SunRaysEffect"] = true,
	["DepthOfFieldEffect"] = true,
	["Clouds"] = true
}
local v_u_10 = {
	["SurfaceAppearance"] = true,
	["Texture"] = true
}
local v_u_11 = {
	["bush 1"] = true,
	["bush 2"] = true,
	["tree 1"] = true,
	["grass"] = true,
	["trees"] = true
}
local v_u_12 = v5.LocalPlayer
local v_u_13 = false
local v_u_14 = {}
local v_u_15 = {}
local v_u_16 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_17 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_23(p18) -- name: tintForMaterialVariant
	-- upvalues: (copy) v_u_16, (copy) v_u_15, (copy) v_u_8
	if not v_u_16[p18] then
		v_u_16[p18] = true
		local v19
		if p18.MaterialVariant == "" then
			v19 = v_u_15[p18.Material]
		else
			v19 = p18.MaterialVariant
		end
		local v20
		if v19 then
			v20 = v_u_8.MaterialVariants[("%*/%*"):format(p18.Material.Name, v19)]
		else
			v20 = nil
		end
		if v20 then
			local v21 = p18.Color
			local v22 = Color3.fromRGB(v20[1], v20[2], v20[3])
			p18.Color = Color3.new(v21.R * v22.R, v21.G * v22.G, v21.B * v22.B)
		end
	end
end
local function v_u_40(p24) -- name: tintForRemovedSurface
	-- upvalues: (copy) v_u_8, (copy) v_u_17
	local v25 = p24.Parent
	if v25 and v25:IsA("BasePart") then
		local v26 = 1
		local v27 = 1
		local v28, v29, v30
		if p24:IsA("Texture") then
			local v31 = p24.Texture
			local v32 = string.match
			local v33 = tonumber(v32(v31, "(%d+)$"))
			if v33 then
				v28 = v_u_8.Textures[v33]
			else
				v28 = nil
			end
			v29 = p24.Texture
			v30 = p24.Color3
			v26 = 1 - p24.Transparency
		else
			if not (p24:IsA("SurfaceAppearance") and v25:IsA("MeshPart")) then
				return
			end
			local v34 = v25.MeshId
			local v35 = string.match
			local v36 = tonumber(v35(v34, "(%d+)$"))
			if v36 then
				v28 = v_u_8.SurfaceAppearances[v36]
			else
				v28 = nil
			end
			v30 = p24.Color
			v29 = "SurfaceAppearance"
		end
		if v28 and v29 then
			if p24:IsA("Texture") or p24.AlphaMode == Enum.AlphaMode.Overlay then
				v27 = v28[4]
			end
			local v37 = v_u_17[v25]
			if not v37 then
				v37 = {}
				v_u_17[v25] = v37
			end
			if not v37[v29] then
				v37[v29] = true
				local v38 = v25.Color
				local v39 = Color3.fromRGB(v28[1], v28[2], v28[3])
				v25.Color = v38:Lerp(Color3.new(v39.R * v30.R, v39.G * v30.G, v39.B * v30.B), v27 * v26)
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_42(p41) -- name: stripMaterialInstance
	if p41:IsA("MaterialVariant") then
		p41:Destroy()
	end
end
local function v_u_44(p43) -- name: stripEffectInstance
	-- upvalues: (copy) v_u_9
	if v_u_9[p43.ClassName] then
		p43:Destroy()
	end
end
local function v_u_47(p45) -- name: isInsideRig
	-- upvalues: (copy) v_u_6
	local v46 = p45.Parent
	while v46 and v46 ~= v_u_6 do
		if v46:IsA("Model") and (v46:FindFirstChild("HumanoidRootPart") or (v46:FindFirstChildOfClass("Humanoid") or v46:FindFirstChildOfClass("AnimationController"))) then
			return true
		end
		v46 = v46.Parent
	end
	return false
end
local function v_u_49(p48) -- name: stripMapInstance
	-- upvalues: (copy) v_u_10, (copy) v_u_47, (copy) v_u_40, (copy) v_u_23, (copy) v_u_11
	if (v_u_10[p48.ClassName] or p48:IsA("BasePart")) and v_u_47(p48) then
		return
	elseif v_u_10[p48.ClassName] then
		v_u_40(p48)
		p48:Destroy()
	elseif p48:IsA("BasePart") then
		p48.CastShadow = false
		v_u_23(p48)
		if v_u_11[p48.Name] and not p48.CanCollide then
			p48.Transparency = 1
			return
		end
	elseif p48:IsA("Light") then
		p48.Shadows = false
	end
end
local function v_u_58(p50, p_u_51, p52) -- name: stripContainer
	local v53
	if p52 then
		v53 = p50.DescendantAdded
	else
		v53 = p50.ChildAdded
	end
	v53:Connect(function(p54)
		-- upvalues: (copy) p_u_51
		task.defer(p_u_51, p54)
	end)
	local v55
	if p52 then
		v55 = p50:GetDescendants()
	else
		v55 = p50:GetChildren()
	end
	for v56, v57 in v55 do
		if v57.Parent then
			p_u_51(v57)
		end
		if v56 % 2000 ~= 0 then
			continue
		end
		task.wait()
	end
end
local function v_u_66() -- name: resetBaseMaterialOverrides
	-- upvalues: (copy) v_u_3, (copy) v_u_15
	for _, v59 in Enum.Material:GetEnumItems() do
		local v60 = v_u_3.GetBaseMaterialOverride
		local v61 = v_u_3
		local v62, v63 = pcall(v60, v61, v59)
		if v62 and v63 ~= "" then
			v_u_15[v59] = v63
		end
		local v64 = v_u_3.SetBaseMaterialOverride
		local v65 = v_u_3
		pcall(v64, v65, v59, "")
	end
end
local function v_u_69() -- name: stopAnimatedProps
	-- upvalues: (ref) v_u_14
	local v67 = v_u_14
	v_u_14 = {}
	for _, v68 in v67 do
		task.spawn(v68)
	end
end
local function v_u_72() -- name: applyPotatoMode
	-- upvalues: (ref) v_u_13, (copy) v_u_69, (copy) v_u_66, (copy) v_u_58, (copy) v_u_3, (copy) v_u_42, (copy) v_u_4, (copy) v_u_44, (copy) v_u_6, (copy) v_u_49
	if not v_u_13 then
		v_u_13 = true
		v_u_69()
		v_u_66()
		task.spawn(v_u_58, v_u_3, v_u_42, true)
		task.spawn(v_u_58, v_u_4, v_u_44, false)
		task.spawn(v_u_58, v_u_6.Terrain, v_u_44, false)
		local v70 = v_u_6:FindFirstChild("Map")
		if v70 then
			task.spawn(v_u_58, v70, v_u_49, true)
		end
		v_u_6.ChildAdded:Connect(function(p71)
			-- upvalues: (ref) v_u_58, (ref) v_u_49
			if p71.Name == "Map" then
				task.spawn(v_u_58, p71, v_u_49, true)
			end
		end)
	end
end
function v1.RunAnimatedProp(p73) -- name: RunAnimatedProp
	-- upvalues: (ref) v_u_13, (ref) v_u_14
	if v_u_13 then
		return nil
	end
	local v_u_74 = p73()
	if not v_u_74 then
		return nil
	end
	local v_u_75 = {}
	v_u_14[v_u_75] = v_u_74
	return function()
		-- upvalues: (ref) v_u_14, (copy) v_u_75, (copy) v_u_74
		if v_u_14[v_u_75] then
			v_u_14[v_u_75] = nil
			v_u_74()
		end
	end
end
function v1.Start() -- name: Start
	-- upvalues: (copy) v_u_7, (copy) v_u_12, (copy) v_u_72
	v_u_7.CreateListener(v_u_12, "Settings.Video.Presets.Potato Mode", function(p76)
		-- upvalues: (ref) v_u_72
		if p76 == true then
			v_u_72()
		end
		return nil
	end)
end
return v1
-- NIGHT Analyzer | ReplicatedStorage.Controllers.SoundController.MovementSounds
-- ModuleScript | 243 linhas | 7746 bytes | hash 77eb698c

local v_u_1 = {}
v_u_1.__index = v_u_1
local v2 = game:GetService("ReplicatedStorage")
local v3 = game:GetService("Players")
require(script:WaitForChild("Types"))
local v_u_4 = v3.LocalPlayer
local v_u_5 = require(v2.Classes.Sound)
local v_u_6 = require(v2.Components.Common.VFXLibary.CreateImpact.Components.Materials)
local v_u_7 = require(v2.Components.Common.GetRayIgnore)
local v_u_8 = require(v2.Components.Common.VFXLibary.FlashEffect)
local v_u_9 = require(v2.Components.Common.CharacterResolver)
local v_u_10 = require(v2.Components.Common.LocalFootsteps)
local v_u_11 = require(v2.MovementV2.RuntimeKinematics)
local v_u_12 = {
	Vector3.new(0, 0, 0),
	Vector3.new(0.8, 0, 0),
	Vector3.new(-0.8, 0, 0),
	Vector3.new(0, 0, 0.8),
	Vector3.new(0, 0, -0.8)
}
local v_u_13 = {
	["Concrete"] = "LandingConcrete",
	["Brick"] = "LandingConcrete",
	["Cobblestone"] = "LandingConcrete",
	["Basalt"] = "LandingConcrete",
	["Limestone"] = "LandingConcrete",
	["Pavement"] = "LandingConcrete",
	["Asphalt"] = "LandingConcrete",
	["Rock"] = "LandingConcrete",
	["Slate"] = "LandingConcrete",
	["Granite"] = "LandingConcrete",
	["Marble"] = "LandingConcrete",
	["Pebble"] = "LandingConcrete",
	["CeramicTiles"] = "LandingConcrete",
	["Ground"] = "LandingDirt",
	["Mud"] = "LandingDirt",
	["Glass"] = "LandingGlass",
	["Gravel"] = "LandingGravel",
	["Rubber"] = "LandingRubber",
	["Plastic"] = "LandingRubber",
	["Sand"] = "LandingSand",
	["Snow"] = "LandingSand",
	["Grass"] = "LandingGrass",
	["LeafyGrass"] = "LandingGrass",
	["Metal"] = "LandingMetal",
	["DiamondPlate"] = "LandingMetal",
	["CorrodedMetal"] = "LandingMetal",
	["Corroded Metal"] = "LandingMetal",
	["Wood"] = "Wood",
	["WoodPlanks"] = "WoodPlanks",
	["Fabric"] = "LandingDirt",
	["Carpet"] = "LandingDirt",
	["Cardboard"] = "LandingDirt"
}
local v_u_14 = nil
local v_u_15 = RaycastParams.new()
v_u_15.FilterType = Enum.RaycastFilterType.Exclude
v_u_15.IgnoreWater = true
local function v_u_25(p16, p17, p18) -- name: GetFloorMaterial
	-- upvalues: (copy) v_u_7, (copy) v_u_15, (copy) v_u_12
	local v19 = v_u_7()
	if not table.find(v19, p16) then
		table.insert(v19, p16)
	end
	v_u_15.FilterDescendantsInstances = v19
	local v20 = -(p18 or 3.1)
	local v21 = Vector3.new(0, v20, 0)
	for _, v22 in ipairs(v_u_12) do
		local v23 = p17 + v22
		local v24 = workspace:Raycast(v23, v21, v_u_15)
		if not v24 or v24.Normal.Y <= 0.7 then
			continue
		end
		return v24.Material.Name
	end
	return "Air"
end
local function v_u_30(p26, p27, p28) -- name: PlayFootstepSound
	-- upvalues: (ref) v_u_14, (copy) v_u_6
	if not v_u_14 or (p27 == "" or p27 == "Air") then
		return nil
	end
	local v29 = v_u_14.Sounds and not v_u_14.Sounds:FindFirstChild(p27) and (v_u_6[p27] or "Ground") or p27
	if not v_u_14.Sounds or v_u_14.Sounds:FindFirstChild(v29) then
		return v_u_14:play({
			["Parent"] = p26,
			["Name"] = v29
		}, p28)
	end
	warn(string.format("[FloorSound] Missing sound for category: \'%s\' (material: %s)", v29, p27))
	return nil
end
local function v_u_39(p31, p32, p33, p34) -- name: PlayLandingSound
	-- upvalues: (copy) v_u_25, (copy) v_u_8, (copy) v_u_30, (copy) v_u_13
	local v35 = tick()
	if v35 - p31.LastFloorSoundTime >= 0.1 then
		p31.LastFloorSoundTime = v35
		local v36 = p31.Player:GetAttribute("IsCrouching")
		local v37 = p34 or v_u_25(p33, p32.Position)
		local v38 = (v36 and 0.4 or 1) * (p31.IsLocalPlayer and v_u_8.GetAudioFadeMultiplier() or 1)
		v_u_30(p32, v_u_13[v37] or "LandingConcrete", v38)
	end
end
local function v_u_46(p40, p41, p42) -- name: PlayJumpSound
	-- upvalues: (copy) v_u_8, (copy) v_u_30
	local v43 = tick()
	if v43 - p40.LastFloorSoundTime >= 0.1 then
		local v44 = p40.CurrentFootstepSound
		if v44 and v44.Playing then
			v44:Stop()
		end
		p40.CurrentFootstepSound = nil
		p40.LastFloorSoundTime = v43
		local v45 = (p40.Player:GetAttribute("IsCrouching") and 0.4 or 1) * (p40.IsLocalPlayer and v_u_8.GetAudioFadeMultiplier() or 1)
		v_u_30(p41, "Jump", v45)
		v_u_30(p41, p42, v45)
	end
end
function v_u_1.SetCharacter(p47, p48) -- name: SetCharacter
	-- upvalues: (copy) v_u_9, (copy) v_u_11
	if p48 then
		local v49 = v_u_9.getRootPart(p48)
		if v49 and p48.Parent then
			p47.PrimaryPart = v49
			p47.Character = p48
			p47.TimePassed = 0.25
			local _, _, _, v50, v51 = v_u_11.resolve(p48, v49)
			p47.IsAirborne = not v51
			p47.AirborneStartTime = not p47.IsAirborne and 0 or tick()
			p47.PeakAirborneVelocityY = not p47.IsAirborne and 0 or v50
		end
	else
		local v52 = p47.CurrentFootstepSound
		if v52 and v52.Playing then
			v52:Stop()
		end
		p47.CurrentFootstepSound = nil
		p47.CurrentFloorMaterial = nil
		p47.PrimaryPart = nil
		p47.TimePassed = 0.25
		p47.Character = nil
		p47.IsAirborne = false
		p47.AirborneStartTime = 0
		p47.PeakAirborneVelocityY = 0
		return
	end
end
function v_u_1.Update(p53, p54, _) -- name: Update
	-- upvalues: (copy) v_u_9, (copy) v_u_11, (copy) v_u_25, (copy) v_u_46, (copy) v_u_39, (copy) v_u_30, (copy) v_u_8, (copy) v_u_10
	local v55 = p53.PrimaryPart
	local v56 = p53.Character
	local v57 = p53.Player
	if v55 and (v56 and (v56.Parent and v_u_9.isAliveCharacter(v56))) then
		local v58 = tick()
		local v59, _, v60, _, v61 = v_u_11.resolve(v56, v55)
		if v61 then
			if p53.IsAirborne then
				local v62, v63 = v_u_11.getPosition(v56, v55)
				local v64 = v_u_25(v56, v62, v63 and 3.1 or 6.2)
				local v65 = v64 == "Air" and "Concrete" or v64
				p53.CurrentFloorMaterial = v65
				local v66 = not p53.IsAirborne and 0 or v58 - p53.AirborneStartTime
				local v67 = p53.PeakAirborneVelocityY
				p53.IsAirborne = false
				p53.AirborneStartTime = 0
				p53.PeakAirborneVelocityY = 0
				if v66 >= 0.08 and v67 <= -2.5 then
					v_u_39(p53, v55, v56, v65)
				end
			end
		else
			if not p53.IsAirborne and v59.Y > 2 then
				local v68 = v_u_25(v56, v55.Position, 6.2)
				v_u_46(p53, v55, v68 == "Air" and (p53.CurrentFloorMaterial or "Concrete") or v68)
			end
			local v69 = v59.Y
			if p53.IsAirborne then
				local v70 = p53.PeakAirborneVelocityY
				p53.PeakAirborneVelocityY = math.min(v70, v69)
			else
				p53.IsAirborne = true
				p53.AirborneStartTime = v58
				p53.PeakAirborneVelocityY = v69
			end
		end
		local v71 = v57:GetAttribute("IsCrouching")
		if v57:GetAttribute("IsWalking") or v71 then
			return
		elseif v57:GetAttribute("IsSniperScoped") ~= true then
			local v72 = v71 and 3.5 or 7.5
			local v73 = v71 and 0.55 or 0.3
			p53.TimePassed = p53.TimePassed + p54
			if v73 <= p53.TimePassed then
				p53.TimePassed = p53.TimePassed - v73
				if v58 - p53.LastFloorSoundTime < 0.1 then
					return
				end
				if v72 <= v60 then
					local v74 = v_u_25(v56, v55.Position, 3.1)
					if v74 == "Air" then
						if v61 then
							local v75 = p53.CurrentFloorMaterial
							v74 = (not v75 or (v75 == "" or v75 == "Air")) and "Concrete" or v75
						else
							v74 = "Air"
						end
					end
					if v61 then
						p53.CurrentFloorMaterial = v74
					end
					p53.LastFloorSoundTime = v58
					p53.CurrentFootstepSound = v_u_30(v55, v74, (v71 and 0.4 or 1) * (p53.IsLocalPlayer and v_u_8.GetAudioFadeMultiplier() or 1))
					if p53.IsLocalPlayer then
						v_u_10.step()
					end
				end
			end
		end
	else
		return
	end
end
function v_u_1.new(p76) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (ref) v_u_14, (copy) v_u_5
	local v77 = v_u_1
	local v78 = setmetatable({}, v77)
	v78.IsLocalPlayer = p76 == v_u_4
	v78.Player = p76
	v78.PrimaryPart = nil
	v78.Character = nil
	v78.TimePassed = 0.25
	v78.CurrentFootstepSound = nil
	v78.CurrentFloorMaterial = nil
	v78.LastFloorSoundTime = 0
	v78.IsAirborne = false
	v78.AirborneStartTime = 0
	v78.PeakAirborneVelocityY = 0
	if not v_u_14 then
		v_u_14 = v_u_5.new("FloorSounds")
	end
	return v78
end
return v_u_1
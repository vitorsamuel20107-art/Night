-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.ToggleInventoryDisplay
-- ModuleScript | 1 linhas | 109 bytes | hash effacbd6

return require(script.Parent.Parent.ActionTemplates).placeholder("Toggle Inventory Display", "Movement Keys")
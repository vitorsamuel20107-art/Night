-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.LastWeaponUsed
-- ModuleScript | 53 linhas | 1538 bytes | hash b83ba5ab

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
require(script.Parent.Parent.Types)
local v_u_3 = v2.LocalPlayer
local v_u_4 = require(v1.Controllers.InventoryController)
local v_u_5 = require(v1.Controllers.CaseSceneController)
local v_u_6 = require(v1.Controllers.BlackMarketSceneController)
local v_u_7 = require(v1.Controllers.InspectController)
local function v_u_15() -- name: equipFallback
	-- upvalues: (copy) v_u_4
	local v8 = v_u_4.getCurrentInventory()
	local v9 = v_u_4.getCurrentEquipped()
	if v8 and v9 then
		local v10 = nil
		local v11 = nil
		for _, v12 in ipairs(v8) do
			for v13, v14 in ipairs(v12._items) do
				if v14.Identifier == v9.Identifier then
					continue
				end
				v10 = v14.Slot
				v11 = v13
			end
		end
		if v10 and v11 then
			v_u_4.equip(v10, v11)
		end
	end
end
return table.freeze({
	["Name"] = "Last Weapon Used",
	["Group"] = "Gameplay",
	["Category"] = "Weapon Keys",
	["Callback"] = nil,
	["Callback"] = function(p16, _) -- name: onInput
		-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_6, (copy) v_u_7, (copy) v_u_4, (copy) v_u_15
		if v_u_3:GetAttribute("IsPlayerChatting") or p16 ~= Enum.UserInputState.Begin then
			return
		elseif v_u_5.IsActive() or (v_u_6.IsActive() or v_u_7.IsActive()) then
			return
		else
			local v17 = v_u_4.getPreviousEquipped()
			if v17 then
				local _, v18, v19 = v_u_4.getInventoryItemFromLoadout(v17.Identifier)
				if v18 and v19 then
					v_u_4.equip(v18, v19)
				end
			else
				v_u_15()
			end
		end
	end
})
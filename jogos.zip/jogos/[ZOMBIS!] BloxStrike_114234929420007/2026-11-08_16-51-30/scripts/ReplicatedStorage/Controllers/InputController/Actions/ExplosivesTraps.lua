-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.ExplosivesTraps
-- ModuleScript | 1 linhas | 87 bytes | hash 6af7ddff

return require(script.Parent.Parent.ActionTemplates).equipSlot("Explosives & Traps", 5)
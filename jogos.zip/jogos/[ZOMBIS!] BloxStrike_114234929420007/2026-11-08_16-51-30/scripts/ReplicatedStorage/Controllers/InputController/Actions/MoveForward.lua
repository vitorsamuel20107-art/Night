-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.MoveForward
-- ModuleScript | 1 linhas | 97 bytes | hash 0be85bf9

return require(script.Parent.Parent.ActionTemplates).movement("Move Forward", "forwardValue", -1)
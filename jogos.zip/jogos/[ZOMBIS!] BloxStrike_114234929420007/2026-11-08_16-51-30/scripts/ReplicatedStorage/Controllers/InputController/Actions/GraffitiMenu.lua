-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.GraffitiMenu
-- ModuleScript | 1 linhas | 96 bytes | hash c8a957d0

return require(script.Parent.Parent.ActionTemplates).placeholder("Graffiti Menu", "Weapon Keys")
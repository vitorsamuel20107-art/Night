-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.Walk
-- ModuleScript | 62 linhas | 1782 bytes | hash e964c990

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
require(script.Parent.Parent.Types)
local v_u_3 = require(v1.Components.Common.CharacterResolver)
local v_u_4 = require(v1.Components.Common.IsSurvivalMode)
local v_u_5 = require(v1.Controllers.CharacterController)
local v_u_6 = require(v1.Controllers.DataController)
local v_u_7 = v2.LocalPlayer
local v8 = Enum.ContextActionPriority.High.Value + 1
v_u_7:GetAttributeChangedSignal("IsPlayerChatting"):Connect(function()
	-- upvalues: (copy) v_u_7, (copy) v_u_5
	if v_u_7:GetAttribute("IsPlayerChatting") then
		v_u_5.walk(false)
		v_u_5.sprint(false)
	end
end)
return table.freeze({
	["Name"] = "Walk",
	["Group"] = "Default",
	["Category"] = "Movement Keys",
	["BindPriority"] = nil,
	["Callback"] = nil,
	["BindPriority"] = v8,
	["Callback"] = function(p9, _) -- name: onInput
		-- upvalues: (copy) v_u_7, (copy) v_u_3, (copy) v_u_6, (copy) v_u_4, (copy) v_u_5
		if v_u_7:GetAttribute("IsPlayerChatting") then
			return
		elseif v_u_3.isAliveCharacter(v_u_3.getPlayerCharacter(v_u_7)) then
			if v_u_6.Get(v_u_7, "Settings.Keyboard/Mouse.Keyboard & Mouse Settings.Walk Mode") == "Toggle" then
				if p9 == Enum.UserInputState.Begin then
					local v10
					if v_u_4() then
						v10 = v_u_5.GetSprintState()
					else
						v10 = v_u_5.GetWalkState()
					end
					local v11 = v10 ~= true
					if v_u_4() then
						v_u_5.sprint(v11)
					else
						v_u_5.walk(v11)
					end
				end
			else
				if p9 == Enum.UserInputState.Begin then
					if v_u_4() then
						v_u_5.sprint(true)
					else
						v_u_5.walk(true)
					end
				end
				if p9 == Enum.UserInputState.End then
					if v_u_4() then
						v_u_5.sprint(false)
						return
					end
					v_u_5.walk(false)
				end
			end
		end
	end
})
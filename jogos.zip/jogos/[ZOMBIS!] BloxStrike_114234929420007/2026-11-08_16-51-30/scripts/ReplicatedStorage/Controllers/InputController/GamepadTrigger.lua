-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.GamepadTrigger
-- ModuleScript | 50 linhas | 1472 bytes | hash e7510c19

local v_u_1 = {}
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = table.freeze({
	[Enum.UserInputType.Gamepad1] = true,
	[Enum.UserInputType.Gamepad2] = true,
	[Enum.UserInputType.Gamepad3] = true,
	[Enum.UserInputType.Gamepad4] = true,
	[Enum.UserInputType.Gamepad5] = true,
	[Enum.UserInputType.Gamepad6] = true,
	[Enum.UserInputType.Gamepad7] = true,
	[Enum.UserInputType.Gamepad8] = true
})
function v_u_1.getInputBinding(p4) -- name: getInputBinding
	if p4.KeyCode and p4.KeyCode ~= Enum.KeyCode.Unknown then
		return p4.KeyCode
	elseif p4.UserInputType == Enum.UserInputType.MouseButton1 or (p4.UserInputType == Enum.UserInputType.MouseButton2 or p4.UserInputType == Enum.UserInputType.MouseButton3) then
		return p4.UserInputType
	else
		return nil
	end
end
function v_u_1.isGamepadInput(p5) -- name: isGamepadInput
	-- upvalues: (copy) v_u_3
	return v_u_3[p5.UserInputType] == true
end
function v_u_1.isTrigger(p6, p7) -- name: isTrigger
	-- upvalues: (copy) v_u_3
	local v8
	if v_u_3[p6.UserInputType] == true then
		v8 = p7[p6.KeyCode] == true
	else
		v8 = false
	end
	return v8
end
function v_u_1.isStillPressed(p9, p10) -- name: isStillPressed
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	if not v_u_1.isTrigger(p9, p10) then
		return false
	end
	local v11 = p9.KeyCode
	for _, v12 in ipairs(v_u_2:GetGamepadState(p9.UserInputType)) do
		if v12.KeyCode ~= v11 then
			continue
		end
		return v12.Position.Z > 0.3
	end
	return false
end
return v_u_1
-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.SecondaryFire
-- ModuleScript | 102 linhas | 3473 bytes | hash 8d59b46a

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Players").LocalPlayer
require(script.Parent.Parent.Types)
local v_u_3 = require(script.Parent.Parent.GamepadTrigger)
local v_u_4 = require(v1.Controllers.InventoryController)
local v_u_5 = require(v1.Controllers.SpectateController)
local v_u_6 = require(v1.Controllers.CaseSceneController)
local v_u_7 = require(v1.Controllers.BlackMarketSceneController)
local v_u_8 = require(v1.Controllers.InspectController)
local v_u_9 = require(v1.Database.Components.GameState)
local v_u_10 = require(v1.Components.Common.CharacterResolver)
local v_u_11 = require(v1.Components.Common.SurvivalDowned)
local v_u_12 = table.freeze({
	[Enum.KeyCode.ButtonL2] = true
})
local v_u_13 = false
local v18 = {
	["Name"] = "Secondary Fire",
	["Group"] = "Default",
	["Category"] = "Weapon Keys",
	["Callback"] = nil,
	["Callback"] = function(p14, p15) -- name: onInput
		-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_7, (copy) v_u_8, (ref) v_u_13, (copy) v_u_4, (copy) v_u_10, (copy) v_u_11, (copy) v_u_2, (copy) v_u_9, (copy) v_u_3, (copy) v_u_12
		if v_u_5.IsSpectatingNow() and (p14 == Enum.UserInputState.Begin and not v_u_5.IsControllerPress(p15)) then
			v_u_5.RequestSwitch(1)
			return
		elseif v_u_5.IsLocalPlayerDead() or (v_u_6.IsActive() or (v_u_7.IsActive() or v_u_8.IsActive())) then
			if p14 == Enum.UserInputState.End then
				v_u_13 = false
			end
			return
		else
			local v16 = v_u_4.getCurrentEquipped()
			if v_u_10.getLocalCharacter() and v16 then
				if p14 == Enum.UserInputState.Begin and not v_u_11.CanUseSlot(v_u_2, v16.Properties.Slot) then
					return
				elseif v16.Properties.Slot ~= "Grenade" or v_u_9.GetState() ~= "Buy Period" then
					if p14 == Enum.UserInputState.Begin then
						if v16.Properties.ShootingOptions == "Revolver" then
							local v17 = v_u_3.isTrigger(p15, v_u_12)
							if not (v17 and v_u_13) then
								if v17 then
									v_u_13 = true
								end
								v16:startRevolverSecondaryFire(v_u_3.getInputBinding(p15))
							end
						end
						if v16.Properties.Class == "Grenade" then
							if v_u_9.GetState() ~= "Buy Period" then
								v16:StartThrow()
								return
							end
						else
							if v16.Properties.HasScope then
								v16:scope(true)
								return
							end
							if v16.Properties.HasSuppressor then
								if v16.IsSuppressed then
									v16:removeSuppressor()
								else
									v16:addSuppressor()
								end
							end
							if v16.Properties.ShootingOptions == "Burst" then
								v16:updateFireMode()
								return
							end
							if v16.Properties.Type == "Equipment" and v_u_9.GetState() ~= "Buy Period" then
								v16:shoot(true)
								return
							end
						end
					else
						if v16.Properties.ShootingOptions == "Revolver" and p14 == Enum.UserInputState.End then
							if not v_u_3.isStillPressed(p15, v_u_12) then
								v_u_13 = false
								v16:stopRevolverSecondaryFire()
							end
						end
						local _ = v16.Properties.HasScope
						if v16.Properties.Slot == "Grenade" and p14 == Enum.UserInputState.End then
							v_u_13 = false
							if v_u_9.GetState() == "Buy Period" then
								return
							end
							if v16.ThrowStarted and not v16.ThrowFinished then
								v16:Throw("Near")
								return
							end
						elseif p14 == Enum.UserInputState.End then
							v_u_13 = false
						end
					end
				end
			else
				return
			end
		end
	end
}
return table.freeze(v18)
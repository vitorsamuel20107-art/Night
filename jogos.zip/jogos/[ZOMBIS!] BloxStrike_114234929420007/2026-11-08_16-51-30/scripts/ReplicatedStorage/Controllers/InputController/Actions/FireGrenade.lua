-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.FireGrenade
-- ModuleScript | 4 linhas | 138 bytes | hash 1dff546a

return require(script.Parent.Parent.ActionTemplates).equipGrenade("Fire Grenade", {
	["Molotov"] = true,
	["Incendiary Grenade"] = true
})
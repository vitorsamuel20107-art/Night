-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.Use
-- ModuleScript | 198 linhas | 6543 bytes | hash febda76f

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("CollectionService")
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("Workspace")
require(script.Parent.Parent.Types)
local v_u_5 = v3.LocalPlayer
local v_u_6 = require(v1.Controllers.InventoryController)
local v_u_7 = require(v1.Controllers.CharacterController)
local v_u_8 = require(v1.Controllers.SurvivalDownedController)
local v_u_9 = require(v1.Components.Common.CenterScreenRaycast)
local v_u_10 = require(v1.Components.Common.CharacterResolver)
local v_u_11 = require(v1.Components.Common.SurvivalDowned)
local v_u_12 = require(v1.Components.Common.SurvivalBuyRules)
local v_u_13 = require(v1.Components.Common.GetWeaponProperties)
local v_u_14 = require(v1.Database.Components.Libraries.Skins)
local v_u_15 = require(v1.Database.Custom.GameStats.NumberSlots)
local v_u_16 = require(v1.Database.Custom.GameStats.Rarities)
local v_u_17 = require(v1.Database.Custom.GameStats.Grenades)
local v_u_18 = require(v1.Database.Security.Remotes)
local v_u_19 = require(v1.Database.Security.Router)
local function v_u_23(p20, p21) -- name: computePriority
	-- upvalues: (copy) v_u_10
	local v22 = v_u_10.getLocalCharacter()
	if v22 and v22.PrimaryPart then
		if p20:GetAttribute("HoveringState") == "Hovering" then
			return true
		elseif p21:GetAttribute("HoveringState") == "Hovering" then
			return false
		elseif p20:GetAttribute("CanPickup") == false then
			return false
		elseif p21:GetAttribute("CanPickup") == false then
			return true
		elseif p20.PrimaryPart and p21.PrimaryPart then
			return (v22.PrimaryPart.Position - p20.PrimaryPart.Position).Magnitude < (v22.PrimaryPart.Position - p21.PrimaryPart.Position).Magnitude
		else
			return false
		end
	else
		return false
	end
end
local function v_u_29() -- name: GetHoveredBreakableDoor
	-- upvalues: (copy) v_u_9, (copy) v_u_2
	local v24 = {}
	local v25 = v_u_9.FindTaggedModelInSight("BreakableDoor", 8)
	if v25 and (v25:IsA("Model") and v25:GetAttribute("Destroyed") ~= true) then
		table.insert(v24, v25)
		for _, v26 in v_u_2:GetTagged("BreakableDoor") do
			if v26 == v25 or v26:GetAttribute("Destroyed") == true then
				continue
			end
			local v27 = v25:FindFirstChild("BreakableDoorHingePivot")
			local v28 = v26:FindFirstChild("BreakableDoorHingePivot")
			if not v27 or (not v28 or (v27.Position - v28.Position).Magnitude > 20) then
				continue
			end
			table.insert(v24, v26)
		end
	end
	return v24
end
local function v_u_40(p30) -- name: isGrenadeLimitHit
	-- upvalues: (copy) v_u_13, (copy) v_u_15, (copy) v_u_6, (copy) v_u_12
	local v31 = v_u_13(p30)
	if not v31 then
		return false
	end
	local v32 = v_u_15[v31.Slot]
	local v33 = v_u_6.getInventorySlot(v32)
	if not v33 then
		return false
	end
	local v34 = #v33._items >= v33._settings._strict_slot_space
	local v35 = v_u_12.GetGrenadeLimit(p30)
	local v36 = v33._items
	local v37 = 0
	local v38 = true
	for _, v39 in ipairs(v36) do
		if v39.Name ~= p30 then
			continue
		end
		v37 = v37 + 1
	end
	if v35 <= v37 then
		v34 = v38
	end
	return v34
end
local function v_u_62() -- name: onUseBegin
	-- upvalues: (copy) v_u_8, (copy) v_u_11, (copy) v_u_5, (copy) v_u_2, (copy) v_u_19, (copy) v_u_29, (copy) v_u_4, (copy) v_u_7, (copy) v_u_18, (copy) v_u_23, (copy) v_u_17, (copy) v_u_40, (copy) v_u_14, (copy) v_u_16
	if v_u_8.TryStartRevive() or v_u_11.AreHandsBusy(v_u_5) then
		return
	else
		local v41 = v_u_2:GetTagged("Bomb")[1]
		if v41 and (v41:GetAttribute("CanDefuse") and not (v41:GetAttribute("IsGettingDefused") or v41:GetAttribute("Defused"))) then
			v_u_19.broadcastRouter("Start Defuse Bomb")
			return
		else
			local v42 = v_u_29()
			if #v42 > 0 then
				for _, v43 in v42 do
					if v_u_4:GetAttribute("MovementV2DoorDebug") == true then
						print(string.format("[MovementV2.Door] use-send source=Use model=%s clientTime=%.6f", v43:GetFullName(), v_u_4:GetServerTimeNow()))
					end
					local v44 = v_u_7.PredictDoorUse(v43)
					local v45 = v_u_18.BreakableDoor.Use.Send
					local v46 = {
						["Model"] = v43
					}
					local v47
					if v44 == nil then
						v47 = nil
					else
						v47 = v44.ServerTick
					end
					v46.ServerTick = v47
					local v48
					if v44 == nil then
						v48 = nil
					else
						v48 = v44.TargetAngle
					end
					v46.TargetAngle = v48
					local v49
					if v44 == nil then
						v49 = nil
					else
						v49 = v44.RequestId
					end
					v46.RequestId = v49
					v45(v46)
				end
				return
			else
				local v50 = v_u_2:GetTagged("IsHoveringInteractable")
				if #v50 == 0 then
					return
				else
					table.sort(v50, v_u_23)
					local v51 = v50[1]
					local v52 = v51:GetAttribute("Weapon")
					local v53 = v51:GetAttribute("Skin")
					if v52 == "C4" and v_u_5:GetAttribute("Team") ~= "Terrorists" then
						return
					elseif v_u_17[v52] == nil or not v_u_40(v52) then
						if v51:GetAttribute("CanPickup") then
							local v54 = v_u_14.GetSkinInformation(v52, v53)
							if v54 then
								local v55 = v_u_16[v54.rarity]
								local v56 = v55.Color.R * 255
								local v57 = math.floor(v56)
								local v58 = v55.Color.G * 255
								local v59 = math.floor(v58)
								local v60 = v55.Color.B * 255
								local v61 = math.floor(v60)
								v_u_19.broadcastRouter("CreateNotification", "Item Picked Up", ("You picked up a <font color = \"rgb(%*, %*, %*)\"><b>%* | %*</b></font>"):format(v57, v59, v61, v52:find("Zeus") and "Taser" or v52, v53), 2)
							end
							v_u_18.Inventory.PickupWeapon.Send({
								["Identity"] = nil,
								["AllowAutoEquip"] = true,
								["Identity"] = v51.Name
							})
						end
					else
						return
					end
				end
			end
		end
	end
end
return table.freeze({
	["Category"] = "Weapon Keys",
	["Callback"] = nil,
	["Group"] = "Gameplay",
	["Name"] = "Use",
	["Callback"] = function(p63, _) -- name: onInput
		-- upvalues: (copy) v_u_5, (copy) v_u_10, (copy) v_u_62, (copy) v_u_8, (copy) v_u_2, (copy) v_u_19
		if v_u_5:GetAttribute("IsPlayerChatting") then
			return
		elseif v_u_10.getLocalCharacter() then
			if p63 == Enum.UserInputState.Begin then
				v_u_62()
			elseif p63 == Enum.UserInputState.End then
				v_u_8.StopRevive()
				if v_u_2:GetTagged("Bomb")[1] and (v_u_5:GetAttribute("IsDefusingBomb") or v_u_5:GetAttribute("IsLocallyDefusingBomb")) then
					v_u_19.broadcastRouter("Cancel Defuse Bomb")
					return
				end
				if v_u_5:GetAttribute("IsRescuingHostage") then
					v_u_19.broadcastRouter("Cancel Rescue Hostage")
				end
			end
		else
			return
		end
	end
})
-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.MainMenu
-- ModuleScript | 34 linhas | 1093 bytes | hash 858caf81

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
require(script.Parent.Parent.Types)
local v_u_3 = require(v1.Components.Common.IsPlayingTeam)
local v_u_4 = require(v1.Components.Common.IsTutorialMode)
local v_u_5 = require(v1.Shared.CloseButtonRegistry)
local v_u_6 = v2.LocalPlayer
local v_u_7 = require(v1.Interface.Screens.Menu.Top)
return table.freeze({
	["Name"] = "Main Menu",
	["Group"] = "Default",
	["Category"] = "UI Keys",
	["Callback"] = nil,
	["Callback"] = function(p8, p9) -- name: onInput
		-- upvalues: (copy) v_u_6, (copy) v_u_5, (copy) v_u_4, (copy) v_u_3, (copy) v_u_7
		if v_u_6:GetAttribute("IsPlayerChatting") then
			return
		else
			if p9.KeyCode == Enum.KeyCode.ButtonB then
				if p8 ~= Enum.UserInputState.Begin then
					return
				end
				if v_u_5.CloseFrame() or v_u_5.IsDoublePressed() then
					return
				end
			end
			if not v_u_4() then
				if (v_u_3(v_u_6:GetAttribute("Team")) or v_u_6:GetAttribute("IsSpectating") == true) and p8 == Enum.UserInputState.Begin then
					v_u_7.ToggleMenu()
				end
			end
		end
	end
})
-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.Inspect
-- ModuleScript | 3 linhas | 118 bytes | hash 231b2b96

return require(script.Parent.Parent.ActionTemplates).useEquipped("Inspect", "Inspect", function(p1)
	p1:inspect()
end)
-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.BuyMenu
-- ModuleScript | 20 linhas | 703 bytes | hash 38dc6ccc

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
require(script.Parent.Parent.Types)
local v_u_3 = require(v1.Components.Common.CharacterResolver)
local v_u_4 = v2.LocalPlayer
local v_u_5 = require(v1.Interface.Screens.Gameplay.Middle.BuyMenu)
return table.freeze({
	["Name"] = "Buy Menu",
	["Group"] = "Gameplay",
	["Category"] = "Weapon Keys",
	["Callback"] = nil,
	["Callback"] = function(p6, _) -- name: onInput
		-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_5
		if not v_u_4:GetAttribute("IsPlayerChatting") and p6 == Enum.UserInputState.Begin then
			if v_u_3.isAliveCharacter(v_u_3.getLocalCharacter()) then
				v_u_5.toggleFrame()
			end
		end
	end
})
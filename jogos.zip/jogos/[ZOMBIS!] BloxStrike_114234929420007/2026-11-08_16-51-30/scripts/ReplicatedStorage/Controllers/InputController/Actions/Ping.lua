-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.Ping
-- ModuleScript | 86 linhas | 2740 bytes | hash 0f19ed2a

local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("ReplicatedStorage")
local v3 = game:GetService("Workspace")
local v4 = game:GetService("Players")
require(script.Parent.Parent.Types)
local v_u_5 = require(v2.Components.Common.CharacterResolver)
local v_u_6 = require(v2.Database.Security.Remotes)
local v_u_7 = require(v2.Controllers.DataController)
local v_u_8 = v4.LocalPlayer
local v_u_9 = v3.CurrentCamera
local v_u_10 = 0
local v_u_11 = RaycastParams.new()
v_u_11.FilterType = Enum.RaycastFilterType.Exclude
v_u_11.IgnoreWater = false
local function v_u_15(p12) -- name: GetWeaponDataFromInstance
	-- upvalues: (copy) v_u_1
	while p12 do
		if v_u_1:HasTag(p12, "WeaponDropped") then
			local v13 = p12:GetAttribute("Weapon")
			local v14 = p12:GetAttribute("Skin")
			if v13 and v14 then
				return v13, v14, p12.Name
			end
			break
		end
		p12 = p12.Parent
	end
	return nil, nil, nil
end
local function v_u_19(...) -- name: GetRaycastResult
	-- upvalues: (copy) v_u_9, (copy) v_u_11
	local v16 = { v_u_9, ... }
	v_u_11.FilterDescendantsInstances = v16
	local v17 = workspace:Raycast(v_u_9.CFrame.Position, v_u_9.CFrame.LookVector * 1000, v_u_11)
	while v17 and v17.Instance do
		local v18 = v17.Instance
		if not v18:IsA("BasePart") or v18.Transparency <= 0.98 then
			break
		end
		table.insert(v16, v18)
		v_u_11.FilterDescendantsInstances = v16
		v17 = workspace:Raycast(v17.Position, v_u_9.CFrame.LookVector.Unit * (1000 - v17.Distance), v_u_11)
	end
	return v17
end
local v25 = {
	["Name"] = "Ping",
	["Group"] = "Gameplay",
	["Category"] = "UI Keys",
	["Callback"] = nil,
	["Callback"] = function(p20) -- name: onInput
		-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_5, (copy) v_u_19, (copy) v_u_15, (copy) v_u_6, (ref) v_u_10
		if workspace:GetAttribute("Gamemode") == "Deathmatch" then
			return
		elseif v_u_7.Get(v_u_8, "Settings.Game.HUD.Player Pings") == "Disabled" then
			return
		elseif v_u_5.isAliveCharacter(v_u_5.getPlayerCharacter(v_u_8)) and p20 == Enum.UserInputState.Begin then
			local v21 = v_u_19(v_u_5.getLocalCharacter())
			if v21 then
				local v22, v23, v24 = v_u_15(v21.Instance)
				if v22 and (v23 and v24) then
					v_u_6.Ping.CreatePlayerPositionPing.Send({
						["Position"] = nil,
						["WeaponIdentity"] = nil,
						["WeaponName"] = nil,
						["WeaponSkin"] = nil,
						["IsDanger"] = false,
						["Position"] = v21.Position,
						["WeaponIdentity"] = v24,
						["WeaponName"] = v22,
						["WeaponSkin"] = v23
					})
				else
					v_u_6.Ping.CreatePlayerPositionPing.Send({
						["IsDanger"] = tick() - v_u_10 < 0.5,
						["Position"] = v21.Position
					})
				end
				v_u_10 = tick()
			end
		else
			return
		end
	end
}
return table.freeze(v25)
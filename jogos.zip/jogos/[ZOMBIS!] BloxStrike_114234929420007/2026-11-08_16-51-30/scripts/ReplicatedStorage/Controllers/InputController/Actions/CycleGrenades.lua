-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.CycleGrenades
-- ModuleScript | 1 linhas | 83 bytes | hash dbf726b5

return require(script.Parent.Parent.ActionTemplates).equipSlot("Cycle Grenades", 4)
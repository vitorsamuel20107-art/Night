-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.CycleWeaponsLeft
-- ModuleScript | 4 linhas | 218 bytes | hash 47b13b0e

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(script.Parent.Parent.ActionTemplates)
local v3 = require(v1.Components.Common.UserInput.EquipSlotLeft)
return v2.cycleWeapons("Cycle Weapons Left", v3)
-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.Crouch
-- ModuleScript | 30 linhas | 924 bytes | hash 60d40627

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
require(script.Parent.Parent.Types)
local v_u_3 = v2.LocalPlayer
local v_u_4 = require(v1.Controllers.CharacterController)
local v5 = Enum.ContextActionPriority.High.Value + 1
v_u_3:GetAttributeChangedSignal("IsPlayerChatting"):Connect(function()
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	if v_u_3:GetAttribute("IsPlayerChatting") then
		v_u_4.crouch(false)
	end
end)
return table.freeze({
	["Name"] = "Crouch",
	["Group"] = "Gameplay",
	["Category"] = "Movement Keys",
	["BindPriority"] = nil,
	["Callback"] = nil,
	["BindPriority"] = v5,
	["Callback"] = function(p6, _) -- name: onInput
		-- upvalues: (copy) v_u_3, (copy) v_u_4
		if v_u_3:GetAttribute("IsPlayerChatting") then
			return
		elseif p6 == Enum.UserInputState.Begin then
			v_u_4.crouch(true)
		elseif p6 == Enum.UserInputState.End then
			v_u_4.crouch(false)
		end
	end
})
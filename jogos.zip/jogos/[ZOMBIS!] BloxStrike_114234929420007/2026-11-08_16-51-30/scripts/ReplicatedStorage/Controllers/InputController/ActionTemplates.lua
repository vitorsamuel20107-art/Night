-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.ActionTemplates
-- ModuleScript | 130 linhas | 4775 bytes | hash 1d5783fb

local v1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v3 = game:GetService("Players")
require(script.Parent:WaitForChild("Types"))
local v_u_4 = require(v_u_2.Components.Common.CharacterResolver)
local v_u_5 = require(v_u_2.Components.Common.SurvivalDowned)
local v_u_6 = require(v_u_2.Controllers.InventoryController)
local v_u_7 = require(v_u_2.Controllers.HintController)
local v_u_8 = require(v_u_2.Controllers.CaseSceneController)
local v_u_9 = require(v_u_2.Controllers.BlackMarketSceneController)
local v_u_10 = require(v_u_2.Controllers.InspectController)
local v_u_11 = require(v_u_2.Components.Common.UserInput.EquipInventorySlot)
local v_u_12 = require(v_u_2.Interface.MenuState)
local v_u_13 = require(v_u_2.Interface.Screens.Gameplay.Middle.Leaderboard)
local v_u_14 = v3.LocalPlayer
local v_u_15 = nil
local function v_u_20(p16, p17, p18, p19) -- name: action
	return table.freeze({
		["Name"] = p16,
		["Group"] = p17,
		["Category"] = p18,
		["Callback"] = p19
	})
end
local function v_u_28(p21, p_u_22) -- name: weaponKey
	-- upvalues: (copy) v_u_20, (copy) v_u_14, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_6, (copy) v_u_5
	return v_u_20(p21, "Gameplay", "Weapon Keys", function(p23, _)
		-- upvalues: (ref) v_u_14, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_6, (ref) v_u_5, (copy) p_u_22
		if v_u_14:GetAttribute("IsPlayerChatting") then
			return
		elseif p23 == Enum.UserInputState.Begin then
			if v_u_8.IsActive() or (v_u_9.IsActive() or v_u_10.IsActive()) then
				return
			else
				local v24 = v_u_6.getCurrentEquipped()
				local v25 = v_u_5.CanUseSlot
				local v26 = v_u_14
				local v27
				if v24 then
					v27 = v24.Properties.Slot
				else
					v27 = nil
				end
				if v25(v26, v27) then
					p_u_22()
				end
			end
		else
			return
		end
	end)
end
function v1.placeholder(p29, p30) -- name: placeholder
	-- upvalues: (copy) v_u_20
	return v_u_20(p29, "Gameplay", p30, function() end)
end
function v1.equipSlot(p31, p_u_32, p_u_33) -- name: equipSlot
	-- upvalues: (copy) v_u_28, (copy) v_u_7, (copy) v_u_11
	return v_u_28(p31, function()
		-- upvalues: (copy) p_u_33, (ref) v_u_7, (ref) v_u_11, (copy) p_u_32
		if p_u_33 then
			v_u_7:clearHint("Reload")
		end
		v_u_11(p_u_32)
	end)
end
function v1.equipGrenade(p34, p_u_35) -- name: equipGrenade
	-- upvalues: (copy) v_u_28, (copy) v_u_11
	return v_u_28(p34, function()
		-- upvalues: (ref) v_u_11, (copy) p_u_35
		v_u_11(4, function(p36)
			-- upvalues: (ref) p_u_35
			return p_u_35[p36.Name] == true
		end)
	end)
end
function v1.useEquipped(p37, p_u_38, p_u_39) -- name: useEquipped
	-- upvalues: (copy) v_u_28, (copy) v_u_6, (copy) v_u_7
	return v_u_28(p37, function()
		-- upvalues: (ref) v_u_6, (copy) p_u_39, (ref) v_u_7, (copy) p_u_38
		local v40 = v_u_6.getCurrentEquipped()
		if v40 then
			p_u_39(v40)
			v_u_7:clearHint(p_u_38)
		end
	end)
end
function v1.cycleWeapons(p41, p_u_42) -- name: cycleWeapons
	-- upvalues: (copy) v_u_20, (copy) v_u_14, (copy) v_u_12, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_13, (copy) v_u_7
	return v_u_20(p41, "Gameplay", "Weapon Keys", function(p43, p44)
		-- upvalues: (ref) v_u_14, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_13, (copy) p_u_42, (ref) v_u_7
		if v_u_14:GetAttribute("IsPlayerChatting") or p43 ~= Enum.UserInputState.Begin then
			return
		elseif not v_u_12.GetCurrentScreen() and (not v_u_8.IsActive() and (not v_u_9.IsActive() and (not v_u_10.IsActive() and (not v_u_13.IsRightClickUnlockActive() or p44.UserInputType ~= Enum.UserInputType.MouseWheel)))) then
			p_u_42()
			v_u_7:clearHint("Reload")
		end
	end)
end
function v1.movement(p45, p_u_46, p_u_47) -- name: movement
	-- upvalues: (copy) v_u_14, (copy) v_u_20, (copy) v_u_4
	local v_u_48 = require(v_u_14:WaitForChild("PlayerScripts"):WaitForChild("PlayerModule")):GetControls()
	return v_u_20(p45, "Default", "Movement Keys", function(p49, _)
		-- upvalues: (ref) v_u_14, (ref) v_u_4, (copy) v_u_48, (copy) p_u_46, (copy) p_u_47
		if v_u_14:GetAttribute("IsPlayerChatting") then
			return
		elseif v_u_4.isAliveCharacter(v_u_4.getPlayerCharacter(v_u_14)) then
			local v50 = v_u_48.activeController
			if v50 and v50.UpdateMovement then
				v50[p_u_46] = p49 ~= Enum.UserInputState.Begin and 0 or p_u_47
				v50:UpdateMovement(p49)
			end
		else
			return
		end
	end)
end
function v1.chat(p51, p_u_52) -- name: chat
	-- upvalues: (copy) v_u_20, (ref) v_u_15, (copy) v_u_2
	return v_u_20(p51, "Default", "Communication Options", function(p53, _)
		-- upvalues: (ref) v_u_15, (ref) v_u_2, (copy) p_u_52
		if p53 == Enum.UserInputState.Begin then
			if not v_u_15 then
				v_u_15 = require(v_u_2.Interface.Screens.Gameplay.Middle.Chat)
			end
			v_u_15.OpenChat(p_u_52())
		end
	end)
end
return v1
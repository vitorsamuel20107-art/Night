-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.SwitchViewmodelHand
-- ModuleScript | 21 linhas | 672 bytes | hash 14320057

local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2.Controllers.SpectateController)
local v_u_4 = require(v2.Shared.ViewmodelHand)
require(script.Parent.Parent.Types)
return table.freeze({
	["Name"] = "Switch Viewmodel Left/Right Hand",
	["Group"] = "Gameplay",
	["Category"] = "Weapon Keys",
	["Callback"] = nil,
	["Callback"] = function(p5) -- name: Callback
		-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_4
		if p5 == Enum.UserInputState.Begin then
			if not (v_u_1.LocalPlayer:GetAttribute("IsPlayerChatting") or v_u_3.IsSpectatingNow()) then
				v_u_4.Toggle()
			end
		else
			return
		end
	end
})
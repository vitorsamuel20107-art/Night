-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.MeleeWeapon
-- ModuleScript | 1 linhas | 87 bytes | hash 8f301919

return require(script.Parent.Parent.ActionTemplates).equipSlot("Melee Weapon", 3, true)
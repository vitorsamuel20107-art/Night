-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.CycleWeaponsRight
-- ModuleScript | 4 linhas | 220 bytes | hash 5d13ce54

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(script.Parent.Parent.ActionTemplates)
local v3 = require(v1.Components.Common.UserInput.EquipSlotRight)
return v2.cycleWeapons("Cycle Weapons Right", v3)
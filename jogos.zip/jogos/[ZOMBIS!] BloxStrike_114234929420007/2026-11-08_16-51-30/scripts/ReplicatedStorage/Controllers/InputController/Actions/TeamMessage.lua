-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.TeamMessage
-- ModuleScript | 8 linhas | 286 bytes | hash 3d7c5bea

local v1 = game:GetService("Players")
local v2 = require(script.Parent.Parent.ActionTemplates)
local v_u_3 = v1.LocalPlayer
return v2.chat("Team Message", function()
	-- upvalues: (copy) v_u_3
	local v4 = v_u_3:GetAttribute("Team")
	return (not v4 or v4 == "Spectators") and 1 or 0
end)
-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.DropWeapon
-- ModuleScript | 43 linhas | 1647 bytes | hash 0b2563f5

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
require(script.Parent.Parent.Types)
local v_u_3 = v2.LocalPlayer
local v_u_4 = require(v1.Controllers.InventoryController)
local v_u_5 = require(v1.Controllers.SpectateController)
local v_u_6 = require(v1.Components.Common.SurvivalDowned)
local v_u_7 = require(v1.Database.Components.Libraries.Skins)
local v_u_8 = require(v1.Database.Custom.GameStats.Rarities)
local v_u_9 = require(v1.Database.Security.Router)
return table.freeze({
	["Name"] = "Drop Weapon",
	["Group"] = "Gameplay",
	["Category"] = "Weapon Keys",
	["Callback"] = nil,
	["Callback"] = function(p10, _) -- name: onInput
		-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_6, (copy) v_u_4, (copy) v_u_7, (copy) v_u_8, (copy) v_u_9
		if v_u_3:GetAttribute("IsPlayerChatting") or p10 ~= Enum.UserInputState.Begin then
			return
		elseif v_u_5.IsLocalPlayerDead() or v_u_6.AreHandsBusy(v_u_3) then
			return
		else
			local v11 = v_u_4.getCurrentEquipped()
			if v11 then
				local v12 = v_u_7.GetSkinInformation(v11.Name, v11.Skin)
				if v12 then
					local v13 = v_u_8[v12.rarity]
					local v14 = v13.Color.R * 255
					local v15 = math.floor(v14)
					local v16 = v13.Color.G * 255
					local v17 = math.floor(v16)
					local v18 = v13.Color.B * 255
					local v19 = math.floor(v18)
					if v11:drop() then
						v_u_9.broadcastRouter("CreateNotification", "Item Dropped", ("You dropped your <font color = \"rgb(%*, %*, %*)\"><b>%* | %*</b></font>"):format(v15, v17, v19, v11.Name:find("Zeus") and "Taser" or v11.Name, v11.Skin), 2)
					end
				end
			else
				return
			end
		end
	end
})
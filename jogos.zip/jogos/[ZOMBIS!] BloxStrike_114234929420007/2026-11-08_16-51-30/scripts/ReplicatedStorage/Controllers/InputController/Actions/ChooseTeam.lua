-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.ChooseTeam
-- ModuleScript | 30 linhas | 954 bytes | hash f19c7dda

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
require(script.Parent.Parent.Types)
local v_u_3 = require(v1.Components.Common.CharacterResolver)
local v_u_4 = require(v1.Components.Common.IsPlayingTeam)
local v_u_5 = v2.LocalPlayer
local v_u_6 = require(v1.Interface.Screens.Gameplay.Middle.TeamSelection)
return table.freeze({
	["Name"] = "Choose Team",
	["Group"] = "Default",
	["Category"] = "UI Keys",
	["Callback"] = nil,
	["Callback"] = function(p7, _) -- name: onInput
		-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_6, (copy) v_u_3
		if v_u_5:GetAttribute("IsPlayerChatting") or p7 ~= Enum.UserInputState.Begin then
			return
		else
			local v8 = v_u_5:GetAttribute("IsSpectating")
			if v_u_4(v_u_5:GetAttribute("Team")) or v8 == true then
				if v8 then
					v_u_6.openFrame()
				elseif v_u_3.getLocalCharacter() then
					v_u_6.ToggleTeamSelection()
				end
			else
				return
			end
		end
	end
})
-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.MoveBackward
-- ModuleScript | 1 linhas | 98 bytes | hash 6105acc0

return require(script.Parent.Parent.ActionTemplates).movement("Move Backward", "backwardValue", 1)
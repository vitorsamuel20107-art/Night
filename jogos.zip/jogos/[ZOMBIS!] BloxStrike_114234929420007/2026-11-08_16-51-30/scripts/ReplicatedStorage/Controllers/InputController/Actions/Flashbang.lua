-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.Flashbang
-- ModuleScript | 3 linhas | 105 bytes | hash f845ccf6

return require(script.Parent.Parent.ActionTemplates).equipGrenade("Flashbang", {
	["Flashbang"] = true
})
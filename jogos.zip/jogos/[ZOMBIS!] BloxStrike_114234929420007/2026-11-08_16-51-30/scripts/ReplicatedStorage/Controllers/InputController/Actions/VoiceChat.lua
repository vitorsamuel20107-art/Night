-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.VoiceChat
-- ModuleScript | 343 linhas | 10288 bytes | hash 2a7df538

local v_u_1 = {}
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Players")
local v4 = require(v2.Controllers.DataController)
local v_u_5 = require(v2.Controllers.RunServiceController)
local v6 = require(v2.Packages.Signal)
local v_u_7 = v_u_3.LocalPlayer
local v_u_8 = {
	["disabled"] = "Disabled",
	["off"] = "Disabled",
	["push to talk"] = "Push To Talk",
	["pushtotalk"] = "Push To Talk",
	["ptt"] = "Push To Talk",
	["open mic"] = "Open Microphone",
	["openmic"] = "Open Microphone",
	["open microphone"] = "Open Microphone",
	["openmicrophone"] = "Open Microphone"
}
local v_u_9 = v6.new()
local v_u_10 = {
	["IsPushToTalkHeld"] = false,
	["IsVoiceInputRefreshQueued"] = false,
	["LastVoiceInputScanTime"] = 0,
	["PlayerConnections"] = nil,
	["SpeakingPlayers"] = nil,
	["ShouldRecreateVoiceInputs"] = false,
	["Trackers"] = nil,
	["VoiceActivityConnection"] = nil,
	["VoiceMode"] = "Disabled",
	["PlayerConnections"] = {},
	["SpeakingPlayers"] = {},
	["Trackers"] = {}
}
v_u_1.Name = "Voice Chat"
v_u_1.Group = "Default"
v_u_1.Category = "Communication Options"
v_u_1.SpeakingChanged = v_u_9
function v_u_1.GetVoiceMode(p11) -- name: GetVoiceMode
	-- upvalues: (copy) v_u_8
	if typeof(p11) ~= "string" then
		return "Disabled"
	end
	local v12 = string.lower(p11)
	local v13 = string.gsub(v12, "[%s_%-%./]+", " ")
	local v14 = string.gsub(v13, "^%s+", "")
	local v15 = string.gsub(v14, "%s+$", "")
	local v16 = string.gsub(v15, "%s+", "")
	return v_u_8[v15] or v_u_8[v16] or "Disabled"
end
function v_u_1.SetVoiceMode(p17) -- name: SetVoiceMode
	-- upvalues: (copy) v_u_10, (copy) v_u_1
	v_u_10.VoiceMode = v_u_1.GetVoiceMode(p17)
	v_u_10.IsPushToTalkHeld = false
	v_u_1.SyncVoiceMuted()
	v_u_1.SyncVoiceActivity()
end
function v_u_1.SetPushToTalkHeld(p18) -- name: SetPushToTalkHeld
	-- upvalues: (copy) v_u_10, (copy) v_u_1
	v_u_10.IsPushToTalkHeld = p18
	v_u_1.SyncVoiceMuted()
	v_u_1.SyncVoiceActivity()
end
function v_u_1.IsVoiceTransmitting() -- name: IsVoiceTransmitting
	-- upvalues: (copy) v_u_7, (copy) v_u_10
	if v_u_7:GetAttribute("IsPlayerChatting") then
		return false
	end
	if v_u_10.VoiceMode == "Open Microphone" then
		return true
	end
	local v19
	if v_u_10.VoiceMode == "Push To Talk" then
		v19 = v_u_10.IsPushToTalkHeld
	else
		v19 = false
	end
	return v19
end
function v_u_1.IsPlayerSpeaking(p20) -- name: IsPlayerSpeaking
	-- upvalues: (copy) v_u_10
	return v_u_10.SpeakingPlayers[p20] == true
end
function v_u_1.SetPlayerSpeaking(p21, p22) -- name: SetPlayerSpeaking
	-- upvalues: (copy) v_u_1, (copy) v_u_10, (copy) v_u_9
	if v_u_1.IsPlayerSpeaking(p21) ~= p22 then
		v_u_10.SpeakingPlayers[p21] = p22 and true or nil
		v_u_9:Fire(p21, p22)
	end
end
function v_u_1.GetVoiceInput(p23) -- name: GetVoiceInput
	-- upvalues: (copy) v_u_7
	return (p23 or v_u_7):FindFirstChildWhichIsA("AudioDeviceInput")
end
function v_u_1.CanLocalPlayerHear(p24) -- name: CanLocalPlayerHear
	-- upvalues: (copy) v_u_7
	local v25 = p24.GetUserIdAccessList
	local v26, v27 = pcall(v25, p24)
	if v26 then
		local v28 = table.find(v27, v_u_7.UserId) ~= nil
		if p24.AccessType == Enum.AccessModifierType.Deny then
			return not v28
		else
			return v28
		end
	else
		return nil
	end
end
function v_u_1.SetVoiceMuted(p29) -- name: SetVoiceMuted
	-- upvalues: (copy) v_u_1
	local v30 = v_u_1.GetVoiceInput()
	if v30 then
		v30.Muted = p29
	end
end
function v_u_1.DestroyTracker(p31) -- name: DestroyTracker
	-- upvalues: (copy) v_u_10, (copy) v_u_1
	local v32 = v_u_10.Trackers[p31]
	if v32 then
		v32.Wire:Destroy()
		v32.Analyzer:Destroy()
		v_u_10.Trackers[p31] = nil
		v_u_1.SetPlayerSpeaking(p31, false)
	end
end
function v_u_1.QueueVoiceInputRefresh(p33, p34) -- name: QueueVoiceInputRefresh
	-- upvalues: (copy) v_u_10, (copy) v_u_1
	v_u_10.ShouldRecreateVoiceInputs = v_u_10.ShouldRecreateVoiceInputs or p33 == true
	if p34 then
		task.delay(0.25, function()
			-- upvalues: (ref) v_u_1
			v_u_1.QueueVoiceInputRefresh(true)
		end)
	end
	if not v_u_10.IsVoiceInputRefreshQueued then
		v_u_10.IsVoiceInputRefreshQueued = true
		task.defer(function()
			-- upvalues: (ref) v_u_10, (ref) v_u_1
			local v35 = v_u_10.ShouldRecreateVoiceInputs
			v_u_10.IsVoiceInputRefreshQueued = false
			v_u_10.ShouldRecreateVoiceInputs = false
			if v35 then
				local v36 = {}
				for v37, v38 in pairs(v_u_10.Trackers) do
					local v39 = v_u_1.CanLocalPlayerHear(v38.Input)
					if v39 ~= nil and v39 == v38.CanHear then
						continue
					end
					table.insert(v36, v37)
				end
				for _, v40 in ipairs(v36) do
					v_u_1.DestroyTracker(v40)
				end
			end
			v_u_1.SyncVoiceInputs(true)
			v_u_1.SyncVoiceActivity()
		end)
	end
end
function v_u_1.TrackVoiceInput(p41, p42) -- name: TrackVoiceInput
	-- upvalues: (copy) v_u_10, (copy) v_u_1, (copy) v_u_7
	local v43 = v_u_10.Trackers[p41]
	if not v43 or v43.Input ~= p42 then
		v_u_1.DestroyTracker(p41)
		local v44 = Instance.new("AudioAnalyzer")
		v44.Name = ("%*VoiceChatAnalyzer"):format(p41.Name)
		v44.SpectrumEnabled = false
		v44.Parent = v_u_7
		local v45 = Instance.new("Wire")
		v45.Name = "VoiceChatAnalyzerWire"
		v45.SourceInstance = p42
		v45.SourceName = "Output"
		v45.TargetInstance = v44
		v45.TargetName = "Input"
		v45.Parent = v44
		v_u_10.Trackers[p41] = {
			["Analyzer"] = nil,
			["CanHear"] = nil,
			["Input"] = nil,
			["LastVoiceActivityTime"] = 0,
			["Wire"] = nil,
			["Analyzer"] = v44,
			["CanHear"] = v_u_1.CanLocalPlayerHear(p42),
			["Input"] = p42,
			["Wire"] = v45
		}
		if p41 == v_u_7 then
			v_u_1.SyncVoiceMuted()
		end
	end
end
function v_u_1.SyncVoiceInputs(p46) -- name: SyncVoiceInputs
	-- upvalues: (copy) v_u_10, (copy) v_u_1, (copy) v_u_3
	local v47 = os.clock()
	if p46 or v47 - v_u_10.LastVoiceInputScanTime >= 0.2 then
		v_u_10.LastVoiceInputScanTime = v47
		for v48 in pairs(v_u_10.Trackers) do
			if v48.Parent then
				continue
			end
			v_u_1.DestroyTracker(v48)
		end
		for _, v49 in ipairs(v_u_3:GetPlayers()) do
			local v50 = v_u_10.Trackers[v49]
			local v51 = v_u_1.GetVoiceInput(v49)
			if v51 then
				v_u_1.TrackVoiceInput(v49, v51)
			else
				if not v50 then
					continue
				end
				v_u_1.DestroyTracker(v49)
			end
		end
	end
end
function v_u_1.ObservePlayer(p52) -- name: ObservePlayer
	-- upvalues: (copy) v_u_10, (copy) v_u_1
	if not v_u_10.PlayerConnections[p52] then
		local v53 = {}
		v_u_10.PlayerConnections[p52] = v53
		local function v54() -- name: refreshVoiceAccess
			-- upvalues: (ref) v_u_1
			v_u_1.QueueVoiceInputRefresh(true, true)
		end
		local function v56(p55) -- name: refreshVoiceInput
			-- upvalues: (ref) v_u_1
			if p55:IsA("AudioDeviceInput") then
				v_u_1.QueueVoiceInputRefresh()
			end
		end
		local v57 = p52:GetAttributeChangedSignal("Team")
		table.insert(v53, v57:Connect(v54))
		local v58 = p52:GetAttributeChangedSignal("IsSpectating")
		table.insert(v53, v58:Connect(v54))
		local v59 = p52.ChildAdded
		table.insert(v53, v59:Connect(v56))
		local v60 = p52.ChildRemoved
		table.insert(v53, v60:Connect(v56))
		v_u_1.QueueVoiceInputRefresh()
	end
end
function v_u_1.UnobservePlayer(p61) -- name: UnobservePlayer
	-- upvalues: (copy) v_u_10, (copy) v_u_1
	local v62 = v_u_10.PlayerConnections[p61]
	if v62 then
		v_u_10.PlayerConnections[p61] = nil
		for _, v63 in ipairs(v62) do
			v63:Disconnect()
		end
		table.clear(v62)
		v_u_1.DestroyTracker(p61)
	else
		v_u_1.DestroyTracker(p61)
	end
end
function v_u_1.SyncPlayerVoiceActivity(p64, p65) -- name: SyncPlayerVoiceActivity
	-- upvalues: (copy) v_u_7, (copy) v_u_1
	if p64 == v_u_7 and not v_u_1.IsVoiceTransmitting() then
		p65.LastVoiceActivityTime = 0
		v_u_1.SetPlayerSpeaking(p64, false)
		return
	else
		local v66 = os.clock()
		local v67 = p65.Analyzer.RmsLevel
		local v68 = p65.Analyzer.PeakLevel
		local v69 = math.max(v67, v68)
		if v_u_1.IsPlayerSpeaking(p64) then
			if v69 >= 0.0005 then
				p65.LastVoiceActivityTime = v66
			elseif v66 - p65.LastVoiceActivityTime >= 0.7 then
				v_u_1.SetPlayerSpeaking(p64, false)
			end
		else
			if v69 >= 0.0008 then
				p65.LastVoiceActivityTime = v66
				v_u_1.SetPlayerSpeaking(p64, true)
			end
			return
		end
	end
end
function v_u_1.SyncVoiceActivity() -- name: SyncVoiceActivity
	-- upvalues: (copy) v_u_1, (copy) v_u_10
	v_u_1.SyncVoiceInputs()
	for v70, v71 in pairs(v_u_10.Trackers) do
		v_u_1.SyncPlayerVoiceActivity(v70, v71)
	end
end
function v_u_1.StartVoiceActivityLoop() -- name: StartVoiceActivityLoop
	-- upvalues: (copy) v_u_10, (copy) v_u_5, (copy) v_u_1
	if not v_u_10.VoiceActivityConnection then
		v_u_10.VoiceActivityConnection = v_u_5.BindToPostSimulation("InputController.VoiceChat.SyncVoiceActivity", v_u_1.SyncVoiceActivity)
	end
end
function v_u_1.SyncVoiceMuted() -- name: SyncVoiceMuted
	-- upvalues: (copy) v_u_7, (copy) v_u_1, (copy) v_u_10
	if v_u_7:GetAttribute("IsPlayerChatting") then
		v_u_1.SetVoiceMuted(true)
		return
	elseif v_u_10.VoiceMode == "Open Microphone" then
		v_u_1.SetVoiceMuted(false)
	else
		v_u_1.SetVoiceMuted(v_u_10.VoiceMode ~= "Push To Talk" and true or not v_u_10.IsPushToTalkHeld)
	end
end
function v_u_1.OnInput(p72, _) -- name: OnInput
	-- upvalues: (copy) v_u_7, (copy) v_u_1, (copy) v_u_10
	if v_u_7:GetAttribute("IsPlayerChatting") then
		v_u_1.SetPushToTalkHeld(false)
		return
	elseif v_u_10.VoiceMode == "Push To Talk" then
		if p72 == Enum.UserInputState.Begin then
			v_u_1.SetPushToTalkHeld(true)
		elseif p72 == Enum.UserInputState.End or p72 == Enum.UserInputState.Cancel then
			v_u_1.SetPushToTalkHeld(false)
		end
	else
		v_u_1.SyncVoiceMuted()
		return
	end
end
v_u_3.PlayerAdded:Connect(v_u_1.ObservePlayer)
v_u_3.PlayerRemoving:Connect(v_u_1.UnobservePlayer)
workspace:GetAttributeChangedSignal("VoiceAccessRevision"):Connect(function()
	-- upvalues: (copy) v_u_1
	v_u_1.QueueVoiceInputRefresh(true, true)
end)
for _, v73 in ipairs(v_u_3:GetPlayers()) do
	v_u_1.ObservePlayer(v73)
end
v_u_7:GetAttributeChangedSignal("IsPlayerChatting"):Connect(function()
	-- upvalues: (copy) v_u_1
	v_u_1.SyncVoiceMuted()
	v_u_1.SyncVoiceActivity()
end)
v4.CreateListener(v_u_7, "Settings.Audio.Voice Chat.Voice Chat Activation Mode", v_u_1.SetVoiceMode)
v_u_1.StartVoiceActivityLoop()
v_u_1.SyncVoiceMuted()
v_u_1.SyncVoiceInputs(true)
v_u_1.SyncVoiceActivity()
v_u_1.Callback = v_u_1.OnInput
return table.freeze(v_u_1)
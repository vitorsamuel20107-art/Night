-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.Fire
-- ModuleScript | 229 linhas | 7430 bytes | hash 3926b183

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("RunService")
local v3 = game:GetService("Players")
require(script.Parent.Parent.Types)
local v_u_4 = require(script.Parent.Parent.GamepadTrigger)
local v_u_5 = v3.LocalPlayer
local v_u_6 = require(v1.Controllers.InventoryController)
local v_u_7 = require(v1.Controllers.SpectateController)
local v_u_8 = require(v1.Controllers.CaseSceneController)
local v_u_9 = require(v1.Controllers.BlackMarketSceneController)
local v_u_10 = require(v1.Controllers.InspectController)
local v_u_11 = require(v1.Controllers.HintController)
local v_u_12 = require(v1.Database.Security.Router)
local v_u_13 = require(v1.Database.Components.GameState)
local v14 = require(v1.Components.Common.GetUserPlatform)
local v_u_15 = require(v1.Components.Common.CharacterResolver)
local v_u_16 = require(v1.Components.Common.SurvivalDowned)
local v_u_17 = table.find(v14(), "Mobile")
if v_u_17 then
	v_u_17 = #v14() <= 1
end
local v_u_18 = nil
local v_u_19 = nil
local v_u_20 = false
local v_u_21 = false
local v_u_22 = nil
local v_u_23 = false
local v_u_24 = table.freeze({
	[Enum.KeyCode.ButtonR2] = true,
	[Enum.KeyCode.ButtonL2] = true
})
v_u_2:BindToRenderStep("FireAction.SameFrameFire", Enum.RenderPriority.Camera.Value + 2, function()
	-- upvalues: (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (copy) v_u_6, (copy) v_u_11
	if v_u_21 then
		v_u_21 = false
		local v_u_25 = v_u_22
		local v_u_26 = v_u_23
		v_u_22 = nil
		v_u_23 = false
		if v_u_25 then
			task.spawn(function()
				-- upvalues: (ref) v_u_6, (copy) v_u_25, (copy) v_u_26, (ref) v_u_11
				local v27 = v_u_6.getCurrentEquipped()
				if v27 and v27.Identifier == v_u_25.Identifier then
					if v_u_26 then
						v_u_25:fireBurst()
					else
						debug.profilebegin("FireAction.Shot")
						v_u_25:shoot()
						if v_u_25.Rounds and v_u_25.Rounds <= 0 then
							debug.profilebegin("FireAction.ReloadHint")
							v_u_11:createHint("Reload")
							debug.profileend()
						end
						debug.profileend()
					end
				else
					v_u_25.IsBurstShooting = false
					return
				end
			end)
		end
	else
		return
	end
end)
local v41 = {
	["Name"] = "Fire",
	["Group"] = "Default",
	["Category"] = "Weapon Keys",
	["Callback"] = nil,
	["Callback"] = function(p28, p29) -- name: onInput
		-- upvalues: (copy) v_u_17, (copy) v_u_5, (copy) v_u_7, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (ref) v_u_20, (copy) v_u_6, (copy) v_u_15, (copy) v_u_13, (copy) v_u_16, (copy) v_u_12, (copy) v_u_4, (ref) v_u_18, (ref) v_u_19, (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (copy) v_u_2, (copy) v_u_11, (copy) v_u_24
		if v_u_17 and p29.UserInputType == Enum.UserInputType.MouseButton1 then
			return
		elseif v_u_5:GetAttribute("IsPlayerChatting") then
			return
		elseif v_u_7.IsSpectatingNow() and (p28 == Enum.UserInputState.Begin and not v_u_7.IsControllerPress(p29)) then
			v_u_7.RequestSwitch(-1)
			return
		elseif v_u_7.IsLocalPlayerDead() or (v_u_8.IsActive() or (v_u_9.IsActive() or v_u_10.IsActive())) then
			if p28 == Enum.UserInputState.End then
				v_u_20 = false
			end
			return
		else
			local v_u_30 = v_u_6.getCurrentEquipped()
			if v_u_30 and (v_u_15.getLocalCharacter() and v_u_13.GetState() ~= "Buy Period") then
				if p28 ~= Enum.UserInputState.Begin or v_u_16.CanUseSlot(v_u_5, v_u_30.Properties.Slot) then
					v_u_12.broadcastRouter("Cancel Defuse Bomb")
					if p28 == Enum.UserInputState.Begin then
						local v31 = v_u_4.isGamepadInput(p29)
						local v32 = v_u_30.Properties.Class
						local v33 = v_u_30.Properties.Slot
						if v31 and (v_u_20 and (v32 == "Weapon" and not v_u_30.Properties.Automatic)) then
							return
						end
						if v31 then
							v_u_20 = true
						end
						if v32 == "C4" then
							v_u_30:shoot()
							return
						end
						if v33 == "Grenade" then
							v_u_30:StartThrow()
							return
						end
						if v32 == "Weapon" then
							if v_u_30.Properties.ShootingOptions == "Revolver" then
								if v_u_18 then
									task.cancel(v_u_18)
									v_u_18 = nil
									v_u_19 = nil
								end
								v_u_30:startRevolverCharge(v_u_4.getInputBinding(p29))
								return
							end
							v_u_30.IsFireHeld = true
							v_u_30.FireInputBinding = v_u_4.getInputBinding(p29)
						end
						local v34 = not v_u_30.IsBurstShooting and (not v_u_30.IsShooting and v_u_30.Properties.FireRate)
						if v34 then
							v34 = tick() - v_u_30.AlternativeSwitchTick > v_u_30.Properties.FireRate
						end
						if v34 then
							if v_u_18 then
								task.cancel(v_u_18)
								v_u_18 = nil
								v_u_19 = nil
							end
							local v35 = v_u_30.AlternativeShootingOption == "Burst"
							v_u_30.IsBurstShooting = v35
							if v_u_21 then
								v_u_30.IsBurstShooting = false
							else
								v_u_21 = true
								v_u_22 = v_u_30
								v_u_23 = v35
							end
						end
						if not v_u_30.Properties.Automatic and (v_u_30.AlternativeShootingOption == "Default" and (v_u_30.IsShooting and v_u_19 ~= v_u_30.Identifier)) then
							if v_u_18 then
								task.cancel(v_u_18)
							end
							local v36 = v_u_30.NextShotDue
							local v37
							if v36 then
								local v38 = v36 - os.clock()
								v37 = math.max(0, v38)
							else
								v37 = 0
							end
							if v37 <= 0.15 then
								v_u_19 = v_u_30.Identifier
								v_u_18 = task.delay(v37, function()
									-- upvalues: (ref) v_u_2, (ref) v_u_18, (ref) v_u_19, (ref) v_u_6, (copy) v_u_30, (ref) v_u_11
									v_u_2.Heartbeat:Wait()
									v_u_2.Heartbeat:Wait()
									v_u_18 = nil
									v_u_19 = nil
									local v39 = v_u_6.getCurrentEquipped()
									if v39 and (v39.Identifier == v_u_30.Identifier and not v39.Properties.Automatic) then
										if v39.AlternativeShootingOption == "Burst" then
											return
										elseif v39.Rounds <= 0 then
											v_u_11:createHint("Reload")
										else
											v39:shoot()
										end
									else
										return
									end
								end)
								return
							end
						end
					else
						if p28 == Enum.UserInputState.End and v_u_30.Properties.Class == "Weapon" then
							if v_u_30.Properties.ShootingOptions == "Revolver" then
								if v_u_4.isStillPressed(p29, v_u_24) then
									return
								else
									v_u_20 = false
									local v40 = v_u_30.Properties.FireModes
									if v40 then
										v40 = v_u_30.Properties.FireModes.Primary
									end
									if not v40 or v40.CancelOnRelease ~= false then
										v_u_30:cancelRevolverCharge(false)
									else
										v_u_30.IsFireHeld = false
										v_u_30.FireInputBinding = nil
									end
								end
							else
								v_u_20 = false
								v_u_30.IsFireHeld = false
								v_u_30.FireInputBinding = nil
								return
							end
						end
						if p28 == Enum.UserInputState.End and v_u_30.Properties.Class == "C4" then
							if not v_u_4.isStillPressed(p29, v_u_24) then
								v_u_20 = false
								v_u_30:cancel()
							end
						end
						if v_u_30.Properties.Slot == "Grenade" and p28 == Enum.UserInputState.End then
							v_u_20 = false
							if v_u_30.ThrowStarted and not v_u_30.ThrowFinished then
								v_u_30:Throw("Far")
								return
							end
						elseif p28 == Enum.UserInputState.End then
							v_u_20 = false
						end
					end
				end
			else
				if p28 == Enum.UserInputState.End then
					v_u_20 = false
				end
				return
			end
		end
	end
}
return table.freeze(v41)
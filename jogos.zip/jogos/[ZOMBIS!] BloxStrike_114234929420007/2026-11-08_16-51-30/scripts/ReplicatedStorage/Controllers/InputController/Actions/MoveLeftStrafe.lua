-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.MoveLeftStrafe
-- ModuleScript | 1 linhas | 100 bytes | hash 323f849b

return require(script.Parent.Parent.ActionTemplates).movement("Move Left (Strafe)", "leftValue", -1)
-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.HealthShot
-- ModuleScript | 1 linhas | 94 bytes | hash d8340463

return require(script.Parent.Parent.ActionTemplates).placeholder("Health Shot", "Weapon Keys")
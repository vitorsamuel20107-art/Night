-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.ChatMessage
-- ModuleScript | 3 linhas | 99 bytes | hash cc2edb83

return require(script.Parent.Parent.ActionTemplates).chat("Chat Message", function()
	return 1
end)
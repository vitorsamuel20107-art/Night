-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.Reload
-- ModuleScript | 3 linhas | 115 bytes | hash 67383a59

return require(script.Parent.Parent.ActionTemplates).useEquipped("Reload", "Reload", function(p1)
	p1:reload()
end)
-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.Jump
-- ModuleScript | 34 linhas | 963 bytes | hash 0fa43391

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
require(script.Parent.Parent.Types)
local v_u_3 = require(v1.Controllers.CharacterController)
local v_u_4 = v2.LocalPlayer
local v7 = {
	["Name"] = "Jump",
	["Group"] = "Gameplay",
	["Category"] = "Movement Keys",
	["BindPriority"] = nil,
	["Callback"] = nil,
	["BindPriority"] = Enum.ContextActionPriority.High.Value + 1,
	["Callback"] = function(p5, p6) -- name: onInput
		-- upvalues: (copy) v_u_4, (copy) v_u_3
		if p5 == Enum.UserInputState.Begin then
			if v_u_4:GetAttribute("IsPlayerChatting") then
				return
			elseif p6.UserInputType == Enum.UserInputType.MouseWheel then
				v_u_3.jump()
			else
				v_u_3.jump(true)
			end
		else
			if p5 == Enum.UserInputState.End or p5 == Enum.UserInputState.Cancel then
				if p6.UserInputType == Enum.UserInputType.MouseWheel then
					return
				end
				v_u_3.jump(false)
			end
			return
		end
	end
}
return table.freeze(v7)
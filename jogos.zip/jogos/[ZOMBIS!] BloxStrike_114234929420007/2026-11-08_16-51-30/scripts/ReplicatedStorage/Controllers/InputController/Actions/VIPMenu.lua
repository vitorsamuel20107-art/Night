-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.VIPMenu
-- ModuleScript | 50 linhas | 1215 bytes | hash 5130a02f

local v_u_1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
require(script.Parent.Parent.Types)
local v_u_3 = v2.LocalPlayer
local v_u_4 = nil
local v_u_5 = 0
local v12 = {
	["Name"] = "VIP Menu",
	["Group"] = "Default",
	["Category"] = "UI Keys",
	["BindPriority"] = nil,
	["Callback"] = nil,
	["BindPriority"] = Enum.ContextActionPriority.High.Value + 1,
	["Callback"] = function(p6, _) -- name: onInput
		-- upvalues: (ref) v_u_5, (copy) v_u_3, (ref) v_u_4, (copy) v_u_1
		if p6 == Enum.UserInputState.Begin then
			local v7 = os.clock()
			if v7 - v_u_5 < 0.15 then
				return
			else
				v_u_5 = v7
				if not v_u_3:GetAttribute("IsPlayerChatting") then
					local v8
					if v_u_4 then
						v8 = v_u_4
					else
						local function v9()
							-- upvalues: (ref) v_u_1
							return require(v_u_1.Interface.Screens.Gameplay.Middle.VIPMenu)
						end
						local v10, v11 = pcall(v9)
						if v10 then
							v_u_4 = v11
							v8 = v_u_4
						else
							warn((("Failed to load VIPMenu module: %*"):format((tostring(v11)))))
							v8 = nil
						end
					end
					if v8 then
						v8.toggleFrame()
					end
				end
			end
		else
			return
		end
	end
}
return table.freeze(v12)
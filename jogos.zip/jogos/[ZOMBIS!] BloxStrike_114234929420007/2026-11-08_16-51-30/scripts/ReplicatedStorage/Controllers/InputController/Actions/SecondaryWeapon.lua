-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.SecondaryWeapon
-- ModuleScript | 1 linhas | 91 bytes | hash c2bdd078

return require(script.Parent.Parent.ActionTemplates).equipSlot("Secondary Weapon", 2, true)
-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.PrimaryWeapon
-- ModuleScript | 1 linhas | 89 bytes | hash d74c06b3

return require(script.Parent.Parent.ActionTemplates).equipSlot("Primary Weapon", 1, true)
-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.SmokeGrenade
-- ModuleScript | 3 linhas | 113 bytes | hash 96d3e3b4

return require(script.Parent.Parent.ActionTemplates).equipGrenade("Smoke Grenade", {
	["Smoke Grenade"] = true
})
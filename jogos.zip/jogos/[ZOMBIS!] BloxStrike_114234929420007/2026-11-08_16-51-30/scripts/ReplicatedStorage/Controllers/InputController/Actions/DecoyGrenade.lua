-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.DecoyGrenade
-- ModuleScript | 3 linhas | 113 bytes | hash 84dbcdbe

return require(script.Parent.Parent.ActionTemplates).equipGrenade("Decoy Grenade", {
	["Decoy Grenade"] = true
})
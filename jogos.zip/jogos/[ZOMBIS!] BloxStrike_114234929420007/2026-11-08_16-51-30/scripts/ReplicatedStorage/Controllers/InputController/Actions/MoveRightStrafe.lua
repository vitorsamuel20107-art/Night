-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.MoveRightStrafe
-- ModuleScript | 1 linhas | 101 bytes | hash 73d9a474

return require(script.Parent.Parent.ActionTemplates).movement("Move Right (Strafe)", "rightValue", 1)
-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController.Actions.HEGrenade
-- ModuleScript | 3 linhas | 107 bytes | hash 597c3850

return require(script.Parent.Parent.ActionTemplates).equipGrenade("HE Grenade", {
	["HE Grenade"] = true
})
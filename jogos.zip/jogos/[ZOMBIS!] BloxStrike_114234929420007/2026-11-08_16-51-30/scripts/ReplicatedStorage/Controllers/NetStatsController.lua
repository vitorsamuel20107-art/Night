-- NIGHT Analyzer | ReplicatedStorage.Controllers.NetStatsController
-- ModuleScript | 441 linhas | 14156 bytes | hash 325b3b4d

local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = v1.LocalPlayer
local v_u_4 = require(v2.MovementV2.DiagnosticProtocol)
local v_u_5 = require(v2.MovementV2.Client.PredictionErrorSmoother)
local v6 = {}
local v_u_7 = false
local v_u_8 = nil
local v_u_9 = {
	["DurationSeconds"] = 0,
	["RemoteRxBytes"] = 0,
	["OwnerRxBytes"] = 0,
	["CommandTxBytes"] = 0,
	["RemotePackets"] = 0,
	["OwnerPackets"] = 0,
	["CommandPackets"] = 0,
	["RecoveryPackets"] = 0,
	["FullActorRecords"] = 0,
	["DeltaActorRecords"] = 0,
	["RemovedActorRecords"] = 0
}
local v_u_10 = {
	["DurationSeconds"] = 0,
	["RemoteRxBytes"] = 0,
	["OwnerRxBytes"] = 0,
	["CommandTxBytes"] = 0,
	["RemotePackets"] = 0,
	["OwnerPackets"] = 0,
	["CommandPackets"] = 0,
	["RecoveryPackets"] = 0,
	["FullActorRecords"] = 0,
	["DeltaActorRecords"] = 0,
	["RemovedActorRecords"] = 0
}
local v_u_11 = os.clock()
local v_u_12 = 0
local v_u_13 = 0
local v_u_14 = 0
local v_u_15 = 0
local v_u_16 = 0
local v_u_17 = 0
local v_u_18 = nil
local v_u_19 = 0
local function v_u_27(p20) -- name: updateNetworkDiagnostics
	-- upvalues: (ref) v_u_11, (ref) v_u_9, (ref) v_u_10, (copy) v_u_4, (copy) v_u_3, (ref) v_u_12
	local v21 = p20 - v_u_11
	if v21 >= 1 then
		v_u_9.DurationSeconds = v21
		v_u_10 = v_u_9
		v_u_9 = {
			["DurationSeconds"] = 0,
			["RemoteRxBytes"] = 0,
			["OwnerRxBytes"] = 0,
			["CommandTxBytes"] = 0,
			["RemotePackets"] = 0,
			["OwnerPackets"] = 0,
			["CommandPackets"] = 0,
			["RecoveryPackets"] = 0,
			["FullActorRecords"] = 0,
			["DeltaActorRecords"] = 0,
			["RemovedActorRecords"] = 0
		}
		v_u_11 = p20
	end
	local v22 = v_u_10
	local v23 = v22.DurationSeconds
	local v24 = math.max(v23, 1)
	local v25 = v22.FullActorRecords + v22.DeltaActorRecords + v22.RemovedActorRecords
	local v26 = v25 <= 0 and 0 or v22.RemoteRxBytes / v25
	if v_u_4.shouldOutputForPlayer(v_u_3) and (p20 - v_u_12 >= 5 and v22.RemotePackets + v22.OwnerPackets + v22.CommandPackets > 0) then
		v_u_12 = p20
		print(string.format("[MovementV2.Network] player=%s remoteRxKiBps=%.3f ownerRxKiBps=%.3f commandTxKiBps=%.3f packets=%d/%d/%d recovery=%d remoteRecords=%d/%d/%d wireBytesPerRecord=%.2f", v_u_3.Name, v22.RemoteRxBytes / v24 / 1024, v22.OwnerRxBytes / v24 / 1024, v22.CommandTxBytes / v24 / 1024, v22.RemotePackets, v22.OwnerPackets, v22.CommandPackets, v22.RecoveryPackets, v22.FullActorRecords, v22.DeltaActorRecords, v22.RemovedActorRecords, v26))
	end
end
function v6.ObserveOwnerSnapshot(p28, _, p29) -- name: ObserveOwnerSnapshot
	-- upvalues: (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (ref) v_u_19, (copy) v_u_27
	if v_u_8 ~= p28 then
		v_u_8 = p28
		v_u_9 = {
			["DurationSeconds"] = 0,
			["RemoteRxBytes"] = 0,
			["OwnerRxBytes"] = 0,
			["CommandTxBytes"] = 0,
			["RemotePackets"] = 0,
			["OwnerPackets"] = 0,
			["CommandPackets"] = 0,
			["RecoveryPackets"] = 0,
			["FullActorRecords"] = 0,
			["DeltaActorRecords"] = 0,
			["RemovedActorRecords"] = 0
		}
		v_u_10 = {
			["DurationSeconds"] = 0,
			["RemoteRxBytes"] = 0,
			["OwnerRxBytes"] = 0,
			["CommandTxBytes"] = 0,
			["RemotePackets"] = 0,
			["OwnerPackets"] = 0,
			["CommandPackets"] = 0,
			["RecoveryPackets"] = 0,
			["FullActorRecords"] = 0,
			["DeltaActorRecords"] = 0,
			["RemovedActorRecords"] = 0
		}
		v_u_11 = os.clock()
		v_u_12 = 0
		v_u_13 = 0
		v_u_14 = 0
		v_u_15 = 0
		v_u_16 = 0
		v_u_17 = 0
		v_u_18 = nil
		v_u_19 = 0
	end
	if p29 ~= nil then
		local v30 = p29.Bytes
		if typeof(v30) == "number" then
			local v31 = v_u_9
			local v32 = v31.OwnerRxBytes
			local v33 = p29.Bytes
			v31.OwnerRxBytes = v32 + math.max(0, v33)
			local v34 = v_u_9
			v34.OwnerPackets = v34.OwnerPackets + 1
		end
	end
	v_u_27(os.clock())
end
function v6.ObserveRemoteSnapshot(p35, _, p36) -- name: ObserveRemoteSnapshot
	-- upvalues: (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (ref) v_u_19, (copy) v_u_27
	if v_u_8 ~= p35 then
		v_u_8 = p35
		v_u_9 = {
			["DurationSeconds"] = 0,
			["RemoteRxBytes"] = 0,
			["OwnerRxBytes"] = 0,
			["CommandTxBytes"] = 0,
			["RemotePackets"] = 0,
			["OwnerPackets"] = 0,
			["CommandPackets"] = 0,
			["RecoveryPackets"] = 0,
			["FullActorRecords"] = 0,
			["DeltaActorRecords"] = 0,
			["RemovedActorRecords"] = 0
		}
		v_u_10 = {
			["DurationSeconds"] = 0,
			["RemoteRxBytes"] = 0,
			["OwnerRxBytes"] = 0,
			["CommandTxBytes"] = 0,
			["RemotePackets"] = 0,
			["OwnerPackets"] = 0,
			["CommandPackets"] = 0,
			["RecoveryPackets"] = 0,
			["FullActorRecords"] = 0,
			["DeltaActorRecords"] = 0,
			["RemovedActorRecords"] = 0
		}
		v_u_11 = os.clock()
		v_u_12 = 0
		v_u_13 = 0
		v_u_14 = 0
		v_u_15 = 0
		v_u_16 = 0
		v_u_17 = 0
		v_u_18 = nil
		v_u_19 = 0
	end
	if p36 ~= nil then
		local v37 = p36.Bytes
		if typeof(v37) == "number" then
			local v38 = v_u_9
			local v39 = v38.RemoteRxBytes
			local v40 = p36.Bytes
			v38.RemoteRxBytes = v39 + math.max(0, v40)
			local v41 = v_u_9
			v41.RemotePackets = v41.RemotePackets + 1
			local v42 = v_u_9
			v42.FullActorRecords = v42.FullActorRecords + (p36.FullActorCount or 0)
			local v43 = v_u_9
			v43.DeltaActorRecords = v43.DeltaActorRecords + (p36.DeltaActorCount or 0)
			local v44 = v_u_9
			v44.RemovedActorRecords = v44.RemovedActorRecords + (p36.RemovedActorCount or 0)
		end
	end
	v_u_27(os.clock())
end
function v6.ObserveCommandPacket(p45, p46, p47) -- name: ObserveCommandPacket
	-- upvalues: (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (ref) v_u_19, (copy) v_u_27
	if v_u_8 ~= p45 then
		v_u_8 = p45
		v_u_9 = {
			["DurationSeconds"] = 0,
			["RemoteRxBytes"] = 0,
			["OwnerRxBytes"] = 0,
			["CommandTxBytes"] = 0,
			["RemotePackets"] = 0,
			["OwnerPackets"] = 0,
			["CommandPackets"] = 0,
			["RecoveryPackets"] = 0,
			["FullActorRecords"] = 0,
			["DeltaActorRecords"] = 0,
			["RemovedActorRecords"] = 0
		}
		v_u_10 = {
			["DurationSeconds"] = 0,
			["RemoteRxBytes"] = 0,
			["OwnerRxBytes"] = 0,
			["CommandTxBytes"] = 0,
			["RemotePackets"] = 0,
			["OwnerPackets"] = 0,
			["CommandPackets"] = 0,
			["RecoveryPackets"] = 0,
			["FullActorRecords"] = 0,
			["DeltaActorRecords"] = 0,
			["RemovedActorRecords"] = 0
		}
		v_u_11 = os.clock()
		v_u_12 = 0
		v_u_13 = 0
		v_u_14 = 0
		v_u_15 = 0
		v_u_16 = 0
		v_u_17 = 0
		v_u_18 = nil
		v_u_19 = 0
	end
	local v48 = v_u_9
	v48.CommandTxBytes = v48.CommandTxBytes + math.max(0, p46)
	local v49 = v_u_9
	v49.CommandPackets = v49.CommandPackets + 1
	if p47 then
		local v50 = v_u_9
		v50.RecoveryPackets = v50.RecoveryPackets + 1
	end
	v_u_27(os.clock())
end
function v6.ObserveReconciliation(p51, p52) -- name: ObserveReconciliation
	-- upvalues: (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (ref) v_u_19, (copy) v_u_5, (copy) v_u_4, (copy) v_u_3
	local v53 = p52.Mapping
	if v53 ~= nil then
		local v54 = v53.Generation
		if v_u_8 ~= v54 then
			v_u_8 = v54
			v_u_9 = {
				["DurationSeconds"] = 0,
				["RemoteRxBytes"] = 0,
				["OwnerRxBytes"] = 0,
				["CommandTxBytes"] = 0,
				["RemotePackets"] = 0,
				["OwnerPackets"] = 0,
				["CommandPackets"] = 0,
				["RecoveryPackets"] = 0,
				["FullActorRecords"] = 0,
				["DeltaActorRecords"] = 0,
				["RemovedActorRecords"] = 0
			}
			v_u_10 = {
				["DurationSeconds"] = 0,
				["RemoteRxBytes"] = 0,
				["OwnerRxBytes"] = 0,
				["CommandTxBytes"] = 0,
				["RemotePackets"] = 0,
				["OwnerPackets"] = 0,
				["CommandPackets"] = 0,
				["RecoveryPackets"] = 0,
				["FullActorRecords"] = 0,
				["DeltaActorRecords"] = 0,
				["RemovedActorRecords"] = 0
			}
			v_u_11 = os.clock()
			v_u_12 = 0
			v_u_13 = 0
			v_u_14 = 0
			v_u_15 = 0
			v_u_16 = 0
			v_u_17 = 0
			v_u_18 = nil
			v_u_19 = 0
		end
	end
	local v55 = p51.ReconciliationMode ~= "Reuse"
	local v56
	if v55 then
		if p51.ComparedAtAck == true then
			v56 = (p51.Position >= 0.01 or (p51.Velocity >= 0.1 or (p51.SupportAnchor >= 0.01 or (p51.SupportVelocity >= 0.1 or p51.SupportKindMismatch > 0)))) and true or p51.SupportSourceMismatch > 0
		else
			v56 = false
		end
	else
		v56 = v55
	end
	if v55 then
		if p51.ComparedAtAck == true then
			v55 = v56 or ((p51.LookYaw >= 0.004363323129985824 or (p51.VerticalLook >= 0.004363323129985824 or p51.DuckAmount >= 0.01)) and true or p51.Stamina >= 0.01)
		else
			v55 = false
		end
	end
	local v57
	if p51.TailCompared == true then
		v57 = (p51.TailPosition >= 0.01 or (p51.TailVelocity >= 0.1 or (p51.TailSupportAnchor >= 0.01 or (p51.TailSupportVelocity >= 0.1 or (p51.TailSupportKindMismatch > 0 or (p51.TailSupportSourceMismatch > 0 or p51.TailGroundMismatch == true)))))) and true or p51.TailStanceMismatch == true
	else
		v57 = false
	end
	local v58 = v55 or v57
	if v58 then
		v_u_13 = v_u_13 + 1
	end
	local v59
	if p51.TailCompared == true then
		v59 = v_u_5.isHardSnapCorrection(p51)
	else
		v59 = false
	end
	if v59 then
		v_u_15 = v_u_15 + 1
	end
	local v60 = p51.CanonicalStateMismatchMask or 0
	local v61 = bit32.band(v60, 4071648) ~= 0
	local v62 = (p51.ReplayBarrier == "AcceptedWorldChange" or p51.ReplayBarrier == "MoverRevision") and true or p51.ReplayBarrier == "DestructibleRevision"
	local v63 = p51.SynthesizedInput == true and true or (p51.ServerHeldTickCount or 0) > 0
	local v64 = p51.PlayerContactCorrection == true
	local v65 = v55 and not v63 and not v64 or (v57 and not (v62 or v63) and not v64 or (v61 or (p51.SupportKindMismatch > 0 and true or p51.SupportSourceMismatch > 0)))
	if v65 then
		v_u_14 = v_u_14 + 1
	end
	if v_u_4.shouldOutputForPlayer(v_u_3) and (v58 or (v65 or v59)) then
		local v66 = warn
		local v67 = string.format
		local v68 = "[MovementV2.LocalCounter] player=%s correction=%s desync=%s snap=%s totals=%d/%d/%d generation=%s tick=%s mode=%s barrier=%s replay=%d held=%d synth=%s contact=%s mismatch=0x%X ackPos=%.8f ackVel=%.8f tailPos=%.8f tailVel=%.8f tailTickDelta=%d tailGround=%s tailStance=%s supportMismatch=%d/%d tailSupportMismatch=%d/%d"
		local v69 = v_u_3.Name
		local v70 = tostring(v58)
		local v71 = tostring(v65)
		local v72 = tostring(v59)
		local v73 = v_u_13
		local v74 = v_u_14
		local v75 = v_u_15
		local v76
		if v53 == nil then
			v76 = "nil"
		else
			local v77 = v53.Generation
			v76 = tostring(v77)
		end
		local v78 = p52.ServerTick
		local v79 = tostring(v78)
		local v80 = p51.ReconciliationMode
		local v81 = tostring(v80)
		local v82 = p51.ReplayBarrier
		local v83 = tostring(v82)
		local v84 = p51.ReplayCount or 0
		local v85 = p51.ServerHeldTickCount or 0
		local v86 = p51.SynthesizedInput == true
		local v87 = tostring(v86)
		local v88 = p51.PlayerContactCorrection == true
		local v89 = tostring(v88)
		local v90 = p51.CanonicalStateMismatchMask or 0
		local v91 = p51.Position or 0
		local v92 = p51.Velocity or 0
		local v93 = p51.TailPosition or 0
		local v94 = p51.TailVelocity or 0
		local v95 = p51.TailServerTickDelta or 0
		local v96 = p51.TailGroundMismatch == true
		local v97 = tostring(v96)
		local v98 = p51.TailStanceMismatch == true
		v66(v67(v68, v69, v70, v71, v72, v73, v74, v75, v76, v79, v81, v83, v84, v85, v87, v89, v90, v91, v92, v93, v94, v95, v97, tostring(v98), p51.SupportKindMismatch or 0, p51.SupportSourceMismatch or 0, p51.TailSupportKindMismatch or 0, p51.TailSupportSourceMismatch or 0))
	end
end
function v6.ObservePresentation(p99) -- name: ObservePresentation
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (ref) v_u_18, (ref) v_u_17, (ref) v_u_19
	if v_u_4.shouldOutputForPlayer(v_u_3) then
		local v100 = p99.LocalPlayerContactCritical == true
		local v101 = v_u_18
		v_u_18 = v100
		if v101 ~= nil and v101 ~= v100 then
			v_u_17 = v_u_17 + 1
			local v102 = os.clock()
			if v102 - v_u_19 >= 0.25 then
				v_u_19 = v102
				local v103 = print
				local v104 = string.format
				local v105 = "[MovementV2.Client] PRESENTATION collisionRoot=%s tick=%s fraction=%.4f status=%s reason=%s modeSwitches=%d"
				local v106 = v100 and "exact" or "interpolated"
				local v107
				if p99.ServerTick == nil then
					v107 = "nil"
				else
					local v108 = p99.ServerTick
					v107 = tostring(v108)
				end
				local v109 = p99.TickFraction or 0
				local v110 = p99.Status
				local v111 = tostring(v110)
				local v112 = p99.Reason
				v103(v104(v105, v106, v107, v109, v111, tostring(v112), v_u_17))
			end
		end
	else
		return
	end
end
function v6.ObservePredictionHitch(p113) -- name: ObservePredictionHitch
	-- upvalues: (ref) v_u_16, (copy) v_u_4, (copy) v_u_3
	v_u_16 = v_u_16 + 1
	if v_u_4.shouldOutputForPlayer(v_u_3) then
		local v114 = warn
		local v115 = string.format
		local v116 = v_u_3.Name
		local v117 = v_u_16
		local v118 = p113.ServerTick
		local v119 = tostring(v118)
		local v120 = (p113.FrameSeconds or 0) * 1000
		local v121 = (p113.DiscardedSeconds or 0) * 1000
		local v122 = (p113.BacklogBeforeSeconds or 0) * 1000
		local v123 = (p113.BacklogAfterSeconds or 0) * 1000
		local v124 = p113.StepsDrained or 0
		local v125 = p113.GuaranteedStepBudget or 0
		local v126 = p113.StepBudget or 0
		local v127 = (p113.PredictionWorkSeconds or 0) * 1000
		local v128 = (p113.OwnerSnapshotAgeSeconds or 0) * 1000
		local v129 = p113.Status
		v114(v115("[MovementV2.LocalCounter] player=%s hitch=true total=%d tick=%s frameMs=%.3f discardedMs=%.3f backlogBeforeMs=%.3f backlogAfterMs=%.3f drained=%d guaranteed=%d hardCap=%d predictionWorkMs=%.3f ownerAgeMs=%.3f status=%s", v116, v117, v119, v120, v121, v122, v123, v124, v125, v126, v127, v128, (tostring(v129))))
	end
end
function v6.Initialize() -- name: Initialize
	-- upvalues: (ref) v_u_7, (copy) v_u_3
	if not v_u_7 then
		v_u_7 = true
		local v130 = v_u_3:FindFirstChildOfClass("PlayerGui")
		local v131
		if v130 == nil then
			v131 = nil
		else
			v131 = v130:FindFirstChild("TemporaryNetStats", true)
		end
		if v131 ~= nil then
			v131:Destroy()
		end
	end
end
return v6
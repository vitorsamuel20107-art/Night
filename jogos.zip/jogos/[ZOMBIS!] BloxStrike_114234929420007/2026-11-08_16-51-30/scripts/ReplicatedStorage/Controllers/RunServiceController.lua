-- NIGHT Analyzer | ReplicatedStorage.Controllers.RunServiceController
-- ModuleScript | 296 linhas | 8205 bytes | hash ba8730fa

local v_u_1 = {}
local v_u_2 = game:GetService("RunService")
local v_u_3 = require(game:GetService("ReplicatedStorage").Shared.Profiler)
local v_u_4 = {}
local v_u_5 = 0
local v_u_6 = 0
local function v8(p7) -- name: newScheduler
	return {
		["EventName"] = nil,
		["ProfileLabel"] = nil,
		["Bindings"] = nil,
		["BindingsByName"] = nil,
		["StepBindings"] = nil,
		["RenderPriorityBindings"] = nil,
		["Connection"] = nil,
		["RenderStepNames"] = nil,
		["NeedsCompact"] = false,
		["NeedsSort"] = false,
		["Stepping"] = false,
		["EventName"] = p7,
		["ProfileLabel"] = ("RunServiceController.%*"):format(p7),
		["Bindings"] = {},
		["BindingsByName"] = {},
		["StepBindings"] = {},
		["RenderPriorityBindings"] = {},
		["RenderStepNames"] = {}
	}
end
local v_u_9 = {
	["Heartbeat"] = v8("Heartbeat"),
	["RenderStepped"] = v8("RenderStepped"),
	["Stepped"] = v8("Stepped"),
	["PostSimulation"] = v8("PostSimulation")
}
local function v_u_11(p10) -- name: getTraceback
	return debug.traceback(tostring(p10), 2)
end
local function v_u_17(p12, p13) -- name: getBindingProfileLabel
	local v14 = table.create(8)
	for _, v15 in ipairs(string.split(p13, ".")) do
		local v16
		if tonumber(v15) == nil and string.find(v15, "-", 1, true) == nil then
			if #v15 >= 8 then
				v16 = string.find(v15, "%d") ~= nil
			else
				v16 = false
			end
		else
			v16 = true
		end
		table.insert(v14, v16 and "#" or v15)
	end
	return ("RunService.%*.%*"):format(p12, (table.concat(v14, ".")))
end
local function v_u_22(p18) -- name: syncSchedulerConnections
	-- upvalues: (copy) v_u_2
	if #p18.StepBindings == 0 and p18.Connection then
		p18.Connection:Disconnect()
		p18.Connection = nil
	end
	for v19, v20 in pairs(p18.RenderStepNames) do
		local v21 = p18.RenderPriorityBindings[v19]
		if v21 and #v21 ~= 0 then
			continue
		end
		v_u_2:UnbindFromRenderStep(v20)
		p18.RenderStepNames[v19] = nil
	end
end
local function v_u_33(p23) -- name: rebuildScheduler
	-- upvalues: (copy) v_u_22
	local v24 = 1
	for v25 = 1, #p23.Bindings do
		local v26 = p23.Bindings[v25]
		if not v26.Connected then
			continue
		end
		p23.Bindings[v24] = v26
		v24 = v24 + 1
	end
	for v27 = v24, #p23.Bindings do
		p23.Bindings[v27] = nil
	end
	table.sort(p23.Bindings, function(p28, p29)
		if p28.Priority == p29.Priority then
			return p28.Sequence < p29.Sequence
		else
			return p28.Priority < p29.Priority
		end
	end)
	table.clear(p23.StepBindings)
	table.clear(p23.RenderPriorityBindings)
	for _, v30 in ipairs(p23.Bindings) do
		if v30.UsesRenderPriority then
			local v31 = p23.RenderPriorityBindings[v30.Priority]
			if not v31 then
				v31 = {}
				p23.RenderPriorityBindings[v30.Priority] = v31
			end
			table.insert(v31, v30)
		else
			local v32 = p23.StepBindings
			table.insert(v32, v30)
		end
	end
	p23.NeedsCompact = false
	p23.NeedsSort = false
	v_u_22(p23)
end
local v_u_34 = 0
local function v_u_41(p35, ...) -- name: invokeBinding
	-- upvalues: (ref) v_u_34, (copy) v_u_11
	debug.profilebegin(p35.ProfileLabel)
	local v36 = v_u_34
	local v37 = p35.Callback
	local v38 = v_u_11
	local v39, v40 = xpcall(v37, v38, ...)
	if v36 == v_u_34 then
		debug.profileend()
	end
	if not v39 then
		warn((("[RunServiceController] %* binding \"%*\" failed:\n%*"):format(p35.EventName, p35.Name, v40)))
	end
end
local function v_u_47(p42, p43, ...) -- name: stepScheduler
	-- upvalues: (ref) v_u_34, (copy) v_u_3, (copy) v_u_33, (copy) v_u_4, (copy) v_u_41
	v_u_34 = v_u_34 + 1
	v_u_3.mark(p42.ProfileLabel)
	if p42.NeedsCompact or p42.NeedsSort then
		v_u_33(p42)
	end
	p42.Stepping = true
	local v44
	if p43 == nil then
		v44 = p42.StepBindings
	else
		v44 = p42.RenderPriorityBindings[p43] or v_u_4
	end
	for v45 = 1, #v44 do
		local v46 = v44[v45]
		if not (v46 and v46.Connected) then
			continue
		end
		v_u_41(v46, ...)
	end
	p42.Stepping = false
	if p42.NeedsCompact or p42.NeedsSort then
		v_u_33(p42)
	end
end
local function v_u_53(p_u_48, p_u_49, p50) -- name: ensureSchedulerConnection
	-- upvalues: (copy) v_u_2, (copy) v_u_47
	if p50 then
		if not p_u_48.RenderStepNames[p_u_49] then
			local v51 = ("RunServiceController.RenderStepped.%*"):format(p_u_49)
			p_u_48.RenderStepNames[p_u_49] = v51
			v_u_2:BindToRenderStep(v51, p_u_49, function(p52)
				-- upvalues: (ref) v_u_47, (copy) p_u_48, (copy) p_u_49
				v_u_47(p_u_48, p_u_49, p52)
			end)
		end
	else
		if not (p_u_48.Connection and p_u_48.Connection.Connected) then
			p_u_48.Connection = v_u_2[p_u_48.EventName]:Connect(function(...)
				-- upvalues: (ref) v_u_47, (copy) p_u_48
				v_u_47(p_u_48, nil, ...)
			end)
		end
		return
	end
end
local function v_u_68(p54, p55, p56, p57, p58) -- name: createBinding
	-- upvalues: (copy) v_u_9, (copy) v_u_33, (ref) v_u_5, (copy) v_u_17, (copy) v_u_53
	local v59
	if type(p55) == "string" then
		v59 = p55 ~= ""
	else
		v59 = false
	end
	assert(v59, "RunServiceController binding name must be a non-empty string")
	local v60 = type(p56) == "number"
	assert(v60, "RunServiceController binding priority must be a number")
	local v61 = type(p57) == "function"
	assert(v61, "RunServiceController callback must be a function")
	local v_u_62 = v_u_9[p54]
	local v63 = v_u_62.BindingsByName[p55]
	if v63 and v63.Connected then
		v63.Connected = false
		if v_u_62.BindingsByName[v63.Name] == v63 then
			v_u_62.BindingsByName[v63.Name] = nil
		end
		v_u_62.NeedsCompact = true
		if not v_u_62.Stepping then
			v_u_33(v_u_62)
		end
	end
	v_u_5 = v_u_5 + 1
	local v_u_66 = {
		["Name"] = nil,
		["EventName"] = nil,
		["Priority"] = nil,
		["Connected"] = true,
		["Callback"] = nil,
		["ProfileLabel"] = nil,
		["Sequence"] = nil,
		["UsesRenderPriority"] = nil,
		["Name"] = p55,
		["EventName"] = p54,
		["Priority"] = p56,
		["Callback"] = p57,
		["ProfileLabel"] = v_u_17(p54, p55),
		["Sequence"] = v_u_5,
		["UsesRenderPriority"] = p58,
		["Disconnect"] = function(_) -- name: Disconnect
			-- upvalues: (copy) v_u_62, (copy) v_u_66, (ref) v_u_33
			local v64 = v_u_62
			local v65 = v_u_66
			if v65.Connected then
				v65.Connected = false
				if v64.BindingsByName[v65.Name] == v65 then
					v64.BindingsByName[v65.Name] = nil
				end
				v64.NeedsCompact = true
				if not v64.Stepping then
					v_u_33(v64)
				end
			end
		end
	}
	v_u_66.Destroy = v_u_66.Disconnect
	local v67 = v_u_62.Bindings
	table.insert(v67, v_u_66)
	v_u_62.BindingsByName[p55] = v_u_66
	v_u_62.NeedsSort = true
	v_u_53(v_u_62, p56, p58)
	return v_u_66
end
function v_u_1.CreateBindingName(p69) -- name: CreateBindingName
	-- upvalues: (ref) v_u_6
	local v70
	if type(p69) == "string" then
		v70 = p69 ~= ""
	else
		v70 = false
	end
	assert(v70, "RunServiceController binding prefix must be a non-empty string")
	v_u_6 = v_u_6 + 1
	return ("%*.%*"):format(p69, v_u_6)
end
function v_u_1.BindToHeartbeat(p71, p72, p73) -- name: BindToHeartbeat
	-- upvalues: (copy) v_u_68
	return v_u_68("Heartbeat", p71, p73 or 0, p72, false)
end
function v_u_1.BindToRenderStep(p74, p75, p76) -- name: BindToRenderStep
	-- upvalues: (copy) v_u_68
	if p76 == nil then
		return v_u_68("RenderStepped", p74, 0, p75, false)
	else
		return v_u_68("RenderStepped", p74, p75, p76, true)
	end
end
function v_u_1.BindToRenderSteppedEvent(p77, p78, p79) -- name: BindToRenderSteppedEvent
	-- upvalues: (copy) v_u_68
	return v_u_68("RenderStepped", p77, p79 or 0, p78, false)
end
function v_u_1.BindToStepped(p80, p81, p82) -- name: BindToStepped
	-- upvalues: (copy) v_u_68
	return v_u_68("Stepped", p80, p82 or 0, p81, false)
end
function v_u_1.BindToPostSimulation(p83, p84, p85) -- name: BindToPostSimulation
	-- upvalues: (copy) v_u_68
	return v_u_68("PostSimulation", p83, p85 or 0, p84, false)
end
function v_u_1.Unbind(p86, p87) -- name: Unbind
	-- upvalues: (copy) v_u_9, (copy) v_u_33
	local v88 = v_u_9[p86].BindingsByName[p87]
	if v88 then
		local v89 = v_u_9[p86]
		if not v88.Connected then
			return
		end
		v88.Connected = false
		if v89.BindingsByName[v88.Name] == v88 then
			v89.BindingsByName[v88.Name] = nil
		end
		v89.NeedsCompact = true
		if not v89.Stepping then
			v_u_33(v89)
		end
	end
end
function v_u_1.UnbindFromRenderStep(p90) -- name: UnbindFromRenderStep
	-- upvalues: (copy) v_u_1
	v_u_1.Unbind("RenderStepped", p90)
end
return v_u_1
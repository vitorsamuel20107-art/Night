-- NIGHT Analyzer | ReplicatedStorage.Controllers.HordeController
-- ModuleScript | 791 linhas | 21038 bytes | hash cf029a1f

local v1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v4 = game:GetService("Players")
local v_u_5 = require(v_u_2.Controllers.RunServiceController)
local v_u_6 = require(v_u_2.Components.Common.HordeProtocol)
local v_u_7 = require(v_u_2.Components.Common.IsSurvivalMode)
local v8 = require(v_u_2.Packages.Signal)
local v_u_9 = require(script.DamageNumbers)
local v_u_10 = require(script.HealthBars)
local v_u_11 = require(script.RigShell)
local v_u_12 = require(v_u_2.Database.Security.Remotes)
local v_u_13 = v_u_6.BYTES_PER_ZOMBIE
local v_u_14 = v_u_6.HEADER_BYTES
local v_u_15 = v_u_6.STATE_DEAD
local v_u_16 = v_u_6.STATE_AIRBORNE
local v_u_17 = v_u_6.HEALTH_STEPS
local v_u_18 = v_u_6.LINK_GRAVITY
local v_u_19 = v8.new()
v1.HitConfirmed = v_u_19
local v_u_20 = v4.LocalPlayer
local v_u_21 = {}
local v_u_22 = {}
local v_u_23 = {}
local v_u_24 = 0
local v_u_25 = nil
local v_u_26 = nil
local v_u_27 = {}
local v_u_28 = {}
local v_u_29 = nil
local v_u_30 = {}
local v_u_31 = {}
local v_u_32 = nil
local function v_u_40(p33, p34, p35, p36) -- name: createEntry
	-- upvalues: (copy) v_u_23, (ref) v_u_24, (copy) v_u_11, (ref) v_u_26, (copy) v_u_3, (copy) v_u_6, (copy) v_u_17, (copy) v_u_21, (ref) v_u_29, (copy) v_u_5, (ref) v_u_32
	if v_u_23[p33] then
		v_u_23[p33] = nil
		v_u_24 = v_u_24 - 1
	end
	local v37 = {
		["Shell"] = nil,
		["HealthSteps"] = nil,
		["Samples"] = nil,
		["DiedAt"] = nil,
		["Hidden"] = false,
		["StepDistance"] = 0,
		["LastRenderPosition"] = nil,
		["LastFootstepAt"] = (-1 / 0),
		["WasAirborne"] = false,
		["LastRootFrame"] = nil,
		["NextMoveAt"] = 0,
		["Paced"] = false,
		["DisplayYaw"] = nil,
		["YawEasedAt"] = 0,
		["YawKnown"] = false
	}
	local v38 = v_u_11.Acquire
	local v39 = v_u_26
	if not (v39 and v39.Parent) then
		v39 = v_u_3:FindFirstChild(v_u_6.SHELL_FOLDER)
		if v39 then
			v_u_26 = v39
		else
			v39 = Instance.new("Folder")
			v39.Name = v_u_6.SHELL_FOLDER
			v39.Parent = v_u_3
			v_u_26 = v39
		end
	end
	v37.Shell = v38(p33, p34, p35, v39)
	v37.HealthSteps = v_u_17
	v37.Samples = {
		{
			["Time"] = nil,
			["Position"] = nil,
			["Yaw"] = 0,
			["Airborne"] = false,
			["Time"] = p36,
			["Position"] = p35
		}
	}
	v_u_21[p33] = v37
	if not v_u_29 then
		v_u_29 = v_u_5.BindToRenderSteppedEvent("HordeController.Render", v_u_32)
	end
	return v37
end
local function v_u_47(p41, p42, p43) -- name: retireCorpse
	-- upvalues: (copy) v_u_21, (copy) v_u_10, (copy) v_u_11, (copy) v_u_22
	v_u_21[p41] = nil
	v_u_10.Remove(p41)
	v_u_11.Retire(p42.Shell)
	v_u_22[#v_u_22 + 1] = {
		["Shell"] = nil,
		["SinkAt"] = nil,
		["SinkStartedAt"] = nil,
		["NextSinkMoveAt"] = 0,
		["Shell"] = p42.Shell,
		["SinkAt"] = p43 + 3
	}
	local v44 = 0
	for v45 = #v_u_22, 1, -1 do
		local v46 = v_u_22[v45]
		if v46.SinkStartedAt then
			continue
		end
		v44 = v44 + 1
		if v44 <= 12 then
			continue
		end
		v46.SinkAt = p43
	end
end
local function v_u_56(p48) -- name: updateCorpses
	-- upvalues: (copy) v_u_31, (copy) v_u_11, (copy) v_u_22, (copy) v_u_27, (copy) v_u_28
	local v49 = 1
	local v50 = table.remove(v_u_31)
	if v50 then
		v49 = v49 - 1
		debug.profilebegin("Horde.Recycle")
		v_u_11.Recycle(v50)
		debug.profileend()
	end
	for v51 = #v_u_22, 1, -1 do
		local v52 = v_u_22[v51]
		local v53 = v52.Shell
		local v54 = v52.SinkStartedAt
		if v53.Model.Parent then
			if v54 then
				local v55 = (p48 - v54) / 2.5
				if v55 >= 1 then
					if v_u_11.Bury(v53, p48) then
						table.remove(v_u_22, v51)
					else
						if v49 <= 0 then
							continue
						end
						v49 = v49 - 1
						table.remove(v_u_22, v51)
						debug.profilebegin("Horde.Recycle")
						v_u_11.Recycle(v53)
						debug.profileend()
					end
				else
					if v52.NextSinkMoveAt > p48 then
						continue
					end
					v52.NextSinkMoveAt = p48 + 0.06666666666666667
					v_u_11.AppendSink(v53, 4 * v55 * v55 * (3 - 2 * v55), v_u_27, v_u_28)
				end
			else
				if v52.SinkAt > p48 then
					continue
				end
				v52.SinkStartedAt = p48
				debug.profilebegin("Horde.BeginSink")
				v_u_11.BeginSink(v53)
				debug.profileend()
			end
		else
			table.remove(v_u_22, v51)
			v_u_11.Recycle(v53)
		end
	end
	if v49 > 0 then
		debug.profilebegin("Horde.EvictBuried")
		v_u_11.EvictBuried(p48)
		debug.profileend()
	end
end
local function v_u_64(p57, p58, p59, p60, p61) -- name: pushSample
	local v62 = p57[#p57]
	if v62 and p58 <= v62.Time then
		return
	elseif #p57 >= 6 then
		local v63 = table.remove(p57, 1)
		v63.Time = p58
		v63.Position = p59
		v63.Yaw = p60
		v63.Airborne = p61
		p57[#p57 + 1] = v63
	else
		p57[#p57 + 1] = {
			["Time"] = p58,
			["Position"] = p59,
			["Yaw"] = p60,
			["Airborne"] = p61
		}
	end
end
local function v_u_68(p65) -- name: shiftSamples
	-- upvalues: (copy) v_u_21
	for _, v66 in v_u_21 do
		for _, v67 in v66.Samples do
			v67.Time = v67.Time + p65
		end
	end
end
local function v_u_92(p69) -- name: onStream
	-- upvalues: (copy) v_u_14, (copy) v_u_6, (copy) v_u_13, (ref) v_u_25, (copy) v_u_68, (copy) v_u_21, (copy) v_u_23, (copy) v_u_15, (copy) v_u_40, (copy) v_u_64, (copy) v_u_16, (copy) v_u_10, (copy) v_u_17
	if typeof(p69) == "buffer" then
		local v70 = buffer.len(p69)
		if v70 < v_u_14 then
			return
		else
			local v71, v72 = v_u_6.readHeader(p69)
			if v70 >= v_u_14 + v71 * v_u_13 then
				local v73 = os.clock()
				local v74 = v73 - v72
				local v75 = v_u_25
				if v75 and (v74 >= v75 and v74 - v75 <= 0.5) then
					v74 = v75 + (v74 - v75) * 0.05
				elseif v75 then
					v_u_68(v74 - v75)
				end
				v_u_25 = v74
				local v76 = v72 + v74
				local v77 = v_u_14
				for _ = 1, v71 do
					local v78, v79, v80, v81, v82, v83, v84 = v_u_6.readRecord(p69, v77)
					v77 = v77 + v_u_13
					local v85 = Vector3.new(v79, v80, v81)
					local v86 = v_u_21[v78]
					if not v86 then
						local v87 = v_u_23[v78]
						if v83 == v_u_15 or v87 and v73 - v87 < 1 then
							continue
						end
						v86 = v_u_40(v78, v_u_6.ARCHETYPE_NORMAL, v85, v76)
					end
					local v88 = v86.Samples
					local v89 = v88[#v88]
					if v89 and (v89.Position - v85).Magnitude > 20 then
						table.clear(v88)
						v86.DisplayYaw = nil
					elseif not v86.YawKnown then
						for _, v90 in v88 do
							v90.Yaw = v82
						end
						v86.DisplayYaw = nil
					end
					v86.YawKnown = true
					v_u_64(v88, v76, v85, v82, v83 == v_u_16)
					local v91 = v86.Shell
					if not v91.Dead then
						v91.State = v83
					end
					if v84 == v86.HealthSteps then
						continue
					end
					v86.HealthSteps = v84
					v_u_10.SetHealth(v78, v84 / v_u_17)
				end
			end
		end
	else
		return
	end
end
local function v_u_96(p93) -- name: onSpawn
	-- upvalues: (copy) v_u_21, (copy) v_u_10, (copy) v_u_11, (copy) v_u_40
	local v94 = p93.Id
	local v95 = v_u_21[v94]
	if v95 then
		v_u_21[v94] = nil
		v_u_10.Remove(v94)
		v_u_11.Recycle(v95.Shell)
	end
	v_u_40(v94, p93.Archetype, p93.Feet, os.clock())
end
local function v_u_100(p97) -- name: onDeath
	-- upvalues: (copy) v_u_21, (copy) v_u_10, (copy) v_u_15, (copy) v_u_30
	local v98 = v_u_21[p97.Id]
	v_u_10.Remove(p97.Id)
	if v98 then
		local v99 = v98.Shell
		v99.Dead = true
		v99.State = v_u_15
		v98.DiedAt = os.clock()
		v_u_30[#v_u_30 + 1] = {
			["Entry"] = v98,
			["Data"] = p97
		}
	end
end
local function v_u_107() -- name: stepDeaths
	-- upvalues: (copy) v_u_30, (copy) v_u_21, (copy) v_u_11
	local v101 = #v_u_30
	for _ = 1, math.min(v101, 1) do
		local v102 = table.remove(v_u_30, 1)
		local v103 = v102.Entry
		local v104 = v102.Data
		local v105 = v103.Shell
		if v_u_21[v104.Id] ~= v103 or v105.Ragdolled then
			continue
		end
		debug.profilebegin("Horde.DeathCry")
		v_u_11.DeathCry(v105)
		debug.profileend()
		debug.profilebegin("Horde.Burst")
		v_u_11.Burst(v105)
		debug.profileend()
		debug.profilebegin("Horde.Ragdoll")
		local v106 = v_u_11.Ragdoll(v105, v104.Headshot, v104.Direction, v104.Position, v104.Part)
		debug.profileend()
		if v106 or not v105.Animator then
			continue
		end
		v105.Animator:stopAnimations(0.1)
	end
end
local function v_u_111(p108) -- name: onRemove
	-- upvalues: (copy) v_u_23, (ref) v_u_24, (copy) v_u_21, (copy) v_u_47, (copy) v_u_10, (copy) v_u_11
	local v109 = os.clock()
	if not v_u_23[p108] then
		v_u_24 = v_u_24 + 1
		if v_u_24 > 120 then
			table.clear(v_u_23)
			v_u_24 = 1
		end
	end
	v_u_23[p108] = v109
	local v110 = v_u_21[p108]
	if v110 then
		if v110.Shell.Ragdolled then
			v_u_47(p108, v110, v109)
			return
		end
		v_u_21[p108] = nil
		v_u_10.Remove(p108)
		v_u_11.Recycle(v110.Shell)
	end
end
local function v_u_126(p112) -- name: clearAll
	-- upvalues: (copy) v_u_30, (copy) v_u_27, (copy) v_u_28, (copy) v_u_21, (copy) v_u_23, (ref) v_u_24, (copy) v_u_47, (copy) v_u_10, (copy) v_u_11, (copy) v_u_31, (copy) v_u_3, (ref) v_u_29, (copy) v_u_5, (ref) v_u_32, (copy) v_u_22, (copy) v_u_9
	local v113 = os.clock()
	table.clear(v_u_30)
	if p112 then
		for v114, v115 in v_u_21 do
			if not v_u_23[v114] then
				v_u_24 = v_u_24 + 1
				if v_u_24 > 120 then
					table.clear(v_u_23)
					v_u_24 = 1
				end
			end
			v_u_23[v114] = v113
			v_u_21[v114] = nil
			v_u_10.Remove(v114)
			if p112 then
				v_u_11.Destroy(v115.Shell)
			else
				v_u_11.Recycle(v115.Shell)
			end
		end
		for _, v116 in v_u_22 do
			v_u_11.Destroy(v116.Shell)
		end
		table.clear(v_u_22)
		for _, v117 in v_u_31 do
			v_u_11.Destroy(v117)
		end
		table.clear(v_u_31)
		v_u_11.ClearPool()
		v_u_10.Clear()
		v_u_9.Clear()
	else
		table.clear(v_u_27)
		table.clear(v_u_28)
		for v118, v119 in v_u_21 do
			if not v_u_23[v118] then
				v_u_24 = v_u_24 + 1
				if v_u_24 > 120 then
					table.clear(v_u_23)
					v_u_24 = 1
				end
			end
			v_u_23[v118] = v113
			local v120 = v119.Shell
			if v120.Ragdolled then
				v_u_47(v118, v119, v113)
			else
				v_u_21[v118] = nil
				v_u_10.Remove(v118)
				v_u_11.Retire(v120)
				if v120.Model.Parent then
					local v121 = #v_u_27 + 1
					local v122 = v_u_27
					local v123 = v_u_28
					local v124 = v120.Root
					local v125 = v120.Root.CFrame - Vector3.new(0, 300, 0)
					v122[v121] = v124
					v123[v121] = v125
				end
				v_u_31[#v_u_31 + 1] = v120
			end
		end
		if #v_u_27 > 0 then
			v_u_3:BulkMoveTo(v_u_27, v_u_28, Enum.BulkMoveMode.FireCFrameChanged)
			table.clear(v_u_27)
			table.clear(v_u_28)
		end
		if not v_u_29 then
			v_u_29 = v_u_5.BindToRenderSteppedEvent("HordeController.Render", v_u_32)
		end
	end
end
local function v_u_133(p127) -- name: onHit
	-- upvalues: (copy) v_u_21, (copy) v_u_11, (copy) v_u_20, (copy) v_u_19, (copy) v_u_9, (copy) v_u_10, (copy) v_u_17
	local v128 = p127.Id
	local v129 = p127.Headshot
	local v130 = p127.Died
	local v131 = p127.Part == "Burn"
	local v132 = v_u_21[v128]
	if v132 and not (v132.Shell.Dead or v131) then
		v_u_11.Flinch(v132.Shell, v129, p127.Direction)
		if not v130 then
			v_u_11.Pain(v132.Shell)
		end
	end
	if v_u_20 and p127.AttackerUserId == v_u_20.UserId then
		if not v131 or v130 then
			v_u_19:Fire(v129, v130)
		end
		if p127.Damage > 0 then
			v_u_9.Show(v128, p127.Position, p127.Damage, v129, v130, v131)
			if v132 and not (v130 or v132.Shell.Dead) then
				v_u_10.Show(v128, v132.Shell.Model, v132.HealthSteps / v_u_17)
			end
		end
	end
end
local function v_u_172(p134, p135) -- name: sampleMotion
	-- upvalues: (copy) v_u_18, (copy) v_u_11
	local v136 = p134.Samples
	local v137 = #v136
	local v138 = v136[v137]
	local _ = v138.Position
	local v139 = v138.Yaw
	local v140 = v138.Airborne
	local v141 = v138.Airborne
	local v142 = Vector3.new(0, 0, 0)
	local v143 = nil
	for v144 = v137 - 1, 1, -1 do
		local v145 = v136[v144]
		v141 = v141 or v145.Airborne
		local v146 = v138.Time - v145.Time
		if v146 < 0.05 then
			continue
		end
		v142 = (v138.Position - v145.Position) / v146
		if v141 then
			if v138.Airborne and v145.Airborne then
				v143 = v142.Y - 0.5 * v_u_18 * v146
			end
			v142 = v142 * Vector3.new(1, 0, 1)
		end
		local v147 = v142.Magnitude
		if v147 > 30 then
			v142 = v142 * (30 / v147)
		end
	end
	local v148 = p135 - v138.Time
	local v149
	if v148 >= 0 then
		local v150 = math.min(v148, 0.1)
		v149 = v138.Position + v142 * v150
		if v143 then
			local v151 = v149.Y + (v143 - 0.5 * v_u_18 * v150) * v150
			if v151 < v149.Y then
				local v152 = v_u_11.FloorHeight(v149, v149.Y - v151)
				if v152 then
					v151 = math.max(v151, v152)
				end
			end
			local v153 = v149.X
			local v154 = v149.Z
			v149 = Vector3.new(v153, v151, v154)
		end
		if v148 > 0.30000000000000004 then
			v142 = Vector3.new(0, 0, 0)
		end
	else
		local v155 = v136[1]
		local v156 = 1
		for v157 = v137, 2, -1 do
			if v136[v157 - 1].Time > p135 then
				continue
			end
			v155 = v136[v157 - 1]
			v138 = v136[v157]
			v156 = v157 - 1
		end
		local v158 = v138.Time - v155.Time
		local v159
		if v158 > 0 then
			local v160 = (p135 - v155.Time) / v158
			v159 = math.clamp(v160, 0, 1)
		else
			v159 = 1
		end
		v149 = v155.Position:Lerp(v138.Position, v159)
		if v155.Airborne then
			local v161 = v159 * v158
			local v162 = v149.Y + 0.5 * v_u_18 * v161 * (v158 - v161)
			local v163 = v136[v156 - 1]
			if not v138.Airborne and (v163 and v163.Airborne) then
				local v164 = v155.Time - v163.Time
				local v165 = (v155.Position.Y - v163.Position.Y) / v164 - 0.5 * v_u_18 * v164
				local v166 = v155.Position.Y + (v165 - 0.5 * v_u_18 * v161) * v161
				local v167 = v138.Position.Y
				local v168 = math.max(v166, v167)
				v162 = math.min(v162, v168)
			end
			local v169 = v149.X
			local v170 = v149.Z
			v149 = Vector3.new(v169, v162, v170)
		end
		local v171 = (v138.Yaw - v155.Yaw + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
		v139 = v155.Yaw + v171 * v159
		v140 = v155.Airborne or v138.Airborne
	end
	return v149, v139, v142, v140
end
v_u_32 = function() -- name: render
	-- upvalues: (copy) v_u_3, (copy) v_u_27, (copy) v_u_28, (copy) v_u_21, (copy) v_u_11, (copy) v_u_172, (ref) v_u_26, (copy) v_u_6, (copy) v_u_56, (copy) v_u_107, (copy) v_u_22, (copy) v_u_31, (ref) v_u_29
	local v173 = os.clock()
	local v174 = v173 - 0.12
	local v175 = v_u_3.CurrentCamera
	local v176 = not v175 and Vector3.new(0, 0, 0) or v175.CFrame.Position
	table.clear(v_u_27)
	table.clear(v_u_28)
	local v177 = 1
	for _, v178 in v_u_21 do
		if #v178.Samples == 0 then
			continue
		end
		local v179 = v178.Shell
		if v178.Paced and (v173 < v178.NextMoveAt and not (v179.Dead or v179.Ragdolled)) then
			v_u_11.Animate(v179, v173, v179.LastVelocity, v178.WasAirborne)
		else
			local v180, v181, v182, v183 = v_u_172(v178, v174)
			local v184 = (v180 - v176).Magnitude
			local v185 = v184 > 260
			if v185 ~= v178.Hidden then
				v178.Hidden = v185
				debug.profilebegin("Horde.HideDistance")
				local v186 = v179.Model
				local v187
				if v185 then
					v187 = nil
				else
					v187 = v_u_26
					if not (v187 and v187.Parent) then
						v187 = v_u_3:FindFirstChild(v_u_6.SHELL_FOLDER)
						if v187 then
							v_u_26 = v187
						else
							v187 = Instance.new("Folder")
							v187.Name = v_u_6.SHELL_FOLDER
							v187.Parent = v_u_3
							v_u_26 = v187
						end
					end
				end
				v186.Parent = v187
				debug.profileend()
			end
			if v185 then
				continue
			end
			local v188 = v184 > 150
			if v188 ~= v179.Frozen then
				v_u_11.SetFrozen(v179, v188)
			end
			if v179.Ragdolled then
				continue
			end
			local v189, v190
			if v179.Dead and v178.DiedAt then
				local v191 = v173 - v178.DiedAt
				local v192 = v191 / 1
				v189 = math.clamp(v192, 0, 1)
				local v193 = (v191 - 1) / 1.2
				v190 = math.clamp(v193, 0, 1) * 4
			else
				v189 = 0
				v190 = 0
			end
			v179.LastVelocity = v182
			local v194 = v178.WasAirborne
			if v194 then
				v194 = not v183
			end
			v178.WasAirborne = v183
			if not (v179.Dead or (v188 or v183)) then
				local v195 = v178.LastRenderPosition
				if v195 and not v194 then
					v178.StepDistance = v178.StepDistance + ((v180 - v195) * Vector3.new(1, 0, 1)).Magnitude
				end
				if v178.StepDistance >= 2.6 or v194 then
					v178.StepDistance = 0
					if v177 > 0 and (v184 <= 70 and v173 - v178.LastFootstepAt >= 0.25) then
						v177 = v177 - 1
						v178.LastFootstepAt = v173
						v_u_11.Footstep(v179, v180, v173)
					end
				end
			end
			v178.LastRenderPosition = v180
			local v196 = v_u_11.RootFrame
			local v197 = v178.DisplayYaw
			local v198 = v173 - v178.YawEasedAt
			v178.YawEasedAt = v173
			if v197 == nil then
				v178.DisplayYaw = v181
			else
				local v199 = (v181 - v197 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
				if math.abs(v199) <= 0.002 then
					v178.DisplayYaw = v181
				else
					local v200 = v198 * -14
					v181 = v197 + v199 * (1 - math.exp(v200))
					v178.DisplayYaw = v181
				end
			end
			local v201 = v196(v180, v181, v189, v190)
			local v202 = v188 or v184 > 60
			v178.Paced = v202
			if v201 ~= v178.LastRootFrame and (not v202 or v178.NextMoveAt <= v173) then
				v178.LastRootFrame = v201
				v178.NextMoveAt = v173 + (v188 and 0.05 or 0.025)
				local v203 = #v_u_27
				local v204 = v_u_27
				local v205 = v203 + 1
				local v206 = v_u_28
				local v207 = v203 + 1
				v204[v205] = v179.Root
				v206[v207] = v201
			end
			v_u_11.Animate(v179, v173, v182, v183)
		end
	end
	v_u_56(v173)
	v_u_107()
	v_u_11.StepEffects()
	if #v_u_27 > 0 then
		v_u_3:BulkMoveTo(v_u_27, v_u_28, Enum.BulkMoveMode.FireCFrameChanged)
	end
	if next(v_u_21) == nil and (#v_u_22 == 0 and (#v_u_31 == 0 and (not v_u_11.HasBuried() and v_u_29))) then
		v_u_29:Disconnect()
		v_u_29 = nil
	end
end
function v1.GetBodyPosition(p208) -- name: GetBodyPosition
	-- upvalues: (copy) v_u_21
	local v209 = v_u_21[p208]
	if v209 then
		local v210 = v209.Shell.Model:FindFirstChild("UpperTorso")
		if v210 and v210:IsA("BasePart") then
			return v210.Position
		else
			return v209.Shell.Root.Position
		end
	else
		return nil
	end
end
function v1.GetLiveShells() -- name: GetLiveShells
	-- upvalues: (copy) v_u_21
	local v211 = {}
	for _, v212 in v_u_21 do
		local v213 = v212.Shell
		if v212.DiedAt or (v213.Dead or v212.Hidden) then
			continue
		end
		v211[#v211 + 1] = v213.Model
	end
	return v211
end
function v1.GetLiveShell(p214) -- name: GetLiveShell
	-- upvalues: (copy) v_u_6, (copy) v_u_21
	local v215 = p214:FindFirstAncestorOfClass("Model")
	while v215 and v215:GetAttribute(v_u_6.ID_ATTRIBUTE) == nil do
		v215 = v215:FindFirstAncestorOfClass("Model")
	end
	if v215 then
		local v216 = v215:GetAttribute(v_u_6.ID_ATTRIBUTE)
		local v217
		if typeof(v216) == "number" then
			v217 = v_u_21[v216]
		else
			v217 = nil
		end
		if v217 and (v217.Shell.Model == v215 and not (v217.DiedAt or (v217.Shell.Dead or v217.Hidden))) then
			return v215
		else
			return nil
		end
	else
		return nil
	end
end
function v1.CountNear(p218, p219, p220) -- name: CountNear
	-- upvalues: (copy) v_u_21
	local v221 = 0
	for _, v222 in v_u_21 do
		if v222.DiedAt or v222.Shell.Dead then
			continue
		end
		local v223 = v222.Samples[#v222.Samples]
		if not v223 then
			continue
		end
		local v224 = v223.Position - p218
		local v225 = v224.Y
		if math.abs(v225) > p220 or Vector2.new(v224.X, v224.Z).Magnitude > p219 then
			continue
		end
		v221 = v221 + 1
	end
	return v221
end
function v1.Start() -- name: Start
	-- upvalues: (copy) v_u_12, (copy) v_u_96, (copy) v_u_100, (copy) v_u_111, (copy) v_u_126, (copy) v_u_133, (copy) v_u_7, (copy) v_u_11, (copy) v_u_3, (copy) v_u_2, (copy) v_u_6, (copy) v_u_92
	local v_u_226 = v_u_96
	local v_u_227 = "Horde.Spawn"
	v_u_12.Horde.Spawn.Listen(function(...)
		-- upvalues: (copy) v_u_227, (copy) v_u_226
		debug.profilebegin(v_u_227)
		v_u_226(...)
		debug.profileend()
	end)
	local v_u_228 = v_u_100
	local v_u_229 = "Horde.Death"
	v_u_12.Horde.Death.Listen(function(...)
		-- upvalues: (copy) v_u_229, (copy) v_u_228
		debug.profilebegin(v_u_229)
		v_u_228(...)
		debug.profileend()
	end)
	local v_u_230 = v_u_111
	local v_u_231 = "Horde.Remove"
	v_u_12.Horde.Remove.Listen(function(...)
		-- upvalues: (copy) v_u_231, (copy) v_u_230
		debug.profilebegin(v_u_231)
		v_u_230(...)
		debug.profileend()
	end)
	v_u_12.Horde.Clear.Listen(function()
		-- upvalues: (ref) v_u_126
		v_u_126()
	end)
	local v_u_232 = v_u_133
	local v_u_233 = "Horde.Hit"
	v_u_12.Horde.Hit.Listen(function(...)
		-- upvalues: (copy) v_u_233, (copy) v_u_232
		debug.profilebegin(v_u_233)
		v_u_232(...)
		debug.profileend()
	end)
	if v_u_7() then
		v_u_11.Refill()
	end
	v_u_3:GetAttributeChangedSignal("Gamemode"):Connect(function()
		-- upvalues: (ref) v_u_7, (ref) v_u_11, (ref) v_u_126
		if v_u_7() then
			v_u_11.Refill()
		else
			v_u_126(true)
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_2, (ref) v_u_6, (ref) v_u_92, (ref) v_u_7, (ref) v_u_12
		local v234 = v_u_2:WaitForChild(v_u_6.STREAM_REMOTE, 60)
		if v234 then
			local v_u_235 = v_u_92
			local v_u_236 = "Horde.Stream"
			v234.OnClientEvent:Connect(function(...)
				-- upvalues: (copy) v_u_236, (copy) v_u_235
				debug.profilebegin(v_u_236)
				v_u_235(...)
				debug.profileend()
			end)
			if v_u_7() then
				v_u_12.Horde.Sync.Send()
			end
		end
	end)
end
return v1
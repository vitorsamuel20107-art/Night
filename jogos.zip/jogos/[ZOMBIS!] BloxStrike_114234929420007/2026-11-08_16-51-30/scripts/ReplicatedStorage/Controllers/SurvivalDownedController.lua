-- NIGHT Analyzer | ReplicatedStorage.Controllers.SurvivalDownedController
-- ModuleScript | 362 linhas | 9776 bytes | hash ed32a3ea

local v1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Lighting")
local v_u_4 = game:GetService("Players")
local v_u_5 = require(v_u_2.Controllers.RunServiceController)
local v_u_6 = require(v_u_2.Controllers.CharacterController)
local v_u_7 = require(v_u_2.Controllers.InventoryController)
local v_u_8 = require(v_u_2.Interface.Screens.Gameplay.Middle.SurvivalDowned)
local v_u_9 = require(v_u_2.Components.Common.SurvivalDowned)
local v_u_10 = require(v_u_2.Components.Common.IsSurvivalMode)
local v_u_11 = require(v_u_2.Components.Common.CharacterResolver)
local v_u_12 = require(v_u_2.Components.Common.IsPlayingTeam)
local v_u_13 = require(v_u_2.Database.Security.Remotes)
local v_u_14 = Color3.fromRGB(165, 183, 212)
local v_u_15 = Color3.fromRGB(214, 41, 41)
local v_u_16 = v_u_4.LocalPlayer
local v_u_17 = v_u_16:WaitForChild("PlayerGui")
local v_u_18 = {}
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = 0
local v_u_22 = nil
local v_u_23 = nil
local v_u_24 = nil
local v_u_25 = 0
local v_u_26 = nil
local v_u_27 = 0
local v_u_28 = nil
local function v_u_38(p29) -- name: updateMarkers
	-- upvalues: (copy) v_u_18, (copy) v_u_4, (copy) v_u_9, (copy) v_u_16, (copy) v_u_11, (copy) v_u_6, (copy) v_u_2, (copy) v_u_17, (copy) v_u_14, (copy) v_u_15
	for v30 in v_u_18 do
		if p29 and (v30.Parent == v_u_4 and v_u_9.IsDowned(v30)) then
			continue
		end
		local v31 = v_u_18[v30]
		if not v31 then
			continue
		end
		v31:Destroy()
		v_u_18[v30] = nil
	end
	if p29 then
		for _, v32 in v_u_4:GetPlayers() do
			if v32 == v_u_16 or not v_u_9.IsDowned(v32) then
				continue
			end
			local v33 = v_u_11.getRootPart(v_u_6.GetRemoteShell(v32))
			if v33 then
				local v34 = v_u_18[v32]
				if not v34 then
					v34 = v_u_2.Assets.UI.Survival.DownedMarker:Clone()
					v34.Name = ("Downed_%*"):format(v32.UserId)
					v34.Adornee = v33
					v34.Parent = v_u_17
				end
				v_u_18[v32] = v34
				if v34.Adornee ~= v33 then
					v34.Adornee = v33
				end
				local v35 = v_u_9.GetReviveProgress(v32)
				local v36
				if v35 then
					v36 = v_u_14
				else
					v35 = v_u_9.GetBleedOutLeft(v32) / v_u_9.BLEED_OUT_SECONDS
					v36 = v_u_15
				end
				v34.Track.Bar.Size = UDim2.fromScale(math.clamp(v35, 0, 1), 1)
				v34.Track.Bar.BackgroundColor3 = v36
			else
				local v37 = v_u_18[v32]
				if not v37 then
					continue
				end
				v37:Destroy()
				v_u_18[v32] = nil
			end
		end
	end
end
local function v_u_45() -- name: findReviveTarget
	-- upvalues: (copy) v_u_9, (copy) v_u_16, (copy) v_u_11, (copy) v_u_12, (copy) v_u_4, (copy) v_u_6
	if v_u_9.AreHandsBusy(v_u_16) or not v_u_11.isAlivePlayer(v_u_16) then
		return nil
	end
	local v39 = v_u_11.getRootPart(v_u_11.getLocalCharacter())
	if not (v39 and v_u_12(v_u_16:GetAttribute("Team"))) then
		return nil
	end
	local v40 = (1 / 0)
	local v41 = nil
	for _, v42 in v_u_4:GetPlayers() do
		if v42 == v_u_16 or not v_u_9.IsDowned(v42) then
			continue
		end
		local v43 = v_u_11.getRootPart(v_u_6.GetRemoteShell(v42))
		if not (v43 and v_u_9.IsInReviveRange(v39.Position, v43.Position)) then
			continue
		end
		local v44 = (v43.Position - v39.Position).Magnitude
		if v44 >= v40 then
			continue
		end
		v41 = v42
		v40 = v44
	end
	return v41
end
local function v_u_48() -- name: releaseHands
	-- upvalues: (copy) v_u_7
	local v46 = v_u_7.getCurrentEquipped()
	if v46 then
		local v47 = v46.Properties
		if v47.Class == "Weapon" then
			if v46.IsChargeFiring then
				v46:cancelRevolverCharge(false)
			end
			v46:releaseFireInput()
			if v47.HasScope then
				v46:unscope(nil, true)
			end
			if v46.IsReloading then
				v46.CurrentReloadIdentity = nil
				v46.IsReloading = false
				v46:stopAllAnimations()
				return
			end
		else
			if v47.Class == "Melee" then
				v46:releaseFireInput()
				return
			end
			if v47.Slot == "Grenade" and (v46.ThrowStarted and not v46.ThrowFinished) then
				v46:Cancel()
			end
		end
	end
end
local function v_u_52(p49) -- name: poseViewmodel
	-- upvalues: (copy) v_u_7, (ref) v_u_23, (ref) v_u_24
	local v50
	if p49 then
		v50 = v_u_7.getCurrentEquipped()
	else
		v50 = nil
	end
	local v51
	if v50 then
		v51 = v50.Viewmodel
	else
		v51 = nil
	end
	if v51 ~= v_u_23 then
		if v_u_23 and not v_u_23.IsDestroyed then
			v_u_23:setLowered(false)
			v_u_23:unhide()
		end
		v_u_23 = v51
		v_u_24 = nil
	end
	if v51 and not v51.IsDestroyed then
		v51:setLowered(p49 == "Lowered")
		if p49 == "Hidden" then
			v51:hide()
		elseif v_u_24 == "Hidden" then
			v51:unhide()
		end
		v_u_24 = p49
	else
		v_u_23 = nil
		v_u_24 = nil
	end
end
local function v_u_62(p53, p54) -- name: updateDesaturation
	-- upvalues: (ref) v_u_26, (copy) v_u_3, (ref) v_u_27
	local v55 = p53 and 1 or 0
	local v56
	if v_u_26 == nil then
		v56 = false
	else
		v56 = v_u_26.Parent == v_u_3
	end
	if v_u_27 ~= v55 or v55 ~= 0 and not v56 then
		local v57 = p54 / 0.6
		local v58
		if v_u_27 < v55 then
			local v59 = v_u_27 + v57
			v58 = math.min(v55, v59)
		else
			local v60 = v_u_27 - v57
			v58 = math.max(v55, v60)
		end
		v_u_27 = v58
		local v61 = v_u_26
		if not v61 or v61.Parent ~= v_u_3 then
			v61 = Instance.new("ColorCorrectionEffect")
			v61.Name = "DownedColorCorrection"
			v61.Enabled = false
			v61.Parent = v_u_3
			v_u_26 = v61
		end
		v61.Saturation = -(v_u_27 * v_u_27 * (3 - v_u_27 * 2))
		v61.Enabled = v_u_27 > 0
	end
end
local function v_u_64() -- name: isActive
	-- upvalues: (copy) v_u_10, (ref) v_u_20, (copy) v_u_9, (copy) v_u_16, (copy) v_u_4
	if not v_u_10() then
		return false
	end
	if v_u_20 or v_u_9.IsReviving(v_u_16) then
		return true
	end
	for _, v63 in v_u_4:GetPlayers() do
		if not v_u_9.IsDowned(v63) then
			continue
		end
		return true
	end
	return false
end
local function v_u_76(p65) -- name: update
	-- upvalues: (copy) v_u_10, (ref) v_u_25, (copy) v_u_38, (ref) v_u_19, (copy) v_u_45, (copy) v_u_9, (copy) v_u_16, (ref) v_u_20, (ref) v_u_21, (copy) v_u_7, (ref) v_u_22, (copy) v_u_48, (copy) v_u_52, (copy) v_u_62, (copy) v_u_8, (copy) v_u_64, (ref) v_u_27, (ref) v_u_23, (copy) v_u_18, (ref) v_u_28
	local v66 = v_u_10()
	local v67 = os.clock()
	if v67 - v_u_25 >= 0.06666666666666667 then
		v_u_25 = v67
		v_u_38(v66)
		local v68
		if v66 then
			v68 = v_u_45()
		else
			v68 = nil
		end
		v_u_19 = v68
	end
	local v69
	if v66 then
		v69 = v_u_9.IsDowned(v_u_16)
	else
		v69 = v66
	end
	local v70
	if v66 then
		v70 = v_u_9.IsReviving(v_u_16)
	else
		v70 = v66
	end
	if v_u_20 and (v70 or v67 - v_u_21 > 0.6) then
		v_u_20 = nil
	end
	local v71
	if v66 then
		local v72 = v_u_7.getCurrentEquipped()
		local v73 = v_u_9.CanUseSlot
		local v74 = v_u_16
		local v75
		if v72 then
			v75 = v72.Properties.Slot
		else
			v75 = nil
		end
		v71 = not v73(v74, v75) and (v70 and "Lowered" or "Hidden") or nil
	else
		v71 = nil
	end
	if v71 and not v_u_22 then
		v_u_48()
	end
	v_u_52(v71)
	v_u_22 = v71
	v_u_62(v69, p65)
	if v66 then
		v_u_8.Update(v_u_19)
	else
		v_u_8.Hide()
	end
	if not v_u_64() and (v_u_27 == 0 and (v_u_23 == nil and next(v_u_18) == nil)) then
		if v_u_28 then
			v_u_28:Disconnect()
			v_u_28 = nil
		end
		v_u_19 = nil
		v_u_8.Hide()
	end
end
local function v_u_77() -- name: evaluateUpdating
	-- upvalues: (ref) v_u_28, (copy) v_u_64, (ref) v_u_25, (copy) v_u_5, (copy) v_u_76
	if not v_u_28 and v_u_64() then
		v_u_25 = 0
		v_u_28 = v_u_5.BindToRenderSteppedEvent("SurvivalDownedController.Update", v_u_76)
	end
end
local function v_u_79(p78) -- name: watchPlayer
	-- upvalues: (copy) v_u_9, (copy) v_u_77
	p78:GetAttributeChangedSignal(v_u_9.DOWNED_ATTRIBUTE):Connect(v_u_77)
	p78:GetAttributeChangedSignal(v_u_9.REVIVING_ATTRIBUTE):Connect(v_u_77)
end
function v1.WantsUse() -- name: WantsUse
	-- upvalues: (ref) v_u_19, (copy) v_u_9, (copy) v_u_16
	return v_u_19 ~= nil and true or v_u_9.IsReviving(v_u_16)
end
function v1.TryStartRevive() -- name: TryStartRevive
	-- upvalues: (copy) v_u_10, (copy) v_u_9, (copy) v_u_16, (copy) v_u_45, (ref) v_u_20, (ref) v_u_21, (copy) v_u_13, (ref) v_u_28, (copy) v_u_64, (ref) v_u_25, (copy) v_u_5, (copy) v_u_76
	if not v_u_10() or v_u_9.AreHandsBusy(v_u_16) then
		return false
	end
	local v80 = v_u_45()
	if not v80 then
		return false
	end
	local v81 = os.clock()
	v_u_20 = v80
	v_u_21 = v81
	v_u_13.Survival.StartRevive.Send({
		["Target"] = v80.UserId
	})
	if not v_u_28 and v_u_64() then
		v_u_25 = 0
		v_u_28 = v_u_5.BindToRenderSteppedEvent("SurvivalDownedController.Update", v_u_76)
	end
	return true
end
function v1.StopRevive() -- name: StopRevive
	-- upvalues: (ref) v_u_20, (copy) v_u_9, (copy) v_u_16, (copy) v_u_13
	if v_u_20 or v_u_9.IsReviving(v_u_16) then
		v_u_20 = nil
		v_u_13.Survival.CancelRevive.Send()
	end
end
function v1.Start() -- name: Start
	-- upvalues: (copy) v_u_7, (ref) v_u_22, (copy) v_u_9, (copy) v_u_16, (copy) v_u_48, (copy) v_u_52, (copy) v_u_4, (copy) v_u_77, (copy) v_u_79, (ref) v_u_28, (copy) v_u_64, (ref) v_u_25, (copy) v_u_5, (copy) v_u_76
	v_u_7.OnInventoryItemEquipped:Connect(function()
		-- upvalues: (ref) v_u_22, (ref) v_u_7, (ref) v_u_9, (ref) v_u_16, (ref) v_u_48, (ref) v_u_52
		if v_u_22 then
			local v82 = v_u_7.getCurrentEquipped()
			local v83 = v_u_9.CanUseSlot
			local v84 = v_u_16
			local v85
			if v82 then
				v85 = v82.Properties.Slot
			else
				v85 = nil
			end
			if not v83(v84, v85) then
				v_u_48()
				v_u_52(v_u_22)
			end
		end
	end)
	for _, v86 in v_u_4:GetPlayers() do
		v86:GetAttributeChangedSignal(v_u_9.DOWNED_ATTRIBUTE):Connect(v_u_77)
		v86:GetAttributeChangedSignal(v_u_9.REVIVING_ATTRIBUTE):Connect(v_u_77)
	end
	v_u_4.PlayerAdded:Connect(v_u_79)
	workspace:GetAttributeChangedSignal("Gamemode"):Connect(v_u_77)
	if not v_u_28 and v_u_64() then
		v_u_25 = 0
		v_u_28 = v_u_5.BindToRenderSteppedEvent("SurvivalDownedController.Update", v_u_76)
	end
end
return v1
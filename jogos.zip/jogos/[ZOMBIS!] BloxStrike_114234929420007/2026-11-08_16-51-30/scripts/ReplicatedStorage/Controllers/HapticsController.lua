-- NIGHT Analyzer | ReplicatedStorage.Controllers.HapticsController
-- ModuleScript | 61 linhas | 1714 bytes | hash f229ee61

local v1 = {}
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("HapticService")
local v_u_5 = game:GetService("Players").LocalPlayer
local v_u_6 = require(v2.Controllers.DataController)
local v_u_7 = require(v2.Controllers.RunServiceController)
local v_u_8 = {}
local v_u_9 = nil
local function v_u_13(p10) -- name: updateQueue
	-- upvalues: (copy) v_u_8, (copy) v_u_4, (ref) v_u_9
	for v11, v12 in pairs(v_u_8) do
		v12.Length = v12.Length - p10
		if v_u_4:IsMotorSupported(v12.InputMotor, v11) then
			v_u_4:SetMotor(v12.InputMotor, v11, v12.Intensity)
		end
		if v12.Length > 0 then
			continue
		end
		v_u_4:SetMotor(v12.InputMotor, v11, 0)
		v_u_8[v11] = nil
	end
	if next(v_u_8) == nil and v_u_9 then
		v_u_9:Disconnect()
		v_u_9 = nil
	end
end
function v1.vibrate(p14, p15, p16) -- name: vibrate
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_5, (copy) v_u_8, (ref) v_u_9, (copy) v_u_7, (copy) v_u_13
	local v17 = v_u_3:GetLastInputType() == Enum.UserInputType.Touch and "Mobile" or "Controller"
	local v18 = v_u_6.Get(v_u_5, "Settings.Game.Other." .. v17 .. " Haptics/Vibrations")
	local v19
	if v18 == nil then
		v19 = false
	else
		v19 = v18 ~= false
	end
	if v19 then
		local v20 = Enum.UserInputType.Gamepad1
		local v21 = v_u_8[p14]
		if v21 then
			v21.InputMotor = v20
			if v21.Length < p16 then
				v21.Length = p16
			end
			if v21.Intensity < p15 then
				v21.Intensity = p15
			end
		else
			v_u_8[p14] = {
				["InputMotor"] = v20,
				["Intensity"] = p15,
				["Length"] = p16
			}
		end
		if not v_u_9 then
			v_u_9 = v_u_7.BindToRenderStep("HapticsController.UpdateQueue", v_u_13)
		end
	end
end
return v1
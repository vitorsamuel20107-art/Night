-- NIGHT Analyzer | ReplicatedStorage.Controllers.TutorialBotSmoothing
-- ModuleScript | 346 linhas | 8824 bytes | hash 94405620

local v1 = {}
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = {
	["TutorialEscorts"] = true,
	["TutorialRetakers"] = true,
	["TutorialCTSquad"] = true,
	["TutorialBAttackers"] = true
}
local v_u_5 = {}
local v_u_6 = {}
local v_u_7 = nil
local v_u_8 = {}
local v_u_9 = {}
local v_u_10 = 0
local function v_u_17(p11) -- name: untrack
	-- upvalues: (copy) v_u_5, (ref) v_u_7
	local v12 = v_u_5[p11]
	if v12 then
		v_u_5[p11] = nil
		for _, v13 in v12.Connections do
			v13:Disconnect()
		end
		local v14 = v12.Written
		if v14 and v12.Root.Parent then
			local v15 = v12.Root.CFrame
			local v16
			if (v15.Position - v14.Position).Magnitude <= 0.001 and v15.LookVector:Dot(v14.LookVector) >= 0.999998 then
				v16 = v15.UpVector:Dot(v14.UpVector) >= 0.999998
			else
				v16 = false
			end
			if v16 then
				v12.Root.CFrame = v12.Target
			end
		end
		if next(v_u_5) == nil and v_u_7 then
			v_u_7:Disconnect()
			v_u_7 = nil
		end
	end
end
local function v_u_30(p18, p19, p20) -- name: receive
	-- upvalues: (ref) v_u_10
	p18.Target = p19
	local v21 = p19.Position
	local v22 = p18.Path
	local v23
	if #v22 > 0 then
		v23 = v22[#v22]
	else
		v23 = p18.Visual.Position
	end
	local v24 = (v21 - v23).Magnitude
	if v24 > 8 then
		table.clear(v22)
		table.clear(p18.Arrivals)
		p18.Visual = p19
		p18.Speed = 0
		p18.Cruise = 0
	else
		if v24 > 0.001 then
			table.insert(v22, v21)
			p18.Queued = p18.Queued + v24
			local v25 = p18.MovedAt
			if v25 and p20 - v25 < 0.6 then
				local v26 = v_u_10
				local v27 = p20 - v25
				v_u_10 = math.max(v26, v27)
			end
			p18.MovedAt = p20
		end
		local v28 = p18.Arrivals
		local v29 = {
			["Time"] = p20,
			["Distance"] = p18.Queued
		}
		table.insert(v28, v29)
	end
end
local function v_u_37(p31, p32) -- name: measureSpeed
	local v33 = p31.Arrivals
	while #v33 > 1 and p32 - v33[1].Time > 0.5 do
		table.remove(v33, 1)
	end
	if #v33 < 2 then
		return 0
	end
	local v34 = v33[1]
	local v35 = p31.Queued - v34.Distance
	local v36 = p32 - v34.Time
	return v35 / math.max(v36, 0.25)
end
local function v_u_43(p38, p39, p40) -- name: advance
	while #p39 > 0 do
		local v41 = p39[1]
		local v42 = (v41 - p38).Magnitude
		if p40 < v42 then
			return p38 + (v41 - p38) * (p40 / v42)
		end
		p40 = p40 - v42
		table.remove(p39, 1)
		p38 = v41
	end
	return p38
end
local function v_u_84(p44) -- name: step
	-- upvalues: (ref) v_u_10, (copy) v_u_8, (copy) v_u_9, (copy) v_u_5, (copy) v_u_17, (copy) v_u_30, (copy) v_u_37, (copy) v_u_43, (copy) v_u_3
	local v45 = math.min(p44, 0.1)
	local v46 = os.clock()
	local v47 = v45 * -10
	local v48 = 1 - math.exp(v47)
	local v49 = v45 * -14
	local v50 = 1 - math.exp(v49)
	local v51 = v_u_10
	local v52 = -v45 / 3
	v_u_10 = v51 * math.exp(v52)
	local v53 = v_u_10 * 1.25
	local v54 = math.clamp(v53, 0.1, 0.4)
	local v55 = -v45 / 1
	local v56 = math.exp(v55)
	table.clear(v_u_8)
	table.clear(v_u_9)
	for v57, v58 in v_u_5 do
		local v59 = v58.Root
		if v57.Parent == v58.Folder and (v59.Parent ~= nil and v57:GetAttribute("Dead") ~= true) then
			local v60 = v59.CFrame
			local v61 = v58.Written
			if v61 then
				local v62
				if (v60.Position - v61.Position).Magnitude <= 0.001 and v60.LookVector:Dot(v61.LookVector) >= 0.999998 then
					v62 = v60.UpVector:Dot(v61.UpVector) >= 0.999998
				else
					v62 = false
				end
				if not v62 then
					v_u_30(v58, v60, v46)
				end
			else
				v_u_30(v58, v60, v46)
			end
			local v63 = v58.Target
			local v64 = v58.Visual
			v58.Speed = v58.Speed + (v_u_37(v58, v46) - v58.Speed) * v48
			local v65 = v58.Speed
			local v66 = v58.Cruise * v56
			v58.Cruise = math.max(v65, v66)
			local v67 = v58.Path
			local v68 = v64.Position
			local v69 = 0
			for _, v70 in v67 do
				v69 = v69 + (v70 - v68).Magnitude
				v68 = v70
			end
			local v71
			if v69 <= 0.01 then
				table.clear(v67)
				v71 = v63.Position
			else
				local v72 = v58.Speed + (v69 - v58.Speed * v54) * 3
				local v73 = v58.MovedAt
				if not v73 or v54 < v46 - v73 then
					local v74 = v58.Cruise
					v72 = math.max(v72, v74)
				end
				local v75 = v58.Cruise * 1.5
				local v76 = math.max(v75, 4)
				local v77 = math.clamp(v72, 0, v76) * v45
				local v78 = v69 - 7
				local v79 = math.max(v77, v78)
				if v69 - 0.01 <= v79 then
					v71 = v_u_43(v64.Position, v67, (1 / 0))
				else
					v71 = v_u_43(v64.Position, v67, v79)
				end
			end
			local v80
			if v64.LookVector:Dot(v63.LookVector) >= 0.9999904807207345 then
				v80 = v64.UpVector:Dot(v63.UpVector) >= 0.9999904807207345
			else
				v80 = false
			end
			local v81
			if v80 then
				v81 = v63.Rotation
			else
				v81 = v64.Rotation:Lerp(v63.Rotation, v50)
			end
			local v82 = CFrame.new(v71) * v81
			if #v67 == 0 then
				if v80 then
					v82 = v63
				end
			end
			v58.Visual = v82
			if v82 == v63 then
				local v83
				if (v60.Position - v63.Position).Magnitude <= 0.001 and v60.LookVector:Dot(v63.LookVector) >= 0.999998 then
					v83 = v60.UpVector:Dot(v63.UpVector) >= 0.999998
				else
					v83 = false
				end
				if v83 then
					v58.Written = v60
				else
					v58.Written = v82
					v_u_8[#v_u_8 + 1] = v59
					v_u_9[#v_u_9 + 1] = v82
				end
			else
				v58.Written = v82
				v_u_8[#v_u_8 + 1] = v59
				v_u_9[#v_u_9 + 1] = v82
			end
		else
			v_u_17(v57)
		end
	end
	if #v_u_8 == 1 then
		v_u_8[1].CFrame = v_u_9[1]
	elseif #v_u_8 > 1 then
		v_u_3:BulkMoveTo(v_u_8, v_u_9, Enum.BulkMoveMode.FireCFrameChanged)
	end
end
local function v_u_98(p_u_85, p_u_86) -- name: track
	-- upvalues: (copy) v_u_5, (copy) v_u_98, (copy) v_u_17, (ref) v_u_7, (copy) v_u_2, (copy) v_u_84
	if p_u_85:IsA("Model") and not v_u_5[p_u_85] then
		if p_u_85:GetAttribute("TutorialDummy") == true and p_u_85:GetAttribute("TutorialCutout") ~= true then
			if p_u_85:GetAttribute("Dead") == true then
				return
			else
				local v87 = p_u_85:FindFirstChild("HumanoidRootPart")
				if v87 and v87:IsA("BasePart") then
					if v87.Anchored then
						local v88 = v87.CFrame
						local v89 = {
							["Model"] = nil,
							["Folder"] = nil,
							["Root"] = nil,
							["Target"] = nil,
							["Visual"] = nil,
							["Written"] = nil,
							["Path"] = nil,
							["Queued"] = 0,
							["Arrivals"] = nil,
							["Speed"] = 0,
							["Cruise"] = 0,
							["MovedAt"] = nil,
							["Connections"] = nil,
							["Model"] = p_u_85,
							["Folder"] = p_u_86,
							["Root"] = v87,
							["Target"] = v88,
							["Visual"] = v88,
							["Path"] = {},
							["Arrivals"] = {},
							["Connections"] = {}
						}
						v_u_5[p_u_85] = v89
						local v90 = v89.Connections
						local v91 = p_u_85:GetAttributeChangedSignal("Dead")
						local function v92()
							-- upvalues: (copy) p_u_85, (ref) v_u_17
							if p_u_85:GetAttribute("Dead") == true then
								v_u_17(p_u_85)
							end
						end
						table.insert(v90, v91:Connect(v92))
						local v93 = v89.Connections
						local v94 = p_u_85.AncestryChanged
						local function v95()
							-- upvalues: (copy) p_u_85, (copy) p_u_86, (ref) v_u_17
							if p_u_85.Parent ~= p_u_86 then
								v_u_17(p_u_85)
							end
						end
						table.insert(v93, v94:Connect(v95))
						if not v_u_7 then
							v_u_7 = v_u_2.RenderStepped:Connect(v_u_84)
						end
					end
				else
					local v_u_96 = nil
					v_u_96 = p_u_85.ChildAdded:Connect(function(p97)
						-- upvalues: (ref) v_u_96, (ref) v_u_98, (copy) p_u_85, (copy) p_u_86
						if p97.Name == "HumanoidRootPart" then
							v_u_96:Disconnect()
							v_u_98(p_u_85, p_u_86)
						end
					end)
					task.delay(10, function()
						-- upvalues: (ref) v_u_96
						v_u_96:Disconnect()
					end)
					return
				end
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_103(p_u_99) -- name: watchFolder
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_98, (copy) v_u_17
	if v_u_4[p_u_99.Name] and not v_u_6[p_u_99] then
		v_u_6[p_u_99] = { p_u_99.ChildAdded:Connect(function(p100)
				-- upvalues: (ref) v_u_98, (copy) p_u_99
				v_u_98(p100, p_u_99)
			end), p_u_99.ChildRemoved:Connect(function(p101)
				-- upvalues: (ref) v_u_17
				if p101:IsA("Model") then
					v_u_17(p101)
				end
			end) }
		for _, v102 in p_u_99:GetChildren() do
			v_u_98(v102, p_u_99)
		end
	end
end
local function v_u_109(p104) -- name: unwatchFolder
	-- upvalues: (copy) v_u_6, (copy) v_u_5, (copy) v_u_17
	local v105 = v_u_6[p104]
	if v105 then
		v_u_6[p104] = nil
		for _, v106 in v105 do
			v106:Disconnect()
		end
		for v107, v108 in v_u_5 do
			if v108.Folder ~= p104 then
				continue
			end
			v_u_17(v107)
		end
	end
end
function v1.Start() -- name: Start
	-- upvalues: (copy) v_u_3, (copy) v_u_103, (copy) v_u_109
	v_u_3.ChildAdded:Connect(v_u_103)
	v_u_3.ChildRemoved:Connect(v_u_109)
	for _, v110 in v_u_3:GetChildren() do
		v_u_103(v110)
	end
end
return v1
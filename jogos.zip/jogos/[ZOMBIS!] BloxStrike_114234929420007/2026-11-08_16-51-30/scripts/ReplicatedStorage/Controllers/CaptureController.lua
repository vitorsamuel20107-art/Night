-- NIGHT Analyzer | ReplicatedStorage.Controllers.CaptureController
-- ModuleScript | 24 linhas | 642 bytes | hash a5ee42c5

local v1 = {}
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("CaptureService")
local v_u_4 = require(v2:WaitForChild("Shared"):WaitForChild("Promise"))
function v1.CaptureScreenshot(p_u_5) -- name: CaptureScreenshot
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	return v_u_4.new(function(p_u_6, p7)
		-- upvalues: (ref) v_u_3, (copy) p_u_5
		local v8 = v_u_3.CaptureScreenshot
		local v9 = v_u_3
		local function v11(p10)
			-- upvalues: (ref) p_u_5, (copy) p_u_6
			if p_u_5 then
				p_u_5(p10)
			end
			p_u_6(p10)
		end
		local v12, v13 = pcall(v8, v9, v11)
		if not v12 then
			p7(v13)
		end
	end)
end
return v1
-- NIGHT Analyzer | ReplicatedStorage.Controllers.EntityController
-- ModuleScript | 126 linhas | 3570 bytes | hash 0b5dc700

local v1 = {}
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Players")
local v_u_4 = script:WaitForChild("Entities")
local v_u_5 = require(v2.Components.Common.CharacterResolver)
local v_u_6 = require(v2.Components.Common.SurvivalDowned)
local v7 = require(v2.Components.Common.FarThrottle)
local v_u_8 = require(v2.Controllers.RunServiceController)
local v_u_9 = require(v2.Database.Security.Remotes)
local v_u_10 = workspace:WaitForChild("Debris")
local v_u_11 = {}
local v_u_12 = {}
local v_u_13 = {}
local v_u_14 = {}
local v_u_15 = nil
local v_u_16 = v7.new()
local function v_u_26(p17) -- name: track
	-- upvalues: (copy) v_u_10
	local v18 = p17.Model
	v18:PivotTo(CFrame.new(p17.Position))
	local v19 = v18:GetPivot()
	local v20 = p17.TrackPart
	local v21 = {
		["Entity"] = nil,
		["Parts"] = nil,
		["Offsets"] = nil,
		["Elapsed"] = 0,
		["Entity"] = p17,
		["Parts"] = {},
		["Offsets"] = {}
	}
	for _, v22 in v18:GetDescendants() do
		if not v22:IsA("BasePart") then
			continue
		end
		v22.CanCollide = false
		v22.CanQuery = false
		v22.CanTouch = false
		v22.Anchored = true
		local v23 = v21.Parts
		table.insert(v23, v22)
		local v24 = v21.Offsets
		local v25 = v22.CFrame
		table.insert(v24, v19:ToObjectSpace(v25))
		if not v20 then
			continue
		end
		v20(p17, v22)
	end
	v18.Parent = v_u_10
	return v21
end
local function v_u_43(p27) -- name: step
	-- upvalues: (copy) v_u_13, (copy) v_u_14, (copy) v_u_5, (copy) v_u_6, (copy) v_u_3, (copy) v_u_16, (copy) v_u_11
	table.clear(v_u_13)
	table.clear(v_u_14)
	local v28 = v_u_5.getLocalCharacter()
	local v29
	if v_u_5.isAliveCharacter(v28) and not v_u_6.IsDowned(v_u_3.LocalPlayer) then
		local v30 = v_u_5.getRootPart(v28)
		if v30 then
			v29 = v30.Position
		else
			v29 = nil
		end
	else
		v29 = nil
	end
	v_u_16:Begin()
	local v31 = 0
	for _, v32 in v_u_11 do
		v31 = v31 + 1
		local v33 = v32.Entity
		v32.Elapsed = v32.Elapsed + p27
		local v34 = v32.Elapsed
		v33:Step(v34, v29)
		if v_u_16:Skips(v33.Position, v31) then
			continue
		end
		local v35 = v34 * 0.5 * 2 * 3.141592653589793
		local v36 = math.sin(v35) * 0.15 + 0.2
		local v37 = CFrame.new(v33.Position + Vector3.new(0, v36, 0)) * CFrame.Angles(0, v34 * 1.5707963267948966, 0)
		for v38, v39 in v32.Parts do
			local v40 = v_u_13
			table.insert(v40, v39)
			local v41 = v_u_14
			local v42 = v37 * v32.Offsets[v38]
			table.insert(v41, v42)
		end
	end
	if #v_u_13 > 0 then
		workspace:BulkMoveTo(v_u_13, v_u_14, Enum.BulkMoveMode.FireCFrameChanged)
	end
end
function v1.Initialize() -- name: Initialize
	-- upvalues: (copy) v_u_4, (copy) v_u_12, (copy) v_u_9, (copy) v_u_11, (copy) v_u_26, (ref) v_u_15, (copy) v_u_8, (copy) v_u_43
	for _, v44 in v_u_4:GetChildren() do
		if not v44:IsA("ModuleScript") then
			continue
		end
		v_u_12[v44.Name] = require(v44)
	end
	v_u_9.Entity.CreateEntity.Listen(function(p45)
		-- upvalues: (ref) v_u_12, (ref) v_u_11, (ref) v_u_26, (ref) v_u_15, (ref) v_u_8, (ref) v_u_43
		local v46 = v_u_12[p45.EntityName]
		if v46 then
			v_u_11[p45.EntityId] = v_u_26(v46.new(p45.EntityId, p45.EntityName, p45.EntityPosition, p45.Lifetime))
			if not v_u_15 then
				v_u_15 = v_u_8.BindToHeartbeat("EntityController.Step", v_u_43)
			end
		end
	end)
	v_u_9.Entity.DestroyEntity.Listen(function(p47)
		-- upvalues: (ref) v_u_11, (ref) v_u_15
		local v48 = v_u_11[p47.EntityId]
		if v48 then
			v_u_11[p47.EntityId] = nil
			v48.Entity:Destroy(p47.ClaimedBy)
			if next(v_u_11) == nil and v_u_15 then
				v_u_15:Disconnect()
				v_u_15 = nil
			end
		end
	end)
end
return v1
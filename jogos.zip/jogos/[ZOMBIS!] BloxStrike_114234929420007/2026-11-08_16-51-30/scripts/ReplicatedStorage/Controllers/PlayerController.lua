-- NIGHT Analyzer | ReplicatedStorage.Controllers.PlayerController
-- ModuleScript | 53 linhas | 1440 bytes | hash 90fac140

local v1 = {}
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = tick()
local v_u_5 = require(v2.Components.Common.GetUserPlatform)
local v_u_6 = require(v2.Database.Security.Remotes)
local function v_u_8() -- name: ReportPlayerState
	-- upvalues: (copy) v_u_6, (ref) v_u_4
	debug.profilebegin("PlayerController.HandleNextFrame")
	local v7 = tick()
	v_u_6.Player.BlankRequest.Send(v7)
	if v7 - v_u_4 >= 900 then
		v_u_6.Player.AFKTeleport.Send()
		v_u_4 = v7
	end
	debug.profileend()
end
function v1.Initialize() -- name: Initialize
	-- upvalues: (copy) v_u_3, (ref) v_u_4, (copy) v_u_6
	v_u_3.InputBegan:Connect(function()
		-- upvalues: (ref) v_u_4
		v_u_4 = tick()
	end)
	v_u_3.InputChanged:Connect(function()
		-- upvalues: (ref) v_u_4
		v_u_4 = tick()
	end)
	v_u_6.Player.BlankRequest.Listen(function(p9)
		-- upvalues: (ref) v_u_6
		local v10 = v_u_6.Player.ReportPlayerConnect.Send
		local v11 = (tick() - p9) * 1000
		local v12 = math.floor(v11)
		v10((tostring(v12)))
	end)
end
function v1.Start() -- name: Start
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_8
	task.delay(5, function()
		-- upvalues: (ref) v_u_5, (ref) v_u_6
		local v13 = v_u_5()
		if v13 and #v13 > 0 then
			v_u_6.Player.SubmitUserPlatformAnalytics.Send(v13[1])
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_8
		while true do
			task.wait(5)
			v_u_8()
		end
	end)
end
return v1
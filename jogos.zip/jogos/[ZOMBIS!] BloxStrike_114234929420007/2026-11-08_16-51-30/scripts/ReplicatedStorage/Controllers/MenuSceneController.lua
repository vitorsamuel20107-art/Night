-- NIGHT Analyzer | ReplicatedStorage.Controllers.MenuSceneController
-- ModuleScript | 985 linhas | 29662 bytes | hash 3c5a7685

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v_u_2.Components.Common.SceneLighting)
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game:GetService("Lighting")
local v6 = game:GetService("Players")
local v_u_7 = require(v_u_2.Packages.Observers)
local v8 = require(v_u_2.Packages.Signal)
local v9 = require(v_u_2.Shared.Janitor)
v_u_1.MenuCharacterChanged = v8.new()
local v_u_10 = require(v_u_2.Controllers.CameraController)
local v_u_11 = require(v_u_2.Controllers.DataController)
local v_u_12 = require(v_u_2.Controllers.RunServiceController)
local v_u_13 = nil
local v_u_14 = require(v_u_2.Classes.Sound)
local v_u_15 = require(v_u_2.Database.Custom.Constants)
local v_u_16 = v6.LocalPlayer
local v_u_17 = v_u_16:WaitForChild("PlayerGui")
local v_u_18 = workspace.CurrentCamera
local v_u_19 = nil
local v_u_20 = v_u_2.Assets.Lighting
local v_u_21 = v_u_2.Assets.Characters
local v_u_22 = {
	["CT"] = {
		["Entrance"] = "rbxassetid://96240248165206",
		["Idle"] = "rbxassetid://77870220857645"
	},
	["T"] = {
		["Entrance"] = "rbxassetid://100747011940776",
		["Idle"] = "rbxassetid://99540873384647"
	}
}
local v_u_23 = {
	["CT"] = {
		["Character"] = "IDF",
		["Weapon"] = "M4A1-S",
		["Glove"] = "CT Glove"
	},
	["T"] = {
		["Character"] = "Anarchist",
		["Weapon"] = "AK-47",
		["Glove"] = "T Glove"
	}
}
local v_u_24 = {
	{
		["Team"] = "CT",
		["TeamName"] = "Counter-Terrorists",
		["MarkerPart"] = "CounterTerroristPart",
		["Animation"] = "rbxassetid://81456769299241",
		["HighlightColor"] = nil,
		["Weapon"] = "USP-S",
		["HighlightColor"] = Color3.fromRGB(0, 75, 200)
	},
	{
		["Team"] = "T",
		["TeamName"] = "Terrorists",
		["MarkerPart"] = "TerroristPart",
		["Animation"] = "rbxassetid://128548863350369",
		["HighlightColor"] = nil,
		["Weapon"] = "Glock-18",
		["HighlightColor"] = Color3.fromRGB(255, 220, 50)
	}
}
local v_u_25 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v_u_26 = { "IDF", "Anarchist" }
local v_u_27 = require(v_u_2.Database.Components.Common.AttachGlovesToCharacter)
local v_u_28 = require(v_u_2.Components.Common.CharacterResolver)
local v_u_29 = nil
local v_u_30 = nil
local v_u_31 = nil
local v_u_32 = nil
local v_u_33 = v9.new()
local v_u_34 = false
local v_u_35 = v9.new()
local v_u_36 = v9.new()
local v_u_37 = false
local v_u_38 = {}
local v_u_39 = nil
local v_u_40 = nil
local v_u_41 = nil
local v_u_42 = 1
local v_u_43 = nil
local v_u_44 = nil
local function v_u_45() -- name: applyGlobalShadowsSetting
	-- upvalues: (copy) v_u_3, (ref) v_u_44
	v_u_3.ApplyGlobalShadows(v_u_44)
end
local function v46() -- name: applyMapLighting
	-- upvalues: (ref) v_u_44, (copy) v_u_3
	v_u_44 = v_u_3.RestoreMap(nil, v_u_44)
end
local function v_u_52(p47) -- name: excludeTeamSelectPlaceholders
	-- upvalues: (copy) v_u_26
	for _, v48 in ipairs(p47:GetChildren()) do
		local v49 = v48:FindFirstChild("TeamSelect")
		if not v49 then
			continue
		end
		for _, v50 in ipairs(v_u_26) do
			local v51 = v49:FindFirstChild(v50)
			if not v51 then
				continue
			end
			v51.Archivable = false
		end
	end
end
local function v_u_56() -- name: getRandomMenuScene
	-- upvalues: (ref) v_u_19, (copy) v_u_2, (copy) v_u_52
	local v53
	if v_u_19 then
		v53 = v_u_19
	else
		local v54 = v_u_2:FindFirstChild("Assets")
		v_u_19 = v54 and v54:WaitForChild("MenuScenes", 10)
		if v_u_19 then
			v_u_52(v_u_19)
		end
		v53 = v_u_19
	end
	local v55 = not v53 and {} or v53:GetChildren()
	if #v55 > 0 then
		return v55[math.random(1, #v55)]
	else
		return nil
	end
end
local function v_u_62() -- name: isTeamSelectionActive
	-- upvalues: (copy) v_u_17
	local v57 = v_u_17:FindFirstChild("MainGui")
	if not v57 then
		return false
	end
	local v58 = v57:FindFirstChild("Menu")
	local v59 = v57:FindFirstChild("Gameplay")
	local v60
	if v59 then
		v60 = v59:FindFirstChild("Middle")
	else
		v60 = v59
	end
	if v59 then
		v59 = v59:FindFirstChild("Bottom")
	end
	if v60 then
		v60 = v60:FindFirstChild("TeamSelection")
	end
	local v61 = v58 ~= nil and not v58.Visible and (v59 ~= nil and not v59.Visible)
	if v61 then
		if v60 == nil then
			v61 = false
		else
			v61 = v60.Visible
		end
	end
	return v61
end
local function v_u_67() -- name: shouldShowMenuScene
	-- upvalues: (copy) v_u_2, (ref) v_u_13, (copy) v_u_62, (copy) v_u_16, (copy) v_u_28
	local v63 = require(v_u_2.Interface.MenuState)
	if v_u_13 and v_u_13.IsActive() or (v63.IsInspectActive() or (workspace:FindFirstChild("InspectScene") or v_u_62())) then
		return false
	end
	local v64 = v_u_16:GetAttribute("Team")
	if v64 == "Counter-Terrorists" or v64 == "Terrorists" then
		return false
	end
	local v65 = require(v_u_2.Database.Components.GameState).GetState()
	if v65 == "Game Ending" or v65 == "Map Voting" then
		return not v_u_28.isAliveCharacter(v_u_28.getLocalCharacter())
	end
	local v66 = not v_u_28.isAliveCharacter(v_u_28.getLocalCharacter())
	if v66 then
		v66 = not v_u_16:GetAttribute("IsSpectating")
	end
	return v66
end
local function v_u_84(p68, p69, p70) -- name: attachGlovesToCharacter
	-- upvalues: (copy) v_u_2, (copy) v_u_11, (copy) v_u_16, (copy) v_u_23, (copy) v_u_27
	local v71 = require(v_u_2.Database.Components.Libraries.Skins)
	local v72 = nil
	local v73 = nil
	local v74 = nil
	if p70 then
		v_u_11.WaitForDataLoaded(v_u_16)
		local v75 = v_u_11.Get(v_u_16, "Loadout")
		local v76
		if type(v75) == "table" then
			v76 = v75[p69 == "CT" and "Counter-Terrorists" or "Terrorists"]
		else
			v76 = false
		end
		if type(v76) ~= "table" then
			v76 = nil
		end
		local v77 = v76 and v76.Equipped
		if v77 then
			v77 = v76.Equipped["Equipped Gloves"]
		end
		local v78
		if type(v77) == "string" and v77 ~= "" then
			v78 = v_u_11.Get(v_u_16, "Inventory")
		else
			v78 = false
		end
		if type(v78) == "table" then
			for _, v79 in ipairs(v78) do
				if not v79 or v79._id ~= v77 then
					continue
				end
				v72 = v79.Name
				v73 = v79.Skin
				v74 = v79.Float
				p68:SetAttribute("EquippedGloves", game:GetService("HttpService"):JSONEncode({
					["SkinIdentifier"] = v77
				}))
			end
		end
	end
	local v80 = v72 or v_u_23[p69].Glove
	local v81
	if v73 and (v74 and v80) then
		v81 = v71.GetCharacterGloves(v80, v73, v74)
	else
		v81 = nil
	end
	local v82 = v81 or v71.GetCharacterGloveParts(v80)
	if v82 then
		local v83 = p68:FindFirstChild("CharacterArmor")
		if not v83 then
			v83 = Instance.new("Folder")
			v83.Name = "CharacterArmor"
			v83.Parent = p68
		end
		if v81 then
			v82 = v81:GetChildren()
		end
		v_u_27(v82, p68, v83)
		if v81 and v81.Name == "" then
			v81:Destroy()
		end
	else
		warn((("[MenuSceneController]: Glove folder not found for \"%*\""):format(v80)))
	end
end
local function v_u_113(p85, p86, p87, p88, p89) -- name: attachWeaponToCharacter
	-- upvalues: (copy) v_u_2, (copy) v_u_23, (copy) v_u_11, (copy) v_u_16
	local v90 = require(v_u_2.Database.Components.Libraries.Skins)
	local v91 = nil
	local v92 = nil
	local v93 = nil
	local v94 = nil
	local v95 = p88 or v_u_23[p86].Weapon
	if p87 then
		v_u_11.WaitForDataLoaded(v_u_16)
		local v96 = v_u_11.Get(v_u_16, "Loadout")
		local v97
		if type(v96) == "table" then
			v97 = v96[p86 == "CT" and "Counter-Terrorists" or "Terrorists"]
		else
			v97 = false
		end
		if type(v97) ~= "table" then
			v97 = nil
		end
		local v98 = v_u_11.Get(v_u_16, "Inventory")
		local v99 = v97 and v97.Loadout
		if v99 then
			v99 = v97.Loadout[p89 or "Rifles"]
		end
		if v99 then
			local v100 = v99.Options
			if type(v100) == "table" and type(v98) == "table" then
				for _, v101 in ipairs(v99.Options) do
					if type(v101) ~= "string" or v101 == "" then
						continue
					end
					for _, v102 in ipairs(v98) do
						if not v102 or (v102._id ~= v101 or v102.Name ~= v95) then
							continue
						end
						v91 = v102.Name
						v92 = v102.Skin
						v93 = v102.Float
						v94 = v102.NameTag
					end
					if not v91 then
						break
					end
				end
			end
		end
	end
	local v103 = v91 or v95
	local v104
	if v92 and (typeof(v92) == "string" and v92 ~= "") then
		v104 = v90.GetCharacterModel(v103, v92, v93, nil, v94)
	else
		v104 = nil
	end
	local v105 = v104 or v90.GetBaseWeaponModel(v103, "Character")
	if v105 then
		v105.Name = v103
		local v106 = p85:FindFirstChild("RightHand")
		if v106 then
			if not v105.PrimaryPart then
				local v107 = v105:FindFirstChild("Weapon")
				if v107 then
					v107 = v107:FindFirstChild("Insert")
				end
				if not v107 then
					warn("[MenuSceneController]: Weapon model has no PrimaryPart or Insert")
					v105:Destroy()
					return
				end
				v105.PrimaryPart = v107
			end
			for _, v108 in ipairs(v105:GetDescendants()) do
				if not v108:IsA("BasePart") then
					continue
				end
				v108.CanCollide = false
				v108.CanQuery = false
				v108.CanTouch = false
				v108.Anchored = false
				v108.Massless = true
			end
			v105.Parent = p85
			local v109 = Instance.new("Motor6D")
			v109.Name = "WeaponAttachment"
			v109.Part0 = v106
			v109.Part1 = v105.PrimaryPart
			v109.Parent = v106
			if v103 == "AK-47" then
				v109.C0 = CFrame.new(-0.251, 0.806, -0.406) * CFrame.Angles(0, -1.5707963267948966, 1.5707963267948966)
				return v105
			end
			local v110 = v105:FindFirstChild("Properties")
			if v110 then
				local v111 = v110:FindFirstChild("C0")
				if v111 then
					v109.C0 = v111.Value
				end
				local v112 = v110:FindFirstChild("C1")
				if v112 then
					v109.C1 = v112.Value
				end
			end
			return v105
		end
		warn("[MenuSceneController]: Character missing RightHand")
		v105:Destroy()
	else
		warn((("[MenuSceneController]: Failed to get weapon model for \"%*\""):format(v103)))
	end
end
local function v_u_117(p114) -- name: configureMenuDisplayCharacter
	-- upvalues: (copy) v_u_28
	local v115 = v_u_28.getRootPart(p114)
	for _, v116 in ipairs(p114:GetDescendants()) do
		if not v116:IsA("BasePart") then
			continue
		end
		v116.CanCollide = false
		v116.CanQuery = false
		v116.CanTouch = false
		v116.Massless = true
	end
	if v115 then
		v115.Anchored = true
	end
end
local function v_u_122(p118) -- name: prepareTeamSelectScene
	-- upvalues: (copy) v_u_24
	local v119 = p118:FindFirstChild("TeamSelect")
	if v119 then
		for _, v120 in ipairs(v_u_24) do
			local v121 = v119:FindFirstChild(v120.MarkerPart)
			if not (v121 and v121:IsA("BasePart")) then
				continue
			end
			v121.Transparency = 1
			v121.CanCollide = false
			v121.CanQuery = false
			v121.CanTouch = false
		end
	end
end
local function v_u_128(p123) -- name: ensureSceneLoaded
	-- upvalues: (ref) v_u_29, (copy) v_u_20, (ref) v_u_44, (copy) v_u_3, (copy) v_u_122, (copy) v_u_35
	local v124 = v_u_29
	if v124 and v124.Parent then
		return v124
	end
	if not p123 then
		return nil
	end
	local v125 = p123:Clone()
	v125.Parent = workspace
	v_u_29 = v125
	local v126 = p123.Name
	local v127 = v_u_20:FindFirstChild(v126)
	if v127 then
		v_u_44 = v_u_3.ApplyScene(v126, v127)
	else
		warn((("[MenuSceneController]: No lighting found for scene \"%*\""):format(v126)))
	end
	v_u_122(v125)
	v_u_35:Add(function()
		-- upvalues: (ref) v_u_29
		if v_u_29 then
			v_u_29:Destroy()
			v_u_29 = nil
		end
	end, true, "MenuSceneCleanup")
	return v125
end
local function v_u_135() -- name: getStagedMenuScene
	-- upvalues: (ref) v_u_19, (copy) v_u_2, (copy) v_u_52
	local v129
	if v_u_19 then
		v129 = v_u_19
	else
		local v130 = v_u_2:FindFirstChild("Assets")
		v_u_19 = v130 and v130:WaitForChild("MenuScenes", 10)
		if v_u_19 then
			v_u_52(v_u_19)
		end
		v129 = v_u_19
	end
	if v129 then
		local v131 = {}
		for _, v132 in ipairs(v129:GetChildren()) do
			if not v132:IsA("Model") then
				continue
			end
			local v133 = v132:FindFirstChild("TeamSelect")
			local v134
			if v133 then
				v134 = v133:FindFirstChild("CamPart")
			else
				v134 = v133
			end
			if not (v133 and (v134 and v134:IsA("BasePart"))) then
				v133 = nil
			end
			if not v133 then
				continue
			end
			table.insert(v131, v132)
		end
		if #v131 == 0 then
			return nil
		else
			return v131[math.random(1, #v131)]
		end
	else
		return nil
	end
end
local function v_u_148(p136) -- name: spawnMenuCharacter
	-- upvalues: (copy) v_u_23, (copy) v_u_22, (copy) v_u_21, (ref) v_u_30, (ref) v_u_31, (copy) v_u_1, (ref) v_u_32, (copy) v_u_113, (copy) v_u_84, (copy) v_u_117, (copy) v_u_28, (copy) v_u_33, (ref) v_u_34
	local v137 = p136:FindFirstChild("PlayerPart")
	if v137 then
		local v138 = math.random(1, 2) == 1 and "CT" or "T"
		local v139 = v_u_23[v138]
		local v140 = v_u_22[v138]
		local v141 = v_u_21:FindFirstChild(v139.Character)
		if v141 then
			local v142 = v141:Clone()
			v142.Name = "MenuCharacter"
			v_u_30 = v142
			v_u_31 = v138
			v_u_1.MenuCharacterChanged:Fire(v_u_1.GetMenuCharacterTeam())
			v_u_32 = v_u_113(v142, v138, true)
			v_u_84(v142, v138, true)
			v_u_117(v142)
			v142.Parent = p136
			v142:PivotTo(v137.CFrame)
			local v143 = v_u_28.getOrCreateAnimator(v142)
			if v143 then
				local v144 = Instance.new("Animation")
				v144.AnimationId = v140.Entrance
				local v145 = Instance.new("Animation")
				v145.AnimationId = v140.Idle
				local v146 = v143:LoadAnimation(v144)
				local v_u_147 = v143:LoadAnimation(v145)
				v_u_33:Add(v144, "Destroy", "EntranceAnimation")
				v_u_33:Add(v145, "Destroy", "IdleAnimation")
				v_u_33:Add(v146, "Stop", "EntranceTrack")
				v_u_33:Add(v_u_147, "Stop", "IdleTrack")
				v146.Priority = Enum.AnimationPriority.Action
				v146:Play()
				v146.Stopped:Once(function()
					-- upvalues: (ref) v_u_34, (copy) v_u_147
					if v_u_34 and v_u_147 then
						v_u_147.Looped = true
						v_u_147.Priority = Enum.AnimationPriority.Idle
						v_u_147:Play()
					end
				end)
				v_u_33:Add(function()
					-- upvalues: (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (ref) v_u_1
					if v_u_30 then
						v_u_30:Destroy()
						v_u_30 = nil
						v_u_31 = nil
						v_u_32 = nil
						v_u_1.MenuCharacterChanged:Fire(nil)
					end
				end, true, "MenuCharacterCleanup")
			else
				warn("[MenuSceneController]: Character missing Animator")
			end
		else
			warn((("[MenuSceneController]: Character \"%*\" not found"):format(v139.Character)))
			return
		end
	else
		return
	end
end
local function v_u_159(p149, p_u_150) -- name: spawnTeamSelectCharacter
	-- upvalues: (copy) v_u_23, (copy) v_u_21, (copy) v_u_113, (copy) v_u_84, (copy) v_u_117, (copy) v_u_36, (copy) v_u_38, (copy) v_u_28
	local v151 = p149:FindFirstChild(p_u_150.MarkerPart)
	if v151 then
		local v152 = v_u_23[p_u_150.Team]
		local v153 = v_u_21:FindFirstChild(v152.Character)
		if v153 then
			local v154 = v153:Clone()
			v154.Name = ("TeamSelectCharacter%*"):format(p_u_150.Team)
			v_u_113(v154, p_u_150.Team, true, p_u_150.Weapon, "Pistols")
			v_u_84(v154, p_u_150.Team, true)
			v_u_117(v154)
			v154.Parent = p149
			v154:PivotTo(v151.CFrame)
			v_u_36:Add(v154, "Destroy", (("Character%*"):format(p_u_150.Team)))
			local v155 = Instance.new("Highlight")
			v155.Name = "HoverHighlight"
			v155.DepthMode = Enum.HighlightDepthMode.Occluded
			v155.OutlineColor = p_u_150.HighlightColor
			v155.FillTransparency = 1
			v155.OutlineTransparency = 1
			v155.Adornee = v154
			v155.Parent = v154
			v_u_38[p_u_150.Team] = v155
			v_u_36:Add(function()
				-- upvalues: (ref) v_u_38, (copy) p_u_150
				v_u_38[p_u_150.Team] = nil
			end, true, (("Highlight%*"):format(p_u_150.Team)))
			local v156 = v_u_28.getOrCreateAnimator(v154)
			if v156 then
				local v157 = Instance.new("Animation")
				v157.AnimationId = p_u_150.Animation
				v_u_36:Add(v157, "Destroy", (("Animation%*"):format(p_u_150.Team)))
				local v158 = v156:LoadAnimation(v157)
				v_u_36:Add(v158, "Stop", (("Track%*"):format(p_u_150.Team)))
				v158.Looped = true
				v158.Priority = Enum.AnimationPriority.Idle
				v158:Play()
			else
				warn((("[MenuSceneController]: TeamSelect character \"%*\" is missing an Animator"):format(p_u_150.Team)))
			end
		else
			warn((("[MenuSceneController]: Character \"%*\" not found"):format(v152.Character)))
			return
		end
	else
		warn((("[MenuSceneController]: TeamSelect is missing \"%*\""):format(p_u_150.MarkerPart)))
		return
	end
end
local function v_u_164() -- name: updateMenuMusicVolume
	-- upvalues: (ref) v_u_41, (copy) v_u_11, (copy) v_u_16, (ref) v_u_42
	if v_u_41 and v_u_41.Parent then
		local v160 = v_u_11.Get(v_u_16, "Settings.Audio.Audio.Main Menu Ambience Volume") or 100
		local v161 = v_u_11.Get(v_u_16, "Settings.Audio.Audio.Master Volume") or 100
		local v162 = v160 / 100
		local v163 = v161 / 100
		v_u_41.Volume = (v_u_41:GetAttribute("BaseVolume") or v_u_41.Volume) * v162 * v163 * v_u_42
	end
end
function v_u_1.ShowMenuScene() -- name: ShowMenuScene
	-- upvalues: (copy) v_u_28, (ref) v_u_37, (ref) v_u_34, (copy) v_u_10, (copy) v_u_2, (copy) v_u_128, (copy) v_u_56, (copy) v_u_35, (ref) v_u_44, (copy) v_u_3, (copy) v_u_18, (copy) v_u_33, (copy) v_u_12, (ref) v_u_29, (copy) v_u_1, (copy) v_u_148, (ref) v_u_41, (copy) v_u_11, (copy) v_u_16, (copy) v_u_14, (ref) v_u_40, (copy) v_u_17, (ref) v_u_42
	if v_u_28.isAliveCharacter(v_u_28.getLocalCharacter()) then
		return
	elseif v_u_37 then
		return
	elseif v_u_34 then
		v_u_10.setFOVLock("MenuScene", true, 50)
		v_u_10.setMouseEnabled(true)
		return
	elseif workspace:FindFirstChild("InspectScene") then
		return
	else
		local v165 = require(v_u_2.Interface.MenuState)
		if v165.IsInspectActive() or v165.IsCaseSceneActive() then
			return
		else
			local v166 = v_u_128((v_u_56()))
			if v166 then
				local v_u_167 = v166:FindFirstChild("CamPart")
				if v_u_167 then
					v_u_18.CameraType = Enum.CameraType.Scriptable
					v_u_18.CFrame = v_u_167.CFrame
					v_u_18.Focus = v_u_167.CFrame
					v_u_10.setFOVLock("MenuScene", true, 50)
					v_u_10.setMouseEnabled(true)
					v_u_33:Add(v_u_12.BindToRenderStep("MenuSceneController.CameraUpdate", function()
						-- upvalues: (ref) v_u_29, (copy) v_u_167, (ref) v_u_18
						if v_u_29 and v_u_167 then
							v_u_18.CFrame = v_u_167.CFrame
							v_u_18.Focus = v_u_167.CFrame
						end
					end), "Disconnect", "CameraUpdate")
					v_u_34 = true
					v_u_33:Add(v_u_12.BindToHeartbeat("MenuSceneController.AliveGuard", function()
						-- upvalues: (ref) v_u_28, (ref) v_u_1
						if v_u_28.isAliveCharacter(v_u_28.getLocalCharacter()) then
							v_u_1.HideMenuScene()
						end
					end), "Disconnect", "AliveGuard")
					v_u_148(v166)
					if not (v_u_41 and v_u_41.IsPlaying) then
						local v168 = (v_u_11.Get(v_u_16, "Settings.Audio.Audio.Main Menu Ambience Volume") or 100) / 100
						local v169 = v_u_14.new("Main Menu")
						v_u_40 = v169
						local v_u_170 = v169:play({
							["Name"] = "Main Menu Music",
							["Parent"] = nil,
							["Parent"] = v_u_17
						}, v168)
						v_u_41 = v_u_170
						if v_u_170 then
							local v171 = (v_u_11.Get(v_u_16, "Settings.Audio.Audio.Master Volume") or 100) / 100
							local v172 = v_u_170.Volume
							if v168 > 0 and v171 > 0 then
								v172 = v172 / (v168 * v171) or v172
							end
							v_u_170:SetAttribute("BaseVolume", v172)
							v_u_170:SetAttribute("AmbienceVolumeMultiplier", v168)
							if v_u_42 ~= 1 then
								v_u_170.Volume = v_u_170.Volume * v_u_42
							end
							v_u_170.Destroying:Once(function()
								-- upvalues: (ref) v_u_41, (copy) v_u_170
								if v_u_41 == v_u_170 then
									v_u_41 = nil
								end
							end)
						end
					end
				else
					warn("[MenuSceneController]: Menu scene missing CamPart")
					v_u_35:Cleanup()
					v_u_44 = v_u_3.RestoreMap(nil, v_u_44)
				end
			else
				v_u_10.setMouseEnabled(true)
				return
			end
		end
	end
end
function v_u_1.HideMenuScene(p173, p174, p175) -- name: HideMenuScene
	-- upvalues: (ref) v_u_34, (copy) v_u_2, (copy) v_u_33, (ref) v_u_37, (copy) v_u_35, (copy) v_u_10, (ref) v_u_44, (copy) v_u_3, (copy) v_u_18, (copy) v_u_15, (copy) v_u_1
	if v_u_34 then
		if require(v_u_2.Interface.MenuState).IsInspectActive() or workspace:FindFirstChild("InspectScene") then
			p174 = true
			p173 = true
		end
		v_u_33:Cleanup()
		v_u_34 = false
		if not (p175 or (v_u_34 or v_u_37)) then
			v_u_35:Cleanup()
		end
		v_u_10.setFOVLock("MenuScene", false)
		if not (p174 or p175) then
			v_u_44 = v_u_3.RestoreMap(nil, v_u_44)
			v_u_18.CameraType = Enum.CameraType.Custom
			v_u_10.updateCameraFOV(v_u_15.DEFAULT_CAMERA_FOV)
		end
		if not p173 then
			v_u_1.StopMenuMusic()
		end
	end
end
function v_u_1.IsActive() -- name: IsActive
	-- upvalues: (ref) v_u_34
	return v_u_34
end
function v_u_1.IsTeamSelectSceneActive() -- name: IsTeamSelectSceneActive
	-- upvalues: (ref) v_u_37
	return v_u_37
end
function v_u_1.SetTeamSelectHighlight(p176, p177) -- name: SetTeamSelectHighlight
	-- upvalues: (ref) v_u_39, (copy) v_u_24, (copy) v_u_38, (copy) v_u_4, (copy) v_u_25
	if p177 then
		v_u_39 = p176
	else
		if v_u_39 ~= p176 then
			return
		end
		v_u_39 = nil
	end
	for _, v178 in ipairs(v_u_24) do
		local v179 = v_u_38[v178.Team]
		if not v179 then
			continue
		end
		v_u_4:Create(v179, v_u_25, {
			["OutlineTransparency"] = v_u_39 == v178.TeamName and 0 or 1
		}):Play()
	end
end
function v_u_1.ShowTeamSelectScene() -- name: ShowTeamSelectScene
	-- upvalues: (copy) v_u_28, (copy) v_u_16, (ref) v_u_37, (copy) v_u_10, (ref) v_u_34, (copy) v_u_1, (copy) v_u_128, (copy) v_u_135, (copy) v_u_35, (ref) v_u_29, (ref) v_u_44, (copy) v_u_3, (copy) v_u_18, (copy) v_u_36, (copy) v_u_12, (copy) v_u_24, (copy) v_u_159, (copy) v_u_62
	if v_u_28.isAliveCharacter(v_u_28.getLocalCharacter()) or v_u_16:GetAttribute("IsSpectating") then
		return false
	end
	if v_u_37 then
		v_u_10.setFOVLock("TeamSelectScene", true, 70)
		v_u_10.setMouseEnabled(true)
		return true
	end
	if v_u_34 then
		v_u_1.HideMenuScene(true, true, true)
	end
	local v180 = v_u_128((v_u_135()))
	local v181, v_u_182
	if v180 then
		v181 = v180:FindFirstChild("TeamSelect")
		if v181 then
			v_u_182 = v181:FindFirstChild("CamPart")
		else
			v_u_182 = v181
		end
		if not (v181 and (v_u_182 and v_u_182:IsA("BasePart"))) then
			v181 = nil
			v_u_182 = nil
		end
	else
		v181 = nil
		v_u_182 = nil
	end
	if not (v181 and v_u_182) then
		if not (v_u_34 or v_u_37) then
			v_u_35:Cleanup()
		end
		if not v_u_29 then
			v_u_44 = v_u_3.RestoreMap(nil, v_u_44)
		end
		return false
	end
	v_u_37 = true
	v_u_18.CameraType = Enum.CameraType.Scriptable
	v_u_18.CameraSubject = nil
	v_u_18.CFrame = v_u_182.CFrame
	v_u_18.Focus = v_u_182.CFrame
	v_u_10.setFOVLock("TeamSelectScene", true, 70)
	v_u_10.setMouseEnabled(true)
	v_u_36:Add(v_u_12.BindToRenderStep("MenuSceneController.TeamSelectCameraUpdate", function()
		-- upvalues: (ref) v_u_18, (ref) v_u_182
		v_u_18.CFrame = v_u_182.CFrame
		v_u_18.Focus = v_u_182.CFrame
	end), "Disconnect", "TeamSelectCameraUpdate")
	for _, v183 in ipairs(v_u_24) do
		v_u_159(v181, v183)
	end
	local v_u_184 = 0
	v_u_36:Add(v_u_12.BindToHeartbeat("MenuSceneController.TeamSelectGuard", function(p185)
		-- upvalues: (ref) v_u_184, (ref) v_u_28, (ref) v_u_62, (ref) v_u_1
		v_u_184 = v_u_184 + p185
		if v_u_184 >= 0.25 then
			v_u_184 = 0
			if v_u_28.isAliveCharacter(v_u_28.getLocalCharacter()) or not v_u_62() then
				v_u_1.HideTeamSelectScene()
			end
		end
	end), "Disconnect", "TeamSelectGuard")
	return true
end
function v_u_1.HideTeamSelectScene() -- name: HideTeamSelectScene
	-- upvalues: (ref) v_u_37, (copy) v_u_36, (copy) v_u_10, (ref) v_u_39, (ref) v_u_34, (copy) v_u_35, (ref) v_u_29, (ref) v_u_44, (copy) v_u_3, (copy) v_u_18
	if v_u_37 then
		v_u_36:Cleanup()
		v_u_10.setFOVLock("TeamSelectScene", false)
		v_u_37 = false
		v_u_39 = nil
		if not (v_u_34 or v_u_37) then
			v_u_35:Cleanup()
		end
		if not v_u_29 then
			v_u_44 = v_u_3.RestoreMap(nil, v_u_44)
			v_u_18.CameraType = Enum.CameraType.Custom
		end
	end
end
function v_u_1.StopMenuMusic() -- name: StopMenuMusic
	-- upvalues: (ref) v_u_41, (ref) v_u_40
	if v_u_41 then
		v_u_41:Stop()
		v_u_41 = nil
	end
	if v_u_40 then
		v_u_40:destroy()
		v_u_40 = nil
	end
end
function v_u_1.SetMusicVolumeMultiplier(p186, p187) -- name: SetMusicVolumeMultiplier
	-- upvalues: (ref) v_u_42, (ref) v_u_41, (ref) v_u_43, (copy) v_u_11, (copy) v_u_16, (copy) v_u_4
	v_u_42 = p186
	if v_u_41 then
		if v_u_43 then
			v_u_43:Cancel()
			v_u_43 = nil
		end
		local v188 = v_u_41:GetAttribute("BaseVolume") or 0.1
		local v189 = v_u_11.Get(v_u_16, "Settings.Audio.Audio.Main Menu Ambience Volume") or 100
		local v190 = v_u_11.Get(v_u_16, "Settings.Audio.Audio.Master Volume") or 100
		local v191 = v189 / 100
		local v192 = v190 / 100
		local v193 = v188 * v191 * v192 * v_u_42
		if p187 and p187 > 0 then
			local v194 = v_u_4:Create(v_u_41, TweenInfo.new(p187, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Volume"] = v193
			})
			v_u_43 = v194
			v194:Play()
		else
			v_u_41.Volume = v193
		end
	else
		return
	end
end
v_u_1.ApplyMapLighting = v46
function v_u_1.ApplyMenuSceneLighting() -- name: ApplyMenuSceneLighting
	-- upvalues: (copy) v_u_56, (copy) v_u_20, (ref) v_u_44, (copy) v_u_3, (copy) v_u_5
	local v195 = v_u_56()
	if v195 then
		local v196 = v195.Name
		local v197 = v_u_20:FindFirstChild(v196)
		if v197 then
			v_u_44 = v_u_3.ApplyScene(v196, v197)
		else
			warn((("[MenuSceneController]: No lighting found for scene \"%*\""):format(v196)))
		end
		v_u_5.GlobalShadows = true
	end
end
function v_u_1.GetMenuCharacterTeam() -- name: GetMenuCharacterTeam
	-- upvalues: (ref) v_u_31
	return v_u_31 == "CT" and "Counter-Terrorists" or (v_u_31 == "T" and "Terrorists" or nil)
end
function v_u_1.CreateStandaloneCharacter(p198) -- name: CreateStandaloneCharacter
	-- upvalues: (copy) v_u_23, (copy) v_u_21, (copy) v_u_2, (copy) v_u_84
	local v199 = p198 or (math.random(1, 2) == 1 and "CT" or "T")
	local v200 = v_u_23[v199]
	local v201 = v_u_21:FindFirstChild(v200.Character)
	if not v201 then
		warn((("[MenuSceneController]: Character \"%*\" not found"):format(v200.Character)))
		return nil
	end
	local v202 = v201:Clone()
	v202.Name = "StandaloneCharacter"
	v202.Parent = v_u_2
	v_u_84(v202, v199, true)
	return v202
end
local function v_u_203() -- name: showIfNeeded
	-- upvalues: (copy) v_u_67, (copy) v_u_1
	if v_u_67() then
		v_u_1.ShowMenuScene()
	end
end
local function v_u_204() -- name: recheckLater
	-- upvalues: (copy) v_u_203
	task.delay(0.1, v_u_203)
end
function v_u_1.Initialize() -- name: Initialize
	-- upvalues: (copy) v_u_11, (copy) v_u_16, (copy) v_u_45, (copy) v_u_164, (copy) v_u_67, (copy) v_u_1, (ref) v_u_13, (copy) v_u_2, (copy) v_u_28, (copy) v_u_203, (copy) v_u_7, (copy) v_u_204, (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (copy) v_u_113, (copy) v_u_84, (copy) v_u_117, (copy) v_u_33
	v_u_11.CreateListener(v_u_16, "Settings.Video.Presets.Global Shadows", v_u_45)
	v_u_11.CreateListener(v_u_16, "Settings.Audio.Audio.Main Menu Ambience Volume", v_u_164)
	v_u_11.CreateListener(v_u_16, "Settings.Audio.Audio.Master Volume", v_u_164)
	if v_u_67() then
		v_u_1.ShowMenuScene()
	end
	task.defer(function()
		-- upvalues: (ref) v_u_13, (ref) v_u_2
		if not v_u_13 then
			v_u_13 = require(v_u_2.Controllers.EndScreenController)
		end
	end)
	v_u_28.observeCharacter(v_u_16, function(p_u_205, p206)
		-- upvalues: (ref) v_u_203, (ref) v_u_67, (ref) v_u_1
		if p206 and p206 ~= p_u_205 then
			task.delay(0.1, v_u_203)
		end
		if not p_u_205 then
			return function() end
		end
		if v_u_67() then
			v_u_1.ShowMenuScene()
		else
			v_u_1.StopMenuMusic()
			v_u_1.HideMenuScene()
		end
		local v_u_207 = p_u_205:GetAttributeChangedSignal("Dead"):Connect(function()
			-- upvalues: (copy) p_u_205, (ref) v_u_203
			if p_u_205:GetAttribute("Dead") == true then
				task.delay(0.1, v_u_203)
			end
		end)
		return function()
			-- upvalues: (copy) v_u_207
			v_u_207:Disconnect()
		end
	end)
	v_u_7.observeAttribute(v_u_16, "IsSpectating", function(p208)
		-- upvalues: (ref) v_u_1, (ref) v_u_67, (ref) v_u_203
		if p208 then
			v_u_1.HideMenuScene()
		elseif v_u_67() then
			v_u_1.ShowMenuScene()
		end
		return v_u_203
	end)
	v_u_7.observeAttribute(v_u_16, "Team", function(p209)
		-- upvalues: (ref) v_u_1, (ref) v_u_67, (ref) v_u_204
		if p209 == "Counter-Terrorists" or p209 == "Terrorists" then
			v_u_1.HideMenuScene()
		elseif v_u_67() then
			v_u_1.ShowMenuScene()
		end
		return v_u_204
	end)
	local function v214() -- name: updateMenuCharacterLoadout
		-- upvalues: (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (ref) v_u_113, (ref) v_u_84, (ref) v_u_117
		if v_u_30 and v_u_31 then
			if v_u_32 and v_u_32.Parent then
				v_u_32:Destroy()
				v_u_32 = nil
			end
			local v210 = v_u_30:FindFirstChild("RightHand")
			local v211 = v210 and v210:FindFirstChild("WeaponAttachment")
			if v211 then
				v211:Destroy()
			end
			local v212 = v_u_30:FindFirstChild("CharacterArmor")
			if v212 then
				for _, v213 in ipairs(v212:GetChildren()) do
					if not (v213:IsA("BasePart") and v213:FindFirstChild("GloveAttachment")) then
						continue
					end
					v213:Destroy()
				end
			end
			v_u_32 = v_u_113(v_u_30, v_u_31, true)
			v_u_84(v_u_30, v_u_31, true)
			v_u_117(v_u_30)
		end
	end
	local v_u_215 = v_u_11.CreateListener(v_u_16, "Loadout", v214)
	v_u_33:Add(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_16, (copy) v_u_215
		v_u_11.RemoveListener(v_u_16, "Loadout", v_u_215)
	end, true, "LoadoutListener")
	local v216 = require(v_u_2.Database.Components.GameState)
	local v_u_217 = require(v_u_2.Controllers.SpectateController)
	v216.ListenToState(function(_, p218)
		-- upvalues: (ref) v_u_16, (copy) v_u_217, (ref) v_u_67, (ref) v_u_1
		if p218 == "Game Ending" or p218 == "Map Voting" then
			if v_u_16:GetAttribute("IsSpectating") then
				v_u_217.Stop(false, true)
			end
			if v_u_67() then
				v_u_1.ShowMenuScene()
			end
		end
	end)
end
function v_u_1.Start() -- name: Start end
return v_u_1
-- NIGHT Analyzer | ReplicatedStorage.Controllers.SoundController
-- ModuleScript | 719 linhas | 20917 bytes | hash 15da160b

local v1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("CollectionService")
local v4 = game:GetService("Players")
local v5 = game:GetService("Workspace")
local v_u_6 = v4.LocalPlayer
local v_u_7 = require(v_u_2.Database.Security.Remotes)
local v_u_8 = require(v_u_2.Database.Security.Router)
local v_u_9 = require(v_u_2.Controllers.DataController)
local v_u_10 = require(v_u_2.Controllers.RunServiceController)
local v_u_11 = require(v_u_2.Classes.Sound)
local v_u_12 = require(v_u_2.Interface.MenuState)
local v_u_13 = require(v_u_2.Shared.DebugFlags)
local v_u_14 = require(v_u_2.Database.Components.GameState)
local v_u_15 = require(v_u_2.Components.Common.CharacterResolver)
local v_u_16 = require(v_u_2.Components.Common.IsSurvivalMode)
local v_u_17 = require(v_u_2.Components.Common.VFXLibary.FlashEffect)
local v_u_18 = require(script.MovementSounds)
local v_u_19 = v5.CurrentCamera
local v_u_20 = {}
local v_u_21 = {
	"Knife",
	"Bayonet",
	"Karambit",
	"Daggers"
}
local v_u_22 = {
	["Headshot"] = 1,
	["Humiliation"] = 2,
	["MultiKill"] = 3,
	["KillSpree"] = 4,
	["Rampage"] = 5,
	["Dominating"] = 6,
	["Monster Kill"] = 7,
	["LudicrusKill"] = 8,
	["Unstoppable"] = 9,
	["Godlike"] = 10
}
local v_u_23 = {
	[2] = "MultiKill",
	[3] = "KillSpree",
	[4] = "Rampage",
	[5] = "Dominating",
	[6] = "Monster Kill",
	[7] = "LudicrusKill",
	[8] = "Unstoppable",
	[9] = "Godlike"
}
local v_u_24 = 0
local v_u_25 = nil
local v_u_26 = 0
local v_u_27 = nil
local function v_u_30(p28) -- name: isKnifeWeapon
	-- upvalues: (copy) v_u_21
	for _, v29 in ipairs(v_u_21) do
		if not string.find(p28, v29) then
			continue
		end
		return true
	end
	return false
end
local function v_u_36(p31, p_u_32, p33) -- name: listenWhileAlive
	-- upvalues: (copy) v_u_9, (copy) v_u_6
	local v_u_34 = v_u_9.CreateListener(v_u_6, p_u_32, p33)
	local v_u_35 = v_u_9.CreateListener(v_u_6, "Settings.Audio.Audio.Master Volume", p33)
	p31.Destroying:Once(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_6, (copy) p_u_32, (copy) v_u_34, (copy) v_u_35
		v_u_9.RemoveListener(v_u_6, p_u_32, v_u_34)
		v_u_9.RemoveListener(v_u_6, "Settings.Audio.Audio.Master Volume", v_u_35)
	end)
end
local function v_u_42(p37) -- name: updateBombPlantedMusicVolume
	-- upvalues: (ref) v_u_27, (copy) v_u_9, (copy) v_u_6
	if v_u_27 and v_u_27.Parent then
		local v38 = (tonumber(p37) or 50) / 50
		local v39 = v_u_9.Get(v_u_6, "Settings.Audio.Audio.Master Volume") or 100
		local v40 = (tonumber(v39) or 100) / 100
		local v41 = v_u_27:GetAttribute("BaseVolume")
		if typeof(v41) ~= "number" then
			v41 = v_u_27.Volume
		end
		v_u_27.Volume = v41 * v38 * v40
	end
end
v1.SetBombPlantedMusicVolume = v_u_42
function v1.GetWeaponShootRange(p43, p44) -- name: GetWeaponShootRange
	-- upvalues: (copy) v_u_20, (copy) v_u_2
	local v45
	if v_u_20[p43] then
		v45 = v_u_20[p43]
	else
		local v46 = v_u_2.Database.Audio.Weapons:FindFirstChild(p43)
		if v46 then
			local v47 = require
			local v48
			v48, v45 = pcall(v47, v46)
			if v48 and v45 then
				v_u_20[p43] = v45
			else
				v45 = nil
			end
		else
			v45 = nil
		end
	end
	if v45 then
		if p44 and v45.Silencer then
			local v49 = v45.Silencer
			return v49 and (v49.Properties and v49.Properties.RollOffMaxDistance) or 50
		else
			local v50 = v45.Shoot
			return v50 and (v50.Properties and v50.Properties.RollOffMaxDistance) or 120
		end
	else
		return p44 and 50 or 120
	end
end
function v1.GetMeleeRange(p51) -- name: GetMeleeRange
	-- upvalues: (copy) v_u_20, (copy) v_u_2
	local v52
	if v_u_20[p51] then
		v52 = v_u_20[p51]
	else
		local v53 = v_u_2.Database.Audio.Weapons:FindFirstChild(p51)
		if v53 then
			local v54 = require
			local v55
			v55, v52 = pcall(v54, v53)
			if v55 and v52 then
				v_u_20[p51] = v52
			else
				v52 = nil
			end
		else
			v52 = nil
		end
	end
	if not v52 then
		return 50
	end
	local v56 = v52.HitOne
	return v56 and (v56.Properties and v56.Properties.RollOffMaxDistance) or 50
end
function v1.Initialize() -- name: Initialize
	-- upvalues: (copy) v_u_2, (copy) v_u_11, (copy) v_u_8, (copy) v_u_12, (copy) v_u_19, (copy) v_u_9, (copy) v_u_6, (copy) v_u_10, (copy) v_u_14, (copy) v_u_16, (copy) v_u_36, (copy) v_u_7, (copy) v_u_17, (copy) v_u_13, (ref) v_u_27, (copy) v_u_15, (copy) v_u_42, (copy) v_u_3, (ref) v_u_24, (ref) v_u_25, (ref) v_u_26, (copy) v_u_23, (copy) v_u_22, (copy) v_u_30
	for _, v57 in ipairs(v_u_2.Database.Audio:GetDescendants()) do
		if not v57:IsA("ModuleScript") then
			continue
		end
		v_u_11.createSoundGroup(v57)
	end
	task.spawn(v_u_11.WarmPersistentSounds)
	v_u_8.observerRouter("RunRoundSound", function(p58)
		-- upvalues: (ref) v_u_12, (ref) v_u_11, (ref) v_u_19
		if v_u_12.GetCurrentScreen() == nil then
			local v59 = {
				["Parent"] = v_u_19,
				["Name"] = p58
			}
			return v_u_11.new("Round"):playOneTime(v59)
		end
	end)
	v_u_8.observerRouter("PlayCountdownTimer", function()
		-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_12, (ref) v_u_11
		local v60 = (v_u_9.Get(v_u_6, "Settings.Audio.Music.Main Menu Volume") or 100) / 100
		if v_u_12.GetCurrentScreen() == nil and v60 > 0 then
			v_u_11.new("Interface"):playOneTime({
				["Parent"] = nil,
				["Name"] = "Countdown Timer",
				["Parent"] = v_u_6.PlayerGui
			}, v60)
		end
		return nil
	end)
	local v_u_61 = nil
	local v_u_62 = nil
	local v_u_63 = nil
	local function v_u_74(p64) -- name: updateBuyPhaseVolume
		-- upvalues: (ref) v_u_61, (ref) v_u_9, (ref) v_u_6, (ref) v_u_63, (ref) v_u_62
		if v_u_61 and v_u_61.Parent then
			local v65 = (v_u_9.Get(v_u_6, "Settings.Audio.Music.Round Start Volume") or 50) / 50
			local v66 = (v_u_9.Get(v_u_6, "Settings.Audio.Audio.Master Volume") or 100) / 100
			local v67 = v_u_61:GetAttribute("BaseVolume") or v_u_61.Volume
			local v68
			if p64 and v_u_63 then
				local v69 = tick() - v_u_63
				if v69 < 6 then
					v68 = 1
				else
					local v70 = 1 - (v69 - 6) * 0.2
					v68 = math.max(0, v70)
				end
			else
				v68 = 1
			end
			v_u_61.Volume = v67 * v65 * v66 * v68
			if p64 and v_u_63 then
				local v71 = tick() - v_u_63
				local v72
				if v71 < 6 then
					v72 = 1
				else
					local v73 = 1 - (v71 - 6) * 0.2
					v72 = math.max(0, v73)
				end
				if v72 <= 0 and v_u_61 then
					if v_u_62 then
						v_u_62:Disconnect()
						v_u_62 = nil
					end
					if v_u_61.Parent then
						v_u_61:Stop()
						v_u_61:Destroy()
					end
					v_u_61 = nil
					v_u_63 = nil
				end
			end
		end
	end
	local function v_u_85() -- name: playBuyPhaseSound
		-- upvalues: (ref) v_u_6, (ref) v_u_61, (ref) v_u_62, (ref) v_u_63, (ref) v_u_9, (ref) v_u_11, (ref) v_u_19, (ref) v_u_10, (copy) v_u_74
		local v75 = v_u_6:GetAttribute("Team")
		if v75 == "Counter-Terrorists" or v75 == "Terrorists" then
			if v_u_61 then
				if v_u_62 then
					v_u_62:Disconnect()
					v_u_62 = nil
				end
				if v_u_61.Parent then
					v_u_61:Stop()
					v_u_61:Destroy()
				end
				v_u_61 = nil
				v_u_63 = nil
			end
			local v76 = (v_u_9.Get(v_u_6, "Settings.Audio.Music.Round Start Volume") or 50) / 50
			local v77 = {
				["Parent"] = nil,
				["Name"] = "Buy Phase",
				["Parent"] = v_u_19
			}
			v_u_61 = v_u_11.new("Round"):play(v77, v76)
			if v_u_61 then
				local v_u_78 = v_u_61
				v_u_78.Destroying:Once(function()
					-- upvalues: (ref) v_u_61, (copy) v_u_78, (ref) v_u_63
					if v_u_61 == v_u_78 then
						v_u_61 = nil
						v_u_63 = nil
					end
				end)
				local v79 = (v_u_9.Get(v_u_6, "Settings.Audio.Audio.Master Volume") or 100) / 100
				local v80 = v_u_78.Volume
				if v76 > 0 and v79 > 0 then
					v80 = v80 / (v76 * v79) or v80
				end
				v_u_78:SetAttribute("BaseVolume", v80)
				v_u_63 = tick()
				task.spawn(function()
					-- upvalues: (ref) v_u_62, (ref) v_u_10, (ref) v_u_61, (ref) v_u_63, (ref) v_u_74
					v_u_62 = v_u_10.BindToHeartbeat("SoundController.BuyPhaseFade", function()
						-- upvalues: (ref) v_u_61, (ref) v_u_62, (ref) v_u_63, (ref) v_u_74
						if not (v_u_61 and v_u_61.Parent) then
							if v_u_62 then
								v_u_62:Disconnect()
								v_u_62 = nil
							end
							return
						end
						if not v_u_63 then
							return
						end
						local v81 = tick() - v_u_63
						local v82 = v81 >= 6
						v_u_74(v82)
						if v82 then
							if v_u_61 and v_u_61.Parent then
								local v83
								if v81 < 6 then
									v83 = 1
								else
									local v84 = 1 - (v81 - 6) * 0.2
									v83 = math.max(0, v84)
								end
								if v83 > 0 then
									return
								end
								if v_u_62 then
									v_u_62:Disconnect()
									v_u_62 = nil
								end
							elseif v_u_62 then
								v_u_62:Disconnect()
								v_u_62 = nil
							end
						end
					end)
				end)
			end
		else
			return
		end
	end
	v_u_14.ListenToState(function(_, p86)
		-- upvalues: (copy) v_u_85, (ref) v_u_61, (ref) v_u_62, (ref) v_u_63
		if p86 == "Buy Period" then
			v_u_85()
		elseif v_u_61 then
			if v_u_62 then
				v_u_62:Disconnect()
				v_u_62 = nil
			end
			if v_u_61.Parent then
				v_u_61:Stop()
				v_u_61:Destroy()
			end
			v_u_61 = nil
			v_u_63 = nil
		end
	end)
	local v_u_87 = nil
	local function v_u_90() -- name: updateSurvivalMusicVolume
		-- upvalues: (ref) v_u_87, (ref) v_u_9, (ref) v_u_6
		local v88 = v_u_87
		if v88 and v88.Parent then
			local v89 = v88:GetAttribute("BaseVolume")
			if typeof(v89) ~= "number" then
				v89 = v88.Volume
			end
			v88.Volume = v89 * ((v_u_9.Get(v_u_6, "Settings.Audio.Music.Round Action Volume") or 50) / 50) * ((v_u_9.Get(v_u_6, "Settings.Audio.Audio.Master Volume") or 100) / 100)
		end
	end
	local function v_u_96() -- name: syncSurvivalMusic
		-- upvalues: (ref) v_u_16, (ref) v_u_6, (ref) v_u_14, (ref) v_u_87, (ref) v_u_11, (ref) v_u_19, (ref) v_u_9, (ref) v_u_36, (copy) v_u_90
		local v91
		if v_u_16() then
			local v92 = v_u_6:GetAttribute("Team")
			if v92 == "Counter-Terrorists" or v92 == "Terrorists" then
				local v93 = v_u_14.GetState()
				v91 = v93 == "Round In Progress" and true or v93 == "Buy Period"
			else
				v91 = false
			end
		else
			v91 = false
		end
		if v91 then
			if not (v_u_87 and v_u_87.Parent) then
				local v94 = {
					["Parent"] = nil,
					["Name"] = "Music",
					["Parent"] = v_u_19
				}
				local v95 = v_u_11.new("Survival"):play(v94, (v_u_9.Get(v_u_6, "Settings.Audio.Music.Round Action Volume") or 50) / 50)
				v_u_87 = v95
				if v95 then
					v_u_36(v95, "Settings.Audio.Music.Round Action Volume", v_u_90)
				end
			end
		else
			if v_u_87 then
				if v_u_87.Parent then
					v_u_87:Stop()
					v_u_87:Destroy()
				end
				v_u_87 = nil
			end
			return
		end
	end
	v_u_14.ListenToState(function()
		-- upvalues: (copy) v_u_96
		v_u_96()
	end)
	v_u_6:GetAttributeChangedSignal("Team"):Connect(v_u_96)
	workspace:GetAttributeChangedSignal("Gamemode"):Connect(v_u_96)
	v_u_96()
	local function v97() -- name: onBuyPhaseSettingChanged
		-- upvalues: (copy) v_u_74, (ref) v_u_62
		v_u_74(v_u_62 ~= nil)
	end
	v_u_9.CreateListener(v_u_6, "Settings.Audio.Music.Round Start Volume", v97)
	v_u_9.CreateListener(v_u_6, "Settings.Audio.Audio.Master Volume", v97)
	v_u_7.Sound.ReplicateSound.Listen(function(p98)
		-- upvalues: (ref) v_u_17, (ref) v_u_13, (ref) v_u_27, (ref) v_u_11, (ref) v_u_15, (ref) v_u_6, (ref) v_u_12, (ref) v_u_14, (ref) v_u_9, (ref) v_u_36, (ref) v_u_42
		local v99 = v_u_17.GetAudioFadeMultiplier()
		if v_u_13.IsEnabled("WeaponFX") then
			local v100
			if p98 and p98.Name then
				local v101 = p98.Name
				v100 = tostring(v101) or ""
			else
				v100 = ""
			end
			local v102
			if p98 and p98.Class then
				local v103 = p98.Class
				v102 = tostring(v103) or ""
			else
				v102 = ""
			end
			local v104 = string.lower(v100)
			if string.find(v104, "shoot", 1, true) or string.find(v104, "fire", 1, true) then
				local v105 = warn
				local v106 = "[WeaponFX][Client][Sound] recv class=%s name=%s flashed=%s parent=%s position=%s path=%s"
				local v107 = v_u_17.IsFlashed
				local v108 = tostring(v107())
				local v109
				if p98 then
					v109 = p98.Parent
				else
					v109 = p98
				end
				local v110 = tostring(v109)
				local v111
				if p98 then
					v111 = p98.Position
				else
					v111 = p98
				end
				local v112 = tostring(v111)
				local v113
				if p98 then
					v113 = p98.Path
				else
					v113 = p98
				end
				v105(v106:format(v102, v100, v108, v110, v112, (tostring(v113))))
			end
		end
		local v114
		if p98.Name == "Bomb Planted Music" then
			v114 = p98.Class == "Counter-Terrorists"
		else
			v114 = false
		end
		if v114 and v_u_27 then
			if v_u_27.Parent then
				v_u_27:Stop()
				v_u_27:Destroy()
			end
			v_u_27 = nil
		end
		if p98.Position then
			local v115 = v_u_11.new(p98.Class)
			local v116 = {
				["Position"] = p98.Position,
				["Class"] = p98.Class,
				["Name"] = p98.Name
			}
			local v117 = p98.Duration
			v115:PlaySoundAtPosition(v116, tonumber(v117), v99)
			return
		elseif p98.Parent or p98.Path then
			local v118 = p98.Parent
			if v118 and (v118:IsA("BasePart") and v118.Name == "Head") then
				local v119 = v118.Parent
				if v119 and (v119:IsA("Model") and (v119:IsDescendantOf(workspace) and v_u_15.getPlayerFromCharacter(v119) == v_u_6)) then
					if v_u_13.IsEnabled("WeaponFX") then
						local v120 = warn
						local v121 = p98.Name
						local v122 = tostring(v121)
						local v123 = p98.Class
						v120(("[WeaponFX][Client][Sound] skipped local duplicate head sound name=%s class=%s"):format(v122, (tostring(v123))))
					end
					return
				end
			end
			if (p98.Name == "Bomb Planted" or (p98.Name == "Bomb Defused" or p98.Name == "Hostage Rescued")) and v_u_12.GetCurrentScreen() ~= nil then
				return
			else
				local v124
				if p98.Name == "Counter-Terrorists Win" or p98.Name == "Terrorists Win" then
					v124 = p98.Class == "Round"
				else
					v124 = false
				end
				if v114 then
					if v_u_14.GetState() ~= "Round In Progress" or v_u_12.GetCurrentScreen() ~= nil then
						return
					end
					v99 = v99 * ((v_u_9.Get(v_u_6, "Settings.Audio.Music.Bomb/Hostage Volume") or 50) / 50)
				elseif v124 then
					if v_u_12.GetCurrentScreen() ~= nil then
						return
					end
					v99 = v99 * ((v_u_9.Get(v_u_6, "Settings.Audio.Music.Round End Volume") or 50) / 50)
				end
				local v_u_125 = v_u_11.new(p98.Class):playOneTime({
					["Parent"] = p98.Parent,
					["Name"] = p98.Name,
					["Path"] = p98.Path
				}, v99)
				if v_u_125 then
					if v124 then
						local v126 = (v_u_9.Get(v_u_6, "Settings.Audio.Music.Round End Volume") or 50) / 50
						local v127 = (v_u_9.Get(v_u_6, "Settings.Audio.Audio.Master Volume") or 100) / 100
						local v_u_128 = v_u_125.Volume
						if v126 > 0 and v127 > 0 then
							v_u_128 = v_u_128 / (v126 * v127) or v_u_128
						end
						v_u_125:SetAttribute("BaseVolume", v_u_128)
						v_u_36(v_u_125, "Settings.Audio.Music.Round End Volume", function()
							-- upvalues: (copy) v_u_125, (ref) v_u_9, (ref) v_u_6, (copy) v_u_128
							if v_u_125 and v_u_125.Parent then
								local v129 = (v_u_9.Get(v_u_6, "Settings.Audio.Music.Round End Volume") or 50) / 50
								local v130 = (v_u_9.Get(v_u_6, "Settings.Audio.Audio.Master Volume") or 100) / 100
								v_u_125.Volume = (v_u_125:GetAttribute("BaseVolume") or v_u_128) * v129 * v130
							end
						end)
					elseif v114 then
						v_u_27 = v_u_125
						local v131 = (v_u_9.Get(v_u_6, "Settings.Audio.Music.Bomb/Hostage Volume") or 50) / 50
						local v132 = (v_u_9.Get(v_u_6, "Settings.Audio.Audio.Master Volume") or 100) / 100
						local v133 = v_u_125.Volume
						if v131 > 0 and v132 > 0 then
							v133 = v133 / (v131 * v132) or v133
						end
						v_u_125:SetAttribute("BaseVolume", v133)
						v_u_36(v_u_125, "Settings.Audio.Music.Bomb/Hostage Volume", function()
							-- upvalues: (ref) v_u_27, (ref) v_u_42, (ref) v_u_9, (ref) v_u_6
							if v_u_27 and v_u_27.Parent then
								v_u_42(v_u_9.Get(v_u_6, "Settings.Audio.Music.Bomb/Hostage Volume") or 50)
							end
						end)
					end
				else
					return
				end
			end
		else
			return
		end
	end)
	local function v_u_136() -- name: setupBombDefuseListener
		-- upvalues: (ref) v_u_3, (ref) v_u_27
		local v_u_134 = v_u_3:GetTagged("Bomb")[1]
		if v_u_134 and v_u_134:IsDescendantOf(workspace) then
			local v_u_135 = nil
			v_u_135 = v_u_134:GetAttributeChangedSignal("Defused"):Connect(function()
				-- upvalues: (copy) v_u_134, (ref) v_u_27, (ref) v_u_135
				if v_u_134:GetAttribute("Defused") then
					if v_u_27 then
						if v_u_27.Parent then
							v_u_27:Stop()
							v_u_27:Destroy()
						end
						v_u_27 = nil
					end
					if v_u_135 then
						v_u_135:Disconnect()
					end
				end
			end)
		end
	end
	v_u_3:GetInstanceAddedSignal("Bomb"):Connect(function()
		-- upvalues: (copy) v_u_136
		v_u_136()
	end)
	task.defer(v_u_136)
	v_u_14.ListenToState(function(_, p137)
		-- upvalues: (ref) v_u_27
		if p137 ~= "Round In Progress" and v_u_27 then
			if v_u_27.Parent then
				v_u_27:Stop()
				v_u_27:Destroy()
			end
			v_u_27 = nil
		end
	end)
	v_u_7.UI.UIPlayerKilled.Listen(function(p138)
		-- upvalues: (ref) v_u_6, (ref) v_u_24, (ref) v_u_25, (ref) v_u_26, (ref) v_u_23, (ref) v_u_22, (ref) v_u_30, (ref) v_u_11
		if workspace:GetAttribute("Gamemode") == "Deathmatch" then
			local v139 = v_u_6.UserId
			local v140 = tostring(v139)
			if p138.Victim == v140 then
				v_u_24 = 0
				if v_u_25 then
					local v141 = v_u_25
					v_u_25 = nil
					v_u_26 = 0
					if v141.Parent then
						v141:Stop()
						v141:Destroy()
					end
				end
				return
			elseif p138.Killer == v140 then
				v_u_24 = v_u_24 + 1
				local v142 = v_u_24
				local v_u_143 = v_u_23[math.min(v142, 9)]
				local v_u_144 = v_u_143 and (v_u_22[v_u_143] or 0) or 0
				if p138.Headshot and v_u_144 < v_u_22.Headshot then
					v_u_144 = v_u_22.Headshot
					v_u_143 = "Headshot"
				end
				if p138.Weapon and (v_u_30(p138.Weapon) and v_u_144 < v_u_22.Humiliation) then
					v_u_144 = v_u_22.Humiliation
					v_u_143 = "Humiliation"
				end
				if v_u_143 and v_u_144 >= v_u_26 then
					if v_u_25 then
						local v145 = v_u_25
						v_u_25 = nil
						v_u_26 = 0
						if v145.Parent then
							v145:Stop()
							v145:Destroy()
						end
					end
					task.delay(0.2, function()
						-- upvalues: (copy) v_u_144, (ref) v_u_26, (ref) v_u_25, (ref) v_u_11, (ref) v_u_6, (copy) v_u_143
						if v_u_144 >= v_u_26 then
							if v_u_25 then
								local v146 = v_u_25
								v_u_25 = nil
								v_u_26 = 0
								if v146.Parent then
									v146:Stop()
									v146:Destroy()
								end
							end
							local v_u_147 = v_u_11.new("Deathmatch"):play({
								["Parent"] = v_u_6.PlayerGui,
								["Name"] = v_u_143
							})
							if v_u_147 then
								v_u_25 = v_u_147
								v_u_26 = v_u_144
								local function v148() -- name: clearIfCurrent
									-- upvalues: (ref) v_u_25, (copy) v_u_147, (ref) v_u_26
									if v_u_25 == v_u_147 then
										v_u_25 = nil
										v_u_26 = 0
									end
								end
								v_u_147.Ended:Once(v148)
								v_u_147.Destroying:Once(v148)
							end
						end
					end)
				end
			else
				return
			end
		else
			return
		end
	end)
	v_u_7.Sound.StopSoundAtPosition.Listen(function(p149)
		local v150 = workspace:FindFirstChild("Debris")
		if v150 then
			for _, v151 in ipairs(v150:GetChildren()) do
				if v151.Name ~= "Sound" or (not v151:IsA("BasePart") or (v151.Position - p149.Position).Magnitude > p149.Radius) then
					continue
				end
				v151:Destroy()
			end
		end
	end)
	v_u_8.observerRouter("UpdatePlayerNoiseCone", function()
		return nil
	end)
end
function v1.Start() -- name: Start
	-- upvalues: (copy) v_u_18, (copy) v_u_6, (copy) v_u_15, (ref) v_u_24, (ref) v_u_25, (ref) v_u_26, (copy) v_u_2, (copy) v_u_11, (copy) v_u_10
	local v_u_152 = v_u_18.new(v_u_6)
	v_u_15.observeCharacter(v_u_6, function(p153)
		-- upvalues: (ref) v_u_24, (ref) v_u_25, (ref) v_u_26, (copy) v_u_152
		if p153 then
			v_u_24 = 0
			if v_u_25 then
				local v154 = v_u_25
				v_u_25 = nil
				v_u_26 = 0
				if v154.Parent then
					v154:Stop()
					v154:Destroy()
				end
			end
		end
		v_u_152:SetCharacter(p153)
		return function()
			-- upvalues: (ref) v_u_152
			v_u_152:SetCharacter(nil)
		end
	end)
	local v155 = require(v_u_2.Controllers.MenuSceneController)
	local v_u_156 = {
		v155,
		{
			["IsActive"] = v155.IsTeamSelectSceneActive
		},
		require(v_u_2.Controllers.CaseSceneController),
		require(v_u_2.Controllers.InspectController),
		(require(v_u_2.Controllers.BlackMarketSceneController))
	}
	local v_u_157 = v_u_11.GameplaySoundGroup
	local v_u_158 = false
	v_u_10.BindToHeartbeat("SoundController.MovementSounds", function(p159)
		-- upvalues: (copy) v_u_152, (copy) v_u_156, (ref) v_u_158, (copy) v_u_157
		v_u_152:Update(p159)
		for _, v160 in v_u_156 do
			if not v160.IsActive() then
				continue
			end
			v161 = true
		end
		local v161 = false
		if v161 ~= v_u_158 then
			v_u_158 = v161
			v_u_157.Volume = v161 and 0 or 1
		end
	end)
end
return v1
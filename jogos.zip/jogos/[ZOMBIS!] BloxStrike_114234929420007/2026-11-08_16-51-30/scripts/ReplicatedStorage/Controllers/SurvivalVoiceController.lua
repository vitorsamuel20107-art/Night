-- NIGHT Analyzer | ReplicatedStorage.Controllers.SurvivalVoiceController
-- ModuleScript | 502 linhas | 13934 bytes | hash 6fbb1482

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("SoundService")
local v_u_4 = game:GetService("Players")
local v_u_5 = require(v_u_2.Classes.Sound)
local v_u_6 = require(v_u_2.Controllers.RunServiceController)
local v_u_7 = require(v_u_2.Controllers.HordeController)
local v_u_8 = require(v_u_2.Controllers.GeneratorController)
local v_u_9 = require(v_u_2.Components.Common.SurvivalState)
local v_u_10 = require(v_u_2.Components.Common.SurvivalDowned)
local v_u_11 = require(v_u_2.Components.Common.IsSurvivalMode)
local v_u_12 = require(v_u_2.Components.Common.SurvivalBuyRules)
local v_u_13 = require(v_u_2.Components.Common.CharacterResolver)
local v_u_14 = {
	["Surrounded"] = 30,
	["Reloading"] = 20,
	["Headshot Streak"] = 15,
	["Upgrade Reminder"] = 60,
	["Captain Laugh Gasp"] = 45,
	["Captain Laugh Hysterical"] = 90,
	["Generator A Under Attack"] = 25,
	["Generator B Under Attack"] = 25
}
local v_u_15 = NumberRange.new(20, 120)
local v_u_16 = {
	["Rifle"] = true,
	["Heavy"] = true
}
local v_u_17 = {
	["Kevlar"] = true,
	["Kevlar + Helmet"] = true
}
local v_u_18 = v_u_4.LocalPlayer
local v_u_19 = Random.new()
local v_u_20 = nil
local v_u_21 = false
local v_u_22 = 0
local v_u_23 = {}
local v_u_24 = {}
local v_u_25 = {}
local v_u_26 = {}
local v_u_27 = {}
local v_u_28 = false
local v_u_29 = false
local v_u_30 = 0
local v_u_31 = 0
local v_u_32 = nil
local v_u_33 = 100
local v_u_34 = (-1 / 0)
local v_u_35 = 100
local v_u_36 = 0
local v_u_37 = 0
local v_u_38 = 0
local v_u_39 = 0
local v_u_40 = 0
local v_u_41 = nil
local function v_u_48(p42) -- name: speak
	-- upvalues: (ref) v_u_20, (copy) v_u_3, (copy) v_u_24, (ref) v_u_21, (ref) v_u_22, (copy) v_u_23, (copy) v_u_48
	local v43 = v_u_20
	if v43 then
		local v44 = v43:playOneTime({
			["Name"] = p42,
			["Parent"] = v_u_3
		})
		if v44 then
			v_u_24[p42] = os.clock()
			v_u_21 = true
			v_u_22 = v_u_22 + 1
			local v_u_45 = v_u_22
			local function v47() -- name: finished
				-- upvalues: (copy) v_u_45, (ref) v_u_22, (ref) v_u_21, (ref) v_u_23, (ref) v_u_48
				if v_u_45 == v_u_22 then
					v_u_21 = false
					if #v_u_23 > 0 then
						local v46 = table.remove(v_u_23, 1)
						if os.clock() - v46.At > 4 then
							continue
						end
						v_u_48(v46.Name)
					end
				else
					return
				end
			end
			v44.Ended:Once(v47)
			task.delay(6, v47)
		end
	else
		return
	end
end
local function v_u_58(p49) -- name: onGeneratorState
	-- upvalues: (copy) v_u_25, (copy) v_u_26, (copy) v_u_27, (copy) v_u_1
	local v50 = p49.Key
	if v50 == "" then
		table.clear(v_u_25)
		table.clear(v_u_26)
		table.clear(v_u_27)
		return
	else
		local v51 = v_u_25[v50]
		v_u_25[v50] = p49.Destroyed
		if v51 == nil then
			local v52 = v_u_27
			local v53
			if p49.MaxHealth > 0 then
				v53 = p49.Health / p49.MaxHealth < 0.25
			else
				v53 = false
			end
			v52[v50] = v53
			return
		elseif p49.Destroyed then
			if not v51 then
				v_u_1.Play(("Generator %* Offline"):format(v50), 3)
				local v54 = 0
				for _, v55 in v_u_25 do
					if v55 then
						continue
					end
					v54 = v54 + 1
				end
				if v54 == 1 then
					v_u_1.Play("One Generator Left", 3)
				end
			end
			return
		elseif p49.Drop <= 0 then
			return
		else
			local v56 = os.clock()
			local v57 = v_u_26[v50]
			v_u_26[v50] = v56
			if (p49.MaxHealth <= 0 and 1 or p49.Health / p49.MaxHealth) < 0.25 and not v_u_27[v50] then
				v_u_27[v50] = true
				v_u_1.Play(("Generator %* Failing"):format(v50), 2)
			elseif not v57 or v56 - v57 >= 15 then
				v_u_1.Play(("Generator %* Under Attack"):format(v50), 2)
			end
		end
	end
end
local function v_u_67() -- name: getPrimaries
	-- upvalues: (ref) v_u_32, (copy) v_u_2
	local v59 = v_u_32
	if v59 then
		return v59
	end
	local v60 = {}
	for _, v61 in v_u_2.Database.Custom.Weapons:GetChildren() do
		if not v61:IsA("ModuleScript") then
			continue
		end
		local v62 = require
		local v63, v64 = pcall(v62, v61)
		if not v63 or (type(v64) ~= "table" or v64.Slot ~= "Primary") then
			continue
		end
		local v65 = v64.Cost
		if type(v65) ~= "number" then
			continue
		end
		local v66 = {
			["Name"] = v61.Name,
			["Team"] = v64.Team,
			["Cost"] = v64.Cost
		}
		table.insert(v60, v66)
	end
	v_u_32 = v60
	return v60
end
local function v_u_78() -- name: hasAffordableUpgrade
	-- upvalues: (copy) v_u_18, (copy) v_u_2, (copy) v_u_67, (copy) v_u_12
	local v68 = v_u_18:GetAttribute("Money")
	if typeof(v68) ~= "number" then
		return false
	end
	local v69 = require(v_u_2.Controllers.InventoryController)
	local v70 = require(v_u_2.Database.Custom.GameStats.NumberSlots)
	local v71 = v69.getCurrentInventory()
	if v71 then
		v71 = v71[v70.Primary]
	end
	if v71 then
		v71 = v71._items[1]
	end
	local v72 = v_u_18:GetAttribute("Team")
	local v73 = 0
	local v74 = v_u_67()
	if v71 then
		for _, v75 in v74 do
			if v75.Name ~= v71.Name then
				continue
			end
			v73 = v_u_12.GetPrice(v75.Name, v75.Cost)
		end
	end
	for _, v76 in v74 do
		if v76.Team ~= "Both" and (v76.Team ~= nil and v76.Team ~= v72) then
			continue
		end
		local v77 = v_u_12.GetPrice(v76.Name, v76.Cost)
		if v73 >= v77 or v77 > v68 then
			continue
		end
		return true
	end
	return false
end
local function v_u_81() -- name: onResupplyChanged
	-- upvalues: (copy) v_u_9, (copy) v_u_1, (ref) v_u_31, (copy) v_u_13, (copy) v_u_18, (copy) v_u_10, (copy) v_u_78
	local v_u_79 = v_u_9.GetWave()
	if v_u_9.IsResupply() and v_u_79 > 1 then
		v_u_1.Play("Buy Period Start", 3)
		task.delay(12, function()
			-- upvalues: (ref) v_u_9, (copy) v_u_79, (ref) v_u_31, (ref) v_u_13, (ref) v_u_18, (ref) v_u_10, (ref) v_u_78, (ref) v_u_1
			if v_u_9.IsResupply() and (v_u_9.GetWave() == v_u_79 and v_u_31 ~= v_u_79) then
				local v80 = v_u_13.isAlivePlayer(v_u_18)
				if v80 then
					v80 = not v_u_10.IsDowned(v_u_18)
				end
				if v80 and v_u_78() then
					v_u_1.Play("Upgrade Reminder", 1)
				end
			end
		end)
	end
end
local function v_u_83() -- name: onWaveStarted
	-- upvalues: (copy) v_u_9, (copy) v_u_1, (ref) v_u_28, (ref) v_u_30, (copy) v_u_19, (copy) v_u_15
	if v_u_9.GetWaveElapsed() ~= nil then
		local v_u_82 = v_u_9.GetWave()
		v_u_1.Play("Buy Period End", 3)
		if v_u_9.IsFlamingWave() then
			task.delay(0.1, v_u_1.Play, "Captain Flaming Wave", 3)
		elseif v_u_82 >= 5 and not v_u_28 then
			v_u_28 = true
			task.delay(0.1, v_u_1.Play, "Captain Laugh Horde", 3)
		end
		if v_u_82 >= 15 and (v_u_30 ~= v_u_82 and v_u_19:NextNumber() < 0.35) then
			v_u_30 = v_u_82
			task.delay(v_u_19:NextNumber(v_u_15.Min, v_u_15.Max), function()
				-- upvalues: (ref) v_u_9, (copy) v_u_82, (ref) v_u_1
				if v_u_9.GetWave() == v_u_82 and v_u_9.GetWaveElapsed() ~= nil then
					v_u_1.Play("Captain Laugh Hysterical", 2)
				end
			end)
		end
	end
end
local function v_u_84() -- name: onWaveChanged
	-- upvalues: (copy) v_u_9, (ref) v_u_28, (ref) v_u_29, (ref) v_u_30
	if v_u_9.GetWave() <= 1 then
		v_u_28 = false
		v_u_29 = false
		v_u_30 = 0
	end
end
local function v_u_87() -- name: recountDowned
	-- upvalues: (copy) v_u_4, (copy) v_u_10, (ref) v_u_39, (copy) v_u_1
	local v85 = 0
	for _, v86 in v_u_4:GetPlayers() do
		if not v_u_10.IsDowned(v86) then
			continue
		end
		v85 = v85 + 1
	end
	if v85 >= 2 and v_u_39 < 2 then
		v_u_1.Play("Captain Laugh Gasp", 2)
	end
	v_u_39 = v85
end
local function v_u_89(p88) -- name: watchPlayer
	-- upvalues: (copy) v_u_10, (copy) v_u_87
	p88:GetAttributeChangedSignal(v_u_10.DOWNED_ATTRIBUTE):Connect(v_u_87)
end
local function v_u_91() -- name: onHealthChanged
	-- upvalues: (copy) v_u_18, (ref) v_u_33, (ref) v_u_35, (ref) v_u_34
	local v90 = v_u_18:GetAttribute("Health")
	if typeof(v90) == "number" then
		v_u_33 = v_u_35
		v_u_35 = v90
		v_u_34 = os.clock()
	end
end
local function v_u_94(p92) -- name: endKillChain
	-- upvalues: (ref) v_u_37, (ref) v_u_36, (copy) v_u_1
	if p92 == v_u_37 then
		local v93 = v_u_36
		v_u_36 = 0
		if v93 >= 5 then
			v_u_1.Play("Massacre", 1)
			return
		elseif v93 >= 3 then
			v_u_1.Play("Triple Kill", 1)
		elseif v93 == 2 then
			v_u_1.Play("Double Kill", 1)
		end
	else
		return
	end
end
local function v_u_97(p95, p96) -- name: onHitConfirmed
	-- upvalues: (copy) v_u_11, (ref) v_u_36, (ref) v_u_37, (copy) v_u_94, (ref) v_u_38, (copy) v_u_1
	if p96 and v_u_11() then
		v_u_36 = v_u_36 + 1
		v_u_37 = v_u_37 + 1
		task.delay(1.25, v_u_94, v_u_37)
		v_u_38 = not p95 and 0 or v_u_38 + 1
		if v_u_38 >= 3 then
			v_u_38 = 0
			v_u_1.Play("Headshot Streak", 1)
		end
	end
end
local function v_u_102() -- name: scanSurroundings
	-- upvalues: (ref) v_u_40, (copy) v_u_11, (copy) v_u_9, (copy) v_u_13, (copy) v_u_18, (copy) v_u_10, (copy) v_u_7, (copy) v_u_1
	local v98 = os.clock()
	if v98 - v_u_40 >= 0.5 then
		v_u_40 = v98
		if v_u_11() and v_u_9.GetWaveElapsed() ~= nil then
			local v99 = v_u_13.isAlivePlayer(v_u_18)
			if v99 then
				v99 = not v_u_10.IsDowned(v_u_18)
			end
			if v99 then
				local v100 = v_u_13.getRootPart(v_u_13.getLocalCharacter())
				local v101
				if v100 then
					v101 = v100.Position
				else
					v101 = nil
				end
				if v101 and v_u_7.CountNear(v101, 14, 8) >= 6 then
					v_u_1.Play("Surrounded", 1)
				end
				return
			end
		end
	end
end
local function v_u_104() -- name: evaluateScanning
	-- upvalues: (copy) v_u_11, (copy) v_u_9, (ref) v_u_41, (copy) v_u_6, (copy) v_u_102
	local v103 = v_u_11()
	if v103 then
		v103 = v_u_9.GetWaveElapsed() ~= nil
	end
	if v103 and not v_u_41 then
		v_u_41 = v_u_6.BindToHeartbeat("SurvivalVoiceController.Scan", v_u_102)
	elseif not v103 and v_u_41 then
		v_u_41:Disconnect()
		v_u_41 = nil
	end
end
local function v_u_106() -- name: onGamemodeChanged
	-- upvalues: (copy) v_u_11, (copy) v_u_23, (copy) v_u_9, (ref) v_u_41, (copy) v_u_6, (copy) v_u_102
	if not v_u_11() then
		table.clear(v_u_23)
	end
	local v105 = v_u_11()
	if v105 then
		v105 = v_u_9.GetWaveElapsed() ~= nil
	end
	if v105 and not v_u_41 then
		v_u_41 = v_u_6.BindToHeartbeat("SurvivalVoiceController.Scan", v_u_102)
	elseif not v105 and v_u_41 then
		v_u_41:Disconnect()
		v_u_41 = nil
	end
end
function v_u_1.Play(p107, p108) -- name: Play
	-- upvalues: (copy) v_u_14, (copy) v_u_11, (ref) v_u_20, (copy) v_u_24, (ref) v_u_21, (copy) v_u_48, (copy) v_u_23
	local v109 = v_u_14[p107] or 4
	local v110 = v_u_11()
	if v110 then
		local v111 = v_u_20
		if v111 == nil or v111.Sounds == nil then
			v110 = false
		else
			v110 = v111.Sounds:FindFirstChild(p107) ~= nil
		end
		if v110 then
			v110 = v109 <= os.clock() - (v_u_24[p107] or (-1 / 0))
		end
	end
	if v110 then
		if v_u_21 then
			for _, v112 in v_u_23 do
				if v112.Name ~= p107 then
					continue
				end
				return
			end
			local v113 = #v_u_23 + 1
			local v114 = p108 or 1
			for v115, v116 in v_u_23 do
				if v116.Priority >= v114 then
					continue
				end
				v113 = v115
			end
			local v117 = v_u_23
			local v118 = {
				["Name"] = p107,
				["Priority"] = v114,
				["At"] = os.clock()
			}
			table.insert(v117, v113, v118)
			if #v_u_23 > 2 then
				table.remove(v_u_23)
			end
		else
			v_u_48(p107)
		end
	else
		return
	end
end
function v_u_1.OnHealthKit() -- name: OnHealthKit
	-- upvalues: (ref) v_u_34, (ref) v_u_35, (ref) v_u_33, (copy) v_u_1
	local v119
	if os.clock() - v_u_34 <= 0.5 and v_u_33 < v_u_35 then
		v119 = v_u_33
	else
		v119 = v_u_35
	end
	v_u_1.Play(v119 < 25 and "Health Kit Close Call" or "Health Kit")
end
function v_u_1.OnAmmoCrate() -- name: OnAmmoCrate
	-- upvalues: (copy) v_u_1
	v_u_1.Play("Max Ammo")
end
function v_u_1.OnPurchase(p120, p121, p122) -- name: OnPurchase
	-- upvalues: (copy) v_u_17, (copy) v_u_1, (ref) v_u_31, (copy) v_u_9, (copy) v_u_16, (ref) v_u_29
	if p121 then
		if v_u_17[p120] then
			v_u_1.Play("Armor Bought")
		elseif p120 == "Ammo" then
			v_u_1.Play("Ammo Bought")
		end
	else
		v_u_31 = v_u_9.GetWave()
		if p122 and (v_u_16[p122] and not v_u_29) then
			v_u_29 = true
			v_u_1.Play("First Big Purchase")
		else
			v_u_1.Play("Weapon Bought")
		end
	end
end
function v_u_1.OnReload() -- name: OnReload
	-- upvalues: (copy) v_u_11, (copy) v_u_9, (copy) v_u_13, (copy) v_u_7, (copy) v_u_1
	if v_u_11() and v_u_9.GetWaveElapsed() ~= nil then
		local v123 = v_u_13.getRootPart(v_u_13.getLocalCharacter())
		local v124
		if v123 then
			v124 = v123.Position
		else
			v124 = nil
		end
		if v124 and v_u_7.CountNear(v124, 18, 8) >= 2 then
			v_u_1.Play("Reloading")
		end
	end
end
function v_u_1.Start() -- name: Start
	-- upvalues: (ref) v_u_20, (copy) v_u_5, (copy) v_u_8, (copy) v_u_58, (copy) v_u_7, (copy) v_u_97, (copy) v_u_9, (copy) v_u_81, (copy) v_u_83, (copy) v_u_84, (copy) v_u_4, (copy) v_u_10, (copy) v_u_87, (copy) v_u_89, (copy) v_u_18, (ref) v_u_35, (ref) v_u_33, (copy) v_u_91, (copy) v_u_104, (copy) v_u_106, (copy) v_u_11, (ref) v_u_41, (copy) v_u_6, (copy) v_u_102
	v_u_20 = v_u_5.new("ZombieSurvival")
	v_u_8.Bind(v_u_58)
	v_u_7.HitConfirmed:Connect(v_u_97)
	workspace:GetAttributeChangedSignal(v_u_9.RESUPPLY_ATTRIBUTE):Connect(v_u_81)
	workspace:GetAttributeChangedSignal(v_u_9.WAVE_STARTED_ATTRIBUTE):Connect(v_u_83)
	workspace:GetAttributeChangedSignal(v_u_9.WAVE_ATTRIBUTE):Connect(v_u_84)
	for _, v125 in v_u_4:GetPlayers() do
		v125:GetAttributeChangedSignal(v_u_10.DOWNED_ATTRIBUTE):Connect(v_u_87)
	end
	v_u_4.PlayerAdded:Connect(v_u_89)
	v_u_4.PlayerRemoving:Connect(function()
		-- upvalues: (ref) v_u_87
		task.defer(v_u_87)
	end)
	local v126 = v_u_18:GetAttribute("Health")
	if typeof(v126) == "number" then
		v_u_35 = v126
		v_u_33 = v126
	end
	v_u_18:GetAttributeChangedSignal("Health"):Connect(v_u_91)
	workspace:GetAttributeChangedSignal(v_u_9.WAVE_STARTED_ATTRIBUTE):Connect(v_u_104)
	workspace:GetAttributeChangedSignal("Gamemode"):Connect(v_u_106)
	local v127 = v_u_11()
	if v127 then
		v127 = v_u_9.GetWaveElapsed() ~= nil
	end
	if v127 and not v_u_41 then
		v_u_41 = v_u_6.BindToHeartbeat("SurvivalVoiceController.Scan", v_u_102)
	elseif not v127 and v_u_41 then
		v_u_41:Disconnect()
		v_u_41 = nil
	end
end
return v_u_1
-- NIGHT Analyzer | ReplicatedStorage.Controllers.TutorialZones
-- ModuleScript | 534 linhas | 14584 bytes | hash 0197daa0

local v1 = {}
local v_u_2 = game:GetService("HttpService")
local v3 = game:GetService("Players")
local v4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = require(v4.Components.Common.CharacterResolver)
local v_u_7 = require(v4.Components.Common.IsTutorialMode)
local v_u_8 = require(v4.Classes.Sound)
local v_u_9 = require(v4.Controllers.RunServiceController)
local v_u_10 = v3.LocalPlayer
local v_u_11 = {
	["Spot"] = Color3.fromRGB(255, 236, 60),
	["T"] = Color3.fromRGB(255, 184, 40),
	["CT"] = Color3.fromRGB(80, 170, 255),
	["Site"] = Color3.fromRGB(255, 20, 20),
	["Bomb"] = Color3.fromRGB(255, 20, 20)
}
local v_u_12 = NumberRange.new(0, 0.2)
local v_u_13 = Enum.EasingStyle.Quint
local v_u_14 = Enum.EasingStyle.Back
local v_u_15 = {
	["Spot"] = 0.5,
	["Bomb"] = 0.5
}
local v_u_16 = {
	"Characters",
	"Debris",
	"TutorialDummies",
	"TutorialEscorts",
	"TutorialRetakers",
	"TutorialCTSquad",
	"TutorialBAttackers"
}
local v_u_17 = nil
local v_u_18 = nil
local function v_u_34(p19) -- name: floorY
	-- upvalues: (copy) v_u_16, (copy) v_u_10
	local v20 = { workspace.CurrentCamera }
	local v21 = workspace:FindFirstChild("Map")
	if v21 then
		for _, v22 in { "Zones", "Geometry", "Barriers" } do
			local v23 = v21:FindFirstChild(v22)
			if not v23 then
				continue
			end
			table.insert(v20, v23)
		end
	end
	for _, v24 in v_u_16 do
		local v25 = workspace:FindFirstChild(v24)
		if not v25 then
			continue
		end
		table.insert(v20, v25)
	end
	local v26 = v_u_10.Character
	if v26 then
		table.insert(v20, v26)
	end
	local v27 = RaycastParams.new()
	v27.FilterType = Enum.RaycastFilterType.Exclude
	v27.FilterDescendantsInstances = v20
	local v28 = p19 + Vector3.new(0, 6, 0)
	local v29 = 36
	for _ = 1, 4 do
		local v30 = workspace
		local v31 = -v29
		local v32 = v30:Raycast(v28, Vector3.new(0, v31, 0), v27)
		if v32 then
			local v33 = v32.Instance
			if v32.Normal.Y > 0.7 and (v33:IsA("BasePart") and v33.Transparency < 0.9) then
				return v32.Position.Y
			end
			v29 = v29 - (v28.Y - v32.Position.Y + 0.05)
			v28 = v32.Position - Vector3.new(0, 0.05, 0)
			if v29 > 0 then
				continue
			end
		end
	end
	return p19.Y
end
local function v_u_43(p35, p36, p37) -- name: buildWall
	local v38 = Instance.new("Part")
	v38.Anchored = true
	v38.CanCollide = false
	v38.CanQuery = false
	v38.CanTouch = false
	v38.CastShadow = false
	v38.Transparency = 1
	v38.Parent = p35
	for _, v39 in { Enum.NormalId.Front, Enum.NormalId.Back } do
		local v40 = Instance.new("SurfaceGui")
		v40.Face = v39
		v40.LightInfluence = 0
		v40.Brightness = 3
		v40.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
		v40.PixelsPerStud = 40
		v40.Parent = v38
		local v41 = Instance.new("Frame")
		v41.Size = UDim2.fromScale(1, 1)
		v41.BackgroundColor3 = p36
		v41.BackgroundTransparency = 1
		v41.BorderSizePixel = 0
		local v42 = Instance.new("UIGradient")
		v42.Rotation = 90
		v42.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0.55), NumberSequenceKeypoint.new(1, 0) })
		v42.Parent = v41
		v41.Parent = v40
		table.insert(p37, v41)
	end
	return v38
end
local function v_u_66(p44, p45, p46, p47) -- name: layoutWalls
	local v48 = p45 * CFrame.new(0, 0.77, 0)
	local v49 = CFrame.Angles(0, 1.5707963267948966, 0)
	local v50 = p46 * 2
	local v51 = Vector3.new(v50, 1.5, 0.01)
	local v52 = p47 * 2
	local v53 = Vector3.new(v52, 1.5, 0.01)
	local v54 = p44[1]
	local v55 = p44[1]
	local v56 = v48 * CFrame.new(0, 0, -p47)
	v54.Size = v51
	v55.CFrame = v56
	local v57 = p44[2]
	local v58 = p44[2]
	local v59 = v48 * CFrame.new(0, 0, p47)
	v57.Size = v51
	v58.CFrame = v59
	local v60 = p44[3]
	local v61 = p44[3]
	local v62 = v48 * CFrame.new(-p46, 0, 0) * v49
	v60.Size = v53
	v61.CFrame = v62
	local v63 = p44[4]
	local v64 = p44[4]
	local v65 = v48 * CFrame.new(p46, 0, 0) * v49
	v63.Size = v53
	v64.CFrame = v65
end
local function v_u_70(p67) -- name: buildWalls
	-- upvalues: (copy) v_u_43
	local v68 = Instance.new("Folder")
	v68.Name = "TutorialZone"
	v68.Parent = workspace.CurrentCamera
	local v69 = {}
	return v68, {
		v_u_43(v68, p67, v69),
		v_u_43(v68, p67, v69),
		v_u_43(v68, p67, v69),
		v_u_43(v68, p67, v69)
	}, v69
end
local v_u_71 = nil
local v_u_72 = {}
local v_u_73 = 0
local function v_u_83() -- name: getGlow
	-- upvalues: (ref) v_u_71, (copy) v_u_72, (copy) v_u_10
	local v74 = v_u_71
	if v74 and v74.Parent then
		return v_u_72
	end
	local v75 = Instance.new("ScreenGui")
	v75.Name = "TutorialArrivalGlow"
	v75.IgnoreGuiInset = true
	v75.ResetOnSpawn = false
	v75.DisplayOrder = 5
	table.clear(v_u_72)
	for _, v76 in {
		{
			UDim2.fromScale(0.5, 0),
			UDim2.fromScale(1, 0.09),
			Vector2.new(0.5, 0),
			90
		},
		{
			UDim2.fromScale(0.5, 1),
			UDim2.fromScale(1, 0.09),
			Vector2.new(0.5, 1),
			-90
		},
		{
			UDim2.fromScale(0, 0.5),
			UDim2.fromScale(0.09, 1),
			Vector2.new(0, 0.5),
			0
		},
		{
			UDim2.fromScale(1, 0.5),
			UDim2.fromScale(0.09, 1),
			Vector2.new(1, 0.5),
			180
		}
	} do
		local v77 = Instance.new("Frame")
		local v78 = v76[1]
		local v79 = v76[2]
		local v80 = v76[3]
		v77.Position = v78
		v77.Size = v79
		v77.AnchorPoint = v80
		v77.BackgroundTransparency = 1
		v77.BorderSizePixel = 0
		local v81 = Instance.new("UIGradient")
		v81.Rotation = v76[4]
		v81.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.35, 0.6), NumberSequenceKeypoint.new(1, 1) })
		v81.Parent = v77
		v77.Parent = v75
		local v82 = v_u_72
		table.insert(v82, v77)
	end
	v75.Parent = v_u_10:WaitForChild("PlayerGui")
	v_u_71 = v75
	return v_u_72
end
local function v_u_91(p84) -- name: playArrival
	-- upvalues: (copy) v_u_8, (copy) v_u_83, (ref) v_u_73, (copy) v_u_5
	v_u_8.new("Deathmatch"):playOneTime({
		["Parent"] = nil,
		["Name"] = "Deathmatch HP Bonus",
		["Parent"] = workspace.CurrentCamera
	})
	local v_u_85 = v_u_83()
	v_u_73 = v_u_73 + 1
	local v_u_86 = v_u_73
	local v87 = TweenInfo.new(0.05, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	for _, v88 in v_u_85 do
		v88.BackgroundColor3 = p84
		v_u_5:Create(v88, v87, {
			["BackgroundTransparency"] = 0.55
		}):Play()
	end
	task.delay(0.05, function()
		-- upvalues: (copy) v_u_86, (ref) v_u_73, (copy) v_u_85, (ref) v_u_5
		if v_u_86 == v_u_73 then
			local v89 = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			for _, v90 in v_u_85 do
				v_u_5:Create(v90, v89, {
					["BackgroundTransparency"] = 1
				}):Play()
			end
		end
	end)
end
local function v_u_103(p92, p93) -- name: isInZone
	local v94 = p92.Room
	if v94 then
		local v95 = v94.CFrame:PointToObjectSpace(p93)
		local v96 = v95.X
		if math.abs(v96) <= v94.Half.X then
			local v97 = v95.Y
			if math.abs(v97) <= v94.Half.Y then
				local v98 = v95.Z
				if math.abs(v98) <= v94.Half.Z then
					return true
				end
			end
		end
	end
	local v99 = p92.Base:PointToObjectSpace(p93)
	local v100 = v99.X
	local v101
	if math.abs(v100) <= p92.HalfX + p92.Margin then
		local v102 = v99.Z
		if math.abs(v102) <= p92.HalfZ + p92.Margin and v99.Y > -4 then
			v101 = v99.Y < 10
		else
			v101 = false
		end
	else
		v101 = false
	end
	return v101
end
local function v_u_126(p104, p105, p106, p107, p108, p109) -- name: buildZone
	-- upvalues: (copy) v_u_11, (copy) v_u_34, (copy) v_u_70, (copy) v_u_66, (copy) v_u_15
	local v110 = v_u_11[p105] or v_u_11.Spot
	local v111 = p106.RightVector.X
	local v112 = p106.RightVector.Z
	local v113 = Vector3.new(v111, 0, v112)
	local v114 = v113.Magnitude <= 0.01 and Vector3.new(1, 0, 0) or v113.Unit
	local v115 = p106.Position
	local v116 = CFrame.fromMatrix
	local v117 = v115.X
	local v118 = v_u_34(v115)
	local v119 = v115.Z
	local v120 = v116(Vector3.new(v117, v118, v119), v114, Vector3.new(0, 1, 0))
	local v121 = p107 * 0.5
	local v122 = p108 * 0.5
	local v123, v124, v125 = v_u_70(v110)
	v_u_66(v124, v120, v121, v122)
	return {
		["Key"] = nil,
		["Kind"] = nil,
		["Folder"] = nil,
		["Walls"] = nil,
		["Frames"] = nil,
		["Morph"] = nil,
		["ShownAt"] = nil,
		["Transparency"] = 1,
		["Base"] = nil,
		["HalfX"] = nil,
		["HalfZ"] = nil,
		["Margin"] = nil,
		["Room"] = nil,
		["Color"] = nil,
		["WasOutside"] = false,
		["Entered"] = false,
		["Key"] = p104,
		["Kind"] = p105,
		["Folder"] = v123,
		["Walls"] = v124,
		["Frames"] = v125,
		["ShownAt"] = os.clock(),
		["Base"] = v120,
		["HalfX"] = v121,
		["HalfZ"] = v122,
		["Margin"] = v_u_15[p105] or 3.5,
		["Room"] = p109,
		["Color"] = v110
	}
end
local function v_u_145(p127, p128, p129, p130, p131, p132) -- name: morphZone
	-- upvalues: (copy) v_u_34, (copy) v_u_15
	p127.Morph = {
		["Base"] = p127.Base,
		["HalfX"] = p127.HalfX,
		["HalfZ"] = p127.HalfZ,
		["StartedAt"] = os.clock()
	}
	p127.Key = p128
	p127.Kind = p129
	local v133 = p130.RightVector.X
	local v134 = p130.RightVector.Z
	local v135 = Vector3.new(v133, 0, v134)
	local v136 = v135.Magnitude <= 0.01 and Vector3.new(1, 0, 0) or v135.Unit
	local v137 = p130.Position
	local v138 = CFrame.fromMatrix
	local v139 = v137.X
	local v140 = v_u_34(v137)
	local v141 = v137.Z
	local v142 = v138(Vector3.new(v139, v140, v141), v136, Vector3.new(0, 1, 0))
	local v143 = p131 * 0.5
	local v144 = p132 * 0.5
	p127.Base = v142
	p127.HalfX = v143
	p127.HalfZ = v144
	p127.Margin = v_u_15[p129] or 3.5
	p127.Room = nil
	p127.WasOutside = false
	p127.Entered = false
end
local function v_u_171() -- name: draw
	-- upvalues: (ref) v_u_17, (copy) v_u_70, (copy) v_u_66, (copy) v_u_5, (copy) v_u_13, (copy) v_u_14, (copy) v_u_6, (copy) v_u_103, (copy) v_u_91, (copy) v_u_12
	local v146 = v_u_17
	if v146 then
		if not v146.Folder.Parent then
			local v147, v148, v149 = v_u_70(v146.Color)
			v146.Folder = v147
			v146.Walls = v148
			v146.Frames = v149
			v146.Transparency = 1
			if not v146.Morph then
				v_u_66(v146.Walls, v146.Base, v146.HalfX, v146.HalfZ)
			end
		end
		local v150 = v146.Morph
		if v150 then
			local v151 = (os.clock() - v150.StartedAt) / 0.9
			local v152 = math.clamp(v151, 0, 1)
			local v153 = v_u_5:GetValue(v152, v_u_13, Enum.EasingDirection.Out)
			local v154 = v_u_5:GetValue(v152, v_u_14, Enum.EasingDirection.Out)
			local v155 = v_u_66
			local v156 = v146.Walls
			local v157 = v150.Base:Lerp(v146.Base, v153)
			local v158 = v150.HalfX + (v146.HalfX - v150.HalfX) * v154
			local v159 = math.max(v158, 0.25)
			local v160 = v150.HalfZ + (v146.HalfZ - v150.HalfZ) * v154
			v155(v156, v157, v159, (math.max(v160, 0.25)))
			if v152 >= 1 then
				v146.Morph = nil
			end
		end
		local v161 = v_u_6.getLocalCharacter()
		if v161 then
			v161 = v_u_6.getRootPart(v161)
		end
		if v161 and not v146.Entered then
			if v_u_103(v146, v161.Position) then
				if v146.WasOutside then
					v146.Entered = true
					v_u_91(v146.Color)
				end
			else
				v146.WasOutside = true
			end
		end
		local v162 = os.clock() - v146.ShownAt
		local v163 = v162 * 3.141592653589793 * 2 / 2.4
		local v164 = math.sin(v163) * 0.5 + 0.5
		local v165
		if v146.Morph then
			v165 = v_u_12.Min
		else
			v165 = v_u_12.Max - (v_u_12.Max - v_u_12.Min) * v164
		end
		local v166 = v162 / 0.4
		local v167 = math.clamp(v166, 0, 1)
		local v168 = (1 - (1 - v165) * v167) * 50 + 0.5
		local v169 = math.floor(v168) / 50
		if v169 ~= v146.Transparency then
			v146.Transparency = v169
			for _, v170 in v146.Frames do
				v170.BackgroundTransparency = v169
			end
		end
	else
		return
	end
end
local function v_u_176() -- name: clear
	-- upvalues: (ref) v_u_17, (copy) v_u_5, (ref) v_u_18, (copy) v_u_9
	local v172 = v_u_17
	v_u_17 = nil
	if v172 then
		local v_u_173 = v172.Folder
		local v174 = TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		for _, v175 in v172.Frames do
			v_u_5:Create(v175, v174, {
				["BackgroundTransparency"] = 1
			}):Play()
		end
		task.delay(0.6, function()
			-- upvalues: (copy) v_u_173
			v_u_173:Destroy()
		end)
	end
	if v_u_18 then
		v_u_9.Unbind("Heartbeat", "TutorialZones.Draw")
		v_u_18 = nil
	end
end
local function v_u_206() -- name: sync
	-- upvalues: (copy) v_u_7, (copy) v_u_10, (copy) v_u_176, (ref) v_u_17, (copy) v_u_2, (copy) v_u_145, (copy) v_u_126, (copy) v_u_171, (ref) v_u_18, (copy) v_u_9
	local v177
	if v_u_7() then
		v177 = v_u_10:GetAttribute("TutorialZone")
	else
		v177 = nil
	end
	if typeof(v177) == "string" and v177 ~= "" then
		if not v_u_17 or v_u_17.Key ~= v177 then
			local v178 = v_u_2.JSONDecode
			local v179 = v_u_2
			local v180, v181 = pcall(v178, v179, v177)
			if v180 and typeof(v181) == "table" then
				local v182 = v181.c
				if typeof(v182) == "table" then
					local v183 = v181.s
					if typeof(v183) == "table" then
						local v184 = CFrame.new
						local v185 = v181.c
						local v186 = v184(table.unpack(v185))
						local v187 = v181.s[1]
						local v188 = tonumber(v187)
						local v189 = v181.s[2]
						local v190 = tonumber(v189)
						if v188 and (v190 and (v188 > 0 and v190 > 0)) then
							local v191 = nil
							local v192 = v181.a
							if typeof(v192) == "table" then
								local v193 = v192.c
								if typeof(v193) == "table" then
									local v194 = v192.s
									if typeof(v194) == "table" then
										local v195 = v192.s[1]
										local v196 = tonumber(v195)
										local v197 = v192.s[2]
										local v198 = tonumber(v197)
										local v199 = v192.s[3]
										local v200 = tonumber(v199)
										if v196 and (v198 and v200) then
											v191 = {}
											local v201 = CFrame.new
											local v202 = v192.c
											v191.CFrame = v201(table.unpack(v202))
											v191.Half = Vector3.new(v196, v198, v200) * 0.5
										end
									end
								end
							end
							local v203 = v181.k
							local v204 = tostring(v203)
							local v205 = v_u_17
							if v205 and (v205.Kind == "Site" and (v204 == "Bomb" and v205.Folder.Parent)) then
								v_u_145(v205, v177, v204, v186, v188, v190)
							else
								v_u_176()
								v_u_17 = v_u_126(v177, v204, v186, v188, v190, v191)
								v_u_171()
								v_u_18 = v_u_9.BindToHeartbeat("TutorialZones.Draw", v_u_171)
							end
						else
							v_u_176()
							return
						end
					end
				end
			end
			v_u_176()
		end
	else
		v_u_176()
		return
	end
end
function v1.IsInside(p207) -- name: IsInside
	-- upvalues: (ref) v_u_17, (copy) v_u_103
	local v208 = v_u_17
	local v209
	if v208 == nil then
		v209 = false
	else
		v209 = v_u_103(v208, p207)
	end
	return v209
end
function v1.Start() -- name: Start
	-- upvalues: (copy) v_u_10, (copy) v_u_206
	v_u_10:GetAttributeChangedSignal("TutorialZone"):Connect(v_u_206)
	v_u_206()
end
return v1
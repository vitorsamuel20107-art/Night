-- NIGHT Analyzer | ReplicatedStorage.Controllers.InspectController
-- ModuleScript | 2379 linhas | 68311 bytes | hash 58f7593f

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v_u_2.Components.Common.SceneLighting)
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game:GetService("TextService")
local v7 = game:GetService("Players")
local v_u_8 = game:GetService("HttpService")
require(v_u_2.Database.Custom.Types)
local v9 = require(v_u_2.Shared.Janitor)
local v_u_10 = require(v_u_2.Shared.CloseButtonRegistry)
local v_u_11 = require(v_u_2.Controllers.MenuSceneController)
local v_u_12 = require(v_u_2.Controllers.CaseSceneController)
local v_u_13 = require(v_u_2.Controllers.CameraController)
local v_u_14 = require(v_u_2.Controllers.InputController)
local v_u_15 = require(v_u_2.Controllers.RunServiceController)
local v_u_16 = require(v_u_2.Controllers.DataController)
local v_u_17 = require(v_u_2.Classes.WeaponComponent.Classes.Viewmodel)
local v_u_18 = require(v_u_2.Components.Common.GetSkinDisplayName)
local v_u_19 = require(v_u_2.Components.Common.InterfaceAnimations.ActivateButton)
local v_u_20 = require(v_u_2.Components.Common.GetWeaponProperties)
local v_u_21 = require(v_u_2.Database.Components.Libraries.Collections)
local v22 = require(v_u_2.Components.Common.GetUserPlatform)
local v_u_23 = require(v_u_2.Components.Common.ApplyMobileButtonLayout)
local v_u_24 = require(v_u_2.Database.Custom.GameStats.UI.Mobile)
local v_u_25 = require(v_u_2.Database.Components.Libraries.Skins)
local v_u_26 = require(v_u_2.Database.Custom.GameStats.Rarities)
local v_u_27 = require(v_u_2.Database.Security.Router)
local v_u_28 = require(v_u_2.Interface.MenuState)
local v_u_29 = require(v_u_2.Database.Custom.Constants)
local v_u_30 = v7.LocalPlayer
local v_u_31 = v_u_30:WaitForChild("PlayerGui")
local v32 = v22()
local v_u_33 = table.find(v32, "Mobile")
if v_u_33 then
	v_u_33 = #v32 <= 1
end
local v_u_34 = workspace.CurrentCamera
local v_u_35 = nil
local v_u_36 = v_u_2.Assets.Lighting
local v_u_37 = v_u_2.Assets.UI.Inspect:WaitForChild("PreviewTemplate")
local v_u_38 = nil
local v_u_39 = nil
local v_u_40 = nil
local v_u_41 = nil
local v_u_42 = nil
local v_u_43 = nil
local v_u_44 = nil
local v_u_45 = nil
local v_u_46 = false
local v_u_47 = nil
local v_u_48 = nil
local v_u_49 = nil
local v_u_50 = {}
local v_u_51 = v9.new()
local v_u_52 = "Weapon"
local v_u_53 = false
local v_u_54 = nil
local v_u_55 = false
local v_u_56 = v_u_29.DEFAULT_CAMERA_FOV
local v_u_57 = CFrame.Angles(0, -1.5707963267948966, 0)
local v_u_58 = {
	"FAMAS",
	"AK-47",
	"M4A1-S",
	"Glock-18",
	"USP-S"
}
local v_u_59 = {
	["Weapon"] = true,
	["Melee"] = true,
	["Glove"] = true
}
local v_u_60 = { "HiddenTransparency", "_CaseScenePrevTransparency", "_InspectPrevTransparency" }
local v_u_61 = false
local v_u_62 = Vector2.zero
local v_u_63 = 40
local v_u_64 = 40
local v_u_65 = 0
local v_u_66 = 0
local v_u_67 = 0
local v_u_68 = 0
local v_u_69 = UDim2.fromScale(0.5, 0.075)
local v_u_70 = UDim2.fromScale(0.317, 0.054)
local v_u_71 = UDim2.fromScale(0.243, 0.054)
local v_u_72 = UDim2.fromScale(0.5, 0.143)
local v_u_73 = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v_u_74 = {
	{
		["Wear"] = "Factory New",
		["Display"] = "Mint Condition",
		["Min"] = 0,
		["Max"] = 0.07,
		["Color"] = nil,
		["Color"] = Color3.fromRGB(0, 255, 127)
	},
	{
		["Wear"] = "Minimal Wear",
		["Display"] = "Near-Mint",
		["Min"] = 0.07,
		["Max"] = 0.15,
		["Color"] = nil,
		["Color"] = Color3.fromRGB(0, 170, 255)
	},
	{
		["Wear"] = "Field-Tested",
		["Display"] = "Standard-Grade",
		["Min"] = 0.15,
		["Max"] = 0.38,
		["Color"] = nil,
		["Color"] = Color3.fromRGB(255, 255, 0)
	},
	{
		["Wear"] = "Well-Worn",
		["Display"] = "Combat-Worn",
		["Min"] = 0.38,
		["Max"] = 0.45,
		["Color"] = nil,
		["Color"] = Color3.fromRGB(255, 85, 0)
	},
	{
		["Wear"] = "Battle-Scarred",
		["Display"] = "War-Torn",
		["Min"] = 0.45,
		["Max"] = 1,
		["Color"] = nil,
		["Color"] = Color3.fromRGB(255, 0, 0)
	}
}
local v_u_75 = {}
local v_u_76 = nil
local v_u_77 = nil
local v_u_78 = 1
local v_u_79 = false
local function v_u_84() -- name: getRandomInspectScene
	-- upvalues: (ref) v_u_35, (copy) v_u_2
	local v80
	if v_u_35 then
		v80 = v_u_35
	else
		local v81 = v_u_2:FindFirstChild("Assets")
		if v81 then
			v_u_35 = v81:WaitForChild("InspectScenes", 10)
		end
		v80 = v_u_35
	end
	if v80 then
		local v82 = {}
		for _, v83 in ipairs(v80:GetChildren()) do
			if not v83:IsA("Model") then
				continue
			end
			table.insert(v82, v83)
		end
		if #v82 > 0 then
			return v82[math.random(1, #v82)]
		else
			return nil
		end
	else
		return nil
	end
end
local function v_u_88(p85) -- name: activateInspectSceneFlags
	for _, v86 in ipairs(p85:GetDescendants()) do
		local v87 = v86:IsA("Model")
		if v87 then
			v87 = v86:FindFirstChild("csFlag")
		end
		if not v87 or (not v87:IsA("Model") or v86:HasTag("Flag")) then
			continue
		end
		v86:AddTag("Flag")
	end
end
local function v_u_91(p89) -- name: isPointerOverButton
	-- upvalues: (copy) v_u_31
	for _, v90 in v_u_31:GetGuiObjectsAtPosition(p89.X, p89.Y) do
		if not (v90:IsA("GuiButton") and (v90.Visible and v90.Active)) then
			continue
		end
		return true
	end
	return false
end
local function v_u_94() -- name: getPinchDistance
	-- upvalues: (ref) v_u_75
	local v92 = {}
	for _, v93 in pairs(v_u_75) do
		table.insert(v92, v93)
	end
	if #v92 >= 2 then
		return (v92[1] - v92[2]).Magnitude
	else
		return nil
	end
end
local function v_u_98(p95, p96) -- name: hideOtherMenuScreens
	for _, v97 in ipairs(p95:GetChildren()) do
		if not v97:IsA("Frame") or (v97.Name == "Top" or (v97.Name == p96 or (v97.Name == "Inspect" or v97.Name == "InspectFrame"))) then
			continue
		end
		v97.Visible = false
	end
end
local function v_u_103() -- name: hideMenuFrames
	-- upvalues: (copy) v_u_28, (ref) v_u_46, (copy) v_u_11
	v_u_28.EnterInspect()
	local v99 = v_u_28.GetMenuFrame()
	if v99 then
		v_u_46 = v_u_11.IsActive()
		if v_u_46 then
			v_u_11.HideMenuScene(true)
			v_u_11.SetMusicVolumeMultiplier(0.5, 0.5)
		end
		v_u_28.SetBlurEnabled(false)
		v99.BackgroundTransparency = 1
		local v100 = v99:FindFirstChild("Pattern")
		if v100 then
			v100.Visible = false
		end
		local v101 = v99:FindFirstChild("Top")
		if v101 then
			v101.Visible = false
		end
		for _, v102 in ipairs(v99:GetChildren()) do
			if not v102:IsA("Frame") or v102.Name == "Top" then
				continue
			end
			v102.Visible = v102.Name == "Inspect" and true or v102.Name == "InspectFrame"
		end
	end
end
local function v_u_109(p104, p105) -- name: getFloatPreviewClosedPosition
	local v106 = p104.Position
	local v107 = -(p104.Size.X.Scale * p105.Position.X.Scale)
	local v108 = -(p104.Size.X.Offset + p105.Position.X.Offset)
	return UDim2.new(v107, v108, v106.Y.Scale, v106.Y.Offset)
end
local function v_u_112(p110) -- name: storeFloatPreviewOpenPosition
	local v111 = p110.Position
	p110:SetAttribute("OpenPositionXScale", v111.X.Scale)
	p110:SetAttribute("OpenPositionXOffset", v111.X.Offset)
	p110:SetAttribute("OpenPositionYScale", v111.Y.Scale)
	p110:SetAttribute("OpenPositionYOffset", v111.Y.Offset)
end
local function v_u_114(p113) -- name: getStoredFloatPreviewOpenPosition
	return UDim2.new(p113:GetAttribute("OpenPositionXScale") or p113.Position.X.Scale, p113:GetAttribute("OpenPositionXOffset") or p113.Position.X.Offset, p113:GetAttribute("OpenPositionYScale") or p113.Position.Y.Scale, p113:GetAttribute("OpenPositionYOffset") or p113.Position.Y.Offset)
end
local function v_u_144() -- name: initializeInspectButtons
	-- upvalues: (copy) v_u_28, (copy) v_u_19, (copy) v_u_10, (copy) v_u_1, (copy) v_u_112, (copy) v_u_109, (copy) v_u_5, (copy) v_u_73, (copy) v_u_16, (copy) v_u_30, (copy) v_u_24, (copy) v_u_23, (copy) v_u_27
	local v115 = v_u_28.GetMenuFrame()
	if v115 then
		v115 = v115:FindFirstChild("Inspect") or v115:FindFirstChild("InspectFrame")
	end
	local v116
	if v115 then
		v116 = v115:FindFirstChild("Bottom")
	else
		v116 = v115
	end
	if v116 then
		local v117 = v116.Container.Buttons:FindFirstChild("Close")
		if v117 and v117:IsA("GuiButton") then
			v_u_19(v117)
			v_u_10.Add(v115, v117, function()
				-- upvalues: (ref) v_u_1
				v_u_1.HideInspect()
			end)
		end
		local v118 = v116:FindFirstChild("Middle")
		if v118 then
			v118 = v118:FindFirstChild("Buttons")
		end
		if v118 then
			for _, v119 in ipairs({ "Viewmodel", "Weapon" }) do
				local v120 = v118:FindFirstChild(v119)
				if not (v120 and v120:IsA("GuiButton")) then
					continue
				end
				v_u_19(v120)
			end
		end
		local v_u_121 = v115:FindFirstChild("FloatPreviews")
		if v_u_121 then
			v_u_121.Visible = false
			local v_u_122 = v_u_121:FindFirstChild("ToggleButton")
			if v_u_122 and v_u_122:IsA("GuiButton") then
				v_u_19(v_u_122)
				v_u_112(v_u_121)
				local v_u_123 = v_u_121.Position
				local v_u_124 = v_u_109(v_u_121, v_u_122)
				v_u_121:SetAttribute("IsOpen", true)
				local v125 = v_u_122:FindFirstChild("TextLabel")
				if v125 and v125:IsA("TextLabel") then
					v125.Rotation = 0
				end
				local v_u_126 = nil
				v_u_122.Activated:Connect(function()
					-- upvalues: (copy) v_u_121, (copy) v_u_122, (ref) v_u_126, (ref) v_u_5, (ref) v_u_73, (copy) v_u_123, (copy) v_u_124
					local v127 = v_u_121:GetAttribute("IsOpen") == false
					v_u_121:SetAttribute("IsOpen", v127)
					local v128 = v_u_122:FindFirstChild("TextLabel")
					if v128 and v128:IsA("TextLabel") then
						v128.Rotation = v127 and 0 or 180
					end
					if v_u_126 then
						v_u_126:Cancel()
					end
					local v129 = v_u_5
					local v130 = v_u_121
					local v131 = v_u_73
					local v132 = {}
					local v133
					if v127 then
						v133 = v_u_123
					else
						v133 = v_u_124
					end
					v132.Position = v133
					local v134 = v129:Create(v130, v131, v132)
					v_u_126 = v134
					v134:Play()
				end)
			end
		end
		local v135 = v115:FindFirstChild("MobileButtons")
		if v135 then
			local v136 = v135:FindFirstChild("Inspect")
			if v136 and v136:IsA("TextButton") then
				v_u_19(v136)
				v136.MouseButton1Click:Connect(function()
					-- upvalues: (ref) v_u_1
					v_u_1.PlayInspectAnimation()
				end)
				local v137 = v_u_16.Get(v_u_30, "MobileButtons")
				local v138 = v_u_24.SanitizeLayout(v137).Inspect
				if v138 then
					v_u_23(v136, v138)
				end
			end
			v135.Visible = false
		end
		local v139 = v116.Middle:FindFirstChild("Charm")
		if v139 then
			local function v140()
				-- upvalues: (ref) v_u_1
				v_u_1.CycleCharmPosition()
			end
			local v141 = v139:FindFirstChild("Next")
			if v141 and v141:IsA("GuiButton") then
				v_u_19(v141)
				v141.MouseButton1Click:Connect(v140)
			end
			local function v142()
				-- upvalues: (ref) v_u_27
				v_u_27.broadcastRouter("ConfirmCharmAttachment")
			end
			local v143 = v139:FindFirstChild("Confirm")
			if v143 and v143:IsA("GuiButton") then
				v_u_19(v143)
				v143.MouseButton1Click:Connect(v142)
			end
		end
	end
end
local v_u_145 = {
	{
		["Name"] = "Inspect",
		["Action"] = "Inspect",
		["Title"] = "Inspect"
	},
	{
		["Name"] = "Cancel",
		["Action"] = "Reload",
		["Title"] = "Cancel"
	}
}
local function v_u_164() -- name: refreshInspectTips
	-- upvalues: (copy) v_u_28, (copy) v_u_2, (ref) v_u_55, (ref) v_u_52, (copy) v_u_4, (copy) v_u_145, (ref) v_u_42, (copy) v_u_20
	local v146 = v_u_28.GetMenuFrame()
	if v146 then
		v146 = v146:FindFirstChild("Inspect") or v146:FindFirstChild("InspectFrame")
	end
	if v146 then
		v146 = v146:FindFirstChild("Tips")
	end
	if v146 and v146:IsA("GuiObject") then
		local v147 = require(v_u_2.Interface.Screens.Gameplay.Middle.Tips)
		if not v146:GetAttribute("Mirrored") then
			v146:SetAttribute("Mirrored", true)
			v146.AnchorPoint = Vector2.new(1, v146.AnchorPoint.Y)
			local v148 = v146:FindFirstChildOfClass("UIListLayout")
			if v148 then
				v148.HorizontalAlignment = Enum.HorizontalAlignment.Right
			end
			for _, v149 in v146:GetChildren() do
				if not v149:IsA("GuiObject") then
					continue
				end
				v147.MirrorRow(v149)
			end
		end
		local v150 = v_u_55
		if v150 then
			if v_u_52 == "Viewmodel" then
				v150 = v_u_4.PreferredInput ~= Enum.PreferredInput.Touch
			else
				v150 = false
			end
		end
		local v151 = false
		for _, v152 in v_u_145 do
			local v153 = v146:FindFirstChild(v152.Name)
			if not (v153 and v153:IsA("GuiObject")) then
				continue
			end
			local v154 = v153:FindFirstChild("Title")
			if v154 and v154:IsA("TextLabel") then
				v154.Text = v152.Title
			end
			local v155 = v153:FindFirstChild("Keybind")
			if v155 and v155:IsA("GuiObject") then
				v155.Selectable = false
			end
			local v156
			if v152.Name == "Cancel" then
				local v157 = v_u_42
				if v157 == nil then
					v156 = false
				elseif v157.Type == "Glove" then
					v156 = true
				else
					local v158
					if v157.Name then
						local v159 = v_u_20
						local v160 = v157.Name
						local v161, v162 = pcall(v159, v160)
						if v161 and v162 then
							v158 = v162.Class
						else
							v158 = nil
						end
					else
						v158 = nil
					end
					v156 = v158 == "Glove"
				end
			else
				v156 = false
			end
			local v163 = v150 and (not v156 and (v155 ~= nil and v155:IsA("GuiButton")))
			if v163 then
				v163 = v147.ApplyBindingToKeybind(v155, v147.ResolveActionBinding(v152.Action))
			end
			v153.Visible = v163
			v151 = v151 or v163
		end
		v146.Visible = v151
	end
end
local function v_u_168() -- name: updateCharmFrameVisibility
	-- upvalues: (copy) v_u_28, (copy) v_u_27
	local v165 = v_u_28.GetMenuFrame()
	if v165 then
		v165 = v165:FindFirstChild("Inspect") or v165:FindFirstChild("InspectFrame")
	end
	if v165 then
		v165 = v165:FindFirstChild("Bottom")
	end
	if v165 then
		local v166 = v165.Middle:FindFirstChild("Charm")
		local v167 = v165.Middle:FindFirstChild("Buttons")
		if v166 then
			v166.Visible = v_u_27.broadcastRouter("HasPendingCharmAttachment") or false
			v167.Visible = not v166.Visible
		end
	end
end
local function v_u_173() -- name: setupGloveViewmodelInspectAnimation
	-- upvalues: (ref) v_u_38, (ref) v_u_39, (ref) v_u_40
	if v_u_38 then
		if v_u_38.IsPlaying then
			v_u_38:Stop(0)
		end
		v_u_38:Destroy()
		v_u_38 = nil
	end
	if v_u_39 then
		v_u_39:Destroy()
		v_u_39 = nil
	end
	if v_u_40 and v_u_40.Animation then
		local v_u_169 = v_u_40.Animation.Animator
		if v_u_169 then
			local v_u_170 = Instance.new("Animation")
			v_u_170.AnimationId = "rbxassetid://135926544677482"
			local v171, v172 = pcall(function()
				-- upvalues: (copy) v_u_169, (copy) v_u_170
				return v_u_169:LoadAnimation(v_u_170)
			end)
			if v171 and v172 then
				v_u_39 = v_u_170
				v_u_38 = v172
				if v_u_38 then
					if v_u_38.IsPlaying then
						return
					end
					if v_u_40 and v_u_40.Animation then
						v_u_40.Animation:stopAnimations()
					end
					v_u_38.TimePosition = 0
					v_u_38:Play(0, 1, 1)
				end
			else
				v_u_170:Destroy()
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_179(p174, p175) -- name: resolveInspectViewmodelSkin
	-- upvalues: (copy) v_u_25
	local v176 = (not p175 or (p175 == "" or not p175)) and "Vanilla" or p175
	for _, v177 in ipairs({ v176, "Vanilla", "Default" }) do
		if not v_u_25.GetSkinInformation(p174, v177) then
			continue
		end
		return v177
	end
	local v178 = v_u_25.GetAllSkinsForWeapon(p174)
	if v178 and (v178[1] and v178[1].skin) then
		return v178[1].skin
	else
		return v176
	end
end
local function v_u_182() -- name: resolveGloveProxyWeapon
	-- upvalues: (copy) v_u_58, (copy) v_u_25
	for _, v180 in ipairs(v_u_58) do
		local v181 = v_u_25.GetBaseWeaponModel(v180, "Camera")
		if not v181 then
			continue
		end
		v181:Destroy()
		return v180
	end
	return "FAMAS"
end
local function v_u_187(p183, p184) -- name: prepareInspectWeapon
	-- upvalues: (ref) v_u_47, (ref) v_u_41
	p183.Name = "InspectWeapon"
	v_u_47 = p183
	v_u_41 = p183:FindFirstChild("InspectPivot", true)
	local v185 = p183:FindFirstChild("CharmBase", true)
	for _, v186 in ipairs(p183:GetDescendants()) do
		if not v186:IsA("BasePart") then
			continue
		end
		v186.CastShadow = false
		if p184 then
			v186.CanCollide = false
			v186.CanQuery = false
			v186.CanTouch = false
			v186.Anchored = p183.PrimaryPart == v186
		elseif v185 and v186:IsDescendantOf(v185) then
			v186.Anchored = false
		else
			v186.CanCollide = v186:IsA("MeshPart")
			v186.CanQuery = false
			v186.CanTouch = false
			v186.Anchored = true
		end
	end
end
local function v_u_200(p188) -- name: setupWeaponInspect
	-- upvalues: (ref) v_u_49, (copy) v_u_25, (copy) v_u_187, (copy) v_u_57, (ref) v_u_41
	if v_u_49 then
		local v189 = v_u_49:FindFirstChild("WeaponPart")
		if v189 then
			local v190 = p188.Type == "Glove"
			local v191 = p188.Type == "Charm"
			local v192
			if v190 then
				local v193 = v_u_25.GetGloves(p188.Name, p188.Skin, p188.Float)
				if v193 and v193:IsA("BasePart") then
					v192 = Instance.new("Model")
					v192.Name = p188.Name
					v193.Parent = v192
					v192.PrimaryPart = v193
				else
					v192 = v193
				end
			elseif v191 then
				v192 = v_u_25.GetCharmModel(p188.Skin, p188.Pattern or 1)
			elseif p188.Type == "Badge" then
				v192 = v_u_25.GetBadgeModel(p188.Skin)
			else
				v192 = v_u_25.GetInspectModel(p188.Name, p188.Skin, p188.Float, p188.StatTrack, p188.NameTag, p188.Charm, p188.Stickers)
			end
			if v192 then
				v_u_187(v192, v191)
				if v190 and (p188.Name == "T Glove" or p188.Name == "CT Glove") then
					local v194 = {}
					for _, v195 in ipairs(v192:GetChildren()) do
						if not v195:IsA("BasePart") then
							continue
						end
						table.insert(v194, v195)
					end
					if #v194 >= 2 then
						local v196 = v192:FindFirstChild("RightGlove") or v194[1]
						for _, v197 in ipairs(v194) do
							if v197 == v196 then
								continue
							end
							v197:Destroy()
						end
					end
				end
				v192.Parent = v_u_49
				local v198 = CFrame.identity
				local v199 = v189.CFrame * v198 * v_u_57
				if v_u_41 then
					v199 = v199 * v192:GetPivot():ToObjectSpace(v_u_41.WorldCFrame):Inverse()
				end
				v192:PivotTo(v199)
			else
				warn(("[InspectController]: Failed to get model for \"%*\""):format(p188.Name), p188)
			end
		else
			warn("[InspectController]: Inspect scene missing WeaponPart")
			return
		end
	else
		return
	end
end
local function v_u_226(p_u_201) -- name: setupViewmodelInspect
	-- upvalues: (ref) v_u_38, (ref) v_u_39, (ref) v_u_40, (ref) v_u_43, (copy) v_u_14, (copy) v_u_30, (copy) v_u_20, (copy) v_u_11, (copy) v_u_8, (copy) v_u_27, (ref) v_u_78, (copy) v_u_182, (copy) v_u_179, (copy) v_u_17, (copy) v_u_34, (copy) v_u_173, (copy) v_u_60
	if v_u_38 then
		if v_u_38.IsPlaying then
			v_u_38:Stop(0)
		end
		v_u_38:Destroy()
		v_u_38 = nil
	end
	if v_u_39 then
		v_u_39:Destroy()
		v_u_39 = nil
	end
	if v_u_40 then
		v_u_40:destroy()
		v_u_40 = nil
	end
	if v_u_43 then
		v_u_43:Destroy()
		v_u_43 = nil
	end
	v_u_14.enableGroup("Gameplay")
	local v202 = v_u_30:GetAttribute("Team") == "Counter-Terrorists" and "CT" or "T"
	local v203
	if p_u_201 == nil then
		v203 = false
	elseif p_u_201.Type == "Glove" then
		v203 = true
	else
		local v204
		if p_u_201.Name then
			local v205 = v_u_20
			local v206 = p_u_201.Name
			local v207, v208 = pcall(v205, v206)
			if v207 and v208 then
				v204 = v208.Class
			else
				v204 = nil
			end
		else
			v204 = nil
		end
		v203 = v204 == "Glove"
	end
	local v209 = v_u_11.CreateStandaloneCharacter(v202)
	if v209 then
		if v203 then
			local v210 = {
				["Name"] = p_u_201.Name,
				["Skin"] = p_u_201.Skin,
				["Float"] = p_u_201.Float
			}
			if p_u_201._id and p_u_201._id ~= "" then
				v210.SkinIdentifier = p_u_201._id
			end
			v209:SetAttribute("EquippedGloves", v_u_8:JSONEncode(v210))
		end
		v_u_43 = v209
		local v211 = p_u_201.Charm
		if v_u_27.broadcastRouter("HasPendingCharmAttachment") and type(v211) == "table" then
			v211 = {
				["_id"] = v211._id
			}
			local v212 = v_u_78
			v211.Position = tostring(v212)
		end
		local v_u_213 = {
			["Player"] = v_u_30,
			["Character"] = v209,
			["StatTrack"] = p_u_201.StatTrack,
			["Stickers"] = p_u_201.Stickers,
			["NameTag"] = p_u_201.NameTag,
			["Float"] = p_u_201.Float,
			["Charm"] = v211
		}
		local v214 = p_u_201.Name
		local v_u_215
		if v203 then
			v214 = v_u_182()
			v_u_215 = "Stock"
		else
			v_u_215 = v_u_179(v214, p_u_201.Skin)
		end
		v_u_213.ViewmodelCameraWeapon = v214
		v_u_213.ViewmodelHideWeaponGeometry = v203
		local function v216()
			-- upvalues: (ref) v_u_17, (copy) v_u_213, (copy) p_u_201, (ref) v_u_215
			return v_u_17.new(v_u_213, p_u_201.Name, v_u_215, true)
		end
		local v217, v218 = pcall(v216)
		if v217 and v218 then
			v_u_40 = v218
			v_u_40:equip(v203)
			if v_u_40.Model then
				if v_u_40.Model.Parent ~= v_u_34 then
					v_u_40.Model.Parent = v_u_34
				end
				if v_u_40.Hidden then
					v_u_40:unhide()
				end
				if v203 then
					local v219 = v_u_40.Model:FindFirstChild("Stats")
					if v219 then
						v219 = v219:FindFirstChild("Default")
					end
					local v220
					if v219 then
						v220 = v219.Value
					else
						v220 = v219
					end
					if typeof(v220) == "Vector3" then
						local v221 = v220.Y
						local v222 = v220.Z
						v219.Value = Vector3.new(0.05, v221, v222)
					end
					v_u_173()
				end
				task.defer(function()
					-- upvalues: (ref) v_u_40, (ref) v_u_60
					if v_u_40 and v_u_40.Model then
						for _, v223 in ipairs(v_u_40.Model:GetDescendants()) do
							if v223:IsA("BasePart") then
								v223.CastShadow = false
								if (v223.Name == "HumanoidRootPart" or (v223.Name == "ViewmodelLight" or (v223.Name == "MuzzlePart" or v223.Name == "MuzzlePartL"))) and true or v223.Name == "MuzzlePartR" then
									continue
								end
								local v224 = nil
								for _, v225 in ipairs(v_u_60) do
									v224 = v223:GetAttribute(v225)
									if v224 == nil then
										continue
									end
									v223:SetAttribute(v225, nil)
								end
								if v224 == nil then
									if v223.Transparency < 1 or v223.Name ~= "Right Arm" and v223.Name ~= "Left Arm" then
										break
									end
									v223.Transparency = 0
								else
									v223.Transparency = v224
								end
							else
								if not v223:IsA("SurfaceGui") then
									continue
								end
								if v223:GetAttribute("_InspectPrevSurfaceGuiEnabled") then
									v223:SetAttribute("_InspectPrevSurfaceGuiEnabled", nil)
								end
								if v223:GetAttribute("_CaseScenePrevSurfaceGuiEnabled") then
									v223:SetAttribute("_CaseScenePrevSurfaceGuiEnabled", nil)
								end
								v223.Enabled = true
							end
						end
					end
				end)
			end
		else
			warn(("[InspectController]: Failed to create viewmodel (%* | %*)"):format(v214, v_u_215), v218)
			if v_u_38 then
				if v_u_38.IsPlaying then
					v_u_38:Stop(0)
				end
				v_u_38:Destroy()
				v_u_38 = nil
			end
			if v_u_39 then
				v_u_39:Destroy()
				v_u_39 = nil
			end
			if v_u_40 then
				v_u_40:destroy()
				v_u_40 = nil
			end
			if v_u_43 then
				v_u_43:Destroy()
				v_u_43 = nil
			end
			v_u_14.enableGroup("Gameplay")
			return
		end
	else
		warn("[InspectController]: Failed to create standalone character for viewmodel")
		return
	end
end
local function v_u_232(p227) -- name: applyInspectMode
	-- upvalues: (ref) v_u_42, (ref) v_u_52, (ref) v_u_47, (ref) v_u_41, (ref) v_u_38, (ref) v_u_39, (ref) v_u_40, (ref) v_u_43, (copy) v_u_14, (copy) v_u_28, (ref) v_u_55, (copy) v_u_33, (copy) v_u_164, (copy) v_u_200, (ref) v_u_64, (copy) v_u_226, (copy) v_u_56, (copy) v_u_1
	local v228 = v_u_42
	if v228 then
		if v_u_52 == "Weapon" then
			if v_u_47 then
				v_u_47:Destroy()
				v_u_47 = nil
			end
			v_u_41 = nil
		elseif v_u_52 == "Viewmodel" then
			if v_u_38 then
				if v_u_38.IsPlaying then
					v_u_38:Stop(0)
				end
				v_u_38:Destroy()
				v_u_38 = nil
			end
			if v_u_39 then
				v_u_39:Destroy()
				v_u_39 = nil
			end
			if v_u_40 then
				v_u_40:destroy()
				v_u_40 = nil
			end
			if v_u_43 then
				v_u_43:Destroy()
				v_u_43 = nil
			end
			v_u_14.enableGroup("Gameplay")
		end
		v_u_52 = p227
		local v229 = v_u_28.GetMenuFrame()
		if v229 then
			v229 = v229:FindFirstChild("Inspect") or v229:FindFirstChild("InspectFrame")
		end
		if v229 then
			v229 = v229:FindFirstChild("MobileButtons")
		end
		local v230
		if v229 then
			v230 = v229:FindFirstChild("Inspect")
		else
			v230 = v229
		end
		if v230 then
			local v231 = v_u_55
			if v231 then
				if v_u_52 == "Viewmodel" then
					v231 = v_u_33
				else
					v231 = false
				end
			end
			v229.Visible = v231
			v230.Visible = v231
		end
		v_u_164()
		if p227 == "Weapon" then
			v_u_200(v228)
			v_u_64 = 40
			v_u_14.enableGroup("Gameplay")
		elseif p227 == "Viewmodel" then
			v_u_14.disableGroup("Gameplay")
			v_u_226(v228)
			v_u_64 = v_u_56
			v_u_1.PlayInspectAnimation()
		end
	else
		return
	end
end
local function v_u_245(p233) -- name: setInspectMode
	-- upvalues: (ref) v_u_42, (copy) v_u_20, (ref) v_u_52, (ref) v_u_53, (ref) v_u_54, (copy) v_u_232, (ref) v_u_55
	local v234 = v_u_42
	if v234 then
		local v235
		if v234 == nil then
			v235 = false
		elseif v234.Type == "Glove" then
			v235 = true
		else
			local v236
			if v234.Name then
				local v237 = v_u_20
				local v238 = v234.Name
				local v239, v240 = pcall(v237, v238)
				if v239 and v240 then
					v236 = v240.Class
				else
					v236 = nil
				end
			else
				v236 = nil
			end
			v235 = v236 == "Glove"
		end
		local v241 = v235 and p233 == "Weapon" and "Viewmodel" or p233
		if v_u_52 == v241 then
			return
		elseif v_u_53 then
			v_u_54 = v241
		else
			v_u_53 = true
			while v241 do
				local v242 = v_u_232
				local v243, v244 = pcall(v242, v241)
				if not v243 then
					warn(("[InspectController]: Failed to apply inspect mode \"%*\""):format(v241), v244)
				end
				v241 = v_u_54
				v_u_54 = nil
				if v241 ~= v_u_52 and v_u_55 then
					continue
				end
				v241 = nil
			end
			v_u_53 = false
		end
	else
		return
	end
end
local function v_u_259(p246, p247, p248) -- name: updateButtonVisuals
	-- upvalues: (ref) v_u_52, (copy) v_u_5
	local v249 = p247:FindFirstChild("HoverFrame")
	local v250 = p247:FindFirstChild("SelectFrame")
	local v251 = p247:FindFirstChild("ImageLabel")
	local v252
	if v_u_52 == p246 then
		v252 = p246 ~= "Info"
	else
		v252 = false
	end
	if v252 then
		local v253 = {
			["BackgroundTransparency"] = 1
		}
		if v249 then
			v_u_5:Create(v249, TweenInfo.new(0.2), v253):Play()
		end
		local v254 = {
			["BackgroundTransparency"] = 0,
			["BackgroundColor3"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(95, 95, 95)
		}
		if v250 then
			v_u_5:Create(v250, TweenInfo.new(0.2), v254):Play()
		end
		local v255 = {
			["ImageColor3"] = Color3.fromRGB(210, 210, 210)
		}
		if v251 then
			v_u_5:Create(v251, TweenInfo.new(0.2), v255):Play()
			return
		end
	else
		local v256 = {
			["BackgroundTransparency"] = 1
		}
		if v250 then
			v_u_5:Create(v250, TweenInfo.new(0.2), v256):Play()
		end
		local v257 = {
			["ImageColor3"] = Color3.fromRGB(255, 255, 255)
		}
		if v251 then
			v_u_5:Create(v251, TweenInfo.new(0.2), v257):Play()
		end
		local v258 = {
			["BackgroundTransparency"] = p248 and 0 or 1
		}
		if v249 then
			v_u_5:Create(v249, TweenInfo.new(0.2), v258):Play()
		end
	end
end
local function v_u_264(p260, p261) -- name: refreshAllButtons
	-- upvalues: (copy) v_u_259
	for v262, v263 in pairs(p260) do
		if not (v263 and v263:IsA("GuiButton")) then
			continue
		end
		v_u_259(v262, v263, v262 == p261)
	end
end
local function v_u_273(p265, p266) -- name: scaleInfoFrameToFit
	-- upvalues: (copy) v_u_34, (copy) v_u_6
	local v267 = v_u_34.ViewportSize.Y * 0.025
	local v268 = math.floor(v267)
	local v269 = math.clamp(v268, 8, 32)
	local v270 = 0
	for _, v271 in ipairs(p266) do
		if not v271 or (not v271:IsA("TextLabel") or v271.Text == "") then
			continue
		end
		v271.TextScaled = false
		local v272 = v_u_6:GetTextSize(v271.Text:gsub("<[^>]*>", ""), v269, Enum.Font.Gotham, Vector2.new((1 / 0), (1 / 0)))
		if v270 < v272.X then
			v270 = v272.X
		end
		v271.TextSize = v269
		v271.TextWrapped = false
	end
	if v270 > 0 then
		p265.Size = UDim2.new(0.05, v270, p265.Size.Y.Scale, p265.Size.Y.Offset)
	end
end
local function v_u_299(p274, p275, p276) -- name: showInfoFrame
	-- upvalues: (copy) v_u_25, (copy) v_u_273
	local v_u_277 = p274:FindFirstChild("Information")
	if v_u_277 then
		if p276 then
			local v278 = v_u_277.Parent.AbsolutePosition.X
			local v279 = p276.AbsolutePosition.X + p276.AbsoluteSize.X / 2 - v278
			v_u_277.Position = UDim2.new(0, v279 + v_u_277.AbsoluteSize.X / 2, v_u_277.Position.Y.Scale, v_u_277.Position.Y.Offset)
		end
		v_u_277.Visible = true
		local v280 = v_u_25.GetSkinInformation(p275.Name, p275.Skin)
		local v281
		if v280 then
			local _, v282 = v_u_25.GetWearNameForFloat(v280, p275.Float or 0)
			v281 = v282 or "Mint Condition"
		else
			v281 = "Mint Condition"
		end
		local v283 = p275.Type == "Charm"
		local v_u_284 = v_u_277:FindFirstChild("Exterior")
		if v_u_284 then
			v_u_284.Visible = not v283
			if not v283 then
				v_u_284.RichText = true
				v_u_284.Text = ("<b><font color=\"rgb(175,175,175)\">Exterior</font></b>: <font color=\"rgb(255,255,255)\">%*</font>"):format(v281)
			end
		end
		local v_u_285 = v_u_277:FindFirstChild("Tradeable")
		if v_u_285 then
			v_u_285.RichText = true
			v_u_285.Text = ("<b><font color=\"rgb(175,175,175)\">Tradeable</font></b>: <font color=\"rgb(255,255,255)\">%*</font>"):format(p275.IsTradeable and "Yes" or "No")
		end
		local v_u_286 = v_u_277:FindFirstChild("Serial")
		if v_u_286 then
			v_u_286.RichText = true
			local v287 = p275.Serial
			v_u_286.Text = ("<b><font color=\"rgb(175,175,175)\">Serial</font></b>: <font color=\"rgb(255,255,255)\">%*</font>"):format(typeof(v287) ~= "number" and "N/A" or ("#%*"):format((tostring(v287):reverse():gsub("(%d%d%d)", "%1,"):reverse():gsub("^,", ""))))
		end
		local v_u_288 = v_u_277:FindFirstChild("Pattern")
		if v_u_288 then
			if v283 then
				v_u_288.Visible = true
				v_u_288.RichText = true
				local v289 = p275.Pattern or 0
				v_u_288.Text = ("<b><font color=\"rgb(175,175,175)\">Pattern</font></b>: <font color=\"rgb(255,255,255)\">%*</font>"):format((tostring(v289)))
			elseif p275.Skin:find("PATTERN") then
				local v290 = p275.Skin
				local _, v291 = table.unpack(v290:split("_PATTERN_"))
				v_u_288.Text = ("<b><font color=\"rgb(175,175,175)\">Pattern</font></b>: <font color=\"rgb(255,255,255)\">%*</font>"):format(v291)
				v_u_288.Visible = true
			else
				v_u_288.Visible = false
			end
		end
		local v_u_292 = v_u_277:FindFirstChild("Float")
		if v_u_292 then
			v_u_292.Visible = not v283
			if not v283 then
				v_u_292.RichText = true
				v_u_292.Text = ("<b><font color=\"rgb(175,175,175)\">Float</font></b>: <font color=\"rgb(255,255,255)\">%*</font>"):format((string.format("%.14f", p275.Float or 0)))
			end
		end
		task.defer(function()
			-- upvalues: (copy) v_u_284, (copy) v_u_285, (copy) v_u_286, (copy) v_u_288, (copy) v_u_292, (ref) v_u_273, (copy) v_u_277
			local v293 = {}
			if v_u_284 and v_u_284.Visible then
				local v294 = v_u_284
				table.insert(v293, v294)
			end
			if v_u_285 then
				local v295 = v_u_285
				table.insert(v293, v295)
			end
			if v_u_286 then
				local v296 = v_u_286
				table.insert(v293, v296)
			end
			if v_u_288 and v_u_288.Visible then
				local v297 = v_u_288
				table.insert(v293, v297)
			end
			if v_u_292 and v_u_292.Visible then
				local v298 = v_u_292
				table.insert(v293, v298)
			end
			v_u_273(v_u_277, v293)
		end)
	end
end
local function v_u_302() -- name: isStoreOriginInspect
	-- upvalues: (copy) v_u_28, (copy) v_u_31
	if v_u_28.IsCaseSceneActive() or (v_u_28.GetScreenBeforeCaseScene() == "Store" or v_u_28.GetCurrentScreen() == "Store") then
		return true
	end
	local v300 = v_u_31:FindFirstChild("MainGui")
	if v300 then
		v300 = v300:FindFirstChild("Menu")
	end
	if v300 then
		v300 = v300:FindFirstChild("Store")
	end
	if v300 then
		v300 = v300:FindFirstChild("CaseContent")
	end
	local v301
	if v300 == nil then
		v301 = false
	else
		v301 = v300:GetAttribute("WasVisibleBeforeInspect") == true
	end
	return v301
end
local function v_u_312(p_u_303, p_u_304, p_u_305, p_u_306) -- name: setupButtonEvents
	-- upvalues: (copy) v_u_51, (copy) v_u_259, (ref) v_u_42, (copy) v_u_302, (copy) v_u_299, (ref) v_u_52, (copy) v_u_245, (copy) v_u_264, (copy) v_u_1
	v_u_51:Add(p_u_303.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_259, (copy) p_u_304, (copy) p_u_303, (copy) p_u_306, (ref) v_u_42, (ref) v_u_302, (ref) v_u_299
		v_u_259(p_u_304, p_u_303, true)
		if p_u_304 == "Info" then
			local v307 = p_u_306
			local v308 = p_u_303
			if v307 and (v_u_42 and (not v_u_302() and v_u_42.Type ~= "Badge")) then
				v_u_299(v307, v_u_42, v308)
			end
		end
	end), "Disconnect", "InspectButton_Enter_" .. p_u_304)
	v_u_51:Add(p_u_303.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_259, (copy) p_u_304, (copy) p_u_303, (copy) p_u_306
		v_u_259(p_u_304, p_u_303, false)
		local v309 = p_u_304 == "Info" and (p_u_306 and p_u_306:FindFirstChild("Information"))
		if v309 then
			v309.Visible = false
		end
	end), "Disconnect", "InspectButton_Leave_" .. p_u_304)
	if p_u_304 == "Info" then
		v_u_51:Add(p_u_303.Activated:Connect(function()
			-- upvalues: (copy) p_u_306, (copy) p_u_303, (ref) v_u_42, (ref) v_u_302, (ref) v_u_299
			local v310 = p_u_306
			local v311 = p_u_303
			if v310 and (v_u_42 and (not v_u_302() and v_u_42.Type ~= "Badge")) then
				v_u_299(v310, v_u_42, v311)
			end
		end), "Disconnect", "InspectButton_Activated_Info")
	else
		v_u_51:Add(p_u_303.MouseButton1Click:Connect(function()
			-- upvalues: (ref) v_u_52, (copy) p_u_304, (ref) v_u_245, (ref) v_u_264, (copy) p_u_305, (ref) v_u_1
			if v_u_52 == p_u_304 then
				if p_u_304 == "Viewmodel" then
					v_u_1.PlayInspectAnimation()
				end
			else
				v_u_245(p_u_304)
				v_u_264(p_u_305, p_u_304)
			end
		end), "Disconnect", "InspectButton_Click_" .. p_u_304)
	end
end
local function v_u_336(p313, p314) -- name: setupInspectButtons
	-- upvalues: (copy) v_u_59, (copy) v_u_20, (copy) v_u_302, (copy) v_u_259, (copy) v_u_312
	local v315 = p313:FindFirstChild("Bottom").Middle
	if v315 then
		v315 = v315:FindFirstChild("Buttons")
	end
	if v315 then
		local v316
		if v_u_59[p314.Type] == true then
			v316 = true
		else
			local v317 = v_u_59
			local v318
			if p314.Name then
				local v319 = v_u_20
				local v320 = p314.Name
				local v321, v322 = pcall(v319, v320)
				if v321 and v322 then
					v318 = v322.Class
				else
					v318 = nil
				end
			else
				v318 = nil
			end
			v316 = v317[v318] == true
		end
		local v323
		if p314 == nil then
			v323 = false
		elseif p314.Type == "Glove" then
			v323 = true
		else
			local v324
			if p314.Name then
				local v325 = v_u_20
				local v326 = p314.Name
				local v327, v328 = pcall(v325, v326)
				if v327 and v328 then
					v324 = v328.Class
				else
					v324 = nil
				end
			else
				v324 = nil
			end
			v323 = v324 == "Glove"
		end
		local v329 = {
			["Info"] = v315:FindFirstChild("Info"),
			["Viewmodel"] = v315:FindFirstChild("Viewmodel"),
			["Weapon"] = v315:FindFirstChild("Weapon")
		}
		local v330 = v_u_302()
		local v331 = p314.Type == "Badge"
		for v332, v333 in pairs(v329) do
			if not (v333 and v333:IsA("GuiButton")) then
				continue
			end
			if v332 == "Info" then
				local v334 = not v330
				if v334 then
					v334 = not v331
				end
				v333.Visible = v334
			elseif v332 == "Weapon" then
				local v335
				if v316 then
					v335 = not v323
				else
					v335 = v316
				end
				v333.Visible = v335
			else
				v333.Visible = v316
			end
			v_u_259(v332, v333, false)
			v_u_312(v333, v332, v329, p313)
		end
	end
end
local function v_u_340(p337, p338) -- name: getWearPreviewChance
	for _, v339 in ipairs(p337.floatChances or {}) do
		if v339.wear ~= p338 then
			continue
		end
		return v339.chance
	end
	return nil
end
local function v_u_344(p341, p342) -- name: setKillTrakBadgeVisible
	for _, v343 in ipairs({
		"Bottom",
		"Middle",
		"Description",
		"Statrak"
	}) do
		if not p341 then
			continue
		end
		p341 = p341:FindFirstChild(v343)
	end
	if p341 and p341:IsA("GuiObject") then
		p341.Visible = p342
	end
end
local function v_u_353(p_u_345, p346, p347) -- name: updateStatTrakToggle
	-- upvalues: (ref) v_u_79, (copy) v_u_51, (copy) v_u_344, (ref) v_u_42, (ref) v_u_52, (ref) v_u_47, (ref) v_u_41, (ref) v_u_38, (ref) v_u_39, (ref) v_u_40, (ref) v_u_43, (copy) v_u_14, (copy) v_u_200, (copy) v_u_226
	local v348 = p346:FindFirstChild("KillTrak")
	if v348 then
		v348.Visible = p347
		local v349 = v348:FindFirstChild("Button")
		if v349 and v349:IsA("GuiButton") then
			local v_u_350 = v349:FindFirstChild("CheckmarkImage")
			if v_u_350 then
				v_u_350.Visible = v_u_79
			end
			v_u_51:Add(v349.Activated:Connect(function()
				-- upvalues: (ref) v_u_79, (copy) v_u_350, (ref) v_u_344, (copy) p_u_345, (ref) v_u_42, (ref) v_u_52, (ref) v_u_47, (ref) v_u_41, (ref) v_u_38, (ref) v_u_39, (ref) v_u_40, (ref) v_u_43, (ref) v_u_14, (ref) v_u_200, (ref) v_u_226
				v_u_79 = not v_u_79
				if v_u_350 then
					v_u_350.Visible = v_u_79
				end
				v_u_344(p_u_345, v_u_79)
				local v351 = v_u_42
				if v351 then
					local v352 = table.clone(v351)
					v352.StatTrack = v_u_79 and 0 or false
					v_u_42 = v352
					if v_u_52 == "Weapon" then
						if v_u_47 then
							v_u_47:Destroy()
							v_u_47 = nil
						end
						v_u_41 = nil
					elseif v_u_52 == "Viewmodel" then
						if v_u_38 then
							if v_u_38.IsPlaying then
								v_u_38:Stop(0)
							end
							v_u_38:Destroy()
							v_u_38 = nil
						end
						if v_u_39 then
							v_u_39:Destroy()
							v_u_39 = nil
						end
						if v_u_40 then
							v_u_40:destroy()
							v_u_40 = nil
						end
						if v_u_43 then
							v_u_43:Destroy()
							v_u_43 = nil
						end
						v_u_14.enableGroup("Gameplay")
					end
					if v_u_52 == "Weapon" then
						v_u_200(v352)
						return
					end
					if v_u_52 == "Viewmodel" then
						v_u_14.disableGroup("Gameplay")
						v_u_226(v352)
					end
				end
			end), "Disconnect", "FloatPreview_StatTrakToggle")
		end
	else
		return
	end
end
local function v_u_369(p354, p355, p356, p357, p358) -- name: updateFloatPreviewRow
	-- upvalues: (copy) v_u_74, (copy) v_u_25, (copy) v_u_26
	p354.Name = p355.Wear
	p354.Visible = true
	p354.LayoutOrder = table.find(v_u_74, p355) or 0
	p354:SetAttribute("Wear", p355.Wear)
	p354:SetAttribute("PreviewFloat", p357)
	local v359 = p354:FindFirstChild("Left")
	local v360
	if v359 then
		v360 = v359:FindFirstChild("Label")
	else
		v360 = v359
	end
	if v360 and v360:IsA("TextLabel") then
		v360.Text = p355.Display
		v360.TextColor3 = p355.Color
	end
	if v359 then
		v359 = v359:FindFirstChild("Percent")
	end
	if v359 and v359:IsA("TextLabel") then
		v359.Text = not p358 and "" or string.format("%.2f%%", p358)
	end
	local v361 = p354:FindFirstChild("Bar")
	if v361 then
		v361 = v361:FindFirstChild("Current")
	end
	if v361 and v361:IsA("Frame") then
		local v362 = v361.Size
		local v363 = (p358 or 0) / 100
		local v364 = math.clamp(v363, 0, 1)
		v361.Size = UDim2.new(v364, 0, v362.Y.Scale, v362.Y.Offset)
		v361.BackgroundColor3 = p355.Color
	end
	local v365 = p354:FindFirstChild("Icon", true)
	if v365 and v365:IsA("ImageLabel") then
		v365.Image = v_u_25.GetWearImageForFloat(p356, p357) or (p356.imageAssetId or "")
	end
	local v366 = v_u_26[p356.rarity]
	if v366 then
		local v367 = p354:FindFirstChild("RarityFrame", true)
		if v367 and v367:IsA("Frame") then
			v367.BackgroundColor3 = v366.Color
		end
		local v368 = p354:FindFirstChild("Rarity", true)
		if v368 and v368:IsA("ImageLabel") then
			v368.ImageColor3 = v366.Color
		end
	end
end
local function v_u_396(p370, p371, p372) -- name: updateFloatPreviewFrame
	-- upvalues: (copy) v_u_114, (copy) v_u_302, (ref) v_u_79, (copy) v_u_353, (copy) v_u_74, (copy) v_u_340, (copy) v_u_37, (copy) v_u_369, (ref) v_u_42, (ref) v_u_52, (ref) v_u_47, (ref) v_u_41, (ref) v_u_38, (ref) v_u_39, (ref) v_u_40, (ref) v_u_43, (copy) v_u_14, (copy) v_u_200, (copy) v_u_226, (copy) v_u_19, (copy) v_u_51
	local v373 = p370:FindFirstChild("FloatPreviews")
	if v373 then
		local v374 = v373:FindFirstChild("Container")
		if v374 then
			for _, v375 in ipairs(v374:GetChildren()) do
				if not v375:IsA("Frame") then
					continue
				end
				v375:Destroy()
			end
			local v376
			if p372 == nil or p371.HideWearDetails ~= true then
				v376 = false
			else
				v376 = p371.Type ~= "Charm"
			end
			v373.Visible = v376
			if v376 and p372 then
				v374.Visible = true
				v373.Position = v_u_114(v373)
				v373:SetAttribute("IsOpen", true)
				local v377 = v373:FindFirstChild("ToggleButton")
				if v377 and v377:IsA("GuiButton") then
					local v378 = v377:FindFirstChild("TextLabel")
					if v378 and v378:IsA("TextLabel") then
						v378.Rotation = 0
					end
				end
				local v379
				if ((p372.type == "Glove" or p372.supportsStatTrak == false) and 0 or (p372.statTrakChance or 0)) > 0 then
					v379 = v_u_302()
				else
					v379 = false
				end
				if not v379 then
					v_u_79 = false
				end
				v_u_353(p370, v373, v379)
				for _, v380 in ipairs(v_u_74) do
					local v381 = p372.floatRange.min
					local v382 = v380.Min
					local v383 = math.max(v381, v382)
					local v384 = p372.floatRange.max
					local v385 = v380.Max - 1e-12
					local v386 = math.min(v384, v385)
					local v_u_387
					if v386 < v383 then
						v_u_387 = nil
					else
						local v388 = (v383 + v386) / 2
						v_u_387 = math.clamp(v388, 0, 1)
					end
					local v389 = v_u_340(p372, v380.Wear)
					if not v_u_387 or (not v389 or v389 <= 0) then
						continue
					end
					local v390 = v_u_37:Clone()
					v_u_369(v390, v380, p372, v_u_387, v389)
					local function v393() -- name: selectWearPreview
						-- upvalues: (ref) v_u_42, (copy) v_u_387, (ref) v_u_52, (ref) v_u_47, (ref) v_u_41, (ref) v_u_38, (ref) v_u_39, (ref) v_u_40, (ref) v_u_43, (ref) v_u_14, (ref) v_u_200, (ref) v_u_226
						local v391 = v_u_42
						if v391 then
							local v392 = table.clone(v391)
							v392.Float = v_u_387
							v392.HideWearDetails = true
							v392.ShowFullPriceRange = true
							v_u_42 = v392
							if v_u_52 == "Weapon" then
								if v_u_47 then
									v_u_47:Destroy()
									v_u_47 = nil
								end
								v_u_41 = nil
							elseif v_u_52 == "Viewmodel" then
								if v_u_38 then
									if v_u_38.IsPlaying then
										v_u_38:Stop(0)
									end
									v_u_38:Destroy()
									v_u_38 = nil
								end
								if v_u_39 then
									v_u_39:Destroy()
									v_u_39 = nil
								end
								if v_u_40 then
									v_u_40:destroy()
									v_u_40 = nil
								end
								if v_u_43 then
									v_u_43:Destroy()
									v_u_43 = nil
								end
								v_u_14.enableGroup("Gameplay")
							end
							if v_u_52 == "Weapon" then
								v_u_200(v392)
							elseif v_u_52 == "Viewmodel" then
								v_u_14.disableGroup("Gameplay")
								v_u_226(v392)
							end
						else
							return
						end
					end
					local v394 = v390:FindFirstChild("Inspect")
					if v394 and v394:IsA("GuiObject") then
						v394.Visible = false
					end
					local v395 = v390:FindFirstChild("Button")
					if v395 and v395:IsA("GuiButton") then
						v_u_19(v395)
						v_u_51:Add(v395.Activated:Connect(v393), "Disconnect", "FloatPreview_Button_" .. v380.Wear)
					end
					v390.Parent = v374
				end
			end
		else
			v373.Visible = false
			return
		end
	else
		return
	end
end
local function v_u_406(p397, p398) -- name: updateCollectionData
	-- upvalues: (copy) v_u_21, (copy) v_u_69, (copy) v_u_71, (copy) v_u_70, (copy) v_u_72
	if p398 then
		p398 = p398.collection
	end
	local v399
	if p398 then
		v399 = v_u_21.GetCollectionByName(p398)
	else
		v399 = p398
	end
	local v400 = v399 ~= nil
	local v401 = p397.Top.Frame.Frame.TextInfo:FindFirstChild("Collection")
	if v401 and v401:IsA("TextLabel") then
		v401.Visible = v400
		v401.Text = p398 or ""
	end
	local v402 = p397.Top.Frame.Frame:FindFirstChild("CollectionIcon")
	if v402 and v402:IsA("ImageLabel") then
		v402.Image = v399 and v399.imageAssetId or ""
		v402.Visible = v400
	end
	local v403 = p397:FindFirstChild("WeaponName")
	if v403 and v403:IsA("TextLabel") then
		v403.Position = v_u_69
		local v404
		if v400 then
			v404 = v_u_71
		else
			v404 = v_u_70
		end
		v403.Size = v404
		v403.TextXAlignment = Enum.TextXAlignment.Center
	end
	local v405 = p397:FindFirstChild("Rarity")
	if v405 and v405:IsA("Frame") then
		v405.Position = v_u_72
	end
end
local function v_u_419(p407) -- name: updateInspectFrameUI
	-- upvalues: (copy) v_u_31, (copy) v_u_336, (copy) v_u_302, (copy) v_u_25, (copy) v_u_396, (copy) v_u_18, (copy) v_u_406, (copy) v_u_26
	local v408 = v_u_31:FindFirstChild("MainGui")
	if v408 then
		v408 = v408:FindFirstChild("Menu")
	end
	if v408 then
		v408 = v408:FindFirstChild("Inspect") or v408:FindFirstChild("InspectFrame")
	end
	if v408 then
		v_u_336(v408, p407)
		local v409 = v_u_302() and v408:FindFirstChild("Information")
		if v409 then
			v409.Visible = false
		end
		local v410 = v_u_25.GetSkinInformation(p407.Name, p407.Skin)
		v_u_396(v408, p407, v410)
		local v411 = v408.Top.Frame.Frame.TextInfo:FindFirstChild("Item")
		if v411 and v411:IsA("TextLabel") then
			local v412 = v_u_18(p407.Skin)
			local v413 = v410 and v410.type == "Melee" and "\226\152\133 " or ""
			v_u_18.ApplyNameLabel(v411, v413 .. v_u_18.GetWeaponDisplayName(p407.Name, p407.NameTag) .. " | " .. v412, p407.NameTag)
		end
		if v410 then
			v_u_406(v408, v410)
			local v414 = v408.Top.Frame:FindFirstChild("Rarity")
			local v415 = v414 and (v414:IsA("Frame") and v410.rarity) and v_u_26[v410.rarity]
			if v415 then
				v414.BackgroundColor3 = v415.Color
			end
		end
		local v416 = v408.Bottom.Middle:FindFirstChild("Description")
		if v416 then
			local v417 = p407.StatTrack
			local v418 = typeof(v417) == "number" and true or p407.StatTrack == true
			v416.Statrak.Visible = v418
			v416.Description.Text = v410 and v410.description or ""
		end
	end
end
local function v_u_423() -- name: hideViewmodels
	-- upvalues: (ref) v_u_50, (copy) v_u_34, (ref) v_u_40
	v_u_50 = {}
	for _, v420 in ipairs(v_u_34:GetChildren()) do
		if not v420:IsA("Model") or (v420.Name == "InspectScene" or v_u_40 and v_u_40.Model == v420) then
			continue
		end
		for _, v421 in ipairs(v420:GetDescendants()) do
			if v421:IsA("BasePart") or v421:IsA("Texture") then
				if v421.Transparency >= 1 then
					continue
				end
				v421:SetAttribute("_InspectPrevTransparency", v421.Transparency)
				v421.Transparency = 1
			else
				if not (v421:IsA("SurfaceGui") and v421.Enabled) then
					continue
				end
				v421:SetAttribute("_InspectPrevSurfaceGuiEnabled", true)
				v421.Enabled = false
			end
		end
		local v422 = v_u_50
		table.insert(v422, v420)
	end
end
local function v_u_428() -- name: showViewmodels
	-- upvalues: (ref) v_u_50
	for _, v424 in ipairs(v_u_50) do
		if not (v424 and v424.Parent) then
			continue
		end
		for _, v425 in ipairs(v424:GetDescendants()) do
			if v425:IsA("BasePart") then
				local v426 = v425:GetAttribute("_InspectPrevTransparency")
				if v426 == nil then
					continue
				end
				v425.Transparency = v426
				v425:SetAttribute("_InspectPrevTransparency", nil)
			elseif v425:IsA("SurfaceGui") then
				if v425:GetAttribute("_InspectPrevSurfaceGuiEnabled") == nil then
					continue
				end
				v425.Enabled = true
				v425:SetAttribute("_InspectPrevSurfaceGuiEnabled", nil)
			else
				if not v425:IsA("Texture") then
					continue
				end
				local v427 = v425:GetAttribute("_InspectPrevTransparency")
				if v427 == nil then
					v425.Transparency = 0.3
				else
					v425.Transparency = v427
					v425:SetAttribute("_InspectPrevTransparency", nil)
				end
			end
		end
	end
	v_u_50 = {}
end
local function v_u_442() -- name: restoreMenuFrames
	-- upvalues: (copy) v_u_28, (ref) v_u_46, (copy) v_u_11, (copy) v_u_98
	local v429 = v_u_28.GetMenuFrame()
	if v429 and v429.Visible then
		local v430 = v429:FindFirstChild("Inspect") or v429:FindFirstChild("InspectFrame")
		if v430 and v430:IsA("GuiObject") then
			local v431 = v430:FindFirstChild("MobileButtons")
			v430.Visible = false
			if v431 then
				v431.Visible = false
			end
		end
		local v432 = v_u_28.GetScreenBeforeInspect()
		local v433 = v_u_46
		v_u_46 = false
		v_u_28.ExitInspect()
		if v433 then
			v_u_11.ShowMenuScene()
			v_u_11.SetMusicVolumeMultiplier(1, 0.5)
		end
		local v434 = v429:FindFirstChild("Top")
		if v434 then
			v434.Visible = true
		end
		if v432 then
			local v435 = v429:FindFirstChild(v432)
			if v435 then
				v_u_98(v429, v432)
				v435.Visible = true
				if v_u_28.IsCaseSceneActive() and v432 == "Store" or v_u_28.IsSceneScreen(v432) then
					v_u_28.SetBlurEnabled(false)
					v429.BackgroundTransparency = 1
					local v436 = v429:FindFirstChild("Pattern")
					if v436 then
						v436.Visible = false
						return
					end
				else
					local v437
					if v432 == "Dashboard" then
						v437 = false
					else
						v437 = v432 ~= "Play"
					end
					local v438 = not v437
					v_u_28.SetBlurEnabled(v437)
					v429.BackgroundTransparency = v437 and 0.15 or 1
					local v439 = v429:FindFirstChild("Pattern")
					if v439 then
						v439.Visible = v438
						return
					end
				end
			end
		else
			v_u_98(v429, "Dashboard")
			local v440 = v429:FindFirstChild("Dashboard")
			if v440 then
				v440.Visible = true
			end
			v_u_28.SetBlurEnabled(false)
			v429.BackgroundTransparency = 1
			local v441 = v429:FindFirstChild("Pattern")
			if v441 then
				v441.Visible = true
			end
		end
	else
		v_u_46 = false
		v_u_28.ExitInspect()
	end
end
function v_u_1.ShowInspect(p443) -- name: ShowInspect
	-- upvalues: (ref) v_u_55, (copy) v_u_1, (copy) v_u_27, (ref) v_u_77, (ref) v_u_78, (ref) v_u_42, (ref) v_u_79, (ref) v_u_52, (copy) v_u_20, (copy) v_u_103, (copy) v_u_423, (copy) v_u_168, (copy) v_u_419, (ref) v_u_45, (copy) v_u_442, (ref) v_u_49, (copy) v_u_88, (ref) v_u_48, (copy) v_u_36, (ref) v_u_44, (copy) v_u_3, (copy) v_u_2, (copy) v_u_14, (copy) v_u_226, (copy) v_u_200, (copy) v_u_56, (ref) v_u_65, (ref) v_u_66, (ref) v_u_67, (ref) v_u_68, (ref) v_u_63, (ref) v_u_64, (copy) v_u_34, (copy) v_u_13, (copy) v_u_51, (copy) v_u_15, (copy) v_u_4, (ref) v_u_40, (ref) v_u_47, (copy) v_u_57, (ref) v_u_41, (ref) v_u_61, (ref) v_u_62, (copy) v_u_91, (copy) v_u_30, (ref) v_u_75, (ref) v_u_76, (copy) v_u_94, (copy) v_u_28, (copy) v_u_33, (copy) v_u_164
	if v_u_55 then
		v_u_1.HideInspect()
	end
	if v_u_27.broadcastRouter("HasPendingCharmAttachment") then
		v_u_77 = p443
		v_u_78 = 1
	else
		v_u_77 = nil
	end
	v_u_42 = p443
	v_u_79 = false
	local v444
	if p443 == nil then
		v444 = false
	elseif p443.Type == "Glove" then
		v444 = true
	else
		local v445
		if p443.Name then
			local v446 = v_u_20
			local v447 = p443.Name
			local v448, v449 = pcall(v446, v447)
			if v448 and v449 then
				v445 = v449.Class
			else
				v445 = nil
			end
		else
			v445 = nil
		end
		v444 = v445 == "Glove"
	end
	v_u_52 = v444 and "Viewmodel" or "Weapon"
	v_u_103()
	v_u_423()
	v_u_168()
	v_u_419(p443)
	if v_u_45 then
		if v_u_45.Parent ~= workspace then
			v_u_45.Parent = workspace
		end
		v_u_49 = v_u_45
		v_u_88(v_u_49)
		if v_u_48 then
			local v450 = v_u_48
			local v451 = v_u_36:FindFirstChild(v450) or v_u_36:FindFirstChild("Menu")
			if v451 then
				v_u_44 = v_u_3.ApplyScene(v450, v451)
			end
		end
		local v_u_452
		if v_u_49 then
			v_u_452 = v_u_49:FindFirstChild("CamPart")
		else
			v_u_452 = nil
		end
		if v_u_452 then
			if v_u_49 and v_u_49:FindFirstChild("WeaponPart") then
				if v_u_52 == "Viewmodel" then
					v_u_14.disableGroup("Gameplay")
					v_u_226(p443)
				else
					v_u_14.enableGroup("Gameplay")
					v_u_200(p443)
				end
				local v453 = v_u_52 ~= "Viewmodel" and 40 or v_u_56
				v_u_65 = 0
				v_u_66 = 0
				v_u_67 = 0
				v_u_68 = 0
				v_u_63 = v453
				v_u_64 = v453
				v_u_34.CameraType = Enum.CameraType.Scriptable
				v_u_34.CFrame = v_u_452.CFrame
				v_u_34.Focus = v_u_452.CFrame
				v_u_13.updateCameraFOV(v_u_52 ~= "Viewmodel" and 40 or v_u_56)
				v_u_13.setForceLockOverride("Inspect", true)
				v_u_51:Add(v_u_15.BindToRenderStep("InspectController.CameraUpdate", function(p454)
					-- upvalues: (ref) v_u_63, (ref) v_u_64, (ref) v_u_49, (copy) v_u_452, (ref) v_u_34, (ref) v_u_13, (ref) v_u_52, (ref) v_u_4, (ref) v_u_68, (ref) v_u_67, (ref) v_u_40, (ref) v_u_65, (ref) v_u_66, (ref) v_u_47, (ref) v_u_57, (ref) v_u_41
					local v455 = p454 * 8
					local v456 = math.min(1, v455)
					v_u_63 = v_u_63 + (v_u_64 - v_u_63) * v456
					if v_u_49 and v_u_452 then
						v_u_34.CameraType = Enum.CameraType.Scriptable
						v_u_34.CFrame = v_u_452.CFrame
						v_u_34.Focus = v_u_452.CFrame
						v_u_34.FieldOfView = v_u_13.clampFOV(v_u_63)
					end
					if v_u_52 == "Weapon" and v_u_4.GamepadEnabled then
						local v457 = v_u_4:GetLastInputType()
						local v458 = v_u_4:GetGamepadState((v457 == Enum.UserInputType.Gamepad1 or (v457 == Enum.UserInputType.Gamepad2 or (v457 == Enum.UserInputType.Gamepad3 or v457 == Enum.UserInputType.Gamepad4))) and v457 and v457 or Enum.UserInputType.Gamepad1)
						if v458 then
							for _, v459 in pairs(v458) do
								if v459.KeyCode == Enum.KeyCode.Thumbstick2 then
									local v460 = Vector2.new(v459.Position.X, v459.Position.Y)
									if v460.Magnitude <= 0.1 then
										continue
									end
									local v461 = Vector2.new(v460.X * 0.5 * 60 * p454 * 4.75, v460.Y * 0.5 * 60 * p454 * 4.75)
									v_u_68 = v_u_68 + v461.X * 0.5
									local v462 = v_u_67 + v461.Y * 0.5
									v_u_67 = math.clamp(v462, -80, 80)
								else
									if v459.KeyCode ~= Enum.KeyCode.ButtonR2 and v459.KeyCode ~= Enum.KeyCode.ButtonL2 or v459.Position.Z <= 0.1 then
										continue
									end
									local v463
									if v459.KeyCode == Enum.KeyCode.ButtonR2 then
										v463 = -v459.Position.Z
									else
										v463 = v459.Position.Z
									end
									local v464 = v463 * 2 * 30 * p454 * 0.55
									if v_u_52 == "Viewmodel" then
										continue
									end
									local v465 = v_u_64 - v464 * 2
									v_u_64 = math.clamp(v465, 20, 70)
								end
							end
						end
					end
					if v_u_52 == "Viewmodel" and v_u_40 then
						v_u_40:render(p454)
					elseif v_u_52 == "Weapon" then
						local v466 = p454 * 10
						local v467 = math.min(1, v466)
						v_u_65 = v_u_65 + (v_u_67 - v_u_65) * v467
						v_u_66 = v_u_66 + (v_u_68 - v_u_66) * v467
						if v_u_47 then
							if not v_u_49 then
								return
							end
							local v468 = v_u_49:FindFirstChild("WeaponPart")
							if v468 then
								local v469 = v_u_66
								local v470 = v_u_65
								local v471 = CFrame.Angles(0, math.rad(v469), (math.rad(v470)))
								local v472 = v_u_47
								local v473 = v468.CFrame * v471 * v_u_57
								if v_u_41 then
									v473 = v473 * v472:GetPivot():ToObjectSpace(v_u_41.WorldCFrame):Inverse()
								end
								v472:PivotTo(v473)
							end
						end
					end
				end), "Disconnect", "CameraUpdate")
				v_u_51:Add(v_u_4.InputBegan:Connect(function(p474, _)
					-- upvalues: (ref) v_u_61, (ref) v_u_62, (ref) v_u_91, (ref) v_u_1, (ref) v_u_14, (ref) v_u_30, (ref) v_u_75, (ref) v_u_76, (ref) v_u_94
					if p474.UserInputType == Enum.UserInputType.MouseButton1 then
						v_u_61 = true
						v_u_62 = Vector2.new(p474.Position.X, p474.Position.Y)
						if not v_u_91(p474.Position) then
							v_u_1.PlayInspectAnimation()
						end
					end
					if table.find(v_u_14.getActionKeybinds("Inspect"), p474.KeyCode) then
						if v_u_30:GetAttribute("IsPlayerChatting") then
							return
						end
						v_u_1.PlayInspectAnimation()
					end
					if table.find(v_u_14.getActionKeybinds("Reload"), p474.KeyCode) then
						if v_u_30:GetAttribute("IsPlayerChatting") then
							return
						end
						v_u_1.CancelInspectAnimation()
					end
					if p474.UserInputType == Enum.UserInputType.Touch then
						v_u_75[p474] = Vector2.new(p474.Position.X, p474.Position.Y)
						local v475 = 0
						for _ in pairs(v_u_75) do
							v475 = v475 + 1
						end
						if v475 == 1 then
							v_u_61 = true
							v_u_62 = Vector2.new(p474.Position.X, p474.Position.Y)
						end
						v_u_76 = v_u_94()
					end
				end), "Disconnect", "InputBegan")
				v_u_51:Add(v_u_4.InputChanged:Connect(function(p476, _)
					-- upvalues: (ref) v_u_61, (ref) v_u_62, (ref) v_u_68, (ref) v_u_67, (ref) v_u_75, (ref) v_u_94, (ref) v_u_76, (ref) v_u_52, (ref) v_u_64
					if p476.UserInputType == Enum.UserInputType.MouseMovement and v_u_61 then
						local v477 = Vector2.new(p476.Position.X, p476.Position.Y)
						local v478 = v477 - v_u_62
						v_u_68 = v_u_68 + v478.X * 0.5
						local v479 = v_u_67 + v478.Y * 0.5
						v_u_67 = math.clamp(v479, -80, 80)
						v_u_62 = v477
					end
					if p476.UserInputType == Enum.UserInputType.Touch then
						local v480 = Vector2.new(p476.Position.X, p476.Position.Y)
						v_u_75[p476] = v480
						local v481 = 0
						for _ in pairs(v_u_75) do
							v481 = v481 + 1
						end
						if v481 == 1 and v_u_61 then
							local v482 = v480 - v_u_62
							v_u_68 = v_u_68 + v482.X * 0.5
							local v483 = v_u_67 + v482.Y * 0.5
							v_u_67 = math.clamp(v483, -80, 80)
							v_u_62 = v480
						end
						if v481 >= 2 then
							local v484 = v_u_94()
							if v484 and v_u_76 then
								local v485 = (v484 - v_u_76) * 0.01
								if v_u_52 ~= "Viewmodel" then
									local v486 = v_u_64 - v485 * 2
									v_u_64 = math.clamp(v486, 20, 70)
								end
							end
							v_u_76 = v484
						end
					end
					if p476.UserInputType == Enum.UserInputType.MouseWheel then
						local v487 = p476.Position.Z
						if v_u_52 == "Viewmodel" then
							return
						end
						local v488 = v_u_64 - v487 * 2
						v_u_64 = math.clamp(v488, 20, 70)
					end
				end), "Disconnect", "InputChanged")
				v_u_51:Add(v_u_4.InputEnded:Connect(function(p489, _)
					-- upvalues: (ref) v_u_61, (ref) v_u_75, (ref) v_u_76, (ref) v_u_94
					if p489.UserInputType == Enum.UserInputType.MouseButton1 then
						v_u_61 = false
					end
					if p489.UserInputType == Enum.UserInputType.Touch then
						v_u_75[p489] = nil
						local v490 = 0
						for _ in pairs(v_u_75) do
							v490 = v490 + 1
						end
						if v490 == 0 then
							v_u_61 = false
						end
						v_u_76 = v_u_94()
					end
				end), "Disconnect", "InputEnded")
				v_u_51:Add(function()
					-- upvalues: (ref) v_u_47, (ref) v_u_41, (ref) v_u_49, (ref) v_u_45, (ref) v_u_2, (ref) v_u_61, (ref) v_u_75, (ref) v_u_76, (ref) v_u_65, (ref) v_u_66, (ref) v_u_67, (ref) v_u_68, (ref) v_u_63, (ref) v_u_64
					if v_u_47 then
						v_u_47:Destroy()
						v_u_47 = nil
					end
					v_u_41 = nil
					if v_u_49 then
						if v_u_49 == v_u_45 then
							v_u_49.Parent = v_u_2
						else
							v_u_49:Destroy()
						end
						v_u_49 = nil
					end
					v_u_61 = false
					v_u_75 = {}
					v_u_76 = nil
					v_u_65 = 0
					v_u_66 = 0
					v_u_67 = 0
					v_u_68 = 0
					v_u_63 = 40
					v_u_64 = 40
				end, true, "InspectCleanup")
				v_u_55 = true
				local v491 = v_u_28.GetMenuFrame()
				if v491 then
					v491 = v491:FindFirstChild("Inspect") or v491:FindFirstChild("InspectFrame")
				end
				if v491 then
					v491 = v491:FindFirstChild("MobileButtons")
				end
				local v492
				if v491 then
					v492 = v491:FindFirstChild("Inspect")
				else
					v492 = v491
				end
				if v492 then
					local v493 = v_u_55
					if v493 then
						if v_u_52 == "Viewmodel" then
							v493 = v_u_33
						else
							v493 = false
						end
					end
					v491.Visible = v493
					v492.Visible = v493
				end
				v_u_164()
			else
				warn("[InspectController]: Inspect scene missing WeaponPart")
				if v_u_49 then
					v_u_49.Parent = v_u_2
					v_u_49 = nil
				end
				v_u_44 = v_u_3.RestoreMap(nil, v_u_44)
				v_u_442()
			end
		else
			warn("[InspectController]: Inspect scene missing CamPart")
			if v_u_49 then
				v_u_49.Parent = v_u_2
				v_u_49 = nil
			end
			v_u_44 = v_u_3.RestoreMap(nil, v_u_44)
			v_u_442()
			return
		end
	else
		warn("[InspectController]: No preloaded inspect scene available")
		v_u_442()
		return
	end
end
function v_u_1.HideInspect(p494) -- name: HideInspect
	-- upvalues: (ref) v_u_55, (ref) v_u_54, (copy) v_u_51, (ref) v_u_38, (ref) v_u_39, (ref) v_u_40, (ref) v_u_43, (copy) v_u_14, (ref) v_u_47, (ref) v_u_41, (copy) v_u_28, (copy) v_u_12, (ref) v_u_44, (copy) v_u_3, (copy) v_u_34, (copy) v_u_13, (copy) v_u_29, (copy) v_u_442, (ref) v_u_46, (copy) v_u_428, (ref) v_u_50, (ref) v_u_77, (ref) v_u_78, (ref) v_u_52, (copy) v_u_33, (copy) v_u_164
	if v_u_55 then
		v_u_54 = nil
		v_u_51:Cleanup()
		if v_u_38 then
			if v_u_38.IsPlaying then
				v_u_38:Stop(0)
			end
			v_u_38:Destroy()
			v_u_38 = nil
		end
		if v_u_39 then
			v_u_39:Destroy()
			v_u_39 = nil
		end
		if v_u_40 then
			v_u_40:destroy()
			v_u_40 = nil
		end
		if v_u_43 then
			v_u_43:Destroy()
			v_u_43 = nil
		end
		v_u_14.enableGroup("Gameplay")
		if v_u_47 then
			v_u_47:Destroy()
			v_u_47 = nil
		end
		v_u_41 = nil
		if v_u_28.IsCaseSceneActive() then
			v_u_12.ApplyCaseSceneLighting()
		else
			v_u_44 = v_u_3.RestoreMap(nil, v_u_44)
		end
		v_u_34.CameraType = Enum.CameraType.Custom
		v_u_13.updateCameraFOV(v_u_29.DEFAULT_CAMERA_FOV)
		v_u_13.setForceLockOverride("Inspect", false)
		if p494 then
			v_u_28.ExitInspect()
			v_u_46 = false
		else
			v_u_442()
		end
		if v_u_28.IsCaseSceneActive() then
			v_u_50 = {}
		else
			v_u_428()
		end
		v_u_77 = nil
		v_u_78 = 1
		v_u_55 = false
		local v495 = v_u_28.GetMenuFrame()
		if v495 then
			v495 = v495:FindFirstChild("Inspect") or v495:FindFirstChild("InspectFrame")
		end
		if v495 then
			v495 = v495:FindFirstChild("MobileButtons")
		end
		local v496
		if v495 then
			v496 = v495:FindFirstChild("Inspect")
		else
			v496 = v495
		end
		if v496 then
			local v497 = v_u_55
			if v497 then
				if v_u_52 == "Viewmodel" then
					v497 = v_u_33
				else
					v497 = false
				end
			end
			v495.Visible = v497
			v496.Visible = v497
		end
		v_u_164()
	end
end
function v_u_1.IsActive() -- name: IsActive
	-- upvalues: (ref) v_u_55
	return v_u_55
end
function v_u_1.CycleCharmPosition() -- name: CycleCharmPosition
	-- upvalues: (ref) v_u_55, (ref) v_u_77, (ref) v_u_78, (copy) v_u_1
	if v_u_55 and v_u_77 then
		v_u_78 = v_u_78 % 4 + 1
		local v498 = v_u_78
		v_u_1.RefreshWeaponWithCharm((tostring(v498)))
	end
end
function v_u_1.RefreshWeaponWithCharm(p499) -- name: RefreshWeaponWithCharm
	-- upvalues: (ref) v_u_55, (ref) v_u_49, (ref) v_u_77, (ref) v_u_65, (ref) v_u_66, (ref) v_u_67, (ref) v_u_68, (ref) v_u_52, (ref) v_u_47, (ref) v_u_41, (copy) v_u_25, (copy) v_u_187, (copy) v_u_57, (ref) v_u_40, (ref) v_u_43
	if v_u_55 and (v_u_49 and v_u_77) then
		local v500 = v_u_49
		local v501 = v_u_77
		if v500:FindFirstChild("WeaponPart") then
			local v502 = v_u_65
			local v503 = v_u_66
			local v504 = v_u_67
			local v505 = v_u_68
			local v506 = v501.Charm
			local v507 = type(v506) == "table" and {
				["_id"] = v506._id,
				["Position"] = p499
			} or p499
			if v_u_52 == "Weapon" then
				if v_u_47 then
					v_u_47:Destroy()
					v_u_47 = nil
				end
				v_u_41 = nil
				local v508 = v_u_25.GetInspectModel(v501.Name, v501.Skin, v501.Float, v501.StatTrack, v501.NameTag, v507, v501.Stickers)
				if not v508 then
					warn((("[InspectController]: Failed to refresh weapon model for charm position %*"):format(p499)))
					return
				end
				v_u_187(v508, false)
				v508.Parent = v500
				v_u_65 = v502
				v_u_66 = v503
				v_u_67 = v504
				v_u_68 = v505
				local v509 = v_u_47 and v_u_49 and v_u_49:FindFirstChild("WeaponPart")
				if v509 then
					local v510 = v_u_66
					local v511 = v_u_65
					local v512 = CFrame.Angles(0, math.rad(v510), (math.rad(v511)))
					local v513 = v_u_47
					local v514 = v509.CFrame * v512 * v_u_57
					if v_u_41 then
						v514 = v514 * v513:GetPivot():ToObjectSpace(v_u_41.WorldCFrame):Inverse()
					end
					v513:PivotTo(v514)
				end
			end
			if v_u_40 and v_u_43 then
				v_u_40.Charm = v507
				v_u_40:construct(v_u_43, nil)
			end
		end
	else
		return
	end
end
function v_u_1.PlayInspectAnimation() -- name: PlayInspectAnimation
	-- upvalues: (ref) v_u_52, (ref) v_u_40, (ref) v_u_42, (copy) v_u_20, (ref) v_u_38
	if v_u_52 == "Viewmodel" and v_u_40 then
		local v515 = v_u_42
		local v516
		if v515 == nil then
			v516 = false
		elseif v515.Type == "Glove" then
			v516 = true
		else
			local v517
			if v515.Name then
				local v518 = v_u_20
				local v519 = v515.Name
				local v520, v521 = pcall(v518, v519)
				if v520 and v521 then
					v517 = v521.Class
				else
					v517 = nil
				end
			else
				v517 = nil
			end
			v516 = v517 == "Glove"
		end
		if v516 then
			if v_u_38 then
				if not v_u_38.IsPlaying then
					if v_u_40 and v_u_40.Animation then
						v_u_40.Animation:stopAnimations()
					end
					v_u_38.TimePosition = 0
					v_u_38:Play(0, 1, 1)
				end
			end
		elseif v_u_40.Animation then
			local v522 = v_u_40.Animation:pickInspectVariant()
			v_u_40.Animation:stopAnimations()
			v_u_40.Animation:play("Idle")
			v_u_40.Animation:play(v522)
		end
	end
end
function v_u_1.CancelInspectAnimation() -- name: CancelInspectAnimation
	-- upvalues: (ref) v_u_52, (ref) v_u_40, (ref) v_u_42, (copy) v_u_20
	if v_u_52 == "Viewmodel" and v_u_40 then
		local v523 = v_u_42
		local v524
		if v523 == nil then
			v524 = false
		elseif v523.Type == "Glove" then
			v524 = true
		else
			local v525
			if v523.Name then
				local v526 = v_u_20
				local v527 = v523.Name
				local v528, v529 = pcall(v526, v527)
				if v528 and v529 then
					v525 = v529.Class
				else
					v525 = nil
				end
			else
				v525 = nil
			end
			v524 = v525 == "Glove"
		end
		if not v524 then
			if v_u_40.Animation then
				v_u_40.Animation:markInspectCancel()
				v_u_40.Animation:crossfadeTo("Idle", 0.25)
			end
		end
	else
		return
	end
end
function v_u_1.Initialize() -- name: Initialize
	-- upvalues: (copy) v_u_16, (copy) v_u_30, (copy) v_u_3, (ref) v_u_44, (copy) v_u_164, (copy) v_u_4, (copy) v_u_84, (ref) v_u_48, (ref) v_u_45, (copy) v_u_2, (ref) v_u_55, (copy) v_u_1, (copy) v_u_27, (ref) v_u_78
	v_u_16.CreateListener(v_u_30, "Settings.Video.Presets.Global Shadows", function()
		-- upvalues: (ref) v_u_3, (ref) v_u_44
		v_u_3.ApplyGlobalShadows(v_u_44)
	end)
	v_u_16.CreateListener(v_u_30, "Settings.Keyboard/Mouse", v_u_164)
	v_u_4:GetPropertyChangedSignal("PreferredInput"):Connect(v_u_164)
	local v530 = v_u_84()
	if v530 then
		v_u_48 = v530.Name
		v_u_45 = v530
		v530.Name = "InspectScene"
		v530.Parent = v_u_2
	else
		warn("[InspectController]: No inspect scene found to preload in ReplicatedStorage.Assets.InspectScenes")
	end
	v_u_4.InputBegan:Connect(function(p531, p532)
		-- upvalues: (ref) v_u_55, (ref) v_u_1
		if not p532 then
			if p531.KeyCode == Enum.KeyCode.Escape and v_u_55 then
				v_u_1.HideInspect()
			end
		end
	end)
	v_u_30.CharacterAdded:Connect(function()
		-- upvalues: (ref) v_u_55, (ref) v_u_1
		if v_u_55 then
			v_u_1.HideInspect()
		end
	end)
	v_u_27.observerRouter("WeaponInspect", function(p533, p534, p535, p536, p537, p538, p539, p540, p541, p542, p543, p544, p545, p546)
		-- upvalues: (ref) v_u_2, (ref) v_u_1
		if not require(v_u_2.Controllers.EndScreenController).IsActive() then
			local v547 = {
				["_id"] = p542 or "inspect_" .. p533 .. "_" .. p534,
				["Name"] = p533,
				["Skin"] = p534,
				["Float"] = p535,
				["StatTrack"] = p536,
				["NameTag"] = p537,
				["Charm"] = p538,
				["Stickers"] = p539,
				["Type"] = p540,
				["Pattern"] = p541,
				["Serial"] = p543,
				["IsTradeable"] = p544,
				["HideWearDetails"] = p545,
				["ShowFullPriceRange"] = p546
			}
			v_u_1.ShowInspect(v547)
		end
	end)
	v_u_27.observerRouter("WeaponInspectClose", function()
		-- upvalues: (ref) v_u_1
		v_u_1.HideInspect()
	end)
	v_u_27.observerRouter("WeaponInspectCloseForGameEnd", function()
		-- upvalues: (ref) v_u_1
		v_u_1.HideInspect(true)
	end)
	v_u_27.observerRouter("IsInspectActive", function()
		-- upvalues: (ref) v_u_55
		return v_u_55
	end)
	v_u_27.observerRouter("GetCurrentCharmPosition", function()
		-- upvalues: (ref) v_u_78
		return v_u_78
	end)
end
function v_u_1.Start() -- name: Start
	-- upvalues: (copy) v_u_144
	v_u_144()
end
return v_u_1
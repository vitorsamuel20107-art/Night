-- NIGHT Analyzer | ReplicatedStorage.Controllers.BuyStationController
-- ModuleScript | 1101 linhas | 31910 bytes | hash 6d7c29d7

local v1 = {}
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(v2.Controllers.RunServiceController)
local v_u_6 = require(v2.Classes.Sound)
local v_u_7 = require(v2.Packages.Observers)
local v_u_8 = require(v2.Shared.Janitor)
local v_u_9 = require(v2.Components.Common.SurvivalBuyRules)
local v_u_10 = require(v2.Database.Components.GameState)
local v_u_11 = Color3.fromRGB(80, 225, 240)
local v_u_12 = NumberSequence.new(1)
local v_u_13 = v_u_9.BUY_STATION_ARRIVE_SECONDS
local v_u_14 = v_u_9.BUY_STATION_DEPART_SECONDS
local v_u_15 = Color3.fromRGB(225, 250, 255)
local v_u_16 = Color3.new(1, 1, 1)
local v_u_17 = CFrame.Angles(0, 0, 1.5707963267948966)
local v_u_18 = table.freeze({ table.freeze({
		["Width"] = 1,
		["Transparency"] = 0.8
	}), table.freeze({
		["Width"] = 0.62,
		["Transparency"] = 0.7
	}), table.freeze({
		["Width"] = 0.24,
		["Transparency"] = 0.6
	}) })
local v_u_19 = table.freeze({
	["Opened"] = 0.12,
	["Strike"] = 0.3,
	["Grow"] = 0.25,
	["Solid"] = 0.95,
	["Retract"] = 1,
	["Retracted"] = 1.3,
	["SourceGone"] = 1.45,
	["Ring"] = 0.95,
	["RingEnd"] = 1.5,
	["PowerOn"] = 1.05,
	["PowerOnEnd"] = 1.45
})
local v_u_20 = table.freeze({
	["RingGone"] = 0.35,
	["GlitchEnd"] = 0.5,
	["Source"] = 0.1,
	["Opened"] = 0.25,
	["Strike"] = 0.45,
	["Hologram"] = 0.45,
	["Taken"] = 1,
	["Retracted"] = 1.2,
	["Fade"] = nil,
	["Fade"] = v_u_14
})
local v_u_21 = {}
local v_u_22 = {}
local v_u_23 = nil
local v_u_24 = nil
local v_u_25 = false
local v_u_26 = nil
local v_u_27 = {}
local v_u_28 = {}
local function v_u_38(p29, p30) -- name: makeRing
	-- upvalues: (copy) v_u_9, (copy) v_u_11
	local v31 = p30.Position.Y - p30.Size.Y / 2
	local v32 = v_u_9.BUY_STATION_RADIUS * 2 * 1.2
	local v33 = Instance.new("Part")
	v33.Name = "BuyStationRing"
	v33.Size = Vector3.new(v32, 0.05, v32)
	v33.CFrame = CFrame.new(p30.Position.X, v31 + 0.03, p30.Position.Z)
	v33.Transparency = 1
	v33.Anchored = true
	v33.CanCollide = false
	v33.CanQuery = false
	v33.CanTouch = false
	v33.CastShadow = false
	local v34 = Instance.new("SurfaceGui")
	v34.Face = Enum.NormalId.Top
	v34.LightInfluence = 0
	v34.Brightness = 1.3
	v34.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	v34.PixelsPerStud = 48
	v34.Enabled = false
	v34.Parent = v33
	local v35 = Instance.new("Frame")
	v35.AnchorPoint = Vector2.new(0.5, 0.5)
	v35.Position = UDim2.fromScale(0.5, 0.5)
	v35.BackgroundColor3 = v_u_11
	v35.BackgroundTransparency = 0.9
	v35.BorderSizePixel = 0
	local v36 = Instance.new("UICorner")
	v36.CornerRadius = UDim.new(0.5, 0)
	v36.Parent = v35
	local v37 = Instance.new("UIStroke")
	v37.Color = v_u_11
	v37.Thickness = 10
	v37.Parent = v35
	v35.Parent = v34
	v33.Parent = p29
	return {
		["Part"] = v33,
		["Gui"] = v34,
		["Circle"] = v35,
		["Stroke"] = v37
	}
end
local function v_u_48(p39, p40, p41) -- name: setRingReveal
	-- upvalues: (ref) v_u_25
	if p40 ~= p39.RingReveal or p41 ~= p39.RingGlow then
		p39.RingReveal = p40
		p39.RingGlow = p41
		local v42 = p39.Ring
		local v43 = math.clamp(p40, 0, 1)
		local v44 = p40 / 1.2
		local v45 = v44 * -20
		v42.Circle.Size = UDim2.new(v44, v45, v44, v45)
		v42.Circle.BackgroundTransparency = 1 - v43 * 0.09999999999999998
		v42.Stroke.Transparency = 1 - v43
		v42.Stroke.Thickness = (p41 * 1.5 + 1) * 10
		v42.Gui.Brightness = p41 * 3.7 + 1.3
		local v46 = v42.Gui
		local v47 = v_u_25 and not p39.Departed
		if v47 then
			v47 = p39.RingReveal > 0
		end
		v46.Enabled = v47
	end
end
local function v_u_58(p49) -- name: applyEntry
	-- upvalues: (copy) v_u_22, (ref) v_u_25, (copy) v_u_12
	local v50 = p49.Departed or v_u_22[p49.Model] ~= nil
	local v51 = p49.Ring.Gui
	local v52 = v_u_25 and not p49.Departed
	if v52 then
		v52 = p49.RingReveal > 0
	end
	v51.Enabled = v52
	for v53, v55 in p49.Beams do
		if v50 then
			local v55 = v_u_12
		end
		v53.Transparency = v55
	end
	if p49.Marker then
		local v56 = p49.Marker
		local v57 = v_u_25
		if v57 then
			v57 = not v50
		end
		v56.Enabled = v57
	end
end
local function v_u_61(p59, p60) -- name: track
	if p60:IsA("Beam") then
		if not p59.Beams[p60] then
			p59.Beams[p60] = p60.Transparency
			return
		end
	else
		if p60:IsA("SurfaceGui") and p60.Name == "AmmoScreen" then
			p60.Enabled = false
			return
		end
		if p60:IsA("BillboardGui") and p60.Name == "BillboardGui" then
			p59.Marker = p60
			return
		end
		if p60:IsA("TextLabel") and p60.Name == "Distance" then
			p59.MarkerDistance = p60
		end
	end
end
local function v_u_68() -- name: updateMarkers
	-- upvalues: (copy) v_u_4, (copy) v_u_21
	local v62 = v_u_4.CurrentCamera
	if v62 then
		local v63 = v62.CFrame.Position
		for _, v64 in v_u_21 do
			local v65 = v64.MarkerDistance
			if not (v65 and (v64.Marker and v64.Marker.Enabled)) then
				continue
			end
			local v66 = (v64.Anchor.Position - v63).Magnitude
			local v67 = math.round(v66)
			if v67 == v64.MarkerStuds then
				continue
			end
			v64.MarkerStuds = v67
			v65.Text = ("%*m"):format(v67)
		end
	end
end
local function v_u_73(p69, p70) -- name: recordDescendant
	-- upvalues: (copy) v_u_11
	if p70:IsA("BasePart") and p70.Transparency < 1 then
		local v71 = p69.Parts
		local v72 = {
			["Part"] = p70,
			["Offset"] = p69.Anchor:ToObjectSpace(p70.CFrame),
			["Size"] = p70.Size,
			["Material"] = p70.Material,
			["Color"] = p70.Color,
			["Neon"] = p70.Material == Enum.Material.Neon
		}
		table.insert(v71, v72)
		if p69.Hologram then
			p70.Material = Enum.Material.ForceField
			p70.Color = v_u_11
		end
		p70.LocalTransparencyModifier = p69.Transparency or 0
	elseif p70:IsA("Decal") then
		p69.Decals[p70] = p70.Transparency
		if p69.Hologram then
			p70.Transparency = 1
		end
	end
end
local function v_u_87(p74, p75, p76, p77) -- name: poseMachine
	-- upvalues: (copy) v_u_27, (copy) v_u_28, (copy) v_u_4
	local v78 = Vector3.new(p75, p76, p75)
	table.clear(v_u_27)
	table.clear(v_u_28)
	for v79, v80 in p74.Parts do
		local v81 = v80.Offset.Rotation
		local v82 = v80.Part
		local v83 = v80.Size
		local v84 = (v81.XVector * v78).Magnitude
		local v85 = (v81.YVector * v78).Magnitude
		local v86 = (v81.ZVector * v78).Magnitude
		v82.Size = v83 * Vector3.new(v84, v85, v86)
		v_u_27[v79] = v80.Part
		v_u_28[v79] = p74.Anchor * (v81 + v80.Offset.Position * v78 + p77)
	end
	v_u_4:BulkMoveTo(v_u_27, v_u_28, Enum.BulkMoveMode.FireCFrameChanged)
end
local function v_u_97(p88, p89) -- name: setHologram
	-- upvalues: (copy) v_u_11
	p88.Hologram = p89
	for _, v90 in p88.Parts do
		local v91 = v90.Part
		local v92
		if p89 then
			v92 = Enum.Material.ForceField
		else
			v92 = v90.Material
		end
		v91.Material = v92
		local v93 = v90.Part
		local v94
		if p89 then
			v94 = v_u_11
		else
			v94 = v90.Color
		end
		v93.Color = v94
	end
	for v95, v96 in p88.Decals do
		v95.Transparency = p89 and 1 or v96
	end
end
local function v_u_103(p98, p99, p100) -- name: flickerNeon
	p98.Transparency = nil
	for v101, v102 in p98.Parts do
		if not v102.Neon then
			continue
		end
		v102.Part.LocalTransparencyModifier = p100 > 0 and (math.noise(p99 * 22 + 0.5, v101 * 0.731) > 0.5 - p100 and 1 or 0) or 0
	end
end
local function v_u_107(p104, p105) -- name: makeEmitter
	-- upvalues: (copy) v_u_15, (copy) v_u_11
	local v106 = Instance.new("ParticleEmitter")
	v106.Name = p105
	v106.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	v106.Rate = 0
	v106.Shape = Enum.ParticleEmitterShape.Box
	v106.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
	v106.EmissionDirection = Enum.NormalId.Top
	v106.LightEmission = 1
	v106.LightInfluence = 0
	v106.Brightness = 3
	v106.Color = ColorSequence.new(v_u_15, v_u_11)
	v106.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
	v106.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.3), NumberSequenceKeypoint.new(1, 0.05) })
	v106.Parent = p104
	return v106
end
local function v_u_116(p108, p109) -- name: makeConeRing
	-- upvalues: (copy) v_u_15
	local v110 = Instance.new("Part")
	v110.Name = p109
	v110.Size = Vector3.new(1, 0.05, 1)
	v110.Transparency = 1
	v110.Anchored = true
	v110.CanCollide = false
	v110.CanQuery = false
	v110.CanTouch = false
	v110.CastShadow = false
	for _, v111 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v112 = Instance.new("SurfaceGui")
		v112.Face = v111
		v112.LightInfluence = 0
		v112.Brightness = 3
		v112.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
		v112.PixelsPerStud = 48
		v112.Parent = v110
		local v113 = Instance.new("Frame")
		v113.AnchorPoint = Vector2.new(0.5, 0.5)
		v113.Position = UDim2.fromScale(0.5, 0.5)
		v113.Size = UDim2.new(1, -16, 1, -16)
		v113.BackgroundTransparency = 1
		local v114 = Instance.new("UICorner")
		v114.CornerRadius = UDim.new(0.5, 0)
		v114.Parent = v113
		local v115 = Instance.new("UIStroke")
		v115.Color = v_u_15
		v115.Thickness = 8
		v115.Transparency = 1
		v115.Parent = v113
		v113.Parent = v112
	end
	v110.Parent = p108
end
local function v_u_138() -- name: buildEffectTemplate
	-- upvalues: (copy) v_u_15, (copy) v_u_18, (copy) v_u_11, (copy) v_u_116, (copy) v_u_107, (copy) v_u_16
	local v117 = Instance.new("Folder")
	v117.Name = "BuyStationBeam"
	local v118 = v_u_15
	local v119 = Instance.new("Part")
	v119.Name = "Source"
	v119.Shape = Enum.PartType.Cylinder
	v119.Material = Enum.Material.Neon
	v119.Color = v118
	v119.Transparency = 1
	v119.Size = Vector3.new(1, 1, 1)
	v119.Anchored = true
	v119.CanCollide = false
	v119.CanQuery = false
	v119.CanTouch = false
	v119.CastShadow = false
	v119.Parent = v117
	v119.Shape = Enum.PartType.Ball
	local v120 = Instance.new("Attachment")
	v120.Name = "Apex"
	v120.Parent = v119
	local v121 = Instance.new("Attachment")
	v121.Name = "ConeFoot"
	v121.Parent = v119
	for v122, v123 in v_u_18 do
		local v124 = Instance.new("Beam")
		v124.Name = ("Cone%*"):format(v122)
		v124.Attachment0 = v120
		v124.Attachment1 = v121
		v124.FaceCamera = true
		v124.Segments = 1
		v124.LightEmission = 1
		v124.LightInfluence = 0
		v124.Brightness = 2
		local v125 = ColorSequence.new
		local v126
		if v122 == #v_u_18 then
			v126 = v_u_15
		else
			v126 = v_u_11
		end
		v124.Color = v125(v126)
		v124.Transparency = NumberSequence.new(1)
		v124.Width0 = 0.5 * v123.Width
		v124.Width1 = 0.5 * v123.Width
		v124.Parent = v119
	end
	v_u_116(v117, (("ConeRing%*"):format(1)))
	v_u_116(v117, (("ConeRing%*"):format(2)))
	v_u_116(v117, (("ConeRing%*"):format(3)))
	local v127 = v_u_11
	local v128 = Instance.new("Part")
	v128.Name = "Pool"
	v128.Shape = Enum.PartType.Cylinder
	v128.Material = Enum.Material.Neon
	v128.Color = v127
	v128.Transparency = 1
	v128.Size = Vector3.new(1, 1, 1)
	v128.Anchored = true
	v128.CanCollide = false
	v128.CanQuery = false
	v128.CanTouch = false
	v128.CastShadow = false
	v128.Parent = v117
	local v129 = v_u_11
	local v130 = Instance.new("Part")
	v130.Name = "Shockwave"
	v130.Shape = Enum.PartType.Cylinder
	v130.Material = Enum.Material.Neon
	v130.Color = v129
	v130.Transparency = 1
	v130.Size = Vector3.new(1, 1, 1)
	v130.Anchored = true
	v130.CanCollide = false
	v130.CanQuery = false
	v130.CanTouch = false
	v130.CastShadow = false
	v130.Parent = v117
	local v131 = Instance.new("Part")
	v131.Name = "Base"
	v131.Size = Vector3.new(6.6, 0.2, 6.6)
	v131.Transparency = 1
	v131.Anchored = true
	v131.CanCollide = false
	v131.CanQuery = false
	v131.CanTouch = false
	v131.CastShadow = false
	v131.Parent = v117
	local v132 = Instance.new("Attachment")
	v132.Name = "LightAttachment"
	v132.Position = Vector3.new(0, 3, 0)
	v132.Parent = v131
	local v133 = Instance.new("PointLight")
	v133.Color = v_u_11
	v133.Range = 20
	v133.Brightness = 0
	v133.Shadows = false
	v133.Parent = v132
	local v134 = v_u_107(v119, "Fall")
	v134.EmissionDirection = Enum.NormalId.Bottom
	v134.SpreadAngle = Vector2.new(12.907408671265838, 12.907408671265838)
	v134.Speed = NumberRange.new(18, 26)
	v134.Lifetime = NumberRange.new(0.9230769230769231, 1.3333333333333333)
	local v135 = v_u_107(v131, "Rise")
	v135.Lifetime = NumberRange.new(0.8, 1.4)
	v135.Speed = NumberRange.new(10, 18)
	v135.SpreadAngle = Vector2.new(4, 4)
	local v136 = v_u_107(v131, "Sparks")
	v136.Lifetime = NumberRange.new(0.35, 0.9)
	v136.Speed = NumberRange.new(16, 34)
	v136.SpreadAngle = Vector2.new(80, 80)
	v136.Acceleration = Vector3.new(0, -35, 0)
	v136.Drag = 3
	v136.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.35), NumberSequenceKeypoint.new(1, 0.05) })
	local v137 = Instance.new("Highlight")
	v137.Name = "Flash"
	v137.DepthMode = Enum.HighlightDepthMode.Occluded
	v137.FillColor = v_u_16
	v137.OutlineColor = v_u_11
	v137.FillTransparency = 1
	v137.OutlineTransparency = 1
	v137.Parent = v117
	return v117
end
local function v_u_152(p139) -- name: makeEffect
	-- upvalues: (ref) v_u_26, (copy) v_u_138, (copy) v_u_18, (copy) v_u_4
	local v140 = v_u_26 or v_u_138()
	v_u_26 = v140
	local v141 = v140:Clone()
	local v142 = v141.Source
	v142.CFrame = p139.Anchor * CFrame.new(0, 24, 0)
	local v143 = {}
	for v144 in v_u_18 do
		local v145 = v142:FindFirstChild((("Cone%*"):format(v144)))
		table.insert(v143, v145)
	end
	local v146 = {}
	for v147 = 1, 3 do
		local v148 = v141:FindFirstChild((("ConeRing%*"):format(v147)))
		local v149 = {}
		for _, v150 in v148:GetDescendants() do
			if not v150:IsA("UIStroke") then
				continue
			end
			table.insert(v149, v150)
		end
		table.insert(v146, {
			["Part"] = v148,
			["Strokes"] = v149
		})
	end
	local v151 = v141.Base
	v151.CFrame = p139.Anchor * CFrame.new(0, 0.1, 0)
	v141.Flash.Adornee = p139.Model
	v141.Parent = v_u_4:FindFirstChild("Debris") or v_u_4
	return {
		["Folder"] = v141,
		["Source"] = v142,
		["Cone"] = v143,
		["ConeFoot"] = v142.ConeFoot,
		["ConeRings"] = v146,
		["Pool"] = v141.Pool,
		["Shockwave"] = v141.Shockwave,
		["Light"] = v151.LightAttachment.PointLight,
		["Fall"] = v142.Fall,
		["Rise"] = v151.Rise,
		["Sparks"] = v151.Sparks,
		["Flash"] = v141.Flash
	}
end
local function v_u_182(p153, p154, p155, p156, p157) -- name: shapeCone
	-- upvalues: (copy) v_u_18, (copy) v_u_17
	local v158 = p153.Effect
	local v159 = p153.Entry.Anchor
	local v160 = v158.ConeFoot
	local v161 = p155 * 24
	local v162 = -math.max(v161, 0.05)
	v160.Position = Vector3.new(0, v162, 0)
	local v163 = p155 * 10.5 + 0.5
	for v164, v165 in v_u_18 do
		local v166 = v158.Cone[v164]
		v166.Width0 = 0.5 * v165.Width
		v166.Width1 = v163 * v165.Width
		local v167 = 1 - (1 - v165.Transparency) * p156
		v166.Transparency = NumberSequence.new(v167, 1 - (1 - v167) * 0.55)
	end
	for v168, v169 in v158.ConeRings do
		local v170 = (p154 * 1.4 + v168 / 3) % 1
		if p157 then
			v170 = 1 - v170
		end
		local v171
		if v170 <= p155 then
			v171 = p156 > 0
		else
			v171 = false
		end
		local v172
		if v171 then
			local v173 = 3.141592653589793 * v170
			v172 = math.sin(v173) * p156
		else
			v172 = 0
		end
		local v174 = v170 * 11
		local v175 = math.max(v174, 0.3)
		v169.Part.Size = Vector3.new(v175, 0.05, v175)
		v169.Part.CFrame = v159 * CFrame.new(0, (1 - v170) * 24, 0)
		for _, v176 in v169.Strokes do
			v176.Transparency = 1 - v172 * 0.65
		end
	end
	local v177 = (p155 - 0.85) / 0.15
	local v178 = math.clamp(v177, 0, 1)
	local v179 = v158.Pool
	local v180 = p155 * 11
	local v181 = math.max(v180, 0.05)
	v179.Size = Vector3.new(0.08, v181, v181)
	v179.CFrame = v159 * CFrame.new(0, 0.04, 0) * v_u_17
	v158.Pool.Transparency = 1 - v178 * 0.18000000000000005 * p156
end
local function v_u_194(p183, p184, p185) -- name: stepShockwave
	-- upvalues: (copy) v_u_3, (copy) v_u_17
	local v186 = p185 + 0.5
	local v187 = (p184 - p185) / (v186 - p185)
	local v188 = math.clamp(v187, 0, 1)
	local v189 = p183.Effect.Shockwave
	if p184 < p185 or v188 >= 1 then
		v189.Transparency = 1
	else
		local v190 = v_u_3:GetValue(v188, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out)
		local v191 = p183.Entry.Anchor
		local v192 = v190 * 16 + 2
		local v193 = math.max(v192, 0.05)
		v189.Size = Vector3.new(0.08, v193, v193)
		v189.CFrame = v191 * CFrame.new(0, 0.04, 0) * v_u_17
		v189.Transparency = v188 * 0.5 + 0.5
	end
end
local function v_u_197(p195, p196) -- name: playSound
	-- upvalues: (copy) v_u_6
	v_u_6.new("Survival"):PlaySoundAtPosition({
		["Position"] = nil,
		["Class"] = "Survival",
		["Name"] = nil,
		["Position"] = (p195.Entry.Anchor * CFrame.new(0, 3, 0)).Position,
		["Name"] = p196
	})
end
local function v_u_256(p198, p199) -- name: stepArrive
	-- upvalues: (copy) v_u_197, (copy) v_u_19, (copy) v_u_3, (copy) v_u_182, (copy) v_u_194, (copy) v_u_97, (copy) v_u_87, (copy) v_u_103, (copy) v_u_48
	local v200 = p198.Entry
	local v201 = p198.Effect
	local v202
	if p199 < 0 or p198.Fired.Sound then
		v202 = false
	else
		p198.Fired.Sound = true
		v202 = true
	end
	if v202 then
		v_u_197(p198, "Buy Station Arrive")
	end
	local v203 = v_u_19.Opened
	local v204 = (p199 - 0) / (v203 - 0)
	local v205 = math.clamp(v204, 0, 1)
	local v206 = v_u_19.Retracted
	local v207 = v_u_19.SourceGone
	local v208 = (p199 - v206) / (v207 - v206)
	local v209 = math.clamp(v208, 0, 1)
	local v210
	if v209 > 0 then
		v210 = (1 - v_u_3:GetValue(v209, Enum.EasingStyle.Cubic, Enum.EasingDirection.In)) * 1.15
	else
		v210 = v_u_3:GetValue(v205, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
	end
	local v211 = p198.Effect.Source
	local v212 = v210 * 1.8
	v211.Size = Vector3.new(1, 1, 1) * math.max(v212, 0.05)
	v211.CFrame = p198.Entry.Anchor * CFrame.new(0, 24, 0)
	v211.Transparency = v210 > 0 and 0 or 1
	local v213 = v_u_19.Opened
	local v214 = v_u_19.Strike
	local v215 = (p199 - v213) / (v214 - v213)
	local v216 = math.clamp(v215, 0, 1)
	local v217 = v_u_19.Retract
	local v218 = v_u_19.Retracted
	local v219 = (p199 - v217) / (v218 - v217)
	local v220 = math.clamp(v219, 0, 1)
	local v221
	if p199 < v_u_19.Retract then
		v221 = v_u_3:GetValue(v216, Enum.EasingStyle.Cubic, Enum.EasingDirection.In)
	else
		v221 = 1 - v_u_3:GetValue(v220, Enum.EasingStyle.Cubic, Enum.EasingDirection.In)
	end
	v_u_182(p198, p199, v221, 1, false)
	v_u_194(p198, p199, v_u_19.Strike)
	local v222 = v_u_19.Strike
	local v223 = v_u_19.Strike + 0.25
	local v224 = (p199 - v222) / (v223 - v222)
	local v225 = math.clamp(v224, 0, 1) * -3.5 + 6
	local v226 = v201.Light
	local v227
	if p199 < v_u_19.Strike then
		v227 = 2.5 * v221
	else
		v227 = v225 * v221
	end
	v226.Brightness = v227
	v201.Fall.Rate = v_u_19.Opened <= p199 and p199 < v_u_19.Solid and 60 or 0
	local v228
	if p199 < v_u_19.Strike or p198.Fired.Impact then
		v228 = false
	else
		p198.Fired.Impact = true
		v228 = true
	end
	if v228 then
		v201.Sparks:Emit(55)
	end
	if p199 < v_u_19.Grow then
		if v200.Transparency ~= 1 then
			v200.Transparency = 1
			for _, v229 in v200.Parts do
				v229.Part.LocalTransparencyModifier = 1
			end
		end
	elseif p199 < v_u_19.Solid then
		local v230
		if p199 < v_u_19.Grow or p198.Fired.Hologram then
			v230 = false
		else
			p198.Fired.Hologram = true
			v230 = true
		end
		if v230 then
			v_u_97(v200, true)
		end
		local v231 = v_u_19.Grow
		local v232 = v_u_19.Solid
		local v233 = (p199 - v231) / (v232 - v231)
		local v234 = math.clamp(v233, 0, 1)
		local v235 = v_u_3:GetValue(v234, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
		local v236 = v_u_3:GetValue(v234, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out)
		local v237 = v_u_87
		local v238 = v235 * 0.95 + 0.05
		local v239 = v235 * -0.6000000000000001 + 1.6
		local v240 = 8 * (1 - v236)
		v237(v200, v238, v239, (Vector3.new(0, v240, 0)))
		local v241 = p199 ~= nil
		if v241 or v200.Transparency ~= 0 then
			v200.Transparency = not v241 and 0 or nil
			for v242, v243 in v200.Parts do
				local v244
				if p199 == nil then
					v244 = false
				else
					v244 = math.noise(p199 * 22 + 0.5, v242 * 0.731) > 0.35
				end
				v243.Part.LocalTransparencyModifier = v244 and 0.55 or 0
			end
		end
	else
		local v245
		if p199 < v_u_19.Solid or p198.Fired.Solid then
			v245 = false
		else
			p198.Fired.Solid = true
			v245 = true
		end
		if v245 then
			v_u_97(v200, false)
			v_u_87(v200, 1, 1, Vector3.new(0, 0, 0))
			if v200.Transparency ~= 0 then
				v200.Transparency = 0
				for _, v246 in v200.Parts do
					v246.Part.LocalTransparencyModifier = 0
				end
			end
			v201.Sparks:Emit(20)
		end
		local v247 = v_u_19.Solid
		local v248 = v_u_19.Solid + 0.4
		local v249 = (p199 - v247) / (v248 - v247)
		local v250 = math.clamp(v249, 0, 1)
		v201.Flash.FillTransparency = v250 * 0.9 + 0.1
		v201.Flash.OutlineTransparency = v250 * 1 + 0
		v_u_103(v200, p199, v_u_19.PowerOn <= p199 and p199 < v_u_19.PowerOnEnd and 0.45 or 0)
	end
	local v251 = v_u_19.Ring
	local v252 = v_u_19.RingEnd
	local v253 = (p199 - v251) / (v252 - v251)
	local v254 = math.clamp(v253, 0, 1)
	local v255 = v_u_3:GetValue(v254, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
	v_u_48(v200, v254 <= 0 and 0 or v255, 1 - v254)
end
local function v_u_326(p257, p258) -- name: stepDepart
	-- upvalues: (copy) v_u_197, (copy) v_u_20, (copy) v_u_48, (copy) v_u_3, (copy) v_u_87, (copy) v_u_103, (copy) v_u_97, (copy) v_u_182, (copy) v_u_194
	local v259 = p257.Entry
	local v260 = p257.Effect
	local v261 = v259.Model.Parent ~= nil
	local v262
	if p258 < 0 or p257.Fired.Glitch then
		v262 = false
	else
		p257.Fired.Glitch = true
		v262 = true
	end
	if v262 then
		v_u_197(p257, "Buy Station Glitch")
		v260.Sparks:Emit(10)
	end
	local v263
	if p258 < v_u_20.GlitchEnd * 0.5 or p257.Fired.Crackle then
		v263 = false
	else
		p257.Fired.Crackle = true
		v263 = true
	end
	if v263 then
		v260.Sparks:Emit(10)
	end
	if v261 then
		local v264 = v_u_20.RingGone
		local v265 = (p258 - 0) / (v264 - 0)
		local v266 = math.clamp(v265, 0, 1)
		v_u_48(v259, 1 - v_u_3:GetValue(v266, Enum.EasingStyle.Cubic, Enum.EasingDirection.In), v266)
	end
	if v261 and p258 < v_u_20.Taken then
		if p258 < v_u_20.Hologram then
			local v267 = v_u_20.GlitchEnd * 0.5
			local v268 = (p258 - 0) / (v267 - 0)
			local v269 = math.clamp(v268, 0, 1) * 0.1
			local v270 = v_u_87
			local v271 = math.noise(p258 * 30, 1.7)
			local v272 = math.noise
			local v273 = p258 * 30
			v270(v259, 1, 1, Vector3.new(v271, 0, v272(v273, 4.2)) * v269 * 2)
			v_u_103(v259, p258, 0.35)
		else
			local v274
			if p258 < v_u_20.Hologram or p257.Fired.Hologram then
				v274 = false
			else
				p257.Fired.Hologram = true
				v274 = true
			end
			if v274 then
				v_u_97(v259, true)
			end
			local v275 = v_u_20.Hologram
			local v276 = v_u_20.Taken
			local v277 = (p258 - v275) / (v276 - v275)
			local v278 = v_u_3:GetValue(math.clamp(v277, 0, 1), Enum.EasingStyle.Cubic, Enum.EasingDirection.In)
			local v279 = v_u_87
			local v280 = v278 * -0.95 + 1
			local v281 = v278 * 0.6000000000000001 + 1
			local v282 = 16 * v278
			v279(v259, v280, v281, (Vector3.new(0, v282, 0)))
			local v283 = p258 ~= nil
			if v283 or v259.Transparency ~= 0 then
				v259.Transparency = not v283 and 0 or nil
				for v284, v285 in v259.Parts do
					local v286
					if p258 == nil then
						v286 = false
					else
						v286 = math.noise(p258 * 22 + 0.5, v284 * 0.731) > 0.35
					end
					v285.Part.LocalTransparencyModifier = v286 and 0.55 or 0
				end
			end
		end
		local v287 = v_u_20.Hologram
		local v288 = v_u_20.Hologram + 0.25
		local v289 = (p258 - v287) / (v288 - v287)
		local v290 = math.clamp(v289, 0, 1)
		v260.Flash.FillTransparency = p258 < v_u_20.Hologram and 1 or v290 * 0.8 + 0.2
		v260.Flash.OutlineTransparency = p258 < v_u_20.Hologram and 1 or v290 * 1 + 0
	else
		local v291
		if p258 < v_u_20.Taken or p257.Fired.Taken then
			v291 = false
		else
			p257.Fired.Taken = true
			v291 = true
		end
		if v291 then
			if v261 and v259.Transparency ~= 1 then
				v259.Transparency = 1
				for _, v292 in v259.Parts do
					v292.Part.LocalTransparencyModifier = 1
				end
			end
			v260.Flash.FillTransparency = 1
			v260.Flash.OutlineTransparency = 1
			v_u_197(p257, "Buy Station Depart")
		end
	end
	local v293 = p258 - v_u_20.Retracted
	local v294 = math.max(v293, 0) * 260
	local v295 = v_u_20.Source
	local v296 = v_u_20.Opened
	local v297 = (p258 - v295) / (v296 - v295)
	local v298 = math.clamp(v297, 0, 1)
	local v299
	if p258 < v_u_20.Taken then
		v299 = v_u_3:GetValue(v298, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
	else
		local v300 = v_u_20.Taken
		local v301 = v_u_20.Fade
		local v302 = (p258 - v300) / (v301 - v300)
		v299 = math.clamp(v302, 0, 1) * -1.1 + 1.5
	end
	local v303 = p258 < v_u_20.Source and 0 or v299
	local v304 = p257.Effect.Source
	local v305 = v303 * 1.8
	v304.Size = Vector3.new(1, 1, 1) * math.max(v305, 0.05)
	v304.CFrame = p257.Entry.Anchor * CFrame.new(0, v294 + 24, 0)
	v304.Transparency = v303 > 0 and 0 or 1
	local v306 = v260.Source
	local v307
	if p258 < v_u_20.Source then
		v307 = 1
	else
		local v308 = v_u_20.Retracted
		local v309 = v_u_20.Fade
		local v310 = (p258 - v308) / (v309 - v308)
		v307 = math.clamp(v310, 0, 1)
	end
	v306.Transparency = v307
	local v311 = v_u_20.Opened
	local v312 = v_u_20.Strike
	local v313 = (p258 - v311) / (v312 - v311)
	local v314 = math.clamp(v313, 0, 1)
	local v315 = v_u_20.Taken
	local v316 = v_u_20.Retracted
	local v317 = (p258 - v315) / (v316 - v315)
	local v318 = math.clamp(v317, 0, 1)
	local v319
	if p258 < v_u_20.Taken then
		v319 = v_u_3:GetValue(v314, Enum.EasingStyle.Cubic, Enum.EasingDirection.In)
	else
		v319 = 1 - v_u_3:GetValue(v318, Enum.EasingStyle.Cubic, Enum.EasingDirection.In)
	end
	v_u_182(p257, p258, v319, 1, true)
	v_u_194(p257, p258, v_u_20.Strike)
	local v320
	if p258 < v_u_20.Strike or p257.Fired.Impact then
		v320 = false
	else
		p257.Fired.Impact = true
		v320 = true
	end
	if v320 then
		v260.Sparks:Emit(45)
	end
	local v321 = v260.Light
	local v322
	if p258 < v_u_20.Taken then
		v322 = 2.5 * v319
	else
		local v323 = v_u_20.Taken
		local v324 = v_u_20.Retracted
		local v325 = (p258 - v323) / (v324 - v323)
		v322 = (math.clamp(v325, 0, 1) * -6 + 6) * v319
	end
	v321.Brightness = v322
	v260.Rise.Rate = v_u_20.Strike <= p258 and p258 < v_u_20.Taken and 60 or 0
end
local function v_u_329(p327) -- name: stopAnimation
	-- upvalues: (copy) v_u_22, (ref) v_u_23, (copy) v_u_21, (copy) v_u_58
	local v328 = v_u_22[p327]
	if v328 then
		v_u_22[p327] = nil
		v328.Effect.Folder:Destroy()
		if next(v_u_22) == nil and v_u_23 then
			v_u_23:Disconnect()
			v_u_23 = nil
		end
		if v_u_21[p327] then
			v_u_58(v328.Entry)
		end
	end
end
local function v_u_334(p330) -- name: finishAnimation
	-- upvalues: (copy) v_u_97, (copy) v_u_87, (copy) v_u_48, (copy) v_u_329
	local v331 = p330.Entry
	if p330.Kind == "arrive" then
		v_u_97(v331, false)
		v_u_87(v331, 1, 1, Vector3.new(0, 0, 0))
		if v331.Transparency ~= 0 then
			v331.Transparency = 0
			for _, v332 in v331.Parts do
				v332.Part.LocalTransparencyModifier = 0
			end
		end
		v_u_48(v331, 1, 0)
	else
		v331.Departed = true
		if v331.Model.Parent and v331.Transparency ~= 1 then
			v331.Transparency = 1
			for _, v333 in v331.Parts do
				v333.Part.LocalTransparencyModifier = 1
			end
		end
	end
	v_u_329(v331.Model)
end
local function v_u_339() -- name: animate
	-- upvalues: (copy) v_u_4, (copy) v_u_22, (copy) v_u_13, (copy) v_u_14, (copy) v_u_334, (copy) v_u_256, (copy) v_u_326
	local v335 = v_u_4:GetServerTimeNow()
	for _, v336 in v_u_22 do
		local v337 = v335 - v336.StartedAt
		local v338
		if v336.Kind == "arrive" then
			v338 = v_u_13
		else
			v338 = v_u_14
		end
		if v338 <= v337 then
			v_u_334(v336)
		elseif v336.Kind == "arrive" then
			v_u_256(v336, (math.max(v337, 0)))
		else
			v_u_326(v336, (math.max(v337, 0)))
		end
	end
end
local function v_u_348(p340, p341, p342) -- name: startAnimation
	-- upvalues: (copy) v_u_22, (copy) v_u_334, (copy) v_u_13, (copy) v_u_14, (copy) v_u_4, (copy) v_u_58, (copy) v_u_152, (copy) v_u_48, (ref) v_u_23, (copy) v_u_5, (copy) v_u_339
	local v343 = p340.Model
	local v344 = v_u_22[v343]
	if v344 then
		if v344.Kind == p341 then
			return
		end
		v_u_334(v344)
	end
	local v345
	if p341 == "arrive" then
		v345 = v_u_13
	else
		v345 = v_u_14
	end
	if v345 <= v_u_4:GetServerTimeNow() - p342 then
		if p341 == "depart" then
			p340.Departed = true
			if p340.Transparency ~= 1 then
				p340.Transparency = 1
				for _, v346 in p340.Parts do
					v346.Part.LocalTransparencyModifier = 1
				end
			end
			v_u_58(p340)
		end
	else
		v_u_22[v343] = {
			["Kind"] = p341,
			["Entry"] = p340,
			["StartedAt"] = p342,
			["Effect"] = v_u_152(p340),
			["Fired"] = {}
		}
		if p341 == "arrive" then
			if p340.Transparency ~= 1 then
				p340.Transparency = 1
				for _, v347 in p340.Parts do
					v347.Part.LocalTransparencyModifier = 1
				end
			end
			v_u_48(p340, 0, 0)
		end
		if not v_u_23 then
			v_u_23 = v_u_5.BindToRenderSteppedEvent("BuyStationController.Animate", v_u_339)
		end
		v_u_58(p340)
	end
end
local function v_u_352(p349) -- name: readStamps
	-- upvalues: (copy) v_u_9, (copy) v_u_348
	local v350 = p349.Model:GetAttribute(v_u_9.BUY_STATION_DEPARTED_ATTRIBUTE)
	if typeof(v350) == "number" then
		v_u_348(p349, "depart", v350)
	else
		local v351 = p349.Model:GetAttribute(v_u_9.BUY_STATION_ARRIVED_ATTRIBUTE)
		if typeof(v351) == "number" then
			v_u_348(p349, "arrive", v351)
		end
	end
end
local function v_u_361(p_u_353, p354) -- name: watch
	-- upvalues: (copy) v_u_38, (copy) v_u_48, (copy) v_u_73, (copy) v_u_61, (copy) v_u_58, (copy) v_u_21, (ref) v_u_24, (copy) v_u_5, (copy) v_u_68, (copy) v_u_22, (copy) v_u_329, (copy) v_u_9, (copy) v_u_352
	local v355 = p_u_353.PrimaryPart or p_u_353:WaitForChild("Hitbox", 30)
	if v355 and (v355:IsA("BasePart") and p_u_353.Parent) then
		local v_u_356 = {
			["Model"] = nil,
			["Ring"] = nil,
			["Beams"] = nil,
			["Anchor"] = nil,
			["Parts"] = nil,
			["Decals"] = nil,
			["Departed"] = false,
			["RingReveal"] = 1,
			["Hologram"] = false,
			["Transparency"] = 0,
			["Model"] = p_u_353,
			["Ring"] = v_u_38(p_u_353, v355),
			["Beams"] = {},
			["Anchor"] = v355.CFrame * CFrame.new(0, -v355.Size.Y / 2, 0),
			["Parts"] = {},
			["Decals"] = {}
		}
		v_u_48(v_u_356, 1, 0)
		for _, v357 in p_u_353:GetDescendants() do
			v_u_73(v_u_356, v357)
		end
		p354:Add(v_u_356.Ring.Part)
		p354:Add(p_u_353.DescendantAdded:Connect(function(p358)
			-- upvalues: (ref) v_u_73, (copy) v_u_356, (ref) v_u_61, (ref) v_u_58
			v_u_73(v_u_356, p358)
			v_u_61(v_u_356, p358)
			v_u_58(v_u_356)
		end))
		for _, v359 in p_u_353:GetDescendants() do
			v_u_61(v_u_356, v359)
		end
		v_u_21[p_u_353] = v_u_356
		if not v_u_24 then
			v_u_24 = v_u_5.BindToRenderSteppedEvent("BuyStationController.Marker", v_u_68)
		end
		p354:Add(function()
			-- upvalues: (ref) v_u_21, (copy) p_u_353, (ref) v_u_24, (ref) v_u_22, (ref) v_u_329
			v_u_21[p_u_353] = nil
			if next(v_u_21) == nil and v_u_24 then
				v_u_24:Disconnect()
				v_u_24 = nil
			end
			local v360 = v_u_22[p_u_353]
			if v360 and v360.Kind ~= "depart" then
				v_u_329(p_u_353)
			end
		end, true)
		p354:Add(p_u_353:GetAttributeChangedSignal(v_u_9.BUY_STATION_DEPARTED_ATTRIBUTE):Connect(function()
			-- upvalues: (ref) v_u_352, (copy) v_u_356
			v_u_352(v_u_356)
		end))
		v_u_58(v_u_356)
		v_u_352(v_u_356)
	end
end
local function v_u_364(p362) -- name: observeStation
	-- upvalues: (copy) v_u_8, (copy) v_u_361
	if not p362:IsA("Model") then
		return nil
	end
	local v_u_363 = v_u_8.new()
	v_u_363:Add(task.spawn(v_u_361, p362, v_u_363), true)
	return function()
		-- upvalues: (copy) v_u_363
		v_u_363:Destroy()
	end
end
function v1.Start() -- name: Start
	-- upvalues: (copy) v_u_7, (copy) v_u_9, (copy) v_u_364, (copy) v_u_4, (copy) v_u_10, (ref) v_u_25, (copy) v_u_21, (copy) v_u_58
	local v365 = { v_u_4 }
	v_u_7.observeTag(v_u_9.BUY_STATION_TAG, v_u_364, v365)
	v_u_10.ListenToState(function(_, p366)
		-- upvalues: (ref) v_u_25, (ref) v_u_21, (ref) v_u_58
		local v367 = p366 == "Round In Progress"
		if v367 ~= v_u_25 then
			v_u_25 = v367
			for _, v368 in v_u_21 do
				v_u_58(v368)
			end
		end
	end)
end
return v1
-- NIGHT Analyzer | ReplicatedStorage.Controllers.HordeController.HealthBars
-- ModuleScript | 176 linhas | 4473 bytes | hash 23bff9c8

local v_u_1 = {}
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = TweenInfo.new(0.3, Enum.EasingStyle.Linear)
local v_u_6 = TweenInfo.new(0.25)
local v_u_7 = {}
local v_u_8 = {}
local function v_u_12(p9) -- name: collectFadeTargets
	local v10 = {}
	for _, v11 in p9:GetDescendants() do
		if v11:IsA("GuiObject") then
			v10[#v10 + 1] = {
				["Instance"] = nil,
				["Property"] = "BackgroundTransparency",
				["Base"] = nil,
				["Instance"] = v11,
				["Base"] = v11.BackgroundTransparency
			}
			if v11:IsA("TextLabel") then
				v10[#v10 + 1] = {
					["Instance"] = nil,
					["Property"] = "TextTransparency",
					["Base"] = nil,
					["Instance"] = v11,
					["Base"] = v11.TextTransparency
				}
			else
				if not v11:IsA("ImageLabel") then
					continue
				end
				v10[#v10 + 1] = {
					["Instance"] = nil,
					["Property"] = "ImageTransparency",
					["Base"] = nil,
					["Instance"] = v11,
					["Base"] = v11.ImageTransparency
				}
			end
		else
			if not v11:IsA("UIStroke") then
				continue
			end
			v10[#v10 + 1] = {
				["Instance"] = nil,
				["Property"] = "Transparency",
				["Base"] = nil,
				["Instance"] = v11,
				["Base"] = v11.Transparency
			}
		end
	end
	return v10
end
local function v_u_15(p13) -- name: makeBar
	-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_12
	local v14 = v_u_3.Assets.UI.Survival.ZombieHealth:Clone()
	v14.ResetOnSpawn = false
	v14.Enabled = false
	v14.Adornee = p13
	v14.Parent = v_u_2.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	return {
		["Gui"] = nil,
		["Head"] = nil,
		["Fill"] = nil,
		["Fraction"] = -1,
		["Fade"] = nil,
		["Fading"] = nil,
		["Generation"] = 0,
		["Gui"] = v14,
		["Head"] = p13,
		["Fill"] = v14.Track.Bar,
		["Fade"] = v_u_12(v14),
		["Fading"] = {}
	}
end
local function v_u_21(p16, p17) -- name: takeBar
	-- upvalues: (copy) v_u_8, (copy) v_u_15
	local v18 = table.remove(v_u_8) or v_u_15(p16)
	if v18.Head ~= p16 then
		v18.Head = p16
		v18.Gui.Adornee = p16
	end
	local v19 = v18.Gui
	local v20 = p16.Size.Y / 2 + 0.8
	v19.StudsOffsetWorldSpace = Vector3.new(0, v20, 0)
	v18.Fraction = p17
	v18.Fill.Size = UDim2.fromScale(p17, 1)
	v18.Gui.Enabled = true
	return v18
end
local function v_u_25(p22) -- name: stopFade
	if #p22.Fading ~= 0 then
		for _, v23 in p22.Fading do
			v23:Cancel()
		end
		table.clear(p22.Fading)
		for _, v24 in p22.Fade do
			v24.Instance[v24.Property] = v24.Base
		end
	end
end
local function v_u_31(p_u_26, p_u_27) -- name: hide
	-- upvalues: (copy) v_u_7, (copy) v_u_4, (copy) v_u_6, (copy) v_u_1
	local v_u_28 = v_u_7[p_u_26]
	if v_u_28 and v_u_28.Generation == p_u_27 then
		for _, v29 in v_u_28.Fade do
			local v30 = v_u_4:Create(v29.Instance, v_u_6, {
				[v29.Property] = 1
			})
			v30:Play()
			v_u_28.Fading[#v_u_28.Fading + 1] = v30
		end
		task.delay(0.25, function()
			-- upvalues: (ref) v_u_7, (copy) p_u_26, (copy) v_u_28, (copy) p_u_27, (ref) v_u_1
			if v_u_7[p_u_26] == v_u_28 and v_u_28.Generation == p_u_27 then
				v_u_1.Remove(p_u_26)
			end
		end)
	end
end
function v_u_1.Show(p32, p33, p34) -- name: Show
	-- upvalues: (copy) v_u_7, (copy) v_u_1, (copy) v_u_21, (copy) v_u_25, (copy) v_u_31
	local v35 = v_u_7[p32]
	if v35 and v35.Head.Parent ~= p33 then
		v_u_1.Remove(p32)
		v35 = nil
	end
	if not v35 then
		local v36 = p33:FindFirstChild("Head")
		if not (v36 and v36:IsA("BasePart")) then
			return
		end
		v35 = v_u_21(v36, p34)
		v_u_7[p32] = v35
	end
	v_u_25(v35)
	v35.Generation = v35.Generation + 1
	task.delay(3, v_u_31, p32, v35.Generation)
end
function v_u_1.SetHealth(p37, p38) -- name: SetHealth
	-- upvalues: (copy) v_u_7, (copy) v_u_4, (copy) v_u_5
	local v39 = v_u_7[p37]
	if v39 and v39.Fraction ~= p38 then
		v39.Fraction = p38
		v_u_4:Create(v39.Fill, v_u_5, {
			["Size"] = UDim2.fromScale(p38, 1)
		}):Play()
	end
end
function v_u_1.Remove(p40) -- name: Remove
	-- upvalues: (copy) v_u_7, (copy) v_u_25, (copy) v_u_8
	local v41 = v_u_7[p40]
	if v41 then
		v_u_7[p40] = nil
		v41.Generation = v41.Generation + 1
		v_u_25(v41)
		if #v_u_8 < 24 and v41.Gui.Parent then
			v41.Gui.Enabled = false
			v_u_8[#v_u_8 + 1] = v41
			return
		end
		v41.Gui:Destroy()
	end
end
function v_u_1.Clear() -- name: Clear
	-- upvalues: (copy) v_u_7, (copy) v_u_1, (copy) v_u_8
	for v42 in v_u_7 do
		v_u_1.Remove(v42)
	end
	for _, v43 in v_u_8 do
		v43.Gui:Destroy()
	end
	table.clear(v_u_8)
end
return v_u_1
-- NIGHT Analyzer | ReplicatedStorage.Controllers.HordeController.RigShell
-- ModuleScript | 1248 linhas | 33220 bytes | hash 27e291f3

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Workspace")
local v_u_3 = require(v_u_1.Classes.Character.Classes.CharacterAnimator)
local v_u_4 = require(v_u_1.Components.Common.ClientCharacterPresentation)
local v_u_5 = require(v_u_1.Components.Common.CharacterResolver)
local v_u_6 = require(v_u_1.Controllers.CharacterController.HitFlinch)
local v_u_7 = require(v_u_1.Components.Common.HordeProtocol)
local v_u_8 = require(v_u_1.Classes.Ragdoll.Rig)
local v_u_9 = require(v_u_1.Classes.Sound)
local v_u_10 = require(v_u_1.Components.Common.VFXLibary.CreateImpact.Components.Materials)
local v_u_11 = require(v_u_1.Components.Common.GetRayIgnore)
local v_u_12 = require(v_u_1.Components.Common.VFXLibary.CreateImpact)
local v_u_13 = require(v_u_1.Database.Components.Libraries.Skins)
local v_u_14 = require(v_u_1.Database.Components.Common.AttachGlovesToCharacter)
local v_u_15 = require(v_u_1.Components.Common.VFXLibary.CreateGrenadeBurst)
local v_u_16 = {}
local v_u_17 = v_u_7.ZOMBIE_CHARACTER_FOLDER
local v_u_18 = v_u_7.ARCHETYPE_FOLDERS
local v_u_19 = v_u_18[v_u_7.ARCHETYPE_NORMAL]
local v_u_20 = v_u_7.STATE_ATTACK
local v_u_21 = v_u_7.STATE_STUNNED
local v_u_22 = CFrame.new(0, 3, 0)
local v_u_23 = table.freeze({
	["LeftWrist"] = true,
	["RightWrist"] = true,
	["LeftAnkle"] = true,
	["RightAnkle"] = true
})
local v_u_24 = { v_u_7.SHELL_FOLDER, v_u_7.HITBOX_FOLDER }
local v_u_25 = {
	["Idle"] = {
		["Sound"] = "Zombie Idle",
		["Priority"] = 1,
		["PitchVariation"] = 0.08
	},
	["Pain"] = {
		["Sound"] = "Zombie Pain",
		["Priority"] = 3,
		["PitchVariation"] = 0.06
	},
	["Attack"] = {
		["Sound"] = "Zombie Attack",
		["Priority"] = 2,
		["PitchVariation"] = 0.03
	}
}
local v_u_26 = {
	[v_u_7.ARCHETYPE_NORMAL] = NumberRange.new(0.88, 1.14),
	[v_u_7.ARCHETYPE_HEAVY] = NumberRange.new(0.7, 0.86),
	[v_u_7.ARCHETYPE_FLAMING] = NumberRange.new(1, 1.22),
	[v_u_7.ARCHETYPE_FLAMING_HEAVY] = NumberRange.new(0.7, 0.86)
}
local v_u_27 = NumberRange.new(5, 12)
local v_u_28 = NumberRange.new(1, 6)
local v_u_29 = NumberRange.new(0.3, 1.2)
local v_u_30 = NumberRange.new(0.85, 1.2)
local v_u_31 = {
	"Head",
	"UpperTorso",
	"LowerTorso",
	"LeftUpperArm",
	"RightUpperArm",
	"LeftLowerArm",
	"RightLowerArm",
	"LeftHand",
	"RightHand",
	"LeftUpperLeg",
	"RightUpperLeg",
	"LeftLowerLeg",
	"RightLowerLeg",
	"LeftFoot",
	"RightFoot"
}
local v_u_32 = { "T Glove", "CT Glove" }
local v_u_33 = { "Driver Gloves", "Operator Gloves", "Sports Gloves" }
local v_u_34 = Color3.fromRGB(255, 140, 60)
local v_u_35 = Random.new()
local v_u_36 = Random.new()
local v_u_37 = {}
local v_u_38 = Random.new()
local v_u_39 = 0
local v_u_40 = 2
local v_u_41 = {}
local v_u_42 = {}
local v_u_43 = nil
local v_u_44 = nil
local v_u_45 = nil
local v_u_46 = RaycastParams.new()
v_u_46.FilterType = Enum.RaycastFilterType.Exclude
v_u_46.IgnoreWater = true
local v_u_47 = {}
local v_u_48 = false
local v_u_49 = false
local v_u_50 = {}
local v_u_51 = false
v_u_13.ObserveItemStockSchemas(function(p52)
	-- upvalues: (ref) v_u_51
	if next(p52) ~= nil then
		v_u_51 = true
	end
end)
local v_u_53 = {}
local function v_u_60(p54, p55) -- name: getVariants
	-- upvalues: (copy) v_u_41, (copy) v_u_17
	local v56 = v_u_41[p55]
	if v56 then
		return v56
	end
	local v57 = {}
	local v58 = p54:FindFirstChild(v_u_17)
	if v58 then
		v58 = v58:FindFirstChild(p55)
	end
	if v58 then
		for _, v59 in v58:GetChildren() do
			if not v59:IsA("Model") then
				continue
			end
			v57[#v57 + 1] = v59
		end
	end
	v_u_41[p55] = v57
	return v57
end
local function v_u_66(p61) -- name: getArchetypeVariants
	-- upvalues: (copy) v_u_1, (copy) v_u_18, (copy) v_u_19, (copy) v_u_2, (copy) v_u_60
	local v62 = v_u_1:FindFirstChild("Assets")
	if v62 then
		v62 = v62:FindFirstChild("Characters")
	end
	if not v62 then
		return {}
	end
	local v63 = v_u_18[p61] or v_u_19
	for _, v64 in v_u_2:GetAttribute("HordeRigStyle") ~= "R15" and { "R6", "" } or { "" } do
		local v65 = v_u_60(v62, v63 .. v64)
		if #v65 == 0 and v63 ~= v_u_19 then
			v65 = v_u_60(v62, v_u_19 .. v64)
		end
		if #v65 <= 0 then
			continue
		end
		return v65
	end
	return {}
end
local function v_u_69(p67, p68) -- name: byName
	return p67.Name < p68.Name
end
local function v_u_77(p70) -- name: getZombieAnimations
	-- upvalues: (copy) v_u_42, (copy) v_u_1, (copy) v_u_69
	local v71 = v_u_42[p70]
	if v71 then
		return v71
	end
	local v72 = {
		["Idle"] = nil,
		["Jump"] = nil,
		["Walks"] = nil,
		["Attacks"] = nil,
		["Trip"] = nil,
		["Walks"] = {},
		["Attacks"] = {}
	}
	local v73 = v_u_1:FindFirstChild("Assets")
	if v73 then
		v73 = v73:FindFirstChild("CharacterAnimations")
	end
	if v73 then
		v73 = v73:FindFirstChild("Zombie")
	end
	if v73 and p70 then
		v73 = v73:FindFirstChild("R6")
	end
	if v73 then
		for _, v74 in v73:GetChildren() do
			if not v74:IsA("Animation") then
				continue
			end
			local v75 = v74.Name
			if v75 == "Idle" then
				v72.Idle = v74
			elseif v75 == "Jump" then
				v72.Jump = v74
			elseif v75 == "Trip" then
				v72.Trip = v74
			elseif v75 == "ZombieWalk" or string.sub(v75, 1, 5) == "Chase" then
				v72.Walks[#v72.Walks + 1] = v74
			else
				if string.sub(v75, 1, 6) ~= "Attack" then
					continue
				end
				v72.Attacks[#v72.Attacks + 1] = v74
			end
		end
		table.sort(v72.Walks, v_u_69)
		table.sort(v72.Attacks, v_u_69)
	end
	local v76 = "ReplicatedStorage.Assets.CharacterAnimations.Zombie"
	if p70 then
		v76 = v76 .. ".R6"
	end
	if #v72.Walks == 0 then
		warn((("[Horde] %* has no ZombieWalk or Chase* clip; zombies walk like humans"):format(v76)))
	end
	if #v72.Attacks == 0 then
		warn((("[Horde] %* has no Attack* clips; zombies bite without an animation"):format(v76)))
	end
	v_u_42[p70] = v72
	return v72
end
local function v_u_80(p78) -- name: configureParts
	for _, v79 in p78:GetDescendants() do
		if not v79:IsA("BasePart") then
			continue
		end
		v79.CanCollide = false
		v79.CanTouch = false
		v79.CanQuery = v79.Name ~= "CameraPart"
	end
end
local function v_u_87(p81, p82) -- name: recordParts
	local v83 = p82.CFrame
	local v84 = {}
	local v85 = {}
	for _, v86 in p81:GetDescendants() do
		if not v86:IsA("BasePart") then
			continue
		end
		v84[#v84 + 1] = v86
		v85[#v85 + 1] = {
			["Anchored"] = v86.Anchored,
			["CanCollide"] = v86.CanCollide,
			["CanQuery"] = v86.CanQuery,
			["CanTouch"] = v86.CanTouch,
			["Massless"] = v86.Massless,
			["CollisionGroup"] = v86.CollisionGroup,
			["Pose"] = v83:ToObjectSpace(v86.CFrame)
		}
	end
	return v84, v85
end
local function v_u_98(p88, p89) -- name: registerAnimations
	-- upvalues: (copy) v_u_1, (copy) v_u_38
	local v90 = {}
	local v91 = v_u_1.Assets:FindFirstChild("CharacterAnimations")
	local v92 = p89.Idle
	if not v92 then
		if v91 then
			v92 = v91:FindFirstChild("CharacterIdle")
		else
			v92 = v91
		end
	end
	if v92 and v92:IsA("Animation") then
		p88:register("CharacterIdle", v92)
	end
	if v91 then
		v91 = v91:FindFirstChild("Movement")
	end
	local v93 = p89.Jump
	if not v93 then
		if v91 then
			v93 = v91:FindFirstChild("Jump")
		else
			v93 = v91
		end
	end
	if v93 and v93:IsA("Animation") then
		p88:register("Jump", v93)
	end
	local v94 = p89.Walks
	local v95
	if #v94 > 0 then
		v95 = v94[v_u_38:NextInteger(1, #v94)]
	else
		v95 = nil
	end
	if v91 then
		v91 = v91:FindFirstChild("Walking")
	end
	if v91 then
		for _, v96 in v91:GetChildren() do
			if not v96:IsA("Animation") then
				continue
			end
			p88:register(v96.Name, v95 or v96)
		end
	end
	for _, v97 in p89.Attacks do
		p88:register(v97.Name, v97)
		v90[#v90 + 1] = v97.Name
	end
	if p89.Trip then
		p88:register("Trip", p89.Trip)
	end
	return v90
end
local function v_u_108(p99, p100) -- name: castFloor
	-- upvalues: (copy) v_u_11, (copy) v_u_24, (copy) v_u_2, (copy) v_u_46
	local v101 = v_u_11()
	for _, v102 in v_u_24 do
		local v103 = v_u_2:FindFirstChild(v102)
		if not v103 then
			continue
		end
		v101[#v101 + 1] = v103
	end
	v_u_46.FilterDescendantsInstances = v101
	local v104 = v_u_2
	local v105 = p99 + Vector3.new(0, 1, 0)
	local v106 = -(p100 + 1)
	local v107 = v104:Raycast(v105, Vector3.new(0, v106, 0), v_u_46)
	if v107 and v107.Normal.Y > 0.7 then
		return v107
	else
		return nil
	end
end
local function v_u_119(p109) -- name: pickFinish
	-- upvalues: (copy) v_u_13, (copy) v_u_38
	local v110 = {}
	local v111 = v_u_13.GetAllSkinsForWeapon(p109)
	if v111 then
		for _, v112 in v111 do
			if v112.isEnabled == false or v112.skin == "Stock" then
				continue
			end
			v110[#v110 + 1] = v112
		end
	end
	if #v110 == 0 then
		return "Stock", 0
	end
	local v113 = v110[v_u_38:NextInteger(1, #v110)]
	local v114 = v113.floatRange
	local v115 = v114.min
	local v116 = math.max(v115, 0.45)
	local v117 = v114.max
	local v118 = math.min(v116, v117)
	return v113.skin, v_u_38:NextNumber(v118, v114.max)
end
local function v_u_133(p_u_120) -- name: dress
	-- upvalues: (copy) v_u_32, (copy) v_u_38, (copy) v_u_33, (copy) v_u_119, (copy) v_u_13, (copy) v_u_14
	local v121 = v_u_32[v_u_38:NextInteger(1, #v_u_32)]
	local v122 = "Stock"
	local v123 = 0
	local v124, v125, v126
	if v_u_38:NextNumber() < 0.45 then
		v124 = v_u_33[v_u_38:NextInteger(1, #v_u_33)]
		v125, v126 = v_u_119(v124)
		if v125 == "Stock" then
			v126 = v123
			v125 = v122
			v124 = v121
		end
	else
		v126 = v123
		v125 = v122
		v124 = v121
	end
	local v127 = v_u_13.GetCharacterGloves
	local v128, v_u_129 = pcall(v127, v124, v125, v126)
	if v128 and v_u_129 then
		local function v130()
			-- upvalues: (ref) v_u_14, (copy) v_u_129, (copy) p_u_120
			v_u_14(v_u_129:GetChildren(), p_u_120, p_u_120, {
				["collisionGroup"] = "Debris"
			})
		end
		local v131, v132 = pcall(v130)
		if not v131 then
			warn((("[Horde] gloves failed on %*: %*"):format(p_u_120.Name, v132)))
		end
		v_u_129:Destroy()
	end
end
local function v_u_155(p134, p135, p136, p137) -- name: findHitPart
	-- upvalues: (copy) v_u_31
	local v138 = p134:FindFirstChild((p137 or p136 == "Head") and "Head" or "UpperTorso")
	if not (v138 and v138:IsA("BasePart")) then
		v138 = nil
	end
	if not p135 then
		return v138
	end
	local v139 = (1 / 0)
	local v140 = nil
	for _, v141 in v_u_31 do
		local v142 = p134:FindFirstChild(v141)
		if not v142 or (not v142:IsA("BasePart") or v142.Anchored) then
			continue
		end
		local v143 = v142.CFrame:PointToObjectSpace(p135)
		local v144 = v142.Size / 2
		local v145 = v143.X
		local v146 = math.abs(v145) - v144.X
		local v147 = math.max(v146, 0)
		local v148 = v143.Y
		local v149 = math.abs(v148) - v144.Y
		local v150 = math.max(v149, 0)
		local v151 = v143.Z
		local v152 = math.abs(v151) - v144.Z
		local v153 = math.max(v152, 0)
		local v154 = Vector3.new(v147, v150, v153).Magnitude
		if v154 >= v139 then
			continue
		end
		v140 = v142
		v139 = v154
	end
	return v140 or v138
end
local function v_u_173(p156, p157) -- name: clampOnto
	local v158 = p156.CFrame:PointToObjectSpace(p157)
	local v159 = p156.Size / 2
	local v160 = p156.CFrame
	local v161 = v158.X
	local v162 = -v159.X
	local v163 = v159.X
	local v164 = math.clamp(v161, v162, v163)
	local v165 = v158.Y
	local v166 = -v159.Y
	local v167 = v159.Y
	local v168 = math.clamp(v165, v166, v167)
	local v169 = v158.Z
	local v170 = -v159.Z
	local v171 = v159.Z
	local v172 = math.clamp(v169, v170, v171)
	return v160:PointToWorldSpace((Vector3.new(v164, v168, v172)))
end
local function v_u_189(p174, p175, p176, p177, p178) -- name: throwBody
	-- upvalues: (copy) v_u_36, (copy) v_u_30, (copy) v_u_155, (copy) v_u_173
	local v179 = v_u_36:NextNumber(v_u_30.Min, v_u_30.Max)
	local v180 = p174:FindFirstChild("UpperTorso")
	if not (v180 and v180:IsA("BasePart")) then
		v180 = nil
	end
	local v181 = v_u_155(p174, p177, p178, p176)
	local v182
	if p176 and (v181 and v181.Name == "Head") then
		v182 = true
		v181 = v180 or v181
	else
		v182 = false
	end
	local v183 = p175 * (v182 and 8 or 7) * v179 + Vector3.new(0, 5, 0)
	for _, v184 in p174:GetChildren() do
		if not v184:IsA("BasePart") or (v184.Anchored or v184 == v181) then
			continue
		end
		v184:ApplyImpulse(v183 * v184.Mass)
	end
	local v185 = (p176 and 26 or 24) * v179
	if v181 then
		local v186 = v_u_173(v181, p177 or v181.Position)
		local v187 = p175 * v185 * v181.Mass
		if v182 then
			v181:ApplyImpulse(v187 * 0.6)
			v181:ApplyImpulseAtPosition(v187 * 0.4, v186)
		else
			v181:ApplyImpulseAtPosition(v187, v186)
		end
	end
	if v180 and (not v180.Anchored and v180 ~= v181) then
		local v188 = v_u_173(v180, p177 or v180.Position)
		v180:ApplyImpulseAtPosition(p175 * v185 * 0.9 * v180.Mass, v188)
	end
end
local function v_u_194(p190) -- name: popHead
	-- upvalues: (copy) v_u_37
	local v191 = p190.HeadParts[1]
	if v191 and not p190.HeadHidden then
		v_u_37[#v_u_37 + 1] = v191
		for _, v192 in p190.HeadLooks do
			v192.Instance.Transparency = 1
		end
		for _, v193 in p190.HeadParts do
			if not v193.CanCollide then
				continue
			end
			v193.CanCollide = false
		end
		p190.HeadHidden = true
	end
end
local function v_u_201(p195) -- name: findHeadParts
	local v196 = p195:FindFirstChild("Head")
	if not (v196 and v196:IsA("BasePart")) then
		return {}
	end
	local v197 = { v196 }
	for _, v198 in p195:GetDescendants() do
		if not (v198:IsA("WeldConstraint") or (v198:IsA("Weld") or v198:IsA("Motor6D"))) then
			continue
		end
		local v199 = v198.Part0
		local v200 = v198.Part1
		if v199 == v196 then
			v199 = v200
		elseif v200 ~= v196 then
			v199 = nil
		end
		if not v199 or (not v199:IsA("BasePart") or (v199.Parent == v196 or v199.Name == "UpperTorso")) then
			continue
		end
		v197[#v197 + 1] = v199
	end
	return v197
end
local function v_u_208(p202) -- name: findHeadLooks
	local v_u_203 = {}
	local function v205(p204) -- name: add
		-- upvalues: (copy) v_u_203
		if (p204:IsA("BasePart") or p204:IsA("Decal")) and p204.Transparency < 1 then
			v_u_203[#v_u_203 + 1] = {
				["Instance"] = p204,
				["Transparency"] = p204.Transparency
			}
		end
	end
	for _, v206 in p202 do
		v205(v206)
		for _, v207 in v206:GetDescendants() do
			v205(v207)
		end
	end
	return v_u_203
end
local function v_u_223(p209) -- name: build
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_80, (copy) v_u_8, (ref) v_u_51, (copy) v_u_133, (copy) v_u_50, (copy) v_u_23, (copy) v_u_87, (copy) v_u_201, (copy) v_u_208, (copy) v_u_7
	local v210 = p209:Clone()
	v_u_4.PrepareRuntimeRig(v210)
	local v211 = v_u_5.getRootPart(v210)
	local v212 = assert(v211, "character rig has no HumanoidRootPart")
	v_u_80(v210)
	local v213 = v_u_8.Prepare
	pcall(v213, v210)
	if v_u_51 then
		v_u_133(v210)
	end
	local v214 = v_u_8.IsR6(v210)
	for _, v215 in v210:GetDescendants() do
		if v215:IsA("Vector3Value") or (v215:IsA("Sound") or v215:IsA("NoCollisionConstraint")) then
			v215:Destroy()
		else
			if not v214 or (not v215:IsA("MeshPart") or (not v215.HasSkinnedMesh or v_u_50[p209])) then
				continue
			end
			v_u_50[p209] = true
			warn((("[Horde] %* has a skinned mesh (%*): its zombies render through FastCluster"):format(p209.Name, v215.Name)))
		end
	end
	v_u_8.MatchPreparedMass(v210)
	v_u_8.StagePooled(v210, v_u_23)
	local v216, v217 = v_u_87(v210, v212)
	local v218 = v212.CFrame
	local v219 = {}
	local v220 = {}
	for _, v221 in v210:GetChildren() do
		if not v221:IsA("BasePart") or v221:HasTag("CharacterAccessory") then
			continue
		end
		v219[#v219 + 1] = v221
		v220[#v220 + 1] = v218:ToObjectSpace(v221.CFrame)
	end
	local v222 = v_u_201(v210)
	return {
		["Id"] = 0,
		["Template"] = p209,
		["Model"] = v210,
		["Root"] = v212,
		["Parts"] = v216,
		["PartStates"] = v217,
		["BodyParts"] = v219,
		["BodyPoses"] = v220,
		["HeadParts"] = v222,
		["HeadLooks"] = v_u_208(v222),
		["HeadHidden"] = false,
		["Broken"] = false,
		["SinkParts"] = {},
		["SinkFrames"] = {},
		["Animator"] = nil,
		["AttackNames"] = {},
		["LastAnimationAt"] = (-1 / 0),
		["NextSwingAt"] = 0,
		["SwingIndex"] = 0,
		["FloorMaterial"] = "Concrete",
		["FloorProbedAt"] = (-1 / 0),
		["State"] = v_u_7.STATE_IDLE,
		["Dead"] = false,
		["Frozen"] = false,
		["StunHeld"] = false,
		["Ragdolled"] = false,
		["LastVelocity"] = Vector3.new(0, 0, 0),
		["Voice"] = nil,
		["VoicePriority"] = 0,
		["VoiceStartedAt"] = (-1 / 0),
		["VoiceSound"] = nil,
		["StepSound"] = nil,
		["NextGrowlAt"] = 0,
		["VoicePitch"] = 1,
		["Flaming"] = false,
		["Flames"] = {},
		["Crackle"] = nil
	}
end
local function v_u_229(p224, p225) -- name: scaleSequence
	local v226 = {}
	for v227, v228 in p224.Keypoints do
		v226[v227] = NumberSequenceKeypoint.new(v228.Time, v228.Value * p225, v228.Envelope * p225)
	end
	return NumberSequence.new(v226)
end
local function v_u_239(p230) -- name: ignite
	-- upvalues: (copy) v_u_1, (copy) v_u_229, (copy) v_u_34, (ref) v_u_45, (copy) v_u_9
	local v231 = p230.Flames
	if #v231 == 0 then
		local v232 = p230.Model:FindFirstChild("UpperTorso", true) or p230.Root
		local v233 = v_u_1:FindFirstChild("Assets")
		if v233 then
			v233 = v233:FindFirstChild("GrenadeParticles")
		end
		if v233 then
			v233 = v233:FindFirstChild("InnerFire")
		end
		if v233 then
			v233 = v233:FindFirstChild("Fire 3")
		end
		if v233 and v233:IsA("ParticleEmitter") then
			local v234 = v233:Clone()
			v234.Size = v_u_229(v234.Size, 0.5)
			v234.Shape = Enum.ParticleEmitterShape.Box
			v234.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v234.LockedToPart = false
			v234.Enabled = false
			v234.Parent = v232
			v231[#v231 + 1] = v234
		end
		local v235 = Instance.new("PointLight")
		v235.Color = v_u_34
		v235.Brightness = 2
		v235.Range = 12
		v235.Shadows = false
		v235.Enabled = false
		v235.Parent = v232
		v231[#v231 + 1] = v235
	end
	for _, v236 in v231 do
		v236.Enabled = true
	end
	local v237 = v_u_45
	if not v237 then
		v237 = v_u_9.new("Grenade")
		v_u_45 = v237
	end
	local v238 = p230.Crackle
	if not v238 or v238.Parent ~= p230.Root then
		v238 = Instance.new("Sound")
		v238.Name = "Flames"
		v238.Parent = p230.Root
		p230.Crackle = v238
	end
	if v237:playOn(v238, "Flames", 0.4) then
		v238.Looped = true
	end
end
local function v_u_243() -- name: getAllTemplates
	-- upvalues: (copy) v_u_18, (copy) v_u_66
	local v240 = {}
	for v241 in v_u_18 do
		for _, v242 in v_u_66(v241) do
			if table.find(v240, v242) then
				continue
			end
			v240[#v240 + 1] = v242
		end
	end
	return v240
end
function v_u_16.Refill() -- name: Refill
	-- upvalues: (ref) v_u_48, (ref) v_u_49, (ref) v_u_51, (copy) v_u_243, (copy) v_u_47, (copy) v_u_223
	v_u_48 = true
	if not v_u_49 then
		v_u_49 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_48, (ref) v_u_51, (ref) v_u_243, (ref) v_u_47, (ref) v_u_223, (ref) v_u_49
			while v_u_48 and not v_u_51 do
				task.wait(0.5)
			end
			for _, v244 in v_u_243() do
				local v245 = v_u_47[v244]
				if not v245 then
					v245 = {}
					v_u_47[v244] = v245
				end
				while v_u_48 and #v245 < 8 do
					local v246 = v_u_223(v244)
					if not v_u_48 then
						v246.Model:Destroy()
						break
					end
					v245[#v245 + 1] = v246
					task.wait()
				end
			end
			v_u_49 = false
		end)
	end
end
function v_u_16.ClearPool() -- name: ClearPool
	-- upvalues: (ref) v_u_48, (copy) v_u_47, (copy) v_u_53
	v_u_48 = false
	for _, v247 in v_u_47 do
		for _, v248 in v247 do
			v248.Model:Destroy()
		end
	end
	table.clear(v_u_47)
	for _, v249 in v_u_53 do
		v249.Shell.Model:Destroy()
	end
	table.clear(v_u_53)
end
local function v_u_264(p250, p251, p252) -- name: restore
	-- upvalues: (copy) v_u_8, (copy) v_u_2
	local v253 = p250.Model
	if p250.Ragdolled then
		v_u_8.Deactivate(v253)
	end
	if p250.HeadHidden then
		for _, v254 in p250.HeadLooks do
			v254.Instance.Transparency = v254.Transparency
		end
		p250.HeadHidden = false
	end
	for _, v255 in p250.Flames do
		if not v255.Enabled then
			continue
		end
		v255.Enabled = false
	end
	local v256 = p250.Crackle
	if v256 then
		v256:Stop()
	end
	p250.Flaming = false
	if p250.VoiceSound then
		p250.VoiceSound:Stop()
	end
	if p250.StepSound then
		p250.StepSound:Stop()
	end
	if p252 then
		local v257 = p250.BodyParts
		local v258 = table.create(#v257)
		for v259, v260 in v257 do
			if not v260.Anchored then
				v260.Anchored = true
			end
			v258[v259] = p251 * p250.BodyPoses[v259]
		end
		v_u_2:BulkMoveTo(v257, v258, Enum.BulkMoveMode.FireCFrameChanged)
	end
	for v261, v262 in p250.Parts do
		local v263 = p250.PartStates[v261]
		if v262.Anchored ~= v263.Anchored then
			v262.Anchored = v263.Anchored
		end
		if v262.CanCollide ~= v263.CanCollide then
			v262.CanCollide = v263.CanCollide
		end
		if v262.CanQuery ~= v263.CanQuery then
			v262.CanQuery = v263.CanQuery
		end
		if v262.CanTouch ~= v263.CanTouch then
			v262.CanTouch = v263.CanTouch
		end
		if v262.Massless ~= v263.Massless then
			v262.Massless = v263.Massless
		end
		if v262.CollisionGroup ~= v263.CollisionGroup then
			v262.CollisionGroup = v263.CollisionGroup
		end
		if p252 then
			continue
		end
		v262.CFrame = p251 * v263.Pose
		v262.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
		v262.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
	end
	p250.Ragdolled = false
	p250.Voice = nil
	table.clear(p250.SinkParts)
	table.clear(p250.SinkFrames)
end
local function v_u_272(p265, p266) -- name: takeBuried
	-- upvalues: (copy) v_u_53, (copy) v_u_66
	if #v_u_53 == 0 then
		return nil
	else
		local v267 = v_u_66(p266)
		local v268 = nil
		for v269, v270 in v_u_53 do
			local v271 = v270.Shell.Template
			if v271 == p265 then
				table.remove(v_u_53, v269)
				return v270.Shell
			end
			if v268 or not table.find(v267, v271) then
				continue
			end
			v268 = v269
		end
		if v268 then
			return table.remove(v_u_53, v268).Shell
		else
			return nil
		end
	end
end
function v_u_16.Acquire(p273, p274, p275, p276) -- name: Acquire
	-- upvalues: (copy) v_u_66, (copy) v_u_17, (copy) v_u_272, (copy) v_u_22, (copy) v_u_264, (copy) v_u_47, (copy) v_u_223, (copy) v_u_7, (copy) v_u_3, (copy) v_u_98, (copy) v_u_77, (copy) v_u_8, (copy) v_u_26, (copy) v_u_35, (copy) v_u_28, (copy) v_u_239, (copy) v_u_16
	local v277 = v_u_66(p274)
	local v278
	if #v277 > 0 then
		v278 = v277[p273 % #v277 + 1]
	else
		v278 = nil
	end
	local v279 = ("no zombie rig under ReplicatedStorage.Assets.Characters.%* to build a zombie from"):format(v_u_17)
	local v280 = assert(v278, v279)
	local v281 = v_u_272(v280, p274)
	if v281 then
		v_u_264(v281, CFrame.new(p275) * v_u_22, true)
	else
		local v282 = v_u_47[v280]
		if v282 and #v282 > 0 then
			v281 = table.remove(v282)
		else
			v281 = v_u_223(v280)
		end
	end
	local v283 = v281.Model
	v283.Name = v_u_7.modelName(p273)
	v283:SetAttribute(v_u_7.ID_ATTRIBUTE, p273)
	if v283.Parent ~= p276 then
		v283:PivotTo(CFrame.new(p275) * v_u_22 * v281.Root.CFrame:ToObjectSpace(v283:GetPivot()))
		v283.Parent = p276
	end
	if not v281.Animator then
		local v284 = v_u_3.new(v283, {
			["SkipBaseAnimations"] = true
		})
		v281.Animator = v284
		v281.AttackNames = v_u_98(v284, (v_u_77(v_u_8.IsR6(v283))))
	end
	local v285 = v_u_26[p274] or v_u_26[v_u_7.ARCHETYPE_NORMAL]
	v281.Id = p273
	v281.LastAnimationAt = (-1 / 0)
	v281.NextSwingAt = 0
	v281.SwingIndex = 0
	v281.FloorProbedAt = (-1 / 0)
	v281.State = v_u_7.STATE_IDLE
	v281.Dead = false
	v281.Frozen = false
	v281.StunHeld = false
	v281.Ragdolled = false
	v281.LastVelocity = Vector3.new(0, 0, 0)
	v281.Voice = nil
	v281.VoicePriority = 0
	v281.VoiceStartedAt = (-1 / 0)
	v281.NextGrowlAt = os.clock() + v_u_35:NextNumber(v_u_28.Min, v_u_28.Max)
	v281.VoicePitch = v_u_35:NextNumber(v285.Min, v285.Max)
	v281.Flaming = v_u_7.ARCHETYPE_BURSTS[p274] == true
	if v281.Flaming then
		v_u_239(v281)
	end
	v_u_16.Refill()
	return v281
end
function v_u_16.RootFrame(p286, p287, p288, p289) -- name: RootFrame
	-- upvalues: (copy) v_u_22
	return CFrame.new(p286.X, p286.Y - p289, p286.Z) * CFrame.Angles(0, p287, p288 * 1.3962634015954636) * v_u_22
end
function v_u_16.Vocalize(p290, p291, p292, p293, p294) -- name: Vocalize
	-- upvalues: (ref) v_u_40, (copy) v_u_25, (ref) v_u_44, (copy) v_u_9, (copy) v_u_35
	local v295 = p290.Root
	if not v295.Parent then
		return false
	end
	if v_u_40 <= 0 and not p294 then
		return false
	end
	local v296 = v_u_25[p291]
	local v297 = p290.Voice
	if v297 and (v297.Parent and (v297.IsPlaying or not v297.IsLoaded)) then
		if not p292 and v296.Priority <= p290.VoicePriority then
			return false
		end
		if p291 == "Pain" and (p293 == nil and os.clock() - p290.VoiceStartedAt < 0.3) then
			return false
		end
		v297:Stop()
	end
	local v298 = v_u_44
	if not v298 then
		v298 = v_u_9.new("Survival")
		v_u_44 = v298
	end
	local v299 = p290.VoiceSound
	if not v299 or v299.Parent ~= v295 then
		v299 = Instance.new("Sound")
		v299.Name = "Voice"
		v299.Parent = v295
		p290.VoiceSound = v299
	end
	local v300 = v296.PitchVariation
	v299.PlaybackSpeed = (p293 or 1) * p290.VoicePitch * (1 + v_u_35:NextNumber(-v300, v300))
	if not v298:playOn(v299, v296.Sound) then
		return false
	end
	v_u_40 = v_u_40 - 1
	p290.Voice = v299
	p290.VoicePriority = v296.Priority
	p290.VoiceStartedAt = os.clock()
	return true
end
function v_u_16.Pain(p301) -- name: Pain
	-- upvalues: (copy) v_u_16
	v_u_16.Vocalize(p301, "Pain", true)
end
function v_u_16.DeathCry(p302) -- name: DeathCry
	-- upvalues: (copy) v_u_16
	v_u_16.Vocalize(p302, "Pain", true, 0.8, true)
end
function v_u_16.Animate(p303, p304, p305, p306) -- name: Animate
	-- upvalues: (copy) v_u_21, (ref) v_u_39, (copy) v_u_20, (copy) v_u_16, (copy) v_u_35, (copy) v_u_27, (copy) v_u_29
	local v307 = p303.Animator
	if v307 and not (p303.Dead or p303.Frozen) then
		local v308 = v307.Animations.Trip and true or false
		if p303.State == v_u_21 then
			if not p303.StunHeld then
				p303.StunHeld = true
				if v308 then
					v307:play("Trip", 0.1)
				else
					v307:freezeAnimations()
				end
			end
			if v308 then
				local v309 = Vector3.new(0, 0, 0)
				if p304 - p303.LastAnimationAt < 0.06666666666666667 then
					return
				end
				local v310 = v309 * Vector3.new(1, 0, 1)
				local v311 = v310.Magnitude
				local v312
				if v311 < 0.6 then
					v312 = Vector3.new(0, 0, 0)
				else
					local v313 = v311 / 9
					v312 = v310 * (math.max(v313, 1) * 16 / v311)
				end
				v307:updateLocomotion(v312, true, false, false)
				p303.LastAnimationAt = p304
			end
		else
			if p303.StunHeld then
				p303.StunHeld = false
				if not v308 then
					v307:stopAnimations(0)
					p303.LastAnimationAt = (-1 / 0)
				end
			end
			if p303.NextGrowlAt <= p304 then
				if v_u_39 <= p304 and p303.State ~= v_u_20 then
					if v_u_16.Vocalize(p303, "Idle") then
						v_u_39 = p304 + 0.4
					end
					p303.NextGrowlAt = p304 + v_u_35:NextNumber(v_u_27.Min, v_u_27.Max)
				else
					p303.NextGrowlAt = p304 + v_u_35:NextNumber(v_u_29.Min, v_u_29.Max)
				end
			end
			if p304 - p303.LastAnimationAt >= 0.06666666666666667 then
				local v314 = p305 * Vector3.new(1, 0, 1)
				local v315 = v314.Magnitude
				local v316
				if v315 < 0.6 then
					v316 = Vector3.new(0, 0, 0)
				else
					local v317 = v315 / 9
					v316 = v314 * (math.max(v317, 1) * 16 / v315)
				end
				v307:updateLocomotion(v316, not p306, false, false)
				p303.LastAnimationAt = p304
			end
			if p303.State == v_u_20 and p303.NextSwingAt <= p304 then
				local v318 = p303.AttackNames
				if #v318 > 0 then
					p303.SwingIndex = p303.SwingIndex % #v318 + 1
					v307:playAction(v318[p303.SwingIndex])
				end
				v_u_16.Vocalize(p303, "Attack")
				p303.NextSwingAt = p304 + 1.1
			end
		end
	else
		return
	end
end
function v_u_16.SetFrozen(p319, p320) -- name: SetFrozen
	p319.Frozen = p320
	local v321 = p319.Animator
	if v321 then
		if p320 then
			v321:freezeAnimations()
		else
			v321:stopAnimations(0)
			p319.LastAnimationAt = (-1 / 0)
			p319.StunHeld = false
		end
	else
		return
	end
end
function v_u_16.Flinch(p322, p323, p324) -- name: Flinch
	-- upvalues: (copy) v_u_6
	if p323 then
		v_u_6.flickHead(p322.Model, p324)
	else
		v_u_6.flinchBody(p322.Model, p324)
	end
end
function v_u_16.FloorHeight(p325, p326) -- name: FloorHeight
	-- upvalues: (copy) v_u_108
	local v327 = v_u_108(p325, p326)
	if v327 then
		return v327.Position.Y
	else
		return nil
	end
end
function v_u_16.Footstep(p328, p329, p330) -- name: Footstep
	-- upvalues: (ref) v_u_43, (copy) v_u_9, (copy) v_u_108, (copy) v_u_10
	local v331 = v_u_43
	if not v331 then
		v331 = v_u_9.new("FloorSounds")
		v_u_43 = v331
	end
	local v332 = v331.Sounds
	if v332 then
		local v333
		if p330 - p328.FloorProbedAt < 0.5 then
			v333 = p328.FloorMaterial
		else
			p328.FloorProbedAt = p330
			local v334 = v_u_108(p329, 3.5)
			if v334 then
				p328.FloorMaterial = v334.Material.Name
			end
			v333 = p328.FloorMaterial
		end
		if not v332:FindFirstChild(v333) then
			v333 = v_u_10[v333] or "Ground"
			if not v332:FindFirstChild(v333) then
				return
			end
		end
		local v335 = p328.StepSound
		if not v335 or v335.Parent ~= p328.Root then
			v335 = Instance.new("Sound")
			v335.Name = "Step"
			v335.Parent = p328.Root
			p328.StepSound = v335
		end
		v331:playOn(v335, v333, 0.8)
	end
end
function v_u_16.Ragdoll(p336, p337, p338, p339, p340) -- name: Ragdoll
	-- upvalues: (copy) v_u_8, (copy) v_u_189, (copy) v_u_194
	local v341 = p336.Model
	if not v341.Parent then
		return false
	end
	if p336.Animator then
		p336.Animator:stopAnimations(0)
	end
	local v342 = v_u_8.Activate
	local v343 = p336.LastVelocity
	local v344, v345 = pcall(v342, v341, nil, v343, 0.5, 1)
	if not (v344 and v345) then
		warn((("[Horde] ragdoll failed for zombie %*: %*"):format(p336.Id, v344 and "activation returned false" or tostring(v345))))
		p336.Broken = true
		return false
	end
	p336.Ragdolled = true
	local v346
	if p338 and p338.Magnitude > 0.001 then
		v346 = p338.Unit
	else
		v346 = nil
	end
	if v346 then
		local v347 = v346 * Vector3.new(1, 0, 1)
		if v347.Magnitude < 0.1 then
			v347 = -p336.Root.CFrame.LookVector * Vector3.new(1, 0, 1)
		end
		v_u_189(v341, (v347.Unit + Vector3.new(0, 0.15, 0)).Unit, p337 == true, p339, p340)
	end
	if p337 then
		debug.profilebegin("Horde.PopHead")
		v_u_194(p336)
		debug.profileend()
	end
	return true
end
function v_u_16.StepEffects() -- name: StepEffects
	-- upvalues: (ref) v_u_40, (copy) v_u_37, (copy) v_u_12
	v_u_40 = 2
	local v348 = table.remove(v_u_37, 1)
	if v348 then
		debug.profilebegin("Horde.HeadshotBlood")
		local v349 = v_u_12
		local v350 = v348.Position
		pcall(v349, v348, "Blood Splatter", v350, Vector3.new(0, 1, 0), false, false, false, nil, false, false, false, true)
		debug.profileend()
	end
end
function v_u_16.Burst(p351) -- name: Burst
	-- upvalues: (copy) v_u_1, (copy) v_u_15
	if p351.Flaming then
		p351.Flaming = false
		local v352 = p351.Root.Position
		for _, v353 in p351.Flames do
			if not v353.Enabled then
				continue
			end
			v353.Enabled = false
		end
		local v354 = p351.Crackle
		if v354 then
			v354:Stop()
		end
		local v355 = v_u_1:FindFirstChild("Assets")
		if v355 then
			v355 = v355:FindFirstChild("GrenadeParticles")
		end
		if v355 then
			v355 = v355:FindFirstChild("HE Grenade")
		end
		if v355 and (v355:IsA("BasePart") and p351.Model.Parent) then
			v_u_15(v355, v352, "HE Grenade")
		end
	else
		return
	end
end
function v_u_16.Retire(p356) -- name: Retire
	if p356.Animator then
		p356.Animator:stopAnimations(0)
	end
end
function v_u_16.Destroy(p357) -- name: Destroy
	if p357.Animator then
		p357.Animator:destroy()
		p357.Animator = nil
	end
	p357.Model:Destroy()
end
function v_u_16.Recycle(p358) -- name: Recycle
	-- upvalues: (copy) v_u_47, (ref) v_u_48, (copy) v_u_264
	if p358.Animator then
		p358.Animator:destroy()
		p358.Animator = nil
	end
	local v359 = p358.Model
	local v360 = v_u_47[p358.Template]
	if not v360 then
		v360 = {}
		v_u_47[p358.Template] = v360
	end
	if p358.Broken or (not v_u_48 or #v360 >= 40) then
		v359:Destroy()
	else
		v359.Parent = nil
		v_u_264(p358, p358.Root.CFrame, false)
		v360[#v360 + 1] = p358
	end
end
function v_u_16.Bury(p361, p362) -- name: Bury
	-- upvalues: (ref) v_u_48, (copy) v_u_53, (copy) v_u_16, (copy) v_u_7
	if p361.Broken or (not v_u_48 or (#v_u_53 >= 10 or not p361.Model.Parent)) then
		return false
	end
	v_u_16.Retire(p361)
	p361.Model:SetAttribute(v_u_7.ID_ATTRIBUTE, nil)
	p361.Model.Name = "Buried"
	v_u_53[#v_u_53 + 1] = {
		["Shell"] = p361,
		["At"] = p362
	}
	return true
end
function v_u_16.EvictBuried(p363) -- name: EvictBuried
	-- upvalues: (copy) v_u_53, (copy) v_u_16
	local v364 = v_u_53[1]
	if not v364 or p363 - v364.At < 8 then
		return false
	end
	table.remove(v_u_53, 1)
	v_u_16.Recycle(v364.Shell)
	return true
end
function v_u_16.HasBuried() -- name: HasBuried
	-- upvalues: (copy) v_u_53
	return #v_u_53 > 0
end
function v_u_16.BeginSink(p365) -- name: BeginSink
	-- upvalues: (copy) v_u_2
	local v366 = p365.SinkParts
	local v367 = p365.SinkFrames
	table.clear(v366)
	table.clear(v367)
	for _, v368 in p365.BodyParts do
		if not v368:IsDescendantOf(v_u_2) then
			continue
		end
		if not v368.Anchored then
			v368.Anchored = true
		end
		v366[#v366 + 1] = v368
		v367[#v367 + 1] = v368.CFrame
	end
end
function v_u_16.AppendSink(p369, p370, p371, p372) -- name: AppendSink
	local v373 = -p370
	local v374 = Vector3.new(0, v373, 0)
	local v375 = p369.SinkFrames
	for v376, v377 in p369.SinkParts do
		local v378 = #p371 + 1
		local v379 = v375[v376] + v374
		p371[v378] = v377
		p372[v378] = v379
	end
end
return v_u_16
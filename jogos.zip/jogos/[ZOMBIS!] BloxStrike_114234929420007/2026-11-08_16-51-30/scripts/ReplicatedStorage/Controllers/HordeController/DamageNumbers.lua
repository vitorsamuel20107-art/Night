-- NIGHT Analyzer | ReplicatedStorage.Controllers.HordeController.DamageNumbers
-- ModuleScript | 226 linhas | 6144 bytes | hash 8e1b7a74

local v1 = {}
local v_u_2 = game:GetService("TweenService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Bold, Enum.FontStyle.Normal)
local v_u_6 = Color3.fromRGB(255, 255, 255)
local v_u_7 = Color3.new(0, 0, 0)
local v_u_8 = Color3.fromRGB(255, 220, 140)
local v_u_9 = Color3.fromRGB(214, 41, 41)
local v_u_10 = Color3.fromRGB(255, 150, 60)
local v_u_11 = TweenInfo.new(1.25, Enum.EasingStyle.Quad)
local v_u_12 = TweenInfo.new(1, Enum.EasingStyle.Quad)
local v_u_13 = TweenInfo.new(0.15)
local v_u_14 = Random.new()
local v_u_15 = {}
local v_u_16 = {}
local v_u_17 = false
local v_u_18 = {}
local v_u_19 = {}
local function v_u_23() -- name: build
	-- upvalues: (copy) v_u_5, (copy) v_u_7, (copy) v_u_4
	local v20 = Instance.new("Attachment")
	v20.Name = "DamageNumber"
	local v21 = Instance.new("BillboardGui")
	v21.AlwaysOnTop = true
	v21.LightInfluence = 0
	v21.MaxDistance = 250
	v21.ResetOnSpawn = false
	v21.Enabled = false
	v21.Parent = v20
	local v22 = Instance.new("TextLabel")
	v22.AnchorPoint = Vector2.new(0.5, 0.5)
	v22.Position = UDim2.fromScale(0.5, 0.5)
	v22.Size = UDim2.fromScale(1, 1)
	v22.BackgroundTransparency = 1
	v22.FontFace = v_u_5
	v22.TextScaled = true
	v22.TextStrokeColor3 = v_u_7
	v22.Parent = v21
	v20.Parent = v_u_4.Terrain
	return {
		["Anchor"] = nil,
		["Billboard"] = nil,
		["Label"] = nil,
		["Tweens"] = nil,
		["Serial"] = 0,
		["Anchor"] = v20,
		["Billboard"] = v21,
		["Label"] = v22,
		["Tweens"] = {}
	}
end
local function v_u_47(p24) -- name: spawnNumber
	-- upvalues: (copy) v_u_18, (copy) v_u_19, (copy) v_u_23, (copy) v_u_9, (copy) v_u_10, (copy) v_u_8, (copy) v_u_6, (copy) v_u_14, (copy) v_u_11, (copy) v_u_2, (copy) v_u_12, (copy) v_u_13
	while #v_u_18 >= 40 do
		local v25 = v_u_18[1]
		local v26 = table.find(v_u_18, v25)
		if v26 then
			table.remove(v_u_18, v26)
		end
		for _, v27 in v25.Tweens do
			v27:Cancel()
		end
		table.clear(v25.Tweens)
		v25.Billboard.Enabled = false
		v_u_19[#v_u_19 + 1] = v25
	end
	local v_u_28 = table.remove(v_u_19) or v_u_23()
	v_u_28.Serial = v_u_28.Serial + 1
	local v_u_29 = v_u_28.Serial
	v_u_18[#v_u_18 + 1] = v_u_28
	local v30 = p24.Headshot and 32 or 28
	local v31 = v_u_28.Billboard
	local v_u_32 = v_u_28.Label
	v_u_28.Anchor.WorldPosition = p24.Position
	v31.StudsOffsetWorldSpace = Vector3.new(0, 0, 0)
	v31.Size = UDim2.fromOffset(v30, v30)
	local v33
	if p24.Died then
		v33 = v_u_9
	elseif p24.Burn then
		v33 = v_u_10
	elseif p24.Headshot then
		v33 = v_u_8
	else
		v33 = v_u_6
	end
	v_u_32.TextColor3 = v33
	v_u_32.TextTransparency = 0
	v_u_32.TextStrokeTransparency = 0.45
	v_u_32.Rotation = v_u_14:NextNumber(-25, 25)
	local v34 = p24.Damage
	local v35 = math.round(v34)
	local v36 = math.max(1, v35)
	v_u_32.Text = tostring(v36)
	v31.Enabled = true
	local v37 = v_u_14:NextNumber(-1.25, 1.25)
	local v38 = 2 + v_u_14:NextNumber(-1.25, 1.25)
	local v39 = v_u_14
	local v40 = v_u_2:Create(v31, v_u_11, {
		["StudsOffsetWorldSpace"] = Vector3.new(v37, v38, v39:NextNumber(-1.25, 1.25)),
		["Size"] = UDim2.fromOffset(36, 36)
	})
	v_u_28.Tweens[#v_u_28.Tweens + 1] = v40
	v40:Play()
	local v41 = v_u_2:Create(v_u_32, v_u_12, {
		["Rotation"] = 0
	})
	v_u_28.Tweens[#v_u_28.Tweens + 1] = v41
	v41:Play()
	task.delay(1.25, function()
		-- upvalues: (copy) v_u_28, (copy) v_u_29, (copy) v_u_32, (ref) v_u_13, (ref) v_u_2, (ref) v_u_18, (ref) v_u_19
		if v_u_28.Serial == v_u_29 and v_u_28.Billboard.Enabled then
			local v42 = v_u_28
			local v43 = v_u_2:Create(v_u_32, v_u_13, {
				["TextTransparency"] = 1,
				["TextStrokeTransparency"] = 1
			})
			v42.Tweens[#v42.Tweens + 1] = v43
			v43:Play()
			task.delay(0.15, function()
				-- upvalues: (ref) v_u_28, (ref) v_u_29, (ref) v_u_18, (ref) v_u_19
				if v_u_28.Serial == v_u_29 and v_u_28.Billboard.Enabled then
					local v44 = v_u_28
					local v45 = table.find(v_u_18, v44)
					if v45 then
						table.remove(v_u_18, v45)
					end
					for _, v46 in v44.Tweens do
						v46:Cancel()
					end
					table.clear(v44.Tweens)
					v44.Billboard.Enabled = false
					v_u_19[#v_u_19 + 1] = v44
				end
			end)
		end
	end)
end
local function v_u_49() -- name: flush
	-- upvalues: (ref) v_u_17, (copy) v_u_15, (copy) v_u_47
	v_u_17 = false
	debug.profilebegin("Horde.DamageNumbers")
	for _, v48 in v_u_15 do
		v_u_47(v48)
	end
	table.clear(v_u_15)
	debug.profileend()
end
local function v_u_52(p50) -- name: flushBurn
	-- upvalues: (copy) v_u_16, (copy) v_u_47
	local v51 = v_u_16[p50]
	if v51 then
		v_u_16[p50] = nil
		v_u_47(v51)
	end
end
function v1.Show(p53, p54, p55, p56, p57, p58) -- name: Show
	-- upvalues: (copy) v_u_16, (copy) v_u_52, (copy) v_u_47, (copy) v_u_15, (ref) v_u_17, (copy) v_u_3, (copy) v_u_49
	if p58 then
		local v59 = v_u_16[p53]
		if v59 then
			v59.Damage = v59.Damage + p55
			v59.Died = v59.Died or p57
		else
			v_u_16[p53] = {
				["Damage"] = nil,
				["Position"] = nil,
				["Headshot"] = false,
				["Died"] = nil,
				["Burn"] = true,
				["Damage"] = p55,
				["Position"] = p54,
				["Died"] = p57
			}
			task.delay(0.6, v_u_52, p53)
		end
		local v60 = p57 and v_u_16[p53]
		if v60 then
			v_u_16[p53] = nil
			v_u_47(v60)
		end
	else
		local v61 = v_u_15[p53]
		if v61 then
			v61.Damage = v61.Damage + p55
			v61.Headshot = v61.Headshot or p56
			v61.Died = v61.Died or p57
		else
			v_u_15[p53] = {
				["Damage"] = nil,
				["Position"] = nil,
				["Headshot"] = nil,
				["Died"] = nil,
				["Burn"] = false,
				["Damage"] = p55,
				["Position"] = p54,
				["Headshot"] = p56,
				["Died"] = p57
			}
		end
		if not v_u_17 then
			v_u_17 = true
			v_u_3.Heartbeat:Once(v_u_49)
		end
	end
end
function v1.Clear() -- name: Clear
	-- upvalues: (copy) v_u_15, (copy) v_u_16, (copy) v_u_18, (copy) v_u_19
	table.clear(v_u_15)
	table.clear(v_u_16)
	for _, v62 in v_u_18 do
		for _, v63 in v62.Tweens do
			v63:Cancel()
		end
		table.clear(v62.Tweens)
		v62.Serial = v62.Serial + 1
		v62.Anchor:Destroy()
	end
	table.clear(v_u_18)
	for _, v64 in v_u_19 do
		v64.Anchor:Destroy()
	end
	table.clear(v_u_19)
end
return v1
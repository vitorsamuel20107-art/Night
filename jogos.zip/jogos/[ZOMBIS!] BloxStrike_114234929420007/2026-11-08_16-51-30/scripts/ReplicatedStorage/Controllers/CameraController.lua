-- NIGHT Analyzer | ReplicatedStorage.Controllers.CameraController
-- ModuleScript | 965 linhas | 28502 bytes | hash 1861ff98

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("RunService")
local v5 = game:GetService("Players")
require(script:WaitForChild("Types"))
local v_u_6 = require(v_u_2.Controllers.DataController)
local v_u_7 = require(v_u_2.Components.Common.CharacterResolver)
local v_u_8 = require(v_u_2.Components.Common.LocalFootsteps)
local v_u_9 = require(v_u_2.MovementV2.RuntimeKinematics)
local v_u_10 = require(v_u_2.MovementV2.SpeedProfile)
local v_u_11 = require(v_u_2.Controllers.RunServiceController)
local v_u_12 = require(v_u_2.Database.Custom.Constants)
local v13 = require(v_u_2.Shared.Spring)
local v_u_14 = v5.LocalPlayer
local v_u_15 = v_u_14:WaitForChild("PlayerGui")
local v_u_16 = workspace.CurrentCamera
local v_u_17 = true
local v_u_18 = 1
local v_u_19 = 0
local v_u_20 = {}
local v_u_21 = {}
local v_u_22 = false
local v_u_23 = 1
local v_u_24 = 0.5
local v_u_25 = nil
local v_u_26 = nil
local v_u_27 = nil
local v_u_28 = nil
local v_u_29 = nil
local v_u_30 = 0
local v_u_31 = false
local v_u_32 = false
local v_u_33 = 0
local v_u_34 = nil
local v_u_35 = nil
local v_u_36 = 0
local v_u_37 = nil
local v_u_38 = nil
local v_u_39 = nil
local v_u_40 = nil
local v_u_41 = {}
local v_u_42 = nil
local v_u_43 = v13.new(1, 100, v_u_12.DEFAULT_CAMERA_FOV)
local v_u_44 = v13.new(1, 10, Vector3.new(0, 0, 0))
local v_u_45 = v13.new(0.4, 25, Vector3.new(0, 0, 0))
local v_u_46 = v13.new(0.3, 35, Vector3.new(0, 0, 0))
local v_u_47 = v13.new(1, 1, Vector3.new(0, 0, 0))
local v_u_48 = v13.new(1, 1, Vector3.new(0, 0, 0))
local v_u_49 = v13.new(1, 1, Vector3.new(0, 0, 0))
local v_u_50 = v13.new(1, 6, 0)
local function v_u_55() -- name: getCameraInput
	-- upvalues: (ref) v_u_25, (copy) v_u_14
	if v_u_25 then
		return v_u_25
	end
	local v51 = v_u_14:FindFirstChild("PlayerScripts")
	if v51 then
		v51 = v51:FindFirstChild("PlayerModule")
	end
	if v51 then
		v51 = v51:FindFirstChild("CameraModule")
	end
	if v51 then
		v51 = v51:FindFirstChild("CameraInput")
	end
	if not (v51 and v51:IsA("ModuleScript")) then
		return nil
	end
	local v52 = require
	local v53, v54 = pcall(v52, v51)
	if not (v53 and (v54 and v54.setTouchSensitivity)) then
		return nil
	end
	v_u_25 = v54
	return v54
end
local function v_u_64(p56) -- name: getCameraCFrame
	-- upvalues: (ref) v_u_26, (copy) v_u_2, (copy) v_u_48, (copy) v_u_45, (copy) v_u_44, (copy) v_u_47, (copy) v_u_49, (ref) v_u_18, (copy) v_u_46, (ref) v_u_34, (ref) v_u_33
	if not v_u_26 then
		local function v57()
			-- upvalues: (ref) v_u_2
			return require(v_u_2.Controllers.AimAssistController)
		end
		local v58, v59 = pcall(v57)
		if v58 and v59 then
			v_u_26 = v59
		end
	end
	local v60 = v_u_26
	local v61 = not v60 and Vector3.new(1, 1, 1) or v60.GetRecoilAssistScale()
	local v62 = v_u_48:getPosition() + v_u_45:getPosition()
	local v63 = v_u_44:getPosition() + v_u_47:getPosition() + v_u_49:getPosition() * (p56 or v_u_18) * v61 + v_u_46:getPosition()
	return v_u_34 * CFrame.new(v62) * CFrame.Angles(v63.X - v_u_33, v63.Y, v63.Z)
end
local function v69() -- name: getAspectRatioStretch
	-- upvalues: (ref) v_u_36, (ref) v_u_17, (ref) v_u_41, (copy) v_u_16
	if v_u_36 > 0 and v_u_17 then
		for _, v65 in v_u_41 do
			if not v65.IsActive() then
				continue
			end
			v66 = true
		end
		local v66 = false
		if not v66 then
			local v67 = v_u_16.ViewportSize
			if v67.X <= 0 or v67.Y <= 0 then
				return 1
			end
			local v68 = v67.X / v67.Y / 1.3333333333333333
			return (math.max(v68, 1.3333333333333333) - 1) * v_u_36 + 1
		end
	end
	return 1
end
local function v_u_83() -- name: applyAspectRatioStretch
	-- upvalues: (ref) v_u_36, (ref) v_u_17, (ref) v_u_41, (copy) v_u_16, (ref) v_u_38, (ref) v_u_39, (ref) v_u_40
	local v70
	if v_u_36 <= 0 or not v_u_17 then
		v70 = 1
	else
		for _, v71 in v_u_41 do
			if not v71.IsActive() then
				continue
			end
			v72 = true
		end
		local v72 = false
		if v72 then
			v70 = 1
		else
			local v73 = v_u_16.ViewportSize
			if v73.X <= 0 or v73.Y <= 0 then
				v70 = 1
			else
				local v74 = v73.X / v73.Y / 1.3333333333333333
				v70 = (math.max(v74, 1.3333333333333333) - 1) * v_u_36 + 1
			end
		end
	end
	if v70 > 1 then
		local v75 = 1 / v70
		local v76 = v_u_16.CFrame
		local v77 = v_u_16.FieldOfView
		local v78 = v76 * CFrame.new(0, 0, 0, 1, 0, 0, 0, v75, 0, 0, 0, 1)
		local v79 = math.rad(v77) / 2
		local v80 = v75 * math.tan(v79)
		local v81 = math.atan(v80) * 2
		local v82 = math.deg(v81)
		v_u_38 = v76
		v_u_39 = v77
		v_u_16.CFrame = v78
		v_u_16.FieldOfView = v82
		v_u_40 = v_u_16.FieldOfView
	end
end
local function v_u_89() -- name: restoreAspectRatioStretch
	-- upvalues: (ref) v_u_38, (ref) v_u_39, (ref) v_u_40, (copy) v_u_16
	local v84 = v_u_38
	local v85 = v_u_39
	local v86 = v_u_40
	if v84 and (v85 and v86) then
		v_u_38 = nil
		v_u_39 = nil
		v_u_40 = nil
		local v87 = v_u_16.CFrame
		if v87.Position:FuzzyEq(v84.Position, 0.001) and v87.LookVector:FuzzyEq(v84.LookVector, 0.001) then
			v_u_16.CFrame = v84
		end
		local v88 = v_u_16.FieldOfView - v86
		if math.abs(v88) <= 0.001 then
			v_u_16.FieldOfView = v85
		end
	end
end
local function v_u_95() -- name: isOwnGameplayView
	-- upvalues: (copy) v_u_16, (ref) v_u_41, (ref) v_u_42, (copy) v_u_7
	if v_u_16.CameraType == Enum.CameraType.Custom then
		for _, v90 in v_u_41 do
			if not v90.IsActive() then
				continue
			end
			v91 = true
		end
		local v91 = false
		if not v91 then
			if v_u_42 and v_u_42() then
				return false
			end
			local v92 = v_u_7.getLocalCharacter()
			local v93 = v_u_16.CameraSubject
			local v94 = v92 ~= nil and (v93 ~= nil and v93:IsDescendantOf(v92))
			if v94 then
				v94 = v_u_7.isAliveCharacter(v92)
			end
			return v94
		end
	end
	return false
end
function v_u_1.getWeaponKickRotation() -- name: getWeaponKickRotation
	-- upvalues: (copy) v_u_47
	return v_u_47:getPosition()
end
function v_u_1.updateCameraFOV(p96) -- name: updateCameraFOV
	-- upvalues: (copy) v_u_21, (copy) v_u_43
	for _, v98 in pairs(v_u_21) do
		if v98 == nil then
			v_u_43:setGoal((math.clamp(p96, 1, 80)))
		end
	end
	local v98 = nil
	if v98 == nil then
		v_u_43:setGoal((math.clamp(p96, 1, 80)))
	end
end
function v_u_1.getTargetFOV() -- name: getTargetFOV
	-- upvalues: (copy) v_u_43
	local v99 = v_u_43:getGoal()
	return math.clamp(v99, 1, 80)
end
function v_u_1.setFOVLock(p100, p101, p102) -- name: setFOVLock
	-- upvalues: (copy) v_u_21, (copy) v_u_43
	-- block 12
	local v103 = v_u_21
	local v104
	if p101 then
		local v105 = p102 or v_u_43:getGoal()
		v104 = math.clamp(v105, 1, 80)
	else
		v104 = nil
	end
	v103[p100] = v104
	local v106, v107, v108
	-- GenericForInit
v106, v107, v108 = pairs(v_u_21)
[internal control] = v108
-- end GenericForInit
	local v109, v110
	-- GenericForNext
v109, v110 = v106(v107, [internal control])
if v109 ~= nil
[internal control] = v109
-- end GenericForNext
	::l2::
	v110 = nil
	if v110 ~= nil then
		v_u_43:reset(v110)
	end
	return
	-- block 7
	goto l8
	::l8::
	if v110 ~= nil then
		v_u_43:reset(v110)
	end
	return
	-- block 9
	goto l2
end
function v_u_1.setMouseEnabled(p111) -- name: setMouseEnabled
	-- upvalues: (ref) v_u_22, (copy) v_u_20, (copy) v_u_3, (copy) v_u_15
	v_u_22 = p111
	if next(v_u_20) == nil then
		v_u_3.MouseBehavior = p111 and Enum.MouseBehavior.Default or Enum.MouseBehavior.LockCenter
		v_u_3.MouseIconEnabled = p111
		local v112 = v_u_15:FindFirstChild("MainGui")
		if v112 then
			v112 = v112:FindFirstChild("CameraPerspective")
		end
		if v112 and v112.Visible ~= p111 then
			v112.Visible = p111
		end
	end
end
function v_u_1.setForceLockOverride(p113, p114) -- name: setForceLockOverride
	-- upvalues: (copy) v_u_20, (ref) v_u_22, (copy) v_u_3, (copy) v_u_15
	v_u_20[p113] = p114 and true or nil
	local v115 = next(v_u_20) ~= nil and true or v_u_22
	v_u_3.MouseBehavior = v115 and Enum.MouseBehavior.Default or Enum.MouseBehavior.LockCenter
	v_u_3.MouseIconEnabled = v115
	local v116 = v_u_15:FindFirstChild("MainGui")
	if v116 then
		v116 = v116:FindFirstChild("CameraPerspective")
	end
	if v116 and v116.Visible ~= v115 then
		v116.Visible = v115
	end
end
function v_u_1.resetForceLockOverride() -- name: resetForceLockOverride
	-- upvalues: (copy) v_u_20, (ref) v_u_22, (copy) v_u_3, (copy) v_u_15
	table.clear(v_u_20)
	v_u_22 = false
	v_u_3.MouseBehavior = Enum.MouseBehavior.LockCenter
	v_u_3.MouseIconEnabled = false
	local v117 = v_u_15:FindFirstChild("MainGui")
	if v117 then
		v117 = v117:FindFirstChild("CameraPerspective")
	end
	if v117 and v117.Visible ~= false then
		v117.Visible = false
	end
end
function v_u_1.isForceLockOverrideActive() -- name: isForceLockOverrideActive
	-- upvalues: (copy) v_u_20
	return next(v_u_20) ~= nil
end
function v_u_1.SetEnabled(p118) -- name: SetEnabled
	-- upvalues: (ref) v_u_17, (ref) v_u_34, (ref) v_u_35, (ref) v_u_29, (copy) v_u_55
	v_u_17 = p118
	if not p118 then
		v_u_34 = nil
		v_u_35 = nil
		if v_u_29 then
			local v119 = v_u_29 - 1
			if math.abs(v119) <= 0.0001 then
				return
			end
		end
		local v120 = v_u_55()
		if v120 and v120.setGamepadAssistMultiplier then
			v_u_29 = 1
			v120.setGamepadAssistMultiplier(1)
		end
	end
end
function v_u_1.setPerspective(p121, p122, p123) -- name: setPerspective
	-- upvalues: (copy) v_u_1, (copy) v_u_14
	local v124 = math.max(p121 and 0 or (p123 or 5), 0.5)
	v_u_1.setMouseEnabled(p122)
	if v_u_14.CameraMaxZoomDistance ~= v124 or v_u_14.CameraMinZoomDistance ~= v124 then
		v_u_14.CameraMaxZoomDistance = v124
		v_u_14.CameraMinZoomDistance = v124
	end
	local v125 = p121 and Enum.CameraMode.LockFirstPerson or Enum.CameraMode.Classic
	if v_u_14.CameraMode ~= v125 then
		v_u_14.CameraMode = v125
	end
end
function v_u_1.toWeaponFirePosition() -- name: toWeaponFirePosition
	-- upvalues: (ref) v_u_34, (copy) v_u_47, (copy) v_u_48, (copy) v_u_16, (copy) v_u_1, (copy) v_u_64
	if v_u_34 then
		v_u_47:reset(Vector3.new(0, 0, 0))
		v_u_48:reset(Vector3.new(0, 0, 0))
		v_u_16.CFrame = v_u_34
		v_u_1.updateCamera((v_u_64(1)))
	end
end
function v_u_1.weaponKick(p126, p127) -- name: weaponKick
	-- upvalues: (copy) v_u_47, (copy) v_u_48, (copy) v_u_1
	v_u_47:setDampingRatio(p126.Damper)
	v_u_47:setFrequency(p126.Speed)
	v_u_47:setPosition(p126.Value * 0.017453292519943295)
	v_u_48:setDampingRatio(p127.Damper)
	v_u_48:setFrequency(p127.Speed)
	v_u_48:setPosition(p127.Value)
	v_u_1.updateCamera()
end
function v_u_1.setWeaponRecoil(p128, p129) -- name: setWeaponRecoil
	-- upvalues: (copy) v_u_49, (ref) v_u_18
	v_u_49:setDampingRatio(p128.Damper)
	v_u_49:setFrequency(p128.Speed)
	v_u_49:setGoal(p128.Value)
	v_u_18 = p129
end
function v_u_1.setBaseCameraCFrame(p130) -- name: setBaseCameraCFrame
	-- upvalues: (ref) v_u_34, (ref) v_u_35
	v_u_34 = p130
	v_u_35 = p130
end
function v_u_1.resetWeaponRecoil() -- name: resetWeaponRecoil
	-- upvalues: (copy) v_u_49, (ref) v_u_18
	v_u_49:reset(Vector3.new(0, 0, 0))
	v_u_18 = 1
end
function v_u_1.BombExploded(p131) -- name: BombExploded
	-- upvalues: (copy) v_u_21, (copy) v_u_45, (copy) v_u_46, (copy) v_u_43
	for _, v137 in pairs(v_u_21) do
		::l3::
		if v137 == nil then
			local v133 = p131 / 75
			local v134 = 1 - math.min(v133, 1)
			local v135 = math.max(0.35, v134)
			v_u_45:impulse(Vector3.new(1.2, 0.5, 0.7) * v135)
			v_u_46:impulse(Vector3.new(0.17453292, 0.06981317, 0.05235988) * v135)
			local v_u_136 = v_u_43:getGoal()
			v_u_43:setGoal(v_u_136 - v135 * 1.5)
			task.delay(0.15, function()
				-- upvalues: (ref) v_u_43, (copy) v_u_136
				v_u_43:setGoal(v_u_136)
			end)
		end
	end
	local v137 = nil
	goto l3
end
function v_u_1.updateCamera(p138) -- name: updateCamera
	-- upvalues: (copy) v_u_89, (copy) v_u_21, (copy) v_u_43, (copy) v_u_16, (copy) v_u_12, (ref) v_u_23, (ref) v_u_24, (ref) v_u_26, (copy) v_u_2, (ref) v_u_27, (copy) v_u_3, (ref) v_u_28, (copy) v_u_55, (ref) v_u_29, (copy) v_u_64, (ref) v_u_35
	v_u_89()
	for _, v159 in pairs(v_u_21) do
		::l3::
		if v159 ~= nil and v_u_43:getGoal() ~= v159 then
			v_u_43:reset(v159)
		end
		local v140 = v159 or v_u_43:getPosition()
		local v141 = math.clamp(v140, 1, 80)
		if v_u_16.FieldOfViewMode ~= Enum.FieldOfViewMode.Diagonal then
			v_u_16.FieldOfViewMode = Enum.FieldOfViewMode.Diagonal
		end
		local v142 = v_u_16.FieldOfView - v141
		if math.abs(v142) > 0.001 then
			v_u_16.FieldOfView = v141
		end
		local v143 = v_u_12.DEFAULT_CAMERA_FOV
		local v144 = v141 / v143
		local v145 = v_u_23
		local v146 = v141 - (v143 - 37)
		if math.abs(v146) < 0.1 then
			v145 = v_u_23 * v_u_24
		else
			local v147 = v141 - (v143 - 60)
			if math.abs(v147) < 0.1 then
				v145 = v_u_23 * v_u_24
			end
		end
		if not v_u_26 then
			local function v148()
				-- upvalues: (ref) v_u_2
				return require(v_u_2.Controllers.AimAssistController)
			end
			local v149, v150 = pcall(v148)
			if v149 and v150 then
				v_u_26 = v150
			end
		end
		local v151 = v_u_26
		local v152 = not v151 and 1 or v151.GetFrictionMultiplier()
		local v153 = v144 * v145 * v152
		local v154, v155, v156, v157
		if v_u_27 then
			local v158 = v_u_27 - v153
			if math.abs(v158) > 0.0001 then
				v_u_27 = v153
				v_u_3.MouseDeltaSensitivity = v153
				if v_u_28 then
					v154 = v_u_28 - v153
					if math.abs(v154) <= 0.0001 then
						if not v_u_29 then
							v155 = v_u_55()
							if v155 and v155.setGamepadAssistMultiplier then
								v_u_29 = v152
								v155.setGamepadAssistMultiplier(v152)
							end
							v_u_16.CFrame = p138 or v_u_64()
							v_u_35 = v_u_16.CFrame
							return
						end
					else
						v156 = v_u_55()
						if v156 then
							v_u_28 = v153
							v156.setTouchSensitivity(v153)
						end
						if not v_u_29 then
							v155 = v_u_55()
							if v155 and v155.setGamepadAssistMultiplier then
								v_u_29 = v152
								v155.setGamepadAssistMultiplier(v152)
							end
							v_u_16.CFrame = p138 or v_u_64()
							v_u_35 = v_u_16.CFrame
							return
						end
					end
					v157 = v_u_29 - v152
					if math.abs(v157) <= 0.0001 then
						v_u_16.CFrame = p138 or v_u_64()
						v_u_35 = v_u_16.CFrame
					else
						v155 = v_u_55()
						if v155 and v155.setGamepadAssistMultiplier then
							v_u_29 = v152
							v155.setGamepadAssistMultiplier(v152)
						end
						v_u_16.CFrame = p138 or v_u_64()
						v_u_35 = v_u_16.CFrame
					end
				else
					v156 = v_u_55()
					if v156 then
						v_u_28 = v153
						v156.setTouchSensitivity(v153)
					end
					if not v_u_29 then
						v155 = v_u_55()
						if v155 and v155.setGamepadAssistMultiplier then
							v_u_29 = v152
							v155.setGamepadAssistMultiplier(v152)
						end
						v_u_16.CFrame = p138 or v_u_64()
						v_u_35 = v_u_16.CFrame
						return
					end
					v157 = v_u_29 - v152
					if math.abs(v157) <= 0.0001 then
						v_u_16.CFrame = p138 or v_u_64()
						v_u_35 = v_u_16.CFrame
					else
						v155 = v_u_55()
						if v155 and v155.setGamepadAssistMultiplier then
							v_u_29 = v152
							v155.setGamepadAssistMultiplier(v152)
						end
						v_u_16.CFrame = p138 or v_u_64()
						v_u_35 = v_u_16.CFrame
					end
				end
			elseif v_u_28 then
				v154 = v_u_28 - v153
				if math.abs(v154) <= 0.0001 then
					if not v_u_29 then
						v155 = v_u_55()
						if v155 and v155.setGamepadAssistMultiplier then
							v_u_29 = v152
							v155.setGamepadAssistMultiplier(v152)
						end
						v_u_16.CFrame = p138 or v_u_64()
						v_u_35 = v_u_16.CFrame
						return
					end
				else
					v156 = v_u_55()
					if v156 then
						v_u_28 = v153
						v156.setTouchSensitivity(v153)
					end
					if not v_u_29 then
						v155 = v_u_55()
						if v155 and v155.setGamepadAssistMultiplier then
							v_u_29 = v152
							v155.setGamepadAssistMultiplier(v152)
						end
						v_u_16.CFrame = p138 or v_u_64()
						v_u_35 = v_u_16.CFrame
						return
					end
				end
				v157 = v_u_29 - v152
				if math.abs(v157) <= 0.0001 then
					v_u_16.CFrame = p138 or v_u_64()
					v_u_35 = v_u_16.CFrame
				else
					v155 = v_u_55()
					if v155 and v155.setGamepadAssistMultiplier then
						v_u_29 = v152
						v155.setGamepadAssistMultiplier(v152)
					end
					v_u_16.CFrame = p138 or v_u_64()
					v_u_35 = v_u_16.CFrame
				end
			else
				v156 = v_u_55()
				if v156 then
					v_u_28 = v153
					v156.setTouchSensitivity(v153)
				end
				if not v_u_29 then
					v155 = v_u_55()
					if v155 and v155.setGamepadAssistMultiplier then
						v_u_29 = v152
						v155.setGamepadAssistMultiplier(v152)
					end
					v_u_16.CFrame = p138 or v_u_64()
					v_u_35 = v_u_16.CFrame
					return
				end
				v157 = v_u_29 - v152
				if math.abs(v157) <= 0.0001 then
					v_u_16.CFrame = p138 or v_u_64()
					v_u_35 = v_u_16.CFrame
				else
					v155 = v_u_55()
					if v155 and v155.setGamepadAssistMultiplier then
						v_u_29 = v152
						v155.setGamepadAssistMultiplier(v152)
					end
					v_u_16.CFrame = p138 or v_u_64()
					v_u_35 = v_u_16.CFrame
				end
			end
		else
			v_u_27 = v153
			v_u_3.MouseDeltaSensitivity = v153
			if v_u_28 then
				v154 = v_u_28 - v153
				if math.abs(v154) <= 0.0001 then
					if not v_u_29 then
						v155 = v_u_55()
						if v155 and v155.setGamepadAssistMultiplier then
							v_u_29 = v152
							v155.setGamepadAssistMultiplier(v152)
						end
						v_u_16.CFrame = p138 or v_u_64()
						v_u_35 = v_u_16.CFrame
						return
					end
				else
					v156 = v_u_55()
					if v156 then
						v_u_28 = v153
						v156.setTouchSensitivity(v153)
					end
					if not v_u_29 then
						v155 = v_u_55()
						if v155 and v155.setGamepadAssistMultiplier then
							v_u_29 = v152
							v155.setGamepadAssistMultiplier(v152)
						end
						v_u_16.CFrame = p138 or v_u_64()
						v_u_35 = v_u_16.CFrame
						return
					end
				end
				v157 = v_u_29 - v152
				if math.abs(v157) <= 0.0001 then
					v_u_16.CFrame = p138 or v_u_64()
					v_u_35 = v_u_16.CFrame
				else
					v155 = v_u_55()
					if v155 and v155.setGamepadAssistMultiplier then
						v_u_29 = v152
						v155.setGamepadAssistMultiplier(v152)
					end
					v_u_16.CFrame = p138 or v_u_64()
					v_u_35 = v_u_16.CFrame
				end
			else
				v156 = v_u_55()
				if v156 then
					v_u_28 = v153
					v156.setTouchSensitivity(v153)
				end
				if not v_u_29 then
					v155 = v_u_55()
					if v155 and v155.setGamepadAssistMultiplier then
						v_u_29 = v152
						v155.setGamepadAssistMultiplier(v152)
					end
					v_u_16.CFrame = p138 or v_u_64()
					v_u_35 = v_u_16.CFrame
					return
				end
				v157 = v_u_29 - v152
				if math.abs(v157) <= 0.0001 then
					v_u_16.CFrame = p138 or v_u_64()
					v_u_35 = v_u_16.CFrame
				else
					v155 = v_u_55()
					if v155 and v155.setGamepadAssistMultiplier then
						v_u_29 = v152
						v155.setGamepadAssistMultiplier(v152)
					end
					v_u_16.CFrame = p138 or v_u_64()
					v_u_35 = v_u_16.CFrame
				end
			end
		end
	end
	local v159 = nil
	goto l3
end
function v_u_1.SetAspectRatio(p160) -- name: SetAspectRatio
	-- upvalues: (ref) v_u_37, (ref) v_u_36
	v_u_37 = tonumber(p160)
	local v161 = tonumber(p160) or 1
	v_u_36 = (1 - math.clamp(v161, 0.5, 1)) / 0.5
end
function v_u_1.StateChanged(p162, p163) -- name: StateChanged
	-- upvalues: (copy) v_u_1
	if p162 == Enum.HumanoidStateType.Freefall and p163 == Enum.HumanoidStateType.Landed then
		v_u_1.OnLanded()
	end
end
function v_u_1.OnLanded(p164, p165) -- name: OnLanded
	-- upvalues: (ref) v_u_19, (ref) v_u_30, (copy) v_u_44
	if tick() - v_u_19 < 0.3 then
		return
	else
		local v166 = ((typeof(p164) ~= "number" and 12 or math.max(p164, 0)) - 2) / 10
		local v167 = math.clamp(v166, 0, 1)
		if v167 > 0 then
			if typeof(p165) == "number" then
				v167 = v167 * (math.clamp(p165, 0, 1) * -0.85 + 1)
			end
			v_u_19 = tick()
			v_u_30 = v_u_30 + 1
			local v_u_168 = v_u_30
			v_u_44:setDampingRatio(1)
			v_u_44:setFrequency(10)
			local v169 = v_u_44
			local v170 = v167 * -0.02181661564992912
			v169:setGoal((Vector3.new(v170, 0, 0)))
			task.delay(0.08, function()
				-- upvalues: (copy) v_u_168, (ref) v_u_30, (ref) v_u_44
				if v_u_168 == v_u_30 then
					v_u_44:setGoal(Vector3.new(0, 0, 0))
				end
			end)
		end
	end
end
function v_u_1.SetSprintHeld(p171) -- name: SetSprintHeld
	-- upvalues: (ref) v_u_31, (ref) v_u_32
	v_u_31 = p171
	if p171 then
		v_u_32 = true
	end
end
local function v_u_182(p172) -- name: updateSprintBob
	-- upvalues: (copy) v_u_50, (copy) v_u_8, (ref) v_u_31, (copy) v_u_7, (copy) v_u_14, (copy) v_u_9, (copy) v_u_10, (ref) v_u_33, (ref) v_u_32
	local v173 = v_u_50
	local v174
	if v_u_8.isStepping(2.5) and v_u_31 then
		local v175 = v_u_7.getPlayerCharacter(v_u_14)
		local _, _, v176, _, v177 = v_u_9.resolve(v175, nil)
		if v177 then
			local v178 = (v176 - v_u_10.TopSpeed) / (v_u_10.SprintSpeed - v_u_10.TopSpeed)
			v174 = math.clamp(v178, 0, 1)
		else
			v174 = 0
		end
	else
		v174 = 0
	end
	v173:setGoal(v174)
	v_u_50:update(p172)
	local v179 = v_u_50:getPosition()
	if v_u_31 or v179 >= 0.001 then
		local v180 = v179 * 0.004363323129985824
		local v181 = (v_u_8.getPhase() - 0.1) * 3.141592653589793
		v_u_33 = v180 * math.cos(v181)
	else
		v_u_50:reset(0)
		v_u_33 = 0
		v_u_32 = false
	end
end
function v_u_1.clampFOV(p183) -- name: clampFOV
	return math.clamp(p183, 1, 80)
end
v_u_1.getAspectRatioStretch = v69
function v_u_1.Initialize() -- name: Initialize
	-- upvalues: (ref) v_u_26, (copy) v_u_2, (copy) v_u_11, (copy) v_u_45, (copy) v_u_46, (copy) v_u_47, (copy) v_u_48, (copy) v_u_49, (copy) v_u_43, (copy) v_u_44, (ref) v_u_32, (copy) v_u_182, (ref) v_u_17, (copy) v_u_16, (copy) v_u_7, (copy) v_u_14, (ref) v_u_34, (copy) v_u_1, (copy) v_u_64, (copy) v_u_20, (ref) v_u_22, (copy) v_u_3, (copy) v_u_15, (copy) v_u_95, (ref) v_u_35, (copy) v_u_83, (copy) v_u_4, (copy) v_u_89
	if not v_u_26 then
		local function v184()
			-- upvalues: (ref) v_u_2
			return require(v_u_2.Controllers.AimAssistController)
		end
		local v185, v186 = pcall(v184)
		if v185 and v186 then
			v_u_26 = v186
		end
	end
	local v187 = v_u_26
	if v187 then
		v187.Initialize()
	end
	v_u_11.BindToStepped("CameraController.UpdateSprings", function(_, p188)
		-- upvalues: (ref) v_u_45, (ref) v_u_46, (ref) v_u_47, (ref) v_u_48, (ref) v_u_49, (ref) v_u_43, (ref) v_u_44, (ref) v_u_32, (ref) v_u_182
		v_u_45:update(p188)
		v_u_46:update(p188)
		v_u_47:update(p188)
		v_u_48:update(p188)
		v_u_49:update(p188)
		v_u_43:update(p188)
		v_u_44:update(p188)
		if v_u_32 then
			v_u_182(p188)
		end
	end)
	v_u_11.BindToRenderStep("CameraController.UpdateCamera", Enum.RenderPriority.Camera.Value + 1, function(p189)
		-- upvalues: (ref) v_u_17, (ref) v_u_16, (ref) v_u_26, (ref) v_u_7, (ref) v_u_14, (ref) v_u_34, (ref) v_u_1, (ref) v_u_64, (ref) v_u_20, (ref) v_u_22, (ref) v_u_3, (ref) v_u_15
		if v_u_17 then
			local v190 = v_u_16.CFrame
			if v_u_26 then
				local v191 = v_u_26.GetMagnetismRotation(p189)
				if v191.Magnitude > 1e-6 and (v191.X == v191.X and v191.Y == v191.Y) then
					local v192 = v191.X
					if math.abs(v192) < 3.141592653589793 then
						local v193 = v191.Y
						if math.abs(v193) < 3.141592653589793 then
							local v194 = v_u_7.getPlayerCharacter(v_u_14)
							local v195
							if v194 and v194:FindFirstChild("HumanoidRootPart") then
								v195 = v194.HumanoidRootPart.Position
							else
								v195 = v190.Position
							end
							local v196 = v191.Y
							local v197 = math.clamp(v196, -0.08726646259971647, 0.08726646259971647)
							local v198 = v191.X
							local v199 = math.clamp(v198, -0.08726646259971647, 0.08726646259971647)
							local v200 = CFrame.fromAxisAngle(v190.RightVector, v197) * CFrame.Angles(0, v199, 0)
							local v201 = v200:VectorToWorldSpace(v190.Position - v195)
							v190 = CFrame.new(v195 + v201) * (v200 * v190.Rotation)
						end
					end
				end
			end
			v_u_34 = v190
			v_u_1.updateCamera((v_u_64()))
			local v202 = next(v_u_20) ~= nil and true or v_u_22
			local v203
			if v202 then
				v203 = Enum.MouseBehavior.Default
			else
				v203 = Enum.MouseBehavior.LockCenter
			end
			if v_u_3.MouseBehavior ~= v203 then
				v_u_3.MouseBehavior = v203
			end
			if v_u_3.MouseIconEnabled ~= v202 then
				v_u_3.MouseIconEnabled = v202
			end
			local v204 = v_u_15:FindFirstChild("MainGui")
			if v204 then
				v204 = v204:FindFirstChild("CameraPerspective")
			end
			if v204 and v204.Visible ~= v202 then
				v204.Visible = v202
			end
		end
	end)
	v_u_11.BindToRenderStep("CameraController.ResetCameraShake", Enum.RenderPriority.Camera.Value - 1, function()
		-- upvalues: (ref) v_u_17, (ref) v_u_34, (ref) v_u_95, (ref) v_u_35, (ref) v_u_16
		if v_u_17 and v_u_34 then
			if v_u_95() then
				v_u_16.CFrame = v_u_34
			else
				local v205 = v_u_35
				local v206
				if v205 then
					local v207 = v_u_16.CFrame
					if (v207.Position - v205.Position).Magnitude <= 0.001 then
						v206 = (v207.LookVector - v205.LookVector).Magnitude <= 0.0001
					else
						v206 = false
					end
				else
					v206 = false
				end
				if not v206 then
					return
				end
				v_u_16.CFrame = v_u_34
			end
		end
	end)
	v_u_11.BindToRenderSteppedEvent("CameraController.AspectRatioStretch", v_u_83, (1 / 0))
	v_u_4.PreAnimation:Connect(v_u_89)
	v_u_11.BindToRenderStep("CameraController.UndoAspectRatioStretch", Enum.RenderPriority.First.Value, v_u_89)
	v_u_3.TextBoxFocused:Connect(function()
		-- upvalues: (ref) v_u_1
		v_u_1.setForceLockOverride("TextBox", true)
	end)
	v_u_3.TextBoxFocusReleased:Connect(function()
		-- upvalues: (ref) v_u_3, (ref) v_u_1
		task.defer(function()
			-- upvalues: (ref) v_u_3, (ref) v_u_1
			local v208 = v_u_3:GetFocusedTextBox() ~= nil
			v_u_1.setForceLockOverride("TextBox", v208)
		end)
	end)
	local v209 = v_u_3:GetFocusedTextBox() ~= nil
	v_u_1.setForceLockOverride("TextBox", v209)
	local v210 = v_u_14:GetAttribute("Team")
	local v211 = v210 == "Counter-Terrorists" and true or v210 == "Terrorists"
	if not (v_u_7.getPlayerCharacter(v_u_14) or v211) then
		v_u_1.setForceLockOverride("InitialMenu", true)
	end
end
function v_u_1.Start() -- name: Start
	-- upvalues: (copy) v_u_2, (ref) v_u_41, (ref) v_u_42, (copy) v_u_1, (copy) v_u_12, (copy) v_u_7, (copy) v_u_14, (copy) v_u_6, (ref) v_u_23, (ref) v_u_28, (copy) v_u_55, (ref) v_u_37, (ref) v_u_36, (ref) v_u_24
	local v_u_212 = require(v_u_2.Controllers.CaseSceneController)
	local v213 = require(v_u_2.Controllers.MenuSceneController)
	v_u_41 = {
		v213,
		{
			["IsActive"] = v213.IsTeamSelectSceneActive
		},
		v_u_212,
		require(v_u_2.Controllers.InspectController),
		require(v_u_2.Controllers.BlackMarketSceneController)
	}
	v_u_42 = require(v_u_2.Controllers.SpectateController).IsSpectatingNow
	local v_u_214 = require(v_u_2.Controllers.BlackMarketSceneController)
	local function v_u_215() -- name: resetFOV
		-- upvalues: (copy) v_u_212, (copy) v_u_214, (ref) v_u_1, (ref) v_u_12
		if not (v_u_212.IsActive() or v_u_214.IsActive()) then
			v_u_1.updateCameraFOV(v_u_12.DEFAULT_CAMERA_FOV)
		end
	end
	v_u_7.observeCharacter(v_u_14, function(p216)
		-- upvalues: (copy) v_u_212, (copy) v_u_214, (ref) v_u_1, (ref) v_u_12, (copy) v_u_215
		if p216 then
			if not (v_u_212.IsActive() or v_u_214.IsActive()) then
				v_u_1.updateCameraFOV(v_u_12.DEFAULT_CAMERA_FOV)
			end
			p216:GetAttributeChangedSignal("Dead"):Once(v_u_215)
		end
		return function() end
	end)
	v_u_6.CreateListener(v_u_14, "Settings.Keyboard/Mouse.Keyboard & Mouse Settings.Mouse Sensitivity", function(p217)
		-- upvalues: (ref) v_u_23, (ref) v_u_28, (ref) v_u_55
		v_u_23 = math.clamp(p217 or 1, 0.1, 10)
		local v218 = v_u_23
		if v_u_28 then
			local v219 = v_u_28 - v218
			if math.abs(v219) <= 0.0001 then
				return
			end
		end
		local v220 = v_u_55()
		if v220 then
			v_u_28 = v218
			v220.setTouchSensitivity(v218)
		end
	end)
	local v221 = v_u_23
	local v222
	if v_u_28 then
		local v223 = v_u_28 - v221
		if math.abs(v223) > 0.0001 then
			v222 = v_u_55()
			if v222 then
				v_u_28 = v221
				v222.setTouchSensitivity(v221)
			end
		end
	else
		v222 = v_u_55()
		if v222 then
			v_u_28 = v221
			v222.setTouchSensitivity(v221)
		end
	end
	v_u_6.CreateListener(v_u_14, "Settings.Video.Advanced.Aspect Ratio", function(p224)
		-- upvalues: (ref) v_u_37, (ref) v_u_36
		if v_u_37 ~= nil then
			local v225 = (tonumber(p224) or 1) - v_u_37
			if math.abs(v225) > 0.0001 then
				return
			end
			v_u_37 = nil
		end
		local v226 = tonumber(p224) or 1
		v_u_36 = (1 - math.clamp(v226, 0.5, 1)) / 0.5
	end)
	v_u_6.CreateListener(v_u_14, "Settings.Keyboard/Mouse.Keyboard & Mouse Settings.Zoom Sensitivity Multiplier", function(p227)
		-- upvalues: (ref) v_u_24
		v_u_24 = math.clamp(p227 or 0.5, 0.1, 5)
	end)
end
return v_u_1
-- NIGHT Analyzer | ReplicatedStorage.Controllers.CaseSceneController.ConsoleBoardAnimator
-- ModuleScript | 1378 linhas | 41535 bytes | hash ebc17646

local v_u_1 = {}
v_u_1.__index = v_u_1
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
require(v2.Database.Custom.ConsoleTypes)
local v_u_5 = require(script.Parent:WaitForChild("ConsoleBoardPlanner"))
local v_u_6 = require(script.Parent:WaitForChild("ConsoleItemRoller"))
local v_u_7 = require(v2.Controllers.RunServiceController)
local v_u_8 = require(v2.Shared.Janitor)
local v_u_9 = require(v2.Shared.Profiler)
local v_u_10 = require(v2.Database.Security.Router)
local v_u_11 = v_u_5.ROW_COUNT
local v_u_12 = TweenInfo.new(0.5, Enum.EasingStyle.Back, Enum.EasingDirection.In)
local v_u_13 = TweenInfo.new(0.28, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v_u_14 = Color3.fromRGB(65, 65, 65)
local v_u_15 = Color3.fromRGB(80, 80, 80)
local v_u_16 = TweenInfo.new(0.7, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
local v_u_17 = {
	{ 0, 0 },
	{ 0.1, 0.25 },
	{ 0.6, 1 },
	{ 1, 0 }
}
local v_u_18 = Color3.new(1, 1, 1)
local v_u_19 = TweenInfo.new(0.2)
local v_u_20 = TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v_u_21 = TweenInfo.new(0.12, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v_u_22 = TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v_u_23 = TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v_u_24 = TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v_u_25 = TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
local v_u_26 = TweenInfo.new(0.5, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v_u_27 = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local function v_u_33(p28) -- name: getGridCells
	local v29 = {}
	for _, v30 in ipairs(p28:GetChildren()) do
		if not v30:IsA("GuiObject") then
			continue
		end
		table.insert(v29, v30)
	end
	table.sort(v29, function(p31, p32)
		return p31.LayoutOrder < p32.LayoutOrder
	end)
	return v29
end
local function v_u_36(p34, p35) -- name: waitForSound
	-- upvalues: (copy) v_u_3
	while p34.State == "resolving" and (p35 and (p35.Parent and p35.IsPlaying)) do
		v_u_3.RenderStepped:Wait()
	end
	return p34.State == "resolving"
end
local function v_u_41(p_u_37, p38) -- name: playSound
	-- upvalues: (copy) v_u_10
	local v_u_39 = v_u_10.broadcastRouter("RunStoreSound", p38)
	local v40 = ("[ConsoleBoardAnimator] Store sound \"%*\" is not registered"):format(p38)
	assert(v_u_39, v40)
	p_u_37.ActiveSounds[v_u_39] = true
	p_u_37.Cleanup:Add(v_u_39, "Destroy", v_u_39)
	v_u_39.Destroying:Once(function()
		-- upvalues: (copy) p_u_37, (copy) v_u_39
		p_u_37.ActiveSounds[v_u_39] = nil
		p_u_37.Cleanup:RemoveNoClean(v_u_39)
	end)
	return v_u_39
end
local function v_u_53(p42, p43, p44, p45, p46) -- name: setLandingRows
	-- upvalues: (copy) v_u_11, (copy) v_u_18
	for v47 = 0, v_u_11 - 1 do
		local v48 = p45[v47] == true
		local v49 = p44.Arrows[v47]
		local v50 = p44.RepeatArrows[v47]
		local v51 = p42.ArrowColors[v49]
		if p42.ArrowColor then
			v51 = p42.ArrowColor
		elseif p43 < 1 and p46 ~= false then
			v51 = v_u_18
		end
		local v52 = v48 and 0.05 or 1
		v49.ImageColor3 = v51
		v49.ImageTransparency = v52
		v50.ImageColor3 = v51
		v50.ImageTransparency = v52
	end
end
local function v_u_57(p54, p55) -- name: setPatternProgress
	local v56 = p54.PatternSpan
	p54.PatternPrimary.Position = UDim2.new(v56.Scale * p55, v56.Offset * p55, 0, 0)
	p54.PatternRepeat.Position = UDim2.new(v56.Scale * (p55 - 1), v56.Offset * (p55 - 1), 0, 0)
end
function v_u_1.new(p58, p59) -- name: new
	-- upvalues: (copy) v_u_33, (copy) v_u_8, (copy) v_u_5, (copy) v_u_1, (copy) v_u_11, (copy) v_u_15
	local v60 = p58:FindFirstChild("ConsoleLaptop", true)
	local v61 = v60.Screen.SurfaceGui
	local v62 = v61.BundleMiniGame.Main
	local v63 = v62.ArrowHolder
	local v64 = v62["2"]
	local v65 = v_u_33(v62.Grids)
	local v66 = v_u_8.new()
	local v67 = {
		["Columns"] = nil,
		["Indicators"] = nil,
		["Grid"] = nil,
		["ArrowColors"] = nil,
		["Spinning"] = nil,
		["Cleanup"] = nil,
		["ActiveSounds"] = nil,
		["AliveRows"] = nil,
		["SurvivingRows"] = nil,
		["LandedRows"] = nil,
		["PlannedRows"] = nil,
		["SpinRows"] = nil,
		["PulseScaleByArrow"] = nil,
		["ScrollingCells"] = nil,
		["State"] = "idle",
		["ReelsReady"] = false,
		["SceneReady"] = false,
		["IsSkipped"] = false,
		["IsFullPath"] = false,
		["RolledItem"] = false,
		["ColumnCount"] = nil,
		["BoardParts"] = nil,
		["SideLights"] = nil,
		["Background"] = nil,
		["RollerParent"] = nil,
		["Columns"] = {},
		["Indicators"] = {},
		["Grid"] = {},
		["ArrowColors"] = {},
		["Spinning"] = {},
		["Cleanup"] = v66,
		["ActiveSounds"] = {},
		["AliveRows"] = v_u_5.createAllRows(),
		["SurvivingRows"] = {},
		["LandedRows"] = {},
		["PlannedRows"] = {},
		["SpinRows"] = {},
		["PulseScaleByArrow"] = {},
		["ScrollingCells"] = {},
		["ColumnCount"] = p59,
		["BoardParts"] = {
			[v62] = v62.Position,
			[v61.BundleMiniGame.Frame] = v61.BundleMiniGame.Frame.Position
		},
		["SideLights"] = {},
		["Background"] = {
			["Restore"] = {}
		},
		["RollerParent"] = v61.BundleMiniGame
	}
	local v68 = v_u_1
	local v69 = setmetatable(v67, v68)
	for _, v70 in { "RaritySideLightLeft", "RaritySideLightRight" } do
		local v71 = v60:FindFirstChild(v70)
		if v71 then
			v71 = v71:FindFirstChild("Light", true)
		end
		if not v71 then
			continue
		end
		local v72 = v71:FindFirstChildOfClass("UIShadow")
		local v73 = v69.SideLights
		local v74 = {
			["Frame"] = v71,
			["FrameColor"] = v71.BackgroundColor3,
			["FrameTransparency"] = v71.BackgroundTransparency,
			["Glow"] = v72
		}
		local v75
		if v72 then
			v75 = v72.Color
		else
			v75 = nil
		end
		v74.GlowColor = v75
		local v76
		if v72 then
			v76 = v72.Transparency
		else
			v76 = nil
		end
		v74.GlowTransparency = v76
		table.insert(v73, v74)
	end
	local v77 = v69.Background
	for _, v78 in v61.BundleMiniGame:GetChildren() do
		if not v78:IsA("ImageLabel") then
			continue
		end
		if v78.Name == "Pattern" then
			v77.Pattern = v78
		elseif v78.Name == "BG" and v78.Visible then
			v77.Artwork = v78
		else
			if v78.Name ~= "BG" then
				continue
			end
			v77.Tintable = v78
		end
		v77.Restore[v78] = {
			["Visible"] = v78.Visible,
			["ImageTransparency"] = v78.ImageTransparency,
			["ImageColor3"] = v78.ImageColor3
		}
	end
	for v79 = 0, p59 - 1 do
		local v80 = v79 + 1
		local v81 = v63[tostring(v80)]
		local v82 = v81.Frame
		local v83 = v66:Add(v82:Clone())
		v83.Name = "ReelRepeat"
		v83.Parent = v81
		local v84 = {}
		local v85 = {}
		for v86 = 0, v_u_11 - 1 do
			local v87 = v86 + 1
			local v88 = v82[tostring(v87)].Arrow
			local v89 = v86 + 1
			local v90 = v83[tostring(v89)].Arrow
			v84[v86] = v88
			v85[v86] = v90
			v69.ArrowColors[v88] = v88.ImageColor3
			v88.Visible = true
			v88.ImageTransparency = 1
		end
		v69.Columns[v79] = {
			["Container"] = v82,
			["RepeatContainer"] = v83,
			["Position"] = v82.Position,
			["Span"] = v82.Size.Y,
			["Arrows"] = v84,
			["RepeatArrows"] = v85
		}
		v83.Visible = false
		local v91 = v79 + 1
		local v92 = v64[tostring(v91)]
		local v93 = v92:FindFirstChildWhichIsA("ImageLabel", true)
		local v94 = v92:FindFirstChildWhichIsA("UIShadow", true)
		local v95 = v69.Indicators
		local v96 = {
			["Image"] = v93,
			["ImageColor"] = v93.ImageColor3,
			["ImageTransparency"] = v93.ImageTransparency,
			["Shadow"] = v94
		}
		local v97
		if v94 then
			v97 = v94.Transparency
		else
			v97 = nil
		end
		v96.ShadowTransparency = v97
		local v98
		if v94 then
			v98 = v94.BlurRadius
		else
			v98 = nil
		end
		v96.ShadowBlurRadius = v98
		local v99
		if v94 then
			v99 = v94.Spread
		else
			v99 = nil
		end
		v96.ShadowSpread = v99
		v95[v79] = v96
		v93.ImageColor3 = v_u_15
		if v94 then
			v94.Transparency = 1
		end
		v69.Grid[v79] = {}
		for v100 = 0, v_u_11 - 1 do
			local v101 = v65[v100 * p59 + v79 + 1]
			local v102 = v101.Pattern
			local v103 = v101.ConnectedGrid
			local v104 = v103.ArrowTemplate3.Pattern
			local v105 = v66:Add(v104:Clone())
			v105.Name = "PatternPrimary"
			v105.AnchorPoint = Vector2.zero
			v105.Position = UDim2.fromScale(0, 0)
			v105.Size = v104.TileSize
			v105.Rotation = 0
			v105.ScaleType = Enum.ScaleType.Stretch
			v105.Parent = v104
			local v106 = v66:Add(v105:Clone())
			v106.Name = "PatternRepeat"
			v106.Position = UDim2.new(-v105.Size.X.Scale, -v105.Size.X.Offset, 0, 0)
			v106.Parent = v104
			v69.Grid[v79][v100] = {
				["Frame"] = v101,
				["Pattern"] = v102,
				["Connected"] = v103,
				["PatternMask"] = v104,
				["PatternPrimary"] = v105,
				["PatternRepeat"] = v106,
				["PatternSpan"] = v105.Size.X,
				["PatternMaskTransparency"] = v104.ImageTransparency,
				["PatternMaskClips"] = v104.ClipsDescendants,
				["BackgroundTransparency"] = v101.BackgroundTransparency,
				["PatternTransparency"] = v102.ImageTransparency,
				["ConnectedColor"] = v103.GroupColor3
			}
			v104.ImageTransparency = 1
			v104.ClipsDescendants = true
		end
	end
	return v69
end
function v_u_1._tween(p_u_107, p108, p109, p110) -- name: _tween
	-- upvalues: (copy) v_u_4, (copy) v_u_19
	local v_u_111 = v_u_4:Create(p108, p110 or v_u_19, p109)
	p_u_107.Cleanup:Add(v_u_111, "Cancel", v_u_111)
	v_u_111.Completed:Once(function()
		-- upvalues: (copy) p_u_107, (copy) v_u_111
		p_u_107.Cleanup:RemoveNoClean(v_u_111)
	end)
	v_u_111:Play()
	return v_u_111
end
function v_u_1._activateIndicator(p_u_112, p113) -- name: _activateIndicator
	-- upvalues: (copy) v_u_18, (copy) v_u_20, (copy) v_u_22
	local v_u_114 = p_u_112.Indicators[p113]
	local v115 = p_u_112:_tween(v_u_114.Image, {
		["ImageColor3"] = v_u_114.ImageColor:Lerp(v_u_18, 0.35)
	}, v_u_20)
	local v_u_116 = v_u_114.Shadow
	if v_u_116 then
		local v117 = v_u_114.ShadowBlurRadius
		local v118 = v_u_114.ShadowSpread
		p_u_112:_tween(v_u_116, {
			["BlurRadius"] = nil,
			["Spread"] = nil,
			["Transparency"] = 0.05,
			["BlurRadius"] = UDim.new(v117.Scale, v117.Offset + 18),
			["Spread"] = UDim2.new(v118.X.Scale, v118.X.Offset + 8, v118.Y.Scale, v118.Y.Offset + 8)
		}, v_u_20)
	end
	v115.Completed:Once(function(p119)
		-- upvalues: (copy) p_u_112, (copy) v_u_114, (ref) v_u_22, (copy) v_u_116
		if p119 == Enum.PlaybackState.Completed and p_u_112.State == "resolving" then
			p_u_112:_tween(v_u_114.Image, {
				["ImageColor3"] = v_u_114.ImageColor
			}, v_u_22)
			if v_u_116 then
				p_u_112:_tween(v_u_116, {
					["BlurRadius"] = v_u_114.ShadowBlurRadius,
					["Spread"] = v_u_114.ShadowSpread,
					["Transparency"] = v_u_114.ShadowTransparency
				}, v_u_22)
			end
		end
	end)
end
function v_u_1._setCell(p120, p121, p122, p123, p124) -- name: _setCell
	-- upvalues: (copy) v_u_14, (copy) v_u_18
	local v125 = p120.Columns[p121].Arrows[p122]
	local v126 = p120.Grid[p121][p122]
	v125.Visible = true
	local v127 = {}
	local v128
	if p124 and not p123 then
		v128 = v_u_14
	else
		v128 = p120.ArrowColors[v125]
		if p120.ArrowColor then
			v128 = p120.ArrowColor
		elseif p121 < 1 then
			v128 = v_u_18
		end
	end
	v127.ImageColor3 = v128
	v127.ImageTransparency = p123 and 0.05 or (p124 and 0.2 or 1)
	p120:_tween(v125, v127)
	local v129 = v126.Frame
	local v130 = {}
	local v131
	if p123 then
		v131 = v126.BackgroundTransparency
	else
		local v132 = v126.BackgroundTransparency + 0.2
		v131 = math.min(1, v132)
	end
	v130.BackgroundTransparency = v131
	p120:_tween(v129, v130)
	local v133 = v126.Pattern
	local v134 = {}
	local v135
	if p123 then
		v135 = v126.PatternTransparency
	else
		local v136 = v126.PatternTransparency + 0.45
		v135 = math.min(1, v136)
	end
	v134.ImageTransparency = v135
	p120:_tween(v133, v134)
	if p123 then
		local v137 = v126.Connected
		local v138 = v126.ConnectedColor
		if p120.ArrowColor then
			v138 = p120.ArrowColor
		elseif p121 < 1 then
			v138 = v_u_18
		end
		v137.GroupColor3 = v138
	end
	p120.ScrollingCells[v126] = p123 and true or nil
	p120:_tween(v126.Connected, {
		["GroupTransparency"] = p123 and 0 or 1
	})
end
function v_u_1._greyRows(p139, p140, p141) -- name: _greyRows
	-- upvalues: (copy) v_u_14
	for v142 = 0, p140 do
		for v143 in p139.LandedRows[v142] do
			if p141 and not p141[v143] then
				continue
			end
			local v144 = p139.Grid[v142][v143]
			local v145 = {
				["ImageColor3"] = nil,
				["ImageTransparency"] = 0.2,
				["ImageColor3"] = v_u_14
			}
			p139:_tween(p139.Columns[v142].Arrows[v143], v145)
			p139.ScrollingCells[v144] = nil
			p139:_tween(v144.Connected, {
				["GroupTransparency"] = 1
			})
		end
	end
end
function v_u_1._pulseArrow(p_u_146, p147, p148, p149, p150, p_u_151) -- name: _pulseArrow
	-- upvalues: (copy) v_u_20, (copy) v_u_21
	local v_u_152 = p_u_146.PulseScaleByArrow[p147]
	if not v_u_152 then
		v_u_152 = p_u_146.Cleanup:Add(Instance.new("UIScale"))
		v_u_152.Name = "ConsoleArrowPulse"
		v_u_152.Parent = p147
		p_u_146.PulseScaleByArrow[p147] = v_u_152
	end
	if p149 then
		p_u_146:_tween(p147, {
			["ImageColor3"] = p149
		}, v_u_20)
	end
	p_u_146:_tween(v_u_152, {
		["Scale"] = p148
	}, p150 or v_u_21).Completed:Once(function(p153)
		-- upvalues: (copy) p_u_146, (ref) v_u_152, (copy) p_u_151, (ref) v_u_20
		if p153 == Enum.PlaybackState.Completed and p_u_146.State == "resolving" then
			p_u_146:_tween(v_u_152, {
				["Scale"] = 1
			}, p_u_151 or v_u_20)
		end
	end)
end
function v_u_1._pulsePaths(p_u_154, p_u_155, p_u_156) -- name: _pulsePaths
	-- upvalues: (copy) v_u_11, (copy) v_u_9, (copy) v_u_3
	if p_u_156 then
		p_u_154.ArrowColor = p_u_156
	end
	local function v_u_164(p157, p158) -- name: pulseArrow
		-- upvalues: (copy) p_u_154, (copy) p_u_155, (copy) p_u_156
		local v159 = p_u_154.Columns[p157]
		local v160 = p157 <= p_u_155 and p_u_154.AliveRows[p158]
		if v160 then
			v160 = p_u_154.LandedRows[p157][p158]
		end
		local v161
		if p_u_155 < p157 then
			v161 = v159.Arrows[p158].ImageTransparency < 1
		else
			v161 = false
		end
		if not (v160 or v161) then
			return true
		end
		p_u_154:_pulseArrow(v159.Arrows[p158], 1.18, p_u_156)
		if v160 and p_u_156 then
			local v162 = {
				["GroupColor3"] = p_u_156
			}
			p_u_154:_tween(p_u_154.Grid[p157][p158].Connected, v162)
		end
		if v161 then
			p_u_154:_pulseArrow(v159.RepeatArrows[p158], 1.18, p_u_156)
		end
		local v163 = p_u_154
		task.wait(0.015)
		return v163.State == "resolving"
	end
	local v_u_165 = v_u_11
	local function v_u_168(p166) -- name: pulsePath
		-- upvalues: (copy) v_u_164, (copy) p_u_155, (copy) p_u_154
		if not v_u_164(p_u_155, p166) then
			return false
		end
		for v167 = p_u_154.ColumnCount - 1, 0, -1 do
			if v167 == p_u_155 or v_u_164(v167, p166) then
				continue
			end
			return false
		end
		return true
	end
	for v_u_169 = 0, v_u_11 - 1 do
		v_u_9.spawn("CaseScene.ConsoleBoard.RarityPath", function()
			-- upvalues: (copy) v_u_168, (copy) v_u_169, (ref) v_u_165
			v_u_168(v_u_169)
			v_u_165 = v_u_165 - 1
		end)
	end
	while v_u_165 > 0 and p_u_154.State == "resolving" do
		v_u_3.RenderStepped:Wait()
	end
	local v170
	if p_u_154.State == "resolving" then
		task.wait(0.3)
		v170 = p_u_154.State == "resolving"
	else
		v170 = false
	end
	return v170
end
function v_u_1._startPinkTeaseMelody(p171) -- name: _startPinkTeaseMelody
	-- upvalues: (copy) v_u_41
	if not p171.TeaseMelody then
		p171.TeaseMelody = v_u_41(p171, "Console Pink Tease Melody")
	end
end
function v_u_1._stopPinkTeaseMelody(p_u_172) -- name: _stopPinkTeaseMelody
	-- upvalues: (copy) v_u_16
	local v_u_173 = p_u_172.TeaseMelody
	p_u_172.TeaseMelody = nil
	if v_u_173 and p_u_172.ActiveSounds[v_u_173] then
		p_u_172:_tween(v_u_173, {
			["PlaybackSpeed"] = 0.2,
			["Volume"] = 0
		}, v_u_16).Completed:Once(function()
			-- upvalues: (copy) p_u_172, (copy) v_u_173
			local v174 = p_u_172
			local v175 = v_u_173
			if v175 then
				if not v174.ActiveSounds[v175] then
					return
				end
				v174.ActiveSounds[v175] = nil
				v175:Stop()
				v174.Cleanup:Remove(v175)
			end
		end)
	end
end
function v_u_1._celebrateFullPath(p_u_176) -- name: _celebrateFullPath
	-- upvalues: (copy) v_u_11, (copy) v_u_3
	local v177 = os.clock()
	local function v182(p178, p179) -- name: tweenPathScale
		-- upvalues: (copy) p_u_176, (ref) v_u_11
		for v180 = 0, p_u_176.ColumnCount - 1 do
			for v181 = 0, v_u_11 - 1 do
				if not (p_u_176.AliveRows[v181] and p_u_176.LandedRows[v180][v181]) then
					continue
				end
				p_u_176:_tween(p_u_176.PulseScaleByArrow[p_u_176.Columns[v180].Arrows[v181]], {
					["Scale"] = p178
				}, p179)
			end
		end
	end
	local v183 = 0
	while v183 <= 3.43 do
		local v184 = v183 * -0.606
		local v185 = math.exp(v184) * 0.06 * p_u_176.ColumnCount * 0.8
		local v186 = TweenInfo.new(v185 * 0.45, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
		local v187 = TweenInfo.new(v185 * 0.55, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		for v188 = 0, p_u_176.ColumnCount - 1 do
			local v189 = v183 + 0.1
			while p_u_176.State == "resolving" and os.clock() - v177 < v189 do
				v_u_3.RenderStepped:Wait()
			end
			if p_u_176.State ~= "resolving" then
				return false
			end
			for v190 = 0, v_u_11 - 1 do
				if not (p_u_176.AliveRows[v190] and p_u_176.LandedRows[v188][v190]) then
					continue
				end
				p_u_176:_pulseArrow(p_u_176.Columns[v188].Arrows[v190], 1.5, nil, v186, v187)
			end
			local v191 = v183 * -0.606
			v183 = v183 + math.exp(v191) * 0.06
		end
	end
	v182(1.25, TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.Out))
	task.wait(0.08)
	if p_u_176.State ~= "resolving" then
		return false
	end
	local v192 = 4.2 - (os.clock() - v177)
	local v193 = math.max(0, v192)
	v182(1.8, TweenInfo.new(v193, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut))
	while p_u_176.State == "resolving" and os.clock() - v177 < 4.2 do
		v_u_3.RenderStepped:Wait()
	end
	if p_u_176.State ~= "resolving" then
		return false
	end
	v182(1, TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.Out))
	task.wait(0.08)
	return p_u_176.State == "resolving"
end
local function v_u_198(p194) -- name: getChasePower
	-- upvalues: (copy) v_u_17
	for v195 = 2, #v_u_17 do
		local v196 = v_u_17[v195 - 1]
		local v197 = v_u_17[v195]
		if p194 > v197[1] then
			continue
		end
		return v196[2] + (v197[2] - v196[2]) * (p194 - v196[1]) / (v197[1] - v196[1])
	end
	return 0
end
local function v_u_238(p_u_199, p_u_200, p201) -- name: createChaseSegments
	local v_u_202 = p_u_200.AbsoluteSize.X
	local v_u_203 = p_u_200.AbsoluteSize.Y
	local v204 = math.min(v_u_202, v_u_203) / 2
	local v205 = math.max(v_u_202, v_u_203) - v204 * 2
	local v_u_206 = 2 * (v_u_202 + v_u_203)
	local v207 = v_u_206 / 40
	local v_u_208 = p_u_200:Clone()
	v_u_208:ClearAllChildren()
	v_u_208.AnchorPoint = Vector2.zero
	v_u_208.Rotation = 0
	v_u_208.ImageColor3 = p201
	v_u_208.ImageTransparency = 1
	local v_u_209 = {}
	local v210 = v_u_202 / v207
	local v211 = math.round(v210)
	local v212 = math.max(1, v211)
	local v213 = v205 / v207
	local v214 = math.round(v213)
	local v215 = math.max(1, v214)
	local function v225(p216, p217, p218, p219, p220) -- name: addSegment
		-- upvalues: (copy) p_u_199, (copy) v_u_202, (copy) v_u_203, (copy) v_u_208, (copy) p_u_200, (copy) v_u_209, (copy) v_u_206
		local v221 = p_u_199.Cleanup:Add(Instance.new("Frame"))
		v221.Name = "ConsoleGoldChase"
		v221.BackgroundTransparency = 1
		v221.BorderSizePixel = 0
		v221.ClipsDescendants = true
		v221.Position = UDim2.fromScale(p216 / v_u_202, p217 / v_u_203)
		v221.Size = UDim2.fromScale((p218 - p216) / v_u_202, (p219 - p217) / v_u_203)
		local v222 = v_u_208:Clone()
		v222.Position = UDim2.fromScale(-p216 / (p218 - p216), -p217 / (p219 - p217))
		v222.Size = UDim2.fromScale(v_u_202 / (p218 - p216), v_u_203 / (p219 - p217))
		v222.Parent = v221
		v221.Parent = p_u_200
		local v223 = v_u_209
		local v224 = {
			["Image"] = v222,
			["Position"] = p220 / v_u_206
		}
		table.insert(v223, v224)
	end
	for v226 = 0, v212 - 1 do
		local v227 = v_u_202 * v226 / v212
		local v228 = v_u_202 * (v226 + 1) / v212
		v225(v227, 0, v228, v204, (v227 + v228) / 2)
	end
	for v229 = 0, v215 - 1 do
		local v230 = v204 + v205 * v229 / v215
		local v231 = v204 + v205 * (v229 + 1) / v215
		v225(v_u_202 - v204, v230, v_u_202, v231, v_u_202 + (v230 + v231) / 2)
	end
	for v232 = 0, v212 - 1 do
		local v233 = v_u_202 * (v212 - v232 - 1) / v212
		local v234 = v_u_202 * (v212 - v232) / v212
		v225(v233, v_u_203 - v204, v234, v_u_203, v_u_202 + v_u_203 + v_u_202 - (v233 + v234) / 2)
	end
	for v235 = 0, v215 - 1 do
		local v236 = v204 + v205 * (v215 - v235 - 1) / v215
		local v237 = v204 + v205 * (v215 - v235) / v215
		v225(0, v236, v204, v237, 2 * v_u_202 + v_u_203 + v_u_203 - (v236 + v237) / 2)
	end
	v_u_208:Destroy()
	return v_u_209
end
function v_u_1._chaseIndicatorsGold(p239) -- name: _chaseIndicatorsGold
	-- upvalues: (copy) v_u_238, (copy) v_u_7, (copy) v_u_198
	local v240, v241, v242 = p239.Indicators[p239.ColumnCount - 1].ImageColor:ToHSV()
	local v_u_243 = {}
	for _, v244 in p239.Indicators do
		local v245 = v244.Image.AbsoluteSize
		if not v244.Image.Visible or (v245.X <= 0 or v245.Y <= 0) then
			continue
		end
		local v246 = Color3.fromHSV(v240 * (1 + (math.random() * 2 - 1) * 0.1), v241 * (1 - math.random() * 0.1), v242 * (1 - math.random() * 0.1))
		v244.Image.ImageTransparency = 1
		local v247 = {
			["Offset"] = math.random(),
			["Segments"] = v_u_238(p239, v244.Image, v246)
		}
		table.insert(v_u_243, v247)
	end
	local v_u_248 = os.clock()
	p239.Cleanup:Add(v_u_7.BindToRenderStep(v_u_7.CreateBindingName("CaseScene.ConsoleBoard.GoldChase"), function()
		-- upvalues: (copy) v_u_248, (copy) v_u_243, (ref) v_u_198
		local v249 = (os.clock() - v_u_248) / 2.1
		for _, v250 in v_u_243 do
			for _, v251 in v250.Segments do
				local v252 = (v251.Position - v249 + v250.Offset) % 1
				v251.Image.ImageTransparency = 1 - v_u_198(v252)
			end
		end
	end), "Disconnect", "GoldChase")
end
function v_u_1._stopColumn(p253, p254) -- name: _stopColumn
	local v255 = p253.Spinning[p254]
	if v255 then
		v255 = v255.Sound
	end
	if v255 and p253.ActiveSounds[v255] then
		p253.ActiveSounds[v255] = nil
		v255:Stop()
		p253.Cleanup:Remove(v255)
	end
	p253.Spinning[p254] = nil
	local v256 = p253.Columns[p254]
	v256.Container.Position = v256.Position
	v256.RepeatContainer.Position = UDim2.new(v256.Position.X.Scale, v256.Position.X.Offset, v256.Position.Y.Scale + v256.Span.Scale * -1, v256.Position.Y.Offset + v256.Span.Offset * -1)
	v256.RepeatContainer.Visible = false
end
function v_u_1._revealRemainingColumns(p257, p258) -- name: _revealRemainingColumns
	-- upvalues: (copy) v_u_53, (copy) v_u_13, (copy) v_u_11
	for v259 = p258 + 1, p257.ColumnCount - 1 do
		local v260 = p257.Spinning[v259]
		if v260 then
			v260 = v260.Sound
		end
		if v260 and p257.ActiveSounds[v260] then
			p257.ActiveSounds[v260] = nil
			v260:Stop()
			p257.Cleanup:Remove(v260)
		end
		p257.Spinning[v259] = nil
		local v261 = p257.Columns[v259]
		local v262 = p257.PlannedRows[v259] or p257.SpinRows[v259]
		p257.LandedRows[v259] = v262
		v261.RepeatContainer.Visible = false
		v_u_53(p257, v259, v261, v262)
		v261.Container.Position = UDim2.new(v261.Position.X.Scale, v261.Position.X.Offset, v261.Position.Y.Scale + v261.Span.Scale * -0.18, v261.Position.Y.Offset + v261.Span.Offset * -0.18)
		p257:_tween(v261.Container, {
			["Position"] = v261.Position
		}, v_u_13)
		for v263 = 0, v_u_11 - 1 do
			p257:_setCell(v259, v263, false, v262[v263] == true)
		end
		task.wait(0.11)
		if p257.State == "resolving" then
			break
		end
		return false
	end
	local v264 = v_u_13.Time
	task.wait(v264)
	return p257.State == "resolving"
end
function v_u_1._landColumn(p265, p266) -- name: _landColumn
	-- upvalues: (copy) v_u_53, (copy) v_u_3, (copy) v_u_41
	local v267 = p266.columnIndex
	local v268 = p265.Spinning[v267]
	local v269 = (os.clock() - v268.StartedAt) % 0.21
	if v269 > 0.01 then
		local v270 = 0.21 - v269
		task.wait(v270)
		if p265.State ~= "resolving" then
			return false, {}
		end
	end
	p265.Spinning[v267] = nil
	local v271 = p265.PlannedRows[v267]
	local v272 = p265.Columns[v267]
	local v273 = os.clock()
	local v274 = false
	while p265.State == "resolving" do
		local v275 = (os.clock() - v273) / 1.5
		local v276 = math.min(v275, 1)
		local v277 = (1 - (1 - v276) ^ 2) * 3
		if not v274 and v277 >= 2 then
			v_u_53(p265, v267, v272, v271, false)
			v274 = true
		end
		if v276 == 1 then
			v272.Container.Position = UDim2.new(v272.Position.X.Scale, v272.Position.X.Offset, v272.Position.Y.Scale + v272.Span.Scale * 0, v272.Position.Y.Offset + v272.Span.Offset * 0)
			v272.RepeatContainer.Position = UDim2.new(v272.Position.X.Scale, v272.Position.X.Offset, v272.Position.Y.Scale + v272.Span.Scale * -1, v272.Position.Y.Offset + v272.Span.Offset * -1)
			break
		end
		local v278 = v268.Sound
		local v279 = v268.Sound.PlaybackSpeed
		local v280 = 1 - v276
		local v281 = math.max(0.1, v280)
		v278.PlaybackSpeed = math.min(v279, v281)
		local v282 = v277 % 1
		v272.Container.Position = UDim2.new(v272.Position.X.Scale, v272.Position.X.Offset, v272.Position.Y.Scale + v272.Span.Scale * v282, v272.Position.Y.Offset + v272.Span.Offset * v282)
		local v283 = v272.RepeatContainer
		local v284 = v282 - 1
		v283.Position = UDim2.new(v272.Position.X.Scale, v272.Position.X.Offset, v272.Position.Y.Scale + v272.Span.Scale * v284, v272.Position.Y.Offset + v272.Span.Offset * v284)
		v_u_3.RenderStepped:Wait()
	end
	local v285 = v268.Sound
	if v285 and p265.ActiveSounds[v285] then
		p265.ActiveSounds[v285] = nil
		v285:Stop()
		p265.Cleanup:Remove(v285)
	end
	if p265.State == "resolving" then
		v_u_53(p265, v267, v272, v271)
		p265:_stopColumn(v267)
		local v286
		if p265.ColumnCount == 10 then
			v286 = ("Console 10-Column Connect %*"):format(v267 + 1)
		else
			v286 = ("Console Connect %*"):format(v267 + 1)
		end
		p265.LastResolutionSound = v_u_41(p265, p266.result == "miss" and "Console Fail" or v286)
		if p266.result == "hit" then
			p265:_activateIndicator(v267)
		end
		v_u_3.RenderStepped:Wait()
		if p265.State == "resolving" then
			return true, v271
		else
			return false, {}
		end
	else
		return false, {}
	end
end
function v_u_1._spinColumn(p287, p288, p289) -- name: _spinColumn
	-- upvalues: (copy) v_u_41, (copy) v_u_11
	local v290 = v_u_41(p287, "Console Reel Spin")
	p287.Spinning[p288] = {
		["StartedAt"] = os.clock(),
		["Sound"] = v290
	}
	local v291 = p287.Columns[p288]
	v291.RepeatContainer.Visible = true
	v291.Container.Position = v291.Position
	v291.RepeatContainer.Position = UDim2.new(v291.Position.X.Scale, v291.Position.X.Offset, v291.Position.Y.Scale + v291.Span.Scale * -1, v291.Position.Y.Offset + v291.Span.Offset * -1)
	local v292 = v291.Arrows
	for v293 = 0, v_u_11 - 1 do
		local v294 = p289[v293] == true
		local v295 = v292[v293]
		v295.Visible = true
		v295.ImageTransparency = v294 and 0 or 1
	end
	local v296 = v291.RepeatArrows
	for v297 = 0, v_u_11 - 1 do
		local v298 = p289[v297] == true
		local v299 = v296[v297]
		v299.Visible = true
		v299.ImageTransparency = v298 and 0 or 1
	end
end
function v_u_1._stopSpin(p300) -- name: _stopSpin
	if p300.RenderConnection then
		p300.Cleanup:Remove("RenderConnection")
		p300.RenderConnection = nil
	end
	local v301 = p300.ActiveSounds
	p300.ActiveSounds = {}
	for v302 in v301 do
		v302:Stop()
		p300.Cleanup:Remove(v302)
	end
	p300.TeaseMelody = nil
	table.clear(p300.Spinning)
	for _, v303 in p300.Columns do
		v303.Container.Position = v303.Position
		v303.RepeatContainer.Position = UDim2.new(v303.Position.X.Scale, v303.Position.X.Offset, v303.Position.Y.Scale + v303.Span.Scale * -1, v303.Position.Y.Offset + v303.Span.Offset * -1)
		v303.RepeatContainer.Visible = false
	end
end
function v_u_1._prepareReels(p304, p305) -- name: _prepareReels
	-- upvalues: (copy) v_u_5
	local v306 = v_u_5.prepare(p304.SpinRows, p304.AliveRows, p305, p304.ColumnCount)
	p304.SpinRows = v306.SpinRows
	p304.SurvivingRows = v306.SurvivingRows
	p304.PlannedRows = v306.PlannedRows
end
function v_u_1._applyStep(p307, p308, p309) -- name: _applyStep
	-- upvalues: (copy) v_u_11
	local v310 = p307.SurvivingRows[p308.columnIndex]
	local v311 = {}
	for v312 in p307.AliveRows do
		if v310[v312] then
			continue
		end
		v311[v312] = true
	end
	p307.LandedRows[p308.columnIndex] = p309
	for v313 = 0, v_u_11 - 1 do
		p307:_setCell(p308.columnIndex, v313, v310[v313] == true, p309[v313] == true)
	end
	if p308.result ~= "miss" then
		p307:_greyRows(p308.columnIndex - 1, v311)
	end
	p307.AliveRows = v310
end
function v_u_1._finish(p314) -- name: _finish
	-- upvalues: (copy) v_u_9
	p314.State = "completed"
	p314:_stopSpin()
	local v315 = p314.OnComplete
	p314.OnComplete = nil
	v_u_9.defer("CaseScene.ConsoleBoard.Complete", v315, p314.RolledItem)
end
function v_u_1._resolveStep(p_u_316, p_u_317) -- name: _resolveStep
	-- upvalues: (copy) v_u_9
	local v318, v319 = p_u_316:_landColumn(p_u_317)
	if not v318 then
		return "cancelled"
	end
	p_u_316:_applyStep(p_u_317, v319)
	if p_u_317.result == "miss" then
		p_u_316:_stopPinkTeaseMelody()
		return p_u_316:_revealRemainingColumns(p_u_317.columnIndex) and "miss" or "cancelled"
	end
	if p_u_317.kind ~= "rarity" then
		v_u_9.spawn("CaseScene.ConsoleBoard.BridgePulse", function()
			-- upvalues: (copy) p_u_316, (copy) p_u_317
			p_u_316:_pulsePaths(p_u_317.columnIndex)
		end)
		return "continue"
	end
	if p_u_317.columnIndex == p_u_316.ColumnCount - 1 then
		p_u_316:_stopPinkTeaseMelody()
		if p_u_317.rarity == "Special" then
			p_u_316:_chaseIndicatorsGold()
		end
	end
	p_u_316:_setRarityAmbience(p_u_316.Indicators[p_u_317.columnIndex].ImageColor)
	if not p_u_316:_pulsePaths(p_u_317.columnIndex, p_u_316.Indicators[p_u_317.columnIndex].ImageColor) then
		return "cancelled"
	end
	if p_u_317.columnIndex == p_u_316.ColumnCount - 3 then
		p_u_316:_startPinkTeaseMelody()
	end
	return "continue"
end
function v_u_1._getFinalHoldDuration(p320, p321) -- name: _getFinalHoldDuration
	return p321.result == "miss" and 1.2 or ((p320.FinalRarity == "Red" or p320.FinalRarity == "Special") and 2 or 0.8)
end
function v_u_1._runResolution(p322, p323) -- name: _runResolution
	-- upvalues: (copy) v_u_36
	task.wait(0.63)
	if p322.State == "resolving" then
		for _, v324 in p323 do
			local v325 = p322:_resolveStep(v324)
			if v325 == "cancelled" then
				return
			end
			if v325 ~= "miss" then
				continue
			end
		end
		if p322.IsFullPath and not p322:_celebrateFullPath() then
			return
		else
			local v326 = p323[#p323]
			local v327 = p322.RollerPlan
			if v327 then
				local v328 = v326.result == "miss" and 0.35 or p322:_getFinalHoldDuration(v326)
				task.wait(v328)
				local v329 = p322.State == "resolving"
				if v329 then
					v329 = p322:_playItemRoller(v327)
				end
				p322.RolledItem = v329
				if p322.RolledItem then
					task.wait(1.4)
					if p322.State == "resolving" then
						p322:_finish()
					end
				end
				return
			else
				local v330 = p322:_getFinalHoldDuration(v326)
				task.wait(v330)
				if p322.State == "resolving" then
					if v_u_36(p322, p322.LastResolutionSound) then
						p322:_finish()
					end
				end
			end
		end
	else
		return
	end
end
function v_u_1._setRarityAmbience(p331, p332) -- name: _setRarityAmbience
	-- upvalues: (copy) v_u_23, (copy) v_u_24
	for _, v333 in p331.SideLights do
		p331:_tween(v333.Frame, {
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0,
			["BackgroundColor3"] = p332
		}, v_u_23)
		local v334 = v333.Glow
		if not v334 then
			continue
		end
		p331:_tween(v334, {
			["Color"] = nil,
			["Transparency"] = 0.3,
			["Color"] = p332
		}, v_u_23)
	end
	local v335 = p331.Background
	if v335.Pattern then
		p331:_tween(v335.Pattern, {
			["ImageColor3"] = p332
		}, v_u_24)
	end
	local v336 = v335.Tintable
	if v336 then
		if v336.Visible then
			p331:_tween(v336, {
				["ImageColor3"] = p332
			}, v_u_24)
		else
			v336.ImageColor3 = p332
			v336.ImageTransparency = 1
			v336.Visible = true
			p331:_tween(v336, {
				["ImageTransparency"] = v335.Restore[v336].ImageTransparency
			}, v_u_24)
			if v335.Artwork then
				p331:_tween(v335.Artwork, {
					["ImageTransparency"] = 1
				}, v_u_24)
			end
		end
	else
		return
	end
end
function v_u_1._playItemRoller(p_u_337, p338) -- name: _playItemRoller
	-- upvalues: (copy) v_u_12, (copy) v_u_6
	for v339, v340 in p_u_337.BoardParts do
		p_u_337:_tween(v339, {
			["Position"] = v340 + UDim2.fromScale(0, 1.2)
		}, v_u_12)
	end
	local v341 = v_u_12.Time
	task.wait(v341)
	if p_u_337.State == "resolving" then
		return v_u_6.play(p_u_337.RollerParent, p338, p_u_337.Cleanup, function()
			-- upvalues: (copy) p_u_337
			return p_u_337.State == "resolving"
		end)
	else
		return false
	end
end
function v_u_1._tryResolve(p_u_342) -- name: _tryResolve
	-- upvalues: (copy) v_u_11, (copy) v_u_9
	if p_u_342.State == "spinning" and (p_u_342.ReelsReady and (p_u_342.SceneReady and (p_u_342.Steps and p_u_342.OnComplete))) then
		p_u_342.State = "resolving"
		if p_u_342.IsSkipped then
			p_u_342:_finish()
		else
			local v_u_343 = p_u_342.Steps
			p_u_342:_prepareReels(v_u_343)
			for v344 = 0, p_u_342.ColumnCount - 1 do
				local v345 = p_u_342.Columns[v344]
				local v346 = p_u_342.SpinRows[v344]
				local v347 = v345.Arrows
				for v348 = 0, v_u_11 - 1 do
					local v349 = v346[v348] == true
					local v350 = v347[v348]
					v350.Visible = true
					v350.ImageTransparency = v349 and 0 or 1
				end
				local v351 = v345.RepeatArrows
				for v352 = 0, v_u_11 - 1 do
					local v353 = v346[v352] == true
					local v354 = v351[v352]
					v354.Visible = true
					v354.ImageTransparency = v353 and 0 or 1
				end
			end
			v_u_9.spawn("CaseScene.ConsoleBoard.Resolve", function()
				-- upvalues: (copy) p_u_342, (copy) v_u_343
				p_u_342:_runResolution(v_u_343)
			end)
		end
	else
		return
	end
end
function v_u_1.Start(p_u_355) -- name: Start
	-- upvalues: (copy) v_u_5, (copy) v_u_11, (copy) v_u_7, (copy) v_u_57, (copy) v_u_9
	p_u_355.State = "spinning"
	p_u_355.SpinRows = v_u_5.createInitialSpinRows(p_u_355.ColumnCount)
	for v356 = 0, p_u_355.ColumnCount - 1 do
		local v357 = p_u_355.Columns[v356]
		local v358 = p_u_355.SpinRows[v356]
		local v359 = v357.Arrows
		for v360 = 0, v_u_11 - 1 do
			local v361 = v358[v360] == true
			local v362 = v359[v360]
			v362.Visible = true
			v362.ImageTransparency = v361 and 0 or 1
		end
		local v363 = v357.RepeatArrows
		for v364 = 0, v_u_11 - 1 do
			local v365 = v358[v364] == true
			local v366 = v363[v364]
			v366.Visible = true
			v366.ImageTransparency = v365 and 0 or 1
		end
	end
	p_u_355.RenderConnection = p_u_355.Cleanup:Add(v_u_7.BindToRenderStep(v_u_7.CreateBindingName("CaseScene.ConsoleBoard.Render"), function()
		-- upvalues: (copy) p_u_355, (ref) v_u_57
		for v367, v368 in p_u_355.Spinning do
			local v369 = p_u_355.Columns[v367]
			local v370 = (os.clock() - v368.StartedAt) / 0.21 % 1
			v369.Container.Position = UDim2.new(v369.Position.X.Scale, v369.Position.X.Offset, v369.Position.Y.Scale + v369.Span.Scale * v370, v369.Position.Y.Offset + v369.Span.Offset * v370)
			local v371 = v369.RepeatContainer
			local v372 = v370 - 1
			v371.Position = UDim2.new(v369.Position.X.Scale, v369.Position.X.Offset, v369.Position.Y.Scale + v369.Span.Scale * v372, v369.Position.Y.Offset + v369.Span.Offset * v372)
		end
		local v373 = os.clock() / 2.285714285714286 % 1
		for v374 in p_u_355.ScrollingCells do
			v_u_57(v374, v373)
		end
	end), "Disconnect", "RenderConnection")
	v_u_9.spawn("CaseScene.ConsoleBoard.StartCascade", function()
		-- upvalues: (copy) p_u_355
		task.wait(1)
		for v375 = 0, p_u_355.ColumnCount - 1 do
			if p_u_355.State ~= "spinning" or p_u_355.IsSkipped then
				return
			end
			p_u_355:_spinColumn(v375, p_u_355.SpinRows[v375])
			if v375 >= p_u_355.ColumnCount - 1 then
				continue
			end
			task.wait(0.12)
		end
		p_u_355.ReelsReady = true
		p_u_355:_tryResolve()
	end)
end
function v_u_1.SetSceneReady(p376) -- name: SetSceneReady
	p376.SceneReady = true
	p376:_tryResolve()
end
function v_u_1.Resolve(p377, p378, p379, p380, p381) -- name: Resolve
	-- upvalues: (copy) v_u_5
	p377.IsFullPath = p378.finalColumnIndex == p377.ColumnCount - 1
	p377.RollerPlan = p380
	p377.FinalRarity = p378.finalRarity or p381
	p377.Steps = v_u_5.getDisplaySteps(p378)
	p377.OnComplete = p379
	p377:_tryResolve()
end
function v_u_1.Skip(p382) -- name: Skip
	p382.IsSkipped = true
	p382.ReelsReady = true
	p382:_stopSpin()
	if p382.State == "resolving" then
		p382:_finish()
	else
		p382:_tryResolve()
	end
end
function v_u_1.PlayReset(p_u_383) -- name: PlayReset
	-- upvalues: (copy) v_u_25, (copy) v_u_11, (copy) v_u_15, (copy) v_u_27, (copy) v_u_26
	if p_u_383.State == "completed" then
		p_u_383.Cleanup:Remove("GoldChase")
		local v384 = p_u_383.Background
		for v385, v386 in v384.Restore do
			if v385 == v384.Tintable and not v386.Visible then
				p_u_383:_tween(v385, {
					["ImageTransparency"] = 1
				}, v_u_25)
			else
				p_u_383:_tween(v385, {
					["ImageTransparency"] = v386.ImageTransparency,
					["ImageColor3"] = v386.ImageColor3
				}, v_u_25)
			end
		end
		for _, v387 in p_u_383.SideLights do
			p_u_383:_tween(v387.Frame, {
				["BackgroundColor3"] = v387.FrameColor,
				["BackgroundTransparency"] = v387.FrameTransparency
			}, v_u_25)
			if not v387.Glow then
				continue
			end
			p_u_383:_tween(v387.Glow, {
				["Color"] = v387.GlowColor,
				["Transparency"] = v387.GlowTransparency
			}, v_u_25)
		end
		local v_u_388 = false
		for v389, v390 in p_u_383.BoardParts do
			if v389.Position == v390 then
				continue
			end
			v_u_388 = true
		end
		local function v398(p391, p392) -- name: ease
			-- upvalues: (ref) v_u_388, (copy) p_u_383, (ref) v_u_25
			local v393 = nil
			for v394, v395 in p392 do
				if p391[v394] == v395 then
					continue
				end
				v393 = v393 or {}
				v393[v394] = v395
			end
			if v393 then
				if v_u_388 then
					for v396, v397 in v393 do
						p391[v396] = v397
					end
				else
					p_u_383:_tween(p391, v393, v_u_25)
				end
			else
				return
			end
		end
		table.clear(p_u_383.ScrollingCells)
		for v399, v400 in p_u_383.Columns do
			for v401 = 0, v_u_11 - 1 do
				local v402 = v400.Arrows[v401]
				v398(v402, {
					["ImageTransparency"] = 1
				})
				v398(v400.RepeatArrows[v401], {
					["ImageTransparency"] = 1
				})
				local v403 = p_u_383.PulseScaleByArrow[v402]
				if v403 then
					v398(v403, {
						["Scale"] = 1
					})
				end
				local v404 = p_u_383.Grid[v399][v401]
				v398(v404.Frame, {
					["BackgroundTransparency"] = v404.BackgroundTransparency
				})
				v398(v404.Pattern, {
					["ImageTransparency"] = v404.PatternTransparency
				})
				v398(v404.Connected, {
					["GroupTransparency"] = 1
				})
			end
		end
		for _, v405 in p_u_383.Indicators do
			v398(v405.Image, {
				["ImageColor3"] = v_u_15,
				["ImageTransparency"] = v405.ImageTransparency
			})
			if v405.Shadow then
				v398(v405.Shadow, {
					["Transparency"] = 1
				})
			end
			for _, v406 in v405.Image:GetChildren() do
				local v407
				if v406.Name == "ConsoleGoldChase" then
					v407 = v406:FindFirstChildOfClass("ImageLabel")
				else
					v407 = false
				end
				if not v407 then
					continue
				end
				v398(v407, {
					["ImageTransparency"] = 1
				})
			end
		end
		if v_u_388 then
			local v408 = p_u_383.RollerParent:FindFirstChild("ConsoleItemRoller")
			if v408 then
				for _, v409 in v408:GetDescendants() do
					if not v409:IsA("ImageLabel") or v409.ImageTransparency >= 1 then
						continue
					end
					p_u_383:_tween(v409, {
						["ImageTransparency"] = 1
					}, v_u_27)
				end
				local v410 = v_u_27.Time
				task.wait(v410)
				if p_u_383.State ~= "completed" then
					return
				end
			end
			for v411, v412 in p_u_383.BoardParts do
				p_u_383:_tween(v411, {
					["Position"] = v412
				}, v_u_26)
			end
			local v413 = v_u_26.Time
			task.wait(v413)
			local _ = p_u_383.State == "completed"
		else
			local v414 = v_u_25.Time
			task.wait(v414)
			local _ = p_u_383.State == "completed"
		end
	else
		return
	end
end
function v_u_1.Cancel(p415) -- name: Cancel
	p415.State = "cancelled"
	p415.OnComplete = nil
	p415:_stopSpin()
	p415.Cleanup:Cleanup()
	for v416, v417 in p415.ArrowColors do
		v416.Visible = true
		v416.ImageColor3 = v417
		v416.ImageTransparency = 1
	end
	for _, v418 in p415.Grid do
		for _, v419 in v418 do
			v419.Frame.BackgroundTransparency = v419.BackgroundTransparency
			v419.Pattern.ImageTransparency = v419.PatternTransparency
			v419.Connected.GroupTransparency = 1
			v419.Connected.GroupColor3 = v419.ConnectedColor
			v419.PatternMask.ImageTransparency = v419.PatternMaskTransparency
			v419.PatternMask.ClipsDescendants = v419.PatternMaskClips
		end
	end
	table.clear(p415.ScrollingCells)
	for v420, v421 in p415.BoardParts do
		v420.Position = v421
	end
	for v422, v423 in p415.Background.Restore do
		v422.Visible = v423.Visible
		v422.ImageTransparency = v423.ImageTransparency
		v422.ImageColor3 = v423.ImageColor3
	end
	for _, v424 in p415.SideLights do
		v424.Frame.BackgroundColor3 = v424.FrameColor
		v424.Frame.BackgroundTransparency = v424.FrameTransparency
		if not v424.Glow then
			continue
		end
		v424.Glow.Color = v424.GlowColor
		v424.Glow.Transparency = v424.GlowTransparency
	end
	for _, v425 in p415.Indicators do
		v425.Image.ImageColor3 = v425.ImageColor
		v425.Image.ImageTransparency = v425.ImageTransparency
		local v426 = v425.Shadow
		if not v426 then
			continue
		end
		v426.Transparency = v425.ShadowTransparency
		v426.BlurRadius = v425.ShadowBlurRadius
		v426.Spread = v425.ShadowSpread
	end
end
return v_u_1
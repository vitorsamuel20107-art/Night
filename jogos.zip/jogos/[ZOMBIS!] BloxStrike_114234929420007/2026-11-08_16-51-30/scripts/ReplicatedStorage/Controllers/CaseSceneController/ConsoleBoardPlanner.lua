-- NIGHT Analyzer | ReplicatedStorage.Controllers.CaseSceneController.ConsoleBoardPlanner
-- ModuleScript | 419 linhas | 6251 bytes | hash 9fabdd1d

local v1 = game:GetService("ReplicatedStorage")
require(v1.Database.Custom.ConsoleTypes)
local v2 = {
	["ROW_COUNT"] = 5
}
local v_u_3 = {
	["Blue"] = 1,
	["Purple"] = 2,
	["Pink"] = 3,
	["Red"] = 4,
	["Special"] = 5
}
local v_u_4 = {
	[8] = {
		["ArrowCountOptions"] = {
			{ 5 },
			{
				3,
				4,
				4,
				4
			},
			{ 3, 4 },
			{
				3,
				3,
				3,
				4
			},
			{ 3 },
			{
				2,
				2,
				3,
				3,
				3
			},
			{ 2 },
			{ 1 }
		},
		["MinimumArrowCounts"] = {
			5,
			3,
			3,
			3,
			3,
			2,
			2,
			1
		},
		["SurvivingRowOptions"] = {
			{ 5 },
			{ 4 },
			{
				2,
				2,
				2,
				3,
				3
			},
			{
				2,
				2,
				2,
				2,
				3
			},
			{
				2,
				2,
				2,
				2,
				3
			},
			{
				1,
				2,
				2,
				2,
				2
			},
			{
				1,
				1,
				2,
				2,
				2
			},
			{ 1 }
		},
		["MinimumSurvivingRowsBeforeMiss"] = {
			5,
			4,
			2,
			2,
			2,
			2,
			1,
			1
		}
	},
	[10] = {
		["ArrowCountOptions"] = {
			{ 5 },
			{
				3,
				4,
				4,
				4
			},
			{ 3, 4 },
			{ 3, 4 },
			{
				3,
				3,
				3,
				4
			},
			{ 3 },
			{
				2,
				2,
				3,
				3,
				3
			},
			{ 2 },
			{ 1, 2 },
			{ 1 }
		},
		["MinimumArrowCounts"] = {
			5,
			3,
			3,
			3,
			3,
			3,
			2,
			2,
			1,
			1
		},
		["SurvivingRowOptions"] = {
			{ 5 },
			{ 4 },
			{
				2,
				2,
				2,
				3,
				3
			},
			{
				2,
				2,
				2,
				2,
				3
			},
			{
				2,
				2,
				2,
				2,
				3
			},
			{
				2,
				2,
				2,
				2,
				3
			},
			{
				1,
				2,
				2,
				2,
				2
			},
			{
				1,
				1,
				2,
				2,
				2
			},
			{
				1,
				1,
				1,
				2
			},
			{ 1 }
		},
		["MinimumSurvivingRowsBeforeMiss"] = {
			5,
			4,
			2,
			2,
			2,
			2,
			2,
			1,
			1,
			1
		}
	}
}
local function v_u_11(p5, p6) -- name: randomSubset
	local v7 = {}
	for v8 in p5 do
		table.insert(v7, v8)
	end
	local v9 = {}
	for _ = 1, p6 do
		local v10 = math.random(1, #v7)
		v9[table.remove(v7, v10)] = true
	end
	return v9
end
local function v_u_22(p12, p13, p14) -- name: landingRows
	local v15 = table.clone(p13)
	local v16 = {}
	if not p12[0] then
		table.insert(v16, 0)
	end
	if not p12[1] then
		table.insert(v16, 1)
	end
	if not p12[2] then
		table.insert(v16, 2)
	end
	if not p12[3] then
		table.insert(v16, 3)
	end
	if not p12[4] then
		table.insert(v16, 4)
	end
	local v17 = 0
	for _ in p13 do
		v17 = v17 + 1
	end
	local v18 = p14 - v17
	local v19 = math.max(v18, 0)
	local v20 = #v16
	for _ = 1, math.min(v19, v20) do
		local v21 = math.random(1, #v16)
		v15[table.remove(v16, v21)] = true
	end
	return v15
end
local function v_u_27(p23, p24) -- name: cloneRowsByColumn
	local v25 = {}
	for v26 = 0, p24 - 1 do
		v25[v26] = table.clone(p23[v26])
	end
	return v25
end
local function v_u_42(p28, p29, p30, p31, p32, p33) -- name: fitUpcomingMiss
	-- upvalues: (copy) v_u_11
	local v34 = 0
	for _ in p29[p31] do
		v34 = v34 + 1
	end
	local v35 = p28.MinimumArrowCounts[p30 + 1] - (5 - p32)
	local v36 = p28.MinimumSurvivingRowsBeforeMiss[p30 + 1]
	local v37 = math.max(v36, v35)
	local v38 = 5 - math.min(p32, v37)
	if v38 < v34 then
		p29[p31] = v_u_11({
			[0] = true,
			[1] = true,
			[2] = true,
			[3] = true,
			[4] = true
		}, v38)
	else
		v38 = v34
	end
	local v39 = 5 - v38
	local v40 = math.min(p32, p33, v39)
	local v41 = 5 - p32 + v40
	return math.min(p33, v41), v40
end
function v2.createAllRows() -- name: createAllRows
	return {
		[0] = true,
		[1] = true,
		[2] = true,
		[3] = true,
		[4] = true
	}
end
function v2.createInitialSpinRows(p43) -- name: createInitialSpinRows
	-- upvalues: (copy) v_u_4, (copy) v_u_11
	local v44 = v_u_4[p43]
	local v45 = ("[ConsoleBoardPlanner] No layout for %* columns"):format(p43)
	local v46 = assert(v44, v45)
	local v47 = {
		[0] = true,
		[1] = true,
		[2] = true,
		[3] = true,
		[4] = true
	}
	local v48 = {}
	for v49 = 0, p43 - 1 do
		local v50 = v_u_11
		local v51 = v46.ArrowCountOptions[v49 + 1]
		v48[v49] = v50(v47, v51[math.random(1, #v51)])
	end
	return v48
end
function v2.prepare(p52, p53, p54, p55) -- name: prepare
	-- upvalues: (copy) v_u_4, (copy) v_u_27, (copy) v_u_42, (copy) v_u_11, (copy) v_u_22
	local v56 = v_u_4[p55]
	local v57 = ("[ConsoleBoardPlanner] No layout for %* columns"):format(p55)
	local v58 = assert(v56, v57)
	local v59 = v_u_27(p52, p55)
	local v60 = table.clone(p53)
	local v61 = {}
	local v62 = {}
	for v63, v64 in p54 do
		local v65 = v64.columnIndex
		local v66 = 0
		for _ in v60 do
			v66 = v66 + 1
		end
		local v67 = 0
		for _ in v59[v65] do
			v67 = v67 + 1
		end
		local v68 = 0
		if v64.result == "hit" then
			local v69 = p54[v63 + 1]
			local v70 = math.min(v66, v67)
			if v69 and v69.result == "miss" then
				v67, v70 = v_u_42(v58, v59, v65, v69.columnIndex, v66, v67)
			end
			local v71 = v67 - (5 - v66)
			local v72 = math.max(1, v71)
			local v73 = math.min(v70, v67)
			local v74 = math.max(v72, v73)
			local v75 = v58.SurvivingRowOptions[v65 + 1]
			local v76 = v75[math.random(1, #v75)]
			v68 = math.clamp(v76, v72, v74)
		else
			local v77 = 5 - v66
			v67 = math.min(v67, v77)
		end
		local v78 = v_u_11(v60, v68)
		local v79 = v_u_22(v60, v78, v67)
		v61[v65] = v78
		v62[v65] = v79
		v59[v65] = v79
		if v64.result == "miss" then
			break
		end
		v60 = v78
	end
	for v80 = 0, p55 - 1 do
		v62[v80] = v62[v80] or table.clone(v59[v80])
	end
	return {
		["SpinRows"] = v59,
		["SurvivingRows"] = v61,
		["PlannedRows"] = v62
	}
end
function v2.getDisplaySteps(p81) -- name: getDisplaySteps
	-- upvalues: (copy) v_u_3
	local v82 = nil
	for _, v83 in p81.path do
		if v83.result ~= "miss" or v83.columnIndex >= 3 then
			continue
		end
		v82 = v83
	end
	if not v82 or v82.columnIndex ~= 2 then
		return p81.path
	end
	local v84
	if v82.rarity then
		v84 = v_u_3[v82.rarity]
	else
		v84 = nil
	end
	if v84 and v_u_3[p81.finalRarity] < v84 then
		return p81.path
	end
	local v85 = {}
	for _, v86 in p81.path do
		if v86 == v82 then
			break
		end
		table.insert(v85, v86)
	end
	local v87 = table.clone(v82)
	v87.hitRows = {
		0,
		1,
		2,
		3,
		4
	}
	v87.result = "hit"
	table.insert(v85, v87)
	table.insert(v85, {
		["columnIndex"] = 3,
		["kind"] = "bridge",
		["rarity"] = nil,
		["hitRows"] = nil,
		["result"] = "miss",
		["hitRows"] = {}
	})
	return v85
end
return table.freeze(v2)
-- NIGHT Analyzer | ReplicatedStorage.Controllers.CaseSceneController.SceneRegistry
-- ModuleScript | 133 linhas | 3235 bytes | hash 995b4e45

local v1 = {}
local v2 = game:GetService("ReplicatedStorage")
require(v2.Database.Custom.Types)
local v_u_3 = {
	["Default"] = {
		["AssetFolder"] = "CaseScene",
		["InteractionType"] = "Click",
		["Animations"] = nil,
		["Sounds"] = nil,
		["Animations"] = {
			["CaseFall"] = "rbxassetid://91366765923171",
			["CloseIdle"] = "rbxassetid://96896409518629",
			["CaseOpening"] = "rbxassetid://100000665946048",
			["OpenIdle"] = "rbxassetid://127592440292292"
		},
		["Sounds"] = {
			["Drop"] = "Case Fall",
			["Opening"] = "Case Opening"
		}
	},
	["CharmCapsule"] = {
		["AssetFolder"] = "CharmScene",
		["InteractionType"] = "Drag",
		["Animations"] = nil,
		["DragSettings"] = nil,
		["Sounds"] = nil,
		["Animations"] = {
			["PackOpening"] = "rbxassetid://97837283629886"
		},
		["DragSettings"] = {
			["Threshold"] = 0.5,
			["EndKeyframe"] = "DragEndPoint"
		},
		["Sounds"] = {
			["DragStart"] = "Charm Drag Start",
			["DragLoop"] = "Charm Drag Loop"
		}
	}
}
local v4 = {
	["AssetFolder"] = "PackageScene",
	["InteractionType"] = "Click",
	["Animations"] = nil,
	["AnimationKeyframeSounds"] = nil,
	["Animations"] = {
		["CaseFall"] = "rbxassetid://134599478765866",
		["CloseIdle"] = "rbxassetid://119593507010060",
		["CaseOpening"] = "rbxassetid://97681949800792"
	},
	["AnimationKeyframeSounds"] = {
		["CaseFall"] = {
			["Drop"] = "Package Drop"
		},
		["CaseOpening"] = {
			["RightTape"] = "Package Right Tape",
			["LeftTape"] = "Package Left Tape",
			["FrontLid"] = "Package Front Lid",
			["FinalOpen"] = "Package Final Open"
		}
	}
}
v_u_3.Package = v4
v_u_3.Console = {
	["AssetFolder"] = "ConsoleScene",
	["InteractionType"] = "Click",
	["Animations"] = nil,
	["Sounds"] = nil,
	["ConsoleColumnCount"] = 8,
	["Animations"] = {
		["CaseFall"] = "rbxassetid://127945219825547",
		["CaseOpening"] = "rbxassetid://136396496384739"
	},
	["Sounds"] = {
		["Enter"] = "Console Enter Animation",
		["Opening"] = "Console Open Animation"
	}
}
v_u_3.KnifeConsole = {
	["AssetFolder"] = "KnifeConsoleScene",
	["InteractionType"] = "Click",
	["Animations"] = nil,
	["Sounds"] = nil,
	["ConsoleColumnCount"] = 10,
	["Animations"] = {
		["CaseFall"] = "rbxassetid://127945219825547",
		["CaseOpening"] = "rbxassetid://136396496384739"
	},
	["Sounds"] = {
		["Enter"] = "Console Enter Animation",
		["Opening"] = "Console Open Animation"
	}
}
local v_u_5 = {
	["Case"] = "Default",
	["Sticker Capsule"] = "Default",
	["Charm Capsule"] = "CharmCapsule",
	["Package"] = "Package",
	["Console"] = "Console"
}
function v1.GetSceneForCase(p6, p7) -- name: GetSceneForCase
	-- upvalues: (copy) v_u_5
	if p6 == "Console" and p7 then
		local v8
		if p7.specialContents and #p7.specialContents > 0 then
			v8 = true
		else
			for _, v9 in p7.contents do
				if not v9.isSpecial and v9.rarity ~= "Special" then
					continue
				end
				v8 = true
			end
			v8 = false
		end
		if v8 then
			return "KnifeConsole"
		end
	end
	return v_u_5[p6] or "Default"
end
function v1.GetConfig(p10) -- name: GetConfig
	-- upvalues: (copy) v_u_3
	return v_u_3[p10]
end
function v1.GetAllSceneNames() -- name: GetAllSceneNames
	-- upvalues: (copy) v_u_3
	local v11 = {}
	for v12 in v_u_3 do
		table.insert(v11, v12)
	end
	return v11
end
return v1
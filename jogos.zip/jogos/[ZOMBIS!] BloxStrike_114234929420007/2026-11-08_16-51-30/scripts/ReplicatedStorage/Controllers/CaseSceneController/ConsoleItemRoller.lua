-- NIGHT Analyzer | ReplicatedStorage.Controllers.CaseSceneController.ConsoleItemRoller
-- ModuleScript | 273 linhas | 7872 bytes | hash 99c1486a

local v1 = {}
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
require(v2.Shared.Janitor)
local v_u_5 = require(v2.Database.Security.Router)
local v_u_6 = require(v2.Controllers.RunServiceController)
local v_u_7 = UDim2.fromScale(0.196, 0.621)
local v_u_8 = TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
local v_u_9 = TweenInfo.new(0.4, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local function v_u_14(p10, p11) -- name: pickOther
	local v12 = table.find(p10, p11)
	if not v12 or #p10 < 2 then
		return p10[math.random(1, #p10)]
	end
	local v13 = math.random(1, #p10 - 1)
	if v12 <= v13 then
		v13 = v13 + 1
	end
	return p10[v13]
end
local function v_u_18(p15) -- name: buildSequence
	-- upvalues: (copy) v_u_14
	local v16 = table.create(42)
	v16[5] = p15.Winner
	v16[4] = v_u_14(p15.Pool, v16[5])
	v16[3] = v_u_14(p15.Pool, v16[4])
	v16[2] = v_u_14(p15.Pool, v16[3])
	v16[1] = v_u_14(p15.Pool, v16[2])
	for v17 = 6, 42 do
		v16[v17] = v_u_14(p15.Pool, v16[v17 - 1])
	end
	return v16
end
local function v_u_21(p19) -- name: createRoot
	local v20 = Instance.new("Frame")
	v20.Name = "ConsoleItemRoller"
	v20.AnchorPoint = Vector2.new(0.5, 0.5)
	v20.Position = UDim2.fromScale(0.5, 0.5)
	v20.Size = UDim2.fromScale(0.74, 0.36)
	v20.BackgroundTransparency = 1
	v20.ClipsDescendants = true
	v20.ZIndex = 20
	v20.Parent = p19
	return v20
end
local function v_u_28(p22, p23) -- name: createTile
	-- upvalues: (copy) v_u_7
	local v24 = Instance.new("Frame")
	v24.AnchorPoint = Vector2.new(0.5, 0.5)
	v24.Size = v_u_7
	v24.BackgroundTransparency = 1
	v24.Visible = false
	local v25 = Instance.new("UIScale")
	v25.Parent = v24
	local v26 = Instance.new("ImageLabel")
	v26.Name = "Glow"
	v26.AnchorPoint = Vector2.new(0.5, 0.5)
	v26.Position = UDim2.fromScale(0.5, 0.56)
	v26.Size = UDim2.fromScale(1.19, 1.37)
	v26.BackgroundTransparency = 1
	v26.Image = "rbxassetid://10906540366"
	v26.ImageColor3 = p23.Color
	v26.ImageTransparency = 1
	v26.Parent = v24
	local v27 = Instance.new("ImageLabel")
	v27.Name = "Icon"
	v27.AnchorPoint = Vector2.new(0.5, 0.5)
	v27.Position = UDim2.fromScale(0.5, 0.5)
	v27.Size = UDim2.fromScale(1, 1)
	v27.BackgroundTransparency = 1
	v27.Image = p23.Image
	v27.ImageTransparency = 1
	v27.ScaleType = Enum.ScaleType.Fit
	v27.ZIndex = 2
	v27.Parent = v24
	v24.Parent = p22
	return {
		["Frame"] = v24,
		["Scale"] = v25,
		["Icon"] = v27,
		["Glow"] = v26
	}
end
local function v_u_33(p29) -- name: createPointer
	local v30 = Instance.new("Frame")
	v30.Name = "Pointer"
	v30.AnchorPoint = Vector2.new(0.5, 0.5)
	v30.Position = UDim2.fromScale(0.5, 0.02)
	v30.Size = UDim2.fromScale(0.32, 0.32)
	v30.BackgroundTransparency = 1
	v30.ZIndex = 5
	Instance.new("UIAspectRatioConstraint").Parent = v30
	local v31 = Instance.new("UIScale")
	v31.Parent = v30
	local v32 = Instance.new("ImageLabel")
	v32.Name = "Arrow"
	v32.AnchorPoint = Vector2.new(0.5, 0)
	v32.Position = UDim2.fromScale(0.5, 0.5)
	v32.Size = UDim2.fromScale(0.5, 0.5)
	v32.BackgroundTransparency = 1
	v32.Image = "rbxassetid://106962999752773"
	v32.ImageTransparency = 1
	v32.Rotation = 90
	v32.Parent = v30
	v30.Parent = p29
	return v30, v32, v31
end
local function v_u_50(p34, p35, p36) -- name: layoutTiles
	for v37, v38 in p34 do
		local v39 = v37 - p35
		local v40 = 0.5 - v39 * 0.3333333333333333
		local v41
		if v40 > -0.3333333333333333 then
			v41 = v40 < 1.3333333333333333
		else
			v41 = false
		end
		v38.Frame.Visible = v41
		if not v41 then
			continue
		end
		v38.Frame.Position = UDim2.fromScale(v40, 0.5)
		local v42 = 1 - math.abs(v39)
		local v43 = math.clamp(v42, 0, 1)
		local v44 = v43 * v43 * (3 - v43 * 2)
		v38.Scale.Scale = v44 * 0.51 + 1
		local v45 = 1 - v40
		local v46 = math.min(v40, v45) / 0.15
		local v47 = math.clamp(v46, 0, 1)
		local v48 = v47 * v47 * (3 - v47 * 2) * p36
		local v49 = 1 - (v44 * -0.4 + 0.8)
		v38.Icon.ImageTransparency = 1 - v48
		v38.Glow.ImageTransparency = 1 - v49 * v48
	end
end
function v1.play(p51, p52, p53, p54) -- name: play
	-- upvalues: (copy) v_u_21, (copy) v_u_18, (copy) v_u_28, (copy) v_u_33, (copy) v_u_50, (copy) v_u_3, (copy) v_u_6, (copy) v_u_5, (copy) v_u_8, (copy) v_u_4, (copy) v_u_9
	local v55 = p53:Add((v_u_21(p51)))
	local v_u_56 = {}
	for v57, v58 in v_u_18(p52) do
		v_u_56[v57] = v_u_28(v55, v58)
	end
	local v_u_59, v60, v61 = v_u_33(v55)
	local v_u_62 = 0
	local v_u_63 = 0
	local v_u_64 = 39
	local v_u_65 = os.clock()
	local function v_u_75(p66) -- name: swingPointer
		-- upvalues: (ref) v_u_65, (ref) v_u_63, (ref) v_u_62, (ref) v_u_64, (copy) v_u_59
		local v67 = os.clock()
		local v68 = v67 - v_u_65
		local v69 = math.min(v68, 0.1)
		v_u_65 = v67
		while v69 > 0 do
			local v70 = math.min(v69, 0.004166666666666667)
			v_u_63 = v_u_63 - (1934.4424626135142 * v_u_62 + 26.389378290154262 * v_u_63) * v70
			v_u_62 = v_u_62 + v_u_63 * v70
			v69 = v69 - v70
		end
		local v71 = p66 - 0.5
		local v72 = math.ceil(v71) + 0.5 - p66
		local v73 = nil
		if v72 < 0.26 then
			v73 = v72 * 38 / 0.26
		elseif p66 < v_u_64 then
			local v74 = v_u_64
			v73 = math.round(p66) ~= math.round(v74) and 38 or v73
		end
		v_u_64 = p66
		if v73 and v_u_62 < v73 then
			v_u_62 = v73
			v_u_63 = 0
		end
		v_u_59.Rotation = v_u_62
	end
	local v76 = os.clock()
	while p54() do
		local v77 = os.clock() - v76
		local v78 = v77 / 0.25
		local v79 = math.min(v78, 1)
		v_u_50(v_u_56, 39, v79)
		v60.ImageTransparency = 1 - v79
		if v77 >= 0.5 then
			break
		end
		v_u_3.RenderStepped:Wait()
	end
	if not p54() then
		v_u_50(v_u_56, 5, 1)
		v_u_59.Rotation = 0
		v60.ImageTransparency = 0
		v60.ImageColor3 = p52.Winner.Color
		return false
	end
	local v_u_80 = 5 + (math.random() < 0.5 and -1 or 1) * (0.26 + math.random() * 0.18)
	local v_u_81 = 39
	local v82 = v_u_81
	local v_u_83 = math.round(v82)
	local v_u_84 = os.clock()
	local v_u_85 = false
	p53:Add(v_u_6.BindToRenderStep(v_u_6.CreateBindingName("CaseScene.ConsoleItemRoller"), function()
		-- upvalues: (copy) v_u_84, (ref) v_u_81, (copy) v_u_80, (ref) v_u_50, (copy) v_u_56, (copy) v_u_75, (ref) v_u_83, (ref) v_u_5, (ref) v_u_85
		local v86 = (os.clock() - v_u_84) / 5
		local v87 = math.min(v86, 1)
		local v88 = 1 - (1 - v87) ^ 5
		v_u_81 = 39 + (v_u_80 - 39) * v88
		v_u_50(v_u_56, v_u_81, 1)
		v_u_75(v_u_81)
		local v89 = v_u_81
		local v90 = math.round(v89)
		if v90 ~= v_u_83 then
			v_u_83 = v90
			v_u_5.broadcastRouter("RunInterfaceSound", "UI Click")
		end
		v_u_85 = v87 >= 1
	end), "Disconnect", "ConsoleItemRollerScroll")
	local v91 = v_u_81
	while not v_u_85 and p54() do
		v_u_3.RenderStepped:Wait()
	end
	p53:Remove("ConsoleItemRollerScroll")
	if not p54() then
		v_u_50(v_u_56, 5, 1)
		v_u_59.Rotation = 0
		v60.ImageTransparency = 0
		v60.ImageColor3 = p52.Winner.Color
		return false
	end
	local v92 = os.clock()
	while p54() and os.clock() - v92 < 0.3 do
		v_u_75(v91)
		v_u_3.RenderStepped:Wait()
	end
	if not p54() then
		v_u_50(v_u_56, 5, 1)
		v_u_59.Rotation = 0
		v60.ImageTransparency = 0
		v60.ImageColor3 = p52.Winner.Color
		return false
	end
	local v93 = os.clock()
	while p54() do
		local v94 = (os.clock() - v93) / v_u_8.Time
		local v95 = math.min(v94, 1)
		local v96 = v_u_4:GetValue(v95, v_u_8.EasingStyle, v_u_8.EasingDirection)
		v_u_81 = v91 + (5 - v91) * v96
		v_u_50(v_u_56, v_u_81, 1)
		v_u_75(v_u_81)
		if v95 >= 1 then
			break
		end
		v_u_3.RenderStepped:Wait()
	end
	if not p54() then
		v_u_50(v_u_56, 5, 1)
		v_u_59.Rotation = 0
		v60.ImageTransparency = 0
		v60.ImageColor3 = p52.Winner.Color
		return false
	end
	v60.ImageColor3 = p52.Winner.Color
	v61.Scale = 1.45
	v_u_4:Create(v_u_59, v_u_9, {
		["Rotation"] = 0
	}):Play()
	v_u_4:Create(v61, v_u_9, {
		["Scale"] = 1
	}):Play()
	v_u_5.broadcastRouter("RunStoreSound", p52.LandingSound)
	return true
end
return table.freeze(v1)
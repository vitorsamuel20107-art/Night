-- NIGHT Analyzer | ReplicatedStorage.Controllers.DataController
-- ModuleScript | 268 linhas | 6825 bytes | hash 6d1f1b91

local v_u_1 = {}
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("HttpService")
local v_u_4 = game:GetService("Players")
require(v2.Database.Custom.Types)
local v_u_5 = require(v2.Database.Components.Libraries.Stock)
local v_u_6 = require(v2.Database.Security.Remotes)
local v_u_7 = require(v2.Shared.Promise)
local v_u_8 = require(v2.Packages.Sift)
local v_u_9 = { "Serial", "Pattern" }
local v_u_10 = { "OriginalOwner", "Owner" }
local v_u_11 = {}
local v_u_12 = {}
local function v_u_18(p13, p14, p15) -- name: FireListeners
	-- upvalues: (copy) v_u_1, (copy) v_u_7
	local v16 = v_u_1.Get(p13, p14)
	for _, v17 in pairs(p15) do
		v_u_7.try(v17, v16)
	end
end
local function v_u_26(p19, p20) -- name: ExecuteListeners
	-- upvalues: (copy) v_u_12, (copy) v_u_18
	local v21 = v_u_12[p19]
	if v21 then
		local v22 = ""
		for v23, v24 in ipairs(p20) do
			if v23 <= 1 then
				v22 = v24
			else
				v22 = ("%*.%*"):format(v22, v24)
			end
			local v25 = v21[v22]
			if not v25 then
				continue
			end
			v_u_18(p19, v22, v25)
		end
	end
end
local function v_u_37(p27) -- name: DenormalizeInventoryItemFromRemote
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_10
	local v28 = v_u_8.Dictionary.copyDeep(p27)
	for _, v29 in v_u_9 do
		if v28[v29] == nil then
			continue
		end
		local v30 = v28[v29]
		if typeof(v30) ~= "string" then
			continue
		end
		local v31 = v28[v29]
		v28[v29] = tonumber(v31) or v28[v29]
	end
	if v28.MetaData then
		local v32 = v28.MetaData
		if typeof(v32) == "table" then
			for _, v33 in v_u_10 do
				if v28.MetaData[v33] == nil then
					continue
				end
				local v34 = v28.MetaData[v33]
				if typeof(v34) ~= "string" then
					continue
				end
				local v35 = v28.MetaData
				local v36 = v28.MetaData[v33]
				v35[v33] = tonumber(v36) or v28.MetaData[v33]
			end
		end
	end
	return v28
end
local function v_u_45(p38) -- name: ShouldDenormalizeInventoryItem
	if typeof(p38) ~= "table" then
		return false
	end
	local v39 = p38.MetaData
	local v40 = typeof(v39) == "table"
	local v41 = p38.Serial
	if typeof(v41) == "string" then
		v40 = true
		return v40
	else
		local v42 = p38.Pattern
		if typeof(v42) == "string" then
			v40 = true
			return v40
		else
			local v43
			if v40 then
				local v44 = v39.OriginalOwner
				if typeof(v44) == "string" then
					v40 = true
					return v40
				end
				if v40 then
					v43 = v39.Owner
					v40 = typeof(v43) == "string"
				end
			elseif v40 then
				v43 = v39.Owner
				v40 = typeof(v43) == "string"
			end
			return v40
		end
	end
end
function v_u_1.ApplyInventoryDelta(p46, p47, p48) -- name: ApplyInventoryDelta
	-- upvalues: (copy) v_u_11, (copy) v_u_45, (copy) v_u_37, (copy) v_u_26
	local v49 = v_u_11[p46]
	if v49 and v49.Inventory then
		local v50 = false
		if p48 then
			local v51 = {}
			for _, v52 in ipairs(p48) do
				v51[v52] = true
			end
			for v53 = #v49.Inventory, 1, -1 do
				local v54 = v49.Inventory[v53]
				if not (v54 and (v54._id and v51[v54._id])) then
					continue
				end
				table.remove(v49.Inventory, v53)
				v50 = true
			end
		end
		local v55 = {}
		for _, v56 in ipairs(v49.Inventory) do
			if not (v56 and v56._id) then
				continue
			end
			v55[v56._id] = true
		end
		for _, v58 in ipairs(p47) do
			if v_u_45(v58) then
				local v58 = v_u_37(v58)
			end
			if not v58 or (not v58._id or v55[v58._id]) then
				continue
			end
			local v59 = v49.Inventory
			table.insert(v59, v58)
			v55[v58._id] = true
			v50 = true
		end
		if v50 then
			v_u_26(p46, { "Inventory" })
		end
	end
end
function v_u_1.IsDataLoaded(p60) -- name: IsDataLoaded
	-- upvalues: (copy) v_u_11
	return v_u_11[p60] ~= nil
end
function v_u_1.WaitForDataLoaded(p61) -- name: WaitForDataLoaded
	-- upvalues: (copy) v_u_11
	local v62 = 0
	while not v_u_11[p61] do
		v62 = v62 + task.wait()
		if v62 < 60 then
			continue
		end
		error((("[DataController] Failed to load player profile for %* after %* seconds"):format(p61.Name, 60)))
	end
	return v_u_11[p61]
end
function v_u_1.Get(p63, ...) -- name: Get
	-- upvalues: (copy) v_u_11
	local v64 = v_u_11[p63]
	if not v64 then
		return nil
	end
	local v65 = {}
	for _, v66 in table.pack(...) do
		local v67 = v64
		for _, v68 in string.split(v66, ".") do
			v64 = v64[v68]
			if v64 then
				continue
			end
		end
		table.insert(v65, v64)
		v64 = v67
	end
	return table.unpack(v65)
end
function v_u_1.RemoveListener(p69, p70, p71) -- name: RemoveListener
	-- upvalues: (copy) v_u_12
	if v_u_12[p69] and v_u_12[p69][p70] then
		v_u_12[p69][p70][p71] = nil
		if next(v_u_12[p69][p70]) == nil then
			v_u_12[p69][p70] = nil
		end
	end
end
function v_u_1.CreateListener(p72, p73, p74) -- name: CreateListener
	-- upvalues: (copy) v_u_3, (copy) v_u_12, (copy) v_u_1, (copy) v_u_7
	local v75 = v_u_3:GenerateGUID(false)
	v_u_12[p72] = v_u_12[p72] or {}
	v_u_12[p72][p73] = v_u_12[p72][p73] or {}
	v_u_12[p72][p73][v75] = p74
	local v76 = v_u_1.Get(p72, p73)
	if v76 ~= nil then
		v_u_7.try(p74, v76)
	end
	return v75
end
function v_u_1.Initialize() -- name: Initialize
	-- upvalues: (copy) v_u_6, (copy) v_u_12, (copy) v_u_5, (copy) v_u_11, (copy) v_u_18, (copy) v_u_26
	v_u_6.PlayerData.PlayerDataEvent.Listen(function(p77)
		-- upvalues: (ref) v_u_12, (ref) v_u_5, (ref) v_u_11, (ref) v_u_18
		local v78 = v_u_12[p77.Player]
		if p77.Data and p77.Data.Inventory then
			v_u_5.InjectStockItems(p77.Data.Inventory)
		end
		v_u_11[p77.Player] = p77.Data
		if v78 then
			for v79, v80 in pairs(v78) do
				v_u_18(p77.Player, v79, v80)
			end
		end
	end)
	v_u_6.PlayerData.PlayerDataChanged.Listen(function(p81)
		-- upvalues: (ref) v_u_11, (ref) v_u_26
		local v82 = p81.Player
		local v83 = v_u_11[v82]
		if v83 then
			for v84, v85 in pairs(p81.Data) do
				local v86 = string.split(v84, ".")
				local v87 = v83
				for v88 = 1, #v86 - 1 do
					local v89 = v86[v88]
					local v90 = v83[v89]
					if typeof(v90) ~= "table" then
						v83[v89] = {}
					end
					v83 = v83[v89]
				end
				v83[v86[#v86]] = v85
				v_u_26(v82, v86)
				v83 = v87
			end
		else
			warn((("[DataController] Received data change for %* but profile not loaded yet. Requesting full profile."):format(v82.Name)))
		end
	end)
end
function v_u_1.Start() -- name: Start
	-- upvalues: (copy) v_u_6, (copy) v_u_4, (copy) v_u_1, (copy) v_u_12, (copy) v_u_11
	v_u_6.PlayerData.RetrieveAllPlayerData.Send()
	v_u_6.Store.NewInventoryItem.Listen(function(p91)
		-- upvalues: (ref) v_u_4, (ref) v_u_1
		local v92 = p91.Player
		local v93 = tonumber(v92)
		if v93 then
			local v94 = v_u_4:GetPlayerByUserId(v93)
			if v94 and v94:IsDescendantOf(v_u_4) then
				v_u_1.ApplyInventoryDelta(v94, p91.Items, p91.DeletedItemIds)
			end
		end
	end)
	v_u_4.PlayerRemoving:Connect(function(p95)
		-- upvalues: (ref) v_u_12, (ref) v_u_11
		v_u_12[p95] = nil
		v_u_11[p95] = nil
	end)
end
return v_u_1
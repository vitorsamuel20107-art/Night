-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.Market Window
-- ModuleScript | 59 linhas | 1762 bytes | hash cfce2524

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Debris")
local v_u_3 = require(v1.MovementV2.Collision.Schema)
local v_u_4 = workspace:WaitForChild("Debris")
local v_u_5 = require(v1.Packages.Observers)
local v_u_6 = require(v1.Classes.Sound)
local function v_u_12(p7) -- name: createDuplicateWindow
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v8 = p7:GetPivot()
	local v9 = p7:Clone()
	v9:SetAttribute("Broken", false)
	v9:RemoveTag("Market Window")
	v9:RemoveTag("Interactable")
	for _, v10 in v9:GetDescendants() do
		v10:RemoveTag(v_u_3.Tags.Destructible)
	end
	v9:PivotTo(v8)
	for _, v11 in ipairs(v9:GetChildren()) do
		if not v11:IsA("BasePart") then
			continue
		end
		v11.CanCollide = true
		v11.Transparency = 0
	end
	v9.Parent = v_u_4
	return v9
end
local function v_u_19(p13) -- name: createBreakPoints
	-- upvalues: (copy) v_u_2, (copy) v_u_6
	local v14 = p13:GetAttribute("Direction")
	for _, v15 in ipairs(p13:GetChildren()) do
		if not v15:IsA("BasePart") then
			continue
		end
		v15.CollisionGroup = "Debris"
		v15.Anchored = false
		local v16 = v14.X * math.random(7, 12)
		local v17 = v14.Y * math.random(7, 12)
		local v18 = v14.Z * math.random(7, 12)
		v15:ApplyImpulse((Vector3.new(v16, v17, v18)))
	end
	v_u_2:AddItem(p13, 5)
	v_u_6.new("Bullet"):playOneTime({
		["Name"] = "Break Market Window",
		["Parent"] = nil,
		["Parent"] = p13.PrimaryPart
	})
end
return v_u_5.observeTag("Market Window", function(p_u_20)
	-- upvalues: (copy) v_u_5, (copy) v_u_12, (copy) v_u_19
	if p_u_20:IsDescendantOf(workspace) then
		return v_u_5.observeAttribute(p_u_20, "Broken", function(p21)
			-- upvalues: (ref) v_u_12, (copy) p_u_20, (ref) v_u_19
			if p21 then
				v_u_19((v_u_12(p_u_20)))
			end
		end)
	end
end)
-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Players
-- ModuleScript | 531 linhas | 17571 bytes | hash 4325f31a

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("HttpService")
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("RunService")
local v_u_5 = require(v1.Packages.Observers)
local v_u_6 = require(v1.Shared.DebugFlags)
local v_u_7 = v_u_3.LocalPlayer
local v_u_8 = require(script.Components.CreateWeaponModel)
local v_u_9 = require(v1.Components.Common.CharacterResolver)
local v_u_10 = {}
local v_u_11 = {}
local v_u_12 = {}
local v_u_13 = {}
local v_u_14 = {}
local v_u_15 = {}
local v_u_16 = 1
local v_u_17 = false
local v_u_18 = nil
local function v_u_22(p19) -- name: waitForPresentationRig
	for _, v20 in {
		"HumanoidRootPart",
		"UpperTorso",
		"LeftHand",
		"RightHand"
	} do
		local v21 = p19:FindFirstChild(v20) or p19:WaitForChild(v20, 10)
		if v21 and v21:IsA("BasePart") then
			continue
		end
		return false
	end
	return true
end
local function v_u_26(p23) -- name: clearCurrentEquippedVisuals
	-- upvalues: (copy) v_u_10, (copy) v_u_11, (copy) v_u_9, (copy) v_u_8
	v_u_10[p23] = nil
	v_u_11[p23] = nil
	local v24 = v_u_9.getPlayerCharacter(p23)
	if v24 then
		for _, v25 in ipairs(v24:GetChildren()) do
			if not v25:IsA("Folder") or v25.Name ~= "WeaponAttachments" and v25.Name ~= "WeaponModel" then
				continue
			end
			v25:ClearAllChildren()
		end
	end
	v_u_8.ClearPlayerCache(p23)
end
local function v_u_31(p27) -- name: buildInventorySlots
	-- upvalues: (copy) v_u_2
	local v28 = {}
	for v29 = 1, 3 do
		local v30 = p27:GetAttribute("Slot" .. v29)
		if not v30 then
			continue
		end
		v28[v29] = v_u_2:JSONDecode(v30)
	end
	return v28
end
local function v_u_42(p32) -- name: stickerSignature
	if typeof(p32) ~= "table" then
		return ""
	end
	local v33 = {}
	for v34, v35 in ipairs(p32) do
		if typeof(v35) == "table" then
			local v36 = v35.Position
			local v37 = typeof(v36) == "table" and (v36.Rotation or "") or ""
			local v38 = typeof(v36) == "table" and (v36.X or "") or ""
			local v39 = typeof(v36) == "table" and (v36.Y or "") or ""
			local v40 = string.format
			local v41 = v35.Sticker or ""
			v33[v34] = v40("%s@%s,%s,%s", tostring(v41), tostring(v37), tostring(v38), (tostring(v39)))
		else
			v33[v34] = tostring(v35)
		end
	end
	return table.concat(v33, ";")
end
local function v_u_57(p43) -- name: visualSignature
	-- upvalues: (copy) v_u_42
	if typeof(p43) ~= "table" then
		return ""
	end
	local v44 = table.concat
	local v45 = {}
	local v46 = p43.Identifier or ""
	local v47 = tostring(v46)
	local v48 = p43.Name or ""
	local v49 = tostring(v48)
	local v50 = p43.Skin or ""
	local v51 = tostring(v50)
	local v52 = p43.Float or ""
	local v53 = tostring(v52)
	local v54 = p43.StatTrack or ""
	local v55 = tostring(v54)
	local v56 = p43.NameTag or ""
	__set_list(v45, 1, {v47, v49, v51, v53, v55, tostring(v56), v_u_42(p43.Stickers)})
	return v44(v45, "|")
end
local function v_u_62(p58) -- name: refreshObjectiveKitHolster
	-- upvalues: (copy) v_u_8, (copy) v_u_6
	local v59 = v_u_8.RefreshObjectiveKitHolster
	local v60, v61 = pcall(v59, p58)
	if v_u_6.IsEnabled("ThirdPersonWeaponModels") and not v60 then
		warn(("[ThirdPersonWeaponModels] %s %s failed: %s"):format(p58.Name, "RefreshObjectiveKitHolster", (tostring(v61))))
	end
end
local function v_u_67(p63) -- name: refreshBombHolster
	-- upvalues: (copy) v_u_8, (copy) v_u_6
	debug.profilebegin("Observers.Players.RefreshBombHolster")
	local v64 = v_u_8.RefreshBombHolster
	local v65, v66 = pcall(v64, p63)
	if v_u_6.IsEnabled("ThirdPersonWeaponModels") and not v65 then
		warn(("[ThirdPersonWeaponModels] %s %s failed: %s"):format(p63.Name, "RefreshBombHolster", (tostring(v66))))
	end
	debug.profileend()
end
local function v_u_76(p_u_68) -- name: createObjectiveKitListener
	-- upvalues: (copy) v_u_12, (copy) v_u_62, (copy) v_u_14, (copy) v_u_3, (copy) v_u_5
	local function v72() -- name: onKitChanged
		-- upvalues: (copy) p_u_68, (ref) v_u_12, (ref) v_u_62, (ref) v_u_14, (ref) v_u_3
		local v_u_69 = p_u_68
		local v_u_70 = v_u_12
		local v_u_71 = v_u_62
		if not (v_u_14[v_u_69] or v_u_70[v_u_69]) then
			v_u_70[v_u_69] = true
			task.defer(function()
				-- upvalues: (copy) v_u_70, (copy) v_u_69, (ref) v_u_3, (ref) v_u_14, (copy) v_u_71
				v_u_70[v_u_69] = nil
				if v_u_69.Parent == v_u_3 and not v_u_14[v_u_69] then
					v_u_71(v_u_69)
				end
			end)
		end
		return function() end
	end
	local v_u_73 = v_u_5.observeAttribute(p_u_68, "HasDefuseKit", v72)
	local v_u_74 = v_u_5.observeAttribute(p_u_68, "HasRescueKit", v72)
	local v_u_75 = p_u_68:GetAttributeChangedSignal("Team"):Connect(v72)
	return function()
		-- upvalues: (copy) v_u_73, (copy) v_u_74, (copy) v_u_75
		v_u_73()
		v_u_74()
		v_u_75:Disconnect()
	end
end
local function v_u_94(p_u_77) -- name: createBombHolsterListener
	-- upvalues: (copy) v_u_13, (copy) v_u_67, (copy) v_u_14, (copy) v_u_3, (copy) v_u_5, (copy) v_u_15, (ref) v_u_17, (ref) v_u_16, (copy) v_u_4, (ref) v_u_18
	local v78 = p_u_77:GetAttribute("CurrentEquipped")
	local v_u_79 = typeof(v78) == "string" and (string.match(v78, "\"Name\"%s*:%s*\"([^\"]+)\"") or "") or ""
	local v_u_83 = p_u_77:GetAttributeChangedSignal("Slot5"):Connect(function()
		-- upvalues: (copy) p_u_77, (ref) v_u_13, (ref) v_u_67, (ref) v_u_14, (ref) v_u_3
		local v_u_80 = p_u_77
		local v_u_81 = v_u_13
		local v_u_82 = v_u_67
		if not v_u_14[v_u_80] then
			if v_u_81[v_u_80] then
				return
			end
			v_u_81[v_u_80] = true
			task.defer(function()
				-- upvalues: (copy) v_u_81, (copy) v_u_80, (ref) v_u_3, (ref) v_u_14, (copy) v_u_82
				v_u_81[v_u_80] = nil
				if v_u_80.Parent == v_u_3 and not v_u_14[v_u_80] then
					v_u_82(v_u_80)
				end
			end)
		end
	end)
	local v_u_93 = v_u_5.observeAttribute(p_u_77, "CurrentEquipped", function(p84)
		-- upvalues: (ref) v_u_79, (copy) p_u_77, (ref) v_u_14, (ref) v_u_15, (ref) v_u_17, (ref) v_u_16, (ref) v_u_4, (ref) v_u_3, (ref) v_u_18
		local v85 = typeof(p84) == "string" and (string.match(p84, "\"Name\"%s*:%s*\"([^\"]+)\"") or "") or ""
		if v85 == v_u_79 then
			return function() end
		end
		v_u_79 = v85
		local v86 = p_u_77
		if not v_u_14[v86] then
			v_u_14[v86] = true
			local v87 = v_u_15
			table.insert(v87, v86)
			if not v_u_17 then
				v_u_17 = true
				task.spawn(function()
					-- upvalues: (ref) v_u_16, (ref) v_u_15, (ref) v_u_4, (ref) v_u_14, (ref) v_u_3, (ref) v_u_18, (ref) v_u_17
					while v_u_16 <= #v_u_15 do
						v_u_4.Heartbeat:Wait()
						local v_u_88 = v_u_15[v_u_16]
						v_u_16 = v_u_16 + 1
						if not v_u_14[v_u_88] then
							continue
						end
						v_u_14[v_u_88] = nil
						if v_u_88.Parent ~= v_u_3 then
							continue
						end
						task.spawn(function()
							-- upvalues: (ref) v_u_18, (copy) v_u_88
							local v89 = v_u_18
							local v90 = v_u_88
							local v91, v92 = pcall(v89, v90)
							if not v91 then
								warn((("[ThirdPersonWeaponModels] %* presentation rebuild failed: %*"):format(v_u_88.Name, v92)))
							end
						end)
					end
					table.clear(v_u_15)
					v_u_16 = 1
					v_u_17 = false
				end)
			end
		end
		return function() end
	end)
	return function()
		-- upvalues: (copy) v_u_83, (copy) v_u_93
		v_u_83:Disconnect()
		v_u_93()
	end
end
v_u_18 = function(p_u_95)
	-- upvalues: (copy) v_u_9, (copy) v_u_8, (copy) v_u_22, (copy) v_u_14, (copy) v_u_15, (ref) v_u_17, (ref) v_u_16, (copy) v_u_4, (copy) v_u_3, (ref) v_u_18, (copy) v_u_2, (copy) v_u_10, (copy) v_u_57, (copy) v_u_11, (copy) v_u_31, (copy) v_u_6
	local v_u_96 = v_u_9.getPlayerCharacter(p_u_95)
	if v_u_96 and v_u_96:GetAttribute("Dead") ~= true then
		if v_u_22(v_u_96) then
			local function v126()
				-- upvalues: (ref) v_u_9, (copy) p_u_95, (copy) v_u_96, (ref) v_u_14, (ref) v_u_15, (ref) v_u_17, (ref) v_u_16, (ref) v_u_4, (ref) v_u_3, (ref) v_u_18, (ref) v_u_2, (ref) v_u_10, (ref) v_u_57, (ref) v_u_11, (ref) v_u_8, (ref) v_u_31, (ref) v_u_6
				if v_u_9.getPlayerCharacter(p_u_95) == v_u_96 and v_u_96:GetAttribute("Dead") ~= true then
					local v97 = false
					local v_u_98 = p_u_95:GetAttribute("CurrentEquipped")
					if v_u_98 then
						local function v99()
							-- upvalues: (ref) v_u_2, (copy) v_u_98
							return v_u_2:JSONDecode(v_u_98)
						end
						local v100, v_u_101 = pcall(v99)
						if v100 and typeof(v_u_101) == "table" then
							v_u_10[p_u_95] = v_u_57(v_u_101)
							v_u_11[p_u_95] = v_u_101.IsSuppressed == true
							local function v102()
								-- upvalues: (ref) v_u_8, (ref) p_u_95, (copy) v_u_101, (ref) v_u_31
								v_u_8(p_u_95, v_u_101, (v_u_31(p_u_95)))
							end
							debug.profilebegin("Observers.Players.RebuildCharacterVisuals.Weapon")
							local v103, v104 = pcall(v102)
							debug.profileend()
							if v103 then
								v97 = true
							else
								error(v104, 0)
								v97 = true
							end
						end
					end
					if not v97 then
						local function v109()
							-- upvalues: (ref) p_u_95, (ref) v_u_8, (ref) v_u_6
							local v105 = p_u_95
							local v106 = v_u_8.RefreshObjectiveKitHolster
							local v107, v108 = pcall(v106, v105)
							if v_u_6.IsEnabled("ThirdPersonWeaponModels") and not v107 then
								warn(("[ThirdPersonWeaponModels] %s %s failed: %s"):format(v105.Name, "RefreshObjectiveKitHolster", (tostring(v108))))
							end
						end
						debug.profilebegin("Observers.Players.RebuildCharacterVisuals.ObjectiveKit")
						local v110, v111 = pcall(v109)
						debug.profileend()
						if not v110 then
							error(v111, 0)
						end
						local function v116()
							-- upvalues: (ref) p_u_95, (ref) v_u_8, (ref) v_u_6
							local v112 = p_u_95
							debug.profilebegin("Observers.Players.RefreshBombHolster")
							local v113 = v_u_8.RefreshBombHolster
							local v114, v115 = pcall(v113, v112)
							if v_u_6.IsEnabled("ThirdPersonWeaponModels") and not v114 then
								warn(("[ThirdPersonWeaponModels] %s %s failed: %s"):format(v112.Name, "RefreshBombHolster", (tostring(v115))))
							end
							debug.profileend()
						end
						debug.profilebegin("Observers.Players.RebuildCharacterVisuals.BombHolster")
						local v117, v118 = pcall(v116)
						debug.profileend()
						if not v117 then
							error(v118, 0)
						end
					end
					return
				else
					local v119 = p_u_95
					if v_u_14[v119] then
						return
					else
						v_u_14[v119] = true
						local v120 = v_u_15
						table.insert(v120, v119)
						if not v_u_17 then
							v_u_17 = true
							task.spawn(function()
								-- upvalues: (ref) v_u_16, (ref) v_u_15, (ref) v_u_4, (ref) v_u_14, (ref) v_u_3, (ref) v_u_18, (ref) v_u_17
								while v_u_16 <= #v_u_15 do
									v_u_4.Heartbeat:Wait()
									local v_u_121 = v_u_15[v_u_16]
									v_u_16 = v_u_16 + 1
									if not v_u_14[v_u_121] then
										continue
									end
									v_u_14[v_u_121] = nil
									if v_u_121.Parent ~= v_u_3 then
										continue
									end
									task.spawn(function()
										-- upvalues: (ref) v_u_18, (copy) v_u_121
										local v122 = v_u_18
										local v123 = v_u_121
										local v124, v125 = pcall(v122, v123)
										if not v124 then
											warn((("[ThirdPersonWeaponModels] %* presentation rebuild failed: %*"):format(v_u_121.Name, v125)))
										end
									end)
								end
								table.clear(v_u_15)
								v_u_16 = 1
								v_u_17 = false
							end)
						end
					end
				end
			end
			debug.profilebegin("Observers.Players.RebuildCharacterVisuals")
			local v127, v128 = pcall(v126)
			debug.profileend()
			if not v127 then
				error(v128, 0)
			end
		else
			v_u_8.ClearPlayerCache(p_u_95)
		end
	else
		local function v129()
			-- upvalues: (ref) v_u_8, (copy) p_u_95
			v_u_8.ClearPlayerCache(p_u_95)
		end
		debug.profilebegin("Observers.Players.RebuildCharacterVisuals.ClearCache")
		local v130, v131 = pcall(v129)
		debug.profileend()
		if not v130 then
			error(v131, 0)
		end
		return
	end
end
return v_u_5.observePlayer(function(p_u_132)
	-- upvalues: (copy) v_u_7, (copy) v_u_5, (copy) v_u_6, (copy) v_u_14, (copy) v_u_26, (copy) v_u_2, (copy) v_u_57, (copy) v_u_10, (copy) v_u_11, (copy) v_u_8, (copy) v_u_15, (ref) v_u_17, (ref) v_u_16, (copy) v_u_4, (copy) v_u_3, (ref) v_u_18, (copy) v_u_76, (copy) v_u_94, (copy) v_u_9, (copy) v_u_12, (copy) v_u_13
	if p_u_132 == v_u_7 then
		return function() end
	end
	local v_u_157 = v_u_5.observeAttribute(p_u_132, "CurrentEquipped", function(p133)
		-- upvalues: (ref) v_u_6, (copy) p_u_132, (ref) v_u_14, (ref) v_u_26, (ref) v_u_2, (ref) v_u_57, (ref) v_u_10, (ref) v_u_11, (ref) v_u_8, (ref) v_u_15, (ref) v_u_17, (ref) v_u_16, (ref) v_u_4, (ref) v_u_3, (ref) v_u_18
		if v_u_6.IsEnabled("ThirdPersonWeaponModels") then
			local v134 = warn
			local v135 = p_u_132.Name
			local v136 = typeof(p133) == "string" and (#p133 or -1) or -1
			v134(("[ThirdPersonWeaponModels] %s CurrentEquipped changed (%s bytes JSON)"):format(v135, (tostring(v136))))
		end
		if not p133 then
			v_u_14[p_u_132] = nil
			v_u_26(p_u_132)
			return function() end
		end
		local v_u_137 = v_u_2:JSONDecode(p133)
		local v138 = v_u_57(v_u_137)
		if v138 ~= "" and v_u_10[p_u_132] == v138 then
			local v139 = v_u_137.IsSuppressed == true
			if v_u_11[p_u_132] ~= v139 then
				v_u_11[p_u_132] = v139
				local function v140()
					-- upvalues: (ref) v_u_8, (ref) p_u_132, (copy) v_u_137
					return v_u_8.RefreshSuppressorState(p_u_132, v_u_137)
				end
				debug.profilebegin("Observers.Players.RefreshSuppressorState")
				local v141, v142 = pcall(v140)
				debug.profileend()
				if not v141 then
					error(v142, 0)
				end
				if not v142 then
					local v143 = p_u_132
					if not v_u_14[v143] then
						v_u_14[v143] = true
						local v144 = v_u_15
						table.insert(v144, v143)
						if not v_u_17 then
							v_u_17 = true
							task.spawn(function()
								-- upvalues: (ref) v_u_16, (ref) v_u_15, (ref) v_u_4, (ref) v_u_14, (ref) v_u_3, (ref) v_u_18, (ref) v_u_17
								while v_u_16 <= #v_u_15 do
									v_u_4.Heartbeat:Wait()
									local v_u_145 = v_u_15[v_u_16]
									v_u_16 = v_u_16 + 1
									if not v_u_14[v_u_145] then
										continue
									end
									v_u_14[v_u_145] = nil
									if v_u_145.Parent ~= v_u_3 then
										continue
									end
									task.spawn(function()
										-- upvalues: (ref) v_u_18, (copy) v_u_145
										local v146 = v_u_18
										local v147 = v_u_145
										local v148, v149 = pcall(v146, v147)
										if not v148 then
											warn((("[ThirdPersonWeaponModels] %* presentation rebuild failed: %*"):format(v_u_145.Name, v149)))
										end
									end)
								end
								table.clear(v_u_15)
								v_u_16 = 1
								v_u_17 = false
							end)
						end
					end
				end
			end
			return function() end
		end
		v_u_10[p_u_132] = v138
		v_u_11[p_u_132] = v_u_137.IsSuppressed == true
		local v150 = p_u_132
		if not v_u_14[v150] then
			v_u_14[v150] = true
			local v151 = v_u_15
			table.insert(v151, v150)
			if not v_u_17 then
				v_u_17 = true
				task.spawn(function()
					-- upvalues: (ref) v_u_16, (ref) v_u_15, (ref) v_u_4, (ref) v_u_14, (ref) v_u_3, (ref) v_u_18, (ref) v_u_17
					while v_u_16 <= #v_u_15 do
						v_u_4.Heartbeat:Wait()
						local v_u_152 = v_u_15[v_u_16]
						v_u_16 = v_u_16 + 1
						if not v_u_14[v_u_152] then
							continue
						end
						v_u_14[v_u_152] = nil
						if v_u_152.Parent ~= v_u_3 then
							continue
						end
						task.spawn(function()
							-- upvalues: (ref) v_u_18, (copy) v_u_152
							local v153 = v_u_18
							local v154 = v_u_152
							local v155, v156 = pcall(v153, v154)
							if not v155 then
								warn((("[ThirdPersonWeaponModels] %* presentation rebuild failed: %*"):format(v_u_152.Name, v156)))
							end
						end)
					end
					table.clear(v_u_15)
					v_u_16 = 1
					v_u_17 = false
				end)
			end
		end
		return function()
			-- upvalues: (ref) p_u_132, (ref) v_u_26
			if p_u_132:GetAttribute("CurrentEquipped") == nil then
				v_u_26(p_u_132)
			end
		end
	end)
	local v_u_158 = v_u_76(p_u_132)
	local v_u_159 = v_u_94(p_u_132)
	local v_u_167 = v_u_9.observeCharacter(p_u_132, function()
		-- upvalues: (copy) p_u_132, (ref) v_u_14, (ref) v_u_15, (ref) v_u_17, (ref) v_u_16, (ref) v_u_4, (ref) v_u_3, (ref) v_u_18
		local v160 = p_u_132
		if not v_u_14[v160] then
			v_u_14[v160] = true
			local v161 = v_u_15
			table.insert(v161, v160)
			if not v_u_17 then
				v_u_17 = true
				task.spawn(function()
					-- upvalues: (ref) v_u_16, (ref) v_u_15, (ref) v_u_4, (ref) v_u_14, (ref) v_u_3, (ref) v_u_18, (ref) v_u_17
					while v_u_16 <= #v_u_15 do
						v_u_4.Heartbeat:Wait()
						local v_u_162 = v_u_15[v_u_16]
						v_u_16 = v_u_16 + 1
						if not v_u_14[v_u_162] then
							continue
						end
						v_u_14[v_u_162] = nil
						if v_u_162.Parent ~= v_u_3 then
							continue
						end
						task.spawn(function()
							-- upvalues: (ref) v_u_18, (copy) v_u_162
							local v163 = v_u_18
							local v164 = v_u_162
							local v165, v166 = pcall(v163, v164)
							if not v165 then
								warn((("[ThirdPersonWeaponModels] %* presentation rebuild failed: %*"):format(v_u_162.Name, v166)))
							end
						end)
					end
					table.clear(v_u_15)
					v_u_16 = 1
					v_u_17 = false
				end)
			end
		end
		return function() end
	end)
	return function()
		-- upvalues: (copy) v_u_157, (copy) v_u_158, (copy) v_u_159, (copy) v_u_167, (ref) v_u_12, (copy) p_u_132, (ref) v_u_13, (ref) v_u_14, (ref) v_u_8, (ref) v_u_10, (ref) v_u_11
		v_u_157()
		v_u_158()
		v_u_159()
		v_u_167()
		v_u_12[p_u_132] = nil
		v_u_13[p_u_132] = nil
		v_u_14[p_u_132] = nil
		v_u_8.ClearPlayerCache(p_u_132)
		v_u_10[p_u_132] = nil
		v_u_11[p_u_132] = nil
	end
end)
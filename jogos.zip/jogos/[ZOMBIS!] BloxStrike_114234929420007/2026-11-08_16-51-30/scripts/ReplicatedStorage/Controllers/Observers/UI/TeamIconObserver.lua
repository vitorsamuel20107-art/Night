-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.UI.TeamIconObserver
-- ModuleScript | 15 linhas | 422 bytes | hash e7f397e9

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Packages.Observers)
local v_u_3 = {
	["Counter-Terrorists"] = "rbxassetid://72938147057400",
	["Terrorists"] = "rbxassetid://73218600485628"
}
return v2.observeTag("TeamIcon", function(p4)
	-- upvalues: (copy) v_u_3
	local v5 = p4:GetAttribute("TeamName")
	local v6 = v5 and v_u_3[v5] or nil
	if v6 then
		p4.Image = v6
	end
	return function() end
end)
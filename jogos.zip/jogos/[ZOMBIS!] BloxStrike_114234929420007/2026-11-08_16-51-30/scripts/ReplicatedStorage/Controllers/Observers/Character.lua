-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Character
-- ModuleScript | 639 linhas | 18630 bytes | hash 563a9f90

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("HttpService")
local v3 = game:GetService("Players")
require(v_u_1.Database.Custom.Types)
local v_u_4 = v3.LocalPlayer
local v_u_5 = v_u_4:WaitForChild("PlayerGui")
local v_u_6 = require(v_u_1.Controllers.SpectateController)
local v_u_7 = require(v_u_1.Controllers.CameraController)
local v_u_8 = require(v_u_1.Controllers.InputController)
local v_u_9 = require(v_u_1.Controllers.BlackMarketSceneController)
local v_u_10 = require(v_u_1.Packages.Observers)
local v_u_11 = require(v_u_1.Shared.Janitor)
local v_u_12 = require(v_u_1.Classes.CharacterHighlight)
local v_u_13 = require(v_u_1.Components.Common.GetWeaponProperties)
local v_u_14 = require(v_u_1.Components.Common.CharacterResolver)
local v_u_15 = require(v_u_1.Components.Common.Participants)
local v_u_16 = require(v_u_1.Components.Common.IsSurvivalMode)
local v_u_17 = require(v_u_1.Controllers.CharacterController)
local v_u_18 = require(script.Components.Defuser)
local v_u_19 = {
	["Counter-Terrorists"] = Color3.fromRGB(25, 80, 170),
	["Terrorists"] = Color3.fromRGB(255, 215, 70)
}
local v_u_20 = {}
local v_u_21 = {}
local v_u_22 = {}
local function v_u_26(p23, p24) -- name: ApplyNameTagTextColor
	for _, v25 in ipairs(p23:GetDescendants()) do
		if not (v25:IsA("TextLabel") or (v25:IsA("TextButton") or v25:IsA("TextBox"))) then
			continue
		end
		v25.TextColor3 = p24
	end
end
local function v_u_32() -- name: RefreshNameTagArrowColors
	-- upvalues: (copy) v_u_22, (copy) v_u_19, (copy) v_u_15, (copy) v_u_26
	for v27, v28 in pairs(v_u_22) do
		local v29 = v27:GetAttribute("Team")
		local v30
		if v29 then
			v30 = v_u_19[v29]
		else
			v30 = nil
		end
		if not v30 then
			continue
		end
		local v31 = v_u_15.Character(v27)
		if v31 then
			v30 = v31:GetAttribute("CompetitivePlayerColor") or v30
		end
		if v28.Arrow.Parent then
			v28.Arrow.Arrow.ImageColor3 = v30
		end
		if not v28.NameTag.Parent then
			continue
		end
		v_u_26(v28.NameTag, v30)
	end
end
workspace:GetAttributeChangedSignal("ServerGamemode"):Connect(v_u_32)
local function v_u_77(p_u_33, p_u_34, p35) -- name: CreateNameTag
	-- upvalues: (copy) v_u_19, (copy) v_u_14, (copy) v_u_21, (copy) v_u_32, (copy) v_u_11, (copy) v_u_1, (copy) v_u_5, (copy) v_u_15, (copy) v_u_26, (copy) v_u_2, (copy) v_u_10, (copy) v_u_13, (copy) v_u_22, (copy) v_u_6, (copy) v_u_4, (copy) v_u_9
	local v_u_36 = v_u_19[p35]
	if not v_u_36 then
		return nil
	end
	local v37 = v_u_14.getHead(p_u_34)
	if not (v37 and p_u_34:IsDescendantOf(workspace)) then
		return nil
	end
	if v_u_21[p_u_33] then
		v_u_21[p_u_33]:Destroy()
		v_u_21[p_u_33] = nil
		v_u_32()
	end
	local v38 = v_u_11.new()
	local v_u_39 = v38:Add(v_u_1.Assets.Other.Character.Arrow:Clone())
	local v40
	if p_u_34 then
		v40 = p_u_34:GetAttribute("CompetitivePlayerColor") or v_u_36
	else
		v40 = v_u_36
	end
	v_u_39.Arrow.ImageColor3 = v40
	v_u_39.Adornee = v37
	v_u_39.Parent = v_u_5
	local v_u_41 = v38:Add(v_u_1.Assets.Other.Character.NameTag:Clone())
	v_u_41.Info.PlayerName.Text = ("%*"):format((v_u_15.DisplayName(p_u_33)))
	v_u_41.Info.Weapons.Bomb.Visible = false
	v_u_41.Adornee = v37
	v_u_41.Parent = v_u_5
	local v42 = v_u_41.Info.Health
	local v43 = v_u_14.getHealth(p_u_34)
	local v44 = v_u_14.getMaxHealth(p_u_34)
	local v45 = v43 / math.max(v44, 1) * 100
	v42.Text = ("%*%%"):format((math.ceil(v45)))
	v_u_26(v_u_41, v40)
	v38:Add(p_u_34:GetAttributeChangedSignal("CompetitivePlayerColor"):Connect(function()
		-- upvalues: (copy) p_u_34, (copy) v_u_36, (copy) v_u_39, (copy) v_u_41, (ref) v_u_26
		local v46 = p_u_34
		local v47 = v_u_36
		if v46 then
			v47 = v46:GetAttribute("CompetitivePlayerColor") or v47
		end
		if v_u_39.Parent and v_u_39:FindFirstChild("Arrow") then
			v_u_39.Arrow.ImageColor3 = v47
		end
		if v_u_41.Parent then
			v_u_26(v_u_41, v47)
		end
	end))
	local function v53() -- name: updateHealthText
		-- upvalues: (copy) v_u_41, (copy) p_u_34, (ref) v_u_14
		if v_u_41.Parent and v_u_41:FindFirstChild("Info") then
			local v48 = v_u_41.Info.Health
			local v49 = p_u_34
			local v50 = v_u_14.getHealth(v49)
			local v51 = v_u_14.getMaxHealth(v49)
			local v52 = v50 / math.max(v51, 1) * 100
			v48.Text = ("%*%%"):format((math.ceil(v52)))
		end
	end
	v38:Add(p_u_34:GetAttributeChangedSignal("Health"):Connect(v53))
	v38:Add(p_u_34:GetAttributeChangedSignal("MaxHealth"):Connect(v53))
	v38:Add(v_u_10.observeAttribute(p_u_33, "CurrentEquipped", function(p54)
		-- upvalues: (copy) v_u_41, (ref) v_u_2, (ref) v_u_13, (copy) p_u_33
		if not (v_u_41.Parent and v_u_41:FindFirstChild("Info")) then
			return function() end
		end
		local v55 = v_u_2:JSONDecode(p54 or "[]")
		local v56 = v_u_41.Info.Weapons.Gun
		if v55 and v55.Name then
			local v57 = v_u_13(v55.Name)
			v56.Image = v57 and (v57.Icon or "") or ""
			v56.Visible = v57 or false
		else
			v56.Visible = false
		end
		local v58 = p_u_33:GetAttribute("Slot5")
		local v59
		if v58 then
			v59 = v_u_2:JSONDecode(v58)
		else
			v59 = nil
		end
		local v60
		if v59 == nil then
			v60 = false
		else
			v60 = v59.Weapon == "C4"
		end
		local v61
		if v55 == nil then
			v61 = false
		else
			v61 = v55.Name == "C4"
		end
		local v62 = v_u_41.Info.Weapons.Bomb
		if v60 then
			v60 = not v61
		end
		v62.Visible = v60
		return function()
			-- upvalues: (ref) v_u_41
			if v_u_41:FindFirstChild("Info") then
				v_u_41.Info.Weapons.Gun.Visible = false
			end
		end
	end))
	v38:Add(v_u_10.observeAttribute(p_u_33, "Slot5", function(p63)
		-- upvalues: (copy) v_u_41, (copy) p_u_33, (ref) v_u_2
		if not (v_u_41.Parent and v_u_41:FindFirstChild("Info")) then
			return function() end
		end
		local v64 = p_u_33:GetAttribute("CurrentEquipped")
		local v65
		if v64 then
			v65 = v_u_2:JSONDecode(v64)
		else
			v65 = nil
		end
		local v66 = v_u_2:JSONDecode(p63 or "[]")
		local v67
		if v66 == nil then
			v67 = false
		else
			v67 = v66.Weapon == "C4"
		end
		local v68
		if v65 == nil then
			v68 = false
		else
			v68 = v65.Name == "C4"
		end
		local v69 = v_u_41.Info.Weapons.Bomb
		if v67 then
			v67 = not v68
		end
		v69.Visible = v67
		return function()
			-- upvalues: (ref) v_u_41
			if v_u_41:FindFirstChild("Info") then
				v_u_41.Info.Weapons.Bomb.Visible = false
			end
		end
	end))
	v_u_21[p_u_33] = v38
	v_u_22[p_u_33] = {
		["Arrow"] = v_u_39,
		["NameTag"] = v_u_41
	}
	local v70 = v_u_6.GetPlayer()
	local v71
	if v70 == nil or v70 == v_u_4 then
		v71 = not v_u_9.IsActive()
	else
		v71 = false
	end
	v_u_39.Enabled = v71
	v_u_41.Enabled = v71
	v38:Add(function()
		-- upvalues: (ref) v_u_22, (copy) p_u_33
		v_u_22[p_u_33] = nil
	end)
	local function v76() -- name: cleanupIfCharacterBecameStale
		-- upvalues: (copy) p_u_33, (ref) v_u_14, (ref) v_u_15, (copy) p_u_34, (ref) v_u_21, (ref) v_u_32
		local v72 = true
		local v73 = p_u_33
		local v74
		if v73:IsA("Player") then
			v74 = v_u_14.getPlayerCharacter(v73)
		else
			v74 = v_u_15.Character(v73)
		end
		if v74 == p_u_34 then
			v72 = not (p_u_34:IsDescendantOf(workspace) and v_u_14.isAliveCharacter(p_u_34))
		end
		if v72 then
			local v75 = p_u_33
			if v_u_21[v75] then
				v_u_21[v75]:Destroy()
				v_u_21[v75] = nil
				v_u_32()
			end
		end
	end
	v38:Add(p_u_34:GetAttributeChangedSignal("Dead"):Connect(v76))
	v38:Add(p_u_34:GetAttributeChangedSignal("Health"):Connect(v76))
	v38:Add(p_u_34.AncestryChanged:Connect(v76))
	v_u_32()
	return v38
end
local function v_u_78() -- name: ReleaseCameraToMenu
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	if not v_u_6.IsTakingOverCamera() then
		v_u_7.setPerspective(false, true)
	end
end
local function v_u_80(p79) -- name: characterAdded
	-- upvalues: (copy) v_u_7, (copy) v_u_78, (copy) v_u_9, (copy) v_u_8
	v_u_7.setPerspective(true, false)
	p79:Add(v_u_78)
	if not v_u_9.IsActive() then
		v_u_8.enableGroup("Gameplay")
	end
	p79:Add(function()
		-- upvalues: (ref) v_u_8
		v_u_8.disableGroup("Gameplay")
	end)
end
local function v84() -- name: RefreshNameTagVisibility
	-- upvalues: (copy) v_u_6, (copy) v_u_4, (copy) v_u_9, (copy) v_u_22
	local v81 = v_u_6.GetPlayer()
	local v82
	if v81 == nil or v81 == v_u_4 then
		v82 = not v_u_9.IsActive()
	else
		v82 = false
	end
	for _, v83 in pairs(v_u_22) do
		v83.Arrow.Enabled = v82
		v83.NameTag.Enabled = v82
	end
end
v_u_6.ListenToSpectate:Connect(v84)
v_u_9.OnActiveChanged:Connect(v84)
local function v_u_125(p_u_85, p_u_86, p87) -- name: observeRemoteCharacter
	-- upvalues: (copy) v_u_17, (copy) v_u_11, (copy) v_u_21, (copy) v_u_32, (copy) v_u_14, (copy) v_u_18, (copy) v_u_12, (copy) v_u_4, (copy) v_u_6, (copy) v_u_9, (copy) v_u_10, (copy) v_u_16, (copy) v_u_77
	local v_u_88 = not p_u_85:IsA("Player")
	local v_u_89 = p_u_85:GetAttribute("Team")
	local v_u_90 = v_u_89 == "Counter-Terrorists" and Color3.fromRGB(0, 75, 200) or (v_u_89 == "Terrorists" and Color3.fromRGB(255, 220, 50) or Color3.fromRGB(255, 255, 255))
	if not v_u_88 then
		v_u_17.TrackCharacter(p_u_85, p_u_86)
		p87:Add(function()
			-- upvalues: (ref) v_u_17, (copy) p_u_85, (copy) p_u_86
			v_u_17.UntrackCharacter(p_u_85, p_u_86)
		end)
	end
	local v_u_91 = workspace:GetAttribute("Gamemode")
	local v_u_92 = v_u_89 == "Terrorists" and true or v_u_89 == "Counter-Terrorists"
	local v_u_93 = v_u_11.new()
	p87:Add(function()
		-- upvalues: (ref) v_u_93, (copy) p_u_85, (ref) v_u_21, (ref) v_u_32
		v_u_93:Destroy()
		local v94 = p_u_85
		if v_u_21[v94] then
			v_u_21[v94]:Destroy()
			v_u_21[v94] = nil
			v_u_32()
		end
	end)
	local function v_u_122() -- name: rebuildRemoteVisuals
		-- upvalues: (ref) v_u_93, (ref) v_u_11, (copy) p_u_86, (ref) v_u_14, (copy) p_u_85, (ref) v_u_21, (ref) v_u_32, (copy) v_u_88, (ref) v_u_18, (copy) v_u_92, (copy) v_u_91, (ref) v_u_12, (copy) v_u_90, (ref) v_u_4, (ref) v_u_6, (ref) v_u_9, (ref) v_u_10, (copy) v_u_89, (ref) v_u_16, (ref) v_u_77
		v_u_93:Destroy()
		v_u_93 = v_u_11.new()
		if p_u_86:GetAttribute("Dead") == true or not v_u_14.isAliveCharacter(p_u_86) then
			local v95 = p_u_85
			if v_u_21[v95] then
				v_u_21[v95]:Destroy()
				v_u_21[v95] = nil
				v_u_32()
			end
		else
			if not v_u_88 then
				local v_u_96 = v_u_18.new(p_u_85, p_u_86)
				v_u_93:Add(function()
					-- upvalues: (copy) v_u_96
					v_u_96:Destroy()
				end)
			end
			if v_u_92 then
				local v97
				if v_u_91 == "Deathmatch" then
					v97 = Enum.HighlightDepthMode.Occluded
				else
					v97 = Enum.HighlightDepthMode.AlwaysOnTop
				end
				local v_u_98 = v_u_93:Add(v_u_12.new(p_u_86, {
					["DepthMode"] = nil,
					["FillColor"] = nil,
					["OutlineColor"] = nil,
					["OutlineTransparency"] = 0.4,
					["FillTransparency"] = 0.7,
					["DepthMode"] = v97,
					["FillColor"] = Color3.fromRGB(255, 255, 255),
					["OutlineColor"] = v_u_90
				}))
				local function v_u_116() -- name: updateHighlightVisible
					-- upvalues: (ref) p_u_86, (ref) p_u_85, (ref) v_u_4, (ref) v_u_6, (copy) v_u_98, (ref) v_u_9
					if p_u_86.Parent then
						local v99 = workspace:GetAttribute("Gamemode")
						local v100 = workspace:GetAttribute("GameState")
						local v101 = p_u_85:GetAttribute("Team")
						local v102 = p_u_86:GetAttribute("Dead") == true
						local v103 = p_u_85:GetAttribute("Invincible") == true
						local v104 = v_u_4:GetAttribute("IsSpectating") == true
						local v105 = v_u_6.GetPlayer()
						local v106
						if v105 then
							v106 = v105:GetAttribute("Team")
						else
							v106 = v105
						end
						local v107 = v_u_6.GetCurrentSpectateInstance()
						local v108
						if v107 == nil then
							v108 = false
						else
							v108 = v107.PerspectiveState == "First-Person"
						end
						local v109 = v105 == p_u_85
						local v110 = v_u_4:GetAttribute("Team") == v101
						if v104 then
							if not v108 then
								v109 = v108
							end
						else
							v109 = v104
						end
						local v111
						if v99 == "Deathmatch" then
							v111 = false
						elseif v104 then
							if v106 == v101 then
								v111 = not v109
							else
								v111 = false
							end
						else
							v111 = v104
						end
						if v110 then
							v104 = v110
						elseif v104 then
							v104 = v106 == v101
						end
						local v112 = v103 and not v109
						if v112 then
							v112 = v99 == "Deathmatch" and true or (v100 == "Warmup" and true or v104)
						end
						local v113
						if v112 and v100 == "Warmup" then
							v113 = Enum.HighlightDepthMode.Occluded
						elseif v99 == "Deathmatch" then
							v113 = Enum.HighlightDepthMode.Occluded
						else
							v113 = Enum.HighlightDepthMode.AlwaysOnTop
						end
						if v_u_98.Highlight and v_u_98.Highlight.Parent then
							v_u_98.Highlight.DepthMode = v113
						end
						if v102 or v_u_9.IsActive() then
							v_u_98.OutlineOnly = false
							v_u_98:UpdateState(false)
						else
							local v114 = v_u_98
							local v115
							if v111 then
								v115 = not v112
							else
								v115 = v111
							end
							v114.OutlineOnly = v115
							v_u_98:UpdateState(v112 or v111)
						end
					else
						return
					end
				end
				v_u_116()
				v_u_93:Add(p_u_85:GetAttributeChangedSignal("Invincible"):Connect(v_u_116))
				v_u_93:Add(v_u_6.ListenToSpectate:Connect(function()
					-- upvalues: (copy) v_u_116
					v_u_116()
				end))
				v_u_93:Add(v_u_9.OnActiveChanged:Connect(function()
					-- upvalues: (copy) v_u_116
					v_u_116()
				end))
				local function v117() -- name: onHighlightInputChanged
					-- upvalues: (copy) v_u_116
					v_u_116()
					return function() end
				end
				for _, v118 in {
					{ v_u_4, "IsSpectating" },
					{ v_u_4, "SpectatePerspective" },
					{ v_u_4, "Team" },
					{ p_u_85, "Team" },
					{ workspace, "GameState" }
				} do
					v_u_93:Add(v_u_10.observeAttribute(v118[1], v118[2], v117))
				end
			end
			local v119 = v_u_89
			local v120
			if (v119 == "Terrorists" and true or v119 == "Counter-Terrorists") and workspace:GetAttribute("Gamemode") ~= "Deathmatch" then
				v120 = v_u_4:GetAttribute("Team") == v119 and true or v_u_16()
			else
				v120 = false
			end
			if v120 then
				v_u_77(p_u_85, p_u_86, v_u_89)
				v_u_93:Add(function()
					-- upvalues: (ref) p_u_85, (ref) v_u_21, (ref) v_u_32
					local v121 = p_u_85
					if v_u_21[v121] then
						v_u_21[v121]:Destroy()
						v_u_21[v121] = nil
						v_u_32()
					end
				end)
			end
		end
	end
	v_u_122()
	p87:Add(p_u_86:GetAttributeChangedSignal("Dead"):Connect(v_u_122))
	local v_u_123 = p_u_86:IsDescendantOf(workspace)
	p87:Add(p_u_86.AncestryChanged:Connect(function()
		-- upvalues: (copy) p_u_86, (ref) v_u_123, (copy) v_u_122
		local v124 = p_u_86:IsDescendantOf(workspace)
		if v124 ~= v_u_123 then
			v_u_123 = v124
			v_u_122()
		end
	end))
	if v_u_4:GetAttribute("IsSpectating") and not v_u_6.GetCurrentSpectateInstance() then
		v_u_6.Next()
	end
end
local v_u_126 = {}
local function v_u_129(p127) -- name: BotShellRemoved
	-- upvalues: (copy) v_u_126
	local v128 = v_u_126[p127]
	if v128 then
		v_u_126[p127] = nil
		v128:Destroy()
	end
end
local function v_u_136(p130) -- name: BotShellAdded
	-- upvalues: (copy) v_u_1, (copy) v_u_126, (copy) v_u_20, (copy) v_u_11, (copy) v_u_21, (copy) v_u_32, (copy) v_u_125
	if p130:IsA("Model") and p130:GetAttribute("Bot") == true then
		local v131 = v_u_1:FindFirstChild("Combatants")
		local v132 = p130:GetAttribute("CombatantId")
		local v_u_133
		if v131 and v132 ~= nil then
			v_u_133 = v131:FindFirstChild((tostring(v132)))
		else
			v_u_133 = nil
		end
		if v_u_133 then
			local v134 = v_u_126[p130]
			if v134 then
				v_u_126[p130] = nil
				v134:Destroy()
			end
			if v_u_20[v_u_133] then
				v_u_20[v_u_133]:Destroy()
			end
			local v_u_135 = v_u_11.new()
			v_u_126[p130] = v_u_135
			v_u_20[v_u_133] = v_u_135
			v_u_135:Add(function()
				-- upvalues: (ref) v_u_20, (copy) v_u_133, (copy) v_u_135
				if v_u_20[v_u_133] == v_u_135 then
					v_u_20[v_u_133] = nil
				end
			end)
			if v_u_21[v_u_133] then
				v_u_21[v_u_133]:Destroy()
				v_u_21[v_u_133] = nil
				v_u_32()
			end
			v_u_125(v_u_133, p130, v_u_135)
		end
	else
		return
	end
end
local v_u_137 = false
local function v_u_140(p138) -- name: BindBotCharacters
	-- upvalues: (ref) v_u_137, (copy) v_u_136, (copy) v_u_129
	if not v_u_137 then
		v_u_137 = true
		p138.ChildAdded:Connect(v_u_136)
		p138.ChildRemoved:Connect(v_u_129)
		for _, v139 in p138:GetChildren() do
			task.spawn(v_u_136, v139)
		end
	end
end
local v141 = workspace:FindFirstChild("Characters")
if v141 then
	v_u_140(v141)
else
	local v_u_142 = nil
	v_u_142 = workspace.ChildAdded:Connect(function(p143)
		-- upvalues: (copy) v_u_140, (ref) v_u_142
		if p143.Name == "Characters" then
			v_u_140(p143)
			if v_u_142 then
				v_u_142:Disconnect()
			end
		end
	end)
end
return v_u_10.observeCharacter(function(p144, p_u_145)
	-- upvalues: (copy) v_u_20, (copy) v_u_11, (copy) v_u_21, (copy) v_u_32, (copy) v_u_4, (copy) v_u_80, (copy) v_u_6, (copy) v_u_7, (copy) v_u_8, (copy) v_u_15, (copy) v_u_16, (copy) v_u_77, (copy) v_u_125
	if v_u_20[p144] then
		v_u_20[p144]:Destroy()
		v_u_20[p144] = nil
	end
	local v_u_146 = v_u_11.new()
	v_u_20[p144] = v_u_146
	if v_u_21[p144] then
		v_u_21[p144]:Destroy()
		v_u_21[p144] = nil
		v_u_32()
	end
	if v_u_4 == p144 then
		v_u_80(v_u_146)
		v_u_146:Add(p_u_145:GetAttributeChangedSignal("Dead"):Connect(function()
			-- upvalues: (copy) p_u_145, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8
			if p_u_145:GetAttribute("Dead") == true then
				if not v_u_6.IsTakingOverCamera() then
					v_u_7.setPerspective(false, true)
				end
				v_u_8.disableGroup("Gameplay")
			end
		end))
		for v147 in pairs(v_u_21) do
			if not v_u_21[v147] then
				continue
			end
			v_u_21[v147]:Destroy()
			v_u_21[v147] = nil
			v_u_32()
		end
		for _, v_u_148 in ipairs(v_u_15.GetAll()) do
			if v_u_148 == v_u_4 then
				continue
			end
			local v149 = v_u_15.Character(v_u_148)
			if not (v149 and v149:IsDescendantOf(workspace)) then
				continue
			end
			local v150 = v_u_148:GetAttribute("Team")
			local v151
			if (v150 == "Terrorists" and true or v150 == "Counter-Terrorists") and workspace:GetAttribute("Gamemode") ~= "Deathmatch" then
				v151 = v_u_4:GetAttribute("Team") == v150 and true or v_u_16()
			else
				v151 = false
			end
			if not v151 then
				continue
			end
			v_u_77(v_u_148, v149, v150)
			if not v_u_20[v_u_148] then
				continue
			end
			v_u_20[v_u_148]:Add(function()
				-- upvalues: (copy) v_u_148, (ref) v_u_21, (ref) v_u_32
				local v152 = v_u_148
				if v_u_21[v152] then
					v_u_21[v152]:Destroy()
					v_u_21[v152] = nil
					v_u_32()
				end
			end)
		end
	else
		v_u_125(p144, p_u_145, v_u_146)
	end
	return function()
		-- upvalues: (copy) v_u_146
		v_u_146:Destroy()
	end
end)
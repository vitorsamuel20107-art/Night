-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.BombPlanted.Bomb
-- ModuleScript | 178 linhas | 6746 bytes | hash 4fe74f77

local v_u_1 = {}
v_u_1.__index = v_u_1
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("HttpService")
local v_u_4 = game:GetService("Players").LocalPlayer
local v_u_5 = require(v_u_2.Controllers.HapticsController)
local v_u_6 = require(v_u_2.Controllers.CameraController)
local v_u_7 = require(v_u_2.Components.Common.CharacterResolver)
local v_u_8 = require(v_u_2.Components.Common.IsTutorialMode)
local v_u_9 = require(v_u_2.Controllers.RunServiceController)
local v_u_10 = require(v_u_2.Database.Security.Router)
local v_u_11 = require(v_u_2.Classes.Sound)
local v_u_12 = require(v_u_2.Shared.Janitor)
local v_u_13 = workspace.CurrentCamera
local v_u_14 = {
	["KillTs"] = true,
	["DefuseB"] = true
}
local function v_u_22(p15) -- name: syncTutorialMarkers
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_14
	local v16 = v_u_4:GetAttribute("TutorialStep")
	local v17 = p15.Model:GetAttribute("Defused")
	local v18 = p15.IsDefused or (v17 ~= nil and v17 ~= false and true or p15.Model:GetAttribute("Exploding") == true)
	local v19 = v_u_8() and not v18
	if v19 then
		v19 = v_u_14[v16] == true
	end
	local v20 = p15.Model:FindFirstChild("TutorialBombOutline")
	if v19 and not v20 then
		local v21 = Instance.new("Highlight")
		v21.Name = "TutorialBombOutline"
		v21.FillTransparency = 1
		v21.OutlineColor = Color3.fromRGB(235, 40, 40)
		v21.OutlineTransparency = 0
		v21.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
		v21.Adornee = p15.Model
		v21.Parent = p15.Model
	elseif not v19 and v20 then
		v20:Destroy()
	end
end
function v_u_1.updateHeartbeat(p23, p24) -- name: updateHeartbeat
	-- upvalues: (copy) v_u_13
	if p23.Model:GetAttribute("IsGettingDefused") then
		p23.Model:SetAttribute("CanDefuse", false)
		return
	elseif p24.PrimaryPart and p23.Model.PrimaryPart then
		if (p24.PrimaryPart.Position - p23.Model.PrimaryPart.Position).Magnitude > 5 then
			p23.Model:SetAttribute("CanDefuse", false)
			return
		else
			local v25 = v_u_13.CFrame.Position
			local v26 = p23.Model.PrimaryPart.Position - v25
			local v27 = v26.Magnitude
			if v27 > 0 then
				local v28 = v26 / v27
				local v29 = v_u_13.CFrame.LookVector:Dot(v28)
				p23.Model:SetAttribute("CanDefuse", v29 >= 0.966)
			else
				p23.Model:SetAttribute("CanDefuse", false)
			end
		end
	else
		return
	end
end
function v_u_1.new(p30) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_12, (copy) v_u_11, (copy) v_u_3, (copy) v_u_9, (copy) v_u_10, (copy) v_u_2, (copy) v_u_7, (copy) v_u_6, (copy) v_u_5, (copy) v_u_4, (copy) v_u_8, (copy) v_u_22
	local v31 = v_u_1
	local v_u_32 = setmetatable({}, v31)
	v_u_32.Janitor = v_u_12.new()
	v_u_32.Sound = v_u_11.new("C4")
	v_u_32.Janitor:Add(function()
		-- upvalues: (copy) v_u_32
		v_u_32.Sound:destroy()
	end)
	v_u_32.Model = p30
	v_u_32.Data = v_u_3:JSONDecode(p30:GetAttribute("BombPlanted"))
	local v33 = v_u_32.Data.Time
	local v34 = typeof(v33) == "number" and v_u_32.Data.Time or workspace:GetServerTimeNow()
	local v35 = v_u_32.Data.TimeUntilExplode
	local v36 = typeof(v35) == "number" and (v_u_32.Data.TimeUntilExplode or 40) or 40
	v_u_32.TimeUntilExplode = math.max(v36, 0.1)
	v_u_32.ExplodeAt = v34 + v_u_32.TimeUntilExplode
	v_u_32.NextBeepAt = workspace:GetServerTimeNow()
	v_u_32.IsDefused = false
	local v37 = v_u_9.CreateBindingName("Observers.Game.BombPlanted")
	v_u_10.broadcastRouter("CreateNotification", "Bomb", "The bomb has been planted.", 2.5)
	for _, v38 in ipairs(v_u_32.Model:GetDescendants()) do
		if not v38:IsA("BasePart") then
			continue
		end
		v38.CanQuery = true
	end
	v_u_32.Janitor:Add(v_u_32.Model:GetAttributeChangedSignal("Defused"):Connect(function()
		-- upvalues: (ref) v_u_10, (copy) v_u_32
		v_u_10.broadcastRouter("Cancel Defuse Bomb")
		v_u_10.broadcastRouter("CreateNotification", "Bomb", "The bomb has been defused.", 2.5)
		v_u_32.IsDefused = true
	end))
	v_u_32.Janitor:Add(v_u_32.Model:GetAttributeChangedSignal("Exploding"):Connect(function()
		-- upvalues: (ref) v_u_10, (ref) v_u_2
		v_u_10.broadcastRouter("Cancel Defuse Bomb")
		local v39 = require(v_u_2.Interface.Screens.Gameplay.Middle.DefuseBomb)
		if v39.SetDefuseBlockedUntil then
			v39.SetDefuseBlockedUntil(workspace:GetServerTimeNow() + 5)
		end
	end))
	v_u_32.Janitor:Add(v_u_32.Model:GetAttributeChangedSignal("Exploded"):Connect(function()
		-- upvalues: (ref) v_u_7, (ref) v_u_6, (copy) v_u_32, (ref) v_u_5
		local v40 = v_u_7.getLocalCharacter()
		if v40 and v_u_7.isAliveCharacter(v40) then
			v_u_6.BombExploded((v_u_32.Model:GetPivot().Position - v40:GetPivot().Position).Magnitude)
			v_u_5.vibrate(Enum.VibrationMotor.Large, 1.5, 0.25)
		end
	end))
	v_u_32.Janitor:Add(v_u_9.BindToHeartbeat(("%*.DefuseCheck"):format(v37), function(_)
		-- upvalues: (ref) v_u_7, (ref) v_u_4, (copy) v_u_32
		local v41 = v_u_7.getLocalCharacter()
		if v_u_7.isAliveCharacter(v41) and v_u_4:GetAttribute("Team") == "Counter-Terrorists" then
			v_u_32:updateHeartbeat(v41)
		end
	end))
	v_u_32.Janitor:Add(v_u_9.BindToHeartbeat(("%*.Beep"):format(v37), function(_)
		-- upvalues: (copy) v_u_32
		local v42 = workspace:GetServerTimeNow()
		local v43 = v_u_32.ExplodeAt - v42
		local v44 = math.max(v43, 0)
		local v45 = v_u_32.Model:FindFirstChild("Weapon")
		if v45 then
			v45 = v_u_32.Model.Weapon:FindFirstChild("FlashingLight")
		end
		if v_u_32.IsDefused or v44 <= 0 then
			if v45 and (v45:FindFirstChild("Attachment") and v45.Attachment:FindFirstChild("PointLight")) then
				local v46 = v45.Attachment.PointLight
				v46.Enabled = not v46.Enabled
			end
		elseif v_u_32.NextBeepAt <= v42 then
			local v47 = v_u_32
			local v48 = v44 / v_u_32.TimeUntilExplode * 0.9 + 0.1
			v47.NextBeepAt = v42 + (v48 <= 0.15 and 0.15 or v48)
			if v45 and (v45:FindFirstChild("Attachment") and v45.Attachment:FindFirstChild("PointLight")) then
				local v49 = v45.Attachment.PointLight
				v49.Enabled = not v49.Enabled
			end
			local v50 = v_u_32.Model.PrimaryPart
			if v50 then
				v_u_32.Sound:play({
					["Parent"] = nil,
					["Name"] = "Beep",
					["Parent"] = v50
				})
			end
		end
	end))
	if v_u_8() then
		local function v51() -- name: sync
			-- upvalues: (ref) v_u_22, (copy) v_u_32
			v_u_22(v_u_32)
		end
		v_u_32.Janitor:Add(v_u_4:GetAttributeChangedSignal("TutorialStep"):Connect(v51))
		v_u_32.Janitor:Add(v_u_32.Model:GetAttributeChangedSignal("Defused"):Connect(v51))
		v_u_32.Janitor:Add(v_u_32.Model:GetAttributeChangedSignal("Exploding"):Connect(v51))
		v_u_32.Janitor:Add(function()
			-- upvalues: (copy) v_u_32
			local v52 = v_u_32.Model:FindFirstChild("TutorialBombOutline")
			if v52 then
				v52:Destroy()
			end
		end)
		v_u_22(v_u_32)
	end
	return v_u_32
end
function v_u_1.destroy(p53) -- name: destroy
	p53.Janitor:Destroy()
end
return v_u_1
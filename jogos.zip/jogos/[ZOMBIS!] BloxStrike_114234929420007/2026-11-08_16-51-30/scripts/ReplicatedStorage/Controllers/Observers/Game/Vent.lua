-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.Vent
-- ModuleScript | 62 linhas | 1735 bytes | hash a7e4a2b8

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Debris")
local v_u_3 = workspace:WaitForChild("Debris")
local v_u_4 = require(v1.Packages.Observers)
local v_u_5 = require(v1.Classes.Sound)
local function v_u_10(p6) -- name: createDuplicateVent
	-- upvalues: (copy) v_u_3
	local v7 = p6:GetPivot()
	local v8 = p6:Clone()
	v8:SetAttribute("Broken", false)
	v8:RemoveTag("Interactable")
	v8:RemoveTag("Vent")
	v8:PivotTo(v7)
	for _, v9 in ipairs(v8:GetChildren()) do
		if not v9:IsA("BasePart") then
			continue
		end
		if v9.Name == "BreakPoint" then
			v9.CanCollide = true
			v9.CanQuery = false
			v9.Transparency = 0
		else
			v9:Destroy()
		end
	end
	v8.Parent = v_u_3
	return v8
end
local function v_u_18(p11) -- name: createBreakPoints
	-- upvalues: (copy) v_u_2, (copy) v_u_5
	local v12 = p11:GetPivot().Position
	local v13 = p11:GetAttribute("Direction")
	for _, v14 in ipairs(p11:GetChildren()) do
		if not v14:IsA("BasePart") then
			continue
		end
		v14.CollisionGroup = "Debris"
		v14.Anchored = false
		local v15 = v13.X * math.random(15, 20)
		local v16 = v13.Y * math.random(15, 20)
		local v17 = v13.Z * math.random(15, 20)
		v14:ApplyImpulse((Vector3.new(v15, v16, v17)))
	end
	v_u_2:AddItem(p11, 5)
	v_u_5.new("Bullet"):PlaySoundAtPosition({
		["Name"] = "Break Metal Vent",
		["Class"] = "Bullet",
		["Position"] = nil,
		["Position"] = v12
	})
end
return v_u_4.observeTag("Vent", function(p_u_19)
	-- upvalues: (copy) v_u_4, (copy) v_u_10, (copy) v_u_18
	if p_u_19:IsDescendantOf(workspace) then
		return v_u_4.observeAttribute(p_u_19, "Broken", function(p20)
			-- upvalues: (ref) v_u_10, (copy) p_u_19, (ref) v_u_18
			if p20 then
				v_u_18((v_u_10(p_u_19)))
			end
		end)
	end
end)
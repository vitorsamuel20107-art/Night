-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.FireFlicker
-- ModuleScript | 173 linhas | 5253 bytes | hash 1ab4f378

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Workspace")
local v_u_3 = require(v1.Controllers.RunServiceController)
local v_u_4 = require(v1.Controllers.GraphicsQualityController)
local v5 = require(v1.Packages.Observers)
local v_u_6 = require(v1.Shared.Janitor)
local v_u_7 = Color3.fromRGB(255, 170, 95)
local v_u_8 = Color3.fromRGB(255, 96, 32)
local v_u_9 = {}
local v_u_10 = nil
local v_u_11 = 0
local function v_u_20(p12, p13, p14) -- name: addLight
	local v15 = p13.Parent
	if not p14 or (v15 == p14 or not (v15 and v15:IsA("BasePart"))) then
		v15 = nil
	end
	local v16 = p12.Lights
	local v17 = {
		["Light"] = p13,
		["BaseBrightness"] = p13.Brightness,
		["BaseColor"] = p13.Color,
		["Seed"] = math.random() * 100,
		["Holder"] = v15
	}
	if v15 then
		v15 = v15.CFrame
	end
	v17.HolderCFrame = v15
	table.insert(v16, v17)
	local v18 = p13.Parent
	local v19
	if v18 and v18:IsA("Attachment") then
		v19 = v18.WorldPosition
	elseif v18 and v18:IsA("BasePart") then
		v19 = v18.Position
	else
		v19 = nil
	end
	if v19 then
		p12.PositionSum = p12.PositionSum + v19
		p12.PositionCount = p12.PositionCount + 1
		p12.Centre = p12.PositionSum / p12.PositionCount
	end
end
local function v_u_26(p21, p22) -- name: addCoal
	local v23 = p22.Parent
	local v24 = p21.Coals
	local v25 = {
		["Appearance"] = p22,
		["BaseEmissive"] = v23:GetAttribute("BaseEmissive") or p22.EmissiveStrength,
		["AuthoredEmissive"] = p22.EmissiveStrength,
		["Seed"] = math.random() * 100
	}
	table.insert(v24, v25)
end
local function v_u_30(p27) -- name: restoreFire
	for _, v28 in p27.Lights do
		v28.Light.Brightness = v28.BaseBrightness
		v28.Light.Color = v28.BaseColor
		if not (v28.Holder and v28.HolderCFrame) then
			continue
		end
		v28.Holder.CFrame = v28.HolderCFrame
	end
	for _, v29 in p27.Coals do
		v29.Appearance.EmissiveStrength = v29.AuthoredEmissive
	end
end
local function v_u_54(p31) -- name: stepFires
	-- upvalues: (ref) v_u_11, (copy) v_u_2, (copy) v_u_9, (copy) v_u_8, (copy) v_u_7
	v_u_11 = v_u_11 + p31
	if v_u_11 < 0.03333333333333333 then
		return
	else
		v_u_11 = 0
		local v32 = v_u_2.CurrentCamera
		if v32 then
			local v33 = v32.CFrame.Position
			local v34 = os.clock()
			local v35 = math.noise(v34 * 1.1, 0.3) * 0.5 + math.noise(v34 * 3.7, 1.7) * 0.3
			for _, v36 in v_u_9 do
				if (v33 - v36.Centre).Magnitude > 300 then
					continue
				end
				for _, v37 in v36.Coals do
					local v38 = 0.8 + v35 * 0.25 + math.noise(v34 * 0.7, v37.Seed) * 0.35
					local v39 = math.clamp(v38, 0.45, 1.3)
					v37.Appearance.EmissiveStrength = v37.BaseEmissive * v39
				end
				for _, v40 in v36.Lights do
					local v41 = v40.Seed
					local v42 = 1 + v35 * 0.45 + math.noise(v34 * 8.3, v41) * 0.25
					local v43 = math.clamp(v42, 0.55, 1.4)
					local v44 = v40.Light
					v44.Brightness = v40.BaseBrightness * v43
					local v45 = v_u_8
					local v46 = v_u_7
					local v47 = (v43 - 0.6) / 0.7
					v44.Color = v45:Lerp(v46, (math.clamp(v47, 0, 1)))
					local v48 = v40.Holder
					local v49 = v40.HolderCFrame
					if not (v48 and v49) then
						continue
					end
					local v50 = math.noise(v34 * 2.1, v41, 1)
					local v51 = math.noise(v34 * 2.6, v41, 2) * 0.6
					local v52 = math.noise
					local v53 = v34 * 2.3
					v48.CFrame = v49 + Vector3.new(v50, v51, v52(v53, v41, 3)) * 0.35
				end
			end
		end
	end
end
local function v_u_62(p_u_55, p_u_56, p57) -- name: observeFireModel
	-- upvalues: (copy) v_u_20, (copy) v_u_26
	local function v60(p58) -- name: onDescendant
		-- upvalues: (ref) v_u_20, (copy) p_u_56, (copy) p_u_55, (ref) v_u_26
		if p58:IsA("Light") and not p58:HasTag("FireFlicker") then
			v_u_20(p_u_56, p58, p_u_55)
		elseif p58:IsA("SurfaceAppearance") then
			local v59 = p58.Parent
			if v59 then
				v59 = v59.Parent
			end
			if v59 and (v59.Name == "CoalBeds" and v59.Parent == p_u_55) then
				v_u_26(p_u_56, p58)
			end
		end
	end
	for _, v61 in p_u_55:GetDescendants() do
		v60(v61)
	end
	p57:Add(p_u_55.DescendantAdded:Connect(v60))
end
return v5.observeTag("FireFlicker", function(p_u_63)
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_20, (copy) v_u_62, (copy) v_u_9, (ref) v_u_10, (copy) v_u_3, (copy) v_u_54, (copy) v_u_30, (ref) v_u_11
	return v_u_4.RunAnimatedProp(function()
		-- upvalues: (ref) v_u_6, (copy) p_u_63, (ref) v_u_20, (ref) v_u_62, (ref) v_u_9, (ref) v_u_10, (ref) v_u_3, (ref) v_u_54, (ref) v_u_30, (ref) v_u_11
		local v_u_64 = v_u_6.new()
		local v_u_65 = {
			["Lights"] = nil,
			["Coals"] = nil,
			["Centre"] = Vector3.new(0, 0, 0),
			["PositionSum"] = Vector3.new(0, 0, 0),
			["PositionCount"] = 0,
			["Lights"] = {},
			["Coals"] = {}
		}
		if p_u_63:IsA("Light") then
			v_u_20(v_u_65, p_u_63, nil)
		else
			v_u_62(p_u_63, v_u_65, v_u_64)
		end
		v_u_9[p_u_63] = v_u_65
		if not v_u_10 then
			v_u_10 = v_u_3.BindToHeartbeat("Observers.Game.FireFlicker.Update", v_u_54)
		end
		return function()
			-- upvalues: (copy) v_u_64, (ref) v_u_9, (ref) p_u_63, (ref) v_u_30, (copy) v_u_65, (ref) v_u_10, (ref) v_u_11
			v_u_64:Destroy()
			v_u_9[p_u_63] = nil
			v_u_30(v_u_65)
			if next(v_u_9) == nil then
				if v_u_10 then
					v_u_10:Disconnect()
					v_u_10 = nil
				end
				v_u_11 = 0
			end
		end
	end)
end, { v_u_2 })
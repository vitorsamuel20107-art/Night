-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.TugBoat
-- ModuleScript | 52 linhas | 1798 bytes | hash 59a6d13c

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Controllers.RunServiceController)
local v3 = require(v1.Packages.Observers)
local v_u_4 = require(v1.Controllers.GraphicsQualityController)
local v_u_5 = require(v1.Shared.Janitor)
local function v_u_25(p6, p7, p8, p9) -- name: UpdateBoat
	p8[1] = p8[1] + p7
	if p6:IsDescendantOf(workspace) then
		if not p9[1] then
			p9[1] = p6.CFrame
		end
		local v10 = p9[1]
		local v11 = p8[1]
		local v12 = v11 * 0.8
		local v13 = math.sin(v12) * 0.05235987755982989
		local v14 = v11 * 0.8 * 0.7
		local v15 = math.cos(v14) * 0.05235987755982989 * 0.8
		local v16 = v11 * 0.5
		local v17 = math.sin(v16) * 0.15
		local v18 = v11 * 1.2
		local v19 = math.sin(v18) * 0.1
		local v20 = v10.LookVector * v17 + Vector3.new(0, v19, 0)
		local v21 = v10.Position + v20
		local v22 = CFrame.Angles(v13, 0, 0)
		local v23 = CFrame.Angles(0, 0, v15)
		local v24 = v10 * v22 * v23
		p6.CFrame = v24 + (v21 - v24.Position)
	end
end
return v3.observeTag("TugBoat", function(p26)
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_2, (copy) v_u_25
	if p26:IsDescendantOf(workspace) then
		local v_u_27 = p26:WaitForChild("Handle", 10)
		if v_u_27 and p26:IsDescendantOf(workspace) then
			return v_u_4.RunAnimatedProp(function()
				-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_25, (copy) v_u_27
				local v_u_28 = v_u_5.new()
				local v_u_29 = { nil }
				local v_u_30 = { 0 }
				local v31 = v_u_2.CreateBindingName("Observers.Game.TugBoat.Update")
				v_u_28:Add(v_u_2.BindToHeartbeat(v31, function(p32)
					-- upvalues: (ref) v_u_25, (ref) v_u_27, (copy) v_u_30, (copy) v_u_29
					v_u_25(v_u_27, p32, v_u_30, v_u_29)
				end))
				return function()
					-- upvalues: (copy) v_u_28
					v_u_28:Destroy()
				end
			end)
		end
	end
end)
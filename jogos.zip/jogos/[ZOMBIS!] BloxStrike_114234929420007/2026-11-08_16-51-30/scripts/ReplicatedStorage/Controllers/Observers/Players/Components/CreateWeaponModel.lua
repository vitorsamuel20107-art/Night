-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Players.Components.CreateWeaponModel
-- ModuleScript | 915 linhas | 24903 bytes | hash 6060b0de

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("HttpService")
local v3 = game:GetService("Players")
local v_u_4 = v1.Assets.Other
local v_u_5 = v1:WaitForChild("Assets"):WaitForChild("MuzzleFlashes"):WaitForChild("Character")
require(v1.Database.Custom.Types)
local v_u_6 = require(v1.Components.Common.GetWeaponProperties)
local v_u_7 = require(v1.Components.Common.CharacterResolver)
local v_u_8 = require(v1.Components.Common.VFXLibary.CreateMuzzleFlash.GetMuzzleFlash)
local v_u_9 = require(v1.Components.Common.ThirdPersonWeaponStash)
local v_u_10 = require(v1.Shared.DebugFlags)
local v_u_11 = require(v1.Database.Components.Libraries.Skins)
local v_u_12 = require(v1.Database.Custom.GameStats.Character.Attachments)
local v_u_13 = { "PrimaryAttachment", "SecondaryAttachment", "MeleeAttachment" }
local v_u_14 = {
	["MuzzlePartL"] = 1,
	["MuzzlePartR"] = 1,
	["MuzzlePart"] = 1,
	["RootPart"] = 1,
	["Hitbox"] = 1,
	["Insert"] = 1,
	["move"] = 1
}
local v_u_15 = CFrame.new(0, -0.4, 0.24) * CFrame.Angles(0, 3.141592653589793, 0)
local v_u_16 = CFrame.new(0, 0.2, 0.8) * CFrame.Angles(1.5707963267948966, 0.20943951023931956, 0.17453292519943295)
local v_u_17 = {}
local v_u_18 = {}
local function v_u_22(p19, p20, ...) -- name: dlog
	-- upvalues: (copy) v_u_10
	if v_u_10.IsEnabled("ThirdPersonWeaponModels") then
		local v21 = not p19 and "[ThirdPersonWeaponModels] " or "[ThirdPersonWeaponModels] " .. p19.Name .. " - "
		warn(v21 .. p20:format(...))
	end
end
local function v_u_26(p23) -- name: GetUpperTorso
	local v24 = p23:FindFirstChild("HumanoidRootPart") or p23:WaitForChild("HumanoidRootPart", 10)
	if v24 and v24:IsA("BasePart") then
		local v25 = p23:FindFirstChild("UpperTorso") or p23:WaitForChild("UpperTorso", 10)
		if v25 and v25:IsA("BasePart") then
			return v25
		else
			return nil
		end
	else
		return nil
	end
end
local function v_u_30(p27) -- name: SetWeaponProperties
	-- upvalues: (copy) v_u_14
	for _, v28 in ipairs(p27:GetDescendants()) do
		if not v28:IsA("BasePart") then
			continue
		end
		v28.CollisionGroup = "WeaponModel"
		v28.CastShadow = false
		v28.CanCollide = false
		v28.CanTouch = false
		v28.CanQuery = false
		v28.Anchored = false
		v28.Massless = true
		local v29 = v_u_14[v28.Name]
		if not v29 then
			continue
		end
		v28.Transparency = v29
	end
end
local function v_u_35(p31, p32, p33) -- name: SetModelVisible
	-- upvalues: (copy) v_u_14
	if p33 then
		p33 = p31:GetAttribute("SpectatedFirstPerson") ~= true
	end
	for _, v34 in ipairs(p32:GetDescendants()) do
		if not v34:IsA("BasePart") then
			continue
		end
		v34.Transparency = v_u_14[v34.Name] or (p33 and 0 or 1)
	end
end
local function v_u_42(p36, p37) -- name: CreateWeldForWeapon
	local v38 = p37.Parent
	if not (v38 and v38:IsA("BasePart")) then
		error((("Character attachment parent is not a BasePart: %*"):format(p37.Name)))
	end
	local v39 = p36:FindFirstChild("Insert", true) or p36.PrimaryPart
	if not v39 then
		error("Weapon model has no PrimaryPart or Insert part")
	end
	local v40 = v39:FindFirstChild("WeaponAttachment")
	if not v40 then
		v40 = Instance.new("Attachment")
		v40.Name = "WeaponAttachment"
		v40.Parent = v39
	end
	p36:PivotTo(v38.CFrame * p37.CFrame * v40.CFrame:Inverse() * v39.CFrame:Inverse() * p36:GetPivot())
	local v41 = Instance.new("Weld")
	v41.Name = "HolsterWeld"
	v41.Part0 = v38
	v41.Part1 = v39
	v41.C0 = p37.CFrame
	v41.C1 = v40.CFrame
	v41.Parent = v39
end
local function v_u_47(p43) -- name: GetPlayerAttachmentsFolder
	-- upvalues: (copy) v_u_7
	local v44 = v_u_7.getPlayerCharacter(p43)
	if not v44 then
		return nil
	end
	local v45 = v44:FindFirstChild("WeaponAttachments")
	if v45 and v45:IsA("Folder") then
		return v45
	end
	if v45 then
		v45:Destroy()
	end
	local v46 = Instance.new("Folder")
	v46.Name = "WeaponAttachments"
	v46.Parent = v44
	return v46
end
local function v_u_53(p48, p49) -- name: GetOrCreateCharacterFolder
	local v50 = nil
	for _, v51 in ipairs(p48:GetChildren()) do
		if v51.Name ~= p49 then
			continue
		end
		if v51:IsA("Folder") and not v50 then
			v50 = v51
		else
			if not v51 then
				continue
			end
			v51:Destroy()
		end
	end
	if v50 then
		return v50
	end
	local v52 = Instance.new("Folder")
	v52.Name = p49
	v52.Parent = p48
	return v52
end
local function v_u_58(p54) -- name: ToModelWithPrimaryPart
	local v55 = p54:Clone()
	local v56
	if v55:IsA("Model") then
		v56 = v55
	else
		v56 = Instance.new("Model")
		v55.Parent = v56
	end
	local v57 = v56.PrimaryPart or v56:FindFirstChildWhichIsA("BasePart", true)
	if v57 then
		if not v56.PrimaryPart then
			v56.PrimaryPart = v57
		end
		return v56
	else
		if v56 then
			v56:Destroy()
		end
		return nil
	end
end
local function v_u_65(p59, p60, p61) -- name: GetOrCreateTorsoAttachment
	-- upvalues: (copy) v_u_26
	local v62 = p59:FindFirstChild(p60, true)
	if v62 and v62:IsA("Attachment") then
		v62.CFrame = p61
		return v62
	end
	local v63 = v_u_26(p59)
	if not v63 then
		return nil
	end
	local v64 = Instance.new("Attachment")
	v64.Name = p60
	v64.CFrame = p61
	v64.Parent = v63
	return v64
end
local function v_u_74(p66, p67) -- name: CreateObjectiveKitHolsterModel
	-- upvalues: (copy) v_u_4, (copy) v_u_22, (copy) v_u_15, (copy) v_u_65, (copy) v_u_58, (copy) v_u_30, (copy) v_u_42, (copy) v_u_47
	local v68 = v_u_4:FindFirstChild("DefuseKit")
	if not v68 then
		v_u_22(p66, "objective kit holster skipped: missing template Assets.Other.DefuseKit")
		return nil
	end
	local v69 = p67:FindFirstChild("BodyBackAttachment", true)
	local v70
	if v69 and v69:IsA("Attachment") then
		v70 = v69.CFrame * v_u_15
	else
		v70 = v_u_15
	end
	local v71 = v_u_65(p67, "ObjectiveKitAttachment", v70)
	if not v71 then
		v_u_22(p66, "objective kit holster skipped: no valid character attachment")
		return nil
	end
	local v72 = v_u_58(v68)
	if not v72 then
		v_u_22(p66, "objective kit holster skipped: template has no BasePart")
		return nil
	end
	v_u_30(v72)
	v_u_42(v72, v71)
	local v73 = v_u_47(p66)
	if not v73 then
		if v72 then
			v72:Destroy()
		end
		return nil
	end
	v72.Name = "ObjectiveKitHolster"
	v72.Parent = v73
	return v72
end
local function v_u_81(p75, p76) -- name: DestroyObjectiveKitHolsters
	-- upvalues: (copy) v_u_7
	local v77 = p76.ObjectiveKitHolsterModel
	if v77 then
		v77:Destroy()
	end
	p76.ObjectiveKitHolsterModel = nil
	local v78 = v_u_7.getPlayerCharacter(p75)
	local v79
	if v78 then
		v79 = v78:FindFirstChild("WeaponAttachments")
	else
		v79 = nil
	end
	if v79 then
		for _, v80 in ipairs(v79:GetChildren()) do
			if not v80:IsA("Model") or (v80.Name ~= "ObjectiveKitHolster" or not v80) then
				continue
			end
			v80:Destroy()
		end
	end
end
local function v_u_87(p82, p83) -- name: UpdateObjectiveKitHolster
	-- upvalues: (copy) v_u_17, (copy) v_u_81, (copy) v_u_74
	local v84 = v_u_17[p82] or {
		["Character"] = nil
	}
	v_u_17[p82] = v84
	local v85
	if p82:GetAttribute("Team") == "Counter-Terrorists" then
		v85 = p82:GetAttribute("HasDefuseKit") == true and true or p82:GetAttribute("HasRescueKit") == true
	else
		v85 = false
	end
	local v86 = v84.ObjectiveKitHolsterModel
	if not (v85 and (v86 and v86.Parent)) then
		v_u_81(p82, v84)
		if v85 then
			v84.ObjectiveKitHolsterModel = v_u_74(p82, p83)
		end
	end
end
local function v_u_94(p88, p89, p90) -- name: CreateBombHolsterModel
	-- upvalues: (copy) v_u_65, (copy) v_u_16, (copy) v_u_22, (copy) v_u_11, (copy) v_u_30, (copy) v_u_42, (copy) v_u_47
	local v91 = v_u_65(p89, "BombAttachment", v_u_16)
	if not v91 then
		v_u_22(p88, "bomb holster skipped: no valid character attachment (missing UpperTorso)")
		return nil
	end
	local v92 = v_u_11.GetCharacterModel("C4", p90.Skin or "", p90.Float, p90.StatTrack, p90.NameTag, false, p90.Stickers)
	if not v92 then
		v_u_22(p88, "bomb holster skipped: SkinHandler returned nil for C4")
		return nil
	end
	v_u_30(v92)
	v_u_42(v92, v91)
	local v93 = v_u_47(p88)
	if not v93 then
		if v92 then
			v92:Destroy()
		end
		return nil
	end
	v92.Name = "BombHolster"
	v92.Parent = v93
	return v92
end
local function v_u_105(p95, p96, p97) -- name: UpdateBombHolster
	-- upvalues: (copy) v_u_17, (copy) v_u_2, (copy) v_u_94, (copy) v_u_35
	local v98 = v_u_17[p95] or {
		["Character"] = nil
	}
	v_u_17[p95] = v98
	local v99 = p95:GetAttribute("Slot5")
	local v100
	if v99 then
		v100 = v_u_2:JSONDecode(v99)
	else
		v100 = nil
	end
	if v100 and v100.Weapon == "C4" then
		local v101 = v98.BombHolsterModel
		if not (v101 and v101.Parent) then
			local v102 = v98.BombHolsterModel
			if v102 then
				v102:Destroy()
			end
			v98.BombHolsterModel = nil
			v98.BombHolsterVisible = nil
			v101 = v_u_94(p95, p96, v100)
			v98.BombHolsterModel = v101
		end
		if p97 then
			p97 = p97.Name == "C4"
		end
		local v103 = not p97
		if v101 and v98.BombHolsterVisible ~= v103 then
			v_u_35(p96, v101, v103)
			v98.BombHolsterVisible = v103
		end
	else
		local v104 = v98.BombHolsterModel
		if v104 then
			v104:Destroy()
		end
		v98.BombHolsterModel = nil
		v98.BombHolsterVisible = nil
	end
end
local function v_u_125(p106, p107, p108, p109, p110) -- name: CacheWeaponCharacterModel
	-- upvalues: (copy) v_u_11, (copy) v_u_22, (copy) v_u_30, (copy) v_u_13, (copy) v_u_42, (copy) v_u_47, (copy) v_u_17, (copy) v_u_35
	local v111 = p109.Weapon
	local v112 = p109.Skin
	local v113 = v_u_11.GetCharacterModel
	local v114 = p109.Float
	local v115 = p109.StatTrack
	local v116 = p109.NameTag
	local v117 = false
	local v118 = p109.Stickers
	local v119
	if v111 == "Smoke Grenade" then
		v119 = p106:GetAttribute("Team")
		if v119 ~= "Counter-Terrorists" and v119 ~= "Terrorists" then
			v119 = nil
		end
	else
		v119 = nil
	end
	local v120 = v113(v111, v112, v114, v115, v116, v117, v118, v119)
	if v120 then
		v_u_30(v120)
		local v121 = v_u_13[p108]
		local v122
		if v121 then
			v122 = p107:FindFirstChild(v121, true)
		else
			v122 = nil
		end
		if not v122 then
			v_u_22(p106, "missing character attachment for slot=%d weapon=%s (expected %s)", p108, v111, (tostring(v121)))
			error((("Missing character attachment for slot: %*"):format(p108)))
		end
		v_u_42(v120, v122)
		local v123 = v_u_47(p106)
		if v123 then
			v120.Parent = v123
			v120.Name = v111
		end
		local v124 = v_u_17[p106] or {
			["Character"] = nil
		}
		v_u_17[p106] = v124
		v124[p108] = {
			["StatTrack"] = p109.StatTrack,
			["Stickers"] = p109.Stickers,
			["NameTag"] = p109.NameTag,
			["Model"] = v120,
			["Float"] = p109.Float,
			["Charm"] = p109.Charm,
			["Weapon"] = v111,
			["Skin"] = v112,
			["Visible"] = p110
		}
		v_u_22(p106, "cached holster slot=%d weapon=%s skin=%s visible=%s", p108, v111, v112, "unknown")
		v_u_35(p107, v120, p110)
	else
		v_u_22(p106, "holster skipped: SkinHandler returned nil for slot=%d weapon=%s skin=%s", p108, v111, v112)
	end
end
local function v_u_131(p126) -- name: DestroyEquippedModels
	local v127 = p126.EquippedModels
	if v127 then
		for _, v128 in pairs(v127) do
			for _, v129 in v128.Motors do
				v129:Destroy()
			end
			local v130 = v128.Model
			if not v130 then
				break
			end
			v130:Destroy()
		end
	end
	p126.EquippedModels = nil
	p126.ActiveEquipped = nil
end
local function v_u_144(p132) -- name: ClearPlayerCache
	-- upvalues: (copy) v_u_18, (copy) v_u_17, (copy) v_u_131, (copy) v_u_22
	local v133 = v_u_18[p132]
	if v133 then
		for _, v134 in v133 do
			v134:Disconnect()
		end
		v_u_18[p132] = nil
	end
	local v135 = v_u_17[p132]
	if v135 then
		local v136 = v135.Character
		v_u_131(v135)
		local v137 = v135.ObjectiveKitHolsterModel
		if v137 then
			v137:Destroy()
		end
		v135.ObjectiveKitHolsterModel = nil
		local v138 = v135.BombHolsterModel
		if v138 then
			v138:Destroy()
		end
		v135.BombHolsterModel = nil
		v135.BombHolsterVisible = nil
		for v139, v140 in pairs(v135) do
			if typeof(v139) ~= "number" or typeof(v140) ~= "table" then
				continue
			end
			local v141 = v140.Model
			if v141 then
				v141:Destroy()
			end
			v135[v139] = nil
		end
		if v136 then
			for _, v142 in { "WeaponModel", "WeaponAttachments" } do
				local v143 = v136:FindFirstChild(v142)
				if not (v143 and v143:IsA("Folder")) then
					continue
				end
				v143:ClearAllChildren()
			end
		end
	end
	v_u_22(p132, "cleared player cache (destroyed holsters)")
	v_u_17[p132] = nil
end
local function v_u_151(p145, p146) -- name: RefreshHolsterVisibility
	-- upvalues: (copy) v_u_17, (copy) v_u_35
	local v147 = v_u_17[p145]
	if v147 and v147.Character == p146 then
		for v148, v149 in pairs(v147) do
			if typeof(v148) ~= "number" or (typeof(v149) ~= "table" or (not v149.Model or v149.Visible == nil)) then
				continue
			end
			v_u_35(p146, v149.Model, v149.Visible)
		end
		local v150 = v147.BombHolsterModel
		if v150 and v147.BombHolsterVisible ~= nil then
			v_u_35(p146, v150, v147.BombHolsterVisible)
		end
	end
end
local function v_u_161(p_u_152, p_u_153) -- name: InitializePlayerCache
	-- upvalues: (copy) v_u_17, (copy) v_u_144, (copy) v_u_18, (copy) v_u_151, (copy) v_u_131
	local v154 = v_u_17[p_u_152] or {
		["Character"] = nil
	}
	v_u_17[p_u_152] = v154
	if v154.Character ~= p_u_153 then
		if v154.Character then
			v_u_144(p_u_152)
			v154 = v_u_17[p_u_152] or {
				["Character"] = nil
			}
			v_u_17[p_u_152] = v154
		end
		v154.Character = p_u_153
		local v155 = v_u_18[p_u_152]
		if v155 then
			for _, v156 in v155 do
				v156:Disconnect()
			end
			v_u_18[p_u_152] = nil
		end
		v_u_18[p_u_152] = { p_u_153:GetAttributeChangedSignal("SpectatedFirstPerson"):Connect(function()
				-- upvalues: (ref) v_u_151, (copy) p_u_152, (copy) p_u_153
				v_u_151(p_u_152, p_u_153)
			end), (p_u_153.AncestryChanged:Connect(function(_, p157)
				-- upvalues: (ref) v_u_17, (copy) p_u_152, (ref) v_u_131
				local v158 = v_u_17[p_u_152]
				if not p157 and v158 then
					v_u_131(v158)
					v158.ObjectiveKitHolsterModel = nil
					v158.BombHolsterModel = nil
					for v159, v160 in pairs(v158) do
						if typeof(v159) ~= "number" or typeof(v160) ~= "table" then
							continue
						end
						v158[v159] = nil
					end
					v158.Character = nil
				end
			end)) }
	end
end
local function v_u_176(p162, p163, p164, p165, p166) -- name: UpdateCachedWeapon
	-- upvalues: (copy) v_u_6, (copy) v_u_17, (copy) v_u_35, (copy) v_u_22, (copy) v_u_125
	local v167 = v_u_6(p165.Weapon)
	if not v167 or v167.ShootingOptions ~= "Dual" then
		local v168 = v_u_17[p162] or {
			["Character"] = nil
		}
		v_u_17[p162] = v168
		local v169 = v168[p164]
		local v170 = p165.Weapon
		local v171 = p165.Skin
		local v172
		if v170 == p166.Name then
			v172 = v171 == p166.Skin
		else
			v172 = false
		end
		local v173 = not v172
		if v169 then
			local v174
			if v169.Skin == p165.Skin then
				v174 = v169.Weapon == p165.Weapon
			else
				v174 = false
			end
			if v174 and v169.Model then
				if v169.Visible ~= v173 then
					v_u_35(p163, v169.Model, v173)
					v169.Visible = v173
				end
				return
			end
			local v175 = v169.Model
			if v175 then
				v175:Destroy()
			end
		end
		v168[p164] = nil
		v_u_22(p162, "holster slot=%d weapon=%s skin=%s equippedInHand=%s", p164, p165.Weapon, p165.Skin, (tostring(v172)))
		v_u_125(p162, p163, p164, p165, v173)
	end
end
local function v_u_187(p177, p178, p179, p180) -- name: CreateCharacterWeapons
	-- upvalues: (copy) v_u_161, (copy) v_u_17, (copy) v_u_176, (copy) v_u_87, (copy) v_u_105
	v_u_161(p177, p178)
	local v181 = v_u_17[p177] or {
		["Character"] = nil
	}
	v_u_17[p177] = v181
	for v182 = 1, 3 do
		local v183 = v181[v182]
		if p180[v182] or not v183 then
			continue
		end
		local v184 = v183.Model
		if v184 then
			v184:Destroy()
		end
		v181[v182] = nil
	end
	for v185, v186 in pairs(p180) do
		if not v186 then
			continue
		end
		v_u_176(p177, p178, v185, v186, p179)
	end
	v_u_87(p177, p178)
	v_u_105(p177, p178, p179)
end
local function v_u_192(p188, p189) -- name: ResolveWeaponBindPart
	if p189 then
		local v190 = p188:FindFirstChild(p189, true)
		if v190 and v190:IsA("BasePart") then
			return v190
		end
	end
	if p188.PrimaryPart then
		return p188.PrimaryPart
	else
		local v191 = p188:FindFirstChild("Insert", true)
		if v191 and v191:IsA("BasePart") then
			return v191
		else
			return p188:FindFirstChildWhichIsA("BasePart", true)
		end
	end
end
local function v_u_204(p193, p194, p195) -- name: CreateMotor6DAttachment
	-- upvalues: (copy) v_u_192, (copy) v_u_9
	local v196 = v_u_192(p194, p195)
	if not v196 then
		warn((("CreateMotor6DAttachment: no bindable part on \"%*\", skipping attachment"):format(p194.Name)))
		return nil
	end
	local v197 = CFrame.identity
	local v198 = CFrame.identity
	local v199 = p194:FindFirstChild("Properties")
	if v199 then
		for _, v200 in ipairs(p195 and { "LEFT", "RIGHT" } or { "" }) do
			local v201 = v199:FindFirstChild("C0" .. v200)
			if v201 then
				v197 = v201.Value
			end
			local v202 = v199:FindFirstChild("C1" .. v200)
			if not v202 then
				continue
			end
			v198 = v202.Value
		end
	end
	v_u_9.PoseForJoint(p194, v196, p193, v197, v198)
	local v203 = Instance.new("Motor6D")
	v203.Name = "WeaponAttachment" .. (p195 or "")
	v203.C0 = v197
	v203.C1 = v198
	v203.Part0 = p193
	v203.Part1 = v196
	v203.Parent = p193
	return v203
end
local function v_u_212(p205, p206) -- name: CreateDualMotor6DAttachments
	-- upvalues: (copy) v_u_204
	local v207 = p205:FindFirstChild("RightHand")
	local v208 = p205:FindFirstChild("LeftHand")
	if not (v207 and v208) then
		warn("CreateDualMotor6DAttachments: Could not find RightHand or LeftHand for dual weapon")
		return {}
	end
	local v209 = {}
	local v210 = v_u_204(v207, p206, "HandleR")
	if v210 then
		table.insert(v209, v210)
	end
	local v211 = v_u_204(v208, p206, "HandleL")
	if v211 then
		table.insert(v209, v211)
	end
	return v209
end
local function v_u_218(p213, p214, p215, p216) -- name: CreateEquippedMotors
	-- upvalues: (copy) v_u_212, (copy) v_u_204
	if p216 then
		return v_u_212(p213, p215)
	end
	local v217 = v_u_204(p214, p215, nil)
	return v217 and { v217 } or {}
end
local function v_u_234(p219, p220) -- name: GetEquippedModelKey
	-- upvalues: (copy) v_u_2
	local v221 = p220.Stickers
	local v222 = table.concat
	local v223 = {}
	local v224 = p220.Name
	local v225 = p220.Skin
	local v226 = p220.Float
	local v227 = tostring(v226)
	local v228 = p220.StatTrack
	local v229 = tostring(v228)
	local v230 = p220.NameTag
	local v231 = tostring(v230)
	local v232 = typeof(v221) ~= "table" and "" or v_u_2:JSONEncode(v221)
	local v233
	if p220.Name == "Smoke Grenade" then
		v233 = p219:GetAttribute("Team")
		if v233 ~= "Counter-Terrorists" and v233 ~= "Terrorists" then
			v233 = nil
		end
	else
		v233 = nil
	end
	__set_list(v223, 1, {v224, v225, v227, v229, v231, v232, (tostring(v233))})
	return v222(v223, "|")
end
local function v_u_242(p235) -- name: EvictEquippedModels
	local v236 = 0
	local v237 = (1 / 0)
	local v238 = nil
	for v239, v240 in pairs(p235) do
		v236 = v236 + 1
		if v240.LastUsed >= v237 then
			continue
		end
		v237 = v240.LastUsed
		v238 = v239
	end
	if v236 > 8 and v238 then
		local v241 = p235[v238].Model
		if v241 then
			v241:Destroy()
		end
		p235[v238] = nil
	end
end
local function v_u_284(p243, p244, p245) -- name: CreateEquippedWeapon
	-- upvalues: (copy) v_u_12, (copy) v_u_6, (copy) v_u_17, (copy) v_u_9, (copy) v_u_53, (copy) v_u_234, (copy) v_u_218, (copy) v_u_11, (copy) v_u_22, (copy) v_u_30, (copy) v_u_8, (copy) v_u_5, (copy) v_u_242
	if not p244.Parent then
		return nil
	end
	local v246 = p245.Name
	local v247 = v_u_12.WEAPON_JOINT_PARTS[v246] or v_u_12.DEFAULT_JOINT_PART
	local v248 = p244:WaitForChild(v247, 10)
	local v249 = ("Failed to get joint part: %* for weapon: %*"):format(v247, v246)
	assert(v248, v249)
	local v250 = v_u_6(p245.Name)
	if not v250 then
		return nil
	end
	local v251 = v_u_17[p243] or {
		["Character"] = nil
	}
	v_u_17[p243] = v251
	local v252 = v251.ActiveEquipped
	if v252 then
		v251.ActiveEquipped = nil
		v_u_9.Park(v252.Model, v252.Motors)
	end
	local v253 = v_u_53(p244, "WeaponModel")
	v253:ClearAllChildren()
	local v254 = v248:FindFirstChild("WeaponAttachment")
	if v254 then
		v254:Destroy()
	end
	local v255 = v248:FindFirstChild("WeaponAttachmentHandleR")
	if v255 then
		v255:Destroy()
	end
	local v256 = p244:FindFirstChild("LeftHand")
	local v257 = v256 and v256:FindFirstChild("WeaponAttachmentHandleL")
	if v257 then
		v257:Destroy()
	end
	local v258 = v251.EquippedModels or {}
	v251.EquippedModels = v258
	local v259 = v_u_234(p243, p245)
	local v260 = v250.ShootingOptions == "Dual"
	local v261 = v258[v259]
	if v261 then
		v258[v259] = nil
		if v_u_9.TryUnpark(v261.Model, v253) then
			local v262 = v261.Model
			local v263 = p245.IsSuppressed
			local v264 = v262:FindFirstChild("Silencer", true)
			if v264 and v250.HasSuppressor then
				v264.Transparency = v263 and 0 or 1
			end
			v261.Motors = v_u_218(p244, v248, v261.Model, v260)
			if #v261.Motors == 0 then
				local v265 = v261.Model
				if v265 then
					v265:Destroy()
				end
				return nil
			end
			v_u_9.Release(v261.Motors)
			v261.LastUsed = os.clock()
			v258[v259] = v261
			v251.ActiveEquipped = v261
			return v248
		end
	end
	local v266 = v_u_11.GetCharacterModel
	local v267 = p245.Name
	local v268 = p245.Skin
	local v269 = p245.Float
	local v270 = p245.StatTrack
	local v271 = p245.NameTag
	local v272 = false
	local v273 = p245.Stickers
	local v274
	if p245.Name == "Smoke Grenade" then
		v274 = p243:GetAttribute("Team")
		if v274 ~= "Counter-Terrorists" and v274 ~= "Terrorists" then
			v274 = nil
		end
	else
		v274 = nil
	end
	local v275 = v266(v267, v268, v269, v270, v271, v272, v273, v274)
	if not v275 then
		v_u_22(p243, "equipped weapon skipped: SkinHandler returned nil for weapon=%s skin=%s", p245.Name, p245.Skin)
		return nil
	end
	v_u_30(v275)
	local v276 = p245.IsSuppressed
	local v277 = v275:FindFirstChild("Silencer", true)
	if v277 and v250.HasSuppressor then
		v277.Transparency = v276 and 0 or 1
	end
	local v278 = v250.MuzzleType
	if v278 then
		v278 = v275:FindFirstChild("Interactables")
	end
	if v278 then
		if v260 then
			local v279 = v278:FindFirstChild("MuzzlePartL")
			if v279 and v250.MuzzleType then
				v_u_8(v279, v_u_5, v250.MuzzleType, "WeldConstraint")
				if v250.HasSuppressor then
					v_u_8(v279, v_u_5, "Suppressor", "WeldConstraint")
				end
			end
			local v280 = v278:FindFirstChild("MuzzlePartR")
			if v280 and v250.MuzzleType then
				v_u_8(v280, v_u_5, v250.MuzzleType, "WeldConstraint")
				if v250.HasSuppressor then
					v_u_8(v280, v_u_5, "Suppressor", "WeldConstraint")
				end
			end
		else
			local v281 = v278:FindFirstChild("MuzzlePart")
			if v281 and v250.MuzzleType then
				v_u_8(v281, v_u_5, v250.MuzzleType, "WeldConstraint")
				if v250.HasSuppressor then
					v_u_8(v281, v_u_5, "Suppressor", "WeldConstraint")
				end
			end
		end
	end
	local v282 = v_u_218(p244, v248, v275, v260)
	if #v282 == 0 then
		v_u_22(p243, "equipped weapon skipped: nothing to joint on weapon=%s", p245.Name)
		if v275 then
			v275:Destroy()
		end
		return nil
	end
	v275.Name = "Equipped"
	v275.Parent = v253
	local v283 = {
		["Model"] = v275,
		["Motors"] = v282,
		["LastUsed"] = os.clock()
	}
	v258[v259] = v283
	v251.ActiveEquipped = v283
	v_u_242(v258)
	return v248
end
local v290 = setmetatable({}, {
	["__call"] = function(_, p285, p286, p287) -- name: __call
		-- upvalues: (copy) v_u_7, (copy) v_u_161, (copy) v_u_284, (copy) v_u_187, (copy) v_u_144
		local v288 = v_u_7.getPlayerCharacter(p285)
		if v288 then
			v_u_161(p285, v288)
			local v289 = v_u_284(p285, v288, p286)
			v_u_187(p285, v288, p286, p287)
			if v289 then
				return v289, v_u_144
			end
		end
		return nil, nil
	end
})
v290.ClearPlayerCache = v_u_144
function v290.RefreshObjectiveKitHolster(p291) -- name: RefreshObjectiveKitHolster
	-- upvalues: (copy) v_u_7, (copy) v_u_161, (copy) v_u_87
	local v292 = v_u_7.getPlayerCharacter(p291)
	if v292 then
		v_u_161(p291, v292)
		v_u_87(p291, v292)
	end
end
function v290.RefreshBombHolster(p293) -- name: RefreshBombHolster
	-- upvalues: (copy) v_u_7, (copy) v_u_161, (copy) v_u_2, (copy) v_u_105
	local v294 = v_u_7.getPlayerCharacter(p293)
	if v294 then
		v_u_161(p293, v294)
		local v295 = p293:GetAttribute("CurrentEquipped")
		local v296
		if v295 then
			v296 = v_u_2:JSONDecode(v295)
		else
			v296 = nil
		end
		v_u_105(p293, v294, v296)
	end
end
function v290.RefreshSuppressorState(p297, p298) -- name: RefreshSuppressorState
	-- upvalues: (copy) v_u_7, (copy) v_u_6
	local v299 = v_u_7.getPlayerCharacter(p297)
	if v299 then
		v299 = v299:FindFirstChild("WeaponModel")
	end
	if v299 then
		v299 = v299:FindFirstChild("Equipped")
	end
	if not (v299 and v299:IsA("Model")) then
		return false
	end
	local v300 = v_u_6(p298.Name)
	if not v300 then
		return false
	end
	local v301 = p298.IsSuppressed
	local v302 = v299:FindFirstChild("Silencer", true)
	if v302 and v300.HasSuppressor then
		v302.Transparency = v301 and 0 or 1
	end
	return true
end
v3.PlayerRemoving:Connect(v_u_144)
return v290
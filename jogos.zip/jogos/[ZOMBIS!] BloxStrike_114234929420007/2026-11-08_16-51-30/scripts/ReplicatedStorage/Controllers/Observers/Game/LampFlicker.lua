-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.LampFlicker
-- ModuleScript | 166 linhas | 4809 bytes | hash 894dad95

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Workspace")
local v_u_3 = require(v1.Controllers.RunServiceController)
local v_u_4 = require(v1.Controllers.GraphicsQualityController)
local v5 = require(v1.Packages.Observers)
local v_u_6 = require(v1.Shared.Janitor)
local v_u_7 = Color3.fromRGB(40, 36, 34)
local v_u_8 = {}
local v_u_9 = nil
local v_u_10 = Random.new()
local function v_u_26(p11) -- name: queueCycle
	-- upvalues: (copy) v_u_10
	table.clear(p11.StepIntensities)
	table.clear(p11.StepDurations)
	p11.StepIndex = 0
	for _ = 1, v_u_10:NextInteger(10, 60) do
		local v12 = v_u_10:NextNumber(0.85, 1)
		local v13 = p11.StepIntensities
		table.insert(v13, v12)
		local v14 = p11.StepDurations
		table.insert(v14, 0.05)
	end
	for _ = 1, v_u_10:NextInteger(2, 8) do
		local v15 = v_u_10:NextNumber(0, 0.15)
		local v16 = v_u_10:NextNumber(0.03, 0.15)
		local v17 = p11.StepIntensities
		table.insert(v17, v15)
		local v18 = p11.StepDurations
		table.insert(v18, v16)
		local v19 = v_u_10:NextNumber(0.4, 1)
		local v20 = v_u_10:NextNumber(0.02, 0.1)
		local v21 = p11.StepIntensities
		table.insert(v21, v19)
		local v22 = p11.StepDurations
		table.insert(v22, v20)
	end
	if v_u_10:NextNumber() < 0.35 then
		local v23 = v_u_10:NextNumber(0.8, 3.5)
		local v24 = p11.StepIntensities
		table.insert(v24, 0)
		local v25 = p11.StepDurations
		table.insert(v25, v23)
	end
end
local function v_u_33(p27, p28) -- name: applyIntensity
	-- upvalues: (copy) v_u_7
	for v29, v30 in p27.Lights do
		v30.Brightness = p27.BaseBrightness[v29] * p28
	end
	local v31 = p27.Bulb
	if v31 then
		v31.Color = v_u_7:Lerp(p27.OnColor, p28)
		local v32
		if p28 > 0.15 then
			v32 = Enum.Material.Neon
		else
			v32 = Enum.Material.SmoothPlastic
		end
		if v32 ~= p27.Material then
			p27.Material = v32
			v31.Material = v32
		end
	end
end
local function v_u_39(p34) -- name: stepLamps
	-- upvalues: (copy) v_u_2, (copy) v_u_8, (copy) v_u_26, (copy) v_u_33
	local v35 = v_u_2.CurrentCamera
	if v35 then
		v35 = v35.CFrame.Position
	end
	for _, v36 in v_u_8 do
		v36.StepRemaining = v36.StepRemaining - p34
		if v36.StepRemaining > 0 then
			continue
		end
		local v37 = v36.Bulb
		local v38
		if v35 == nil or v37 == nil then
			v38 = false
		else
			v38 = (v35 - v37.Position).Magnitude < 250
		end
		if v38 then
			v36.StepIndex = v36.StepIndex + 1
			if v36.StepIndex > #v36.StepIntensities then
				v_u_26(v36)
				v36.StepIndex = 1
			end
			v_u_33(v36, v36.StepIntensities[v36.StepIndex])
			v36.StepRemaining = v36.StepDurations[v36.StepIndex]
		else
			v36.StepRemaining = 1
		end
	end
end
return v5.observeTag("LampFlicker", function(p_u_40)
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_7, (copy) v_u_10, (copy) v_u_8, (ref) v_u_9, (copy) v_u_3, (copy) v_u_39
	return v_u_4.RunAnimatedProp(function()
		-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_10, (copy) p_u_40, (ref) v_u_8, (ref) v_u_9, (ref) v_u_3, (ref) v_u_39
		local v_u_41 = v_u_6.new()
		local v_u_42 = {
			["Bulb"] = nil,
			["OnColor"] = nil,
			["AuthoredMaterial"] = nil,
			["Material"] = nil,
			["Lights"] = nil,
			["BaseBrightness"] = nil,
			["StepIntensities"] = nil,
			["StepDurations"] = nil,
			["StepIndex"] = 0,
			["StepRemaining"] = nil,
			["OnColor"] = v_u_7,
			["AuthoredMaterial"] = Enum.Material.Neon,
			["Material"] = Enum.Material.Neon,
			["Lights"] = {},
			["BaseBrightness"] = {},
			["StepIntensities"] = {},
			["StepDurations"] = {},
			["StepRemaining"] = v_u_10:NextNumber(0, 2)
		}
		local function v48(p43) -- name: onDescendant
			-- upvalues: (copy) v_u_42
			if v_u_42.Bulb or (p43.Name ~= "light" or not p43:IsA("BasePart")) then
				if p43:IsA("Light") and (v_u_42.Bulb and p43:IsDescendantOf(v_u_42.Bulb)) then
					local v44 = v_u_42.Lights
					table.insert(v44, p43)
					local v45 = v_u_42.BaseBrightness
					local v46 = p43.Brightness
					table.insert(v45, v46)
				end
			else
				local v47 = v_u_42
				v47.Bulb = p43
				v47.OnColor = p43.Color
				v47.AuthoredMaterial = p43.Material
				v47.Material = p43.Material
			end
		end
		for _, v49 in p_u_40:GetDescendants() do
			v48(v49)
		end
		v_u_41:Add(p_u_40.DescendantAdded:Connect(v48))
		v_u_8[p_u_40] = v_u_42
		if not v_u_9 then
			v_u_9 = v_u_3.BindToHeartbeat("Observers.Game.LampFlicker.Update", v_u_39)
		end
		return function()
			-- upvalues: (copy) v_u_41, (ref) v_u_8, (ref) p_u_40, (copy) v_u_42, (ref) v_u_9
			v_u_41:Destroy()
			v_u_8[p_u_40] = nil
			local v50 = v_u_42
			for v51, v52 in v50.Lights do
				v52.Brightness = v50.BaseBrightness[v51]
			end
			local v53 = v50.Bulb
			if v53 then
				v53.Color = v50.OnColor
				v53.Material = v50.AuthoredMaterial
			end
			if next(v_u_8) == nil and v_u_9 then
				v_u_9:Disconnect()
				v_u_9 = nil
			end
		end
	end)
end, { v_u_2 })
-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.Ping
-- ModuleScript | 163 linhas | 4449 bytes | hash 8c740aae

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("HttpService")
local v3 = game:GetService("Players")
require(v_u_1.Database.Custom.Types)
local v_u_4 = v3.LocalPlayer
local v_u_5 = require(v_u_1.Controllers.SpectateController)
local v_u_6 = require(v_u_1.Controllers.DataController)
local v_u_7 = require(v_u_1.Database.Components.Libraries.Skins)
local v8 = require(v_u_1.Packages.Observers)
local v_u_9 = require(v_u_1.Database.Custom.GameStats.Settings.Colors)
local v_u_10 = require(v_u_1.Database.Custom.GameStats.Rarities)
local v_u_11 = {}
local function v_u_15(p12, p13) -- name: UpdateVisibility
	-- upvalues: (copy) v_u_4, (copy) v_u_6
	local v14 = p13 or v_u_4:GetAttribute("Team")
	if v_u_6.Get(v_u_4, "Settings.Game.HUD.Player Pings") == "Disabled" or v14 ~= p12.CurrentTeam then
		p12.Model.Parent = nil
	elseif p12.Model.Parent == nil and p12.OriginalParent then
		p12.Model.Parent = p12.OriginalParent
	end
end
local function v19() -- name: RefreshAllMarkers
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_11, (copy) v_u_15
	local v16 = v_u_5.GetPlayer()
	local v17
	if v16 and v16 ~= v_u_4 then
		v17 = v16:GetAttribute("Team")
	else
		v17 = nil
	end
	for _, v18 in pairs(v_u_11) do
		v_u_15(v18, v17)
	end
end
local function v_u_39(p20) -- name: StyleBillboard
	-- upvalues: (copy) v_u_9, (copy) v_u_7, (copy) v_u_1, (copy) v_u_10
	local v21 = v_u_9["Team Color"][p20.CurrentTeam]
	p20.Model.Name = p20.Identifier
	if v21 then
		local v22 = p20.Model:FindFirstChildOfClass("BillboardGui")
		if v22 and v22:IsDescendantOf(workspace) then
			local v23 = p20.IsDanger
			local v24 = p20.Weapon
			local v25
			if typeof(v24) == "string" and p20.Weapon ~= "" then
				local v26 = p20.Skin
				if typeof(v26) == "string" then
					v25 = p20.Skin ~= ""
				else
					v25 = false
				end
			else
				v25 = false
			end
			local v27 = v22.Info
			local v28 = not v23
			if v28 then
				v28 = not v25
			end
			v27.Visible = v28
			local v29 = v22.Danger
			local v30
			if v23 then
				v30 = not v25
			else
				v30 = v23
			end
			v29.Visible = v30
			v22.Weapon.Visible = v25
			if v22.Info.Visible then
				v22.Info.ImageColor3 = v21
				return
			elseif v25 then
				local v31 = p20.Weapon
				local v32 = v_u_7.GetSkinInformation(v31, p20.Skin)
				local v33 = v_u_1.Database.Custom.Weapons:FindFirstChild(v31)
				local v34
				if v33 and v33:IsA("ModuleScript") then
					local v35 = require
					local v36, v37 = pcall(v35, v33)
					v34 = v36 and v37 and v37 or nil
				else
					v34 = nil
				end
				local v38
				if v32 then
					v38 = v_u_10[v32.rarity]
				else
					v38 = v32
				end
				if v32 and (v34 and v38) then
					v22.Weapon.Icon.ImageColor3 = v38.Color
					v22.Weapon.Icon.Image = v34.Icon
				else
					v22.Weapon.Visible = false
					v22.Info.Visible = not v23
					v22.Danger.Visible = v23
					if v22.Info.Visible then
						v22.Info.ImageColor3 = v21
					end
				end
			else
				return
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_46(p40, p_u_41) -- name: CreatePositionPing
	-- upvalues: (copy) v_u_15, (copy) v_u_5, (copy) v_u_4, (copy) v_u_39, (copy) v_u_11
	local v42 = {
		["Weapon"] = p40:GetAttribute("Weapon"),
		["Skin"] = p40:GetAttribute("Skin"),
		["Identifier"] = p_u_41,
		["CurrentTeam"] = p40:GetAttribute("Team"),
		["IsDanger"] = p40:GetAttribute("IsDanger"),
		["OriginalParent"] = p40.Parent,
		["Model"] = p40
	}
	local v43 = v_u_15
	local v44 = v_u_5.GetPlayer()
	local v45
	if v44 and v44 ~= v_u_4 then
		v45 = v44:GetAttribute("Team")
	else
		v45 = nil
	end
	v43(v42, v45)
	task.delay(0.016666666666666666, v_u_39, v42)
	v_u_11[p_u_41] = v42
	return function()
		-- upvalues: (ref) v_u_11, (copy) p_u_41
		v_u_11[p_u_41] = nil
	end
end
v_u_4.CharacterAdded:Connect(function()
	-- upvalues: (copy) v_u_11, (copy) v_u_15
	for _, v47 in pairs(v_u_11) do
		v_u_15(v47, nil)
	end
end)
v_u_4:GetAttributeChangedSignal("Team"):Connect(v19)
v_u_6.CreateListener(v_u_4, "Settings.Game.HUD.Player Pings", v19)
v_u_5.ListenToSpectate:Connect(function(p48)
	-- upvalues: (copy) v_u_11, (copy) v_u_15
	if p48 then
		p48 = p48:GetAttribute("Team")
	end
	for _, v49 in pairs(v_u_11) do
		v_u_15(v49, p48)
	end
end)
return v8.observeTag("PlayerPositionMarker", function(p50)
	-- upvalues: (copy) v_u_46, (copy) v_u_2
	if p50:IsDescendantOf(workspace) then
		return v_u_46(p50, v_u_2:GenerateGUID(false))
	else
		return nil
	end
end)
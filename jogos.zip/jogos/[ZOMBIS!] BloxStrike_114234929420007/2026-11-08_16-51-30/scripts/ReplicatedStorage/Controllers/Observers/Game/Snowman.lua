-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.Snowman
-- ModuleScript | 54 linhas | 1492 bytes | hash 3d4f836d

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Debris")
local v_u_3 = require(v1.MovementV2.Collision.Schema)
local v_u_4 = workspace:WaitForChild("Debris")
local v_u_5 = require(v1.Packages.Observers)
local function v_u_11(p6) -- name: createDuplicateSnowman
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v7 = p6:GetPivot()
	local v8 = p6:Clone()
	v8:SetAttribute("Broken", false)
	v8:RemoveTag("Snowman")
	v8:RemoveTag("Interactable")
	for _, v9 in v8:GetDescendants() do
		v9:RemoveTag(v_u_3.Tags.Destructible)
	end
	v8:PivotTo(v7)
	for _, v10 in ipairs(v8:GetChildren()) do
		if v10.Name ~= "Head" then
			continue
		end
		v10.CanCollide = true
		v10.Transparency = 0
	end
	v8.Parent = v_u_4
	return v8
end
local function v_u_15(p12) -- name: createBreakPoints
	-- upvalues: (copy) v_u_2
	local v13 = p12:GetAttribute("Direction")
	for _, v14 in ipairs(p12:GetChildren()) do
		if v14.Name ~= "Head" then
			continue
		end
		v14.CollisionGroup = "Debris"
		v14.Anchored = false
		v14.Massless = true
		if not v13 then
			continue
		end
		v14:ApplyImpulse(math.random(30, 40) * v13)
	end
	v_u_2:AddItem(p12, 10)
end
return v_u_5.observeTag("Snowman", function(p_u_16)
	-- upvalues: (copy) v_u_5, (copy) v_u_11, (copy) v_u_15
	if p_u_16:IsDescendantOf(workspace) then
		return v_u_5.observeAttribute(p_u_16, "Broken", function(p17)
			-- upvalues: (ref) v_u_11, (copy) p_u_16, (ref) v_u_15
			if p17 then
				v_u_15((v_u_11(p_u_16)))
			end
		end)
	end
end)
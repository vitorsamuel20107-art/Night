-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.Grenade
-- ModuleScript | 307 linhas | 9286 bytes | hash c34e824e

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v_u_1.Components.Common.CharacterResolver)
local v3 = require(v_u_1.Packages.Observers)
local v_u_4 = require(v_u_1.Shared.Janitor)
local v5 = require(v_u_1.Database.Security.Remotes)
local v_u_6 = require(v_u_1.Controllers.RunServiceController)
local v_u_7 = require(v_u_1.Shared.GrenadeSimulator)
local v_u_8 = require(v_u_1.Components.Common.VFXLibary.CreateGrenadeBurst)
local v_u_9 = workspace:WaitForChild("Debris")
local v_u_10 = {}
local function v_u_13(p11) -- name: hideAsDebris
	for _, v12 in ipairs(p11:GetDescendants()) do
		if not v12:IsA("BasePart") then
			continue
		end
		v12.CollisionGroup = "Debris"
		v12.Transparency = 1
		v12.CanCollide = false
		v12.CanTouch = false
		v12.CanQuery = false
	end
end
local v_u_20 = {
	["Decoy Grenade"] = function(_, _, p_u_14)
		-- upvalues: (copy) v_u_13
		v_u_13(p_u_14)
		task.delay(0.5, function()
			-- upvalues: (copy) p_u_14
			if p_u_14.Parent then
				p_u_14:Destroy()
			end
		end)
	end,
	["Flashbang"] = function(_, p15, p_u_16)
		-- upvalues: (copy) v_u_13, (copy) v_u_1, (copy) v_u_8
		v_u_13(p_u_16)
		local v17 = v_u_1.Assets.GrenadeParticles:FindFirstChild("Flashbang")
		if v17 and v17:IsA("BasePart") then
			v_u_8(v17, p15, nil)
		end
		task.delay(3, function()
			-- upvalues: (copy) p_u_16
			if p_u_16.Parent then
				p_u_16:Destroy()
			end
		end)
	end,
	["HE Grenade"] = function(_, p18, p_u_19)
		-- upvalues: (copy) v_u_13, (copy) v_u_8, (copy) v_u_1
		v_u_13(p_u_19)
		v_u_8(v_u_1.Assets.GrenadeParticles["HE Grenade"], p18, "HE Grenade")
		task.delay(3, function()
			-- upvalues: (copy) p_u_19
			if p_u_19.Parent then
				p_u_19:Destroy()
			end
		end)
	end
}
local function v_u_26(p21, p22) -- name: createRaycastParams
	-- upvalues: (copy) v_u_9, (copy) v_u_2
	local v23 = RaycastParams.new()
	v23.FilterType = Enum.RaycastFilterType.Exclude
	local v24 = { p21, v_u_9 }
	local v25 = v_u_2.getLocalCharacter()
	if v25 then
		table.insert(v24, v25)
	end
	v23.FilterDescendantsInstances = v24
	v23.RespectCanCollide = false
	v23.IgnoreWater = true
	if p22 then
		v23.CollisionGroup = p22
	end
	return v23
end
local function v_u_31(p27, p28, p29) -- name: reconcileState
	local v30 = (p27.state.position - p28).Magnitude
	if v30 > 8 then
		p27.state.position = p28
		p27.state.velocity = p29
		p27.visualPosition = p28
	elseif v30 > 2 then
		p27.state.position = p27.state.position:Lerp(p28, 0.08)
		p27.state.velocity = p27.state.velocity:Lerp(p29, 0.08)
	end
end
v5.Projectile.Spawn.Listen(function(p_u_32)
	-- upvalues: (copy) v_u_1, (copy) v_u_9, (copy) v_u_4, (copy) v_u_26, (copy) v_u_10, (copy) v_u_6, (copy) v_u_7
	local v_u_33 = p_u_32.Id
	local v_u_34 = p_u_32.State
	local v_u_35 = p_u_32.Physics
	task.defer(function()
		-- upvalues: (ref) v_u_1, (copy) p_u_32, (copy) v_u_33, (copy) v_u_34, (ref) v_u_9, (ref) v_u_4, (copy) v_u_35, (ref) v_u_26, (ref) v_u_10, (ref) v_u_6, (ref) v_u_7
		local v36 = v_u_1.Assets.Weapons:FindFirstChild(p_u_32.Weapon)
		if v36 then
			v36 = v36:FindFirstChild("Character")
		end
		if v36 then
			local v37 = v36:Clone()
			v37.Name = v_u_33
			v37:PivotTo(CFrame.new(v_u_34.Position))
			v37:SetAttribute("GrenadeName", p_u_32.Weapon)
			v37:AddTag("Grenade")
			v37.Parent = v_u_9
			for _, v38 in v37:GetDescendants() do
				if not v38:IsA("BasePart") then
					continue
				end
				v38.Anchored = true
				v38.CanCollide = false
			end
			local v39 = v_u_4.new()
			v39:Add(v37, "Destroy")
			local v40 = {
				["position"] = nil,
				["velocity"] = nil,
				["angularVelocity"] = Vector3.new(0, 0, 0),
				["timestamp"] = nil,
				["simulationTime"] = 0,
				["bounceCount"] = 0,
				["isGrounded"] = false,
				["isAtRest"] = false,
				["hasTouched"] = false,
				["accumulatedTime"] = 0,
				["isJumpThrow"] = nil,
				["position"] = v_u_34.Position,
				["velocity"] = v_u_34.Velocity,
				["timestamp"] = v_u_34.StartTime or workspace:GetServerTimeNow(),
				["isJumpThrow"] = v_u_34.IsJumpThrow or false
			}
			local v41 = p_u_32.Weapon == "Molotov" and true or p_u_32.Weapon == "Incendiary Grenade"
			local v42 = {
				["radius"] = nil,
				["restitution"] = nil,
				["maxBounces"] = nil,
				["fuseTime"] = nil,
				["minimumFuseTime"] = nil,
				["explodeOnFloorImpact"] = nil,
				["rangeScale"] = 1,
				["isNearThrow"] = false,
				["radius"] = v_u_35.Radius,
				["restitution"] = v_u_35.Restitution,
				["maxBounces"] = v_u_35.MaxBounces
			}
			local v43
			if v_u_35.FuseTime > 0 then
				v43 = v_u_35.FuseTime
			else
				v43 = nil
			end
			v42.fuseTime = v43
			v42.minimumFuseTime = v41 and 0.1 or nil
			v42.explodeOnFloorImpact = v41 and true or nil
			local v44 = v_u_34.Velocity
			local v45
			if v44.Magnitude > 1 then
				local v46 = v44:Cross(Vector3.new(0, 1, 0))
				v45 = (v46.Magnitude <= 0.1 and Vector3.new(1, 0, 0) or v46.Unit) * v44.Magnitude * 0.5
			else
				v45 = Vector3.new(0, 0, 0)
			end
			local v_u_47 = {
				["id"] = nil,
				["model"] = nil,
				["state"] = nil,
				["config"] = nil,
				["raycastParams"] = nil,
				["visualPosition"] = nil,
				["visualRotation"] = nil,
				["angularVelocity"] = nil,
				["isResolved"] = false,
				["janitor"] = nil,
				["id"] = v_u_33,
				["model"] = v37,
				["state"] = v40,
				["config"] = v42,
				["raycastParams"] = v_u_26(v37, v_u_35.CollisionGroup),
				["visualPosition"] = v_u_34.Position,
				["visualRotation"] = CFrame.identity,
				["angularVelocity"] = v45,
				["janitor"] = v39
			}
			v_u_10[v_u_33] = v_u_47
			local v_u_48 = nil
			v_u_48 = v_u_6.BindToRenderStep(("Observers.Game.Grenade.%*.Predict"):format(v_u_47.id), function(p49)
				-- upvalues: (copy) v_u_47, (ref) v_u_48, (ref) v_u_7
				if v_u_47.isResolved then
					v_u_48:Disconnect()
					return
				elseif v_u_47.model.Parent then
					v_u_47.state = v_u_7.simulate(v_u_47.state, v_u_47.config, v_u_47.raycastParams, p49).state
					local v50 = p49 * 20
					local v51 = math.min(1, v50)
					v_u_47.visualPosition = v_u_47.visualPosition:Lerp(v_u_47.state.position, v51)
					local v52 = v_u_47.state.velocity.Magnitude
					if v52 < 2 then
						local v53 = v_u_47
						local v54 = v_u_47.angularVelocity
						local v55 = 1 - p49 * 8
						v53.angularVelocity = v54 * math.max(0, v55)
					elseif v52 < 5 then
						local v56 = v_u_47
						local v57 = v_u_47.angularVelocity
						local v58 = 1 - p49 * 3
						v56.angularVelocity = v57 * math.max(0, v58)
					end
					if v_u_47.angularVelocity.Magnitude > 0.01 then
						local v59 = v_u_47.angularVelocity
						local v60 = CFrame.fromAxisAngle(v59.Unit, v59.Magnitude * p49)
						v_u_47.visualRotation = v_u_47.visualRotation * v60
					end
					if v_u_47.model.PrimaryPart then
						v_u_47.model:PivotTo(CFrame.new(v_u_47.visualPosition) * v_u_47.visualRotation)
					end
				else
					v_u_48:Disconnect()
					v_u_47.isResolved = true
				end
			end)
			v_u_47.janitor:Add(v_u_48, "Disconnect")
		else
			warn("[Client Grenade] Base model not found for:", p_u_32.Weapon)
		end
	end)
end)
v5.Projectile.Bounce.Listen(function(p61)
	-- upvalues: (copy) v_u_10, (copy) v_u_31
	local v62 = v_u_10[p61.Id]
	if v62 then
		v_u_31(v62, p61.Position, p61.Velocity)
		v62.state.bounceCount = p61.BounceIndex
		v62.state.hasTouched = true
		local v63 = p61.Velocity
		local v64 = v63 - v62.state.velocity
		if v64.Magnitude > 1 then
			local v65 = v64:Cross(v63)
			local v66
			if v65.Magnitude > 0.1 then
				v66 = v65.Unit
			else
				local v67 = v63:Cross(Vector3.new(0, 1, 0))
				v66 = v67.Magnitude <= 0.1 and Vector3.new(1, 0, 0) or v67.Unit
			end
			local v68 = v66 * v64.Magnitude * 0.5
			v62.angularVelocity = v62.angularVelocity + v68
		end
	end
end)
v5.Projectile.Resolve.Listen(function(p69)
	-- upvalues: (copy) v_u_10
	local v70 = v_u_10[p69.Id]
	if v70 then
		v70.state.position = p69.Position
		v70.state.isAtRest = true
		v70.isResolved = true
		v70.angularVelocity = Vector3.new(0, 0, 0)
		if v70.model.PrimaryPart then
			v70.model:PivotTo(CFrame.new(p69.Position) * v70.visualRotation)
		end
		v70.model:SetAttribute("SimulationFinished", true)
		v_u_10[p69.Id] = nil
	end
end)
return v3.observeTag("Grenade", function(p_u_71)
	-- upvalues: (copy) v_u_20, (copy) v_u_4, (copy) v_u_10
	local v72 = p_u_71:GetAttribute("GrenadeName")
	if v72 then
		local v_u_73 = v_u_20[v72]
		local v_u_74 = v_u_4.new()
		v_u_74:Add(p_u_71:GetAttributeChangedSignal("SimulationFinished"):Connect(function()
			-- upvalues: (copy) p_u_71, (copy) v_u_73, (copy) v_u_74
			local v75 = p_u_71.PrimaryPart
			if v75 and p_u_71:GetAttribute("SimulationFinished") then
				if v_u_73 then
					v_u_73(v_u_74, v75.Position, p_u_71)
				else
					for _, v76 in p_u_71:GetDescendants() do
						if not v76:IsA("BasePart") then
							continue
						end
						v76.Transparency = 1
						v76.CanCollide = false
					end
					local v_u_77 = p_u_71
					task.delay(0.5, function()
						-- upvalues: (copy) v_u_77
						if v_u_77.Parent then
							v_u_77:Destroy()
						end
					end)
				end
			else
				return
			end
		end))
		return function()
			-- upvalues: (ref) v_u_10, (copy) p_u_71, (copy) v_u_74
			local v78 = v_u_10[p_u_71.Name]
			if v78 then
				v78.isResolved = true
				v_u_10[p_u_71.Name] = nil
			end
			v_u_74:Destroy()
		end
	end
end)
-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.BombPlanted
-- ModuleScript | 11 linhas | 297 bytes | hash 7d4eb32b

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Packages.Observers)
local v_u_3 = require(script.Bomb)
return v2.observeTag("Bomb", function(p4)
	-- upvalues: (copy) v_u_3
	local v_u_5 = v_u_3.new(p4)
	return function()
		-- upvalues: (copy) v_u_5
		v_u_5:destroy()
	end
end)
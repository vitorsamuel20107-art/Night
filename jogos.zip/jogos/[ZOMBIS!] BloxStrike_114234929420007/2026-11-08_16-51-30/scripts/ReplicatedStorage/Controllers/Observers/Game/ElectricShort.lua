-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.ElectricShort
-- ModuleScript | 472 linhas | 15035 bytes | hash 5c61a29e

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Workspace")
local v_u_3 = require(v1.Controllers.RunServiceController)
local v_u_4 = require(v1.Controllers.GraphicsQualityController)
local v5 = require(v1.Packages.Observers)
local v_u_6 = require(v1.Shared.Janitor)
local v_u_7 = require(v1.Classes.Sound)
local v_u_8 = Color3.fromRGB(255, 175, 70)
local v_u_9 = Color3.fromRGB(150, 28, 6)
local v_u_10 = {}
local v_u_11 = nil
local v_u_12 = Random.new()
local v_u_13 = false
local function v_u_25(p14) -- name: stepShorts
	-- upvalues: (copy) v_u_10, (copy) v_u_9, (copy) v_u_8
	local v15 = -p14 * 26
	local v16 = math.exp(v15)
	local v17 = -p14 * 0.8
	local v18 = math.exp(v17)
	for _, v19 in v_u_10 do
		if v19.Idle and (v19.Flash <= 0.001 and v19.Heat <= 0.001) then
			continue
		end
		v19.Flash = v19.Flash * v16
		v19.Heat = v19.Heat * v18
		if v19.Flash < 0.001 and v19.Heat < 0.001 then
			v19.Flash = 0
			v19.Heat = 0
			v19.Idle = true
		else
			v19.Idle = false
		end
		local v20 = v19.Heat
		v19.ArcLight.Brightness = v19.BaseBrightness * v19.Flash
		v19.HotLight.Brightness = v20 * 1.2
		local v21 = v19.Glow
		local v22 = v20 > 0.05
		if v21.Enabled ~= v22 then
			v21.Enabled = v22
		end
		if not v22 then
			continue
		end
		local v23 = math.clamp(v20, 0, 1) * 50 + 0.5
		local v24 = math.floor(v23) / 50
		if v24 == v19.GlowStep then
			continue
		end
		v19.GlowStep = v24
		v21.Color = ColorSequence.new(v_u_9:Lerp(v_u_8, v24))
		v21.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.4, 1 - v24 * 0.9), NumberSequenceKeypoint.new(1, 1) })
	end
end
local function v_u_136(p_u_26, p_u_27, p28) -- name: runShort
	-- upvalues: (copy) v_u_7, (copy) v_u_12, (copy) v_u_2
	local v_u_29 = p_u_26:WaitForChild("Emit", 10)
	if v_u_29 then
		v_u_29 = v_u_29:WaitForChild("Sparks", 10)
	end
	local v_u_30 = p_u_26:WaitForChild("PlasmaFlash", 10)
	local v31 = p_u_26:WaitForChild("Drips", 10)
	local v32 = p_u_26:WaitForChild("SmokeWisp", 10)
	if not (v_u_29 and (v_u_30 and (v31 and v32))) then
		warn((("[ElectricShort] %* is missing its emitters"):format((p_u_26:GetFullName()))))
		return
	end
	local v_u_33 = {}
	for v34 = 0, 8 do
		local v35 = p_u_26:WaitForChild(("ArcJ%*"):format(v34), 10)
		if not v35 then
			continue
		end
		table.insert(v_u_33, v35)
	end
	local v_u_36 = {}
	for v37 = 1, 8 do
		local v38 = p_u_26:WaitForChild(("ArcSeg%*"):format(v37), 10)
		if not v38 then
			continue
		end
		table.insert(v_u_36, v38)
	end
	local v_u_39 = {}
	for v40 = 0, 2 do
		local v41 = p_u_26:WaitForChild(("ArcK%*"):format(v40), 10)
		if not v41 then
			continue
		end
		table.insert(v_u_39, v41)
	end
	local v_u_42 = {}
	local v43 = p_u_26:WaitForChild(("ArcBr%*"):format(1), 10)
	if v43 then
		table.insert(v_u_42, v43)
	end
	local v44 = p_u_26:WaitForChild(("ArcBr%*"):format(2), 10)
	if v44 then
		table.insert(v_u_42, v44)
	end
	local v_u_45 = {}
	for _, v46 in p_u_26:GetDescendants() do
		if not v46:IsA("ParticleEmitter") then
			continue
		end
		local v47 = v46.Name
		if string.sub(v47, 1, 5) ~= "Burst" then
			continue
		end
		table.insert(v_u_45, v46)
	end
	local v_u_48 = p_u_26:FindFirstChild("Impact")
	local v_u_49
	if v_u_48 then
		v_u_49 = v_u_48:FindFirstChild("ImpactSparks")
	else
		v_u_49 = v_u_48
	end
	if v_u_48 then
		v_u_48 = v_u_48:FindFirstChild("ImpactGlow")
	end
	local v_u_50 = string.split(p_u_26:GetAttribute("ArcSegTextures") or "", ",")
	local v_u_51
	if #v_u_33 == 9 and (#v_u_36 == 8 and (#v_u_39 == 3 and #v_u_42 == 2)) then
		v_u_51 = v_u_50[1] ~= ""
	else
		v_u_51 = false
	end
	local v_u_52 = p_u_26.Position
	local v53 = p_u_26:GetAttribute("Activity") or 1
	local v_u_54 = p_u_26:GetAttribute("FloorDrop") or 0
	local v_u_55 = 0
	local v_u_56 = true
	local v_u_57 = v_u_7.new("Miscellaneous")
	local v_u_58 = (-1 / 0)
	p28:Add(function()
		-- upvalues: (ref) v_u_56, (copy) v_u_36, (copy) v_u_42
		v_u_56 = false
		for _, v59 in v_u_36 do
			v59.Enabled = false
		end
		for _, v60 in v_u_42 do
			v60.Enabled = false
		end
	end, true)
	local function v_u_87(p61) -- name: arc
		-- upvalues: (copy) v_u_51, (ref) v_u_55, (ref) v_u_12, (copy) v_u_52, (copy) v_u_33, (copy) v_u_36, (copy) v_u_50, (copy) v_u_39, (copy) v_u_42, (ref) v_u_56
		if v_u_51 then
			v_u_55 = v_u_55 + 1
			local v_u_62 = v_u_55
			local v63 = v_u_12:NextNumber(-1, 1)
			local v64 = v_u_12:NextNumber(-0.6, 1)
			local v65 = v_u_12
			local v66 = Vector3.new(v63, v64, v65:NextNumber(-1, 1)).Unit
			local v67 = v_u_12:NextNumber(0.5, 1.4)
			local v68 = v_u_52 + v66 * v67
			local v69 = v66:Cross(Vector3.new(0, 1, 0))
			if v69.Magnitude < 0.1 then
				v69 = v66:Cross(Vector3.new(1, 0, 0))
			end
			local v70 = v69.Unit
			local v71 = v66:Cross(v70)
			v_u_33[1].WorldPosition = v_u_52
			local v72 = v_u_12:NextNumber() < 0.5 and 1 or -1
			for v73 = 2, 8 do
				local v74 = (v73 - 1) / 8
				if v_u_12:NextNumber() < 0.75 then
					v72 = -v72
				end
				local v75 = v67 * v_u_12:NextNumber(0.04, 0.15)
				local v76 = 3.141592653589793 * v74
				local v77 = v75 * math.sin(v76) ^ 0.5
				v_u_33[v73].WorldPosition = v_u_52:Lerp(v68, v74) + v70 * v72 * v77 + v71 * v_u_12:NextNumber(-1, 1) * v77 * 0.6
			end
			v_u_33[9].WorldPosition = v68
			for _, v78 in v_u_36 do
				v78.Texture = v_u_50[v_u_12:NextInteger(1, #v_u_50)]
				local v79 = v_u_12:NextNumber(0.08, 0.15)
				v78.Width0 = v79
				v78.Width1 = v79 * v_u_12:NextNumber(0.75, 1)
			end
			for _, v80 in v_u_36 do
				v80.Enabled = true
			end
			if v_u_12:NextNumber() < 0.6 then
				local v81 = v_u_33[v_u_12:NextInteger(2, 8)].WorldPosition
				local v82 = (v66 + (v70 * v_u_12:NextNumber(-1, 1) + v71 * v_u_12:NextNumber(-1, 1)) * 1.2).Unit
				v_u_39[1].WorldPosition = v81
				v_u_39[2].WorldPosition = v81 + v82 * v67 * v_u_12:NextNumber(0.15, 0.25) + v71 * v_u_12:NextNumber(-0.06, 0.06)
				v_u_39[3].WorldPosition = v_u_39[2].WorldPosition + v82 * v67 * v_u_12:NextNumber(0.12, 0.22) + v70 * v_u_12:NextNumber(-0.06, 0.06)
				for _, v83 in v_u_42 do
					v83.Texture = v_u_50[v_u_12:NextInteger(1, #v_u_50)]
					v83.Width0 = v_u_12:NextNumber(0.04, 0.08)
					v83.Width1 = v83.Width0 * 0.7
					v83.Enabled = true
				end
			else
				for _, v84 in v_u_42 do
					v84.Enabled = false
				end
			end
			task.delay(p61 or v_u_12:NextNumber(0.03, 0.08), function()
				-- upvalues: (ref) v_u_56, (ref) v_u_55, (copy) v_u_62, (ref) v_u_36, (ref) v_u_42
				if v_u_56 and v_u_55 == v_u_62 then
					for _, v85 in v_u_36 do
						v85.Enabled = false
					end
					for _, v86 in v_u_42 do
						v86.Enabled = false
					end
				end
			end)
		end
	end
	local function v104(p88, p89, p90) -- name: zap
		-- upvalues: (copy) v_u_30, (ref) v_u_12, (copy) p_u_27, (ref) v_u_58, (copy) v_u_57, (copy) p_u_26, (copy) v_u_29, (copy) v_u_49, (copy) v_u_48, (copy) v_u_54, (ref) v_u_56, (copy) v_u_87
		v_u_30:Emit(1)
		local v91 = p88 * v_u_12:NextNumber(0.7, 1)
		local v92 = p_u_27
		local v93 = p_u_27.Flash
		v92.Flash = math.max(v93, v91)
		local v94 = os.clock()
		if v94 - v_u_58 >= 0.15 then
			v_u_58 = v94
			v_u_57:play({
				["Parent"] = nil,
				["Name"] = "Electricity Zap",
				["Parent"] = p_u_26
			}, v91)
		end
		p_u_27.ArcLight.Color = Color3.fromRGB(v_u_12:NextInteger(175, 215), v_u_12:NextInteger(190, 222), 255)
		local v95 = p_u_27
		local v96 = p_u_27.Heat + p88 * 0.1
		v95.Heat = math.min(1.2, v96)
		if v_u_12:NextNumber() < 0.75 then
			local v97 = v_u_12:NextInteger(5, 22) * p88 * (p89 or 1) + 0.5
			local v_u_98 = math.floor(v97)
			v_u_29:Emit(v_u_98)
			if v_u_49 and (v_u_48 and (v_u_98 > 0 and v_u_54 < 13)) then
				local v99 = task.delay
				local v100 = 2 * v_u_54 / 35
				v99(math.sqrt(v100) * 1.25 + 0.15, function()
					-- upvalues: (ref) v_u_56, (ref) v_u_49, (copy) v_u_98, (ref) v_u_12, (ref) v_u_48
					if v_u_56 then
						local v101 = v_u_49
						local v102 = v_u_98 * v_u_12:NextNumber(0.25, 0.45)
						local v103 = math.floor(v102)
						v101:Emit((math.max(1, v103)))
						v_u_48:Emit(v_u_12:NextInteger(1, 3))
					end
				end)
			end
		end
		if p90 or v_u_12:NextNumber() < 0.55 then
			v_u_87(p90)
		end
	end
	local function v114() -- name: burst
		-- upvalues: (copy) v_u_45, (ref) v_u_12, (copy) v_u_30, (copy) v_u_29, (copy) v_u_49, (copy) v_u_48, (copy) v_u_54, (ref) v_u_56, (copy) v_u_87, (copy) p_u_27, (ref) v_u_58, (copy) v_u_57, (copy) p_u_26
		if #v_u_45 > 0 then
			v_u_45[v_u_12:NextInteger(1, #v_u_45)]:Emit(1)
		end
		v_u_30:Emit(1)
		local v_u_105 = v_u_12:NextInteger(24, 50)
		v_u_29:Emit(v_u_105)
		if v_u_49 and (v_u_48 and (v_u_105 > 0 and v_u_54 < 13)) then
			local v106 = task.delay
			local v107 = 2 * v_u_54 / 35
			v106(math.sqrt(v107) * 1.25 + 0.15, function()
				-- upvalues: (ref) v_u_56, (ref) v_u_49, (copy) v_u_105, (ref) v_u_12, (ref) v_u_48
				if v_u_56 then
					local v108 = v_u_49
					local v109 = v_u_105 * v_u_12:NextNumber(0.25, 0.45)
					local v110 = math.floor(v109)
					v108:Emit((math.max(1, v110)))
					v_u_48:Emit(v_u_12:NextInteger(1, 3))
				end
			end)
		end
		v_u_87(v_u_12:NextNumber(0.05, 0.11))
		p_u_27.Flash = v_u_12:NextNumber(1.1, 1.5)
		local v111 = p_u_27.Flash
		v_u_58 = os.clock()
		v_u_57:play({
			["Parent"] = nil,
			["Name"] = "Electricity Zap",
			["Parent"] = p_u_26
		}, v111)
		local v112 = p_u_27
		local v113 = p_u_27.Heat + 0.35
		v112.Heat = math.min(1.2, v113)
	end
	task.wait(v_u_12:NextNumber(0, 6))
	local v115 = v_u_58
	local v_u_116 = v_u_56
	while true do
		local v117 = v_u_2.CurrentCamera
		local v118
		if v117 == nil then
			v118 = false
		else
			v118 = (v117.CFrame.Position - v_u_52).Magnitude < 250
		end
		if v118 then
			local v119
			if v_u_12:NextNumber() < 0.2 then
				v119 = v_u_12:NextNumber(0.3, 1.2)
			else
				v119 = v_u_12:NextNumber(2, 9)
			end
			local v120 = v119 / v53
			local v121 = os.clock()
			while os.clock() - v121 < v120 do
				task.wait(v_u_12:NextNumber(0.4, 1.6))
				if v_u_12:NextNumber() >= 0.18 then
					continue
				end
				local v_u_122 = v_u_12:NextInteger(2, 6)
				v_u_29:Emit(v_u_122)
				if v_u_49 and (v_u_48 and (v_u_122 > 0 and v_u_54 < 13)) then
					local v123 = task.delay
					local v124 = 2 * v_u_54 / 35
					v123(math.sqrt(v124) * 1.25 + 0.15, function()
						-- upvalues: (ref) v_u_116, (copy) v_u_49, (copy) v_u_122, (ref) v_u_12, (copy) v_u_48
						if v_u_116 then
							local v125 = v_u_49
							local v126 = v_u_122 * v_u_12:NextNumber(0.25, 0.45)
							local v127 = math.floor(v126)
							v125:Emit((math.max(1, v127)))
							v_u_48:Emit(v_u_12:NextInteger(1, 3))
						end
					end)
				end
				local v128 = p_u_27.Flash
				p_u_27.Flash = math.max(v128, 0.15)
				local v129 = os.clock()
				if v129 - v115 >= 0.15 then
					v_u_58 = v129
					v_u_57:play({
						["Parent"] = nil,
						["Name"] = "Electricity Zap",
						["Parent"] = p_u_26
					}, 0.15)
					v115 = v_u_58
				end
				if v_u_12:NextNumber() >= 0.5 then
					continue
				end
				v_u_30:Emit(1)
			end
			local v130 = v_u_12:NextNumber()
			if v130 < 0.35 then
				v114()
				if v_u_12:NextNumber() < 0.4 then
					task.wait(v_u_12:NextNumber(0.06, 0.2))
					v104(0.8)
				end
			elseif v130 < 0.75 then
				if v_u_12:NextNumber() < 0.6 then
					v114()
				end
				for _ = 1, v_u_12:NextInteger(3, 12) do
					v104(v_u_12:NextNumber(0.35, 1))
					task.wait(v_u_12:NextNumber(0.03, 0.17))
				end
				if v_u_12:NextNumber() < 0.35 then
					v114()
				end
			else
				v114()
				local v131 = v_u_12:NextNumber(0.3, 1.4)
				local v132 = os.clock()
				while os.clock() - v132 < v131 do
					v104(v_u_12:NextNumber(0.5, 1), 0.35, 0.07)
					task.wait(v_u_12:NextNumber(0.02, 0.06))
				end
				if v_u_12:NextNumber() < 0.5 then
					v114()
				end
			end
			if v_u_12:NextNumber() < 0.75 then
				v32:Emit(v_u_12:NextInteger(1, 2))
			end
			if p_u_27.Heat <= 0.4 or v_u_12:NextNumber() >= 0.6 then
				break
			end
			local v_u_133 = v_u_12:NextInteger(1, 4)
			v31:Emit(v_u_133)
			if not v_u_49 or (not v_u_48 or v_u_133 <= 0) then
				break
			end
			local v134 = task.delay
			local v135 = 2 * v_u_54 / 30
			v134(math.sqrt(v135) * 1.1 + 0.1, function()
				-- upvalues: (ref) v_u_116, (copy) v_u_48, (copy) v_u_133, (copy) v_u_49, (ref) v_u_12
				if v_u_116 then
					v_u_48:Emit(v_u_133)
					v_u_49:Emit(v_u_133 * v_u_12:NextInteger(2, 5))
				end
			end)
		else
			task.wait(1)
		end
	end
end
return v5.observeTag("ElectricShort", function(p_u_137)
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_10, (ref) v_u_11, (copy) v_u_3, (copy) v_u_25, (ref) v_u_13, (copy) v_u_7, (copy) v_u_136
	return v_u_4.RunAnimatedProp(function()
		-- upvalues: (ref) v_u_6, (copy) p_u_137, (ref) v_u_10, (ref) v_u_11, (ref) v_u_3, (ref) v_u_25, (ref) v_u_13, (ref) v_u_7, (ref) v_u_136
		local v_u_138 = v_u_6.new()
		v_u_138:Add(task.spawn(function()
			-- upvalues: (ref) p_u_137, (ref) v_u_10, (ref) v_u_11, (ref) v_u_3, (ref) v_u_25, (ref) v_u_13, (ref) v_u_7, (copy) v_u_138, (ref) v_u_136
			local v139 = p_u_137:WaitForChild("ArcLight", 10)
			local v140 = p_u_137:WaitForChild("HotLight", 10)
			local v141 = p_u_137:WaitForChild("HotGlow", 10)
			if v139 and (v140 and v141) then
				local v_u_142 = {
					["ArcLight"] = nil,
					["HotLight"] = nil,
					["Glow"] = nil,
					["BaseBrightness"] = nil,
					["Flash"] = 0,
					["Heat"] = 0,
					["Idle"] = false,
					["GlowStep"] = -1,
					["AuthoredArcBrightness"] = nil,
					["AuthoredHotBrightness"] = nil,
					["AuthoredGlowEnabled"] = nil,
					["AuthoredGlowColor"] = nil,
					["AuthoredGlowTransparency"] = nil,
					["ArcLight"] = v139,
					["HotLight"] = v140,
					["Glow"] = v141,
					["BaseBrightness"] = v139:GetAttribute("BaseBrightness") or 5,
					["AuthoredArcBrightness"] = v139.Brightness,
					["AuthoredHotBrightness"] = v140.Brightness,
					["AuthoredGlowEnabled"] = v141.Enabled,
					["AuthoredGlowColor"] = v141.Color,
					["AuthoredGlowTransparency"] = v141.Transparency
				}
				v_u_10[p_u_137] = v_u_142
				if not v_u_11 then
					v_u_11 = v_u_3.BindToHeartbeat("Observers.Game.ElectricShort.Update", v_u_25)
				end
				if not v_u_13 then
					v_u_13 = true
					task.spawn(v_u_7.WarmPersistentSound, "Miscellaneous", "Electricity Zap")
				end
				v_u_138:Add(function()
					-- upvalues: (ref) v_u_10, (ref) p_u_137, (copy) v_u_142, (ref) v_u_11
					v_u_10[p_u_137] = nil
					local v143 = v_u_142
					v143.ArcLight.Brightness = v143.AuthoredArcBrightness
					v143.HotLight.Brightness = v143.AuthoredHotBrightness
					v143.Glow.Enabled = v143.AuthoredGlowEnabled
					v143.Glow.Color = v143.AuthoredGlowColor
					v143.Glow.Transparency = v143.AuthoredGlowTransparency
					if next(v_u_10) == nil and v_u_11 then
						v_u_11:Disconnect()
						v_u_11 = nil
					end
				end, true)
				v_u_136(p_u_137, v_u_142, v_u_138)
			else
				warn((("[ElectricShort] %* is missing ArcLight, HotLight or HotGlow"):format((p_u_137:GetFullName()))))
			end
		end), true)
		return function()
			-- upvalues: (copy) v_u_138
			v_u_138:Destroy()
		end
	end)
end, { v_u_2 })
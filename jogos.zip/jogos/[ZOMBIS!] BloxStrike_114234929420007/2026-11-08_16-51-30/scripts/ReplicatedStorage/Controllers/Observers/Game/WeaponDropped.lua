-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.WeaponDropped
-- ModuleScript | 11 linhas | 308 bytes | hash 4018b46d

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Packages.Observers)
local v_u_3 = require(script.Weapon)
return v2.observeTag("WeaponDropped", function(p4)
	-- upvalues: (copy) v_u_3
	local v_u_5 = v_u_3.new(p4)
	return function()
		-- upvalues: (copy) v_u_5
		v_u_5:destroy()
	end
end)
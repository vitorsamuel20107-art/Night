-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.VertigoCar
-- ModuleScript | 62 linhas | 1730 bytes | hash 619a7a6e

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("TweenService")
local v3 = require(v1.Packages.Observers)
local v_u_4 = require(v1.Controllers.GraphicsQualityController)
local v_u_5 = require(v1.Shared.Janitor)
local function v_u_15(p6, p7) -- name: CreateTween
	-- upvalues: (copy) v_u_2
	if p7:IsDescendantOf(workspace) then
		local v8 = p7:WaitForChild("PointA", 5)
		local v9 = p7:WaitForChild("PointB", 5)
		if v8 and v9 then
			if p7:IsDescendantOf(workspace) then
				local v10 = v8.WorldPosition
				local v11 = v9.WorldPosition
				local v12 = (v11 - v10).Magnitude
				if v12 > 0 then
					local v13 = v12 / 42
					local v14 = v_u_2:Create(p7, TweenInfo.new(v13, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["Position"] = v11
					})
					p6:Add(v14, "Cancel")
					while p7:IsDescendantOf(workspace) do
						p7.Position = v10
						v14:Play()
						v14.Completed:Wait()
					end
				end
			else
				return
			end
		else
			warn((("[VertigoCar] Model \"%*\" is missing PointA or PointB attachments"):format(p7.Name)))
			return
		end
	else
		return
	end
end
return v3.observeTag("VertigoCar", function(p_u_16)
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_15
	p_u_16.Anchored = true
	if not p_u_16:IsDescendantOf(workspace) then
		return nil
	end
	local v18 = v_u_4.RunAnimatedProp(function()
		-- upvalues: (ref) v_u_5, (copy) p_u_16, (ref) v_u_15
		local v_u_17 = v_u_5.new()
		v_u_17:Add(p_u_16)
		v_u_17:Add(task.spawn(function()
			-- upvalues: (ref) v_u_15, (copy) v_u_17, (ref) p_u_16
			v_u_15(v_u_17, p_u_16)
		end))
		return function()
			-- upvalues: (copy) v_u_17
			v_u_17:Destroy()
		end
	end)
	if not v18 then
		p_u_16:Destroy()
	end
	return v18
end)
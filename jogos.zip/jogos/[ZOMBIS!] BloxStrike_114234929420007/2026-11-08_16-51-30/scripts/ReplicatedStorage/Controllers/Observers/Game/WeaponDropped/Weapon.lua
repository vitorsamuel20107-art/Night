-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.WeaponDropped.Weapon
-- ModuleScript | 227 linhas | 6967 bytes | hash 657d65db

local v_u_1 = {}
v_u_1.__index = v_u_1
local v2 = game:GetService("ReplicatedStorage")
local v3 = game:GetService("Players")
require(v2.Database.Custom.Types)
local v_u_4 = require(v2.Controllers.InventoryController)
local v_u_5 = require(v2.Controllers.DataController)
local v_u_6 = require(v2.Controllers.RunServiceController)
local v_u_7 = require(v2.Components.Common.GetWeaponProperties)
local v_u_8 = require(v2.Components.Common.CharacterResolver)
local v_u_9 = require(v2.Components.Common.CenterScreenRaycast)
local v_u_10 = require(v2.Components.Common.SurvivalBuyRules)
local v_u_11 = require(v2.Database.Components.Libraries.Skins)
local v_u_12 = require(v2.Database.Security.Remotes)
local v_u_13 = require(v2.Database.Security.Router)
local v_u_14 = require(v2.Database.Custom.GameStats.NumberSlots)
local v_u_15 = require(v2.Database.Custom.GameStats.Rarities)
local v_u_16 = v3.LocalPlayer
local v_u_17 = {
	["ProximityRange"] = 6,
	["HoverRange"] = 10
}
local v_u_18 = {}
local v_u_19 = 0
local v_u_20 = nil
local v_u_21 = nil
local v_u_22 = {}
local function v_u_28(p23, p24) -- name: HasReachedDuplicateLimit
	-- upvalues: (copy) v_u_10
	local v25 = v_u_10.GetGrenadeLimit(p24)
	if not v25 then
		return false
	end
	local v26 = 0
	if p23 then
		for _, v27 in ipairs(p23._items) do
			if v27.Name ~= p24 then
				continue
			end
			v26 = v26 + 1
		end
	end
	return v25 <= v26
end
function v_u_1.autoPickup(p_u_29) -- name: autoPickup
	-- upvalues: (copy) v_u_7, (copy) v_u_14, (copy) v_u_4, (copy) v_u_28, (copy) v_u_22, (copy) v_u_11, (copy) v_u_15, (copy) v_u_16, (copy) v_u_13, (copy) v_u_12
	local v30 = p_u_29.Model:GetAttribute("Weapon")
	if v30 then
		local v31 = v_u_7(v30)
		if v31 then
			local v_u_32 = v_u_14[v31.Slot]
			if v_u_32 then
				local v33 = v_u_4.getInventorySlot(v_u_32)
				if v_u_28(v33, v30) then
					return
				else
					if v33 then
						v33 = #v33._items < v33._settings._strict_slot_space
					end
					if v33 and p_u_29.Model:GetAttribute("CanPickup") then
						if not p_u_29.SentPickupRequest then
							local v_u_34 = os.clock()
							local v35 = v_u_22[v_u_32]
							local v36
							if v35 and v_u_34 - v35 < 1 then
								v36 = false
							else
								v_u_22[v_u_32] = v_u_34
								task.delay(1, function()
									-- upvalues: (ref) v_u_22, (copy) v_u_32, (copy) v_u_34
									if v_u_22[v_u_32] == v_u_34 then
										v_u_22[v_u_32] = nil
									end
								end)
								v36 = true
							end
							if v36 then
								p_u_29.SentPickupRequest = true
								task.delay(1, function()
									-- upvalues: (copy) p_u_29
									p_u_29.SentPickupRequest = false
								end)
								local v37 = v_u_11.GetSkinInformation(p_u_29.Weapon, p_u_29.Skin)
								local v38 = "Skin data not found for weapon: " .. p_u_29.Weapon .. " and skin: " .. p_u_29.Skin
								assert(v37, v38)
								local v39 = v_u_15[v37.rarity]
								local v40 = v39.Color.R * 255
								local v41 = math.floor(v40)
								local v42 = v39.Color.G * 255
								local v43 = math.floor(v42)
								local v44 = v39.Color.B * 255
								local v45 = math.floor(v44)
								if p_u_29.Weapon ~= "C4" or v_u_16:GetAttribute("Team") == "Terrorists" then
									v_u_13.broadcastRouter("CreateNotification", "Item Picked Up", ("You picked up a <font color = \"rgb(%*, %*, %*)\"><b>%* | %*</b></font>"):format(v41, v43, v45, p_u_29.Weapon:find("Zeus") and "Taser" or p_u_29.Weapon, p_u_29.Skin), 2)
									v_u_12.Inventory.PickupWeapon.Send({
										["Identity"] = nil,
										["AllowAutoEquip"] = false,
										["Identity"] = p_u_29.Model.Name
									})
								end
							end
						end
					end
				end
			else
				return
			end
		else
			return
		end
	else
		return
	end
end
function v_u_1.updateState(p46, p47) -- name: updateState
	-- upvalues: (ref) v_u_20, (copy) v_u_8, (copy) v_u_16, (copy) v_u_5, (copy) v_u_7
	p46.AlphaTime = p46.AlphaTime + p47
	local v48 = v_u_20
	local v49
	if v48 == nil then
		v49 = false
	else
		v49 = v48:IsDescendantOf(p46.Model)
	end
	local v50 = v49 and "Hovering"
	local v51 = v_u_8.getLocalCharacter()
	if v51 then
		v51 = v51.PrimaryPart
	end
	local v52 = v51 and (v51.Position - p46.Model.PrimaryPart.Position).Magnitude <= 6 and (v50 or "Proximity") or v50
	if p46.Weapon == "C4" then
		local v53 = v_u_16:GetAttribute("Team")
		if p46.AlphaTime >= 1 then
			local v54 = p46.Model.Weapon:FindFirstChild("FlashingLight")
			p46.AlphaTime = 0
			if v54 then
				v54.Attachment.PointLight.Enabled = not v54.Attachment.PointLight.Enabled
				v54.Attachment.PointLight.Color = Color3.fromRGB(255, 255, 15)
				v54.Attachment.PointLight.Brightness = 5
			end
		end
		if v53 ~= "Terrorists" then
			v52 = false
		end
	end
	local v55 = (v52 == "Hovering" or v52 == "Proximity") and v52 and v52 or nil
	if p46.LastHoveringState ~= v55 then
		p46.LastHoveringState = v55
		p46.Model:SetAttribute("HoveringState", v55)
	end
	local v56 = v55 ~= nil
	if p46.IsInteractableTagged ~= v56 then
		p46.IsInteractableTagged = v56
		if v56 then
			p46.Model:AddTag("IsHoveringInteractable")
		else
			p46.Model:RemoveTag("IsHoveringInteractable")
		end
	end
	if v55 == "Proximity" then
		local v57 = v_u_5.Get(v_u_16, "Settings.Game.Item.Auto Pickup Dropped Weapons")
		local v58 = v_u_7(p46.Weapon)
		if v58 then
			v58 = v58.Slot
		end
		local v59 = v58 == "Grenade" and true or v58 == "C4"
		if v57 ~= false or v59 then
			p46:autoPickup()
		end
	end
end
function v_u_1.new(p60) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_18, (ref) v_u_19, (ref) v_u_21, (copy) v_u_6, (ref) v_u_20, (copy) v_u_9, (copy) v_u_17
	local v61 = v_u_1
	local v62 = setmetatable({}, v61)
	v62.Model = p60
	v62.AlphaTime = 0
	v62.Weapon = v62.Model:GetAttribute("Weapon")
	v62.Skin = v62.Model:GetAttribute("Skin")
	v62.SentPickupRequest = false
	v62.IsInteractableTagged = false
	v_u_18[v62] = true
	v_u_19 = v_u_19 + 1
	if v_u_21 then
		return v62
	end
	v_u_21 = v_u_6.BindToHeartbeat("Observers.Game.WeaponDropped.Update", function(p63)
		-- upvalues: (ref) v_u_19, (ref) v_u_21, (ref) v_u_20, (ref) v_u_9, (ref) v_u_17, (ref) v_u_18
		if v_u_19 <= 0 then
			if v_u_19 <= 0 and v_u_21 then
				v_u_21:Disconnect()
				v_u_21 = nil
				v_u_20 = nil
			end
		else
			v_u_20 = v_u_9.GetInstance(v_u_17.HoverRange)
			for v64 in pairs(v_u_18) do
				if not v64.Model.PrimaryPart then
					continue
				end
				v64:updateState(p63)
			end
		end
	end)
	return v62
end
function v_u_1.destroy(p65) -- name: destroy
	-- upvalues: (copy) v_u_18, (ref) v_u_19, (ref) v_u_21, (ref) v_u_20
	if v_u_18[p65] then
		v_u_18[p65] = nil
		v_u_19 = v_u_19 - 1
		if v_u_19 <= 0 and v_u_21 then
			v_u_21:Disconnect()
			v_u_21 = nil
			v_u_20 = nil
		end
	end
	if p65.IsInteractableTagged then
		p65.Model:RemoveTag("IsHoveringInteractable")
		p65.IsInteractableTagged = false
	end
	if p65.LastHoveringState ~= nil then
		p65.Model:SetAttribute("HoveringState", nil)
		p65.LastHoveringState = nil
	end
end
return v_u_1
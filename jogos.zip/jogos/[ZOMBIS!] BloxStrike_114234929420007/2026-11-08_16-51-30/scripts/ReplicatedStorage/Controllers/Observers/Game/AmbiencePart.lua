-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.AmbiencePart
-- ModuleScript | 181 linhas | 4826 bytes | hash 24b93d07

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("SoundService")
local v_u_3 = game:GetService("Workspace")
local v4 = game:GetService("Players").LocalPlayer
local v_u_5 = require(v1.Controllers.RunServiceController)
local v6 = require(v1.Controllers.DataController)
local v7 = require(v1.Packages.Observers)
local v_u_8 = require(v1.Shared.Janitor)
local v_u_9 = require(v1.Classes.Sound)
local v_u_10 = {}
local v_u_11 = nil
local v_u_12 = 0
local v_u_13 = 1
local v_u_14 = 0
local function v_u_23(p15, p16, p17) -- name: stepVolumes
	-- upvalues: (ref) v_u_13
	for _, v18 in ipairs(p15.SoundDataList) do
		local v19 = p16 <= v18.AudibleRange and (v18.MaximumVolume * v_u_13 or 0) or 0
		local v20 = v18.CurrentVolume
		local v21 = v19 - v20
		if v19 > 0 and not v18.Playing then
			v18.LoopSound:Resume()
			v18.Playing = true
		end
		if math.abs(v21) <= 0.002 then
			if v20 ~= v19 then
				v18.LoopSound.Volume = v19
			end
			v18.CurrentVolume = v19
			if v19 ~= 0 or not v18.Playing then
				continue
			end
			v18.LoopSound:Pause()
			v18.Playing = false
		else
			local v22 = v20 + v21 * p17
			v18.LoopSound.Volume = v22
			v18.CurrentVolume = v22
		end
	end
end
local function v_u_36(p24) -- name: stepZones
	-- upvalues: (ref) v_u_12, (ref) v_u_14, (copy) v_u_3, (copy) v_u_10, (copy) v_u_23, (ref) v_u_11
	v_u_12 = v_u_12 + p24
	local v25 = v_u_12
	local v26 = v_u_12 >= 0.06666666666666667
	if v26 or v_u_14 ~= 0 then
		local v27 = v_u_3.CurrentCamera
		if v27 then
			v27 = v27.CFrame.Position
		end
		if v27 then
			if v26 then
				v_u_12 = 0
			end
			local v28 = v25 * 3
			local v29 = math.min(1, v28)
			for v30, v31 in pairs(v_u_10) do
				local v32 = v31.Emitter
				if not (v26 or v32) then
					continue
				end
				if v30:IsDescendantOf(v_u_3) then
					local v33 = v31.BoundsCFrame:PointToObjectSpace(v27)
					local v34 = v31.HalfSize
					local v35 = v33:Max(-v34):Min(v34)
					if v32 and v32.Position ~= v35 then
						v32.Position = v35
					end
					if not v26 then
						continue
					end
					v_u_23(v31, (v33 - v35).Magnitude, v29)
				else
					v_u_10[v30] = nil
				end
			end
			if next(v_u_10) == nil then
				if v_u_11 then
					v_u_11:Disconnect()
					v_u_11 = nil
				end
				v_u_12 = 0
			end
		end
	else
		return
	end
end
v6.CreateListener(v4, "Settings.Audio.Audio.Master Volume", function(p37)
	-- upvalues: (ref) v_u_13
	v_u_13 = (tonumber(p37) or 100) / 100
	return nil
end)
return v7.observeTag("AmbiencePart", function(p_u_38)
	-- upvalues: (copy) v_u_8, (ref) v_u_14, (copy) v_u_9, (copy) v_u_2, (copy) v_u_10, (ref) v_u_11, (copy) v_u_5, (copy) v_u_36, (ref) v_u_12
	if not p_u_38:IsDescendantOf(workspace) then
		return function() end
	end
	local v39 = {}
	for _, v40 in p_u_38:GetChildren() do
		if not v40:IsA("Sound") then
			continue
		end
		table.insert(v39, v40)
	end
	if #v39 <= 0 then
		return function() end
	end
	local v_u_41 = v_u_8.new()
	local v42 = {}
	local v43
	if p_u_38:GetAttribute("Positional") == true then
		v43 = v_u_41:Add(Instance.new("Attachment"))
		v43.Name = "AmbienceEmitter"
		v43.Parent = p_u_38
		v_u_14 = v_u_14 + 1
		v_u_41:Add(function()
			-- upvalues: (ref) v_u_14
			v_u_14 = v_u_14 - 1
		end, true)
	else
		v43 = nil
	end
	for _, v44 in v39 do
		local v45 = v_u_41:Add(v44:Clone())
		if not v43 then
			v45.RollOffMode = Enum.RollOffMode.Inverse
			v45.RollOffMaxDistance = 10000
			v45.RollOffMinDistance = 10000
		end
		v45.SoundGroup = v_u_9.GameplaySoundGroup
		v45.Parent = v43 or v_u_2
		v45.PlayOnRemove = false
		v45.Volume = 0
		local v46 = {
			["MaximumVolume"] = nil,
			["LoopSound"] = nil,
			["CurrentVolume"] = 0,
			["AudibleRange"] = nil,
			["Playing"] = false,
			["MaximumVolume"] = v44.Volume > 0 and (v44.Volume or 1) or 1,
			["LoopSound"] = v45,
			["AudibleRange"] = v43 and v44.RollOffMaxDistance or 0
		}
		table.insert(v42, v46)
	end
	local v_u_47 = {
		["SoundDataList"] = v42,
		["BoundsCFrame"] = p_u_38.CFrame,
		["HalfSize"] = p_u_38.Size / 2,
		["Emitter"] = v43
	}
	v_u_10[p_u_38] = v_u_47
	v_u_41:Add(p_u_38:GetPropertyChangedSignal("CFrame"):Connect(function()
		-- upvalues: (copy) v_u_47, (copy) p_u_38
		v_u_47.BoundsCFrame = p_u_38.CFrame
	end))
	v_u_41:Add(p_u_38:GetPropertyChangedSignal("Size"):Connect(function()
		-- upvalues: (copy) v_u_47, (copy) p_u_38
		v_u_47.HalfSize = p_u_38.Size / 2
	end))
	if not v_u_11 then
		v_u_11 = v_u_5.BindToRenderStep("Observers.Game.AmbiencePart.UpdateZones", Enum.RenderPriority.Last.Value, v_u_36)
	end
	v_u_41:Add(function()
		-- upvalues: (ref) v_u_10, (copy) p_u_38, (ref) v_u_11, (ref) v_u_12
		v_u_10[p_u_38] = nil
		if next(v_u_10) == nil then
			if v_u_11 then
				v_u_11:Disconnect()
				v_u_11 = nil
			end
			v_u_12 = 0
		end
	end)
	return function()
		-- upvalues: (copy) v_u_41
		v_u_41:Cleanup()
	end
end)
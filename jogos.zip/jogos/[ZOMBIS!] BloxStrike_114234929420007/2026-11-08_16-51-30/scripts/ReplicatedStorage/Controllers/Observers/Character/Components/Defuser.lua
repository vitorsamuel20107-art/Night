-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Character.Components.Defuser
-- ModuleScript | 133 linhas | 3691 bytes | hash e4051b92

local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2.Packages.Observers)
local v_u_4 = require(v2.Shared.Janitor)
local v5 = v2.Assets.Other
local v_u_6 = v5.Defuser
local v_u_7 = v5.DefuseA1
local v_u_8 = v5.DefuseA2
local v_u_9 = v5.DefuseB1
local v_u_10 = v5.DefuseB2
local v_u_11 = CFrame.new(0, -0.2, -0.5) * CFrame.Angles(0, 3.141592653589793, 0)
local v_u_12 = {}
v_u_12.__index = v_u_12
local function v_u_20(p13, p14, p15) -- name: cloneDefusePart
	local v16 = p13:Clone()
	local v17 = v16:FindFirstChild("Attachment")
	local v18 = p14.Parent
	v16.CFrame = v18.CFrame * p14.CFrame * v17.CFrame:Inverse()
	v16.Parent = workspace
	local v19 = Instance.new("WeldConstraint")
	v19.Part0 = v18
	v19.Part1 = v16
	v19.Parent = v16
	p15:Add(v16)
	return v17
end
function v_u_12.new(p21, p_u_22) -- name: new
	-- upvalues: (copy) v_u_12, (copy) v_u_4, (copy) v_u_3, (copy) v_u_1, (copy) v_u_6, (copy) v_u_11, (copy) v_u_20, (copy) v_u_7, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10
	local v23 = v_u_12
	local v24 = setmetatable({}, v23)
	v24.Janitor = v_u_4.new()
	local v_u_25 = nil
	local v_u_26 = nil
	local v_u_27 = nil
	local function v_u_32() -- name: reset
		-- upvalues: (ref) v_u_26, (ref) v_u_27, (ref) v_u_25
		local v28 = v_u_26
		if v28 then
			v28.Attachment0 = nil
			v28.Attachment1 = nil
		end
		local v29 = v_u_27
		if v29 then
			v29.Attachment0 = nil
			v29.Attachment1 = nil
		end
		if v_u_25 then
			local v_u_30 = v_u_25
			task.defer(function()
				-- upvalues: (copy) v_u_30
				local function v31()
					-- upvalues: (ref) v_u_30
					v_u_30:Destroy()
				end
				pcall(v31)
			end)
		end
		v_u_26 = nil
		v_u_27 = nil
		v_u_25 = nil
	end
	v24.Janitor:Add(v_u_3.observeAttribute(p21, "IsDefusingBomb", function(p33)
		-- upvalues: (ref) v_u_26, (ref) v_u_27, (ref) v_u_25, (copy) v_u_32, (copy) p_u_22, (ref) v_u_1, (ref) v_u_4, (ref) v_u_6, (ref) v_u_11, (ref) v_u_20, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10
		local v34 = v_u_26
		if v34 then
			v34.Attachment0 = nil
			v34.Attachment1 = nil
		end
		local v35 = v_u_27
		if v35 then
			v35.Attachment0 = nil
			v35.Attachment1 = nil
		end
		if v_u_25 then
			local v_u_36 = v_u_25
			task.defer(function()
				-- upvalues: (copy) v_u_36
				local function v37()
					-- upvalues: (ref) v_u_36
					v_u_36:Destroy()
				end
				pcall(v37)
			end)
		end
		v_u_26 = nil
		v_u_27 = nil
		v_u_25 = nil
		if p33 ~= true then
			return v_u_32
		end
		local v38 = p_u_22:FindFirstChild("LeftHand")
		local v39 = v_u_1:GetTagged("Bomb")[1]
		if not (v38 and v39) then
			return function() end
		end
		v_u_25 = v_u_4.new()
		local v40 = v_u_6:Clone()
		local v41 = v40.Handle
		v40.Parent = p_u_22
		v41.CFrame = v38.CFrame * v_u_11
		v40.PrimaryPart = v41
		local v42 = Instance.new("WeldConstraint")
		v42.Part0 = v38
		v42.Part1 = v41
		v42.Parent = v41
		v_u_25:Add(v40)
		local v43 = v39.Weapon.Body
		local v44 = v_u_20(v_u_7, v41:FindFirstChild("AttachmentA"), v_u_25)
		local v45 = v_u_20(v_u_8, v43:FindFirstChild("AttachmentA"), v_u_25)
		local v46 = v_u_20(v_u_9, v41:FindFirstChild("AttachmentB"), v_u_25)
		local v47 = v_u_20(v_u_10, v43:FindFirstChild("AttachmentB"), v_u_25)
		local v48 = v44.Parent:FindFirstChildWhichIsA("Beam")
		if v48 then
			v48.Attachment0 = v44
			v48.Attachment1 = v45
			v48.Enabled = true
		end
		v_u_26 = v48
		local v49 = v46.Parent:FindFirstChildWhichIsA("Beam")
		if v49 then
			v49.Attachment0 = v46
			v49.Attachment1 = v47
			v49.Enabled = true
		end
		v_u_27 = v49
		return v_u_32
	end))
	return v24
end
function v_u_12.Destroy(p50) -- name: Destroy
	p50.Janitor:Destroy()
end
return v_u_12
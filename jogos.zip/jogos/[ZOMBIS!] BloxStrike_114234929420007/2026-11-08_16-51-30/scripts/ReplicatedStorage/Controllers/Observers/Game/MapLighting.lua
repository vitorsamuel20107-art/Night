-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.MapLighting
-- ModuleScript | 82 linhas | 2476 bytes | hash 259072e3

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v_u_1.Components.Common.SceneLighting)
local v3 = game:GetService("Players")
local v4 = require(v_u_1.Controllers.DataController)
local v5 = v3.LocalPlayer
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local function v_u_12() -- name: shouldApplyMapLighting
	-- upvalues: (ref) v_u_6, (copy) v_u_1, (ref) v_u_7, (ref) v_u_9, (ref) v_u_8
	v_u_6 = v_u_6 or require(v_u_1.Controllers.MenuSceneController)
	v_u_7 = v_u_7 or require(v_u_1.Controllers.CaseSceneController)
	v_u_9 = v_u_9 or require(v_u_1.Controllers.InspectController)
	v_u_8 = v_u_8 or require(v_u_1.Controllers.BlackMarketSceneController)
	local v11 = not (v_u_6.IsActive() or v_u_6.IsTeamSelectSceneActive() or (v_u_7.IsActive() or v_u_8.IsActive()))
	if v11 then
		v11 = not v_u_9.IsActive()
	end
	return v11
end
local function v_u_17(p_u_13) -- name: handleMapLoaded
	-- upvalues: (copy) v_u_12, (ref) v_u_10, (copy) v_u_2
	if v_u_12() then
		local v14 = p_u_13:GetAttribute("MapName")
		if typeof(v14) ~= "string" then
			v14 = nil
		end
		if v14 then
			v_u_10 = v_u_2.RestoreMap(v14, v_u_10)
		else
			local v_u_15 = nil
			v_u_15 = p_u_13:GetAttributeChangedSignal("MapName"):Connect(function()
				-- upvalues: (ref) v_u_12, (ref) v_u_15, (copy) p_u_13, (ref) v_u_10, (ref) v_u_2
				if v_u_12() then
					local v16 = p_u_13:GetAttribute("MapName")
					if typeof(v16) ~= "string" then
						v16 = nil
					end
					if v16 then
						v_u_15:Disconnect()
						v_u_10 = v_u_2.RestoreMap(v16, v_u_10)
					end
				else
					v_u_15:Disconnect()
				end
			end)
		end
	else
		return
	end
end
local function v_u_19() -- name: handleMapAttributeChanged
	-- upvalues: (copy) v_u_12, (ref) v_u_10, (copy) v_u_2
	if v_u_12() then
		local v18 = workspace:GetAttribute("Map")
		if typeof(v18) == "string" and v18 ~= "" then
			v_u_10 = v_u_2.RestoreMap(v18, v_u_10)
		end
	end
end
v4.CreateListener(v5, "Settings.Video.Presets.Global Shadows", function()
	-- upvalues: (copy) v_u_2, (ref) v_u_10
	v_u_2.ApplyGlobalShadows(v_u_10)
end)
workspace.ChildAdded:Connect(function(p20)
	-- upvalues: (copy) v_u_17
	if p20.Name == "Map" then
		task.defer(v_u_17, p20)
	end
end)
workspace:GetAttributeChangedSignal("Map"):Connect(function()
	-- upvalues: (copy) v_u_19
	task.defer(v_u_19)
end)
local v21 = workspace:FindFirstChild("Map")
if v21 then
	task.defer(v_u_17, v21)
end
task.defer(v_u_19)
return nil
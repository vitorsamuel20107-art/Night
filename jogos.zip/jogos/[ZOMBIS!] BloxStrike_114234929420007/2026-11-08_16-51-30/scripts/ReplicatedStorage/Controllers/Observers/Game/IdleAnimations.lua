-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.IdleAnimations
-- ModuleScript | 73 linhas | 2013 bytes | hash e5da7478

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Packages.Observers)
local v_u_3 = require(v1.Controllers.GraphicsQualityController)
local v_u_4 = {}
for _, v_u_5 in {
	{
		["Tag"] = "Ceiling Fan",
		["AnimationId"] = "rbxassetid://82806563298602",
		["AnimatorPath"] = nil,
		["RequireWorkspace"] = true,
		["AnimatorPath"] = { "AnimationController", "Animator" }
	},
	{
		["Tag"] = "Flag",
		["AnimationId"] = "rbxassetid://103823379066850",
		["AnimationName"] = "FLAG_IDLE",
		["AnimatorPath"] = nil,
		["Ancestors"] = nil,
		["AnimatorPath"] = { "csFlag", "AnimationController", "Animator" },
		["Ancestors"] = { workspace }
	},
	{
		["Tag"] = "VertigoCrane",
		["AnimationId"] = "rbxassetid://75914758947993",
		["AnimationName"] = "CRANE_IDLE",
		["AnimatorPath"] = nil,
		["RequireWorkspace"] = true,
		["AnimatorPath"] = { "AnimationController", "Animator" }
	},
	{
		["Tag"] = "VertigoGenerator",
		["AnimationId"] = "rbxassetid://106431666932790",
		["AnimationName"] = "GENERATOR_IDLE",
		["AnimatorPath"] = nil,
		["RequireWorkspace"] = true,
		["AnimatorPath"] = { "AnimationController", "Animator" }
	}
} do
	local v_u_6 = Instance.new("Animation")
	v_u_6.AnimationId = v_u_5.AnimationId
	if v_u_5.AnimationName then
		v_u_6.Name = v_u_5.AnimationName
	end
	local v7 = v2.observeTag
	local v8 = v_u_5.Tag
	local v9 = v_u_5.Ancestors
	table.insert(v_u_4, v7(v8, function(p_u_10)
		-- upvalues: (copy) v_u_5, (copy) v_u_3, (copy) v_u_6
		local v11 = p_u_10
		for _, v12 in v_u_5.AnimatorPath do
			p_u_10 = p_u_10:WaitForChild(v12)
		end
		if v_u_5.RequireWorkspace and not v11:IsDescendantOf(workspace) then
			return nil
		else
			return v_u_3.RunAnimatedProp(function()
				-- upvalues: (ref) p_u_10, (ref) v_u_6
				local v_u_13 = p_u_10:LoadAnimation(v_u_6)
				v_u_13:Play()
				return function()
					-- upvalues: (copy) v_u_13
					v_u_13:Destroy()
				end
			end)
		end
	end, v9))
end
return function()
	-- upvalues: (copy) v_u_4
	for _, v14 in v_u_4 do
		v14()
	end
end
-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.Garage
-- ModuleScript | 104 linhas | 2959 bytes | hash e6d665f3

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("RunService")
local v_u_3 = require(v1.MovementV2.MoverTrajectory)
local v4 = require(v1.Packages.Observers)
local v_u_5 = require(v1.Classes.Sound)
return v4.observeTag("Garage", function(p_u_6)
	-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_5
	if not p_u_6:IsDescendantOf(workspace) then
		return nil
	end
	local v_u_7 = p_u_6:FindFirstChild("Handle")
	if v_u_7 == nil or not v_u_7:IsA("BasePart") then
		return nil
	end
	local v_u_8 = nil
	local v_u_9 = nil
	local v_u_10 = true
	local function v_u_12() -- name: applyPose
		-- upvalues: (ref) v_u_8, (copy) v_u_7, (ref) v_u_9, (ref) v_u_3
		if v_u_8 == nil or v_u_7.Parent == nil then
			if v_u_9 ~= nil then
				v_u_9:Disconnect()
				v_u_9 = nil
			end
		else
			local v11 = workspace:GetServerTimeNow()
			v_u_7.CFrame = v_u_3.EvaluateTime(v_u_8, v11)
			if (not v_u_8.Moving or v_u_3.TimeAlpha(v_u_8, v11) >= 1) and v_u_9 ~= nil then
				v_u_9:Disconnect()
				v_u_9 = nil
			end
		end
	end
	local function v14() -- name: refreshTrajectory
		-- upvalues: (ref) v_u_3, (copy) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_2, (copy) v_u_12
		local v13 = v_u_3.Read(v_u_7)
		if v13 ~= nil then
			v_u_8 = v13
			if v_u_9 ~= nil then
				v_u_9:Disconnect()
				v_u_9 = nil
			end
			if v13.Moving then
				v_u_9 = v_u_2.RenderStepped:Connect(v_u_12)
			end
			v_u_12()
		end
	end
	local v_u_15 = v_u_7:GetAttributeChangedSignal(v_u_3.Attributes.Revision):Connect(v14)
	local v_u_16 = v_u_7:GetAttributeChangedSignal(v_u_3.Attributes.Id):Connect(v14)
	local v_u_19 = v_u_3.ClientDescriptorChanged:Connect(function(p17)
		-- upvalues: (copy) v_u_7, (ref) v_u_3, (ref) v_u_8, (ref) v_u_9, (ref) v_u_2, (copy) v_u_12
		if v_u_7:GetAttribute(v_u_3.Attributes.Id) == p17 then
			local v18 = v_u_3.Read(v_u_7)
			if v18 == nil then
				return
			end
			v_u_8 = v18
			if v_u_9 ~= nil then
				v_u_9:Disconnect()
				v_u_9 = nil
			end
			if v18.Moving then
				v_u_9 = v_u_2.RenderStepped:Connect(v_u_12)
			end
			v_u_12()
		end
	end)
	local v_u_21 = p_u_6:GetAttributeChangedSignal("CurrentState"):Connect(function()
		-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) p_u_6, (ref) v_u_5
		if not v_u_10 then
			local v20 = {
				["Parent"] = v_u_7,
				["Name"] = p_u_6:GetAttribute("CurrentState") == true and "Open Garage" or "Close Garage"
			}
			v_u_5.new("Miscellaneous"):playOneTime(v20)
		end
		v_u_10 = false
	end)
	local v22 = v_u_3.Read(v_u_7)
	if v22 ~= nil then
		v_u_8 = v22
		if v_u_9 ~= nil then
			v_u_9:Disconnect()
			v_u_9 = nil
		end
		if v22.Moving then
			v_u_9 = v_u_2.RenderStepped:Connect(v_u_12)
		end
		v_u_12()
	end
	v_u_10 = false
	return function()
		-- upvalues: (ref) v_u_9, (copy) v_u_15, (copy) v_u_16, (copy) v_u_19, (copy) v_u_21
		if v_u_9 ~= nil then
			v_u_9:Disconnect()
			v_u_9 = nil
		end
		v_u_15:Disconnect()
		v_u_16:Disconnect()
		v_u_19:Disconnect()
		v_u_21:Disconnect()
	end
end)
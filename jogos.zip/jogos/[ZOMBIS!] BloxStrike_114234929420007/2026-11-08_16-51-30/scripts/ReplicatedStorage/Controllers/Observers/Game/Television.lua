-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.Television
-- ModuleScript | 87 linhas | 2529 bytes | hash c8428c03

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = require(v1.Controllers.RunServiceController)
local v_u_4 = require(v1.Packages.Observers)
local v_u_5 = require(v1.Controllers.GraphicsQualityController)
local function v_u_10(p6) -- name: getNoiseInstances
	local v7 = {}
	local v8 = p6:FindFirstChild("Screen")
	if v8 then
		for _, v9 in ipairs(v8:GetChildren()) do
			if v9.Name ~= "Noise" then
				continue
			end
			table.insert(v7, v9)
		end
	end
	return v7
end
local function v_u_14(p11) -- name: updateScreen
	for _, v12 in ipairs(p11) do
		local v13 = math.random()
		v12.Transparency = math.clamp(v13, 0.2, 0.7)
		v12.Color3 = Color3.fromRGB(192 + math.random(-10, 10), 216 + math.random(-10, 10), 255 + math.random(-10, 10))
	end
end
local function v_u_19(p15) -- name: breakScreen
	-- upvalues: (copy) v_u_2
	local v16 = p15:FindFirstChild("Screen")
	if v16 then
		v_u_2:Create(v16, TweenInfo.new(2.15), {
			["Color"] = Color3.fromRGB(0, 0, 0)
		}):Play()
		local v17 = v16.ScreenLight.PointLight
		for _ = 1, 8 do
			v17.Enabled = not v17.Enabled
			task.wait(math.random(1, 4) / 10)
		end
		v17.Enabled = false
		for _, v18 in ipairs(v16:GetChildren()) do
			if v18.Name ~= "Noise" then
				continue
			end
			v18.Transparency = 1
		end
	end
end
return v_u_4.observeTag("Television", function(p_u_20)
	-- upvalues: (copy) v_u_10, (copy) v_u_5, (copy) v_u_3, (copy) v_u_14, (copy) v_u_4, (copy) v_u_19
	local v_u_21 = 0
	if p_u_20:IsDescendantOf(workspace) then
		local v_u_22 = v_u_10(p_u_20)
		local v_u_26 = v_u_5.RunAnimatedProp(function()
			-- upvalues: (ref) v_u_3, (ref) v_u_21, (copy) p_u_20, (ref) v_u_14, (copy) v_u_22
			local v23 = v_u_3.CreateBindingName("Observers.Game.Television.Noise")
			local v_u_25 = v_u_3.BindToHeartbeat(v23, function(p24)
				-- upvalues: (ref) v_u_21, (ref) p_u_20, (ref) v_u_14, (ref) v_u_22
				v_u_21 = v_u_21 + p24
				if v_u_21 >= 0.05 then
					v_u_21 = v_u_21 % 0.05
					if p_u_20:IsDescendantOf(workspace) then
						v_u_14(v_u_22)
					end
				end
			end)
			return function()
				-- upvalues: (copy) v_u_25
				if v_u_25.Connected then
					v_u_25:Disconnect()
				end
			end
		end)
		local v_u_27 = v_u_4.observeAttribute(p_u_20, "Broken", function(_)
			-- upvalues: (ref) v_u_19, (copy) p_u_20, (copy) v_u_26
			v_u_19(p_u_20)
			if v_u_26 then
				v_u_26()
			end
		end)
		return function()
			-- upvalues: (copy) v_u_27, (copy) v_u_26
			v_u_27()
			if v_u_26 then
				v_u_26()
			end
		end
	end
end)
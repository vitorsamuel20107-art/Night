-- NIGHT Analyzer | ReplicatedStorage.Controllers.Observers.Game.BreakableDoor
-- ModuleScript | 499 linhas | 15533 bytes | hash 6c05d5ae

local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("UserInputService")
local v_u_5 = game:GetService("Workspace")
local v_u_6 = require(v3.MovementV2.MoverTrajectory)
local v_u_7 = require(v3.MovementV2.DiagnosticProtocol)
local v8 = require(v3.MovementV2.DoorSwing)
local v_u_9 = require(v3.MovementV2.Serial)
local v_u_10 = require(v3.Controllers.CharacterController)
local v_u_11 = require(v3.Controllers.RunServiceController)
local v12 = require(v3.Packages.Observers)
local v_u_13 = require(v3.Shared.Janitor)
local v_u_14 = require(v3.Database.Security.Remotes)
local v_u_15 = require(v3.Classes.Sound)
local v_u_16 = v2.LocalPlayer
local v_u_17 = v_u_16:GetMouse()
local v_u_18 = v4.TouchEnabled
if v_u_18 then
	v_u_18 = not v4.KeyboardEnabled
end
local v_u_19 = {}
local v_u_20 = nil
local v_u_21 = v8.SwingRate
local v_u_22 = {}
local function v_u_29(p23, p24) -- name: captureLayout
	local v25 = p23:FindFirstChild("BreakableDoorHingePivot")
	if v25 == nil or not v25:IsA("BasePart") then
		return false
	end
	local v26 = p23:GetAttribute("DoorClosedPivot")
	local v27
	if typeof(v26) == "CFrame" then
		v27 = v26.Position
	else
		v27 = v25.Position
	end
	p24.HingePosition = v27
	table.clear(p24.LayoutParts)
	table.clear(p24.LayoutOffsets)
	for _, v28 in p23:GetDescendants() do
		if not v28:IsA("BasePart") then
			continue
		end
		p24.LayoutParts[#p24.LayoutParts + 1] = v28
		p24.LayoutOffsets[#p24.LayoutOffsets + 1] = v25.CFrame:ToObjectSpace(v28.CFrame)
	end
	return true
end
local function v_u_49(p30, p31, p32) -- name: setPose
	-- upvalues: (copy) v_u_29
	if p30.Parent == nil then
		return
	elseif p31.HingePosition ~= nil or v_u_29(p30, p31) then
		local v33 = p31.HingePosition
		local v34 = (p32.Position - v33).Magnitude
		if v34 > 0.25 and not p31.WarnedDrift then
			p31.WarnedDrift = true
			local v35 = p31.Descriptor
			local v36 = warn
			local v37 = string.format
			local v38 = "[BreakableDoor] presented pose left its hinge by %.2f studs model=%s id=%s revision=%s moving=%s"
			local v39 = p30:GetFullName()
			local v40
			if v35 then
				v40 = v35.Id
			else
				v40 = v35
			end
			local v41 = tostring(v40)
			local v42
			if v35 then
				v42 = v35.Revision
			else
				v42 = v35
			end
			local v43 = tostring(v42)
			if v35 then
				v35 = v35.Moving
			end
			v36(v37(v38, v34, v39, v41, v43, (tostring(v35))))
		end
		local v44 = CFrame.new(v33) * p32.Rotation
		local v45 = {}
		local v46 = {}
		for v47, v48 in p31.LayoutParts do
			if v48.Parent == nil then
				continue
			end
			v45[#v45 + 1] = v48
			v46[#v46 + 1] = v44 * p31.LayoutOffsets[v47]
		end
		workspace:BulkMoveTo(v45, v46, Enum.BulkMoveMode.FireCFrameChanged)
	end
end
local function v_u_58(p50, p51) -- name: presentationTarget
	-- upvalues: (copy) v_u_6, (copy) v_u_9
	local v52 = v_u_6.GetClientPresentation(p50.Id)
	local v53, v54 = v_u_6.GetClientPresentationClock()
	if v52 == nil or v53 == nil then
		local v55 = v_u_6.EvaluateTime(p50, p51)
		return {
			["Pose"] = nil,
			["RestPose"] = nil,
			["Predicted"] = false,
			["Moving"] = nil,
			["Discontinuity"] = 0,
			["Descriptor"] = nil,
			["Pose"] = v55,
			["RestPose"] = v55,
			["Moving"] = v_u_6.PresentationMoving(p50, p51),
			["Descriptor"] = p50
		}
	end
	local v56 = v_u_9.deltaUInt32(v53, v52.ServerTick)
	local v57
	if v56 == 0 then
		v57 = v52.PreviousPose:Lerp(v52.Pose, v54)
	elseif v56 < 0 then
		v57 = v52.PreviousPose
	else
		v57 = v52.Pose
	end
	return {
		["Pose"] = nil,
		["RestPose"] = nil,
		["Predicted"] = true,
		["Moving"] = nil,
		["Discontinuity"] = nil,
		["Descriptor"] = nil,
		["Pose"] = v57,
		["RestPose"] = v52.Pose,
		["Moving"] = v52.PreviousPose ~= v52.Pose,
		["Discontinuity"] = v52.Discontinuity,
		["Descriptor"] = v52.Descriptor
	}
end
local function v_u_83(p59, p60, p61, p62) -- name: stepTowardPose
	-- upvalues: (copy) v_u_21
	local _, v63 = p59.Rotation:ToObjectSpace(p60.Rotation):ToAxisAngle()
	local v64 = math.abs(v63)
	local v65 = (p60.Position - p59.Position).Magnitude
	if v64 <= 0.0001 and v65 <= 0.0001 then
		return p60
	end
	local v66 = (p61.TargetPose.Position - p61.StartPose.Position).Magnitude
	local v67 = p61.DurationSeconds
	local v68 = math.max(v67, 0.001)
	local v69
	if p61.Moving then
		local v70 = p61.StartPose
		local v71 = p61.TargetPose
		local _, v72 = v70.Rotation:ToObjectSpace(v71.Rotation):ToAxisAngle()
		local v73 = math.abs(v72)
		local v74 = p61.DurationSeconds
		local v75 = v73 / math.max(v74, 0.001)
		local v76 = v_u_21
		v69 = math.max(v75, v76)
	else
		v69 = v_u_21
	end
	local v77 = v66 / v68
	local v78 = math.max(v77, 8)
	local v79 = 1
	if v64 > 0.0001 then
		local v80 = v69 * 1.5 * math.max(p62, 0)
		local v81 = math.min(v80, 0.20943951023931956) / v64
		v79 = math.min(v79, v81)
	end
	if v65 > 0.0001 then
		local v82 = v78 * 1.5 * math.max(p62, 0) / v65
		v79 = math.min(v79, v82)
	end
	return p59:Lerp(p60, (math.clamp(v79, 0, 1)))
end
local function v_u_109(p84, p85, p86) -- name: correctedPose
	-- upvalues: (copy) v_u_21
	if p84.SeenDiscontinuity ~= p85.Discontinuity then
		p84.SeenDiscontinuity = p85.Discontinuity
		local v87 = p84.CurrentPose
		p84.CorrectionOffset = nil
		if v87 ~= nil then
			local v88 = p85.Pose
			local _, v89 = v87.Rotation:ToObjectSpace(v88.Rotation):ToAxisAngle()
			if math.abs(v89) > 0.0001 and true or (v87.Position - v88.Position).Magnitude > 0.0001 then
				local v90 = p85.Pose:ToObjectSpace(v87)
				local _, v91 = v90:ToAxisAngle()
				local v92 = math.abs(v91)
				local v93 = p85.Descriptor
				local v94
				if v93.Moving then
					local v95 = v93.StartPose
					local v96 = v93.TargetPose
					local _, v97 = v95.Rotation:ToObjectSpace(v96.Rotation):ToAxisAngle()
					local v98 = math.abs(v97)
					local v99 = v93.DurationSeconds
					local v100 = v98 / math.max(v99, 0.001)
					local v101 = v_u_21
					v94 = math.max(v100, v101)
				else
					v94 = v_u_21
				end
				local v102 = v92 / v94
				local v103 = v90.Position.Magnitude / 8
				local v104 = math.max(v102, v103)
				p84.CorrectionOffset = v90
				p84.CorrectionElapsed = 0
				p84.CorrectionSeconds = math.min(0.1, v104)
			end
		end
	end
	local v105 = p84.CorrectionOffset
	if v105 == nil then
		return p85.Pose
	end
	p84.CorrectionElapsed = p84.CorrectionElapsed + math.max(p86, 0)
	local v106 = p84.CorrectionElapsed
	local v107 = p84.CorrectionSeconds
	local v108 = 1 - v106 / math.max(v107, 0.001)
	if v108 > 0 then
		return p85.Pose * CFrame.identity:Lerp(v105, v108)
	end
	p84.CorrectionOffset = nil
	return p85.Pose
end
local function v_u_123(p110) -- name: stepVisuals
	-- upvalues: (copy) v_u_22, (copy) v_u_58, (copy) v_u_109, (copy) v_u_83, (copy) v_u_7, (copy) v_u_16, (copy) v_u_5, (copy) v_u_49, (copy) v_u_6, (ref) v_u_20
	local v111 = workspace:GetServerTimeNow()
	local v112 = false
	for v113, v114 in v_u_22 do
		local v115 = v114.Descriptor
		if v113.Parent == nil then
			v_u_22[v113] = nil
		else
			if v115 == nil then
				continue
			end
			local v116 = v_u_58(v115, v111)
			local v117 = v114.CurrentPose or v113:GetPivot()
			local v118
			if v116.Predicted then
				v118 = v_u_109(v114, v116, p110)
			else
				v118 = v_u_83(v117, v116.Pose, v115, p110)
			end
			local v119 = v_u_7.shouldOutputForPlayer(v_u_16)
			if v119 then
				v119 = v_u_5:GetAttribute("MovementV2DoorDebug") == true
			end
			if v119 and (v115.Moving and v114.LoggedMotionRevision ~= v115.Revision) then
				local _, v120 = v118.Rotation:ToObjectSpace(v117.Rotation):ToAxisAngle()
				if math.abs(v120) > 0.0001 and true or (v118.Position - v117.Position).Magnitude > 0.0001 then
					v114.LoggedMotionRevision = v115.Revision
					print(string.format("[MovementV2.Door] visual-start id=%d revision=%d clientTime=%.6f descriptorAge=%.4f", v115.Id, v115.Revision, v111, v111 - v115.StartServerTime))
				end
			end
			v114.CurrentPose = v118
			v_u_49(v113, v114, v118)
			if not v116.Moving and (v114.CorrectionOffset == nil and not v_u_6.PresentationMoving(v115, v111)) then
				local v121 = v116.RestPose
				local _, v122 = v118.Rotation:ToObjectSpace(v121.Rotation):ToAxisAngle()
				if math.abs(v122) <= 0.0001 and (v118.Position - v121.Position).Magnitude <= 0.0001 then
					continue
				end
			end
			v112 = true
		end
	end
	if not v112 and v_u_20 ~= nil then
		v_u_20:Disconnect()
		v_u_20 = nil
	end
end
local function v_u_140(p124) -- name: refreshTrajectory
	-- upvalues: (copy) v_u_22, (copy) v_u_6, (copy) v_u_58, (copy) v_u_7, (copy) v_u_16, (copy) v_u_5, (copy) v_u_49, (ref) v_u_20, (copy) v_u_11, (copy) v_u_123
	local v125 = v_u_22[p124]
	if v125 == nil then
		return
	end
	local v126 = v_u_6.Read(p124)
	if v126 == nil then
		return
	end
	local v127 = v125.Descriptor == nil
	local v128
	if v125.Descriptor == nil then
		v128 = nil
	else
		v128 = v125.Descriptor.Revision
	end
	v125.Descriptor = v126
	local v129 = workspace:GetServerTimeNow()
	local v130 = v_u_58(v126, v129)
	local v131 = v_u_7.shouldOutputForPlayer(v_u_16)
	if v131 then
		v131 = v_u_5:GetAttribute("MovementV2DoorDebug") == true
	end
	if v131 and v126.Revision ~= v128 then
		local v132 = print
		local v133 = string.format
		local v134 = v126.Id
		local v135 = v126.Revision
		local v136 = v126.Moving
		v132(v133("[MovementV2.Door] descriptor id=%d revision=%d moving=%s clientTime=%.6f startTime=%.6f descriptorAge=%.4f", v134, v135, tostring(v136), v129, v126.StartServerTime, v129 - v126.StartServerTime))
	end
	if v127 then
		v125.CurrentPose = v130.Pose
		v125.SeenDiscontinuity = v130.Discontinuity
		v_u_49(p124, v125, v130.Pose)
	end
	local v137 = v125.CurrentPose or p124:GetPivot()
	if v126.Moving or (v130.Moving or v130.Discontinuity ~= v125.SeenDiscontinuity) then
		if v_u_20 == nil then
			v_u_20 = v_u_11.BindToRenderStep("Observers.Game.BreakableDoor.StepVisuals", Enum.RenderPriority.Last.Value, v_u_123)
		end
		return
	else
		local v138 = v130.Pose
		local _, v139 = v137.Rotation:ToObjectSpace(v138.Rotation):ToAxisAngle()
		if math.abs(v139) > 0.0001 and true or (v137.Position - v138.Position).Magnitude > 0.0001 then
			if v_u_20 == nil then
				v_u_20 = v_u_11.BindToRenderStep("Observers.Game.BreakableDoor.StepVisuals", Enum.RenderPriority.Last.Value, v_u_123)
			end
		end
	end
end
local function v_u_149() -- name: useMouseDoor
	-- upvalues: (copy) v_u_17, (copy) v_u_19, (copy) v_u_10, (copy) v_u_7, (copy) v_u_16, (copy) v_u_5, (copy) v_u_14
	local v141 = v_u_17.Target
	while v141 ~= nil do
		if v141:IsA("Model") and v_u_19[v141] then
			if v_u_10.IsDoorInUseRange(v141) then
				local v142 = v_u_7.shouldOutputForPlayer(v_u_16)
				if v142 then
					v142 = v_u_5:GetAttribute("MovementV2DoorDebug") == true
				end
				if v142 then
					print(string.format("[MovementV2.Door] use-send source=Mouse model=%s clientTime=%.6f", v141:GetFullName(), workspace:GetServerTimeNow()))
				end
				local v143 = v_u_10.PredictDoorUse(v141)
				local v144 = v_u_14.BreakableDoor.Use.Send
				local v145 = {
					["Model"] = v141
				}
				local v146
				if v143 == nil then
					v146 = nil
				else
					v146 = v143.ServerTick
				end
				v145.ServerTick = v146
				local v147
				if v143 == nil then
					v147 = nil
				else
					v147 = v143.TargetAngle
				end
				v145.TargetAngle = v147
				local v148
				if v143 == nil then
					v148 = nil
				else
					v148 = v143.RequestId
				end
				v145.RequestId = v148
				v144(v145)
			end
		end
		v141 = v141.Parent
	end
end
v_u_17.Button1Down:Connect(function()
	-- upvalues: (copy) v_u_18, (copy) v_u_149
	if not v_u_18 then
		v_u_149()
	end
end)
local function v_u_163(p_u_150, p151) -- name: releaseVisualStage
	-- upvalues: (copy) v_u_22, (copy) v_u_15, (copy) v_u_1
	local v152 = v_u_22[p_u_150]
	if v152 ~= nil then
		local v153 = p_u_150:GetAttribute("BreakDirectionX") or 0
		local v154 = p_u_150:GetAttribute("BreakDirectionY") or 0
		local v155 = p_u_150:GetAttribute("BreakDirectionZ") or 0
		local v156 = Vector3.new(v153, v154, v155)
		local v157 = v156.Magnitude <= 0 and Vector3.new(0, 0, 1) or v156.Unit
		local v158 = workspace:FindFirstChild("Debris") or workspace
		for _, v159 in v152.StageParts[p151] or {} do
			if v159.Parent == nil then
				continue
			end
			local v_u_160 = v159:Clone()
			v_u_160.Transparency = v152.Transparencies[v159] or 0
			v_u_160.Anchored = false
			v_u_160.CanCollide = true
			v_u_160.CanQuery = false
			v_u_160.CanTouch = true
			v_u_160.CFrame = v159.CFrame
			v_u_160:SetAttribute("BreakableDoorDebris", true)
			local v_u_161 = nil
			v_u_161 = v_u_160.Touched:Connect(function(p162)
				-- upvalues: (copy) p_u_150, (ref) v_u_161, (ref) v_u_15, (copy) v_u_160
				if p162.CanCollide and (p162:GetAttribute("BreakableDoorDebris") ~= true and not p162:IsDescendantOf(p_u_150)) then
					if v_u_161 ~= nil then
						v_u_161:Disconnect()
						v_u_161 = nil
					end
					v_u_15.new("BreakableDoor"):PlaySoundAtPosition({
						["Position"] = nil,
						["Class"] = "BreakableDoor",
						["Name"] = "Part Hit Ground",
						["Position"] = v_u_160.Position
					})
				end
			end)
			v_u_160.Parent = v158
			v_u_1:AddItem(v_u_160, 8)
			v_u_160:ApplyImpulse((v157 + Vector3.new(0, 0.35, 0)) * v_u_160.AssemblyMass * math.random(20, 35))
		end
	end
end
local function v_u_168(p164) -- name: applyStage
	-- upvalues: (copy) v_u_22, (copy) v_u_163
	local v165 = v_u_22[p164]
	if v165 ~= nil then
		local v166 = p164:GetAttribute("Stage") or 0
		for v167 = v165.Stage + 1, v166 do
			v_u_163(p164, v167)
		end
		v165.Stage = v166
	end
end
return v12.observeTag("BreakableDoor", function(p_u_169)
	-- upvalues: (copy) v_u_13, (copy) v_u_19, (copy) v_u_22, (copy) v_u_140, (copy) v_u_6, (copy) v_u_168, (ref) v_u_20
	if not p_u_169:IsA("Model") then
		return nil
	end
	local v_u_170 = v_u_13.new()
	local v171 = {
		["Stage"] = nil,
		["StageParts"] = nil,
		["Transparencies"] = nil,
		["CorrectionElapsed"] = 0,
		["CorrectionSeconds"] = 0,
		["LayoutParts"] = nil,
		["LayoutOffsets"] = nil,
		["WarnedDrift"] = false,
		["Stage"] = p_u_169:GetAttribute("Stage") or 0,
		["StageParts"] = {},
		["Transparencies"] = {},
		["LayoutParts"] = {},
		["LayoutOffsets"] = {}
	}
	v_u_19[p_u_169] = true
	v_u_22[p_u_169] = v171
	for _, v172 in p_u_169:GetChildren() do
		if not v172:IsA("BasePart") then
			continue
		end
		local v173 = v172.Name
		local v174 = tonumber(v173:match("^Stage(%d)Break$"))
		if v174 == nil then
			continue
		end
		v171.StageParts[v174] = v171.StageParts[v174] or {}
		v171.StageParts[v174][#v171.StageParts[v174] + 1] = v172
		v171.Transparencies[v172] = v172.Transparency
	end
	v_u_140(p_u_169)
	v_u_170:Add(v_u_6.ClientDescriptorChanged:Connect(function(p175)
		-- upvalues: (copy) p_u_169, (ref) v_u_6, (ref) v_u_140
		if p_u_169:GetAttribute(v_u_6.Attributes.Id) == p175 then
			v_u_140(p_u_169)
		end
	end))
	for _, v176 in { v_u_6.Attributes.Id, v_u_6.Attributes.Revision } do
		v_u_170:Add(p_u_169:GetAttributeChangedSignal(v176):Connect(function()
			-- upvalues: (ref) v_u_140, (copy) p_u_169
			v_u_140(p_u_169)
		end))
	end
	v_u_170:Add(p_u_169:GetAttributeChangedSignal("Stage"):Connect(function()
		-- upvalues: (ref) v_u_168, (copy) p_u_169
		v_u_168(p_u_169)
	end))
	v_u_170:Add(function()
		-- upvalues: (ref) v_u_19, (copy) p_u_169, (ref) v_u_22, (ref) v_u_20
		v_u_19[p_u_169] = nil
		v_u_22[p_u_169] = nil
		if next(v_u_22) == nil and v_u_20 ~= nil then
			v_u_20:Disconnect()
			v_u_20 = nil
		end
	end)
	return function()
		-- upvalues: (copy) v_u_170
		v_u_170:Destroy()
	end
end)
-- NIGHT Analyzer | ReplicatedStorage.Controllers.CandyController.PickupFeed
-- ModuleScript | 311 linhas | 9222 bytes | hash 3eb923a7

local v_u_1 = {}
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("ContentProvider")
local v_u_4 = game:GetService("SoundService")
local v_u_5 = game:GetService("GuiService")
local v_u_6 = game:GetService("Workspace")
local v7 = game:GetService("Players")
local v_u_8 = require(v2.Controllers.RunServiceController)
local v_u_9 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.ExtraBold, Enum.FontStyle.Italic)
local v_u_10 = Color3.fromRGB(255, 205, 110)
local v_u_11 = Color3.fromRGB(255, 120, 20)
local v_u_12 = NumberRange.new(0.2, 0.8)
local v_u_13 = NumberRange.new(0.74, 0.88)
local v_u_14 = Color3.fromRGB(255, 130, 20)
local v_u_15 = Color3.fromRGB(255, 236, 190)
local v_u_16 = Vector2.new(0.28363636363636363, 0.5)
local v_u_17 = {
	0,
	2,
	4,
	7,
	9,
	12,
	14,
	16,
	19
}
local v_u_18 = v7.LocalPlayer
local v_u_19 = Random.new()
local v_u_20 = {}
local v_u_21 = {}
local v_u_22 = nil
local v_u_23 = nil
local v_u_24 = {}
local v_u_25 = 1
local v_u_26 = 0
local v_u_27 = (-1 / 0)
local function v_u_38() -- name: makePopup
	-- upvalues: (copy) v_u_14, (copy) v_u_16, (copy) v_u_9, (copy) v_u_10, (copy) v_u_11, (copy) v_u_15
	local v28 = Instance.new("Frame")
	v28.Name = "CandyPopup"
	v28.AnchorPoint = Vector2.new(0.5, 0.5)
	v28.Size = UDim2.fromScale(1, 0.072)
	v28.BackgroundTransparency = 1
	local v29 = Instance.new("UIAspectRatioConstraint")
	v29.AspectRatio = 2.2
	v29.DominantAxis = Enum.DominantAxis.Height
	v29.Parent = v28
	Instance.new("UIScale").Parent = v28
	local v30 = Instance.new("ImageLabel")
	v30.Name = "Glow"
	v30.AnchorPoint = Vector2.new(0.5, 0.5)
	v30.Position = UDim2.fromScale(0.42, 0.5)
	v30.Size = UDim2.fromScale(1.9, 3.6)
	v30.BackgroundTransparency = 1
	v30.Image = "rbxassetid://10906540366"
	v30.ImageColor3 = v_u_14
	v30.ImageTransparency = 1
	v30.ZIndex = 1
	v30.Parent = v28
	local v31 = Instance.new("ImageLabel")
	v31.Name = "Icon"
	v31.AnchorPoint = Vector2.new(0.5, 0.5)
	v31.Position = UDim2.fromScale(v_u_16.X, v_u_16.Y)
	v31.Size = UDim2.fromScale(0.7272727272727273, 1.6)
	v31.BackgroundTransparency = 1
	v31.Image = "rbxassetid://114576415464386"
	v31.ScaleType = Enum.ScaleType.Fit
	v31.ZIndex = 3
	v31.Parent = v28
	local v32 = Instance.new("TextLabel")
	v32.Name = "Amount"
	v32.AnchorPoint = Vector2.new(1, 0.5)
	v32.Position = UDim2.fromScale(1, 0.5)
	v32.Size = UDim2.fromScale(0.4318181818181819, 0.95)
	v32.BackgroundTransparency = 1
	v32.FontFace = v_u_9
	v32.TextScaled = true
	v32.TextXAlignment = Enum.TextXAlignment.Left
	v32.TextColor3 = Color3.new(1, 1, 1)
	v32.Text = "+1"
	v32.ZIndex = 3
	local v33 = Instance.new("UIGradient")
	v33.Color = ColorSequence.new(v_u_10, v_u_11)
	v33.Rotation = 90
	v33.Parent = v32
	local v34 = Instance.new("UIStroke")
	v34.Color = Color3.new(0, 0, 0)
	v34.Thickness = 0.09
	v34.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
	v34.Parent = v32
	v32.Parent = v28
	local v35 = {}
	for v36 = 1, 4 do
		local v37 = Instance.new("ImageLabel")
		v37.Name = ("Spark%*"):format(v36)
		v37.AnchorPoint = Vector2.new(0.5, 0.5)
		v37.Size = UDim2.fromScale(0.40909090909090906, 0.9)
		v37.BackgroundTransparency = 1
		v37.Image = "rbxasset://textures/particles/sparkles_main.dds"
		v37.ImageColor3 = v_u_15
		v37.ZIndex = 4
		v37.Parent = v28
		v35[v36] = v37
	end
	return v28, v35
end
local function v_u_50(p39, p40) -- name: stepFlash
	-- upvalues: (copy) v_u_16
	local v41 = p39.Frame
	local v42 = p40 / 0.45
	local v43 = math.min(v42, 1)
	v41.Glow.ImageTransparency = v43 * 1 + 0
	local v44 = p40 / 0.4
	local v45 = math.min(v44, 1)
	local v46 = (1 - (1 - v45) ^ 3) * 1.2
	for v47, v48 in p39.Sparks do
		if v45 >= 1 then
			v48.Visible = false
		else
			local v49 = p39.SparkDirections[v47]
			v48.Position = UDim2.fromScale(v_u_16.X + v49.X * v46 / 2.2, v_u_16.Y + v49.Y * v46)
			v48.ImageTransparency = v45
			v48.Rotation = v45 * 180
		end
	end
end
local function v_u_62() -- name: update
	-- upvalues: (copy) v_u_5, (copy) v_u_21, (copy) v_u_20, (copy) v_u_50, (ref) v_u_22
	local v51 = os.clock()
	local v52 = v_u_5.ReducedMotionEnabled
	local v53 = 1
	while v53 <= #v_u_21 do
		local v54 = v_u_21[v53]
		local v55 = v51 - v54.BornAt
		if v55 >= 1.35 then
			local v56 = v_u_21[v53]
			v_u_21[v53] = v_u_21[#v_u_21]
			v_u_21[#v_u_21] = nil
			v56.Frame.Parent = nil
			v_u_20[#v_u_20 + 1] = {
				["Frame"] = v56.Frame,
				["Sparks"] = v56.Sparks
			}
		else
			local v57 = v54.Frame
			local v58 = v52 and 0 or 1 - (1 - v55 / 1.35) ^ 3
			v57.Position = UDim2.fromScale(v54.Start.X + v54.Drift * v58, v54.Start.Y - v58 * 0.17)
			if v52 or v55 >= 0.24 then
				v57.UIScale.Scale = v54.Size
				v57.Rotation = 0
			else
				local v59 = v55 / 0.24
				v57.UIScale.Scale = v54.Size * ((v59 - 1) ^ 3 * 4 + 1 + (v59 - 1) ^ 2 * 3)
				v57.Rotation = v54.Tilt * (1 - v59) ^ 2
			end
			if not (v52 or v54.FlashDone) then
				v_u_50(v54, (math.min(v55, 0.45)))
				v54.FlashDone = v55 >= 0.45
			end
			local v60 = (v55 - 0.8500000000000001) / 0.5
			local v61 = math.clamp(v60, 0, 1)
			v57.Icon.ImageTransparency = v61
			v57.Amount.TextTransparency = v61
			v57.Amount.UIStroke.Transparency = v61
			v53 = v53 + 1
		end
	end
	if #v_u_21 == 0 and v_u_22 then
		v_u_22:Disconnect()
		v_u_22 = nil
	end
end
function v_u_1.LadderPitch(p63) -- name: LadderPitch
	-- upvalues: (copy) v_u_17
	local v64 = v_u_17
	local v65 = p63 + 1
	local v66 = #v_u_17
	return 2 ^ (v64[math.min(v65, v66)] / 12)
end
function v_u_1.Preload() -- name: Preload
	-- upvalues: (copy) v_u_24, (copy) v_u_4, (copy) v_u_3
	for _, v67 in v_u_24 do
		v67:Destroy()
	end
	table.clear(v_u_24)
	for v68 = 1, 4 do
		local v69 = Instance.new("Sound")
		v69.Name = ("CandyCollect%*"):format(v68)
		v69.SoundId = "rbxassetid://15675059323"
		v69.Volume = 0.5
		v69.Parent = v_u_4
		v_u_24[v68] = v69
	end
	local v_u_70 = table.clone(v_u_24)
	table.insert(v_u_70, "rbxassetid://114576415464386")
	table.insert(v_u_70, "rbxassetid://10906540366")
	task.spawn(function()
		-- upvalues: (ref) v_u_3, (copy) v_u_70
		local v71 = v_u_3.PreloadAsync
		local v72 = v_u_3
		local v73 = v_u_70
		pcall(v71, v72, v73)
	end)
end
function v_u_1.Collect() -- name: Collect
	-- upvalues: (ref) v_u_23, (copy) v_u_18, (copy) v_u_6, (copy) v_u_21, (copy) v_u_20, (copy) v_u_38, (ref) v_u_26, (ref) v_u_27, (copy) v_u_24, (ref) v_u_25, (copy) v_u_1, (copy) v_u_5, (copy) v_u_19, (copy) v_u_12, (copy) v_u_13, (copy) v_u_16, (ref) v_u_22, (copy) v_u_8, (copy) v_u_62
	local v74 = v_u_23
	if not (v74 and v74.Parent) then
		local v75 = v_u_18:FindFirstChildOfClass("PlayerGui")
		if v75 then
			v74 = Instance.new("ScreenGui")
			v74.Name = "CandyFeed"
			v74.IgnoreGuiInset = true
			v74.ResetOnSpawn = false
			v74.DisplayOrder = 5
			v74.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
			v74.Parent = v75
			v_u_23 = v74
		else
			v74 = nil
		end
	end
	if v74 and v_u_6.CurrentCamera then
		if #v_u_21 >= 40 then
			local v76 = 1
			for v77, v78 in v_u_21 do
				if v78.BornAt >= v_u_21[v76].BornAt then
					continue
				end
				v76 = v77
			end
			local v79 = v_u_21[v76]
			v_u_21[v76] = v_u_21[#v_u_21]
			v_u_21[#v_u_21] = nil
			v79.Frame.Parent = nil
			v_u_20[#v_u_20 + 1] = {
				["Frame"] = v79.Frame,
				["Sparks"] = v79.Sparks
			}
		end
		local v80 = table.remove(v_u_20)
		local v81, v82
		if v80 then
			v81 = v80.Frame
			v82 = v80.Sparks
		else
			v81, v82 = v_u_38()
		end
		local v83 = os.clock()
		v_u_26 = v83 - v_u_27 > 1 and 0 or v_u_26 + 1
		v_u_27 = v83
		local v84 = v_u_24[v_u_25]
		if v84 then
			v_u_25 = v_u_25 % #v_u_24 + 1
			v84.PlaybackSpeed = v_u_1.LadderPitch(v_u_26)
			v84.TimePosition = 0
			v84:Play()
		end
		local v85 = v_u_5.ReducedMotionEnabled
		local v86 = Vector2.new(v_u_19:NextNumber(v_u_12.Min, v_u_12.Max), v_u_19:NextNumber(v_u_13.Min, v_u_13.Max))
		local v87 = v_u_19:NextNumber(0, 6.283185307179586)
		local v88 = table.create(4)
		for v89, v90 in v82 do
			local v91 = v87 + (v89 - 1) / 4 * 2 * 3.141592653589793
			v88[v89] = Vector2.new(math.cos(v91), (math.sin(v91)))
			v90.Visible = not v85
			v90.Position = UDim2.fromScale(v_u_16.X, v_u_16.Y)
			v90.ImageTransparency = 0
		end
		local v92 = {
			["Frame"] = v81,
			["Sparks"] = v82,
			["Start"] = v86,
			["Drift"] = v_u_19:NextNumber(-0.03, 0.03),
			["Tilt"] = v85 and 0 or v_u_19:NextNumber(-14, 14)
		}
		local v93 = v_u_26
		v92.Size = math.min(v93, 8) * 0.05 + 1
		v92.SparkDirections = v88
		v92.FlashDone = v85
		v92.BornAt = v83
		v81.Position = UDim2.fromScale(v86.X, v86.Y)
		v81.Rotation = v92.Tilt
		v81.UIScale.Scale = not v85 and 0 or v92.Size
		v81.Glow.ImageTransparency = v85 and 1 or 0
		v81.Icon.ImageTransparency = 0
		v81.Amount.TextTransparency = 0
		v81.Amount.UIStroke.Transparency = 0
		v81.Parent = v74
		v_u_21[#v_u_21 + 1] = v92
		if not v_u_22 then
			v_u_22 = v_u_8.BindToRenderSteppedEvent("Survival.CandyFeed", v_u_62)
		end
	end
end
function v_u_1.Clear() -- name: Clear
	-- upvalues: (copy) v_u_21, (copy) v_u_20
	while #v_u_21 > 0 do
		local v94 = #v_u_21
		local v95 = v_u_21[v94]
		v_u_21[v94] = v_u_21[#v_u_21]
		v_u_21[#v_u_21] = nil
		v95.Frame.Parent = nil
		v_u_20[#v_u_20 + 1] = {
			["Frame"] = v95.Frame,
			["Sparks"] = v95.Sparks
		}
	end
end
return v_u_1
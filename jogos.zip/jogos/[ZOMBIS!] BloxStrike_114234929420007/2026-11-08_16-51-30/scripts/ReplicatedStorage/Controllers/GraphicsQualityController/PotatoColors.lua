-- NIGHT Analyzer | ReplicatedStorage.Controllers.GraphicsQualityController.PotatoColors
-- ModuleScript | 4893 linhas | 53370 bytes | hash 26b988a4

local v1 = {
	["MaterialVariants"] = {
		["Asphalt/AsphaltDamaged_9602"] = {
			191,
			184,
			167,
			1
		},
		["Asphalt/AsphaltRoadCracked_9614"] = {
			112,
			105,
			93,
			1
		},
		["Asphalt/AsphaltRoadCracked_9616"] = {
			93,
			88,
			79,
			1
		},
		["Asphalt/CityStreetAsphaltGenericDamaged001"] = {
			56,
			57,
			55,
			1
		},
		["Asphalt/ConcreteFoundation"] = {
			145,
			142,
			138,
			1
		},
		["Asphalt/ConcreteFoundationSmall"] = {
			145,
			142,
			138,
			1
		},
		["Asphalt/ConcreteFreeway_12302"] = {
			195,
			184,
			167,
			1
		},
		["Asphalt/ConcretePanelsGrungy"] = {
			105,
			106,
			93,
			1
		},
		["Asphalt/Concretetrim"] = {
			139,
			135,
			128,
			1
		},
		["Asphalt/Cracked Concrete Wall"] = {
			184,
			183,
			182,
			1
		},
		["Asphalt/CrackedAsphalt"] = {
			105,
			102,
			97,
			1
		},
		["Asphalt/CrackedAsphalt2"] = {
			128,
			128,
			125,
			1
		},
		["Asphalt/GroundAsphaltDamaged_10849"] = {
			173,
			167,
			158,
			1
		},
		["Asphalt/MatteConcrete"] = {
			205,
			195,
			178,
			1
		},
		["Asphalt/Painted Concrete"] = {
			177,
			165,
			150,
			1
		},
		["Asphalt/Painted Concrete2"] = {
			219,
			218,
			215,
			1
		},
		["Asphalt/PolishedConcrete"] = {
			199,
			199,
			194,
			1
		},
		["Asphalt/PolishedConcreteFloor"] = {
			205,
			195,
			178,
			1
		},
		["Asphalt/RoadAsphalt"] = {
			104,
			101,
			98,
			1
		},
		["Asphalt/SealedConcrete"] = {
			200,
			200,
			200,
			1
		},
		["Asphalt/SmoothAsphalt"] = {
			172,
			177,
			172,
			1
		},
		["Asphalt/Wall Plaster"] = {
			226,
			222,
			218,
			1
		},
		["Asphalt/Worn Wall Plaster"] = {
			152,
			146,
			142,
			1
		},
		["Asphalt/WornPlaster"] = {
			217,
			208,
			201,
			1
		},
		["Asphalt/rubblewall"] = {
			177,
			165,
			150,
			1
		},
		["Brick/BeigeBricks"] = {
			174,
			172,
			171,
			1
		},
		["Brick/BiegeBlocks"] = {
			204,
			197,
			185,
			1
		},
		["Brick/BrickConcrete"] = {
			177,
			177,
			177,
			1
		},
		["Brick/BrickPaverRunning_9175"] = {
			140,
			120,
			110,
			1
		},
		["Brick/BrickWallOld_12262"] = {
			136,
			110,
			96,
			1
		},
		["Brick/BricksLongThinRunningExtruded001"] = {
			147,
			138,
			130,
			1
		},
		["Brick/BricksPaintedGrey001"] = {
			164,
			165,
			160,
			1
		},
		["Brick/ConcretePanels2"] = {
			172,
			172,
			172,
			1
		},
		["Brick/Faded Brick 2"] = {
			174,
			167,
			162,
			1
		},
		["Brick/Faded Brick"] = {
			200,
			180,
			163,
			1
		},
		["Brick/OutdoorBrick"] = {
			164,
			141,
			129,
			1
		},
		["Brick/PaintedBricksBig"] = {
			251,
			251,
			251,
			1
		},
		["Brick/Peeling Brick"] = {
			214,
			214,
			214,
			1
		},
		["Brick/Sandy Brick"] = {
			175,
			160,
			140,
			1
		},
		["Brick/WornBrick"] = {
			198,
			195,
			192,
			1
		},
		["Brick/WornBrickBig"] = {
			198,
			195,
			192,
			1
		},
		["Brick/Y2K roof_shingles"] = {
			92,
			85,
			82,
			1
		},
		["Brick/YellowBricks"] = {
			198,
			189,
			163,
			1
		},
		["CeramicTiles/CeramicSquareTile_9979"] = {
			198,
			183,
			168,
			1
		},
		["CeramicTiles/KitchenTile"] = {
			156,
			142,
			133,
			1
		},
		["CeramicTiles/MarbleTile"] = {
			217,
			211,
			200,
			1
		},
		["CeramicTiles/MarbleTile2"] = {
			215,
			208,
			199,
			1
		},
		["CeramicTiles/PlainCeramicTiles"] = {
			151,
			138,
			118,
			1
		},
		["CeramicTiles/Tile 2"] = {
			195,
			161,
			122,
			1
		},
		["CeramicTiles/Tile 3"] = {
			170,
			153,
			140,
			1
		},
		["CeramicTiles/Tile 3bigger"] = {
			170,
			153,
			140,
			1
		},
		["CeramicTiles/WallTile"] = {
			246,
			246,
			246,
			1
		},
		["Concrete/AdobeWall"] = {
			226,
			177,
			129,
			1
		},
		["Concrete/BlocksBurnishedWhite001"] = {
			211,
			209,
			200,
			1
		},
		["Concrete/BoardFormConcrete"] = {
			166,
			171,
			171,
			1
		},
		["Concrete/BoardFormConcreteBig"] = {
			166,
			171,
			171,
			1
		},
		["Concrete/Brick Tiles 2"] = {
			185,
			185,
			185,
			1
		},
		["Concrete/Brick Tiles 3"] = {
			200,
			200,
			200,
			1
		},
		["Concrete/Brick Tiles"] = {
			199,
			198,
			196,
			1
		},
		["Concrete/BrushedConrete"] = {
			194,
			192,
			192,
			1
		},
		["Concrete/BrushedConreteLarge"] = {
			194,
			192,
			192,
			1
		},
		["Concrete/BuildingFacadeOffice_13227"] = {
			131,
			130,
			128,
			1
		},
		["Concrete/CinderBlockWall"] = {
			202,
			200,
			197,
			1
		},
		["Concrete/CityStreetSidewalk"] = {
			153,
			149,
			149,
			1
		},
		["Concrete/Cobblestone(wookey)"] = {
			154,
			148,
			141,
			1
		},
		["Concrete/Cobblestone2(wookey)"] = {
			156,
			154,
			152,
			1
		},
		["Concrete/Cobblestone3(wookey)"] = {
			126,
			123,
			120,
			1
		},
		["Concrete/CobblestonePavers_9680"] = {
			125,
			124,
			119,
			1
		},
		["Concrete/CobblestoneWall"] = {
			177,
			176,
			164,
			1
		},
		["Concrete/CompositePanelFacade_12924"] = {
			225,
			225,
			224,
			1
		},
		["Concrete/Concrete11"] = {
			171,
			171,
			172,
			1
		},
		["Concrete/ConcreteBlockStacked"] = {
			114,
			106,
			98,
			1
		},
		["Concrete/ConcreteBlockStacked2"] = {
			189,
			187,
			183,
			1
		},
		["Concrete/ConcreteBlockStacked2big"] = {
			189,
			187,
			183,
			1
		},
		["Concrete/ConcreteBlockWall"] = {
			125,
			133,
			118,
			1
		},
		["Concrete/ConcreteBlocks"] = {
			184,
			178,
			168,
			1
		},
		["Concrete/ConcreteBlocksFluted001"] = {
			194,
			188,
			174,
			1
		},
		["Concrete/ConcreteBlocksHorizontallyScored001"] = {
			169,
			159,
			150,
			1
		},
		["Concrete/ConcreteCavityTiles"] = {
			113,
			105,
			95,
			1
		},
		["Concrete/ConcreteCeilingWeathered"] = {
			121,
			114,
			105,
			1
		},
		["Concrete/ConcreteCeiling_12554"] = {
			172,
			166,
			153,
			1
		},
		["Concrete/ConcreteCeiling_9502"] = {
			155,
			141,
			126,
			1
		},
		["Concrete/ConcreteCladdingOffsetVertical001"] = {
			151,
			150,
			145,
			1
		},
		["Concrete/ConcreteFloorCracked_10570"] = {
			140,
			129,
			118,
			1
		},
		["Concrete/ConcreteFloorCracks"] = {
			176,
			167,
			160,
			1
		},
		["Concrete/ConcreteFloorPoured"] = {
			136,
			135,
			131,
			1
		},
		["Concrete/ConcreteFloorStained_11667"] = {
			112,
			105,
			96,
			1
		},
		["Concrete/ConcreteFloor_8462"] = {
			128,
			117,
			106,
			1
		},
		["Concrete/ConcreteHexagonTiles"] = {
			178,
			171,
			166,
			1
		},
		["Concrete/ConcretePanelWeathered"] = {
			150,
			146,
			138,
			1
		},
		["Concrete/ConcretePanel_11827"] = {
			191,
			186,
			175,
			1
		},
		["Concrete/ConcretePanels004"] = {
			202,
			210,
			226,
			1
		},
		["Concrete/ConcretePanels3"] = {
			163,
			163,
			163,
			1
		},
		["Concrete/ConcretePanelsSquare001"] = {
			116,
			114,
			110,
			1
		},
		["Concrete/ConcretePanelsVertical"] = {
			212,
			213,
			207,
			1
		},
		["Concrete/ConcretePanelsVertical2"] = {
			164,
			157,
			151,
			1
		},
		["Concrete/ConcretePanelsVertical3"] = {
			212,
			213,
			207,
			1
		},
		["Concrete/ConcretePanelsVerticalbig"] = {
			212,
			213,
			207,
			1
		},
		["Concrete/ConcretePaversGravel_10402"] = {
			83,
			78,
			72,
			1
		},
		["Concrete/ConcretePaversTread_10359"] = {
			133,
			87,
			71,
			1
		},
		["Concrete/ConcretePavers_9651"] = {
			134,
			121,
			109,
			1
		},
		["Concrete/ConcretePlatesStudded001"] = {
			163,
			163,
			163,
			1
		},
		["Concrete/ConcreteRectangleTiles"] = {
			188,
			187,
			186,
			1
		},
		["Concrete/ConcreteSlab_10549"] = {
			204,
			193,
			181,
			1
		},
		["Concrete/ConcreteTiles2"] = {
			120,
			111,
			98,
			1
		},
		["Concrete/ConcreteWall"] = {
			199,
			196,
			194,
			1
		},
		["Concrete/ConcreteWallBoardForm_9522"] = {
			207,
			206,
			203,
			1
		},
		["Concrete/ConcreteWallBrick_10013"] = {
			164,
			162,
			157,
			1
		},
		["Concrete/ConcreteWallDamaged"] = {
			198,
			198,
			198,
			1
		},
		["Concrete/ConcreteWallDamaged_11961"] = {
			161,
			152,
			138,
			1
		},
		["Concrete/ConcreteWallDecorative_9922"] = {
			154,
			147,
			132,
			1
		},
		["Concrete/ConcreteWallGrooved_11106"] = {
			120,
			115,
			105,
			1
		},
		["Concrete/ConcreteWallMaterial"] = {
			129,
			133,
			135,
			1
		},
		["Concrete/ConcreteWallMottled_8760"] = {
			165,
			159,
			148,
			1
		},
		["Concrete/ConcreteWallPaintedPeeling_12242"] = {
			212,
			212,
			212,
			1
		},
		["Concrete/ConcreteWallPainted_11681"] = {
			198,
			191,
			177,
			1
		},
		["Concrete/ConcreteWallPanels_9876"] = {
			186,
			181,
			167,
			1
		},
		["Concrete/ConcreteWallRetaining_10197"] = {
			69,
			62,
			51,
			1
		},
		["Concrete/ConcreteWallRetaining_10391"] = {
			135,
			129,
			119,
			1
		},
		["Concrete/ConcreteWallRetaining_10785"] = {
			85,
			81,
			73,
			1
		},
		["Concrete/ConcreteWallRetaining_10895"] = {
			88,
			78,
			64,
			1
		},
		["Concrete/ConcreteWallRetaining_10897"] = {
			160,
			157,
			151,
			1
		},
		["Concrete/ConcreteWallWeatheredPeeling"] = {
			204,
			199,
			193,
			1
		},
		["Concrete/ConcreteWallWeathered_11310"] = {
			80,
			74,
			67,
			1
		},
		["Concrete/ConcreteWallWeathered_12402"] = {
			149,
			139,
			126,
			1
		},
		["Concrete/ConcreteWallWeathered_12402big"] = {
			149,
			139,
			126,
			1
		},
		["Concrete/ConcreteWall_9800"] = {
			170,
			163,
			151,
			1
		},
		["Concrete/Curbs"] = {
			228,
			223,
			218,
			1
		},
		["Concrete/CurbsLines"] = {
			228,
			223,
			218,
			1
		},
		["Concrete/DustCobblestone"] = {
			190,
			176,
			164,
			1
		},
		["Concrete/Fine Particles Concrete"] = {
			197,
			198,
			199,
			1
		},
		["Concrete/Fine Particles Concreteflat"] = {
			197,
			198,
			199,
			1
		},
		["Concrete/FormedConcrete1"] = {
			166,
			167,
			166,
			1
		},
		["Concrete/Gabion"] = {
			106,
			103,
			96,
			1
		},
		["Concrete/GreekCobbleStone"] = {
			161,
			164,
			169,
			1
		},
		["Concrete/GreenCeiling"] = {
			154,
			155,
			146,
			1
		},
		["Concrete/IrregularStoneWall"] = {
			184,
			174,
			156,
			1
		},
		["Concrete/LimestoneBricks"] = {
			160,
			155,
			146,
			1
		},
		["Concrete/LimestoneBrickssmaller"] = {
			160,
			155,
			146,
			1
		},
		["Concrete/MixedRocks"] = {
			120,
			109,
			94,
			1
		},
		["Concrete/NukeCurbs"] = {
			178,
			178,
			178,
			1
		},
		["Concrete/NukeInteriorConcrete"] = {
			234,
			232,
			229,
			1
		},
		["Concrete/OldConcreteTiles1"] = {
			118,
			108,
			92,
			1
		},
		["Concrete/OldPatternedConcreteTiles"] = {
			127,
			111,
			93,
			1
		},
		["Concrete/OldPlainConcreteTiles"] = {
			194,
			173,
			146,
			1
		},
		["Concrete/Patterned-Glass-Blocks"] = {
			249,
			249,
			249,
			1
		},
		["Concrete/PatternedConcrete10"] = {
			167,
			168,
			163,
			1
		},
		["Concrete/PatternedConcrete11"] = {
			185,
			186,
			185,
			1
		},
		["Concrete/PatternedConcrete2"] = {
			202,
			204,
			205,
			1
		},
		["Concrete/PatternedConcrete3"] = {
			102,
			100,
			90,
			1
		},
		["Concrete/PatternedConcrete4"] = {
			160,
			147,
			132,
			1
		},
		["Concrete/PatternedConcrete5"] = {
			119,
			88,
			69,
			1
		},
		["Concrete/PatternedConcrete6"] = {
			146,
			141,
			131,
			1
		},
		["Concrete/PatternedConcrete8"] = {
			173,
			153,
			133,
			1
		},
		["Concrete/PatternedConcrete9"] = {
			105,
			94,
			80,
			1
		},
		["Concrete/PatternedConcreteTiles"] = {
			179,
			168,
			158,
			1
		},
		["Concrete/PlainConcreteTiles"] = {
			124,
			122,
			110,
			1
		},
		["Concrete/PlainConcreteTiles2"] = {
			113,
			94,
			75,
			1
		},
		["Concrete/PlainConcreteTiles3"] = {
			207,
			199,
			188,
			1
		},
		["Concrete/PlasterVenetian"] = {
			127,
			125,
			119,
			1
		},
		["Concrete/PlasteredStoneWall"] = {
			161,
			164,
			165,
			1
		},
		["Concrete/Poliigon_ConcreteFloorWorn_12254"] = {
			140,
			132,
			126,
			1
		},
		["Concrete/Poliigon_ConcretePavers_9191"] = {
			102,
			92,
			83,
			1
		},
		["Concrete/Poliigon_RailBallasted_12998"] = {
			110,
			101,
			91,
			1
		},
		["Concrete/Poliigon_StonePaversAggregate_10334"] = {
			156,
			135,
			119,
			1
		},
		["Concrete/Poliigon_StonePaversCobblestone_10233"] = {
			130,
			122,
			114,
			1
		},
		["Concrete/PoolConcreteWall"] = {
			234,
			233,
			232,
			1
		},
		["Concrete/RedConcretePavement"] = {
			203,
			148,
			125,
			1
		},
		["Concrete/RoofConcrete"] = {
			110,
			109,
			103,
			1
		},
		["Concrete/RoughConcreteSurface"] = {
			176,
			179,
			172,
			1
		},
		["Concrete/RoughConcreteSurface2"] = {
			176,
			179,
			172,
			1
		},
		["Concrete/RoughTile"] = {
			165,
			159,
			155,
			1
		},
		["Concrete/RoughTile2"] = {
			188,
			188,
			188,
			1
		},
		["Concrete/RubbleMortarWall"] = {
			183,
			175,
			158,
			1
		},
		["Concrete/SandyConcrete"] = {
			203,
			198,
			194,
			1
		},
		["Concrete/SidewalkTiles"] = {
			185,
			179,
			175,
			1
		},
		["Concrete/SidewalkTiles2"] = {
			124,
			116,
			103,
			1
		},
		["Concrete/SlimBricks"] = {
			227,
			227,
			227,
			1
		},
		["Concrete/SnowyStoneWall"] = {
			120,
			127,
			128,
			1
		},
		["Concrete/StoneBricks"] = {
			148,
			143,
			140,
			1
		},
		["Concrete/StoneFacadeAggregate_9810"] = {
			189,
			180,
			171,
			1
		},
		["Concrete/StoneFacadePebbledash_11690"] = {
			144,
			144,
			130,
			1
		},
		["Concrete/StoneFacadePebbledash_12071"] = {
			188,
			174,
			159,
			1
		},
		["Concrete/StoneGraniteFacade_11525"] = {
			175,
			161,
			144,
			1
		},
		["Concrete/StonePanelsFacade_11570"] = {
			174,
			167,
			161,
			1
		},
		["Concrete/StonePaversAggregate_11684"] = {
			91,
			83,
			70,
			1
		},
		["Concrete/StonePaversBrushed_10234"] = {
			152,
			136,
			120,
			1
		},
		["Concrete/StonePaversDamp_11292"] = {
			94,
			95,
			93,
			1
		},
		["Concrete/StonePaversDecorative_9558"] = {
			138,
			126,
			116,
			1
		},
		["Concrete/StonePaversWorn_9532"] = {
			122,
			99,
			92,
			1
		},
		["Concrete/StonePavers_11313"] = {
			117,
			116,
			110,
			1
		},
		["Concrete/StoneSandstoneFacade"] = {
			163,
			155,
			138,
			1
		},
		["Concrete/StoneTileDecorative_11397"] = {
			112,
			111,
			107,
			1
		},
		["Concrete/StoneTileEroded_10794"] = {
			117,
			108,
			97,
			1
		},
		["Concrete/StoneTileExterior_9143"] = {
			121,
			109,
			100,
			1
		},
		["Concrete/StoneTileExterior_9176"] = {
			156,
			138,
			113,
			1
		},
		["Concrete/StoneTileFloor_11178"] = {
			69,
			61,
			54,
			1
		},
		["Concrete/StoneTileGranite_11566"] = {
			125,
			121,
			116,
			1
		},
		["Concrete/StoneTileGranite_11566smaller"] = {
			125,
			121,
			116,
			1
		},
		["Concrete/StoneTileSlate_11335"] = {
			145,
			137,
			126,
			1
		},
		["Concrete/StoneTile_11557"] = {
			133,
			131,
			121,
			1
		},
		["Concrete/StoneTilesPavement"] = {
			199,
			199,
			199,
			1
		},
		["Concrete/StoneTilesPavement2"] = {
			123,
			124,
			128,
			1
		},
		["Concrete/StoneWallHeavyMortar"] = {
			108,
			103,
			95,
			1
		},
		["Concrete/StoneWallRetaining"] = {
			87,
			82,
			74,
			1
		},
		["Concrete/StoneWallRustic"] = {
			155,
			141,
			124,
			1
		},
		["Concrete/StoneWallSandstone"] = {
			160,
			137,
			110,
			1
		},
		["Concrete/StoneWallSlate"] = {
			164,
			160,
			149,
			1
		},
		["Concrete/StripedConcrete"] = {
			170,
			170,
			170,
			1
		},
		["Concrete/StuccoPlaster"] = {
			219,
			219,
			219,
			1
		},
		["Concrete/StuccoPlaster2"] = {
			220,
			220,
			220,
			1
		},
		["Concrete/StuccoPlaster3"] = {
			221,
			219,
			217,
			1
		},
		["Concrete/StuccoPlaster4"] = {
			215,
			213,
			210,
			1
		},
		["Concrete/TerracottaTileFacade_11513"] = {
			131,
			105,
			86,
			1
		},
		["Concrete/Tile3"] = {
			188,
			188,
			188,
			1
		},
		["Concrete/TilesMarbleGrigioCollemandinaHoned001"] = {
			77,
			80,
			79,
			1
		},
		["Concrete/TilesTerracottaGrayHexagon001"] = {
			149,
			146,
			142,
			1
		},
		["Concrete/Trim Concrete big"] = {
			215,
			207,
			198,
			1
		},
		["Concrete/Trim Concrete"] = {
			215,
			207,
			198,
			1
		},
		["Concrete/TrimConcreteNuke"] = {
			186,
			186,
			186,
			1
		},
		["Concrete/WhiteBuildingWorn"] = {
			220,
			219,
			217,
			1
		},
		["Concrete/WhiteBuildingcleaner"] = {
			215,
			215,
			214,
			1
		},
		["Concrete/WornConcrete2"] = {
			188,
			185,
			182,
			1
		},
		["Concrete/WornConcrete3"] = {
			161,
			151,
			134,
			1
		},
		["Concrete/WornConcrete3Bigger"] = {
			176,
			176,
			176,
			1
		},
		["Concrete/WornConcrete4"] = {
			178,
			178,
			178,
			1
		},
		["Concrete/WornRoofShingles"] = {
			202,
			159,
			130,
			1
		},
		["Concrete/WornSidewalk"] = {
			134,
			128,
			121,
			1
		},
		["Concrete/YellowBricks2"] = {
			162,
			157,
			149,
			1
		},
		["Concrete/YellowBricks3"] = {
			202,
			193,
			179,
			1
		},
		["Concrete/Yellowpaintedbricks"] = {
			229,
			225,
			219,
			1
		},
		["Concrete/Yellowpaintedbricks2"] = {
			222,
			210,
			187,
			1
		},
		["Concrete/concreteBlockout"] = {
			78,
			78,
			78,
			1
		},
		["Concrete/concretebrickwall"] = {
			195,
			195,
			195,
			1
		},
		["Concrete/concretetilespavement"] = {
			184,
			178,
			168,
			1
		},
		["Concrete/curb2"] = {
			140,
			129,
			118,
			1
		},
		["Concrete/darkConcretePavement"] = {
			197,
			171,
			147,
			1
		},
		["Concrete/formedconcretewall"] = {
			229,
			229,
			229,
			1
		},
		["Concrete/graycobblestone"] = {
			191,
			190,
			189,
			1
		},
		["CorrodedMetal/A23D_Old-Patterned-Metal_Substance 3D_PNG_1K"] = {
			76,
			80,
			89,
			1
		},
		["CorrodedMetal/A23D_Patterned-Metal-Surface_Substance 3D_PNG_1K"] = {
			186,
			127,
			92,
			1
		},
		["CorrodedMetal/A23D_Patterned-Metal_Substance 3D_PNG_1K"] = {
			159,
			141,
			122,
			1
		},
		["CorrodedMetal/Beaten Up Metal"] = {
			108,
			105,
			102,
			1
		},
		["CorrodedMetal/MetalCladdingPanels"] = {
			183,
			182,
			181,
			1
		},
		["CorrodedMetal/MetalCorrugatedRusted"] = {
			116,
			112,
			111,
			1
		},
		["CorrodedMetal/MetalCorrugation2"] = {
			191,
			197,
			197,
			1
		},
		["CorrodedMetal/MetalFencingDecorative_12667"] = {
			151,
			160,
			164,
			1
		},
		["CorrodedMetal/MetalPanelsPainted"] = {
			89,
			90,
			85,
			1
		},
		["CorrodedMetal/MetalPanelsRusted"] = {
			67,
			56,
			46,
			1
		},
		["CorrodedMetal/MetalSteelRibbedWorn"] = {
			128,
			110,
			100,
			1
		},
		["CorrodedMetal/MetalSteelRibbedWornsmaller"] = {
			128,
			110,
			100,
			1
		},
		["CorrodedMetal/NewSkyscraperVertigo"] = {
			136,
			136,
			136,
			1
		},
		["CorrodedMetal/RoofSheetMetal"] = {
			180,
			170,
			163,
			1
		},
		["CorrodedMetal/RustedMetal007"] = {
			134,
			147,
			148,
			1
		},
		["CorrodedMetal/SheetMetal"] = {
			204,
			204,
			204,
			1
		},
		["CorrodedMetal/SheetMetalPanels"] = {
			232,
			232,
			232,
			1
		},
		["CorrodedMetal/SheetMetalsmaller"] = {
			204,
			204,
			204,
			1
		},
		["DiamondPlate/DiamondPlate"] = {
			237,
			237,
			237,
			1
		},
		["Fabric/Carpet1"] = {
			136,
			132,
			119,
			1
		},
		["Fabric/Carpet2"] = {
			164,
			142,
			122,
			1
		},
		["Fabric/CarpetCommercialVariedPinstripes001"] = {
			79,
			80,
			80,
			1
		},
		["Fabric/Fabric 1"] = {
			169,
			158,
			145,
			1
		},
		["Foil/Window"] = {
			79,
			89,
			100,
			1
		},
		["Foil/Window2"] = {
			83,
			91,
			99,
			1
		},
		["Foil/Y2K glass_block_window"] = {
			142,
			156,
			151,
			1
		},
		["Granite/CounterGranite"] = {
			159,
			158,
			158,
			1
		},
		["Granite/CounterGranite2"] = {
			203,
			215,
			217,
			1
		},
		["Granite/CounterGranite3"] = {
			159,
			158,
			158,
			1
		},
		["Granite/GraniteTiles"] = {
			202,
			206,
			205,
			1
		},
		["Grass/SeasideGrass"] = {
			130,
			164,
			74,
			1
		},
		["Grass/snowygrass"] = {
			192,
			195,
			203,
			1
		},
		["Ground/Dirt"] = {
			153,
			144,
			136,
			1
		},
		["Ground/Dirt2"] = {
			144,
			137,
			131,
			1
		},
		["Ground/GroundAsphaltCracked_9960"] = {
			93,
			88,
			82,
			1
		},
		["Ground/GroundAsphaltEroded_11018"] = {
			147,
			140,
			127,
			1
		},
		["Ground/RocksGrass"] = {
			145,
			136,
			124,
			1
		},
		["Ground/dirtground2"] = {
			195,
			168,
			136,
			1
		},
		["Marble/Marble"] = {
			170,
			170,
			169,
			1
		},
		["Metal/A23D_Stained-Glass_Substance 3D_PNG_1K"] = {
			213,
			213,
			213,
			1
		},
		["Metal/BluePaintedMetal"] = {
			83,
			139,
			168,
			1
		},
		["Metal/Brushed Metal"] = {
			137,
			137,
			137,
			1
		},
		["Metal/Brushed MetalNoRough"] = {
			137,
			137,
			137,
			1
		},
		["Metal/CacheWindow"] = {
			255,
			255,
			255,
			1
		},
		["Metal/CarbonSteelWorn001"] = {
			66,
			64,
			62,
			1
		},
		["Metal/Ceiling Tiles"] = {
			242,
			242,
			242,
			1
		},
		["Metal/CraneMetal"] = {
			194,
			164,
			96,
			1
		},
		["Metal/CrateMetal"] = {
			239,
			240,
			240,
			1
		},
		["Metal/DiamondPlate2"] = {
			92,
			77,
			70,
			1
		},
		["Metal/DoorAtlas_12552"] = {
			139,
			78,
			67,
			1
		},
		["Metal/GarageDoor"] = {
			225,
			225,
			225,
			1
		},
		["Metal/GrateMetal001"] = {
			157,
			157,
			157,
			0.38
		},
		["Metal/GreenPaintedMetal"] = {
			118,
			135,
			115,
			1
		},
		["Metal/GreenPanels"] = {
			110,
			124,
			106,
			1
		},
		["Metal/MetalBeams"] = {
			54,
			43,
			31,
			1
		},
		["Metal/MetalCastPatina001"] = {
			82,
			77,
			73,
			1
		},
		["Metal/MetalCladding"] = {
			68,
			70,
			70,
			1
		},
		["Metal/MetalCladdingPanels003"] = {
			183,
			182,
			181,
			1
		},
		["Metal/MetalCladdingPanels2"] = {
			85,
			83,
			78,
			1
		},
		["Metal/MetalCopperFacade_11593"] = {
			97,
			106,
			106,
			1
		},
		["Metal/MetalCopperFacade_11593big"] = {
			97,
			106,
			106,
			1
		},
		["Metal/MetalCorrugatedDented_10218"] = {
			94,
			107,
			94,
			1
		},
		["Metal/MetalCorrugated_10551"] = {
			99,
			94,
			84,
			1
		},
		["Metal/MetalGalvanizedZinc_7184"] = {
			184,
			189,
			187,
			1
		},
		["Metal/MetalGatePaintedRusty_9957"] = {
			130,
			124,
			116,
			1
		},
		["Metal/MetalPainted"] = {
			253,
			253,
			253,
			1
		},
		["Metal/MetalPaintedMatte_9774"] = {
			91,
			96,
			102,
			1
		},
		["Metal/MetalPanelCeiling"] = {
			136,
			136,
			136,
			1
		},
		["Metal/MetalPanelRectangular"] = {
			126,
			126,
			128,
			1
		},
		["Metal/MetalPerforatedRound002"] = {
			166,
			166,
			166,
			1
		},
		["Metal/MetalPerforatedSlots002"] = {
			208,
			205,
			201,
			1
		},
		["Metal/MetalPlateDiamondWorn002"] = {
			143,
			141,
			140,
			1
		},
		["Metal/MetalPlateStudded001"] = {
			143,
			143,
			142,
			1
		},
		["Metal/MetalPlateStuddedWorn001"] = {
			139,
			136,
			135,
			1
		},
		["Metal/MetalRoofTiles"] = {
			188,
			188,
			188,
			1
		},
		["Metal/MetalRoofTiles2"] = {
			119,
			122,
			125,
			1
		},
		["Metal/MetalSignRusted_11110"] = {
			169,
			164,
			154,
			1
		},
		["Metal/MetalSteelDistressed_12605"] = {
			81,
			82,
			79,
			1
		},
		["Metal/MetalSteelPanel"] = {
			242,
			244,
			240,
			1
		},
		["Metal/MetalSurface1"] = {
			167,
			158,
			144,
			1
		},
		["Metal/MetalTrimSeams"] = {
			211,
			212,
			207,
			1
		},
		["Metal/MetalTrimSeamsBig"] = {
			211,
			212,
			207,
			1
		},
		["Metal/MetalTrimSeamsTiny"] = {
			211,
			212,
			207,
			1
		},
		["Metal/MetalWallPainted"] = {
			176,
			164,
			151,
			1
		},
		["Metal/MetalWallPaintedPeeling"] = {
			204,
			196,
			188,
			1
		},
		["Metal/MetalWallStreaks_8863"] = {
			127,
			145,
			160,
			1
		},
		["Metal/NewSkyscraperDizzy"] = {
			136,
			136,
			136,
			1
		},
		["Metal/OldBrokeWindow"] = {
			55,
			54,
			50,
			0.66
		},
		["Metal/OldWindow"] = {
			55,
			54,
			50,
			0.66
		},
		["Metal/PanelsAcousticMetalMeshGrid001"] = {
			100,
			98,
			93,
			1
		},
		["Metal/PanelsAcousticPerforatedMetal001"] = {
			191,
			184,
			174,
			1
		},
		["Metal/PatchyPatternedMetal"] = {
			129,
			127,
			130,
			1
		},
		["Metal/PatchySurface"] = {
			115,
			136,
			141,
			1
		},
		["Metal/Patterned-Metal_Substance 3D_PNG_1K"] = {
			207,
			207,
			207,
			1
		},
		["Metal/PatternedMetalPanel"] = {
			89,
			85,
			79,
			1
		},
		["Metal/Perforated-Metal-Panel_Substance 3D_PNG_1K"] = {
			41,
			42,
			44,
			1
		},
		["Metal/PoolOutline"] = {
			246,
			247,
			246,
			1
		},
		["Metal/PoolWall"] = {
			186,
			215,
			239,
			1
		},
		["Metal/RedPaintedMetal"] = {
			161,
			102,
			90,
			1
		},
		["Metal/RoofMetalCorrugated_11968"] = {
			236,
			237,
			238,
			1
		},
		["Metal/RoofTilesZinc002"] = {
			119,
			122,
			125,
			1
		},
		["Metal/RoofTilesZinc002big"] = {
			119,
			122,
			125,
			1
		},
		["Metal/RoughMetal"] = {
			211,
			212,
			208,
			1
		},
		["Metal/Scratched-Metal-Surface_Substance 3D_PNG_1K"] = {
			115,
			115,
			110,
			1
		},
		["Metal/SheetMetal4"] = {
			214,
			214,
			214,
			1
		},
		["Metal/SheetMetalNuke"] = {
			239,
			239,
			239,
			1
		},
		["Metal/SheetMetalNukeMetallic"] = {
			239,
			239,
			239,
			1
		},
		["Metal/SheetMetalNukeNoDetails"] = {
			239,
			239,
			239,
			1
		},
		["Metal/SheetMetalNukeSmaller"] = {
			207,
			207,
			207,
			1
		},
		["Metal/SkyScraperWindows"] = {
			129,
			132,
			142,
			1
		},
		["Metal/SteelCable"] = {
			216,
			216,
			216,
			1
		},
		["Metal/Vents"] = {
			116,
			115,
			118,
			1
		},
		["Metal/Vertically Lined Metal"] = {
			85,
			81,
			80,
			1
		},
		["Metal/WhitePaintedMetal"] = {
			184,
			180,
			177,
			1
		},
		["Metal/Y2K metal"] = {
			167,
			165,
			166,
			1
		},
		["Mud/GroundGrassSparse_9815"] = {
			175,
			155,
			110,
			1
		},
		["Mud/WetConcrete"] = {
			137,
			139,
			142,
			1
		},
		["Pebble/Ceiling"] = {
			211,
			208,
			201,
			1
		},
		["Pebble/OfficeCeiling"] = {
			244,
			244,
			244,
			1
		},
		["Plaster/Drywall"] = {
			218,
			217,
			218,
			1
		},
		["Plaster/Drywall2"] = {
			224,
			223,
			224,
			1
		},
		["Plaster/PlasterWallDamaged_11960"] = {
			210,
			211,
			212,
			1
		},
		["Plastic/AluminumInsulation"] = {
			137,
			136,
			137,
			1
		},
		["Plastic/Ceiling"] = {
			244,
			244,
			244,
			1
		},
		["Plastic/Celestial Wall Trim"] = {
			96,
			98,
			100,
			1
		},
		["Plastic/CityStreetPavementTactileLines002"] = {
			164,
			164,
			159,
			1
		},
		["Plastic/Concrete Tiles "] = {
			114,
			111,
			107,
			1
		},
		["Plastic/Concrete1"] = {
			191,
			187,
			178,
			1
		},
		["Plastic/ConcreteCladding"] = {
			218,
			218,
			218,
			1
		},
		["Plastic/ConcreteWall"] = {
			208,
			207,
			205,
			1
		},
		["Plastic/IndoorWall"] = {
			225,
			225,
			225,
			1
		},
		["Plastic/IndoorWallGrunged"] = {
			220,
			220,
			220,
			1
		},
		["Plastic/Lobby\'s Ceiling"] = {
			175,
			175,
			175,
			1
		},
		["Plastic/Office Ceiling Tiles"] = {
			242,
			242,
			242,
			1
		},
		["Plastic/OfficeCeilingRough"] = {
			239,
			239,
			239,
			1
		},
		["Plastic/PaintedWall"] = {
			157,
			157,
			147,
			1
		},
		["Plastic/PatternedConcrete7"] = {
			192,
			195,
			173,
			1
		},
		["Plastic/PlatedMetal"] = {
			124,
			122,
			121,
			1
		},
		["Plastic/SheetMetal3"] = {
			239,
			239,
			239,
			1
		},
		["Plastic/SheetMetal5"] = {
			239,
			239,
			239,
			1
		},
		["Plastic/Skin"] = {
			236,
			197,
			158,
			1
		},
		["Plastic/VinylTileBackroom_13287"] = {
			210,
			210,
			210,
			1
		},
		["Plastic/Wall Plaster"] = {
			176,
			176,
			175,
			1
		},
		["Plastic/WallPaper1"] = {
			181,
			181,
			181,
			1
		},
		["Plastic/WindowTrim"] = {
			239,
			239,
			239,
			1
		},
		["Plastic/Wires"] = {
			221,
			220,
			218,
			1
		},
		["Plastic/WoodDoor"] = {
			208,
			153,
			103,
			1
		},
		["Rock/Coarse-Rocky-Soil_Substance 3D_PNG_1K"] = {
			78,
			78,
			78,
			1
		},
		["Slate/Slate"] = {
			96,
			102,
			96,
			1
		},
		["SmoothPlastic/Blockout"] = {
			200,
			200,
			200,
			1
		},
		["SmoothPlastic/Grid"] = {
			200,
			200,
			200,
			1
		},
		["Snow/Snow 2022"] = {
			237,
			238,
			239,
			1
		},
		["Snow/SnowSmall"] = {
			203,
			203,
			205,
			1
		},
		["Wood/Construction_Particle_Board"] = {
			219,
			219,
			219,
			1
		},
		["Wood/Construction_Structural_Plywood"] = {
			226,
			226,
			226,
			1
		},
		["Wood/Knotty Plywood"] = {
			206,
			187,
			161,
			1
		},
		["Wood/Matte_Wood"] = {
			237,
			237,
			237,
			1
		},
		["Wood/Poliigon_VinylSquareTile_10632"] = {
			147,
			115,
			90,
			1
		},
		["Wood/Poliigon_WoodFacadeModern_9032"] = {
			139,
			106,
			82,
			1
		},
		["Wood/Poliigon_WoodWallTile_12816"] = {
			88,
			41,
			22,
			1
		},
		["Wood/Poliigon_WoodWallTile_12818"] = {
			96,
			47,
			28,
			1
		},
		["Wood/RawWood"] = {
			162,
			128,
			96,
			1
		},
		["Wood/Varnished_Wood"] = {
			235,
			235,
			235,
			1
		},
		["Wood/WoodBark"] = {
			144,
			134,
			128,
			1
		},
		["Wood/WoodBoard"] = {
			204,
			178,
			151,
			1
		},
		["Wood/WoodDust2"] = {
			159,
			155,
			152,
			1
		},
		["Wood/WoodDust2lighter"] = {
			205,
			201,
			198,
			1
		},
		["Wood/WoodFrames"] = {
			163,
			157,
			151,
			1
		},
		["Wood/WoodTwig"] = {
			147,
			139,
			134,
			1
		},
		["Wood/Worn_Wood"] = {
			238,
			238,
			238,
			1
		},
		["Wood/woodBlockout"] = {
			107,
			107,
			107,
			1
		},
		["WoodPlanks/BluePaintedWood"] = {
			129,
			154,
			141,
			1
		},
		["WoodPlanks/CleanWood"] = {
			176,
			176,
			176,
			1
		},
		["WoodPlanks/FloorWood"] = {
			168,
			156,
			153,
			1
		},
		["WoodPlanks/Matte_Wood_Brick"] = {
			235,
			235,
			235,
			1
		},
		["WoodPlanks/Matte_Wood_Brick_Double"] = {
			235,
			235,
			235,
			1
		},
		["WoodPlanks/Matte_Wood_Checkerboard"] = {
			235,
			235,
			235,
			1
		},
		["WoodPlanks/Matte_Wood_Checkerboard_Double"] = {
			235,
			235,
			235,
			1
		},
		["WoodPlanks/Matte_Wood_Checkerboard_Triple"] = {
			234,
			234,
			234,
			1
		},
		["WoodPlanks/Matte_Wood_Chevron"] = {
			233,
			233,
			233,
			1
		},
		["WoodPlanks/Matte_Wood_Endless"] = {
			235,
			235,
			235,
			1
		},
		["WoodPlanks/Matte_Wood_Herringbone"] = {
			235,
			235,
			235,
			1
		},
		["WoodPlanks/Matte_Wood_Herringbone_Double"] = {
			235,
			235,
			235,
			1
		},
		["WoodPlanks/Matte_Wood_Herringbone_Half"] = {
			235,
			235,
			235,
			1
		},
		["WoodPlanks/OldWoodBeams"] = {
			154,
			140,
			126,
			1
		},
		["WoodPlanks/PaintedPlanks"] = {
			204,
			203,
			203,
			1
		},
		["WoodPlanks/PaintedPlanks2"] = {
			225,
			225,
			223,
			1
		},
		["WoodPlanks/RoughWood(wookey)"] = {
			193,
			183,
			172,
			1
		},
		["WoodPlanks/RoughWoodPlanks"] = {
			143,
			138,
			134,
			1
		},
		["WoodPlanks/Varnished_Wood_Brick"] = {
			233,
			233,
			233,
			1
		},
		["WoodPlanks/Varnished_Wood_Brick_Double"] = {
			233,
			233,
			233,
			1
		},
		["WoodPlanks/Varnished_Wood_Checkerboard"] = {
			233,
			233,
			233,
			1
		},
		["WoodPlanks/Varnished_Wood_Checkerboard_Double"] = {
			233,
			233,
			233,
			1
		},
		["WoodPlanks/Varnished_Wood_Checkerboard_Triple"] = {
			232,
			232,
			232,
			1
		},
		["WoodPlanks/Varnished_Wood_Chevron"] = {
			232,
			232,
			232,
			1
		},
		["WoodPlanks/Varnished_Wood_Endless"] = {
			233,
			233,
			233,
			1
		},
		["WoodPlanks/Varnished_Wood_Herringbone"] = {
			233,
			233,
			233,
			1
		},
		["WoodPlanks/Varnished_Wood_Herringbone_Double"] = {
			233,
			233,
			233,
			1
		},
		["WoodPlanks/Varnished_Wood_Herringbone_Half"] = {
			233,
			233,
			233,
			1
		},
		["WoodPlanks/WhiteDirtyWood"] = {
			181,
			176,
			169,
			1
		},
		["WoodPlanks/Wood(wookey)"] = {
			150,
			150,
			150,
			1
		},
		["WoodPlanks/Wood2(wookey)"] = {
			144,
			141,
			142,
			1
		},
		["WoodPlanks/WoodCarving"] = {
			182,
			180,
			181,
			1
		},
		["WoodPlanks/WoodDeck"] = {
			138,
			131,
			114,
			1
		},
		["WoodPlanks/WoodPlanks(wookey)"] = {
			195,
			193,
			190,
			1
		},
		["WoodPlanks/WoodPlanks2"] = {
			138,
			133,
			129,
			1
		},
		["WoodPlanks/WoodPlanks2smaller"] = {
			138,
			133,
			129,
			1
		},
		["WoodPlanks/WoodPlanks3"] = {
			135,
			120,
			110,
			1
		},
		["WoodPlanks/WoodPlanks4"] = {
			138,
			133,
			129,
			1
		},
		["WoodPlanks/Worn Painted Wood Siding"] = {
			152,
			155,
			153,
			1
		},
		["WoodPlanks/Worn_Wood_Brick"] = {
			237,
			237,
			237,
			1
		},
		["WoodPlanks/Worn_Wood_Brick_Double"] = {
			237,
			237,
			237,
			1
		},
		["WoodPlanks/Worn_Wood_Checkerboard"] = {
			237,
			237,
			237,
			1
		},
		["WoodPlanks/Worn_Wood_Checkerboard_Double"] = {
			236,
			236,
			236,
			1
		},
		["WoodPlanks/Worn_Wood_Checkerboard_Triple"] = {
			236,
			236,
			236,
			1
		},
		["WoodPlanks/Worn_Wood_Chevron"] = {
			235,
			235,
			235,
			1
		},
		["WoodPlanks/Worn_Wood_Endless"] = {
			237,
			237,
			237,
			1
		},
		["WoodPlanks/Worn_Wood_Herringbone"] = {
			237,
			237,
			237,
			1
		},
		["WoodPlanks/Worn_Wood_Herringbone_Double"] = {
			237,
			237,
			237,
			1
		},
		["WoodPlanks/Worn_Wood_Herringbone_Half"] = {
			236,
			236,
			236,
			1
		}
	},
	["SurfaceAppearances"] = {
		[2961720999] = {
			70,
			84,
			35,
			0.27
		},
		[5727367977] = {
			71,
			72,
			72,
			0.79
		},
		[9648923770] = {
			119,
			85,
			92,
			0.35
		},
		[10004787517] = {
			123,
			97,
			80,
			0.54
		},
		[10068594392] = {
			174,
			172,
			145,
			0.25
		},
		[10068594400] = {
			97,
			101,
			100,
			0.37
		},
		[10076282754] = {
			158,
			108,
			43,
			0.77
		},
		[10228815868] = {
			82,
			88,
			35,
			1
		},
		[10228939391] = {
			94,
			84,
			75,
			1
		},
		[11504219291] = {
			119,
			85,
			92,
			0.35
		},
		[11504991258] = {
			96,
			107,
			46,
			0.33
		},
		[11672745409] = {
			125,
			111,
			97,
			1
		},
		[11672746538] = {
			99,
			116,
			58,
			0.41
		},
		[11873713722] = {
			74,
			72,
			70,
			1
		},
		[13088571617] = {
			42,
			43,
			43,
			1
		},
		[13088571989] = {
			33,
			33,
			32,
			1
		},
		[13088572234] = {
			83,
			85,
			92,
			1
		},
		[13088572392] = {
			56,
			58,
			64,
			1
		},
		[13088572569] = {
			56,
			58,
			64,
			1
		},
		[13088572739] = {
			56,
			58,
			64,
			1
		},
		[13088572887] = {
			56,
			58,
			64,
			1
		},
		[13088573050] = {
			128,
			129,
			132,
			1
		},
		[13088573294] = {
			161,
			96,
			62,
			1
		},
		[13088573590] = {
			63,
			65,
			69,
			1
		},
		[13088574513] = {
			42,
			41,
			43,
			1
		},
		[18749138061] = {
			103,
			91,
			75,
			1
		},
		[70430965056966] = {
			166,
			164,
			164,
			1
		},
		[71521089236744] = {
			61,
			79,
			121,
			1
		},
		[72010842831251] = {
			135,
			106,
			95,
			1
		},
		[72567111073357] = {
			175,
			175,
			175,
			0.36
		},
		[72816958806917] = {
			188,
			188,
			188,
			0.98
		},
		[73873258400970] = {
			155,
			161,
			166,
			1
		},
		[73896577546322] = {
			84,
			78,
			69,
			1
		},
		[74852057789879] = {
			189,
			161,
			150,
			0.29
		},
		[74904912185777] = {
			148,
			143,
			142,
			0.99
		},
		[74912441548789] = {
			79,
			79,
			79,
			0.87
		},
		[75076420020359] = {
			136,
			110,
			96,
			1
		},
		[75147449402255] = {
			155,
			128,
			117,
			0.97
		},
		[75189235937818] = {
			150,
			142,
			130,
			0.14
		},
		[75607094125548] = {
			160,
			143,
			102,
			0.18
		},
		[75607335056249] = {
			175,
			175,
			175,
			0.36
		},
		[76345194831354] = {
			168,
			130,
			87,
			0.65
		},
		[76621646481860] = {
			109,
			95,
			84,
			1
		},
		[77091774962768] = {
			148,
			118,
			83,
			1
		},
		[77347074950498] = {
			100,
			80,
			74,
			1
		},
		[77487438569735] = {
			104,
			108,
			85,
			1
		},
		[78475736657622] = {
			146,
			143,
			141,
			1
		},
		[78868844267759] = {
			149,
			115,
			80,
			0.44
		},
		[78938828222990] = {
			129,
			126,
			127,
			1
		},
		[78944485378802] = {
			113,
			101,
			93,
			1
		},
		[79928386669913] = {
			135,
			134,
			98,
			0.14
		},
		[80037638434175] = {
			131,
			128,
			122,
			1
		},
		[80284487597929] = {
			148,
			118,
			83,
			1
		},
		[81093827536174] = {
			107,
			109,
			100,
			1
		},
		[82510958162457] = {
			158,
			157,
			149,
			1
		},
		[82553167094940] = {
			101,
			95,
			87,
			1
		},
		[82730645059367] = {
			196,
			194,
			194,
			1
		},
		[82758732833245] = {
			103,
			104,
			109,
			1
		},
		[82938820215826] = {
			165,
			139,
			98,
			0.08
		},
		[83413913134979] = {
			78,
			87,
			121,
			1
		},
		[83656812069764] = {
			123,
			101,
			77,
			1
		},
		[83661434310741] = {
			68,
			83,
			107,
			1
		},
		[84130662909177] = {
			156,
			156,
			152,
			1
		},
		[84501946685007] = {
			114,
			115,
			113,
			1
		},
		[84506041710734] = {
			73,
			85,
			124,
			1
		},
		[84821396244654] = {
			147,
			141,
			134,
			1
		},
		[84929953270341] = {
			196,
			194,
			194,
			1
		},
		[84956519950267] = {
			255,
			255,
			255,
			0.13
		},
		[85241505982502] = {
			119,
			120,
			118,
			1
		},
		[86099320016938] = {
			255,
			255,
			255,
			0.13
		},
		[86238154253893] = {
			183,
			141,
			102,
			1
		},
		[86272544359289] = {
			147,
			138,
			111,
			0.18
		},
		[86782936630501] = {
			185,
			185,
			185,
			1
		},
		[87064690360385] = {
			172,
			174,
			174,
			1
		},
		[88975715528510] = {
			179,
			178,
			182,
			1
		},
		[89314364125399] = {
			161,
			138,
			135,
			1
		},
		[89413886733161] = {
			135,
			125,
			116,
			1
		},
		[89539845210701] = {
			153,
			194,
			129,
			0.4
		},
		[89550335595126] = {
			148,
			145,
			173,
			1
		},
		[90217319066433] = {
			106,
			109,
			101,
			0.18
		},
		[90438392078689] = {
			165,
			149,
			146,
			1
		},
		[90786304526677] = {
			189,
			161,
			150,
			0.29
		},
		[91041407453025] = {
			193,
			192,
			193,
			1
		},
		[91152907558092] = {
			107,
			77,
			55,
			0.79
		},
		[91275148925612] = {
			129,
			127,
			124,
			1
		},
		[91601444171848] = {
			117,
			97,
			62,
			1
		},
		[91704393561356] = {
			64,
			65,
			56,
			1
		},
		[91977464891606] = {
			183,
			141,
			102,
			1
		},
		[93047667037413] = {
			187,
			187,
			185,
			1
		},
		[93164184534076] = {
			172,
			171,
			170,
			1
		},
		[93222237481248] = {
			115,
			114,
			117,
			1
		},
		[93641398566734] = {
			131,
			117,
			107,
			1
		},
		[93705669235694] = {
			84,
			84,
			83,
			1
		},
		[94351602023183] = {
			134,
			117,
			93,
			1
		},
		[94662872313095] = {
			120,
			115,
			111,
			1
		},
		[94975551047156] = {
			245,
			245,
			245,
			1
		},
		[95614136972860] = {
			84,
			84,
			83,
			1
		},
		[95738273473165] = {
			101,
			101,
			101,
			0.38
		},
		[95979243639318] = {
			64,
			73,
			101,
			1
		},
		[96070760242453] = {
			66,
			62,
			54,
			0.71
		},
		[96249856280830] = {
			61,
			79,
			121,
			1
		},
		[96617049712520] = {
			130,
			122,
			107,
			1
		},
		[96624286972400] = {
			95,
			91,
			90,
			0.54
		},
		[96911766381335] = {
			202,
			199,
			196,
			1
		},
		[97244893553065] = {
			167,
			146,
			135,
			0.76
		},
		[97525498317620] = {
			135,
			134,
			98,
			0.14
		},
		[98180650941849] = {
			195,
			181,
			165,
			1
		},
		[98414081067054] = {
			163,
			164,
			164,
			1
		},
		[98926889222899] = {
			139,
			131,
			118,
			1
		},
		[98993939747645] = {
			152,
			148,
			145,
			1
		},
		[99124655196171] = {
			173,
			164,
			156,
			1
		},
		[99338568979098] = {
			125,
			125,
			116,
			1
		},
		[99518888175817] = {
			186,
			186,
			190,
			1
		},
		[99587670559941] = {
			175,
			175,
			175,
			0.36
		},
		[99714947968082] = {
			146,
			143,
			141,
			1
		},
		[99891666748835] = {
			141,
			135,
			131,
			1
		},
		[100127578618059] = {
			157,
			159,
			157,
			1
		},
		[100151830442505] = {
			144,
			144,
			145,
			1
		},
		[100632736623425] = {
			120,
			130,
			121,
			0.35
		},
		[100864489723520] = {
			100,
			99,
			99,
			1
		},
		[101386015822599] = {
			81,
			91,
			126,
			1
		},
		[101536193217381] = {
			109,
			91,
			78,
			1
		},
		[101956971669509] = {
			127,
			87,
			85,
			0.91
		},
		[102682248821386] = {
			143,
			149,
			153,
			1
		},
		[102896732329260] = {
			95,
			91,
			90,
			0.54
		},
		[103089401001172] = {
			121,
			149,
			84,
			0.36
		},
		[103155725910180] = {
			119,
			122,
			132,
			1
		},
		[103374396932396] = {
			181,
			181,
			181,
			1
		},
		[103774132471892] = {
			129,
			127,
			124,
			1
		},
		[103890504409310] = {
			133,
			130,
			127,
			1
		},
		[104874980699909] = {
			187,
			189,
			191,
			1
		},
		[104903350856756] = {
			75,
			74,
			74,
			1
		},
		[105300177076036] = {
			131,
			117,
			107,
			1
		},
		[106002231311026] = {
			190,
			185,
			177,
			1
		},
		[106033222165296] = {
			197,
			196,
			191,
			0.29
		},
		[106305511656637] = {
			143,
			138,
			134,
			1
		},
		[106351155297764] = {
			134,
			99,
			77,
			1
		},
		[106482042767482] = {
			94,
			102,
			71,
			1
		},
		[106669351377477] = {
			120,
			118,
			94,
			1
		},
		[107402954777711] = {
			129,
			127,
			124,
			1
		},
		[107800184933840] = {
			144,
			119,
			90,
			1
		},
		[107877787735819] = {
			74,
			104,
			133,
			1
		},
		[107936267488219] = {
			144,
			137,
			126,
			0.54
		},
		[108906408925412] = {
			113,
			105,
			93,
			1
		},
		[110034810314152] = {
			176,
			167,
			163,
			1
		},
		[110246590145510] = {
			186,
			184,
			184,
			1
		},
		[110617076593196] = {
			186,
			184,
			184,
			1
		},
		[110736755021210] = {
			144,
			144,
			144,
			1
		},
		[110892689357287] = {
			136,
			110,
			96,
			1
		},
		[111089576385180] = {
			130,
			122,
			107,
			1
		},
		[111431296611123] = {
			157,
			159,
			157,
			1
		},
		[111622283548052] = {
			119,
			120,
			118,
			1
		},
		[111691051570230] = {
			175,
			175,
			175,
			0.36
		},
		[111878200089761] = {
			123,
			117,
			115,
			1
		},
		[112268767252430] = {
			130,
			122,
			107,
			1
		},
		[112472837504601] = {
			110,
			101,
			91,
			1
		},
		[112835334720289] = {
			128,
			145,
			93,
			0.86
		},
		[113357306123385] = {
			135,
			132,
			121,
			1
		},
		[113603658881955] = {
			100,
			80,
			74,
			1
		},
		[113816733917900] = {
			185,
			185,
			185,
			1
		},
		[113839428578225] = {
			144,
			144,
			145,
			1
		},
		[113903669389224] = {
			127,
			124,
			124,
			1
		},
		[114099330552168] = {
			64,
			73,
			101,
			1
		},
		[115122743175055] = {
			177,
			176,
			176,
			1
		},
		[115659942025785] = {
			150,
			142,
			130,
			0.14
		},
		[115920485392218] = {
			218,
			218,
			218,
			0.93
		},
		[116438325194826] = {
			181,
			181,
			181,
			0.29
		},
		[117153733334064] = {
			123,
			107,
			102,
			1
		},
		[118293660821769] = {
			186,
			180,
			170,
			0.97
		},
		[118398804507918] = {
			134,
			134,
			128,
			1
		},
		[118405758253206] = {
			44,
			43,
			44,
			1
		},
		[118565172149747] = {
			105,
			80,
			82,
			1
		},
		[118595051674889] = {
			155,
			161,
			166,
			1
		},
		[119297288405105] = {
			143,
			138,
			134,
			1
		},
		[119724206789598] = {
			99,
			106,
			121,
			1
		},
		[119930134076983] = {
			131,
			117,
			107,
			1
		},
		[120152583200779] = {
			181,
			181,
			181,
			0.29
		},
		[120403218128904] = {
			175,
			175,
			175,
			0.36
		},
		[120681973631505] = {
			96,
			102,
			106,
			0.84
		},
		[121032150430299] = {
			81,
			91,
			126,
			1
		},
		[121063105694701] = {
			131,
			132,
			106,
			1
		},
		[121113035992730] = {
			143,
			138,
			134,
			1
		},
		[121712203045808] = {
			143,
			138,
			134,
			1
		},
		[122375674109901] = {
			73,
			73,
			71,
			1
		},
		[122757701567691] = {
			194,
			192,
			193,
			1
		},
		[122798321166971] = {
			187,
			189,
			191,
			1
		},
		[122918291110692] = {
			164,
			166,
			168,
			1
		},
		[123377383519391] = {
			149,
			144,
			140,
			1
		},
		[123388527485606] = {
			172,
			171,
			170,
			1
		},
		[123920572033734] = {
			98,
			105,
			87,
			1
		},
		[124398696332046] = {
			155,
			151,
			149,
			1
		},
		[125181412704025] = {
			170,
			168,
			168,
			1
		},
		[125501676056521] = {
			110,
			101,
			91,
			1
		},
		[125599190791688] = {
			161,
			160,
			160,
			1
		},
		[125700247126787] = {
			131,
			132,
			106,
			1
		},
		[126102027969672] = {
			175,
			175,
			175,
			0.36
		},
		[126224743505431] = {
			135,
			130,
			187,
			1
		},
		[126262459790337] = {
			114,
			110,
			104,
			0.94
		},
		[126330272019219] = {
			117,
			97,
			62,
			1
		},
		[126728831050819] = {
			196,
			194,
			194,
			1
		},
		[127237821712147] = {
			68,
			66,
			64,
			1
		},
		[127527260814496] = {
			87,
			87,
			86,
			1
		},
		[127757860184512] = {
			127,
			87,
			85,
			0.91
		},
		[127832259750884] = {
			139,
			117,
			102,
			1
		},
		[129004723003883] = {
			193,
			193,
			193,
			0.11
		},
		[129702159095319] = {
			74,
			90,
			107,
			1
		},
		[129944928694851] = {
			101,
			99,
			98,
			1
		},
		[130039295929328] = {
			152,
			154,
			156,
			1
		},
		[130451758165221] = {
			107,
			107,
			107,
			0.08
		},
		[130724855151924] = {
			113,
			105,
			93,
			1
		},
		[131563635661118] = {
			187,
			180,
			171,
			0.91
		},
		[131801755420962] = {
			106,
			102,
			96,
			0.92
		},
		[131973942077096] = {
			136,
			110,
			96,
			1
		},
		[132385859651215] = {
			158,
			166,
			164,
			1
		},
		[132552516113602] = {
			139,
			110,
			97,
			0.49
		},
		[132611546874607] = {
			137,
			145,
			162,
			1
		},
		[132857936101144] = {
			165,
			139,
			98,
			0.08
		},
		[132962841145611] = {
			157,
			141,
			85,
			1
		},
		[133300810670140] = {
			175,
			175,
			175,
			0.36
		},
		[133578626218428] = {
			131,
			117,
			107,
			1
		},
		[134810316354686] = {
			105,
			94,
			92,
			0.75
		},
		[134840581358530] = {
			129,
			126,
			126,
			0.99
		},
		[134846249383823] = {
			192,
			89,
			63,
			0.22
		},
		[135378256567026] = {
			73,
			85,
			124,
			1
		},
		[135599348779538] = {
			131,
			117,
			107,
			1
		},
		[137001039323620] = {
			186,
			186,
			190,
			1
		},
		[137742749117094] = {
			155,
			161,
			166,
			1
		},
		[138588391394584] = {
			108,
			104,
			101,
			1
		},
		[139140034468960] = {
			177,
			164,
			151,
			0.39
		},
		[139329502892326] = {
			175,
			175,
			175,
			0.36
		},
		[139381473711307] = {
			118,
			104,
			91,
			1
		},
		[139818861606326] = {
			152,
			154,
			156,
			1
		},
		[139962924833610] = {
			196,
			194,
			194,
			1
		},
		[140048223961373] = {
			110,
			101,
			91,
			1
		},
		[140062936115959] = {
			223,
			224,
			223,
			1
		},
		[140336495089186] = {
			213,
			212,
			212,
			1
		},
		[140356598023898] = {
			113,
			140,
			153,
			1
		},
		[140535327999397] = {
			130,
			122,
			107,
			1
		},
		[140621480877390] = {
			175,
			175,
			175,
			0.36
		}
	},
	["Textures"] = {
		[20664425] = {
			216,
			214,
			218,
			0.99
		},
		[75825036] = {
			255,
			255,
			255,
			0.07
		},
		[136136589] = {
			77,
			73,
			33,
			0.24
		},
		[230530847] = {
			198,
			215,
			213,
			0.07
		},
		[6171439278] = {
			177,
			177,
			177,
			1
		},
		[6217156141] = {
			92,
			86,
			80,
			0.24
		},
		[6304887570] = {
			166,
			166,
			166,
			1
		},
		[6372755229] = {
			255,
			255,
			255,
			0.41
		},
		[11187055032] = {
			204,
			185,
			144,
			1
		},
		[12847809218] = {
			122,
			125,
			122,
			0.14
		},
		[12969190503] = {
			102,
			83,
			59,
			0.17
		},
		[13781875318] = {
			108,
			101,
			93,
			0.17
		},
		[17352577281] = {
			190,
			190,
			190,
			0.14
		},
		[18882075891] = {
			144,
			129,
			121,
			1
		},
		[70976986090330] = {
			253,
			253,
			253,
			0.65
		},
		[71292815908497] = {
			182,
			180,
			181,
			1
		},
		[71749502861788] = {
			184,
			163,
			62,
			1
		},
		[71762714977042] = {
			141,
			120,
			108,
			1
		},
		[71844347979250] = {
			218,
			216,
			218,
			0.39
		},
		[72532830479225] = {
			255,
			255,
			255,
			0.54
		},
		[72590175623979] = {
			121,
			121,
			121,
			0.02
		},
		[74654202495528] = {
			124,
			126,
			124,
			0.25
		},
		[75061621155876] = {
			207,
			212,
			220,
			0.62
		},
		[75092468029774] = {
			223,
			222,
			235,
			0.61
		},
		[75209167235278] = {
			124,
			126,
			124,
			0.25
		},
		[75442257067716] = {
			161,
			143,
			128,
			1
		},
		[75938694453015] = {
			74,
			91,
			111,
			0.19
		},
		[75949142266107] = {
			121,
			121,
			121,
			0.02
		},
		[78209999431839] = {
			171,
			171,
			170,
			0.58
		},
		[78476342154955] = {
			124,
			126,
			124,
			0.25
		},
		[79206786786371] = {
			249,
			205,
			107,
			0.19
		},
		[79751348964159] = {
			208,
			207,
			204,
			1
		},
		[81669928690495] = {
			206,
			206,
			207,
			0.13
		},
		[82819157056542] = {
			199,
			199,
			199,
			1
		},
		[83401816190872] = {
			229,
			225,
			219,
			0.29
		},
		[83602058425012] = {
			255,
			255,
			255,
			0.36
		},
		[83695446643389] = {
			238,
			232,
			225,
			0.36
		},
		[84342769045685] = {
			255,
			255,
			255,
			0.15
		},
		[84417719554422] = {
			179,
			153,
			118,
			1
		},
		[85982224784704] = {
			181,
			177,
			172,
			0.06
		},
		[87253283163820] = {
			3,
			1,
			0,
			0.01
		},
		[87273643806336] = {
			223,
			222,
			235,
			0.42
		},
		[90008158673201] = {
			247,
			247,
			247,
			0.61
		},
		[90572226161578] = {
			178,
			178,
			178,
			0.44
		},
		[90594476717337] = {
			255,
			255,
			255,
			0.22
		},
		[90633427445177] = {
			127,
			110,
			94,
			0.38
		},
		[90830813909320] = {
			245,
			245,
			245,
			1
		},
		[91273362660021] = {
			104,
			101,
			98,
			1
		},
		[92474269929267] = {
			205,
			205,
			205,
			0.1
		},
		[93724732135425] = {
			116,
			115,
			118,
			1
		},
		[94074721549560] = {
			127,
			113,
			104,
			0.13
		},
		[94077140698941] = {
			139,
			121,
			108,
			1
		},
		[94338556152902] = {
			187,
			186,
			185,
			0.06
		},
		[95434192356440] = {
			254,
			254,
			254,
			0.04
		},
		[95648112131050] = {
			110,
			124,
			106,
			1
		},
		[96813234427601] = {
			233,
			224,
			206,
			0.92
		},
		[98502042886189] = {
			221,
			220,
			232,
			0.34
		},
		[99003287429816] = {
			255,
			255,
			255,
			0.18
		},
		[100270118817155] = {
			255,
			255,
			255,
			1
		},
		[100923305794264] = {
			255,
			255,
			255,
			0.2
		},
		[101320925481792] = {
			207,
			206,
			203,
			1
		},
		[101360715355715] = {
			80,
			80,
			80,
			0.5
		},
		[101580158431493] = {
			118,
			118,
			118,
			0.24
		},
		[101851099131571] = {
			55,
			54,
			50,
			0.66
		},
		[104319928169943] = {
			193,
			194,
			194,
			1
		},
		[104444587245760] = {
			233,
			231,
			229,
			0.13
		},
		[104914927717652] = {
			57,
			61,
			61,
			1
		},
		[105063454237536] = {
			223,
			222,
			235,
			0.34
		},
		[105127071118023] = {
			181,
			188,
			197,
			0.12
		},
		[105796992538505] = {
			181,
			177,
			172,
			0.42
		},
		[106398595609839] = {
			254,
			254,
			254,
			0.04
		},
		[106551595934553] = {
			143,
			143,
			143,
			1
		},
		[106588171982082] = {
			174,
			173,
			173,
			0.29
		},
		[106866205273789] = {
			254,
			254,
			254,
			0.67
		},
		[109343167771314] = {
			120,
			88,
			71,
			0.52
		},
		[110148059262639] = {
			200,
			195,
			190,
			0.5
		},
		[110672976095073] = {
			127,
			100,
			140,
			0.31
		},
		[112079533898919] = {
			238,
			232,
			225,
			0.36
		},
		[113924378910311] = {
			157,
			157,
			157,
			0.38
		},
		[114879010344276] = {
			255,
			255,
			255,
			0.22
		},
		[117079783329584] = {
			162,
			160,
			160,
			0.39
		},
		[118259229800201] = {
			255,
			255,
			255,
			0.03
		},
		[119707497015261] = {
			255,
			255,
			255,
			0.17
		},
		[120267860238434] = {
			150,
			153,
			152,
			0.45
		},
		[121042424158364] = {
			255,
			255,
			255,
			0.26
		},
		[121070285188795] = {
			199,
			199,
			199,
			0.04
		},
		[121399394457012] = {
			170,
			168,
			168,
			0.61
		},
		[121713965070419] = {
			255,
			255,
			255,
			0.04
		},
		[122861521768114] = {
			160,
			103,
			132,
			0.31
		},
		[122903753012591] = {
			255,
			255,
			255,
			0.29
		},
		[122946647165016] = {
			181,
			177,
			172,
			0.22
		},
		[123160259178221] = {
			125,
			121,
			113,
			0.42
		},
		[125250707261352] = {
			220,
			215,
			209,
			0.52
		},
		[125473422820925] = {
			254,
			254,
			254,
			0.05
		},
		[125535050426314] = {
			255,
			255,
			255,
			0.06
		},
		[125899378700143] = {
			249,
			206,
			107,
			0.2
		},
		[125976392777000] = {
			223,
			209,
			191,
			0.13
		},
		[126149060892284] = {
			147,
			148,
			147,
			0.04
		},
		[129293971328010] = {
			187,
			186,
			185,
			0.08
		},
		[130809624332298] = {
			228,
			228,
			228,
			0.88
		},
		[130988004363782] = {
			124,
			126,
			124,
			0.25
		},
		[133390434927661] = {
			242,
			236,
			238,
			0.13
		},
		[133986409552532] = {
			126,
			127,
			126,
			0.37
		},
		[134418068431344] = {
			235,
			213,
			173,
			0.54
		},
		[135231307475567] = {
			226,
			226,
			227,
			0.97
		},
		[136584814719894] = {
			166,
			161,
			155,
			0.73
		},
		[138062943571021] = {
			231,
			231,
			231,
			0.22
		},
		[138846653092341] = {
			200,
			195,
			190,
			0.5
		},
		[138935689598577] = {
			169,
			170,
			171,
			1
		},
		[138993750082604] = {
			191,
			191,
			191,
			0.26
		},
		[139231356674029] = {
			118,
			117,
			114,
			0.29
		},
		[139384951129502] = {
			191,
			168,
			144,
			1
		},
		[139459411203703] = {
			243,
			243,
			243,
			0.54
		},
		[139725908913572] = {
			213,
			213,
			213,
			1
		},
		[140486259382592] = {
			90,
			110,
			85,
			1
		},
		[140660794009500] = {
			21,
			21,
			21,
			0.31
		}
	}
}
return v1
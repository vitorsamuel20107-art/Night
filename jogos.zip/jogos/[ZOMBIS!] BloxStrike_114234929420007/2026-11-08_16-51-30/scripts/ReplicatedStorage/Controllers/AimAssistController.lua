-- NIGHT Analyzer | ReplicatedStorage.Controllers.AimAssistController
-- ModuleScript | 727 linhas | 19435 bytes | hash 9871fbbb

local v_u_1 = {}
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = game:GetService("Players")
local v_u_5 = game:GetService("UserInputService")
local v_u_6 = v_u_4.LocalPlayer
local v_u_7 = require(v2.Controllers.DataController)
local v_u_8 = require(v2.Controllers.HordeController)
local v_u_9 = require(v2.Components.Common.VFXLibary.FlashEffect)
local v10 = require(v2.Components.Common.GetUserPlatform)
local v_u_11 = require(v2.Components.Common.CharacterResolver)
local v_u_12 = require(v2.Components.Common.IsSurvivalMode)
local v13 = require(v2.Database.Custom.Constants)
local v14 = v10()
local v_u_15
if table.find(v14, "Mobile") == nil then
	v_u_15 = false
else
	v_u_15 = #v14 <= 1
end
local v_u_16 = v_u_3.CurrentCamera
local v_u_17 = true
local v_u_18 = true
local v_u_19 = v13.AIM_ASSIST_CONFIGS.PLAYER
local v_u_20 = {
	["Counter-Terrorists"] = true,
	["Terrorists"] = true
}
local v_u_21 = {
	["AimHeight"] = 0.6,
	["PullAngle"] = 0.17453292519943295,
	["PullRate"] = 3.2,
	["IdlePullShare"] = 0.25,
	["MaxPullSpeed"] = 0.5235987755982988,
	["SettleAngle"] = 0.002617993877991494,
	["TrackingStrength"] = 0.55,
	["TrackingAngle"] = 0.12217304763960307,
	["MaxTrackingSpeed"] = 3,
	["StickDeadzone"] = 0.15
}
local v_u_22 = nil
local v_u_23 = (-1 / 0)
local v_u_24 = nil
local v_u_25 = nil
local v_u_26 = 0
local v_u_27 = 0
local function v_u_59(p28, p29, p30, p31, p32) -- name: rayIntersectsAABB
	local v33 = p28.X
	local v34 = p29.X
	local v35 = p30.X
	local v36 = p31.X
	local v37 = 0
	local v38, v39
	if math.abs(v34) < 0.0001 then
		if v33 < v35 or v36 < v33 then
			v38 = p32
			v39 = nil
		else
			v38 = p32
			v39 = v37
		end
	else
		local v40 = 1 / v34
		v38 = (v35 - v33) * v40
		v39 = (v36 - v33) * v40
		if v39 >= v38 then
			local v41 = v38
			v38 = v39
			v39 = v41
		end
		if v37 >= v39 then
			v39 = v37
		end
		if v38 >= p32 then
			v38 = p32
		end
		if v38 < v39 then
			v39 = nil
		end
	end
	if not v39 then
		return false
	end
	local v42 = p28.Y
	local v43 = p29.Y
	local v44 = p30.Y
	local v45 = p31.Y
	if math.abs(v43) < 0.0001 then
		if v42 < v44 or v45 < v42 then
			v39 = nil
		end
	else
		local v46 = 1 / v43
		local v47 = (v44 - v42) * v46
		local v48 = (v45 - v42) * v46
		if v48 >= v47 then
			local v49 = v47
			v47 = v48
			v48 = v49
		end
		if v39 >= v48 then
			v48 = v39
		end
		if v47 >= v38 then
			v47 = v38
		end
		if v47 < v48 then
			v38 = v47
			v39 = nil
		else
			v38 = v47
			v39 = v48
		end
	end
	if not v39 then
		return false
	end
	local v50 = p28.Z
	local v51 = p29.Z
	local v52 = p30.Z
	local v53 = p31.Z
	if math.abs(v51) < 0.0001 then
		if v50 < v52 or v53 < v50 then
			v39 = nil
		end
	else
		local v54 = 1 / v51
		local v55 = (v52 - v50) * v54
		local v56 = (v53 - v50) * v54
		if v56 >= v55 then
			local v57 = v55
			v55 = v56
			v56 = v57
		end
		if v39 >= v56 then
			v56 = v39
		end
		if v55 >= v38 then
			v55 = v38
		end
		if v55 < v56 then
			v38 = v55
			v39 = nil
		else
			v38 = v55
			v39 = v56
		end
	end
	local v58
	if v39 == nil or v39 < 0 then
		v58 = false
	else
		v58 = v39 <= p32
	end
	return v58
end
local function v_u_68(p60, p61, p62) -- name: doesRaycastIntersectSmoke
	-- upvalues: (copy) v_u_3, (copy) v_u_59
	local v63 = v_u_3:FindFirstChild("Debris")
	if not v63 then
		return false
	end
	for _, v64 in ipairs(v63:GetChildren()) do
		if not (v64.Name:match("^VoxelSmoke_") and v64:IsA("Folder")) then
			continue
		end
		for _, v65 in ipairs(v64:GetChildren()) do
			if not v65:IsA("BasePart") or v65.Name ~= "SmokeVoxel" then
				continue
			end
			local v66 = v65.Size
			local v67 = v65.Position
			if not v_u_59(p60, p61, v67 - v66 / 2, v67 + v66 / 2, p62) then
				continue
			end
			return true
		end
	end
	return false
end
local function v_u_73(p69) -- name: isBotTarget
	-- upvalues: (copy) v_u_12, (copy) v_u_6, (copy) v_u_20
	local v70 = p69:IsA("Model")
	if v70 then
		if p69:GetAttribute("Bot") == true and (p69:GetAttribute("Dead") ~= true and ((tonumber(p69:GetAttribute("Health")) or 1) > 0 and (p69:GetAttribute("ClientCharacterPresentationVisible") ~= false and p69.PrimaryPart ~= nil))) then
			local v71 = p69:GetAttribute("Team")
			if v_u_12() then
				return false
			end
			local v72 = v_u_6:GetAttribute("Team")
			if not (v_u_20[v72] and v_u_20[v71]) then
				return false
			end
			v70 = workspace:GetAttribute("Gamemode") == "Deathmatch" and true or v72 ~= v71
		else
			v70 = false
		end
	end
	return v70
end
local function v_u_82() -- name: getTargetCandidates
	-- upvalues: (copy) v_u_12, (copy) v_u_8, (copy) v_u_4, (copy) v_u_6, (copy) v_u_20, (copy) v_u_11, (copy) v_u_3, (copy) v_u_73
	if v_u_12() then
		return v_u_8.GetLiveShells()
	end
	local v74 = {}
	for _, v75 in ipairs(v_u_4:GetPlayers()) do
		if v75 == v_u_6 then
			continue
		end
		local v76 = v75:GetAttribute("Team")
		local v77
		if v_u_12() then
			v77 = false
		else
			local v78 = v_u_6:GetAttribute("Team")
			if v_u_20[v78] and v_u_20[v76] then
				v77 = workspace:GetAttribute("Gamemode") == "Deathmatch" and true or v78 ~= v76
			else
				v77 = false
			end
		end
		if not v77 then
			continue
		end
		local v79 = v_u_11.getPlayerCharacter(v75)
		if not (v79 and (v79.PrimaryPart and v_u_11.isAliveCharacter(v79))) then
			continue
		end
		table.insert(v74, v79)
	end
	local v80 = v_u_3:FindFirstChild("Characters")
	if v80 then
		for _, v81 in ipairs(v80:GetChildren()) do
			if not v_u_73(v81) then
				continue
			end
			table.insert(v74, v81)
		end
	end
	return v74
end
local function v_u_88() -- name: getLocalRaycastParams
	-- upvalues: (copy) v_u_11, (copy) v_u_3
	local v83 = RaycastParams.new()
	v83.FilterType = Enum.RaycastFilterType.Exclude
	local v84 = {}
	local v85 = v_u_11.getLocalCharacter()
	if v85 then
		table.insert(v84, v85)
	end
	local v86 = v_u_3:FindFirstChild("Map")
	local v87
	if v86 then
		v87 = v86:FindFirstChild("Barriers")
	else
		v87 = nil
	end
	if v87 then
		table.insert(v84, v87)
	end
	v83.FilterDescendantsInstances = v84
	return v83
end
local function v_u_95(p89, p90) -- name: isTargetVisible
	-- upvalues: (copy) v_u_68, (copy) v_u_3, (copy) v_u_88
	local v91 = p89.PrimaryPart.Position
	local v92 = (v91 - p90).Unit
	local v93 = (v91 - p90).Magnitude
	if v_u_68(p90, v92, v93) then
		return false
	end
	local v94 = v_u_3:Raycast(p90, v92 * v93, (v_u_88()))
	return v94 == nil and true or p89:IsAncestorOf(v94.Instance)
end
local function v_u_110(p96) -- name: findBestTarget
	-- upvalues: (ref) v_u_23, (ref) v_u_22, (copy) v_u_82, (copy) v_u_19, (copy) v_u_95, (ref) v_u_24
	local v97 = os.clock()
	if v97 - v_u_23 < 0.004166666666666667 then
		return v_u_22
	end
	local v98 = 0
	local v99 = nil
	for _, v100 in ipairs(v_u_82()) do
		local v101 = v100.PrimaryPart.Position
		local v102 = p96.Position
		local v103 = (v101 - v102).Magnitude
		if v_u_19.TargetSelection.MaxDistance < v103 then
			continue
		end
		local v104 = (v101 - v102).Unit
		local v105 = p96.LookVector:Dot(v104)
		local v106 = math.clamp(v105, -1, 1)
		local v107 = math.acos(v106)
		if v_u_19.TargetSelection.MaxAngle < v107 or not v_u_95(v100, v102) then
			continue
		end
		local v108 = v107 / v_u_19.TargetSelection.MaxAngle
		local v109 = 1 / (v103 + 1) * (1 - v108)
		if v100 == v_u_24 then
			v109 = v109 * 1.6
		end
		if v98 >= v109 then
			continue
		end
		v99 = v100
		v98 = v109
	end
	v_u_24 = v99
	v_u_22 = v99
	v_u_23 = v97
	return v99
end
local function v_u_127(p111, p112) -- name: calculateFrictionMultiplier
	-- upvalues: (copy) v_u_19, (copy) v_u_16
	if not p112 then
		return v_u_19.Friction.MaxSensitivity
	end
	local v113 = p112.PrimaryPart.Position
	local v114, v115 = v_u_16:WorldToViewportPoint(v113)
	if not v115 or v114.Z < 0 then
		return v_u_19.Friction.MaxSensitivity
	end
	local v116 = v_u_16.ViewportSize / 2
	local v117 = Vector2.new(v116.X, v116.Y)
	local v118 = (Vector2.new(v114.X, v114.Y) - v117).Magnitude
	local v119 = (v113 - p111.Position).Magnitude
	local v120 = 2 / v119 * v116.Y * 2
	local v121 = v_u_19.Friction.BubbleRadius * (v116.Y / v119) * 2
	if v121 + v120 / 2 < v118 then
		return v_u_19.Friction.MaxSensitivity
	end
	local v122 = v118 - v120 / 2
	local v123 = math.max(0, v122) / math.max(v121, 1)
	local v124 = math.clamp(v123, 0, 1)
	local v125 = v124 * v124 * (3 - v124 * 2)
	local v126 = v_u_19.Friction.MinSensitivity
	return v126 + (v_u_19.Friction.MaxSensitivity - v126) * v125
end
function v_u_1.GetFrictionMultiplier() -- name: GetFrictionMultiplier
	-- upvalues: (copy) v_u_19, (copy) v_u_15, (copy) v_u_5, (ref) v_u_17, (ref) v_u_18, (copy) v_u_9, (copy) v_u_16, (copy) v_u_11, (copy) v_u_127, (copy) v_u_110
	local v128 = v_u_19.Friction.Enabled
	if v128 then
		if v_u_15 or v_u_5.PreferredInput == Enum.PreferredInput.Touch then
			v128 = v_u_17
		elseif v_u_5.PreferredInput == Enum.PreferredInput.Gamepad then
			v128 = v_u_18
		else
			v128 = false
		end
		if v128 then
			v128 = not v_u_9.IsFlashed()
		end
	end
	if v128 then
		local v129
		if v_u_16 == nil then
			v129 = false
		else
			v129 = v_u_11.getLocalCharacter() ~= nil
		end
		if v129 then
			local v130 = v_u_16.CFrame
			return v_u_127(v130, (v_u_110(v130)))
		end
	end
	return v_u_19.Friction.MaxSensitivity
end
local function v_u_152(p131) -- name: findTargetWithRaycast
	-- upvalues: (copy) v_u_19, (copy) v_u_88, (copy) v_u_3, (copy) v_u_12, (copy) v_u_8, (copy) v_u_68, (copy) v_u_73, (copy) v_u_11, (copy) v_u_6, (copy) v_u_20
	-- block 39
	local v132 = p131.Position
	local v133 = v_u_19.Magnetism.MaxDistance
	local v134 = v_u_88()
	local v135 = v_u_19.Magnetism.MaxAngleHorizontal / 2
	local v136 = v_u_19.Magnetism.MaxAngleVertical / 2
	for v137 = -1, 1 do
		goto l6
	end
	return nil
	::l6::
	local v138, v139, v140
	-- NumForInit
local v138, v139, v140 = -1, 1, 1
-- end NumForInit
	-- NumForNext
v138 = v138 + v140;
if v138 <= v139
-- end NumForNext
	local v141 = (p131 * CFrame.Angles(v138 * v136, v137 * v135, 0)).LookVector
	local v142 = v_u_3:Raycast(v132, v141 * v133, v134)
	if not v142 then
		continue
	end
	local v143
	if v_u_12() then
		v143 = v_u_8.GetLiveShell(v142.Instance)
	else
		v143 = nil
	end
	if v143 then
		local v144 = (v142.Position - v132).Magnitude
		if v144 > v133 or v_u_68(v132, v141, v144) then
			continue
		end
		return v143
	end
	local v145 = v142.Instance:FindFirstAncestorOfClass("Model")
	if not v145 then
		continue
	end
	local v146 = v145
	while true do
		if not (v145 and v145:IsA("Model")) then
			v145 = v146
			break
		end
		if v145:GetAttribute("Bot") == true then
			break
		end
		v145 = v145.Parent
	end
	local v147 = v_u_73(v145)
	if not v147 and v_u_11.isPlayerCharacter(v145) then
		local v148 = v_u_11.getPlayerFromCharacter(v145)
		if v148 == nil then
			v147 = false
		else
			local v149 = v148:GetAttribute("Team")
			if v_u_12() then
				v147 = false
			else
				local v150 = v_u_6:GetAttribute("Team")
				if v_u_20[v150] and v_u_20[v149] then
					v147 = workspace:GetAttribute("Gamemode") == "Deathmatch" and true or v150 ~= v149
				else
					v147 = false
				end
			end
			if v147 then
				v147 = v_u_11.isAliveCharacter(v145)
			end
		end
	end
	if not v147 then
		break
	end
	local v151 = (v142.Position - v132).Magnitude
	if v151 > v133 or v_u_68(v132, v141, v151) then
		break
	end
	return v145
end
local function v_u_178(p153, p154, p155) -- name: calculateMagnetismRotation
	-- upvalues: (copy) v_u_19
	if not p154.PrimaryPart then
		return Vector2.zero
	end
	local v156 = p154.PrimaryPart.Position
	local v157 = p153.Position
	local v158 = p153.LookVector
	if (v156 - v157).Magnitude > v_u_19.Magnetism.MaxDistance then
		return Vector2.zero
	end
	local v159 = (v156 - v157).Unit
	local v160 = v158.X
	local v161 = v158.Z
	local v162 = Vector3.new(v160, 0, v161).Unit
	local v163 = v159.X
	local v164 = v159.Z
	local v165 = v162:Dot(Vector3.new(v163, 0, v164).Unit)
	local v166 = math.clamp(v165, -1, 1)
	local v167 = math.acos(v166)
	if v_u_19.Magnetism.MaxAngleHorizontal < v167 or (v167 <= v_u_19.Magnetism.StopThreshold or v167 > 1.5707963267948966) then
		return Vector2.zero
	end
	local v168 = -v158.X
	local v169 = -v158.Z
	local v170 = math.atan2(v168, v169)
	local v171 = -v159.X
	local v172 = -v159.Z
	local v173 = math.atan2(v171, v172) - v170
	if v173 > 3.141592653589793 then
		v173 = v173 - 6.283185307179586
	elseif v173 < -3.141592653589793 then
		v173 = v173 + 6.283185307179586
	end
	local v174 = math.abs(v173)
	if v174 < 0.001 then
		return Vector2.zero
	end
	local v175 = v_u_19.Magnetism.PullStrength * p155
	local v176 = math.min(v175, v174)
	local v177 = v173 > 0 and 1 or -1
	return Vector2.new(v177 * v176, 0)
end
local function v_u_197(p179, p180, p181, p182) -- name: calculateVerticalMagnetismRotation
	-- upvalues: (copy) v_u_19
	local v183 = p180:FindFirstChild("Head")
	if not v183 then
		return 0
	end
	local v184 = v183.Position
	local v185 = v_u_19.VerticalMagnetism
	local v186 = p179.Position
	if (v184 - v186).Magnitude > v185.MaxDistance then
		return 0
	end
	local v187 = (v184 - v186).Unit
	local v188 = p179.LookVector.Y
	local v189 = math.clamp(v188, -1, 1)
	local v190 = math.asin(v189)
	local v191 = v187.Y
	local v192 = math.clamp(v191, -1, 1)
	local v193 = math.asin(v192) - v190
	local v194 = math.abs(v193)
	if not p182 and v185.MaxAngleVertical < v194 then
		return 0
	end
	if v194 <= v185.StopThreshold or v194 < 0.001 then
		return 0
	end
	local v195 = v185.PullStrength * p181
	local v196 = math.min(v195, v194)
	return (v193 > 0 and 1 or -1) * v196
end
local function v_u_203() -- name: getStickActivity
	-- upvalues: (copy) v_u_5
	local v198 = 0
	for _, v199 in v_u_5:GetConnectedGamepads() do
		for _, v200 in v_u_5:GetGamepadState(v199) do
			if v200.KeyCode ~= Enum.KeyCode.Thumbstick1 and v200.KeyCode ~= Enum.KeyCode.Thumbstick2 then
				continue
			end
			local v201 = Vector2.new(v200.Position.X, v200.Position.Y).Magnitude
			v198 = math.max(v198, v201)
		end
	end
	local v202 = (v198 - 0.15) / 0.85 * 1.5
	return math.clamp(v202, 0, 1)
end
local function v_u_245(p204, p205, p206) -- name: calculateControllerMagnetism
	-- upvalues: (copy) v_u_21, (ref) v_u_25, (copy) v_u_19, (copy) v_u_203, (ref) v_u_26, (ref) v_u_27
	local v207 = p205.PrimaryPart
	local v208
	if v207 then
		local v209 = p205:FindFirstChild("Head")
		if v209 and v209:IsA("BasePart") then
			v208 = v207.Position:Lerp(v209.Position, v_u_21.AimHeight)
		else
			v208 = v207.Position
		end
	else
		v208 = nil
	end
	if not v208 then
		v_u_25 = nil
		return Vector2.zero
	end
	local v210 = v208 - p204.Position
	local v211 = v210.Magnitude
	if v211 < 1 or v_u_19.Magnetism.MaxDistance < v211 then
		v_u_25 = nil
		return Vector2.zero
	end
	local v212 = v210 / v211
	local v213 = -v212.X
	local v214 = -v212.Z
	local v215 = math.atan2(v213, v214)
	local v216 = v212.Y
	local v217 = math.clamp(v216, -1, 1)
	local v218 = math.asin(v217)
	local v219 = p204.LookVector
	local v220 = -v219.X
	local v221 = -v219.Z
	local v222 = math.atan2(v220, v221)
	local v223 = v219.Y
	local v224 = math.clamp(v223, -1, 1)
	local v225 = math.asin(v224)
	local v226 = p204.LookVector:Dot(v212)
	local v227 = math.clamp(v226, -1, 1)
	local v228 = math.acos(v227)
	local v229 = v_u_203()
	local v230 = 0
	local v231 = 0
	if v_u_25 == p205 and v228 < 0.12217304763960307 then
		local v232 = (v215 - v_u_26 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
		local v233 = v218 - v_u_27
		local v234 = 3 * p206
		if math.abs(v232) < v234 and math.abs(v233) < v234 then
			local v235 = 0.55 * v229 * (1 - v228 / 0.12217304763960307)
			v230 = v232 * v235
			v231 = v233 * v235
		end
	end
	v_u_25 = p205
	v_u_26 = v215
	v_u_27 = v218
	local v236, v237
	if v228 > 0.002617993877991494 and v228 < 0.17453292519943295 then
		local v238 = 1 - (v228 / 0.17453292519943295) ^ 2
		local v239 = 0.25 + 0.75 * v229
		local v240 = -3.2 * p206
		local v241 = (1 - math.exp(v240)) * v238 * v239
		v236 = ((v215 - v222 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793) * v241
		v237 = (v218 - v225) * v241
		local v242 = v236 * v236 + v237 * v237
		local v243 = math.sqrt(v242)
		local v244 = 0.5235987755982988 * p206
		if v244 < v243 then
			v236 = v236 * v244 / v243
			v237 = v237 * v244 / v243
		end
	else
		v236 = 0
		v237 = 0
	end
	return Vector2.new(v236 + v230, v237 + v231)
end
function v_u_1.GetMagnetismRotation(p246) -- name: GetMagnetismRotation
	-- upvalues: (copy) v_u_19, (copy) v_u_15, (copy) v_u_5, (ref) v_u_17, (ref) v_u_18, (copy) v_u_9, (copy) v_u_16, (copy) v_u_11, (ref) v_u_25, (copy) v_u_110, (copy) v_u_152, (copy) v_u_245, (copy) v_u_178, (copy) v_u_197
	local v247 = v_u_19.Magnetism.Enabled
	if v247 then
		if v_u_15 or v_u_5.PreferredInput == Enum.PreferredInput.Touch then
			v247 = v_u_17
		elseif v_u_5.PreferredInput == Enum.PreferredInput.Gamepad then
			v247 = v_u_18
		else
			v247 = false
		end
		if v247 then
			v247 = not v_u_9.IsFlashed()
		end
	end
	if v247 then
		local v248
		if v_u_16 == nil then
			v248 = false
		else
			v248 = v_u_11.getLocalCharacter() ~= nil
		end
		if v248 then
			local v249 = p246 or 0.016666666666666666
			local v250 = v_u_16.CFrame
			local v251 = v_u_110(v250) or v_u_152(v250)
			if not v251 then
				v_u_25 = nil
				return Vector2.zero
			end
			if v_u_5.PreferredInput == Enum.PreferredInput.Gamepad then
				return v_u_245(v250, v251, v249)
			end
			v_u_25 = nil
			local v252 = v_u_178(v250, v251, v249)
			local v253 = v252.X
			local v254 = math.abs(v253) > 0.0001
			local v255 = not v_u_19.VerticalMagnetism.Enabled and 0 or v_u_197(v250, v251, v249, v254)
			return Vector2.new(v252.X, v255)
		end
	end
	v_u_25 = nil
	return Vector2.zero
end
function v_u_1.GetRecoilAssistMultiplier() -- name: GetRecoilAssistMultiplier
	-- upvalues: (copy) v_u_19, (copy) v_u_15, (copy) v_u_5, (ref) v_u_17, (ref) v_u_18, (copy) v_u_9, (copy) v_u_16, (copy) v_u_11, (copy) v_u_110
	local v256 = v_u_19.RecoilAssist.Enabled
	if v256 then
		if v_u_15 or v_u_5.PreferredInput == Enum.PreferredInput.Touch then
			v256 = v_u_17
		elseif v_u_5.PreferredInput == Enum.PreferredInput.Gamepad then
			v256 = v_u_18
		else
			v256 = false
		end
		if v256 then
			v256 = not v_u_9.IsFlashed()
		end
	end
	if not v256 then
		return 0
	end
	if v_u_19.RecoilAssist.RequiresTarget then
		local v257
		if v_u_16 == nil then
			v257 = false
		else
			v257 = v_u_11.getLocalCharacter() ~= nil
		end
		if not (v257 and v_u_110(v_u_16.CFrame)) then
			return 0
		end
	end
	return v_u_19.RecoilAssist.ReductionAmount
end
function v_u_1.GetRecoilAssistScale() -- name: GetRecoilAssistScale
	-- upvalues: (copy) v_u_1, (copy) v_u_15, (copy) v_u_19
	local v258 = v_u_1.GetRecoilAssistMultiplier()
	if v258 <= 0 then
		return Vector3.new(1, 1, 1)
	end
	local v259
	if v_u_15 then
		local v260 = v_u_19.RecoilAssist.HorizontalReductionAmount
		v259 = math.max(v258, v260)
	else
		v259 = v258
	end
	local v261 = 1 - v258
	local v262 = 1 - v259
	return Vector3.new(v261, v262, 1)
end
local v_u_263 = false
function v_u_1.Initialize() -- name: Initialize
	-- upvalues: (ref) v_u_263, (copy) v_u_7, (copy) v_u_6, (ref) v_u_17, (ref) v_u_18
	if not v_u_263 then
		v_u_263 = true
		v_u_7.CreateListener(v_u_6, "Settings.Game.Other.Mobile Aim Assist", function(p264)
			-- upvalues: (ref) v_u_17
			v_u_17 = p264 ~= false
		end)
		v_u_7.CreateListener(v_u_6, "Settings.Game.Other.Controller Aim Assist", function(p265)
			-- upvalues: (ref) v_u_18
			v_u_18 = p265 ~= false
		end)
	end
end
return v_u_1
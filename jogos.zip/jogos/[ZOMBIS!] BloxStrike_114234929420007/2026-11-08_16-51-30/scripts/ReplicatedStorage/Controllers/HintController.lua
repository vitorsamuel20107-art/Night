-- NIGHT Analyzer | ReplicatedStorage.Controllers.HintController
-- ModuleScript | 13 linhas | 616 bytes | hash 4c63e588

local v1 = {}
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v4 = require(v3.Database.Security.Remotes)
local v5 = v3:WaitForChild("Assets"):WaitForChild("UI"):WaitForChild("Hints")
v5:WaitForChild("Static")
v5:WaitForChild("Ranged")
v2.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainGui", (1 / 0)):WaitForChild("Gameplay"):WaitForChild("Middle")
function v1.createHint(_, _, _, _, _, _) -- name: createHint end
function v1.clearHint(_, _) -- name: clearHint end
v4.Hints.BombSiteEntered.Listen(function() end)
v4.Hints.ClearHint.Listen(function() end)
return v1
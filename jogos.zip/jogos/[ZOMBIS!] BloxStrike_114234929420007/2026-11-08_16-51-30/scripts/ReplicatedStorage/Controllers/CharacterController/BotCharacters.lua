-- NIGHT Analyzer | ReplicatedStorage.Controllers.CharacterController.BotCharacters
-- ModuleScript | 811 linhas | 24231 bytes | hash 3795a5b3

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Workspace")
local v_u_3 = game:GetService("HttpService")
local v4 = v_u_1.Components.Common
local v_u_5 = require(v4.BotPresentationState)
local v_u_6 = require(v4.BotWeaponModel)
local v_u_7 = require(v4.BotWeaponEffects)
local v_u_8 = require(v4.BotWeaponRecoil)
local v_u_9 = require(v4.CharacterGeneration)
local v_u_10 = require(v4.CharacterPose)
local v_u_11 = require(v4.CharacterResolver)
local v_u_12 = require(v4.ClientCharacterPresentation)
local v_u_13 = require(v4.CharacterPresentationDescriptor)
local v_u_14 = require(v_u_1.Classes.Character.Classes.CharacterAnimator)
local v_u_15 = require(v_u_1.MovementV2.RootFrame)
local v_u_16 = require(v_u_1.MovementV2.RuntimeKinematics)
local v_u_17 = require(v_u_1.MovementV2.BotCombatCodec)
local v_u_18 = require(v_u_1.MovementV2.Transport)
local v_u_19 = require(v_u_1.Shared.Janitor)
local v20 = require(v_u_1.Packages.Signal)
local v_u_21 = require(v_u_1.Controllers.Observers.Character.Components.Defuser)
local v_u_22 = require(v_u_1.Classes.Ragdoll)
local v_u_23 = {
	["CombatEvent"] = v20.new()
}
local v_u_24 = {}
local v_u_25 = {}
local v_u_26 = {}
local v_u_27 = {}
local v_u_28 = {}
local v_u_29 = {}
local v_u_30 = {}
local v_u_31 = {}
local v_u_32 = {}
local v_u_33 = 0
local v_u_34 = false
local v_u_35 = nil
local v_u_36 = nil
local v_u_37 = {}
local v_u_38 = {}
local v_u_39 = {}
local function v_u_41(p40) -- name: destroyShell
	-- upvalues: (copy) v_u_6, (copy) v_u_16
	v_u_6.destroy(p40.Weapon)
	v_u_6.clear(p40.Shell)
	v_u_16.clear(p40.Shell)
	if p40.Defuser then
		p40.Defuser:Destroy()
	end
	p40.Animator:destroy()
	p40.Shell:Destroy()
end
local function v_u_45(p42, p43) -- name: releaseCorpseSource
	-- upvalues: (copy) v_u_38, (copy) v_u_41
	local v44 = v_u_38[p42]
	if v44 ~= nil and (p43 == nil or v44 == p43) then
		v_u_38[p42] = nil
		v_u_41(v44)
	end
end
local function v_u_47(p46) -- name: hide
	-- upvalues: (copy) v_u_13, (copy) v_u_16, (copy) v_u_12
	if p46.Visible then
		p46.Visible = false
		p46.Shell:SetAttribute(v_u_13.VisibleAttribute, false)
		p46.Animator:stopAnimations(0)
		v_u_16.clear(p46.Shell)
		p46.LastPosition = nil
	end
	p46.Shell.Parent = v_u_12.GetCulledFolder()
end
local function v_u_53(p48) -- name: retireToCorpse
	-- upvalues: (copy) v_u_13, (copy) v_u_16, (copy) v_u_6, (copy) v_u_47, (copy) v_u_37, (copy) v_u_41
	local v_u_49 = p48.Entry
	if v_u_49 ~= nil then
		p48.Entry = nil
		p48.CorpseGeneration = v_u_49.Descriptor.Generation
		v_u_49.Shell:SetAttribute("Health", 0)
		v_u_49.Shell:SetAttribute("Dead", true)
		if v_u_49.Visible then
			v_u_49.Shell:SetAttribute(v_u_13.VisibleAttribute, false)
			v_u_49.Animator:freezeAnimations()
			v_u_16.clear(v_u_49.Shell)
			for _, v50 in v_u_49.Shell:GetDescendants() do
				if not v50:IsA("BasePart") then
					continue
				end
				v50.CanQuery = false
			end
			task.delay(1.5, function()
				-- upvalues: (copy) v_u_49, (ref) v_u_6, (ref) v_u_47
				if v_u_49.Shell.Parent ~= nil then
					local v51 = v_u_49
					v_u_6.destroy(v51.Weapon)
					v_u_6.clear(v51.Shell)
					v51.Weapon = nil
					if v51.Defuser then
						v51.Defuser:Destroy()
						v51.Defuser = nil
					end
					v_u_47(v51)
				end
			end)
		else
			v_u_6.destroy(v_u_49.Weapon)
			v_u_6.clear(v_u_49.Shell)
			v_u_49.Weapon = nil
			if v_u_49.Defuser then
				v_u_49.Defuser:Destroy()
				v_u_49.Defuser = nil
			end
			v_u_47(v_u_49)
		end
		local v52 = v_u_37[v_u_49.Descriptor.CombatantId]
		if v52 then
			v_u_41(v52.Entry)
		end
		v_u_37[v_u_49.Descriptor.CombatantId] = {
			["Entry"] = v_u_49,
			["Generation"] = v_u_49.Descriptor.Generation,
			["ExpiresAt"] = os.clock() + 1.5
		}
	end
end
local function v_u_62(p54) -- name: readDescriptor
	-- upvalues: (copy) v_u_5
	local v55 = p54:GetAttribute("WeaponName")
	local v56 = p54:GetAttribute("WeaponRevision")
	local v57 = p54:GetAttribute("ObjectiveAction")
	local v58 = p54:GetAttribute("FlashedUntil")
	local v59 = {
		["BotLoadout"] = p54:GetAttribute("BotLoadout")
	}
	if type(v58) ~= "number" then
		v58 = nil
	end
	v59.FlashedUntil = v58
	v59.CombatantId = p54:GetAttribute("CombatantId")
	v59.ActorId = p54:GetAttribute("ActorId")
	v59.Generation = p54:GetAttribute("Generation")
	v59.DisplayName = p54:GetAttribute("DisplayName")
	v59.Team = p54:GetAttribute("Team")
	v59.CharacterName = p54:GetAttribute("CharacterName")
	v59.Health = p54:GetAttribute("Health")
	v59.MaxHealth = p54:GetAttribute("MaxHealth")
	v59.Dead = p54:GetAttribute("Dead")
	if v57 ~= "Planting" and v57 ~= "Defusing" then
		v57 = nil
	end
	v59.ObjectiveAction = v57
	v59.WeaponName = (type(v55) ~= "string" or #v55 > 48) and "" or v55
	v59.WeaponRevision = (type(v56) ~= "number" or (v56 < 0 or (v56 > 4294967295 or v56 % 1 ~= 0))) and 0 or v56
	if v_u_5.validate(v59) then
		local v60 = p54.Name
		local v61 = v59.CombatantId
		if v60 == tostring(v61) then
			return v59
		end
	end
	return nil
end
local function v_u_69(p63, p64) -- name: refresh
	-- upvalues: (copy) v_u_62, (copy) v_u_25, (copy) v_u_5, (copy) v_u_53, (copy) v_u_41
	local v65 = v_u_62(p63)
	local v66 = p64.Descriptor
	if v66 ~= nil and v_u_25[v66.ActorId] == p64 then
		v_u_25[v66.ActorId] = nil
	end
	if v65 ~= nil then
		v_u_25[v65.ActorId] = p64
		if v66 == nil or not v_u_5.sameLife(v66, v65) then
			p64.LastEventSequence = nil
		end
	end
	local v67 = p64.Entry
	if v67 ~= nil then
		if v65 == nil or (not v_u_5.sameLife(v67.Descriptor, v65) or (v67.Descriptor.CharacterName ~= v65.CharacterName or (v67.Descriptor.BotLoadout ~= v65.BotLoadout or v_u_5.decide(v65, nil) == "Destroy"))) then
			if p64.Entry == nil or (v65 == nil or not v65.Dead and v65.Health > 0) then
				local v68 = p64.Entry
				if v68 ~= nil then
					p64.Entry = nil
					v_u_41(v68)
				end
			else
				v_u_53(p64)
			end
		else
			v67.Descriptor = v65
			v67.Shell.Name = v65.DisplayName
			v67.Shell:SetAttribute("Team", v65.Team)
			v67.Shell:SetAttribute("Health", v65.Health)
			v67.Shell:SetAttribute("MaxHealth", v65.MaxHealth)
		end
	end
	if v66 ~= nil and (v65 == nil or not v_u_5.sameLife(v66, v65)) then
		p64.LastDescriptor = v66
	end
	p64.Descriptor = v65
end
local function v_u_74(p70) -- name: untrack
	-- upvalues: (copy) v_u_24, (copy) v_u_25, (copy) v_u_41
	local v71 = v_u_24[p70]
	if v71 ~= nil then
		v_u_24[p70] = nil
		local v72 = v71.Descriptor
		if v72 ~= nil and v_u_25[v72.ActorId] == v71 then
			v_u_25[v72.ActorId] = nil
		end
		v71.Descriptor = nil
		v71.Janitor:Destroy()
		local v73 = v71.Entry
		if v73 ~= nil then
			v71.Entry = nil
			v_u_41(v73)
		end
	end
end
local function v_u_77(p_u_75) -- name: track
	-- upvalues: (copy) v_u_24, (copy) v_u_19, (copy) v_u_69
	if p_u_75:IsA("Folder") and v_u_24[p_u_75] == nil then
		local v_u_76 = {
			["Folder"] = nil,
			["Descriptor"] = nil,
			["Entry"] = nil,
			["Janitor"] = nil,
			["LastEventSequence"] = nil,
			["Folder"] = p_u_75,
			["Janitor"] = v_u_19.new()
		}
		v_u_24[p_u_75] = v_u_76
		v_u_76.Janitor:Add(p_u_75.AttributeChanged:Connect(function()
			-- upvalues: (ref) v_u_69, (copy) p_u_75, (copy) v_u_76
			v_u_69(p_u_75, v_u_76)
		end))
		v_u_69(p_u_75, v_u_76)
	end
end
local function v_u_88(p_u_78) -- name: bindFolder
	-- upvalues: (ref) v_u_36, (ref) v_u_35, (copy) v_u_24, (copy) v_u_25, (copy) v_u_41, (copy) v_u_19, (copy) v_u_77, (copy) v_u_74, (copy) v_u_1
	if p_u_78 ~= v_u_36 and p_u_78:IsA("Folder") then
		if v_u_35 ~= nil then
			v_u_35:Destroy()
		end
		for v79 in v_u_24 do
			local v80 = v_u_24[v79]
			if v80 == nil then
				continue
			end
			v_u_24[v79] = nil
			local v81 = v80.Descriptor
			if v81 ~= nil and v_u_25[v81.ActorId] == v80 then
				v_u_25[v81.ActorId] = nil
			end
			v80.Descriptor = nil
			v80.Janitor:Destroy()
			local v82 = v80.Entry
			if v82 == nil then
				continue
			end
			v80.Entry = nil
			v_u_41(v82)
		end
		v_u_36 = p_u_78
		v_u_35 = v_u_19.new()
		v_u_35:Add(p_u_78.ChildAdded:Connect(v_u_77))
		v_u_35:Add(p_u_78.ChildRemoved:Connect(v_u_74))
		v_u_35:Add(p_u_78.AncestryChanged:Connect(function()
			-- upvalues: (copy) p_u_78, (ref) v_u_1, (ref) v_u_24, (ref) v_u_25, (ref) v_u_41, (ref) v_u_36, (ref) v_u_35
			if p_u_78.Parent ~= v_u_1 then
				for v83 in v_u_24 do
					local v84 = v_u_24[v83]
					if v84 == nil then
						continue
					end
					v_u_24[v83] = nil
					local v85 = v84.Descriptor
					if v85 ~= nil and v_u_25[v85.ActorId] == v84 then
						v_u_25[v85.ActorId] = nil
					end
					v84.Descriptor = nil
					v84.Janitor:Destroy()
					local v86 = v84.Entry
					if v86 == nil then
						continue
					end
					v84.Entry = nil
					v_u_41(v86)
				end
				v_u_36 = nil
				v_u_35:Destroy()
				v_u_35 = nil
			end
		end))
		for _, v87 in p_u_78:GetChildren() do
			v_u_77(v87)
		end
	end
end
function v_u_23.Initialize() -- name: Initialize
	-- upvalues: (ref) v_u_34, (copy) v_u_18, (copy) v_u_17, (copy) v_u_23, (copy) v_u_1, (copy) v_u_88
	if not v_u_34 then
		v_u_34 = true
		v_u_18.getClientChannels().BotCombat.OnClientEvent:Connect(function(p89)
			-- upvalues: (ref) v_u_17, (ref) v_u_23
			local v90 = v_u_17.decode(p89)
			if v90 ~= nil then
				v_u_23.PresentCombatEvents(v90)
			end
		end)
		v_u_1.ChildAdded:Connect(function(p91)
			-- upvalues: (ref) v_u_88
			if p91.Name == "Combatants" then
				v_u_88(p91)
			end
		end)
		local v92 = v_u_1:FindFirstChild("Combatants")
		if v92 ~= nil then
			v_u_88(v92)
		end
	end
end
local function v_u_95(p93) -- name: poseRootCFrame
	-- upvalues: (copy) v_u_15, (copy) v_u_10
	local v94 = p93.VisualRootPosition or v_u_15.simulationToVisualRootPosition(p93.Position, p93.DuckAmount)
	return v_u_10.composeRootCFrame(v94, p93.LookYaw)
end
local function v_u_111(p96, p_u_97, p98) -- name: createEntry
	-- upvalues: (copy) v_u_1, (copy) v_u_13, (copy) v_u_9, (copy) v_u_12, (copy) v_u_3, (copy) v_u_11, (copy) v_u_2, (copy) v_u_22, (copy) v_u_10, (copy) v_u_14, (copy) v_u_21
	local v99 = v_u_1:FindFirstChild("Assets")
	local v100
	if v99 == nil then
		v100 = nil
	else
		v100 = v99:FindFirstChild("Characters")
	end
	local v101
	if v100 == nil then
		v101 = nil
	else
		v101 = v100:FindFirstChild(p_u_97.CharacterName)
	end
	if v101 == nil or not v101:IsA("Model") then
		return nil
	end
	local v_u_102 = v101:Clone()
	v_u_102.Name = p_u_97.DisplayName
	v_u_102:SetAttribute("CharacterType", "PlayerCustomCharacter")
	v_u_102:SetAttribute("CharacterName", p_u_97.CharacterName)
	v_u_102:SetAttribute("Bot", true)
	v_u_102:SetAttribute("CombatantId", p_u_97.CombatantId)
	v_u_102:SetAttribute("ActorId", p_u_97.ActorId)
	v_u_102:SetAttribute("Team", p_u_97.Team)
	v_u_102:SetAttribute("Health", p_u_97.Health)
	v_u_102:SetAttribute("MaxHealth", p_u_97.MaxHealth)
	v_u_102:SetAttribute("Dead", false)
	v_u_102:SetAttribute(v_u_13.OwnedAttribute, true)
	v_u_102:SetAttribute(v_u_13.VisibleAttribute, true)
	v_u_9.Set(v_u_102, p_u_97.Generation)
	v_u_12.PrepareRuntimeRig(v_u_102)
	if p_u_97.BotLoadout then
		local v103 = v_u_3:JSONDecode(p_u_97.BotLoadout)
		v_u_102:SetAttribute("BotLoadout", p_u_97.BotLoadout)
		if v103.Gloves then
			local v104 = v103.Gloves
			v_u_102:SetAttribute("EquippedGloves", v_u_3:JSONEncode(v104))
			local v105 = require(v_u_1.Database.Components.Libraries.Skins).GetCharacterGloves(v104.Name, v104.Skin, v104.Float)
			if v105 then
				require(v_u_1.Database.Components.Common.AttachGlovesToCharacter)(v105:GetChildren(), v_u_102, v_u_102:FindFirstChild("CharacterArmor") or v_u_102)
				v105:Destroy()
			end
		end
	end
	local v106 = v_u_11.resolve(v_u_102)
	if v106 == nil then
		v_u_102:Destroy()
		return nil
	end
	v_u_102:PivotTo(p98 * v106.RootPart.CFrame:ToObjectSpace(v_u_102:GetPivot()))
	v_u_102.Parent = v_u_2:FindFirstChild("Characters") or v_u_2
	task.spawn(function()
		-- upvalues: (copy) v_u_102, (ref) v_u_22, (copy) p_u_97
		if v_u_102:IsDescendantOf(game) and v_u_102:GetAttribute("Dead") ~= true then
			local v107 = v_u_22.PrepareCharacter
			local v108 = v_u_102
			local v109, v110 = pcall(v107, v108)
			if not v109 then
				warn((("[BotCharacters] Ragdoll preparation failed for %*: %*"):format(p_u_97.DisplayName, v110)))
			end
		end
	end)
	return {
		["Descriptor"] = nil,
		["Shell"] = nil,
		["Root"] = nil,
		["Joints"] = nil,
		["Animator"] = nil,
		["Visible"] = true,
		["LastPosition"] = nil,
		["LastAnimationAt"] = (-1 / 0),
		["Weapon"] = nil,
		["Defuser"] = nil,
		["Descriptor"] = p_u_97,
		["Shell"] = v_u_102,
		["Root"] = v106.RootPart,
		["Joints"] = v_u_10.getJoints(v_u_102),
		["Animator"] = v_u_14.new(v_u_102),
		["Defuser"] = v_u_21.new(p96, v_u_102)
	}
end
local function v_u_122(p112, p113) -- name: syncWeapon
	-- upvalues: (copy) v_u_6, (copy) v_u_8
	local v114 = p113.WeaponName or ""
	local v115 = p112.Weapon
	local v116
	if v114 == "" then
		v116 = v115 ~= nil
	else
		v116 = (v115 == nil or v115.Name ~= v114) and true or v115.Revision ~= (p113.WeaponRevision or 0)
	end
	if v116 then
		local v117 = p113.WeaponName or ""
		local v118
		if p112.Weapon == nil then
			v118 = false
		else
			v118 = p112.Weapon.Name ~= v117
		end
		v_u_6.stow(p112.Shell, p112.Weapon)
		p112.Weapon = nil
		p112.Recoil = nil
		p112.Animator:setWeapon(nil, nil, false)
		if v117 ~= "" then
			local v119 = v_u_6.attach(p112.Shell, v117, p113.WeaponRevision or 0)
			if v119 ~= nil then
				p112.Weapon = v119
				p112.Recoil = v_u_8.new(v117)
				local v120 = p112.Animator
				local v121 = v119.Revision
				v120:setWeapon(v117, tostring(v121), v118)
			end
		end
	else
		return
	end
end
function v_u_23.PresentCombatEvents(p123) -- name: PresentCombatEvents
	-- upvalues: (copy) v_u_2, (copy) v_u_25, (copy) v_u_17, (ref) v_u_39, (copy) v_u_5, (copy) v_u_9, (copy) v_u_23, (copy) v_u_7
	local v124 = v_u_2:GetServerTimeNow()
	for _, v125 in p123 do
		local v126 = v_u_25[v125.ActorId]
		local v127
		if v126 then
			v127 = v126.Entry
		else
			v127 = nil
		end
		local v128
		if v126 then
			v128 = v126.Descriptor
		else
			v128 = nil
		end
		if v126 == nil or (v127 == nil or v128 == nil) then
			continue
		end
		local v129 = v127.Weapon
		local v130
		if v128.WeaponName == v125.WeaponName and (v128.WeaponRevision == v125.WeaponRevision and (v129 ~= nil and v129.Name == v125.WeaponName)) then
			v130 = v129.Revision == v125.WeaponRevision
		else
			v130 = false
		end
		local v131
		if (v125.WeaponRevision or 0) > (v128.WeaponRevision or 0) then
			v131 = true
		elseif v128.WeaponName == v125.WeaponName then
			v131 = v128.WeaponRevision == v125.WeaponRevision
		else
			v131 = false
		end
		if v130 or (not v131 or (v125.ActorId ~= v128.ActorId or (v125.Generation ~= v128.Generation or v124 - v125.ServerTime > v_u_17.MaxEventAgeSeconds))) then
			if not v130 or (not v_u_17.canPresent(v125, v128, v127.Visible, v126.LastEventSequence, v124) or (not v127.Shell:IsDescendantOf(v_u_2) or (not v_u_5.sameLife(v127.Descriptor, v128) or v_u_9.Get(v127.Shell) ~= v125.Generation))) then
				continue
			end
			v126.LastEventSequence = v125.Sequence
			v_u_23.CombatEvent:Fire(v125)
			v127.Animator:playAction(v125.Kind)
			if v125.Kind == "Shoot" and v125.Target ~= nil then
				if v127.Recoil then
					v127.Recoil:OnShot(v124)
				end
				v_u_7.shoot(v129, v125.Target, v125.Sequence, v127.Shell:GetAttribute("SpectatedFirstPerson") == true)
			else
				if v125.Kind ~= "Reload" then
					continue
				end
				v_u_7.reloadSound(v129, v127.Root, v127.Shell:GetAttribute("SpectatedFirstPerson") == true)
			end
		else
			v_u_39[v126] = v125
		end
	end
end
function v_u_23.GetEquipment(p132, p133) -- name: GetEquipment
	-- upvalues: (copy) v_u_25, (copy) v_u_3
	local v134 = v_u_25[p132]
	local v135
	if v134 then
		v135 = v134.Entry
	else
		v135 = nil
	end
	if not v135 or (not v135.Visible or v135.Descriptor.Generation ~= p133) then
		return nil
	end
	local v136 = v135.Weapon
	if not v136 then
		return nil
	end
	local v137 = v135.Descriptor.BotLoadout
	if v137 then
		v137 = v_u_3:JSONDecode(v135.Descriptor.BotLoadout)
	end
	if v137 then
		v137 = v137.Weapons[v136.Name]
	end
	return {
		["Name"] = v136.Name,
		["Revision"] = v136.Revision,
		["Skin"] = not v137 and "Stock" or v137.Skin,
		["Float"] = not v137 and 0 or v137.Float
	}
end
function v_u_23.GetRecoil(p138, p139) -- name: GetRecoil
	-- upvalues: (copy) v_u_25, (copy) v_u_2
	local v140 = v_u_25[p138]
	local v141
	if v140 then
		v141 = v140.Entry
	else
		v141 = nil
	end
	if v141 and (v141.Visible and (v141.Weapon and (v141.Recoil and v141.Descriptor.Generation == p139))) then
		return v141.Recoil:Step(v_u_2:GetServerTimeNow())
	else
		return Vector2.zero
	end
end
local function v_u_146(p142, p143, p144) -- name: lifeDescriptor
	for _, v145 in { p142.Descriptor, p142.LastDescriptor } do
		if not v145 or (v145.CombatantId ~= p143 or v145.Generation ~= p144) then
			continue
		end
		return v145
	end
	return nil
end
function v_u_23.TakeCorpse(p147, p148, p149, p150) -- name: TakeCorpse
	-- upvalues: (copy) v_u_37, (copy) v_u_24, (copy) v_u_146, (copy) v_u_111, (copy) v_u_10, (copy) v_u_53, (copy) v_u_38, (copy) v_u_41, (copy) v_u_45
	local v151 = v_u_37[p147]
	if v151 == nil or v151.Generation ~= p148 then
		for _, v152 in v_u_24 do
			local v153 = v_u_146(v152, p147, p148)
			if not v153 or v152.CorpseGeneration == p148 then
				continue
			end
			local v154 = v152.Entry
			if v154 == nil or v154.Descriptor.Generation ~= p148 then
				v152.Entry = v_u_111(v152.Folder, v153, v_u_10.composeRootCFrame(p149, p150))
				v_u_53(v152)
				v152.Entry = v154
			else
				v_u_53(v152)
			end
			v151 = v_u_37[p147]
		end
	end
	if v151 == nil or v151.Generation ~= p148 then
		return nil
	end
	v_u_37[p147] = nil
	local v155 = v151.Entry
	local v156 = v_u_38[p147]
	if v156 ~= nil then
		v_u_38[p147] = nil
		v_u_41(v156)
	end
	v_u_38[p147] = v155
	task.delay(30, v_u_45, p147, v155)
	return v155.Shell
end
function v_u_23.GetCamera(p157, p158) -- name: GetCamera
	-- upvalues: (copy) v_u_25, (copy) v_u_26, (copy) v_u_11, (copy) v_u_23
	local v159 = v_u_25[p157]
	local v160
	if v159 then
		v160 = v159.Entry
	else
		v160 = nil
	end
	local v161 = v_u_26[p157]
	if not v160 or (not v160.Visible or (not v161 or v160.Descriptor.Generation ~= p158)) then
		return nil
	end
	local v162 = v_u_11.getCameraPart(v160.Shell)
	if not v162 then
		return nil
	end
	local v163 = v161.RenderPose
	if v163 == nil then
		return nil
	end
	local v164 = v_u_23.GetRecoil(p157, p158)
	local v165 = v163.VerticalLook
	local v166 = math.clamp(v165, -1, 1)
	local v167 = math.asin(v166)
	return CFrame.new(v162.Position) * CFrame.Angles(0, v163.LookYaw + v164.X, 0) * CFrame.Angles(v167 + v164.Y, 0, 0)
end
function v_u_23.Present(p168) -- name: Present
	-- upvalues: (copy) v_u_23, (copy) v_u_37, (copy) v_u_41, (copy) v_u_26, (copy) v_u_27, (copy) v_u_28, (copy) v_u_29, (copy) v_u_30, (copy) v_u_31, (copy) v_u_32, (copy) v_u_24, (copy) v_u_5, (copy) v_u_53, (copy) v_u_47, (copy) v_u_15, (copy) v_u_10, (ref) v_u_33, (copy) v_u_38, (copy) v_u_111, (copy) v_u_95, (copy) v_u_122, (copy) v_u_2, (copy) v_u_13, (copy) v_u_16, (ref) v_u_39
	v_u_23.Initialize()
	local v169 = os.clock()
	for v170, v171 in v_u_37 do
		if v171.ExpiresAt > v169 then
			continue
		end
		v_u_37[v170] = nil
		v_u_41(v171.Entry)
	end
	table.clear(v_u_26)
	table.clear(v_u_27)
	table.clear(v_u_28)
	table.clear(v_u_29)
	table.clear(v_u_30)
	table.clear(v_u_31)
	table.clear(v_u_32)
	for _, v172 in p168 do
		if v172.UserId ~= 0 then
			continue
		end
		v_u_26[v172.ActorId] = v172
	end
	for _, v173 in v_u_24 do
		local v174 = v173.Descriptor
		local v175
		if v174 == nil then
			v175 = nil
		else
			v175 = v_u_26[v174.ActorId]
		end
		local v176 = v_u_5.decide(v174, v175)
		v173.LastDecision = v176
		local v177 = v173.Entry
		if v176 == "Destroy" then
			if v173.Entry == nil or (v174 == nil or not v174.Dead and v174.Health > 0) then
				local v178 = v173.Entry
				if v178 == nil then
					continue
				end
				v173.Entry = nil
				v_u_41(v178)
			else
				v_u_53(v173)
			end
		elseif v176 == "Hide" then
			if v177 == nil then
				continue
			end
			v_u_47(v177)
		else
			if v176 ~= "Present" then
				continue
			end
			if v177 ~= nil then
				local v179 = v175.RenderPose
				local v180 = v179.VisualRootPosition or v_u_15.simulationToVisualRootPosition(v179.Position, v179.DuckAmount)
				local v181 = v_u_10.composeRootCFrame(v180, v179.LookYaw)
				if v177.Root.CFrame ~= v181 then
					v_u_27[#v_u_27 + 1] = v177.Root
					v_u_28[#v_u_28 + 1] = v181
				end
				v_u_29[#v_u_29 + 1] = v177
				v_u_30[#v_u_30 + 1] = v179
			end
			if v177 ~= nil then
				local v182 = v174.WeaponName or ""
				local v183 = v177.Weapon
				local v184
				if v182 == "" then
					v184 = v183 ~= nil
				else
					v184 = (v183 == nil or v183.Name ~= v182) and true or v183.Revision ~= (v174.WeaponRevision or 0)
				end
				if not v184 then
					continue
				end
			end
			v_u_31[#v_u_31 + 1] = v173
			v_u_32[#v_u_32 + 1] = v175
		end
	end
	local v185 = #v_u_31
	if v185 > 0 then
		local v186 = v_u_33 % v185
		local v187 = math.min(2, v185)
		for v188 = 1, v187 do
			local v189 = (v186 + v188 - 1) % v185 + 1
			local v190 = v_u_31[v189]
			local v191 = v_u_32[v189]
			local v192 = v190.Descriptor
			if v_u_5.decide(v192, v191) ~= "Present" or v192 and v190.CorpseGeneration == v192.Generation then
				continue
			end
			local v193 = v190.Entry
			local v194 = v193 == nil
			if v194 then
				local v195 = v_u_38[v192.CombatantId]
				if v195 and v195.Descriptor.Generation ~= v192.Generation then
					local v196 = v192.CombatantId
					local v197 = v_u_38[v196]
					if v197 ~= nil then
						v_u_38[v196] = nil
						v_u_41(v197)
					end
				end
				v193 = v_u_111(v190.Folder, v192, v_u_95(v191.RenderPose))
				v190.Entry = v193
			end
			if v193 == nil then
				continue
			end
			v_u_122(v193, v192)
			if not v194 then
				continue
			end
			local v198 = v191.RenderPose
			local v199 = v198.VisualRootPosition or v_u_15.simulationToVisualRootPosition(v198.Position, v198.DuckAmount)
			local v200 = v_u_10.composeRootCFrame(v199, v198.LookYaw)
			if v193.Root.CFrame ~= v200 then
				v_u_27[#v_u_27 + 1] = v193.Root
				v_u_28[#v_u_28 + 1] = v200
			end
			v_u_29[#v_u_29 + 1] = v193
			v_u_30[#v_u_30 + 1] = v198
		end
		v_u_33 = (v186 + v187) % v185
	end
	if #v_u_27 == 1 then
		v_u_27[1].CFrame = v_u_28[1]
	elseif #v_u_27 > 1 then
		v_u_2:BulkMoveTo(v_u_27, v_u_28, Enum.BulkMoveMode.FireCFrameChanged)
	end
	local v201 = os.clock()
	local v202 = v_u_2:GetServerTimeNow()
	for v203, v204 in v_u_29 do
		local v205 = v_u_30[v203]
		local v206 = v204.Visible
		if not v206 then
			v204.ObjectiveAction = nil
			v204.Visible = true
			v204.Shell.Parent = v_u_2:FindFirstChild("Characters") or v_u_2
			v204.Shell:SetAttribute(v_u_13.VisibleAttribute, true)
			if v204.Weapon ~= nil then
				local v207 = v204.Animator
				local v208 = v204.Weapon.Name
				local v209 = v204.Weapon.Revision
				v207:setWeapon(v208, tostring(v209), false)
			end
		end
		local v210 = v204.Descriptor.ObjectiveAction
		if v204.ObjectiveAction ~= v210 then
			if v210 == "Planting" then
				if v204.Weapon and v204.Weapon.Name == "C4" then
					v204.Animator:playAction("Use")
					v204.ObjectiveAction = v210
				end
			else
				if v204.ObjectiveAction == "Planting" and (v204.Weapon and v204.Weapon.Name == "C4") then
					v204.Animator:playAction("Cancel Plant")
				end
				v204.ObjectiveAction = v210
			end
		end
		local v211
		if v204.LastPosition == nil then
			v211 = false
		else
			v211 = (v205.Position - v204.LastPosition).Magnitude > 0.00001
		end
		local v212 = not v211 and Vector3.new(0, 0, 0) or v205.Velocity
		v_u_16.write(v204.Shell, v212, v205.OnGround)
		v204.LastPosition = v205.Position
		if v206 and v201 - v204.LastAnimationAt < 0.016666666666666666 then
			continue
		end
		v204.Animator:updateLocomotion(v212, v205.OnGround, v205.DuckAmount > 0.5, v205.MovementMode == "Ladder")
		if v204.Joints ~= nil then
			v_u_10.applyVerticalLook(v204.Joints, v205.VerticalLook, 0.003)
		end
		v204.Animator:setBlinded(v202 < (v204.Descriptor.FlashedUntil or 0))
		v204.LastAnimationAt = v201
	end
	if next(v_u_39) ~= nil then
		local v213 = v_u_39
		v_u_39 = {}
		for _, v214 in v213 do
			v_u_23.PresentCombatEvents({ v214 })
		end
	end
end
return v_u_23
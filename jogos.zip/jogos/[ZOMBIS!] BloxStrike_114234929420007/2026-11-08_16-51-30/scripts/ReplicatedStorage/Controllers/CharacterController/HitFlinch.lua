-- NIGHT Analyzer | ReplicatedStorage.Controllers.CharacterController.HitFlinch
-- ModuleScript | 118 linhas | 3075 bytes | hash 81640706

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Controllers.RunServiceController)
local v3 = {}
local v_u_4 = {}
local function v_u_9(p5) -- name: findNeckMotor
	local v6 = p5:FindFirstChild("UpperTorso")
	local v7
	if v6 then
		v7 = v6:FindFirstChild("Head")
	else
		v7 = nil
	end
	if v7 and v7:IsA("Motor6D") then
		return v7
	else
		local v8 = p5:FindFirstChild("Neck", true)
		if v8 and v8:IsA("Motor6D") then
			return v8
		else
			return nil
		end
	end
end
local function v_u_21(p10, p11) -- name: armFlinch
	-- upvalues: (copy) v_u_4, (copy) v_u_9
	local v12 = v_u_4[p10]
	if not (v12 and v12.Neck.Parent) then
		local v13 = v_u_9(p10)
		if not v13 then
			warn((("[HitFlinch] No neck Motor6D found on %*; hit flinch skipped"):format((p10:GetFullName()))))
			return nil
		end
		local v14 = p10:FindFirstChild("Waist", true)
		if not (v14 and v14:IsA("Motor6D")) then
			v14 = nil
		end
		v12 = {
			["Neck"] = nil,
			["BaseC1"] = nil,
			["Waist"] = nil,
			["WaistBaseC1"] = nil,
			["HeadPitch"] = 0,
			["BodyPitch"] = 0,
			["Neck"] = v13,
			["BaseC1"] = v13.C1,
			["Waist"] = v14
		}
		if v14 then
			v14 = v14.C1
		end
		v12.WaistBaseC1 = v14
		v_u_4[p10] = v12
	end
	local v15 = v12.Neck.Part1
	local v16 = not (p11 and v15) and Vector3.new(0, 0, 1) or v15.CFrame:VectorToObjectSpace(p11)
	local v17 = v16.X
	local v18 = v16.Z
	local v19 = Vector3.new(v17, 0, v18)
	v12.Axis = v19.Magnitude <= 0.01 and Vector3.new(1, 0, 0) or (Vector3.new(0, 1, 0)):Cross(v19.Unit)
	local v20
	if v15 then
		v20 = CFrame.new(0, -v15.Size.Y / 2, 0)
	else
		v20 = CFrame.identity
	end
	v12.Pivot = v20
	return v12
end
function v3.flickHead(p22, p23) -- name: flickHead
	-- upvalues: (copy) v_u_21
	local v24 = v_u_21(p22, p23)
	if v24 then
		local v25 = v24.HeadPitch + 1.2217304763960306
		v24.HeadPitch = math.min(1.5707963267948966, v25)
	end
end
function v3.flinchBody(p26, p27) -- name: flinchBody
	-- upvalues: (copy) v_u_21
	local v28 = v_u_21(p26, p27)
	if v28 then
		local v29 = v28.BodyPitch + 0.24434609527920614
		v28.BodyPitch = math.min(0.4363323129985824, v29)
	end
end
v2.BindToRenderStep("CharacterController.HitFlinch.Update", function(p30)
	-- upvalues: (copy) v_u_4
	local v31 = p30 * -12
	local v32 = math.exp(v31)
	for v33, v34 in pairs(v_u_4) do
		local v35 = v34.Neck
		if v35.Parent then
			if v34.HeadPitch <= 0 and v34.BodyPitch <= 0 then
				continue
			end
			v34.HeadPitch = v34.HeadPitch * v32
			v34.BodyPitch = v34.BodyPitch * v32
			if v34.HeadPitch + v34.BodyPitch <= 0.008726646259971648 then
				v35.C1 = v34.BaseC1
				if v34.Waist then
					v34.Waist.C1 = v34.WaistBaseC1
				end
				v34.HeadPitch = 0
				v34.BodyPitch = 0
			else
				local v36 = v34.HeadPitch + v34.BodyPitch * 0.5
				local v37 = v34.HeadPitch * 0.3 + v34.BodyPitch
				v35.C1 = v34.Pivot * CFrame.fromAxisAngle(v34.Axis, -v36) * v34.Pivot:Inverse() * v34.BaseC1
				if not v34.Waist then
					continue
				end
				v34.Waist.C1 = v34.WaistBaseC1 * CFrame.fromAxisAngle(v34.Axis, -v37)
			end
		else
			v_u_4[v33] = nil
		end
	end
end)
return v3
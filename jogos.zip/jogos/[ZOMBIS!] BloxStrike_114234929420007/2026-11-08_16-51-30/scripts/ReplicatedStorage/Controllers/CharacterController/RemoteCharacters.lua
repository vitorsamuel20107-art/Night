-- NIGHT Analyzer | ReplicatedStorage.Controllers.CharacterController.RemoteCharacters
-- ModuleScript | 695 linhas | 21597 bytes | hash 52c3b75d

local v_u_1 = game:GetService("HttpService")
local v_u_2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(v3.Classes.Character.Classes.CharacterAnimator)
local v_u_6 = require(v3.Classes.Ragdoll)
local v_u_7 = require(v3.Database.Components.CharacterActions)
local v_u_8 = require(v3.Database.Security.Remotes)
local v_u_9 = require(v3.Components.Common.CharacterGeneration)
local v_u_10 = require(v3.Components.Common.ClientCharacterPresentation)
local v_u_11 = require(v3.Components.Common.CharacterPresentationDescriptor)
local v_u_12 = require(v3.Components.Common.CharacterPose)
local v_u_13 = require(v3.Components.Common.SurvivalDowned)
local v_u_14 = require(v3.Components.Common.CharacterResolver)
local v_u_15 = require(v3.MovementV2.RootFrame)
local v_u_16 = require(v3.MovementV2.RuntimeKinematics)
local v_u_17 = require(v3.Shared.Janitor)
local v_u_18 = require(script.Parent.BotCharacters)
local v_u_19 = v_u_2.LocalPlayer
local v_u_20 = {}
local v_u_21 = {}
local v_u_22 = {}
local v_u_23 = {}
local v_u_24 = false
local v_u_25 = 0
local v_u_26 = {}
local v_u_27 = {}
local v_u_28 = {}
local v_u_29 = {}
local v_u_30 = nil
local v_u_31 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_34(p32) -- name: restoreEntryParent
	-- upvalues: (copy) v_u_10, (copy) v_u_4
	if p32.Shell.Parent == v_u_10.GetCulledFolder() then
		local v33 = p32.VisibleParent
		if v33 == nil or (v33 == v_u_10.GetCulledFolder() or not v33:IsDescendantOf(game)) then
			v33 = v_u_4:FindFirstChild("Characters") or v_u_4
			p32.VisibleParent = v33
		end
		p32.Shell.Parent = v33
	end
end
local function v_u_45(p35) -- name: decodeCurrentEquipped
	-- upvalues: (copy) v_u_1
	local v36 = p35:GetAttribute("CurrentEquipped")
	if typeof(v36) ~= "string" or v36 == "" then
		return nil, nil
	end
	local v37 = v_u_1.JSONDecode
	local v38 = v_u_1
	local v39, v40 = pcall(v37, v38, v36)
	if not v39 or typeof(v40) ~= "table" then
		return nil, nil
	end
	local v41 = v40.Name
	local v42
	if typeof(v41) == "string" then
		v42 = v40.Name
	else
		v42 = nil
	end
	local v43 = v40.Identifier
	local v44
	if typeof(v43) == "string" then
		v44 = v40.Identifier
	else
		v44 = nil
	end
	return v42, v44
end
local function v_u_55(p46, p47) -- name: setEntryVisible
	-- upvalues: (ref) v_u_30, (copy) v_u_16, (copy) v_u_10, (copy) v_u_34, (copy) v_u_11, (copy) v_u_45
	local v48 = p46.Player == v_u_30 and (p46.Visible and p46.Shell:GetAttribute("Dead") ~= true) and true or p47
	if p46.Visible == v48 then
		if v48 then
			v_u_34(p46)
		else
			v_u_16.clear(p46.Shell)
			local v49 = v_u_10.GetCulledFolder()
			local v50 = p46.Shell.Parent
			if v50 ~= nil and v50 ~= v49 then
				p46.VisibleParent = v50
			end
			if p46.Shell.Parent ~= v49 then
				p46.Shell.Parent = v49
				return
			end
		end
		return
	else
		p46.Visible = v48
		if v48 then
			v_u_34(p46)
			p46.Shell:SetAttribute(v_u_11.VisibleAttribute, true)
			if p46.Visible then
				local v51, v52 = v_u_45(p46.Player)
				p46.Animator:setWeapon(v51, v52, false)
			end
		else
			p46.Shell:SetAttribute(v_u_11.VisibleAttribute, false)
			p46.Animator:stopAnimations(0)
			v_u_16.clear(p46.Shell)
			local v53 = v_u_10.GetCulledFolder()
			local v54 = p46.Shell.Parent
			if v54 ~= nil and v54 ~= v53 then
				p46.VisibleParent = v54
			end
			if p46.Shell.Parent ~= v53 then
				p46.Shell.Parent = v53
			end
			return
		end
	end
end
function v_u_20.SetPinnedPlayer(p56) -- name: SetPinnedPlayer
	-- upvalues: (ref) v_u_30
	v_u_30 = p56
end
function v_u_20.GetCamera(p57) -- name: GetCamera
	-- upvalues: (copy) v_u_21, (copy) v_u_14, (copy) v_u_13
	local v58 = v_u_21[p57]
	if v58 == nil or (not v58.Visible or v58.LookYaw == nil) then
		return nil
	end
	local v59 = v_u_14.getCameraPart(v58.Shell)
	if v59 == nil then
		return nil
	end
	local v60 = v58.VerticalLook or 0
	local v61 = math.clamp(v60, -1, 1)
	local v62 = math.asin(v61)
	local v63
	if v_u_13.IsDowned(p57) then
		local v64 = v59.Position
		local v65 = v_u_13.EYE_DROP
		v63 = v64 - Vector3.new(0, v65, 0)
	else
		v63 = v59.Position
	end
	return CFrame.new(v63) * CFrame.Angles(0, v58.LookYaw, 0) * CFrame.Angles(v62, 0, 0)
end
function v_u_20.GetShell(p66) -- name: GetShell
	-- upvalues: (copy) v_u_21
	local v67 = v_u_21[p66]
	if v67 == nil or not v67.Visible then
		return nil
	else
		return v67.Shell
	end
end
local function v_u_77(p68) -- name: retireDeadEntry
	-- upvalues: (copy) v_u_55, (copy) v_u_21, (copy) v_u_22, (copy) v_u_16, (copy) v_u_11, (copy) v_u_31, (copy) v_u_10
	local v69 = p68.Player
	local v_u_70 = p68.Shell
	if p68.Visible and v_u_70.Parent ~= nil then
		local v_u_71 = p68.Animator
		v_u_71:freezeAnimations()
		v_u_16.clear(v_u_70)
		v_u_70:SetAttribute(v_u_11.VisibleAttribute, false)
		for _, v72 in v_u_70:GetDescendants() do
			if not v72:IsA("BasePart") then
				continue
			end
			v72.CanQuery = false
		end
		v_u_31[v_u_70] = v_u_71
		p68.RetainAnimator = true
		local v73 = v_u_21[v69]
		if v73 ~= nil then
			v_u_21[v69] = nil
			if v_u_22[v69.UserId] == v73 then
				v_u_22[v69.UserId] = nil
			end
			v_u_16.clear(v73.Shell)
			v73.Janitor:Destroy()
		end
		task.delay(1.5, function()
			-- upvalues: (ref) v_u_31, (copy) v_u_70, (copy) v_u_71, (ref) v_u_10
			if v_u_31[v_u_70] == v_u_71 then
				local v74 = v_u_70
				local v75 = v_u_31[v74]
				if v75 then
					v_u_31[v74] = nil
					v75:destroy()
				end
				if v_u_70.Parent then
					v_u_70.Parent = v_u_10.GetCulledFolder()
				end
			end
		end)
		return
	else
		v_u_55(p68, false)
		local v76 = v_u_21[v69]
		if v76 ~= nil then
			v_u_21[v69] = nil
			if v_u_22[v69.UserId] == v76 then
				v_u_22[v69.UserId] = nil
			end
			v_u_16.clear(v76.Shell)
			v76.Janitor:Destroy()
		end
	end
end
local function v_u_111(p_u_78, p_u_79) -- name: tryBind
	-- upvalues: (copy) v_u_19, (copy) v_u_2, (copy) v_u_23, (copy) v_u_31, (copy) v_u_11, (copy) v_u_10, (copy) v_u_9, (copy) v_u_14, (copy) v_u_21, (copy) v_u_22, (copy) v_u_55, (copy) v_u_16, (copy) v_u_17, (copy) v_u_5, (copy) v_u_12, (copy) v_u_45, (copy) v_u_20, (copy) v_u_77, (copy) v_u_6
	if p_u_78 == v_u_19 or (p_u_78.Parent ~= v_u_2 or (p_u_78.Character ~= p_u_79 or p_u_79.Parent == nil)) then
		local v80 = v_u_23[p_u_78]
		if v80 ~= nil then
			v_u_23[p_u_78] = nil
			v80.Janitor:Destroy()
		end
		return false
	end
	if p_u_79:GetAttribute("Dead") == true then
		if v_u_31[p_u_79] then
			local v81 = v_u_23[p_u_78]
			if v81 ~= nil then
				v_u_23[p_u_78] = nil
				v81.Janitor:Destroy()
			end
			return true
		end
		p_u_79:SetAttribute(v_u_11.VisibleAttribute, false)
		p_u_79.Parent = v_u_10.GetCulledFolder()
		local v82 = v_u_23[p_u_78]
		if v82 ~= nil then
			v_u_23[p_u_78] = nil
			v82.Janitor:Destroy()
		end
		return true
	end
	local v83 = v_u_9.Get(p_u_79)
	local v84 = v_u_14.resolve(p_u_79)
	if v83 == nil or (v84 == nil or v84.Animator == nil) then
		return false
	end
	local v85 = v_u_21[p_u_78]
	if v85 ~= nil then
		v_u_21[p_u_78] = nil
		if v_u_22[p_u_78.UserId] == v85 then
			v_u_22[p_u_78.UserId] = nil
		end
		if v85.Shell.Parent ~= nil and (v85.Shell:GetAttribute("Dead") ~= true and p_u_78.Character == v85.Shell) then
			v_u_55(v85, true)
		end
		v_u_16.clear(v85.Shell)
		v85.Janitor:Destroy()
	end
	local v86 = v_u_31[p_u_79]
	if v86 then
		v_u_31[p_u_79] = nil
		v86:destroy()
	end
	local v87 = v_u_17.new()
	local v_u_88 = v_u_5.new(p_u_79)
	v_u_88.Player = p_u_78
	local v_u_89 = {
		["Player"] = nil,
		["Shell"] = nil,
		["Generation"] = nil,
		["RootPart"] = nil,
		["Joints"] = nil,
		["Animator"] = nil,
		["Visible"] = true,
		["VisibleParent"] = nil,
		["LastPosePosition"] = nil,
		["LookYaw"] = nil,
		["VerticalLook"] = nil,
		["LastAnimationUpdateAt"] = (-1 / 0),
		["PresentedFrame"] = 0,
		["RetainAnimator"] = false,
		["Janitor"] = nil,
		["Player"] = p_u_78,
		["Shell"] = p_u_79,
		["Generation"] = v83,
		["RootPart"] = v84.RootPart,
		["Joints"] = v_u_12.getJoints(p_u_79),
		["Animator"] = v_u_88
	}
	local v90
	if p_u_79.Parent == v_u_10.GetCulledFolder() then
		v90 = nil
	else
		v90 = p_u_79.Parent
	end
	v_u_89.VisibleParent = v90
	v_u_89.Janitor = v87
	v_u_21[p_u_78] = v_u_89
	v_u_22[p_u_78.UserId] = v_u_89
	local v91 = v_u_23[p_u_78]
	if v91 ~= nil then
		v_u_23[p_u_78] = nil
		v91.Janitor:Destroy()
	end
	v84.RootPart.Anchored = true
	v84.RootPart.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
	v84.RootPart.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
	v87:Add(function()
		-- upvalues: (copy) v_u_89, (copy) v_u_88
		if not v_u_89.RetainAnimator then
			v_u_88:destroy()
		end
	end)
	v87:Add(p_u_78:GetAttributeChangedSignal("CurrentEquipped"):Connect(function()
		-- upvalues: (ref) v_u_21, (copy) p_u_78, (copy) v_u_89, (ref) v_u_45
		if v_u_21[p_u_78] == v_u_89 then
			local v92 = v_u_89
			if not v92.Visible then
				return
			end
			local v93, v94 = v_u_45(v92.Player)
			v92.Animator:setWeapon(v93, v94, true)
		end
	end))
	v87:Add(p_u_79.DescendantAdded:Connect(function()
		-- upvalues: (copy) v_u_89, (ref) v_u_12, (copy) p_u_79
		if v_u_89.Joints == nil then
			v_u_89.Joints = v_u_12.getJoints(p_u_79)
		end
	end))
	v87:Add(p_u_79.DescendantRemoving:Connect(function(p95)
		-- upvalues: (copy) v_u_89, (ref) v_u_21, (copy) p_u_78, (ref) v_u_22, (ref) v_u_55, (ref) v_u_16, (copy) p_u_79, (ref) v_u_20
		local v96 = v_u_89.Joints
		if v96 ~= nil and (p95 == v96.RightShoulder or (p95 == v96.LeftShoulder or (p95 == v96.Waist or p95 == v96.Neck))) then
			v_u_89.Joints = nil
		end
		if p95 == v_u_89.RootPart or p95 == v_u_89.Animator.Animator then
			task.defer(function()
				-- upvalues: (ref) v_u_21, (ref) p_u_78, (ref) v_u_89, (ref) v_u_22, (ref) v_u_55, (ref) v_u_16, (ref) p_u_79, (ref) v_u_20
				if v_u_21[p_u_78] == v_u_89 then
					local v97 = p_u_78
					local v98 = v_u_21[v97]
					if v98 ~= nil then
						v_u_21[v97] = nil
						if v_u_22[v97.UserId] == v98 then
							v_u_22[v97.UserId] = nil
						end
						if v98.Shell.Parent ~= nil and (v98.Shell:GetAttribute("Dead") ~= true and v97.Character == v98.Shell) then
							v_u_55(v98, true)
						end
						v_u_16.clear(v98.Shell)
						v98.Janitor:Destroy()
					end
					if p_u_78.Character == p_u_79 and p_u_79.Parent ~= nil then
						v_u_20.Track(p_u_78, p_u_79)
					end
				end
			end)
		end
	end))
	v87:Add(p_u_79.AncestryChanged:Connect(function(_, p99)
		-- upvalues: (ref) v_u_21, (copy) p_u_78, (copy) v_u_89, (ref) v_u_22, (ref) v_u_16, (ref) v_u_10
		if p99 == nil and v_u_21[p_u_78] == v_u_89 then
			local v100 = p_u_78
			local v101 = v_u_21[v100]
			if v101 ~= nil then
				v_u_21[v100] = nil
				if v_u_22[v100.UserId] == v101 then
					v_u_22[v100.UserId] = nil
				end
				v_u_16.clear(v101.Shell)
				v101.Janitor:Destroy()
			end
		else
			if p99 ~= nil and (v_u_21[p_u_78] == v_u_89 and (not v_u_89.Visible and p99 ~= v_u_10.GetCulledFolder())) then
				task.defer(function()
					-- upvalues: (ref) v_u_21, (ref) p_u_78, (ref) v_u_89, (ref) v_u_10
					if v_u_21[p_u_78] == v_u_89 and (not v_u_89.Visible and v_u_89.Shell.Parent ~= v_u_10.GetCulledFolder()) then
						local v102 = v_u_89
						local v103 = v_u_10.GetCulledFolder()
						local v104 = v102.Shell.Parent
						if v104 ~= nil and v104 ~= v103 then
							v102.VisibleParent = v104
						end
						if v102.Shell.Parent ~= v103 then
							v102.Shell.Parent = v103
						end
					end
				end)
			end
			return
		end
	end))
	v87:Add(p_u_79:GetAttributeChangedSignal("Dead"):Connect(function()
		-- upvalues: (copy) p_u_79, (ref) v_u_21, (copy) p_u_78, (copy) v_u_89, (ref) v_u_77
		if p_u_79:GetAttribute("Dead") == true and v_u_21[p_u_78] == v_u_89 then
			v_u_77(v_u_89)
		end
	end))
	v87:Add(p_u_79:GetAttributeChangedSignal(v_u_9.AttributeName):Connect(function()
		-- upvalues: (ref) v_u_9, (copy) p_u_79, (copy) v_u_89, (ref) v_u_21, (copy) p_u_78, (ref) v_u_20
		if v_u_9.Get(p_u_79) ~= v_u_89.Generation and v_u_21[p_u_78] == v_u_89 then
			v_u_20.Track(p_u_78, p_u_79)
		end
	end))
	if v_u_89.Visible then
		local v105, v106 = v_u_45(v_u_89.Player)
		v_u_89.Animator:setWeapon(v105, v106, false)
	end
	v_u_55(v_u_89, false)
	task.spawn(function()
		-- upvalues: (copy) p_u_79, (ref) v_u_6, (copy) p_u_78
		if p_u_79:IsDescendantOf(game) and p_u_79:GetAttribute("Dead") ~= true then
			local v107 = v_u_6.PrepareCharacter
			local v108 = p_u_79
			local v109, v110 = pcall(v107, v108)
			if not v109 then
				warn((("[RemoteCharacters] Ragdoll preparation failed for %*: %*"):format(p_u_78.Name, v110)))
			end
		end
	end)
	return true
end
function v_u_20.Track(p_u_112, p_u_113) -- name: Track
	-- upvalues: (copy) v_u_19, (copy) v_u_21, (copy) v_u_9, (copy) v_u_22, (copy) v_u_55, (copy) v_u_16, (copy) v_u_23, (copy) v_u_111, (copy) v_u_17
	if p_u_112 == v_u_19 or p_u_112.Character ~= p_u_113 then
		return
	else
		local v114 = v_u_21[p_u_112]
		if v114 == nil or (p_u_113:GetAttribute("Dead") == true or (v114.Shell ~= p_u_113 or v114.Generation ~= v_u_9.Get(p_u_113))) then
			local v115 = v_u_21[p_u_112]
			if v115 ~= nil then
				v_u_21[p_u_112] = nil
				if v_u_22[p_u_112.UserId] == v115 then
					v_u_22[p_u_112.UserId] = nil
				end
				if v115.Shell.Parent ~= nil and (v115.Shell:GetAttribute("Dead") ~= true and p_u_112.Character == v115.Shell) then
					v_u_55(v115, true)
				end
				v_u_16.clear(v115.Shell)
				v115.Janitor:Destroy()
			end
			local v116 = v_u_23[p_u_112]
			if v116 == nil or v116.Shell ~= p_u_113 then
				local v117 = v_u_23[p_u_112]
				if v117 ~= nil then
					v_u_23[p_u_112] = nil
					v117.Janitor:Destroy()
				end
				local v118 = v_u_17.new()
				v_u_23[p_u_112] = {
					["Shell"] = p_u_113,
					["Janitor"] = v118
				}
				local function v119() -- name: retry
					-- upvalues: (ref) v_u_23, (copy) p_u_112, (ref) v_u_111, (copy) p_u_113
					if v_u_23[p_u_112] ~= nil then
						v_u_111(p_u_112, p_u_113)
					end
				end
				v118:Add(p_u_113.DescendantAdded:Connect(v119))
				v118:Add(p_u_113:GetAttributeChangedSignal("CharacterType"):Connect(v119))
				v118:Add(p_u_113:GetAttributeChangedSignal("Dead"):Connect(v119))
				v118:Add(p_u_113:GetAttributeChangedSignal(v_u_9.AttributeName):Connect(v119))
				v118:Add(p_u_113.AncestryChanged:Connect(function()
					-- upvalues: (copy) p_u_113, (copy) p_u_112, (ref) v_u_23, (ref) v_u_111
					if p_u_113.Parent == nil then
						local v120 = p_u_112
						local v121 = v_u_23[v120]
						if v121 ~= nil then
							v_u_23[v120] = nil
							v121.Janitor:Destroy()
						end
					else
						if v_u_23[p_u_112] ~= nil then
							v_u_111(p_u_112, p_u_113)
						end
						return
					end
				end))
				if v_u_23[p_u_112] ~= nil then
					v_u_111(p_u_112, p_u_113)
				end
			else
				v_u_111(p_u_112, p_u_113)
			end
		else
			return
		end
	end
end
function v_u_20.Untrack(p122, p123) -- name: Untrack
	-- upvalues: (copy) v_u_21, (copy) v_u_22, (copy) v_u_55, (copy) v_u_16, (copy) v_u_23
	local v124 = v_u_21[p122]
	if v124 ~= nil and (p123 == nil or v124.Shell == p123) then
		local v125 = v_u_21[p122]
		if v125 ~= nil then
			v_u_21[p122] = nil
			if v_u_22[p122.UserId] == v125 then
				v_u_22[p122.UserId] = nil
			end
			if v125.Shell.Parent ~= nil and (v125.Shell:GetAttribute("Dead") ~= true and p122.Character == v125.Shell) then
				v_u_55(v125, true)
			end
			v_u_16.clear(v125.Shell)
			v125.Janitor:Destroy()
		end
	end
	local v126 = v_u_23[p122]
	if v126 ~= nil and (p123 == nil or v126.Shell == p123) then
		local v127 = v_u_23[p122]
		if v127 == nil then
			return
		end
		v_u_23[p122] = nil
		v127.Janitor:Destroy()
	end
end
function v_u_20.Present(p128, _) -- name: Present
	-- upvalues: (copy) v_u_18, (ref) v_u_25, (copy) v_u_26, (copy) v_u_27, (copy) v_u_28, (copy) v_u_29, (copy) v_u_22, (copy) v_u_2, (copy) v_u_19, (copy) v_u_9, (copy) v_u_21, (copy) v_u_10, (copy) v_u_20, (copy) v_u_15, (copy) v_u_12, (copy) v_u_4, (copy) v_u_55, (copy) v_u_16, (copy) v_u_13, (copy) v_u_77
	v_u_18.Present(p128)
	v_u_25 = v_u_25 + 1
	table.clear(v_u_26)
	table.clear(v_u_27)
	table.clear(v_u_28)
	table.clear(v_u_29)
	for _, v129 in p128 do
		if v129.UserId == 0 then
			continue
		end
		local v130 = v_u_22[v129.UserId]
		local v131
		if v130 == nil then
			v131 = v_u_2:GetPlayerByUserId(v129.UserId)
		else
			v131 = v130.Player
		end
		if v131 == nil or v131 == v_u_19 then
			continue
		end
		if v130 ~= nil and (v130.Generation == v129.Generation and v_u_9.Get(v130.Shell) == v129.Generation) then
			v130.PresentedFrame = v_u_25
		end
		local v132 = v129.RenderPose
		if v132 == nil then
			continue
		end
		local v133 = v_u_21[v131]
		local v134 = v131.Character
		if not v_u_10.IsOwned(v134) or (v134 == nil or v_u_9.Get(v134) ~= v132.Generation) then
			v134 = v_u_10.Create(v131, v132.Generation)
		end
		if v134 ~= nil and (v133 == nil or (v133.Shell ~= v134 or v133.Generation ~= v132.Generation)) then
			v_u_20.Track(v131, v134)
			v133 = v_u_21[v131]
		end
		if v133 == nil or (v134 == nil or (v133.Shell ~= v134 or (v133.Shell.Parent == nil or (v133.Shell:GetAttribute("Dead") == true or (v133.Generation ~= v132.Generation or v_u_9.Get(v133.Shell) ~= v132.Generation))))) then
			continue
		end
		v133.PresentedFrame = v_u_25
		local v135 = v132.VisualRootPosition or v_u_15.simulationToVisualRootPosition(v132.Position, v132.DuckAmount)
		local v136 = v_u_12.composeRootCFrame(v135, v132.LookYaw)
		if v133.RootPart.CFrame ~= v136 then
			v_u_26[#v_u_26 + 1] = v133.RootPart
			v_u_27[#v_u_27 + 1] = v136
		end
		v_u_28[#v_u_28 + 1] = v133
		v_u_29[#v_u_29 + 1] = v132
	end
	if #v_u_26 == 1 then
		v_u_26[1].CFrame = v_u_27[1]
	elseif #v_u_26 > 1 then
		v_u_4:BulkMoveTo(v_u_26, v_u_27, Enum.BulkMoveMode.FireCFrameChanged)
	end
	local v137 = os.clock()
	local v138 = v_u_4:GetServerTimeNow()
	for v139, v140 in v_u_28 do
		local v141 = v_u_29[v139]
		local v142 = v140.Visible
		v_u_55(v140, true)
		local v143 = v140.LastPosePosition
		local v144
		if v143 == nil then
			v144 = false
		else
			v144 = (v141.Position - v143).Magnitude > 0.00001
		end
		local v145 = not v144 and Vector3.new(0, 0, 0) or v141.Velocity
		v_u_16.write(v140.Shell, v145, v141.OnGround)
		v140.LastPosePosition = v141.Position
		v140.LookYaw = v141.LookYaw
		v140.VerticalLook = v141.VerticalLook
		local v146 = v137 - v140.LastAnimationUpdateAt
		if v142 and v146 < 0.016666666666666666 then
			continue
		end
		local v147 = v141.DuckAmount > 0.5
		local v148 = v141.MovementMode == "Ladder"
		local v149 = v_u_13.IsDowned(v140.Player)
		v140.Animator:setDowned(v149)
		local v150 = v140.Animator
		local v151
		if v149 then
			local v152 = v141.VerticalLook
			local v153 = math.clamp(v152, -1, 1)
			v151 = math.asin(v153)
		else
			v151 = nil
		end
		v150:setDownedAim(v151)
		v140.Animator:updateLocomotion(v145, v141.OnGround, v147, v148)
		if v140.Joints ~= nil then
			v_u_12.applyVerticalLook(v140.Joints, v149 and 0 or v141.VerticalLook, 0.003)
		end
		v140.Animator:setBlinded(v138 < (v140.Player:GetAttribute("FlashedUntil") or 0))
		local v154
		if v146 == (1 / 0) then
			v154 = v137
		else
			local v155 = v140.LastAnimationUpdateAt
			local v156 = v146 / 0.016666666666666666
			v154 = v155 + math.floor(v156) * 0.016666666666666666
		end
		v140.LastAnimationUpdateAt = v154
	end
	for v157, v158 in v_u_21 do
		if v158.PresentedFrame == v_u_25 then
			continue
		end
		if v157.Parent == v_u_2 and (v157.Character == v158.Shell and v158.Shell.Parent ~= nil) then
			if v158.Shell:GetAttribute("Dead") == true then
				v_u_77(v158)
			elseif v_u_9.Get(v158.Shell) == v158.Generation then
				v_u_55(v158, false)
			else
				local v159 = v158.Shell
				local v160 = v_u_21[v157]
				if v160 ~= nil then
					v_u_21[v157] = nil
					if v_u_22[v157.UserId] == v160 then
						v_u_22[v157.UserId] = nil
					end
					v_u_16.clear(v160.Shell)
					v160.Janitor:Destroy()
				end
				v_u_10.Release(v157, v159)
			end
		else
			local v161 = v_u_21[v157]
			if v161 == nil then
				continue
			end
			v_u_21[v157] = nil
			if v_u_22[v157.UserId] == v161 then
				v_u_22[v157.UserId] = nil
			end
			v_u_16.clear(v161.Shell)
			v161.Janitor:Destroy()
		end
	end
end
function v_u_20.Initialize() -- name: Initialize
	-- upvalues: (ref) v_u_24, (copy) v_u_18, (copy) v_u_8, (copy) v_u_2, (copy) v_u_19, (copy) v_u_21, (copy) v_u_7, (copy) v_u_9, (ref) v_u_30, (copy) v_u_22, (copy) v_u_16, (copy) v_u_23, (copy) v_u_10
	if not v_u_24 then
		v_u_24 = true
		v_u_18.Initialize()
		v_u_8.Character.Action.Listen(function(p162)
			-- upvalues: (ref) v_u_2, (ref) v_u_19, (ref) v_u_21, (ref) v_u_7, (ref) v_u_9
			local v163 = v_u_2:GetPlayerByUserId(p162.UserId)
			if v163 ~= nil and v163 ~= v_u_19 then
				local v164 = v_u_21[v163]
				local v165 = v_u_7.ToName(p162.ActionId)
				if v164 ~= nil and (v164.Visible and (v164.Generation == p162.Generation and (v_u_9.Get(v164.Shell) == p162.Generation and (v163.Character == v164.Shell and (v164.Shell:GetAttribute("Dead") ~= true and v165 ~= nil))))) then
					v164.Animator:playAction(v165)
				end
			end
		end)
		v_u_2.PlayerRemoving:Connect(function(p166)
			-- upvalues: (ref) v_u_30, (ref) v_u_21, (ref) v_u_22, (ref) v_u_16, (ref) v_u_23, (ref) v_u_10
			if v_u_30 == p166 then
				v_u_30 = nil
			end
			local v167 = p166.Character
			local v168 = v_u_21[p166]
			if v168 ~= nil then
				v_u_21[p166] = nil
				if v_u_22[p166.UserId] == v168 then
					v_u_22[p166.UserId] = nil
				end
				v_u_16.clear(v168.Shell)
				v168.Janitor:Destroy()
			end
			local v169 = v_u_23[p166]
			if v169 ~= nil then
				v_u_23[p166] = nil
				v169.Janitor:Destroy()
			end
			v_u_10.Release(p166, v167)
		end)
	end
end
return v_u_20
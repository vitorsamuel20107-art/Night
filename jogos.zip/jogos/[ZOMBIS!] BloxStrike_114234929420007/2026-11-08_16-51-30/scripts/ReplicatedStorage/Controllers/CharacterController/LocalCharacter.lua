-- NIGHT Analyzer | ReplicatedStorage.Controllers.CharacterController.LocalCharacter
-- ModuleScript | 634 linhas | 19757 bytes | hash acf05300

local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(v2.Classes.Character)
local v_u_5 = require(v2.Classes.Ragdoll)
local v_u_6 = require(v2.Classes.Sound)
local v_u_7 = require(v2.Components.Common.CharacterGeneration)
local v_u_8 = require(v2.Components.Common.ClientCharacterPresentation)
local v_u_9 = require(v2.Components.Common.CharacterResolver)
local v_u_10 = require(v2.Components.Common.GetWeaponProperties)
local v_u_11 = require(v2.Components.Common.Participants)
local v_u_12 = require(v2.Components.Common.SurvivalDowned)
local v13 = require(v2.MovementV2.Client.Runtime)
local v_u_14 = require(v2.MovementV2.Collision.Catalog)
local v15 = require(v2.MovementV2.Client.MoverComposer)
local v_u_16 = require(v2.MovementV2.DiagnosticProtocol)
local v_u_17 = require(v2.MovementV2.DoorSwing)
local v_u_18 = require(v2.MovementV2.MoverTrajectory)
local v_u_19 = require(v2.MovementV2.RootFrame)
local v_u_20 = require(v2.MovementV2.RuntimeKinematics)
local v_u_21 = require(v2.MovementV2.Serial)
local v_u_22 = require(v2.MovementV2.SpeedProfile)
local v_u_23 = require(script.Parent.HitFlinch)
local v24 = require(script.Parent.RemoteCharacters)
local v_u_25 = require(v2.Controllers.CameraController)
local v_u_26 = require(v2.Controllers.CaseSceneController)
local v_u_27 = require(v2.Controllers.BlackMarketSceneController)
local v_u_28 = require(v2.Controllers.InventoryController)
local v_u_29 = require(v2.Controllers.NetStatsController)
local v_u_30 = require(v2.Database.Security.Remotes)
local v_u_31 = require(v2.Database.Security.Router)
local v_u_32 = require(v2.Database.Components.GameState)
local v_u_33 = v1.LocalPlayer
local v_u_34 = require(v_u_33:WaitForChild("PlayerScripts"):WaitForChild("PlayerModule")):GetControls()
local v_u_35 = {}
local v_u_36 = nil
local v_u_37 = false
local v_u_38 = false
local v_u_39 = false
local v_u_40 = v15.new()
local v_u_41 = nil
local v_u_42 = nil
local v_u_43 = false
local v_u_44 = 0
local v_u_45 = {}
local function v55(p46) -- name: resolveWeaponSpeedProfile
	-- upvalues: (copy) v_u_22, (copy) v_u_28, (ref) v_u_43, (ref) v_u_41, (copy) v_u_10, (ref) v_u_42
	if p46.Identifier == "" and p46.GrenadeThrowIdentifier ~= nil then
		return v_u_22.resolveWeaponSpeeds(nil, nil)
	end
	local v47 = v_u_28.peekInventoryItemForMovement(p46.Identifier)
	if v47 ~= nil then
		local v48 = v47.Name
		if typeof(v48) == "string" then
			local v49 = v_u_22.resolveWeaponSpeeds
			local v50 = v47.Name
			local v51 = v47.Name
			if not v_u_43 or v_u_41 ~= v51 then
				v_u_41 = v51
				v_u_43 = true
				local v52
				if v51 == nil then
					v52 = nil
				else
					v52 = v_u_10(v51)
				end
				local v53
				if v52 == nil then
					v53 = nil
				else
					local v54 = v52.WalkSpeed
					if typeof(v54) == "number" then
						v53 = v52.WalkSpeed
					else
						v53 = nil
					end
				end
				v_u_42 = v53
			end
			return v49(v50, v_u_42)
		end
	end
	return nil, nil
end
local function v_u_59(_, p56, p57) -- name: moveCharacter
	-- upvalues: (ref) v_u_36
	local v58 = v_u_36
	if v58 ~= nil then
		v58:MoveFunction(p56, p57)
	end
end
local function v_u_62(p60) -- name: resolveControllerRig
	-- upvalues: (copy) v_u_9, (copy) v_u_7
	if v_u_9.isPlayerCharacter(p60) and v_u_7.Get(p60) ~= nil then
		local v61 = v_u_9.resolve(p60)
		if v61 == nil or (v61.Head == nil or v61.Animator == nil) then
			return nil
		else
			return v61
		end
	else
		return nil
	end
end
local v_u_96 = v13.new({
	["PrepareInputFrame"] = function() -- name: PrepareInputFrame
		-- upvalues: (ref) v_u_36
		local v63 = v_u_36
		if v63 ~= nil then
			v63:PrepareInputFrame()
		end
	end,
	["SampleInput"] = function(p64) -- name: SampleInput
		-- upvalues: (ref) v_u_36
		local v65 = v_u_36
		if v65 == nil then
			return nil
		else
			return v65:SampleInput(p64)
		end
	end,
	["ConsumePendingWeaponSelection"] = v_u_28.ConsumePendingMovementWeaponSelect,
	["GetUnresolvedWeaponSelection"] = v_u_28.GetUnresolvedMovementWeaponSelectForResend,
	["RestorePendingWeaponSelection"] = v_u_28.RestorePendingMovementWeaponSelect,
	["ResolveWeaponSpeedProfile"] = v55,
	["ResolveBaseMoveSpeed"] = function(_, p66, p67, p68, p69) -- name: resolveBaseMoveSpeed
		-- upvalues: (copy) v_u_32, (copy) v_u_33, (copy) v_u_22, (copy) v_u_12
		if v_u_32.GetStateAtTime(p66) == "Buy Period" then
			return 0
		end
		if v_u_33:GetAttribute("IsPlantingBomb") == true then
			local v70 = v_u_33:GetAttribute("BombPlantMovementLockAt")
			local v71
			if typeof(v70) == "number" and v70 == v70 then
				v71 = p66 < v70
			else
				v71 = false
			end
			if not v71 then
				return 0
			end
		end
		return v_u_22.resolveFromWeaponSpeeds(p67, p68, p69, v_u_33:GetAttribute("IsCarryingHostage") == true, v_u_12.IsDowned(v_u_33))
	end,
	["ResolveScopedState"] = function() -- name: resolveScopedState
		-- upvalues: (copy) v_u_28
		local v72 = v_u_28.peekCurrentEquippedForMovement()
		local v73
		if v72 == nil then
			v73 = false
		elseif v72.IsAiming == true then
			v73 = true
		elseif v72.Name == "R8 Revolver" then
			v73 = v72.IsChargeFiring == true
		else
			v73 = false
		end
		return v73
	end,
	["ResolveMovementDiagnosticContext"] = function(p74) -- name: ResolveMovementDiagnosticContext
		-- upvalues: (ref) v_u_36, (copy) v_u_32, (copy) v_u_33
		local v75 = v_u_36
		local v76 = {
			["GameStateAtSnapshot"] = v_u_32.GetStateAtTime(p74),
			["CurrentGameState"] = v_u_32.GetState()
		}
		local v77
		if v75 == nil then
			v77 = false
		else
			v77 = v75.IsPlantingBomb == true
		end
		v76.LocalPlanting = v77
		v76.ReplicatedPlanting = v_u_33:GetAttribute("IsPlantingBomb") == true
		v76.LocalDefusing = v_u_33:GetAttribute("IsLocallyDefusingBomb") == true
		v76.ReplicatedDefusing = v_u_33:GetAttribute("IsDefusingBomb") == true
		v76.ReplicatedRescuing = v_u_33:GetAttribute("IsRescuingHostage") == true
		v76.CarryingHostage = v_u_33:GetAttribute("IsCarryingHostage") == true
		v76.BombPlantMovementLockAt = v_u_33:GetAttribute("BombPlantMovementLockAt")
		return v76
	end,
	["ResolveGeneration"] = function() -- name: ResolveGeneration
		-- upvalues: (ref) v_u_36
		local v78 = v_u_36
		if v78 == nil then
			return nil
		else
			return v78.Generation
		end
	end,
	["ResolveMapRoot"] = function(p79) -- name: ResolveMapRoot
		-- upvalues: (copy) v_u_14, (copy) v_u_3
		return v_u_14.FindReplica(p79.TopologyEpoch, p79.TopologyFingerprint) or v_u_3:FindFirstChild("Map")
	end,
	["CollisionComposer"] = v_u_40,
	["PresentLocal"] = function(p80, p81, p82, p83) -- name: PresentLocal
		-- upvalues: (copy) v_u_29, (copy) v_u_18, (ref) v_u_36
		v_u_29.ObservePresentation(p82)
		v_u_18.SetClientPresentationClock(p82.ServerTick, p82.TickFraction or 0)
		local v84 = v_u_36
		if v84 ~= nil then
			v84:Present(p80, p81, p82, p83)
		end
	end,
	["PresentRemotes"] = v24.Present,
	["OnStepEvents"] = function(p85) -- name: OnStepEvents
		-- upvalues: (ref) v_u_36
		local v86 = v_u_36
		if v86 ~= nil then
			v86:OnStepEvents(p85)
		end
	end,
	["OnOwnerSnapshotReceived"] = v_u_29.ObserveOwnerSnapshot,
	["OnRemoteSnapshotReceived"] = v_u_29.ObserveRemoteSnapshot,
	["OnCommandPacketSent"] = v_u_29.ObserveCommandPacket,
	["OnReconciled"] = function(p87, p88) -- name: OnReconciled
		-- upvalues: (copy) v_u_29, (ref) v_u_36
		v_u_29.ObserveReconciliation(p87, p88)
		local v89 = v_u_36
		if v89 ~= nil then
			v89:OnReconciled(p87)
		end
	end,
	["OnPlayerContactCorrection"] = function(p90, _, p91) -- name: OnPlayerContactCorrection
		-- upvalues: (ref) v_u_36
		local v92 = v_u_36
		if v92 ~= nil then
			v92:OnPlayerContactCorrection(p90, p91)
		end
	end,
	["OnPredictionHitch"] = function(p93) -- name: OnPredictionHitch
		-- upvalues: (copy) v_u_29
		v_u_29.ObservePredictionHitch(p93)
	end,
	["OnWarning"] = function(p94) -- name: OnWarning
		-- upvalues: (copy) v_u_16, (copy) v_u_33
		local v95 = ("[MovementV2] %*"):format(p94)
		if v_u_16.shouldOutputForPlayer(v_u_33) then
			warn(v95)
		end
	end
})
local function v_u_120(p_u_97, p98) -- name: characterAdded
	-- upvalues: (copy) v_u_5, (copy) v_u_20, (ref) v_u_36, (copy) v_u_34, (copy) v_u_26, (copy) v_u_27, (copy) v_u_3, (copy) v_u_33, (copy) v_u_4, (copy) v_u_25, (ref) v_u_39, (copy) v_u_96, (copy) v_u_16, (copy) v_u_45, (copy) v_u_28
	local v_u_99 = p98.RootPart
	if p_u_97:GetAttribute("Dead") == true then
		v_u_5.ActivateCharacter(p_u_97, v_u_20.getVelocity(p_u_97, v_u_99))
		return nil
	end
	local v100 = v_u_36 == nil
	assert(v100, "local character rebound before the previous binding was cleaned up")
	local v101 = v_u_34.activeController
	if v101 ~= nil then
		v101.moveVector = Vector3.new(0, 0, 0)
		v101.backwardValue = 0
		v101.forwardValue = 0
		v101.rightValue = 0
		v101.leftValue = 0
	end
	v_u_99.Anchored = true
	v_u_99.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
	v_u_99.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
	if not (v_u_26.IsActive() or v_u_27.IsActive()) then
		local v102 = v_u_3.CurrentCamera
		if v102 ~= nil then
			v102.CameraType = Enum.CameraType.Custom
			v102.CameraSubject = p98.CameraPart
		end
	end
	v_u_33.ReplicationFocus = v_u_99
	local v_u_103 = v_u_4.new(p_u_97, v_u_99)
	v_u_36 = v_u_103
	v_u_103.Janitor:Add(v_u_103.Landed:Connect(function(p104, p105)
		-- upvalues: (ref) v_u_25
		v_u_25.OnLanded(p104, p105)
	end))
	local v106 = v_u_36
	if v_u_39 and v106 ~= nil then
		local v107, v108 = v_u_96:requestMapping(v106.Generation)
		if not v107 then
			local v109 = ("[MovementV2] could not request mapping for generation %*: %*"):format(v106.Generation, v108 or "Unknown")
			if v_u_16.shouldOutputForPlayer(v_u_33) then
				warn(v109)
			end
		end
	end
	local v_u_110 = false
	local v_u_111 = nil
	local function v_u_115() -- name: cleanup
		-- upvalues: (ref) v_u_110, (ref) v_u_111, (ref) v_u_36, (copy) v_u_103, (ref) v_u_45, (ref) v_u_96, (ref) v_u_25, (ref) v_u_33, (copy) p_u_97, (ref) v_u_3, (ref) v_u_28
		if v_u_110 then
			return
		else
			v_u_110 = true
			if v_u_111 ~= nil then
				v_u_111:Disconnect()
			end
			if v_u_36 == v_u_103 then
				for _, v112 in v_u_45 do
					v_u_96:rejectDoorPrediction(v112.MoverId, v112.Revision)
				end
				table.clear(v_u_45)
				local v_u_113 = v_u_103.Generation
				v_u_96:retireGeneration(v_u_113)
				v_u_36 = nil
				v_u_25.SetSprintHeld(false)
				v_u_103:Destroy()
				task.defer(function()
					-- upvalues: (ref) v_u_33, (ref) p_u_97, (ref) v_u_3, (ref) v_u_28, (copy) v_u_113
					local v114 = v_u_33.Character == p_u_97 and p_u_97:IsDescendantOf(v_u_3)
					if v114 then
						v114 = p_u_97:GetAttribute("Dead") ~= true
					end
					if not v114 then
						v_u_28.CleanupCurrentLoadout(v_u_113)
					end
				end)
			end
		end
	end
	v_u_111 = p_u_97:GetAttributeChangedSignal("Dead"):Connect(function()
		-- upvalues: (copy) p_u_97, (ref) v_u_5, (ref) v_u_20, (copy) v_u_99, (copy) v_u_115
		if p_u_97:GetAttribute("Dead") == true then
			v_u_5.ActivateCharacter(p_u_97, v_u_20.getVelocity(p_u_97, v_u_99))
			v_u_115()
		end
	end)
	task.spawn(function()
		-- upvalues: (copy) p_u_97, (ref) v_u_5
		if p_u_97.Parent ~= nil and p_u_97:GetAttribute("Dead") ~= true then
			local v116 = v_u_5.PrepareCharacter
			local v117 = p_u_97
			local v118, v119 = pcall(v116, v117)
			if not v118 then
				warn((("[LocalCharacter] Ragdoll preparation failed: %*"):format(v119)))
			end
		end
	end)
	return v_u_115
end
local function v_u_139(p_u_121) -- name: observeCharacterReady
	-- upvalues: (copy) v_u_62, (copy) v_u_7, (copy) v_u_120
	local v_u_122 = nil
	local v_u_123 = nil
	local v_u_124 = nil
	local v_u_125 = nil
	local v_u_126 = false
	local v_u_127 = false
	local v_u_128 = false
	local function v_u_134() -- name: refreshBinding
		-- upvalues: (ref) v_u_127, (ref) v_u_62, (copy) p_u_121, (ref) v_u_7, (ref) v_u_122, (ref) v_u_123, (ref) v_u_124, (ref) v_u_125, (ref) v_u_126, (ref) v_u_120
		if v_u_127 then
			return
		else
			local v129 = v_u_62(p_u_121)
			local v130 = v_u_7.Get(p_u_121)
			if p_u_121.Parent == nil or (v129 == nil or v130 == nil) then
				local v131 = v_u_122
				v_u_122 = nil
				v_u_123 = nil
				v_u_124 = nil
				v_u_125 = nil
				if v131 ~= nil then
					v131()
				end
				return
			elseif p_u_121:GetAttribute("Dead") == true then
				local v132 = v_u_122
				v_u_122 = nil
				v_u_123 = nil
				v_u_124 = nil
				v_u_125 = nil
				if v132 ~= nil then
					v132()
				end
				if not v_u_126 then
					v_u_126 = true
					v_u_120(p_u_121, v129)
				end
				return
			else
				v_u_126 = false
				if v_u_122 == nil or (v_u_123 ~= v130 or (v_u_124 ~= v129.RootPart or v_u_125 ~= v129.Animator)) then
					local v133 = v_u_122
					v_u_122 = nil
					v_u_123 = nil
					v_u_124 = nil
					v_u_125 = nil
					if v133 ~= nil then
						v133()
					end
					v_u_122 = v_u_120(p_u_121, v129)
					if v_u_122 ~= nil then
						v_u_123 = v130
						v_u_124 = v129.RootPart
						v_u_125 = v129.Animator
					end
				end
			end
		end
	end
	local function v135() -- name: queueRefresh
		-- upvalues: (ref) v_u_128, (ref) v_u_127, (copy) v_u_134
		if not (v_u_128 or v_u_127) then
			v_u_128 = true
			task.defer(function()
				-- upvalues: (ref) v_u_128, (ref) v_u_134
				v_u_128 = false
				v_u_134()
			end)
		end
	end
	local v_u_136 = {
		p_u_121.DescendantAdded:Connect(v_u_134),
		p_u_121.DescendantRemoving:Connect(v135),
		p_u_121:GetAttributeChangedSignal("CharacterType"):Connect(v_u_134),
		p_u_121:GetAttributeChangedSignal(v_u_7.AttributeName):Connect(v_u_134),
		p_u_121:GetAttributeChangedSignal("Dead"):Connect(v_u_134)
	}
	v_u_134()
	return function()
		-- upvalues: (ref) v_u_127, (copy) v_u_136, (ref) v_u_122, (ref) v_u_123, (ref) v_u_124, (ref) v_u_125
		v_u_127 = true
		for _, v137 in v_u_136 do
			v137:Disconnect()
		end
		table.clear(v_u_136)
		local v138 = v_u_122
		v_u_122 = nil
		v_u_123 = nil
		v_u_124 = nil
		v_u_125 = nil
		if v138 ~= nil then
			v138()
		end
	end
end
function v_u_35.getCurrentCharacter() -- name: getCurrentCharacter
	-- upvalues: (ref) v_u_36
	return v_u_36
end
function v_u_35.GetMovementRuntimeStatus() -- name: GetMovementRuntimeStatus
	-- upvalues: (copy) v_u_96
	return v_u_96:getStatus()
end
function v_u_35.GetRemoteViewTick() -- name: GetRemoteViewTick
	-- upvalues: (copy) v_u_96
	return v_u_96:getRemoteViewTick()
end
function v_u_35.GetWalkState() -- name: GetWalkState
	-- upvalues: (ref) v_u_36
	local v140
	if v_u_36 == nil then
		v140 = false
	else
		v140 = v_u_36.IsWalking
	end
	return v140
end
function v_u_35.GetSprintState() -- name: GetSprintState
	-- upvalues: (ref) v_u_36
	local v141
	if v_u_36 == nil then
		v141 = false
	else
		v141 = v_u_36.IsSprinting
	end
	return v141
end
function v_u_35.GetCrouchState() -- name: GetCrouchState
	-- upvalues: (ref) v_u_36
	local v142
	if v_u_36 == nil then
		v142 = false
	else
		v142 = v_u_36.IsCrouching
	end
	return v142
end
function v_u_35.walk(p143) -- name: walk
	-- upvalues: (ref) v_u_36
	if v_u_36 ~= nil then
		v_u_36:ToggleWalkState(p143)
	end
end
function v_u_35.sprint(p144) -- name: sprint
	-- upvalues: (ref) v_u_36, (copy) v_u_25
	if v_u_36 ~= nil then
		v_u_36:ToggleSprintState(p144)
		v_u_25.SetSprintHeld(v_u_36.IsSprinting)
	end
end
function v_u_35.crouch(p145) -- name: crouch
	-- upvalues: (ref) v_u_36
	if v_u_36 ~= nil then
		v_u_36:ToggleCrouchInput(p145)
	end
end
function v_u_35.jump(p146) -- name: jump
	-- upvalues: (ref) v_u_36
	if v_u_36 ~= nil then
		v_u_36:SetJumpInput(p146)
	end
end
function v_u_35.PlantBomb() -- name: PlantBomb
	-- upvalues: (ref) v_u_36
	if v_u_36 ~= nil then
		v_u_36:PlantBomb()
	end
end
function v_u_35.CancelBombPlant() -- name: CancelBombPlant
	-- upvalues: (ref) v_u_36
	if v_u_36 ~= nil then
		v_u_36:CancelBombPlant()
	end
end
function v_u_35.IsDoorInUseRange(p147) -- name: IsDoorInUseRange
	-- upvalues: (copy) v_u_96, (copy) v_u_19, (copy) v_u_17
	local v148 = v_u_96:getPredictedState()
	local v149 = p147:GetAttribute("DoorClosedPivot")
	if v148 == nil or typeof(v149) ~= "CFrame" then
		return false
	else
		return (v_u_19.cframe(v148).Position - v149.Position).Magnitude <= v_u_17.InteractRange
	end
end
function v_u_35.PredictDoorUse(p_u_150) -- name: PredictDoorUse
	-- upvalues: (copy) v_u_96, (copy) v_u_40, (ref) v_u_44, (copy) v_u_21, (copy) v_u_45
	if p_u_150:GetAttribute("CanOpen") == false then
		return nil, "DoorLocked"
	end
	local v151 = v_u_96:getMapping()
	local v152, _, v153 = v_u_96:getPredictedState()
	if v151 == nil or (v152 == nil or v153 == nil) then
		return nil, "MovementPredictionUnavailable"
	end
	local v_u_154, v155 = v_u_40:PredictDoorUse(p_u_150, v152.Position, v153, v151.SimulationHz)
	if v_u_154 == nil then
		return nil, v155
	end
	local v_u_156 = v_u_44
	v_u_44 = v_u_21.addUInt32(v_u_44, 1)
	v_u_45[v_u_156] = {
		["Model"] = p_u_150,
		["MoverId"] = v_u_154.MoverId,
		["Revision"] = v_u_154.Revision
	}
	task.delay(1, function()
		-- upvalues: (ref) v_u_45, (copy) v_u_156, (copy) p_u_150, (copy) v_u_154, (ref) v_u_96
		local v157 = v_u_45[v_u_156]
		if v157 ~= nil and (v157.Model == p_u_150 and v157.Revision == v_u_154.Revision) then
			v_u_45[v_u_156] = nil
			v_u_96:rejectDoorPrediction(v157.MoverId, v157.Revision)
		end
	end)
	return {
		["ServerTick"] = v_u_154.ServerTick,
		["TargetAngle"] = v_u_154.TargetAngle,
		["RequestId"] = v_u_156
	}, nil
end
function v_u_35.Initialize() -- name: Initialize
	-- upvalues: (ref) v_u_37, (copy) v_u_34, (copy) v_u_59, (copy) v_u_96, (ref) v_u_39, (copy) v_u_8, (copy) v_u_30, (copy) v_u_45, (copy) v_u_16, (copy) v_u_33, (copy) v_u_9, (copy) v_u_139, (ref) v_u_36, (copy) v_u_6, (copy) v_u_11, (copy) v_u_23
	if not v_u_37 then
		v_u_37 = true
		v_u_34.moveFunction = v_u_59
		v_u_96:start()
		v_u_39 = true
		v_u_8.ObserveLocalPlayer()
		v_u_30.BreakableDoor.Resolved.Listen(function(p158)
			-- upvalues: (ref) v_u_45, (ref) v_u_96, (ref) v_u_16, (ref) v_u_33
			local v159 = v_u_45[p158.RequestId]
			if v159 == nil or p158.Model ~= v159.Model then
				return
			else
				v_u_45[p158.RequestId] = nil
				if not p158.Accepted then
					local v160, v161 = v_u_96:rejectDoorPrediction(v159.MoverId, v159.Revision)
					if not v160 then
						local v162 = ("[MovementV2] could not reject speculative door use: %*"):format(v161 or "Unknown")
						if v_u_16.shouldOutputForPlayer(v_u_33) then
							warn(v162)
						end
					end
				end
			end
		end)
		v_u_9.observeCharacter(v_u_33, function(p163)
			-- upvalues: (ref) v_u_139
			if p163 == nil then
				return nil
			else
				return v_u_139(p163)
			end
		end)
		v_u_30.Character.CharacterDamaged.Listen(function(p164)
			-- upvalues: (ref) v_u_33, (ref) v_u_36, (ref) v_u_6, (ref) v_u_11, (ref) v_u_23
			if p164.VictimUserId == v_u_33.UserId then
				if v_u_36 ~= nil then
					v_u_6.new("Character"):playOneTime({
						["Parent"] = nil,
						["Name"] = "Character Damaged",
						["Parent"] = v_u_33.PlayerGui
					})
				end
				return
			elseif p164.Melee ~= true and p164.Direction ~= nil then
				local v165 = v_u_11.Character(v_u_11.FromKey(p164.VictimUserId))
				if v165 ~= nil then
					if p164.Headshot == true then
						v_u_23.flickHead(v165, p164.Direction)
						return
					end
					v_u_23.flinchBody(v165, p164.Direction)
				end
			end
		end)
	end
end
function v_u_35.Start() -- name: Start
	-- upvalues: (ref) v_u_38, (copy) v_u_31, (copy) v_u_35
	if not v_u_38 then
		v_u_38 = true
		v_u_31.observerRouter("Plant Bomb", v_u_35.PlantBomb)
		v_u_31.observerRouter("Cancel Bomb Plant", v_u_35.CancelBombPlant)
		v_u_31.observerRouter("Cancel Sprint", function()
			-- upvalues: (ref) v_u_35
			v_u_35.sprint(false)
		end)
		v_u_31.observerRouter("GetCurrentCharacter", v_u_35.getCurrentCharacter)
		v_u_31.observerRouter("GetRemoteViewTick", v_u_35.GetRemoteViewTick)
	end
end
return v_u_35
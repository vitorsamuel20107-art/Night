-- NIGHT Analyzer | ReplicatedStorage.Controllers.InventoryController
-- ModuleScript | 1004 linhas | 30791 bytes | hash 5ddc3f89

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("HttpService")
local v4 = game:GetService("Players")
require(v_u_2.Database.Custom.Types)
local v_u_5 = require(v_u_2.Controllers.CameraController)
local v_u_6 = require(v_u_2.Controllers.DataController)
local v_u_7 = require(v_u_2.Database.Components.Libraries.Collections)
local v_u_8 = require(v_u_2.Database.Components.MarketPlacePrices)
local v_u_9 = require(v_u_2.Database.Components.Libraries.Stock)
local v_u_10 = require(v_u_2.Components.Common.CharacterResolver)
local v_u_11 = require(v_u_2.Components.Common.SurvivalDowned)
local v_u_12 = require(v_u_2.Components.Common.CharacterGeneration)
local v_u_13 = require(v_u_2.Components.Common.PlayerHitPrediction)
local v_u_14 = require(v_u_2.Components.Common.TutorialPurchaseLock)
local v_u_15 = require(v_u_2.Database.Security.Remotes)
local v_u_16 = require(v_u_2.Database.Security.Router)
local v17 = require(v_u_2.Packages.Signal)
local v_u_18 = require(v_u_2.Shared.FilterTradableSkins)
local v_u_19 = require(v_u_2.Shared.FuzzySearch)
local v_u_20 = require(v_u_2.Components.Common.GetSkinDisplayName)
local v_u_21 = require(v_u_2.Components.Common.GetWeaponProperties)
local v_u_22 = require(v_u_2.Classes.Loadout)
local v_u_23 = require(v_u_2.Database.Custom.Constants)
local v_u_24 = require(v_u_2.Database.Custom.GameStats.NumberSlots)
local v_u_25 = require(v_u_2.Components.Common.VFXLibary.CreateMuzzleFlash.Character)
local v_u_26 = require(v_u_2.Components.Common.VFXLibary.CreateTracer)
local v_u_27 = require(v_u_2.Components.Common.VFXLibary.CreateMarker)
local v_u_28 = require(v_u_2.Components.Common.VFXLibary.CreateImpact)
local v_u_29 = require(v_u_2.Components.Common.VFXLibary.BreakGlass)
local v_u_30 = require(v_u_2.Components.Common.VFXLibary.CreateVoxelSmoke)
local v_u_31 = require(v_u_2.Components.Common.VFXLibary.CreateVoxelFire)
local v_u_32 = require(v_u_2.Components.Common.VFXLibary.FlashEffect)
local v_u_33 = require(v_u_2.Components.Common.VFXLibary.PlayZeusDeath)
local v_u_34 = require(v_u_2.Database.Components.Finishers)
local v_u_35 = require(v_u_2.Classes.Ragdoll)
local v_u_36 = require(v_u_2.Components.Common.RecycleFX)
local v_u_37 = v17.new()
v_u_1.OnInventoryItemEquipped = v_u_37
local v_u_38 = v17.new()
v_u_1.OnInventoryChanged = v_u_38
local v_u_39 = v4.LocalPlayer
local v_u_40 = nil
local v_u_41 = nil
local v_u_42 = nil
local v_u_43 = {}
local v_u_44 = 0
local v_u_45 = 0
local v_u_46 = 0
local v_u_47 = false
local v_u_48 = nil
local v_u_49 = nil
local v_u_50 = nil
local v_u_51 = nil
local function v_u_53() -- name: StopBlindedAnimation
	-- upvalues: (ref) v_u_50, (ref) v_u_51, (copy) v_u_16
	if v_u_50 then
		v_u_50:Disconnect()
		v_u_50 = nil
	end
	if v_u_51 then
		v_u_51:Disconnect()
		v_u_51 = nil
	end
	local v52 = v_u_16.broadcastRouter("GetCurrentCharacter")
	if v52 then
		v52.CharacterAnimator:setBlinded(false)
	end
end
local function v_u_55() -- name: StartBlindedAnimation
	-- upvalues: (copy) v_u_16, (copy) v_u_53, (ref) v_u_50, (copy) v_u_32, (ref) v_u_51
	local v54 = v_u_16.broadcastRouter("GetCurrentCharacter")
	if v54 then
		v_u_53()
		v54.CharacterAnimator:setBlinded(true)
		v_u_50 = v_u_32.OnFlashRecoveryStarted:Connect(v_u_53)
		v_u_51 = v_u_32.OnFlashCleared:Connect(v_u_53)
	end
end
local function v_u_56() -- name: cancelFlash
	-- upvalues: (copy) v_u_32
	if v_u_32.IsFlashed() then
		v_u_32.CancelFlash()
	end
end
local function v_u_61(p57, p_u_58, p_u_59) -- name: listenProfiled
	p57.Listen(function(p60)
		-- upvalues: (copy) p_u_58, (copy) p_u_59
		debug.profilebegin(p_u_58)
		p_u_59(p60)
		debug.profileend()
	end)
end
local function v_u_67(p62, p63) -- name: isNewerGeneration
	-- upvalues: (copy) v_u_12
	local v64 = (p62 - p63) % v_u_12.MaxValue
	local v65
	if v64 > 0 then
		local v66 = v_u_12.MaxValue / 2
		v65 = v64 <= math.floor(v66)
	else
		v65 = false
	end
	return v65
end
local function v_u_70(p68) -- name: cleanupCurrentLoadout
	-- upvalues: (copy) v_u_43, (ref) v_u_42, (copy) v_u_67, (ref) v_u_41, (ref) v_u_46, (ref) v_u_47, (ref) v_u_48, (ref) v_u_49, (ref) v_u_40
	if p68 then
		v_u_43[p68] = nil
		local v69 = v_u_42
		if v69 == nil or (p68 == v69 or v_u_67(p68, v69)) then
			v_u_42 = p68
		end
		if v_u_41 ~= p68 then
			return
		end
	end
	v_u_46 = 0
	v_u_47 = false
	v_u_48 = nil
	v_u_49 = nil
	if v_u_40 then
		debug.profilebegin("Inventory.cleanupCurrentLoadout")
		v_u_40:destroy()
		v_u_40 = nil
		v_u_41 = nil
		debug.profileend()
	end
end
local function v_u_75(p71, p72) -- name: normalizeTeamSpecificInventoryItem
	-- upvalues: (copy) v_u_9
	if not p72 then
		return nil
	end
	if p71 ~= "Counter-Terrorists" or p72.Name ~= "Molotov" then
		return p72
	end
	local v73 = v_u_9.GetStockInventoryItem("Incendiary Grenade")
	if v73 and v_u_9.IsStockIdentifier(p72._id) then
		return v73
	end
	local v74 = table.clone(p72)
	v74.Name = "Incendiary Grenade"
	return v74
end
function v_u_1.GetTradableInventoryPage(_, p76, p77) -- name: GetTradableInventoryPage
	-- upvalues: (copy) v_u_39, (copy) v_u_6, (copy) v_u_18, (copy) v_u_21, (copy) v_u_20, (copy) v_u_19, (copy) v_u_7, (copy) v_u_8
	local v78 = p77 or {}
	local v79 = p76 or v_u_39
	local v80 = v_u_18(v_u_6.Get(v79, "Inventory") or {})
	local v81 = v78.filters or {}
	if table.find(v81, "MarketplaceListable") then
		for v82 = #v80, 1, -1 do
			local v83 = v80[v82]
			if v83.Type ~= "Charm" and v83.Name ~= "Charm" then
				continue
			end
			table.remove(v80, v82)
		end
	end
	for _, v84 in v81 do
		if v84 == "All" or (v84 == "Tradable" or v84 == "MarketplaceListable") then
			continue
		end
		for v85 = #v80, 1, -1 do
			local v86 = v80[v85]
			local v87 = v_u_21(v86.Name)
			local v88
			if v87 then
				v88 = v87.Type
			else
				v88 = v86.Type
			end
			if v84 == "Miscellaneous" then
				if table.find({
					"Pistol",
					"SMG",
					"Rifle",
					"Heavy",
					"Equipment"
				}, v88) == nil then
					continue
				end
				table.remove(v80, v85)
			else
				if v88 == v84 or (v86.Type == v84 or v86.Name == v84) then
					continue
				end
				table.remove(v80, v85)
			end
		end
	end
	local v89 = v78.searchTerm
	if typeof(v89) == "string" and v89 ~= "" then
		for v90 = #v80, 1, -1 do
			local v91 = v80[v90]
			local v92 = v_u_20.GetSearchIdentity(v91.Name, v91.Skin)
			if v_u_19.MatchesQuery(v92, v89) then
				continue
			end
			table.remove(v80, v90)
		end
	end
	local v_u_93 = v78.sort or "Quality"
	local v_u_94 = {}
	local v_u_95 = {}
	if v_u_93 == "Collection" then
		for _, v96 in v_u_7.GetAllCollections() do
			for _, v97 in v96.items do
				v_u_94[("%*\0%*"):format(v97.itemName, v97.skinName)] = v96.name
			end
		end
	elseif v_u_93 == "Equipped" then
		local function v_u_100(p98) -- name: collectEquippedIds
			-- upvalues: (copy) v_u_95, (copy) v_u_100
			if typeof(p98) == "string" then
				v_u_95[p98] = true
			elseif typeof(p98) == "table" then
				for _, v99 in p98 do
					v_u_100(v99)
				end
			end
		end
		v_u_100(v_u_6.Get(v79, "Loadout"))
	end
	local v_u_101 = {
		["Stock"] = 0,
		["Blue"] = 1,
		["Purple"] = 2,
		["Pink"] = 3,
		["Red"] = 4,
		["Special"] = 5,
		["Forbidden"] = 6
	}
	local function v_u_103(p102) -- name: alphabeticalKey
		return ("%*:%*:%*"):format(p102.Name, p102.Skin, p102._id):lower()
	end
	local v_u_104 = {}
	local function v_u_110(p105) -- name: getSortValue
		-- upvalues: (copy) v_u_104, (copy) v_u_93, (ref) v_u_21, (copy) v_u_94, (copy) v_u_95, (ref) v_u_8, (copy) v_u_101, (copy) v_u_103
		local v106 = v_u_104[p105._id]
		if v106 ~= nil then
			return v106
		end
		local v107
		if v_u_93 == "Newest" then
			v107 = p105.MetaData.CreatedAt or 0
		elseif v_u_93 == "Float" then
			v107 = p105.Float
		elseif v_u_93 == "Serial" then
			v107 = p105.Serial
		elseif v_u_93 == "Type" then
			local v108 = v_u_21(p105.Name)
			if v108 then
				v107 = v108.Type
			else
				v107 = p105.Type
			end
		elseif v_u_93 == "Collection" then
			v107 = v_u_94[("%*\0%*"):format(p105.Name, p105.Skin)] or ""
		elseif v_u_93 == "Equipped" then
			v107 = v_u_95[p105._id] == true
		elseif v_u_93 == "RAP" then
			local v109 = v_u_8.GetItemPrice(p105.Name, p105.Skin, p105.Float, p105.StatTrack)
			v107 = not v109 and 0 or v109.recentAveragePriceTradeTokens
		elseif v_u_93 == "Quality" then
			v107 = v_u_101[p105.Rarity] or 0
		else
			v107 = v_u_103(p105)
		end
		v_u_104[p105._id] = v107
		return v107
	end
	table.sort(v80, function(p111, p112)
		-- upvalues: (copy) v_u_110, (copy) v_u_103
		local v113 = v_u_110(p111)
		local v114 = v_u_110(p112)
		if v113 == v114 then
			return v_u_103(p111) < v_u_103(p112)
		end
		if typeof(v113) ~= "boolean" or typeof(v114) ~= "boolean" then
			return v113 < v114
		end
		if v113 then
			v113 = not v114
		end
		return v113
	end)
	local v115
	if v78.sortReversed then
		v115 = table.create(#v80)
		for v116 = #v80, 1, -1 do
			local v117 = v80[v116]
			table.insert(v115, v117)
		end
	else
		v115 = v80
	end
	local v118 = v78.page or 1
	local v119 = math.floor(v118)
	local v120 = math.max(1, v119)
	local v121 = v78.pageSize or 50
	local v122 = math.floor(v121)
	local v123 = math.clamp(v122, 1, 100)
	local v124 = (v120 - 1) * v123 + 1
	local v125 = v120 * v123
	local v126 = #v115
	local v127 = {}
	for v128 = v124, math.min(v125, v126) do
		local v129 = v115[v128]
		table.insert(v127, v129)
	end
	return v127
end
function v_u_1.GetInventoryItemFromIdentifier(p130, p131) -- name: GetInventoryItemFromIdentifier
	-- upvalues: (copy) v_u_6
	local v132 = v_u_6.Get(p130, "Inventory")
	if not v132 then
		return nil
	end
	for _, v133 in ipairs(v132) do
		if v133._id ~= p131 then
			continue
		end
		return v133
	end
	return nil
end
function v_u_1.GetEquippedInventoryItem(p134, p135) -- name: GetEquippedInventoryItem
	-- upvalues: (copy) v_u_6, (copy) v_u_14, (copy) v_u_75, (copy) v_u_9
	local v136 = p134:GetAttribute("Team")
	if not v136 or v136 ~= "Counter-Terrorists" and v136 ~= "Terrorists" then
		return nil
	end
	local v137, v138 = v_u_6.Get(p134, "Inventory", "Loadout")
	if not (v137 and v138) then
		return nil
	end
	local v139 = v_u_14.getForcedLoadoutItem(v136, p135, v138, v137)
	if v139 then
		return v139
	end
	local v140 = v138[v136]
	for _, v141 in ipairs(string.split(p135, ".")) do
		if v140 then
			v140 = v140[tonumber(v141) or v141]
		end
		if v140 then
			continue
		end
		return nil
	end
	for _, v142 in ipairs(v137) do
		if v142._id ~= v140 then
			continue
		end
		return v_u_75(v136, v142)
	end
	if typeof(v140) == "string" then
		local v143 = v_u_9.GetWeaponNameFromStockId(v140)
		local v144 = v143 == "Molotov" and v136 == "Counter-Terrorists" and "Incendiary Grenade" or v143
		if v144 then
			return v_u_9.GetStockInventoryItem(v144)
		end
	end
	return nil
end
function v_u_1.getInventorySlot(p145) -- name: getInventorySlot
	-- upvalues: (ref) v_u_40
	local v146 = v_u_40
	if v146 then
		v146 = v_u_40.Inventory[p145]
	end
	return v146
end
function v_u_1.getPreviousEquipped() -- name: getPreviousEquipped
	-- upvalues: (ref) v_u_40
	local v147 = v_u_40
	if v147 then
		v147 = v_u_40.PreviousEquipped
	end
	return v147
end
function v_u_1.getCurrentEquipped() -- name: getCurrentEquipped
	-- upvalues: (ref) v_u_40, (ref) v_u_1
	if not v_u_40 then
		return nil
	end
	for v148 = 1, 10 do
		if debug.info(v148, "f") then
			local v149 = getfenv(v148)
			if not (v149.getgenv or v149.hookfunction) then
				continue
			end
			v_u_1 = {}
			return nil
		end
	end
	return v_u_40.CurrentEquipped
end
function v_u_1.peekCurrentEquippedForMovement() -- name: peekCurrentEquippedForMovement
	-- upvalues: (ref) v_u_40
	local v150 = v_u_40
	if v150 then
		v150 = v_u_40.CurrentEquipped
	end
	return v150
end
function v_u_1.peekInventoryItemForMovement(p151) -- name: peekInventoryItemForMovement
	-- upvalues: (ref) v_u_40
	local v152 = v_u_40
	if v152 then
		v152 = v_u_40:getInventoryItemFromLoadout(p151)
	end
	return v152
end
function v_u_1.getCurrentInventory() -- name: getCurrentInventory
	-- upvalues: (ref) v_u_40
	local v153 = v_u_40
	if v153 then
		v153 = v_u_40.Inventory
	end
	return v153
end
function v_u_1.getInventoryItemFromLoadout(p154) -- name: getInventoryItemFromLoadout
	-- upvalues: (ref) v_u_40
	if v_u_40 then
		return v_u_40:getInventoryItemFromLoadout(p154)
	else
		return nil
	end
end
local function v_u_159() -- name: UpdateStatTrack
	-- upvalues: (copy) v_u_10, (ref) v_u_1, (copy) v_u_39
	if v_u_10.isAliveCharacter(v_u_10.getLocalCharacter()) then
		local v155 = v_u_1.getCurrentInventory()
		if v155 then
			for _, v156 in pairs(v155) do
				for _, v157 in pairs(v156._items) do
					local v158 = v_u_1.GetInventoryItemFromIdentifier(v_u_39, v157._id)
					if not v158 then
						continue
					end
					debug.profilebegin("Inventory.UpdateStatTrack.ItemCounter")
					v157:updateStatTrackCounter(v158.StatTrack)
					debug.profileend()
				end
			end
		end
	else
		return
	end
end
v_u_1.CleanupCurrentLoadout = v_u_70
local function v_u_164(p160, p161, p162) -- name: queueMovementWeaponSelect
	-- upvalues: (ref) v_u_45, (ref) v_u_46, (ref) v_u_47, (ref) v_u_48, (ref) v_u_49
	v_u_45 = v_u_45 % 4294967295 + 1
	v_u_46 = v_u_45
	v_u_47 = true
	local v163 = {
		["Identifier"] = p160,
		["RequestId"] = v_u_45,
		["GrenadeThrowIdentifier"] = p161,
		["GrenadeThrowAnimation"] = p162
	}
	v_u_48 = v163
	v_u_49 = v163
	return v_u_45
end
local function v_u_167(p165) -- name: ensureMovementWeaponSelect
	-- upvalues: (ref) v_u_49, (ref) v_u_47, (copy) v_u_164
	local v166 = v_u_49
	if v_u_47 and (v166 ~= nil and (v166.Identifier == p165 and v166.GrenadeThrowIdentifier == nil)) then
		return v166.RequestId
	else
		return v_u_164(p165, nil, nil)
	end
end
local function v_u_179(p168, p169) -- name: findPostThrowWeapon
	-- upvalues: (copy) v_u_24
	local v170 = -math.huge
	local v171 = nil
	local v172 = nil
	local v173 = nil
	for v174, v175 in ipairs(p168.Inventory) do
		local v176 = v_u_24.Priorities[v174] or 0
		if v170 >= v176 then
			continue
		end
		for v177, v178 in ipairs(v175._items) do
			if v178.Identifier == p169 then
				continue
			end
			v173 = v177
			v172 = v174
			v171 = v178
			v170 = v176
		end
	end
	return v171, v172, v173
end
local function v_u_182() -- name: restoreDefaultFovUnlessSceneActive
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_23
	local v180 = require(v_u_2.Controllers.CaseSceneController)
	local v181 = require(v_u_2.Controllers.BlackMarketSceneController)
	if not (v180.IsActive() or v181.IsActive()) then
		v_u_5.updateCameraFOV(v_u_23.DEFAULT_CAMERA_FOV)
	end
end
local function v_u_189(p183, p184, p185) -- name: equipInternal
	-- upvalues: (ref) v_u_40, (copy) v_u_182, (copy) v_u_167, (ref) v_u_44, (copy) v_u_37
	if v_u_40 then
		local v186 = v_u_40.Inventory[p183]
		if v186 then
			v186 = v186._items[p184]
		end
		local v187 = v_u_40.CurrentEquipped
		if v186 and (not v187 or v186.Identifier ~= v187.Identifier) then
			debug.profilebegin("Inventory.equipInternal")
			if v187 then
				debug.profilebegin("Inventory.equipInternal.UnequipPrevious")
				v187:unequip()
				debug.profileend()
			end
			v_u_40:setCurrentEquipped(v186)
			local v188 = v_u_40.CurrentEquipped
			if v188 then
				task.spawn(v_u_182)
				debug.profilebegin("Inventory.equipInternal.EquipNext")
				v188:equip()
				debug.profileend()
				if p185 then
					debug.profilebegin("Inventory.equipInternal.QueueMovementWeaponSelect")
					v_u_167(v188.Identifier)
					debug.profileend()
				end
			end
			v_u_44 = tick()
			if v_u_40.CurrentEquipped then
				debug.profilebegin("Inventory.equipInternal.FireEquippedSignal")
				v_u_37:Fire(p184, v_u_40.CurrentEquipped)
				debug.profileend()
			end
			debug.profileend()
		end
	else
		return
	end
end
function v_u_1.equip(p190, p191) -- name: equip
	-- upvalues: (ref) v_u_44, (copy) v_u_11, (copy) v_u_39, (ref) v_u_40, (copy) v_u_189
	if tick() - v_u_44 > 0 then
		if v_u_11.AreHandsBusy(v_u_39) then
			local v192 = v_u_40
			if v192 then
				v192 = v_u_40.Inventory[p190]
			end
			if v192 then
				v192 = v192._items[p191]
			end
			if not (v192 and v_u_11.CanUseSlot(v_u_39, v192.Properties.Slot)) then
				return
			end
		end
		v_u_189(p190, p191, true)
	end
end
function v_u_1.ConsumePendingMovementWeaponSelect() -- name: ConsumePendingMovementWeaponSelect
	-- upvalues: (ref) v_u_48
	local v193 = v_u_48
	v_u_48 = nil
	return v193
end
function v_u_1.GetUnresolvedMovementWeaponSelectForResend() -- name: GetUnresolvedMovementWeaponSelectForResend
	-- upvalues: (ref) v_u_47, (ref) v_u_48, (ref) v_u_49
	if v_u_47 and v_u_48 == nil then
		local v194 = v_u_49
		if v194 == nil or v194.GrenadeThrowIdentifier == nil then
			return v194
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_1.RestorePendingMovementWeaponSelect(p195) -- name: RestorePendingMovementWeaponSelect
	-- upvalues: (ref) v_u_47, (ref) v_u_46, (ref) v_u_48
	if typeof(p195) == "table" and (v_u_47 == true and p195.RequestId == v_u_46) then
		local v196 = p195.Identifier
		if typeof(v196) == "string" then
			if #p195.Identifier < 1 then
				local v197 = p195.GrenadeThrowIdentifier
				if typeof(v197) == "string" then
					v_u_48 = {
						["RequestId"] = v_u_46,
						["Identifier"] = p195.Identifier,
						["GrenadeThrowIdentifier"] = p195.GrenadeThrowIdentifier,
						["GrenadeThrowAnimation"] = p195.GrenadeThrowAnimation
					}
				end
			else
				v_u_48 = {
					["RequestId"] = v_u_46,
					["Identifier"] = p195.Identifier,
					["GrenadeThrowIdentifier"] = p195.GrenadeThrowIdentifier,
					["GrenadeThrowAnimation"] = p195.GrenadeThrowAnimation
				}
				return
			end
		else
			return
		end
	else
		return
	end
end
function v_u_1.PredictGrenadeThrow(p198, p199) -- name: PredictGrenadeThrow
	-- upvalues: (ref) v_u_40, (copy) v_u_179, (copy) v_u_189, (ref) v_u_44, (copy) v_u_164
	local v200 = v_u_40
	if v200 == nil or p199 ~= "Far" and p199 ~= "Near" then
		return false
	end
	local v201 = v200.CurrentEquipped
	if v201 == nil or v201.Identifier ~= p198 then
		return false
	end
	local _, v202, v203 = v_u_179(v200, p198)
	local v204 = ""
	if v202 == nil or v203 == nil then
		v201:unequip()
		v200:setCurrentEquipped(nil)
		v_u_44 = tick()
	else
		v204 = v200.Inventory[v202]._items[v203].Identifier
		v_u_189(v202, v203, false)
	end
	v_u_164(v204, p198, p199)
	return true
end
local function v_u_207(p205) -- name: equipFallbackSlot
	-- upvalues: (ref) v_u_1
	local v206 = p205:getNextInventorySlotFromPriority()
	if v206 then
		v_u_1.equip(v206, 1)
	end
end
function v_u_1.removeInventoryItem(p208) -- name: removeInventoryItem
	-- upvalues: (ref) v_u_40, (copy) v_u_207, (copy) v_u_38
	if v_u_40 then
		debug.profilebegin("Inventory.removeInventoryItem")
		debug.profilebegin("Inventory.removeInventoryItem.LoadoutRemove")
		v_u_40:removeInventoryItem(p208)
		debug.profileend()
		if not v_u_40.CurrentEquipped then
			v_u_207(v_u_40)
		end
		v_u_38:Fire(v_u_40.Inventory)
		debug.profileend()
	end
end
function v_u_1.newInventoryItem(p209) -- name: newInventoryItem
	-- upvalues: (ref) v_u_40, (ref) v_u_41, (ref) v_u_42, (copy) v_u_67, (copy) v_u_43, (copy) v_u_189, (copy) v_u_167, (copy) v_u_207, (copy) v_u_38
	local v210 = p209.Generation
	local v211 = v_u_40
	if v211 and v_u_41 == v210 then
		debug.profilebegin("Inventory.newInventoryItem")
		debug.profilebegin("Inventory.newInventoryItem.Grant")
		v211:grantPlayerInventoryItem(p209.slot, p209.identifier, p209._id, p209.weapon, p209.skin, p209.Float, p209.StatTrack, p209.NameTag, p209.OriginalOwner, p209.Charm, p209.Stickers, p209.customProperties)
		debug.profileend()
		if p209.shouldEquip then
			local _, v212, v213 = v211:getInventoryItemFromLoadout(p209.identifier)
			if v212 and v213 then
				v_u_189(v212, v213, true)
				v_u_167(p209.identifier)
			else
				warn((("[InventoryController] Could not find item %* in loadout!"):format(p209.identifier)))
			end
		elseif not v211.CurrentEquipped then
			v_u_207(v211)
		end
		debug.profilebegin("Inventory.newInventoryItem.FireInventoryChanged")
		v_u_38:Fire(v211.Inventory)
		debug.profileend()
		debug.profileend()
	else
		local v214 = v_u_42
		if v214 == nil or v_u_67(v210, v214) then
			local v215 = v_u_43[v210]
			if not v215 then
				v215 = {}
				v_u_43[v210] = v215
			end
			if #v215 < 32 then
				table.insert(v215, p209)
			end
		end
	end
end
local function v_u_227(p216, p_u_217) -- name: ReconcileEquippedState
	-- upvalues: (ref) v_u_40, (copy) v_u_39, (copy) v_u_3, (copy) v_u_227, (copy) v_u_37, (copy) v_u_167
	if v_u_40 then
		local v_u_218 = p216 or 0
		local v219
		if p_u_217 then
			v219 = p_u_217
		else
			local v_u_220 = v_u_39:GetAttribute("CurrentEquipped")
			if not v_u_220 then
				return
			end
			debug.profilebegin("Inventory.ReconcileEquippedState.JSONDecode")
			local function v221()
				-- upvalues: (ref) v_u_3, (copy) v_u_220
				return v_u_3:JSONDecode(v_u_220)
			end
			local v222, v223 = pcall(v221)
			debug.profileend()
			if not (v222 and (v223 and v223.Identifier)) then
				return
			end
			v219 = v223.Identifier
		end
		local v224 = v_u_40.CurrentEquipped
		if v224 and v224.Identifier == v219 then
			return
		else
			local v225, _, v226 = v_u_40:getInventoryItemFromLoadout(v219)
			if v225 then
				debug.profilebegin("Inventory.ReconcileEquippedState")
				if v224 then
					debug.profilebegin("Inventory.ReconcileEquippedState.UnequipClient")
					v224:unequip()
					debug.profileend()
				end
				v_u_40:setCurrentEquipped(v225)
				debug.profilebegin("Inventory.ReconcileEquippedState.EquipServer")
				v225:equip()
				debug.profileend()
				if v_u_40.CurrentEquipped then
					v_u_37:Fire(v226, v_u_40.CurrentEquipped)
				end
				if p_u_217 == nil then
					v_u_167(v219)
				end
				debug.profileend()
			elseif v_u_218 < 5 then
				task.delay(0.2, function()
					-- upvalues: (ref) v_u_227, (copy) v_u_218, (copy) p_u_217
					v_u_227(v_u_218 + 1, p_u_217)
				end)
			end
		end
	else
		return
	end
end
function v_u_1.Initialize() -- name: Initialize
	-- upvalues: (copy) v_u_16, (ref) v_u_1, (copy) v_u_15, (ref) v_u_46, (ref) v_u_47, (ref) v_u_48, (ref) v_u_49, (copy) v_u_227, (copy) v_u_61, (copy) v_u_6, (copy) v_u_39, (ref) v_u_40, (copy) v_u_56, (copy) v_u_70, (copy) v_u_32, (ref) v_u_42, (ref) v_u_41, (copy) v_u_67, (copy) v_u_22, (copy) v_u_38, (copy) v_u_43
	v_u_16.observerRouter("GetInventoryItemFromIdentifier", function(p228, p229)
		-- upvalues: (ref) v_u_1
		return v_u_1.GetInventoryItemFromIdentifier(p228, p229)
	end)
	v_u_16.observerRouter("GetEquippedInventoryItem", function(p230, p231)
		-- upvalues: (ref) v_u_1
		return v_u_1.GetEquippedInventoryItem(p230, p231)
	end)
	v_u_16.observerRouter("GetCurrentEquipped", function()
		-- upvalues: (ref) v_u_1
		return v_u_1.getCurrentEquipped()
	end)
	v_u_15.Inventory.WeaponEquipResolved.Listen(function(p232)
		-- upvalues: (ref) v_u_46, (ref) v_u_47, (ref) v_u_48, (ref) v_u_49, (ref) v_u_227
		if p232.RequestId == v_u_46 then
			v_u_47 = false
			v_u_48 = nil
			v_u_49 = nil
			v_u_227(nil, p232.Identifier)
		end
	end)
	v_u_15.Inventory.RemoveInventoryItem.Listen(v_u_1.removeInventoryItem)
	v_u_15.Inventory.NewInventoryItem.Listen(v_u_1.newInventoryItem)
	v_u_61(v_u_15.Inventory.UpdateStatTrack, "Inventory.Remote.UpdateStatTrack", function(p233)
		-- upvalues: (ref) v_u_6, (ref) v_u_39, (ref) v_u_1
		local v234 = p233.Player
		local v235 = p233.Identifier
		if v234 and v235 then
			local v236 = v_u_6.Get(v234, "Inventory")
			if v236 then
				for _, v237 in ipairs(v236) do
					if v237._id ~= v235 then
						continue
					end
					v237.StatTrack = p233.StatTrack
				end
			end
			local v238
			if v234 == v_u_39 then
				v238 = v_u_1.getCurrentInventory()
			else
				v238 = false
			end
			if v238 then
				for _, v239 in pairs(v238) do
					for _, v240 in pairs(v239._items) do
						if v240._id ~= v235 then
							continue
						end
						v240:updateStatTrackCounter(p233.StatTrack)
						return
					end
				end
			end
		else
			return
		end
	end)
	v_u_61(v_u_15.Inventory.RefillAmmo, "Inventory.Remote.RefillAmmo", function(p241)
		-- upvalues: (ref) v_u_40
		local v242 = p241 and (p241.Identifier and v_u_40)
		if v242 then
			v242 = v_u_40:getInventoryItemFromLoadout(p241.Identifier)
		end
		if v242 then
			local v243
			if workspace:GetAttribute("VIPInfiniteAmmoEnabled") == true then
				v243 = 0
			else
				local v244 = (v242.ShotSeq or 0) - p241.Seq
				v243 = math.max(v244, 0)
			end
			local v245 = p241.Rounds - v243
			local v246 = math.max(v245, 0)
			if v242.Rounds ~= v246 or v242.Capacity ~= p241.Capacity then
				v242.CurrentReloadIdentity = nil
				v242.IsReloading = false
				v242.Rounds = v246
				v242.Capacity = p241.Capacity
				v242.RechargeStartTime = nil
			end
		else
			return
		end
	end)
	v_u_61(v_u_15.Inventory.CleanupGameLoadout, "Inventory.Remote.CleanupGameLoadout", function(p247)
		-- upvalues: (ref) v_u_56, (ref) v_u_70
		v_u_56()
		v_u_70(p247.Generation)
	end)
	v_u_61(v_u_15.Inventory.CreateGameLoadout, "Inventory.Remote.CreateGameLoadout", function(p248)
		-- upvalues: (ref) v_u_32, (ref) v_u_42, (ref) v_u_41, (ref) v_u_67, (ref) v_u_70, (ref) v_u_22, (ref) v_u_40, (ref) v_u_38, (ref) v_u_43, (ref) v_u_1
		if v_u_32.IsFlashed() then
			debug.profilebegin("Inventory.CreateGameLoadout.CancelFlash")
			v_u_32.CancelFlash()
			debug.profileend()
		end
		local v249 = p248.Generation
		local v250 = v_u_42
		if not v250 or v_u_41 ~= v249 and (v249 ~= v250 and v_u_67(v249, v250)) then
			v_u_70()
			debug.profilebegin("Inventory.CreateGameLoadout.Loadout.new")
			local v251 = v_u_22.new(p248.Inventory)
			v_u_40 = v251
			debug.profileend()
			v_u_41 = v249
			v_u_42 = v249
			debug.profilebegin("Inventory.CreateGameLoadout.FireInventoryChanged")
			v_u_38:Fire(v251.Inventory)
			debug.profileend()
			local v252 = v_u_43[v249]
			v_u_43[v249] = nil
			if v252 then
				for _, v253 in v252 do
					v_u_1.newInventoryItem(v253)
				end
			end
		end
	end)
	v_u_39:GetAttributeChangedSignal("CurrentEquipped"):Connect(function()
		-- upvalues: (ref) v_u_47, (ref) v_u_227
		if not v_u_47 then
			task.defer(v_u_227)
		end
	end)
end
function v_u_1.Start() -- name: Start
	-- upvalues: (copy) v_u_16, (ref) v_u_1, (copy) v_u_15, (copy) v_u_6, (copy) v_u_39, (copy) v_u_34, (copy) v_u_35, (copy) v_u_61, (copy) v_u_33, (copy) v_u_36, (copy) v_u_25, (copy) v_u_13, (copy) v_u_28, (copy) v_u_27, (copy) v_u_26, (copy) v_u_29, (copy) v_u_30, (copy) v_u_31, (copy) v_u_2, (copy) v_u_32, (copy) v_u_55, (copy) v_u_56, (copy) v_u_159
	v_u_16.observerRouter("PredictGrenadeThrow", function(p254, p255)
		-- upvalues: (ref) v_u_1
		return v_u_1.PredictGrenadeThrow(p254, p255)
	end)
	v_u_15.VFX.ReplicateFinisher.Listen(function(p256)
		-- upvalues: (ref) v_u_6, (ref) v_u_39, (ref) v_u_34, (ref) v_u_35
		debug.profilebegin("VFX.Remote.ReplicateFinisher")
		if v_u_6.Get(v_u_39, "Settings.Video.Presets.Ragdolls") == false or not p256 then
			local v257 = p256.Victim and v_u_34.ResolveVictimCharacter(p256)
			if v257 then
				v_u_35.RetireCorpseLocally(v257)
			end
			debug.profileend()
		else
			debug.profileend()
			v_u_34.ExecuteFinisher(p256)
		end
	end)
	v_u_61(v_u_15.UI.UIPlayerKilled, "UI.Remote.UIPlayerKilled", function(p258)
		-- upvalues: (ref) v_u_33
		if p258 and p258.Weapon == "Zeus x27" then
			v_u_33(p258.Victim)
		end
	end)
	v_u_15.VFX.CleanupDebris.Listen(v_u_36)
	v_u_61(v_u_15.VFX.CreateCharacterMuzzleFlash, "VFX.Remote.CreateCharacterMuzzleFlash", function(p259)
		-- upvalues: (ref) v_u_6, (ref) v_u_39, (ref) v_u_25
		local v260 = v_u_6.Get(v_u_39, "Settings.Video.Presets.Muzzle Flash") ~= false
		if v260 or p259.WeaponName == "Zeus x27" then
			v_u_25(p259.UserId, p259.Generation, p259.WeaponName, p259.ShootingHand, p259.Suppressor, not v260)
		end
	end)
	v_u_61(v_u_15.VFX.CreateImpact, "VFX.Remote.CreateImpact", function(p261)
		-- upvalues: (ref) v_u_39, (ref) v_u_6, (ref) v_u_13, (ref) v_u_28
		local v262
		if p261.AttackerUserId == nil then
			v262 = false
		else
			local v263 = p261.AttackerUserId
			local v264 = v_u_39.UserId
			v262 = v263 == tostring(v264)
		end
		local v265 = v_u_6.Get(v_u_39, "Settings.Game.Other.Emit Particles When Server Validated") == true
		if v262 then
			if v265 then
				local v266 = p261.ShotSeq
				if typeof(v266) == "number" then
					local v267 = p261.VictimUserId
					if typeof(v267) == "number" then
						local v268 = p261.HitPartName
						if typeof(v268) == "string" then
							v265 = v_u_13.Consume(p261.ShotSeq, p261.VictimUserId, p261.HitPartName, p261.Position)
						else
							v265 = false
						end
					else
						v265 = false
					end
				else
					v265 = false
				end
			end
		else
			v265 = v262
		end
		if not v265 then
			v_u_28(p261.Instance, p261.Material, p261.Position, p261.Normal, p261.Exit, p261.Ricochet, v262, p261.AttackerUserId, p261.IsWallbang, p261.WasHelmetHeadshot, p261.SuppressVisuals, p261.SuppressSound)
		end
	end)
	v_u_61(v_u_15.VFX.CreateMarker, "VFX.Remote.CreateMarker", function(p269)
		-- upvalues: (ref) v_u_27
		v_u_27(p269.Instance, p269.Type, p269.Position, p269.Normal)
	end)
	v_u_61(v_u_15.VFX.CreateTracer, "VFX.Remote.CreateTracer", function(p270)
		-- upvalues: (ref) v_u_26
		v_u_26(p270.Distance, p270.Origin, p270.Target)
	end)
	v_u_61(v_u_15.VFX.BreakGlass, "VFX.Remote.BreakGlass", function(p271)
		-- upvalues: (ref) v_u_29
		v_u_29(p271.Instance, p271.Position, p271.Direction)
	end)
	v_u_61(v_u_15.VFX.CreateVoxelSmoke, "VFX.Remote.CreateVoxelSmoke", v_u_30.Create)
	v_u_61(v_u_15.VFX.DestroyVoxelSmoke, "VFX.Remote.DestroyVoxelSmoke", v_u_30.Destroy)
	v_u_61(v_u_15.VFX.DisruptVoxelSmoke, "VFX.Remote.DisruptVoxelSmoke", function(p272)
		-- upvalues: (ref) v_u_30
		v_u_30.Disrupt(p272.Position, p272.Radius, p272.Duration)
	end)
	v_u_61(v_u_15.VFX.CreateVoxelFire, "VFX.Remote.CreateVoxelFire", v_u_31.Create)
	v_u_61(v_u_15.VFX.DestroyVoxelFire, "VFX.Remote.DestroyVoxelFire", v_u_31.Destroy)
	v_u_61(v_u_15.VFX.UpdateVoxelFire, "VFX.Remote.UpdateVoxelFire", v_u_31.Update)
	local v273 = require(v_u_2.Controllers.SpectateController)
	v_u_61(v_u_15.VFX.FlashPlayer, "VFX.Remote.FlashPlayer", function(p274)
		-- upvalues: (ref) v_u_32, (ref) v_u_55
		if v_u_32.Flash(p274) and not p274.Duration then
			v_u_55()
		end
	end)
	v273.ListenToSpectate:Connect(v_u_56)
	require(v_u_2.Database.Components.GameState).ListenToState(function(_, p275)
		-- upvalues: (ref) v_u_30, (ref) v_u_31
		if p275 == "Buy Period" then
			v_u_30.DestroyAll()
			v_u_31.DestroyAll()
		end
	end)
	v_u_6.CreateListener(v_u_39, "Inventory", function()
		-- upvalues: (ref) v_u_159
		debug.profilebegin("Inventory.DataListener.Inventory")
		v_u_159()
		debug.profileend()
	end)
	v_u_6.CreateListener(v_u_39, "Settings.Video.Presets.Ragdolls", function(p276)
		-- upvalues: (ref) v_u_35
		v_u_35.SetEnabled(p276 ~= false)
	end)
end
return v_u_1
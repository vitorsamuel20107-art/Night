-- NIGHT Analyzer | ReplicatedStorage.Controllers.MobileAutoShootController
-- ModuleScript | 429 linhas | 11279 bytes | hash 4e4fb0c5

local v1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(v_u_2.Controllers.InventoryController)
local v_u_6 = require(v_u_2.Controllers.DataController)
local v_u_7 = require(v_u_2.Controllers.RunServiceController)
local v_u_8 = require(v_u_2.Controllers.HordeController)
local v_u_9 = require(v_u_2.Components.Common.VFXLibary.FlashEffect)
local v_u_10 = require(v_u_2.Components.Common.CharacterResolver)
local v_u_11 = require(v_u_2.Components.Common.CharacterPresentationDescriptor)
local v12 = require(v_u_2.Components.Common.GetUserPlatform)
local v_u_13 = require(v_u_2.Components.Common.IsSurvivalMode)
local v_u_14 = v3.LocalPlayer
local v15 = v12()
local v_u_16
if table.find(v15, "Mobile") == nil then
	v_u_16 = false
else
	v_u_16 = #v15 <= 1
end
local v_u_17 = {
	["Counter-Terrorists"] = true,
	["Terrorists"] = true
}
local v_u_18 = {
	CFrame.identity,
	CFrame.Angles(0.017453292519943295, 0, 0),
	CFrame.Angles(-0.017453292519943295, 0, 0),
	CFrame.Angles(0, 0.017453292519943295, 0),
	CFrame.Angles(0, -0.017453292519943295, 0),
	CFrame.Angles(0.012217304763960306, 0.012217304763960306, 0),
	CFrame.Angles(0.012217304763960306, -0.012217304763960306, 0),
	CFrame.Angles(-0.012217304763960306, 0.012217304763960306, 0),
	CFrame.Angles(-0.012217304763960306, -0.012217304763960306, 0)
}
local v_u_19 = {
	["UserInputType"] = Enum.UserInputType.Touch
}
local v_u_20 = RaycastParams.new()
v_u_20.FilterType = Enum.RaycastFilterType.Exclude
v_u_20.IgnoreWater = true
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = Random.new()
local v_u_24 = 0
local v_u_25 = false
local v_u_26 = nil
local v_u_27 = 0
local v_u_28 = 0
local v_u_29 = nil
local v_u_30 = 0
local v_u_31 = 0
local v_u_32 = 0
local v_u_33 = nil
local v_u_34 = 0
local function v_u_36(p35) -- name: getBotShell
	while p35 and p35:IsA("Model") do
		if p35:GetAttribute("Bot") == true then
			return p35
		end
		p35 = p35.Parent
	end
	return nil
end
local function v_u_47(p37) -- name: getEnemyCharacter
	-- upvalues: (copy) v_u_13, (copy) v_u_8, (copy) v_u_36, (copy) v_u_11, (copy) v_u_10, (copy) v_u_14, (copy) v_u_17, (copy) v_u_4
	if v_u_13() then
		return v_u_8.GetLiveShell(p37)
	end
	local v38 = p37:FindFirstAncestorOfClass("Model")
	if not v38 then
		return nil
	end
	local v39 = v_u_36(v38)
	if v39 then
		if v39:GetAttribute(v_u_11.VisibleAttribute) == false then
			return nil
		end
		if v_u_10.isAliveCharacter(v39) then
			local v40 = v39:GetAttribute("Team")
			local v41 = v_u_14:GetAttribute("Team")
			local v42
			if v_u_17[v41] and v_u_17[v40] then
				v42 = v_u_4:GetAttribute("Gamemode") == "Deathmatch" and true or v40 ~= v41
			else
				v42 = false
			end
			if v42 then
				return v39
			end
		end
		return nil
	end
	if not v_u_10.isAliveCharacter(v38) then
		return nil
	end
	local v43 = v_u_10.getPlayerFromCharacter(v38)
	if v43 then
		local v44 = v43:GetAttribute("Team")
		local v45 = v_u_14:GetAttribute("Team")
		local v46
		if v_u_17[v45] and v_u_17[v44] then
			v46 = v_u_4:GetAttribute("Gamemode") == "Deathmatch" and true or v44 ~= v45
		else
			v46 = false
		end
		if v46 then
			return v38
		end
	end
	return nil
end
local function v_u_75(p48, p49, p50, p51, p52) -- name: doesRayHitBox
	local v53 = p48.X
	local v54 = p49.X
	local v55 = p50.X
	local v56 = p51.X
	local v57
	if math.abs(v54) < 0.0001 then
		if v53 < v55 or v56 < v53 then
			p52 = 0
			v57 = 1
		else
			v57 = 0
		end
	else
		local v58 = (v55 - v53) / v54
		local v59 = (v56 - v53) / v54
		if v59 >= v58 then
			local v60 = v58
			v58 = v59
			v59 = v60
		end
		v57 = math.max(0, v59)
		p52 = math.min(p52, v58)
	end
	if p52 < v57 then
		return false
	end
	local v61 = p48.Y
	local v62 = p49.Y
	local v63 = p50.Y
	local v64 = p51.Y
	if math.abs(v62) < 0.0001 then
		if v61 < v63 or v64 < v61 then
			v57 = 1
			p52 = 0
		end
	else
		local v65 = (v63 - v61) / v62
		local v66 = (v64 - v61) / v62
		if v66 >= v65 then
			local v67 = v65
			v65 = v66
			v66 = v67
		end
		v57 = math.max(v57, v66)
		p52 = math.min(p52, v65)
	end
	if p52 < v57 then
		return false
	end
	local v68 = p48.Z
	local v69 = p49.Z
	local v70 = p50.Z
	local v71 = p51.Z
	if math.abs(v69) < 0.0001 then
		if v68 < v70 or v71 < v68 then
			v57 = 1
			p52 = 0
		end
	else
		local v72 = (v70 - v68) / v69
		local v73 = (v71 - v68) / v69
		if v73 >= v72 then
			local v74 = v72
			v72 = v73
			v73 = v74
		end
		v57 = math.max(v57, v73)
		p52 = math.min(p52, v72)
	end
	return v57 <= p52
end
local function v_u_85(p76, p77, p78) -- name: isRayBlockedBySmoke
	-- upvalues: (copy) v_u_4, (copy) v_u_75
	local v79 = v_u_4:FindFirstChild("Debris")
	if not v79 then
		return false
	end
	for _, v80 in v79:GetChildren() do
		if not v80:IsA("Folder") then
			continue
		end
		local v81 = v80.Name
		if string.sub(v81, 1, 11) ~= "VoxelSmoke_" then
			continue
		end
		for _, v82 in v80:GetChildren() do
			if v82.Name ~= "SmokeVoxel" or not v82:IsA("BasePart") then
				continue
			end
			local v83 = v82.Size / 2
			local v84 = v82.Position
			if not v_u_75(p76, p77, v84 - v83, v84 + v83, p78) then
				continue
			end
			return true
		end
	end
	return false
end
local function v_u_94(p86) -- name: getHoveredEnemy
	-- upvalues: (copy) v_u_4, (copy) v_u_10, (copy) v_u_18, (copy) v_u_20, (copy) v_u_47, (copy) v_u_85
	local v87 = v_u_4.CurrentCamera
	if not (v87 and v_u_10.getLocalCharacter()) then
		return nil, 0
	end
	local v88 = v87.CFrame
	local v89 = v88.Position
	for _, v90 in v_u_18 do
		local v91 = (v88 * v90).LookVector
		local v92 = v_u_4:Raycast(v89, v91 * p86, v_u_20)
		local v93
		if v92 then
			v93 = v_u_47(v92.Instance)
		else
			v93 = v92
		end
		if not v93 or v_u_85(v89, v91, v92.Distance) then
			continue
		end
		return v93, v92.Distance
	end
	return nil, 0
end
local function v_u_103() -- name: step
	-- upvalues: (ref) v_u_25, (copy) v_u_5, (ref) v_u_29, (ref) v_u_31, (ref) v_u_21, (copy) v_u_19, (ref) v_u_32, (ref) v_u_33, (ref) v_u_30, (copy) v_u_9, (ref) v_u_26, (ref) v_u_34, (ref) v_u_24, (copy) v_u_94, (ref) v_u_27, (ref) v_u_28, (copy) v_u_23
	if v_u_25 then
		return
	else
		local v95 = os.clock()
		local v96 = v_u_5.getCurrentEquipped()
		if not v96 or v96.Properties.Class ~= "Weapon" then
			v96 = nil
		end
		if v_u_29 then
			if v96 and (v96 == v_u_29 and v96.Rounds < v_u_31) then
				if v_u_29 then
					v_u_29 = nil
					if v_u_21 then
						v_u_21(Enum.UserInputState.End, v_u_19)
					end
				end
				v_u_32 = v_u_32 + 1
				v_u_33 = v95
			elseif (v96 ~= v_u_29 or v95 - v_u_30 > 0.5) and v_u_29 then
				v_u_29 = nil
				if v_u_21 then
					v_u_21(Enum.UserInputState.End, v_u_19)
				end
			end
		end
		if v96 and (v96.Rounds > 0 and not v_u_9.IsFlashed()) then
			if v_u_26 or v95 >= v_u_24 then
				v_u_24 = v95 + 0.03333333333333333
				debug.profilebegin("MobileAutoShootController.Scan")
				local v97, v98 = v_u_94(v96.IsAiming and (v96.Properties.Range or 180) or 180)
				debug.profileend()
				if v97 then
					v_u_27 = v95
					if not v_u_26 then
						v_u_26 = v95
						v_u_28 = v_u_23:NextNumber(0.12, 0.2)
					end
					if not v_u_29 and (not v96.IsShooting and v95 - v_u_26 >= v_u_28) then
						if v_u_32 >= (v96.Properties.Automatic and (v98 <= 30 and (1 / 0) or (v98 <= 80 and 4 or 2)) or 1) then
							local v99
							if v_u_33 and v95 - v_u_33 < 0.9 then
								local v100 = v96.Recoil
								if v100 and v100.Time > v100.ActiveFireRate * 0.25 then
									v99 = false
								else
									local v101 = v96.Properties.Spread
									if v101 then
										local v102 = v101.Range
										v99 = v96:getBaseSpread() <= v102.Min + (v102.Max - v102.Min) * 0.3
									else
										v99 = true
									end
								end
							else
								v99 = true
							end
							if not v99 then
								return
							end
							v_u_32 = 0
							v_u_34 = v95 + v_u_23:NextNumber(0, 0.04)
						end
						if v_u_34 <= v95 then
							if not v_u_21 then
								return
							end
							v_u_29 = v96
							v_u_30 = os.clock()
							v_u_31 = v96.Rounds
							v_u_21(Enum.UserInputState.Begin, v_u_19)
						end
					end
				else
					if v_u_26 and v95 - v_u_27 > 0.12 then
						if v_u_29 then
							v_u_29 = nil
							if v_u_21 then
								v_u_21(Enum.UserInputState.End, v_u_19)
							end
						end
						v_u_26 = nil
						v_u_32 = 0
						v_u_33 = nil
						v_u_34 = 0
						v_u_24 = 0
					end
					return
				end
			else
				return
			end
		else
			if v_u_26 then
				if v_u_29 then
					v_u_29 = nil
					if v_u_21 then
						v_u_21(Enum.UserInputState.End, v_u_19)
					end
				end
				v_u_26 = nil
				v_u_32 = 0
				v_u_33 = nil
				v_u_34 = 0
				v_u_24 = 0
			end
			return
		end
	end
end
function v1.SetManualFireHeld(p104) -- name: SetManualFireHeld
	-- upvalues: (ref) v_u_25, (ref) v_u_29, (ref) v_u_26, (ref) v_u_32, (ref) v_u_33, (ref) v_u_34, (ref) v_u_24
	v_u_25 = p104
	if p104 then
		v_u_29 = nil
		v_u_26 = nil
		v_u_32 = 0
		v_u_33 = nil
		v_u_34 = 0
		v_u_24 = 0
	end
end
function v1.Start() -- name: Start
	-- upvalues: (copy) v_u_16, (copy) v_u_2, (ref) v_u_21, (copy) v_u_4, (copy) v_u_10, (copy) v_u_20, (copy) v_u_14, (ref) v_u_29, (copy) v_u_19, (ref) v_u_26, (ref) v_u_32, (ref) v_u_33, (ref) v_u_34, (ref) v_u_24, (ref) v_u_22, (copy) v_u_7, (copy) v_u_103, (copy) v_u_6
	if v_u_16 then
		v_u_21 = require(v_u_2.Controllers.InputController.Actions.Fire).Callback
		v_u_4:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
			-- upvalues: (ref) v_u_10, (ref) v_u_4, (ref) v_u_20
			local v105 = v_u_10.getLocalCharacter()
			local v106 = {}
			if v105 then
				table.insert(v106, v105)
			end
			if v_u_4.CurrentCamera then
				local v107 = v_u_4.CurrentCamera
				table.insert(v106, v107)
			end
			v_u_20.FilterDescendantsInstances = v106
		end)
		v_u_10.observeCharacter(v_u_14, function(p108)
			-- upvalues: (ref) v_u_4, (ref) v_u_20, (ref) v_u_29, (ref) v_u_21, (ref) v_u_19, (ref) v_u_26, (ref) v_u_32, (ref) v_u_33, (ref) v_u_34, (ref) v_u_24
			local v109 = {}
			if p108 then
				table.insert(v109, p108)
			end
			if v_u_4.CurrentCamera then
				local v110 = v_u_4.CurrentCamera
				table.insert(v109, v110)
			end
			v_u_20.FilterDescendantsInstances = v109
			if v_u_29 then
				v_u_29 = nil
				if v_u_21 then
					v_u_21(Enum.UserInputState.End, v_u_19)
				end
			end
			v_u_26 = nil
			v_u_32 = 0
			v_u_33 = nil
			v_u_34 = 0
			v_u_24 = 0
			return function() end
		end)
		if not v_u_22 then
			v_u_22 = v_u_7.BindToRenderStep("MobileAutoShootController.Step", v_u_103)
		end
		v_u_6.CreateListener(v_u_14, "Settings.Game.Other.Mobile Auto Shoot", function(p111)
			-- upvalues: (ref) v_u_22, (ref) v_u_7, (ref) v_u_103, (ref) v_u_29, (ref) v_u_21, (ref) v_u_19, (ref) v_u_26, (ref) v_u_32, (ref) v_u_33, (ref) v_u_34, (ref) v_u_24
			local v112 = p111 ~= false
			if v112 and not v_u_22 then
				v_u_22 = v_u_7.BindToRenderStep("MobileAutoShootController.Step", v_u_103)
			elseif not v112 and v_u_22 then
				v_u_22:Disconnect()
				v_u_22 = nil
				if v_u_29 then
					v_u_29 = nil
					if v_u_21 then
						v_u_21(Enum.UserInputState.End, v_u_19)
					end
				end
				v_u_26 = nil
				v_u_32 = 0
				v_u_33 = nil
				v_u_34 = 0
				v_u_24 = 0
			end
			return nil
		end)
	end
end
return v1
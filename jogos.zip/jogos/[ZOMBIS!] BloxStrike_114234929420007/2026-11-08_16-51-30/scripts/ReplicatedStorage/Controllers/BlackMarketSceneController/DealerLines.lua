-- NIGHT Analyzer | ReplicatedStorage.Controllers.BlackMarketSceneController.DealerLines
-- ModuleScript | 145 linhas | 4077 bytes | hash cc31ef4f

local function v3(p1, p2) -- name: line
	return table.freeze({
		["Sound"] = p1,
		["Animation"] = ("rbxassetid://%*"):format(p2)
	})
end
local v4 = {
	["SOUND_GROUP"] = "ArmsDealer",
	["IDLE_ANIMATION"] = "rbxassetid://127680394246389",
	["INTRO_ANIMATION"] = "rbxassetid://95003386452387",
	["Open"] = table.freeze({
		table.freeze({
			["Sound"] = "Open 1",
			["Animation"] = nil,
			["Animation"] = ("rbxassetid://%*"):format(108820213143581)
		}),
		table.freeze({
			["Sound"] = "Open 3",
			["Animation"] = nil,
			["Animation"] = ("rbxassetid://%*"):format(79434798599791)
		}),
		table.freeze({
			["Sound"] = "Open 4",
			["Animation"] = nil,
			["Animation"] = ("rbxassetid://%*"):format(131035732599957)
		}),
		table.freeze({
			["Sound"] = "Open 5",
			["Animation"] = nil,
			["Animation"] = ("rbxassetid://%*"):format(100695883001427)
		}),
		v3("Open 6", 128685469059709)
	})
}
local v5 = table.freeze
local v6 = {
	["Blue"] = table.freeze({ table.freeze({
			["Sound"] = "Blue 1",
			["Animation"] = nil,
			["Animation"] = ("rbxassetid://%*"):format(114988568340900)
		}), v3("Blue 2", 94131440299691) }),
	["Purple"] = table.freeze({ v3("Purple 2", 70665452356574) }),
	["Pink"] = table.freeze({ table.freeze({
			["Sound"] = "Pink 1",
			["Animation"] = nil,
			["Animation"] = ("rbxassetid://%*"):format(70685214815664)
		}), v3("Pink 2", 108640008269911) }),
	["Red"] = table.freeze({ table.freeze({
			["Sound"] = "Red 1",
			["Animation"] = nil,
			["Animation"] = ("rbxassetid://%*"):format(97498387726202)
		}), v3("Red 2", 130623891787655) }),
	["Special"] = table.freeze({ table.freeze({
			["Sound"] = "Gold 1",
			["Animation"] = nil,
			["Animation"] = ("rbxassetid://%*"):format(85665191583665)
		}), v3("Gold 3", 138367858596446) })
}
v4.Rarity = v5(v6)
v4.Purchase = table.freeze({
	table.freeze({
		["Sound"] = "Purchase 1",
		["Animation"] = nil,
		["Animation"] = ("rbxassetid://%*"):format(90216929714117)
	}),
	table.freeze({
		["Sound"] = "Purchase 3",
		["Animation"] = nil,
		["Animation"] = ("rbxassetid://%*"):format(109862435497094)
	}),
	table.freeze({
		["Sound"] = "Purchase 4",
		["Animation"] = nil,
		["Animation"] = ("rbxassetid://%*"):format(113255847772841)
	}),
	table.freeze({
		["Sound"] = "Purchase 5",
		["Animation"] = nil,
		["Animation"] = ("rbxassetid://%*"):format(125620695537467)
	}),
	v3("Purchase 6", 74929276364047)
})
v4.Declined = table.freeze({
	table.freeze({
		["Sound"] = "Declined 1",
		["Animation"] = nil,
		["Animation"] = ("rbxassetid://%*"):format(129610298959912)
	}),
	table.freeze({
		["Sound"] = "Declined 2",
		["Animation"] = nil,
		["Animation"] = ("rbxassetid://%*"):format(132955562823743)
	}),
	table.freeze({
		["Sound"] = "Declined 3",
		["Animation"] = nil,
		["Animation"] = ("rbxassetid://%*"):format(122535234265641)
	}),
	v3("Declined 5", 77965099110387)
})
v4.Refresh = table.freeze({
	table.freeze({
		["Sound"] = "Refresh 1",
		["Animation"] = nil,
		["Animation"] = ("rbxassetid://%*"):format(76033652919780)
	}),
	table.freeze({
		["Sound"] = "Refresh 2",
		["Animation"] = nil,
		["Animation"] = ("rbxassetid://%*"):format(110165533270896)
	}),
	table.freeze({
		["Sound"] = "Refresh 3",
		["Animation"] = nil,
		["Animation"] = ("rbxassetid://%*"):format(88608508842745)
	}),
	table.freeze({
		["Sound"] = "Refresh 4",
		["Animation"] = nil,
		["Animation"] = ("rbxassetid://%*"):format(123025404949952)
	}),
	table.freeze({
		["Sound"] = "Refresh 5",
		["Animation"] = nil,
		["Animation"] = ("rbxassetid://%*"):format(109491615847472)
	}),
	v3("Refresh 6", 84677609075487)
})
v4.Discontinued = table.freeze({ table.freeze({
		["Sound"] = "Discontinued 1",
		["Animation"] = nil,
		["Animation"] = ("rbxassetid://%*"):format(123062898010154)
	}), table.freeze({
		["Sound"] = "Discontinued 2",
		["Animation"] = nil,
		["Animation"] = ("rbxassetid://%*"):format(120236879337679)
	}), v3("Discontinued 3", 103547167570421) })
function v4.Pick(p7) -- name: Pick
	if p7 and #p7 ~= 0 then
		return p7[math.random(1, #p7)]
	else
		return nil
	end
end
return table.freeze(v4)
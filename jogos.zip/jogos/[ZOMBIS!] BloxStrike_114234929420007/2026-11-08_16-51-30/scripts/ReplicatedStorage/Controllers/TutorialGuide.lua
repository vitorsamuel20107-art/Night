-- NIGHT Analyzer | ReplicatedStorage.Controllers.TutorialGuide
-- ModuleScript | 1272 linhas | 32071 bytes | hash 28f11919

local v1 = {}
local v_u_2 = game:GetService("HttpService")
local v_u_3 = game:GetService("PathfindingService")
local v4 = game:GetService("Players")
local v5 = game:GetService("ReplicatedStorage")
local v_u_6 = require(v5.Components.Common.CatmullRomPath)
local v_u_7 = require(v5.Components.Common.CharacterResolver)
local v_u_8 = require(v5.Components.Common.GetRayIgnore)
local v_u_9 = require(v5.Components.Common.IsTutorialMode)
local v_u_10 = require(v5.Controllers.RunServiceController)
local v_u_11 = require(v5.Controllers.TutorialZones)
local v_u_12 = v4.LocalPlayer
local v_u_13 = { 3.5, 2 }
local v_u_14 = Color3.fromRGB(255, 236, 60)
local v_u_15 = {
	"Characters",
	"TutorialDummies",
	"TutorialEscorts",
	"TutorialRetakers",
	"TutorialCTSquad",
	"TutorialBAttackers"
}
local v_u_16 = {
	"Range_Entry",
	"Range_Exit",
	"Site_Entry",
	"Site_Exit"
}
local function v_u_22(p17, p18) -- name: flatDistance
	local v19 = p17 - p18
	local v20 = v19.X
	local v21 = v19.Z
	return Vector3.new(v20, 0, v21).Magnitude
end
local v_u_23 = RaycastParams.new()
v_u_23.FilterType = Enum.RaycastFilterType.Exclude
local v_u_24 = nil
local v_u_25 = RaycastParams.new()
v_u_25.FilterType = Enum.RaycastFilterType.Include
local v_u_26 = nil
local v_u_27 = {}
local v_u_28 = {}
local function v_u_75(p29) -- name: collectLanes
	-- upvalues: (copy) v_u_27, (copy) v_u_28
	table.clear(v_u_27)
	table.clear(v_u_28)
	if not p29 then
		return
	end
	for _, v30 in p29:GetDescendants() do
		if not v30:IsA("BasePart") or (v30.Name ~= "Arrow" or (v30.Size.Magnitude > 8 or v30.CFrame.UpVector.Y < 0.99)) then
			continue
		end
		local v31 = v30.CFrame.LookVector
		local v32 = v31.X
		local v33 = v31.Z
		local v34 = Vector3.new(v32, 0, v33)
		if v34.Magnitude < 0.5 then
			continue
		end
		local v35 = v34.Unit
		local v36, v37, v38, v39, v40, v41, v42, v43, v44, v45, v46
		if v35.X < -0.5 then
			v35 = -v35
			v36 = v30.Position
			v37 = v36.X
			v38 = v36.Z
			v39 = Vector3.new(v37, 0, v38)
			v40 = nil
			for v52, v53 in v_u_27 do
				v41 = v53.Axis:Dot(v35)
				if math.abs(v41) < 0.98 then
					continue
				end
				v42 = v39 - v53.Origin
				if (v42 - v53.Axis * v42:Dot(v53.Axis)).Magnitude > 2 then
					continue
				end
				v40 = v53
			end
			if v40 then
				v43 = (v39 - v40.Origin):Dot(v40.Axis)
				v44 = v40.Min
				v40.Min = math.min(v44, v43)
				v45 = v40.Max
				v40.Max = math.max(v45, v43)
			else
				v46 = v_u_27
				table.insert(v46, {
					["Origin"] = nil,
					["Axis"] = nil,
					["Min"] = 0,
					["Max"] = 0,
					["Joins"] = nil,
					["Origin"] = v39,
					["Axis"] = v35,
					["Joins"] = {}
				})
			end
		else
			local v49 = v35.X
			if math.abs(v49) <= 0.5 and v35.Z < 0 then
				v35 = -v35
				v36 = v30.Position
				v37 = v36.X
				v38 = v36.Z
				v39 = Vector3.new(v37, 0, v38)
				v40 = nil
				for v52, v53 in v_u_27 do
					v41 = v53.Axis:Dot(v35)
					if math.abs(v41) < 0.98 then
						continue
					end
					v42 = v39 - v53.Origin
					if (v42 - v53.Axis * v42:Dot(v53.Axis)).Magnitude > 2 then
						continue
					end
					v40 = v53
				end
				if v40 then
					v43 = (v39 - v40.Origin):Dot(v40.Axis)
					v44 = v40.Min
					v40.Min = math.min(v44, v43)
					v45 = v40.Max
					v40.Max = math.max(v45, v43)
				else
					v46 = v_u_27
					table.insert(v46, {
						["Origin"] = nil,
						["Axis"] = nil,
						["Min"] = 0,
						["Max"] = 0,
						["Joins"] = nil,
						["Origin"] = v39,
						["Axis"] = v35,
						["Joins"] = {}
					})
				end
			else
				v36 = v30.Position
				v37 = v36.X
				v38 = v36.Z
				v39 = Vector3.new(v37, 0, v38)
				v40 = nil
				for v52, v53 in v_u_27 do
					v41 = v53.Axis:Dot(v35)
					if math.abs(v41) < 0.98 then
						continue
					end
					v42 = v39 - v53.Origin
					if (v42 - v53.Axis * v42:Dot(v53.Axis)).Magnitude > 2 then
						continue
					end
					v40 = v53
				end
				if v40 then
					v43 = (v39 - v40.Origin):Dot(v40.Axis)
					v44 = v40.Min
					v40.Min = math.min(v44, v43)
					v45 = v40.Max
					v40.Max = math.max(v45, v43)
				else
					v46 = v_u_27
					table.insert(v46, {
						["Origin"] = nil,
						["Axis"] = nil,
						["Min"] = 0,
						["Max"] = 0,
						["Joins"] = nil,
						["Origin"] = v39,
						["Axis"] = v35,
						["Joins"] = {}
					})
				end
			end
		end
	end
	for v54 = 1, #v_u_27 do
		for v55 = v54 + 1, #v_u_27 do
			local v56 = v_u_27[v54]
			local v57 = v_u_27[v55]
			local v58 = v56.Axis.X * v57.Axis.Z - v56.Axis.Z * v57.Axis.X
			if math.abs(v58) < 0.2 then
				continue
			end
			local v59 = v57.Origin - v56.Origin
			local v60 = (v59.X * v57.Axis.Z - v59.Z * v57.Axis.X) / v58
			local v61 = (v59.X * v56.Axis.Z - v59.Z * v56.Axis.X) / v58
			if v56.Min - 16 > v60 or (v60 > v56.Max + 16 or (v57.Min - 16 > v61 or v61 > v57.Max + 16)) then
				continue
			end
			local v62 = v_u_28
			local v63 = v56.Origin + v56.Axis * v60
			table.insert(v62, v63)
			local v64 = #v_u_28
			local v65 = v56.Joins
			table.insert(v65, {
				["T"] = v60,
				["Node"] = v64
			})
			local v66 = v57.Joins
			table.insert(v66, {
				["T"] = v61,
				["Node"] = v64
			})
			local v67 = v56.Min
			local v68 = math.min(v67, v60)
			local v69 = v56.Max
			local v70 = math.max(v69, v60)
			v56.Min = v68
			v56.Max = v70
			local v71 = v57.Min
			local v72 = math.min(v71, v61)
			local v73 = v57.Max
			local v74 = math.max(v73, v61)
			v57.Min = v72
			v57.Max = v74
		end
	end
end
local function v_u_82(p76) -- name: refreshFloors
	-- upvalues: (ref) v_u_26, (copy) v_u_75, (copy) v_u_25
	if p76 ~= v_u_26 then
		v_u_26 = p76
		v_u_75(p76)
		local v77 = {}
		local v78
		if p76 then
			v78 = p76:FindFirstChild("Zones")
		else
			v78 = p76
		end
		if p76 then
			for _, v79 in p76:GetDescendants() do
				if not v79:IsA("BasePart") or (not v79.CanQuery or (v79.Transparency >= 0.9 or v78 and v79:IsDescendantOf(v78))) then
					continue
				end
				local v80 = v79.Size
				local v81
				if v79.CFrame.UpVector.Y > 0.99 and v80.Y <= 2 then
					v81 = v80.X * v80.Z >= 300
				else
					v81 = false
				end
				if not v81 then
					continue
				end
				table.insert(v77, v79)
			end
		end
		v_u_25.FilterDescendantsInstances = v77
	end
end
local function v_u_89() -- name: refreshIgnore
	-- upvalues: (copy) v_u_82, (ref) v_u_24, (copy) v_u_8, (copy) v_u_15, (copy) v_u_16, (copy) v_u_23
	local v83 = workspace:FindFirstChild("Map")
	v_u_82(v83)
	if v83 then
		v83 = v83:FindFirstChild("Geometry")
	end
	v_u_24 = v83
	local v84 = v_u_8()
	for _, v85 in v_u_15 do
		local v86 = workspace:FindFirstChild(v85)
		if not v86 then
			continue
		end
		table.insert(v84, v86)
	end
	for _, v87 in v_u_16 do
		local v88 = v_u_24
		if v88 then
			v88 = v_u_24:FindFirstChild(v87)
		end
		if not v88 then
			continue
		end
		table.insert(v84, v88)
	end
	v_u_23.FilterDescendantsInstances = v84
end
local function v_u_108(p90, p91) -- name: isClearLine
	-- upvalues: (copy) v_u_25, (ref) v_u_24, (copy) v_u_23
	local v92 = p90 + Vector3.new(0, 3, 0)
	local v93 = workspace:Raycast(v92, Vector3.new(0, -15, 0), v_u_25)
	if v93 then
		local v94 = v_u_24
		local v95
		if v94 == nil then
			v95 = false
		else
			v95 = v93.Instance:IsDescendantOf(v94)
		end
		p90 = v93.Position + Vector3.new(0, v95 and 0.25 or 0, 0)
	end
	local v96 = p90 + Vector3.new(0, 2.6, 0)
	local v97 = p91 + Vector3.new(0, 3, 0)
	local v98 = workspace:Raycast(v97, Vector3.new(0, -15, 0), v_u_25)
	if v98 then
		local v99 = v_u_24
		local v100
		if v99 == nil then
			v100 = false
		else
			v100 = v98.Instance:IsDescendantOf(v99)
		end
		p91 = v98.Position + Vector3.new(0, v100 and 0.25 or 0, 0)
	end
	local v101 = p91 + Vector3.new(0, 2.6, 0) - v96
	if v101.Magnitude < 0.1 then
		return true
	end
	local v102 = CFrame.lookAt(v96, v96 + v101)
	local v103 = table.clone(v_u_23.FilterDescendantsInstances)
	local v104 = workspace:FindFirstChild("Map")
	if v104 then
		v104 = v104:FindFirstChild("Zones")
	end
	if v104 then
		table.insert(v103, v104)
	end
	local v105 = RaycastParams.new()
	v105.FilterType = Enum.RaycastFilterType.Exclude
	for _ = 1, 6 do
		v105.FilterDescendantsInstances = v103
		local v106 = workspace:Blockcast(v102, Vector3.new(4.5, 4, 0.2), v101, v105)
		if not v106 then
			return true
		end
		local v107 = v106.Instance
		if not v107:IsA("BasePart") or v107.Transparency < 0.9 then
			return false
		end
		table.insert(v103, v107)
	end
	return false
end
local function v_u_117(p109, p110) -- name: computePath
	-- upvalues: (copy) v_u_13, (copy) v_u_3
	for _, v111 in v_u_13 do
		local v112 = v_u_3:CreatePath({
			["AgentRadius"] = nil,
			["AgentHeight"] = 5,
			["AgentCanJump"] = true,
			["WaypointSpacing"] = 4,
			["AgentRadius"] = v111
		})
		local v113 = v112.ComputeAsync
		if not pcall(v113, v112, p109, p110) or v112.Status ~= Enum.PathStatus.Success then
			continue
		end
		local v114 = {}
		for _, v115 in v112:GetWaypoints() do
			local v116 = v115.Position
			table.insert(v114, v116)
		end
		return v114
	end
	return nil
end
local function v_u_186(p118, p119) -- name: lanePath
	-- upvalues: (copy) v_u_27, (copy) v_u_28, (copy) v_u_108
	if #v_u_27 == 0 then
		return nil
	else
		local v120 = {}
		local v121 = p118.X
		local v122 = p118.Z
		local v123 = Vector3.new(v121, 0, v122)
		local v124 = p119.X
		local v125 = p119.Z
		__set_list(v120, 1, {v123, (Vector3.new(v124, 0, v125))})
		for v126, v127 in v_u_28 do
			v120[v126 + 2] = v127
		end
		local v_u_128 = {}
		local function v134(p129, p130, p131) -- name: link
			-- upvalues: (copy) v_u_128
			v_u_128[p129] = v_u_128[p129] or {}
			local v132 = v_u_128[p129]
			table.insert(v132, { p130, p131 })
			v_u_128[p130] = v_u_128[p130] or {}
			local v133 = v_u_128[p130]
			table.insert(v133, { p129, p131 })
		end
		local v135 = p118 - p119
		local v136 = v135.X
		local v137 = v135.Z
		v134(1, 2, Vector3.new(v136, 0, v137).Magnitude * 1.6)
		for _, v138 in v_u_27 do
			local v139 = {}
			for _, v140 in v138.Joins do
				local v141 = {
					["T"] = v140.T,
					["Node"] = v140.Node + 2
				}
				table.insert(v139, v141)
			end
			for v142, v143 in { p118, p119 } do
				local v144 = v143.X
				local v145 = v143.Z
				local v146 = (Vector3.new(v144, 0, v145) - v138.Origin):Dot(v138.Axis)
				local v147 = v138.Min
				local v148 = v138.Max
				local v149 = math.clamp(v146, v147, v148)
				local v150 = v138.Origin + v138.Axis * v149
				local v151 = v143 - v150
				local v152 = v151.X
				local v153 = v151.Z
				local v154 = Vector3.new(v152, 0, v153).Magnitude
				if v154 > 30 then
					continue
				end
				if v154 >= 1 then
					local v155 = v_u_108
					local v156 = v150.X
					local v157 = v143.Y
					local v158 = v150.Z
					if not v155(v143, (Vector3.new(v156, v157, v158))) then
						continue
					end
				end
				table.insert(v120, v150)
				local v159 = {
					["T"] = v149,
					["Node"] = #v120
				}
				table.insert(v139, v159)
				v134(v142, #v120, v154 * 1.6)
			end
			table.sort(v139, function(p160, p161)
				return p160.T < p161.T
			end)
			for v162 = 2, #v139 do
				v134(v139[v162 - 1].Node, v139[v162].Node, v139[v162].T - v139[v162 - 1].T)
			end
		end
		local v163 = { 0 }
		local v164 = {}
		local v165 = {}
		while true do
			local v166 = (1 / 0)
			local v167 = nil
			for v168, v169 in v163 do
				if v164[v168] or v169 >= v166 then
					continue
				end
				v167 = v168
				v166 = v169
			end
			if v167 == nil or v167 == 2 then
				if v165[2] == nil or v165[2] == 1 then
					return nil
				else
					local v170 = v165[2]
					local v171 = { p119 }
					while v170 and v170 ~= 1 do
						local v172 = v120[v170].X
						local v173 = p118.Y
						local v174 = v120[v170].Z
						local v175 = Vector3.new(v172, v173, v174)
						local v176 = v175 - v171[1]
						local v177 = v176.X
						local v178 = v176.Z
						if Vector3.new(v177, 0, v178).Magnitude > 0.5 then
							table.insert(v171, 1, v175)
						end
						v170 = v165[v170]
					end
					local v179 = p118 - v171[1]
					local v180 = v179.X
					local v181 = v179.Z
					if Vector3.new(v180, 0, v181).Magnitude > 0.5 then
						table.insert(v171, 1, p118)
						return v171
					else
						v171[1] = p118
						return v171
					end
				end
			end
			v164[v167] = true
			local v182 = v_u_128[v167]
			if not v182 then
				break
			end
			for _, v183 in v182 do
				local v184 = v183[1]
				local v185 = v166 + v183[2]
				if v185 >= (v163[v184] or (1 / 0)) then
					continue
				end
				v163[v184] = v185
				v165[v184] = v167
			end
		end
	end
end
local function v_u_211(p187, p188) -- name: walkLeg
	-- upvalues: (copy) v_u_186, (copy) v_u_108, (copy) v_u_25, (ref) v_u_24, (copy) v_u_117
	local v189 = v_u_186(p187, p188)
	if v189 then
		return v189
	end
	if v_u_108(p187, p188) then
		return { p187, p188 }
	end
	local v190 = p187 + Vector3.new(0, 3, 0)
	local v191 = workspace:Raycast(v190, Vector3.new(0, -15, 0), v_u_25)
	local v192
	if v191 then
		local v193 = v_u_24
		local v194
		if v193 == nil then
			v194 = false
		else
			v194 = v191.Instance:IsDescendantOf(v193)
		end
		v192 = v191.Position + Vector3.new(0, v194 and 0.25 or 0, 0)
	else
		v192 = p187
	end
	local v195 = p188 + Vector3.new(0, 3, 0)
	local v196 = workspace:Raycast(v195, Vector3.new(0, -15, 0), v_u_25)
	local v197
	if v196 then
		local v198 = v_u_24
		local v199
		if v198 == nil then
			v199 = false
		else
			v199 = v196.Instance:IsDescendantOf(v198)
		end
		v197 = v196.Position + Vector3.new(0, v199 and 0.25 or 0, 0)
	else
		v197 = p188
	end
	local v200 = v_u_117(v192, v197)
	if not v200 then
		local v201 = p187 - p188
		local v202 = v201.X
		local v203 = v201.Z
		local v204 = Vector3.new(v202, 0, v203)
		if v204.Magnitude > 3 then
			local v205 = v_u_117
			local v206 = p188 + v204.Unit * 3
			local v207 = v206 + Vector3.new(0, 3, 0)
			local v208 = workspace:Raycast(v207, Vector3.new(0, -15, 0), v_u_25)
			if v208 then
				local v209 = v_u_24
				local v210
				if v209 == nil then
					v210 = false
				else
					v210 = v208.Instance:IsDescendantOf(v209)
				end
				v206 = v208.Position + Vector3.new(0, v210 and 0.25 or 0, 0)
			end
			v200 = v205(v192, v206)
			if v200 then
				table.insert(v200, p188)
			end
		end
	end
	if not v200 then
		return { p187, p188 }
	end
	v200[1] = p187
	return v200
end
local v_u_212 = v_u_24
local v_u_213 = {}
local function v_u_239(p214, p215) -- name: remainingPoints
	local v216 = #p214
	if v216 <= 1 then
		return table.clone(p214)
	end
	local v217 = p215.X
	local v218 = p215.Z
	local v219 = Vector3.new(v217, 0, v218)
	local v220 = {}
	local v221 = {}
	local v222 = (1 / 0)
	for v223 = 1, v216 - 1 do
		local v224 = p214[v223]
		local v225 = v224.X
		local v226 = v224.Z
		local v227 = Vector3.new(v225, 0, v226)
		local v228 = p214[v223 + 1]
		local v229 = v228.X
		local v230 = v228.Z
		local v231 = Vector3.new(v229, 0, v230) - v227
		local v232 = v231:Dot(v231)
		local v233 = v232 <= 1e-6 and 0 or (v219 - v227):Dot(v231) / v232
		v220[v223] = (v219 - (v227 + v231 * math.clamp(v233, 0, 1))).Magnitude
		v221[v223] = v233
		local v234 = v220[v223]
		v222 = math.min(v222, v234)
	end
	local v235 = 1
	for v236 = v216 - 1, 1, -1 do
		if v220[v236] > v222 + 2 then
			continue
		end
		v235 = v236
	end
	local v237 = v235 + 1
	if v235 == 1 and v221[1] <= 0 then
		v237 = 1
	elseif v221[v235] >= 1 then
		v237 = v235 + 2
	end
	local v238 = math.min(v237, v216)
	return table.move(p214, v238, v216, 1, {})
end
local function v_u_255() -- name: decodeRoute
	-- upvalues: (copy) v_u_12, (copy) v_u_2
	local v240 = v_u_12:GetAttribute("TutorialGuide")
	if typeof(v240) ~= "string" then
		return nil
	end
	local v241 = v_u_2.JSONDecode
	local v242 = v_u_2
	local v243, v244 = pcall(v241, v242, v240)
	if v243 and typeof(v244) == "table" then
		local v245 = v244.p
		if typeof(v245) == "table" then
			local v246 = {}
			for _, v247 in v244.p do
				if typeof(v247) ~= "table" then
					continue
				end
				local v248 = v247[1]
				if typeof(v248) ~= "number" then
					continue
				end
				local v249 = v247[1]
				local v250 = v247[2]
				local v251 = v247[3]
				local v252 = Vector3.new(v249, v250, v251)
				table.insert(v246, v252)
			end
			if #v246 == 0 then
				return nil
			end
			local v253 = {
				["Points"] = v246
			}
			local v254 = v244.r
			v253.Radius = typeof(v254) ~= "number" and 5 or v244.r
			v253.Key = v240
			return v253
		end
	end
	return nil
end
local function v_u_269(p256) -- name: roundCorners
	-- upvalues: (copy) v_u_108
	for _ = 1, 2 do
		if #p256 < 3 then
			return p256
		end
		local v257 = { p256[1] }
		for v258 = 2, #p256 - 1 do
			local v259 = p256[v258 - 1]
			local v260 = p256[v258]
			local v261 = p256[v258 + 1]
			local v262 = (v260 - v259).Magnitude
			local v263 = (v261 - v260).Magnitude
			if v262 < 0.001 or v263 < 0.001 then
				table.insert(v257, v260)
			else
				local v264 = v262 * 0.25
				local v265 = v260:Lerp(v259, math.min(v264, 2) / v262)
				local v266 = v263 * 0.25
				local v267 = v260:Lerp(v261, math.min(v266, 2) / v263)
				if v_u_108(v265, v267) then
					table.insert(v257, v265)
					table.insert(v257, v267)
				else
					table.insert(v257, v260)
				end
			end
		end
		local v268 = p256[#p256]
		table.insert(v257, v268)
		p256 = v257
	end
	return p256
end
local function v_u_297(p270) -- name: simplify
	if #p270 < 3 then
		return p270
	end
	local v271 = table.create(#p270, false)
	local v272 = #p270
	v271[1] = true
	v271[v272] = true
	local v273 = {
		{ 1, #p270 }
	}
	while #v273 > 0 do
		local v274 = table.remove(v273)
		local v275 = v274[1]
		local v276 = v274[2]
		local v277 = p270[v275]
		local v278 = v277.X
		local v279 = v277.Z
		local v280 = Vector3.new(v278, 0, v279)
		local v281 = p270[v276]
		local v282 = v281.X
		local v283 = v281.Z
		local v284 = Vector3.new(v282, 0, v283) - v280
		local v285 = v284.Magnitude
		local v286 = 0
		local v287 = 0
		for v288 = v275 + 1, v276 - 1 do
			local v289 = p270[v288]
			local v290 = v289.X
			local v291 = v289.Z
			local v292 = Vector3.new(v290, 0, v291)
			local v293
			if v285 > 0.001 then
				v293 = v284:Cross(v292 - v280).Magnitude / v285
			else
				v293 = (v292 - v280).Magnitude
			end
			if v286 >= v293 then
				continue
			end
			v287 = v288
			v286 = v293
		end
		if v286 <= 0.5 then
			break
		end
		v271[v287] = true
		table.insert(v273, { v275, v287 })
		table.insert(v273, { v287, v276 })
	end
	local v294 = {}
	for v295, v296 in p270 do
		if not v271[v295] then
			continue
		end
		table.insert(v294, v296)
	end
	return v294
end
for _, v298 in { 1, -1 } do
	local v299 = v298 * 0.6691306063588582
	local v300 = Vector3.new(v299, 0, 0.7431448254773942)
	local v301 = -v298 * 0.7431448254773942
	local v302 = Vector3.new(v301, 0, 0.6691306063588582)
	local v303 = Vector3.new(0, 0, -0.83603793) + v300 * 0.6996858843423915
	local v304 = v303 + v302 * 0.315 - v300 * 0.34984294217119577
	local v305 = {
		["ClassName"] = "WedgePart",
		["Size"] = Vector3.new(0.05, 0.63, 0.6996859),
		["Offset"] = nil,
		["Offset"] = CFrame.fromMatrix(v304, v302:Cross(v300), v302, v300)
	}
	table.insert(v_u_213, v305)
	local v306 = v303 + v300 * 0.7751570578288043 + v302 * 0.315
	local v307 = {
		["ClassName"] = "Part",
		["Size"] = Vector3.new(0.63, 0.05, 1.5503141),
		["Offset"] = nil,
		["Offset"] = CFrame.fromMatrix(v306, v302, Vector3.new(0, 1, 0))
	}
	table.insert(v_u_213, v307)
end
local v_u_308 = nil
local v_u_309 = {}
local function v_u_319(p310) -- name: getChevron
	-- upvalues: (ref) v_u_308, (copy) v_u_309, (copy) v_u_213, (copy) v_u_14
	if not (v_u_308 and v_u_308.Parent) then
		local v311 = Instance.new("Folder")
		v311.Name = "TutorialGuide"
		v311.Parent = workspace.CurrentCamera
		v_u_308 = v311
		table.clear(v_u_309)
	end
	local v312 = v_u_309[p310]
	if v312 then
		return v312
	end
	local v313 = {}
	for _, v314 in v_u_213 do
		local v315 = v314.ClassName
		local v316 = Instance.new(v315 or "Part")
		v316.Anchored = true
		v316.CanCollide = false
		v316.CanQuery = false
		v316.CanTouch = false
		v316.CastShadow = false
		v316.Material = Enum.Material.Neon
		v316.Color = v_u_14
		v316.Transparency = 1
		local v317
		if v_u_308 and v_u_308.Parent then
			v317 = v_u_308
		else
			v317 = Instance.new("Folder")
			v317.Name = "TutorialGuide"
			v317.Parent = workspace.CurrentCamera
			v_u_308 = v317
			table.clear(v_u_309)
		end
		v316.Parent = v317
		v316.Size = v314.Size
		table.insert(v313, v316)
	end
	local v318 = {
		["Parts"] = nil,
		["Trail"] = nil,
		["Along"] = 0,
		["Traveled"] = 0,
		["Stop"] = 0,
		["Active"] = false,
		["Transparency"] = 1,
		["Parts"] = v313
	}
	v_u_309[p310] = v318
	return v318
end
local v_u_320 = {}
local v_u_321 = {}
local function v_u_332(p322, p323, p324) -- name: placeChevron
	-- upvalues: (copy) v_u_213, (copy) v_u_320, (copy) v_u_321
	local v325 = CFrame.lookAt(p323, p323 + p324) * CFrame.new(0, 0.05, 0)
	for v326, v327 in v_u_213 do
		local v328 = v_u_320
		local v329 = p322.Parts[v326]
		table.insert(v328, v329)
		local v330 = v_u_321
		local v331 = v325 * v327.Offset
		table.insert(v330, v331)
	end
end
local v_u_333 = 0
local function v_u_364(p334, p335, p336) -- name: buildTrail
	-- upvalues: (copy) v_u_89, (copy) v_u_239, (copy) v_u_211, (ref) v_u_333, (copy) v_u_23, (copy) v_u_25, (ref) v_u_212, (copy) v_u_6, (copy) v_u_269, (copy) v_u_297, (copy) v_u_22
	v_u_89()
	local v337 = p335
	local v338 = { p335 }
	for _, v339 in v_u_239(p334.Points, p335) do
		local v340 = v_u_211(p335, v339)
		for v341 = 2, #v340 do
			local v342 = v340[v341]
			table.insert(v338, v342)
		end
		p335 = v339
	end
	if p336 ~= v_u_333 then
		return nil
	end
	for v343 = 2, #v338 do
		local v344 = v338[v343] - v337
		local v345 = v344.X
		local v346 = v344.Z
		local v347 = Vector3.new(v345, 0, v346)
		if v347.Magnitude <= 0.5 then
			continue
		end
		local v348 = -v347.Unit * 6
		local v349 = workspace:Raycast(v337, v348, v_u_23)
		local v350
		if v349 then
			local v351 = v349.Distance - 0.5
			v350 = math.max(v351, 0)
		else
			v350 = 6
		end
		if v350 > 0.5 then
			local v352 = v337 + v348.Unit * v350
			table.insert(v338, 1, v352)
		end
	end
	for v353, v359 in v338 do
		local v355 = v359 + Vector3.new(0, 3, 0)
		local v356 = workspace:Raycast(v355, Vector3.new(0, -15, 0), v_u_25)
		if v356 then
			local v357 = v_u_212
			local v358
			if v357 == nil then
				v358 = false
			else
				v358 = v356.Instance:IsDescendantOf(v357)
			end
			local v359 = v356.Position + Vector3.new(0, v358 and 0.25 or 0, 0)
		end
		v338[v353] = v359
	end
	local v360 = {
		["Alpha"] = 0.5,
		["Step"] = 0.5,
		["Distance"] = nil,
		["Distance"] = v_u_22
	}
	local v361 = v_u_6.spline(v_u_269((v_u_297(v338))), v360)
	local v362, v363 = v_u_6.resample(v361, 0.5, v_u_22)
	return #v362 >= 2 and {
		["Dense"] = v362,
		["Total"] = v363,
		["Floor"] = {}
	} or nil
end
local function v_u_392(p365, p366) -- name: floorPointAt
	-- upvalues: (copy) v_u_6, (copy) v_u_25, (ref) v_u_212
	local v367 = p365.Dense
	local v368, v369, v370 = v_u_6.locate(#v367, 0.5, p366)
	v367[v368]:Lerp(v367[v369], v370)
	local v371 = v368 - 1
	local v372 = v367[math.max(v371, 1)]
	local v373 = v368 + 2
	local v374 = #v367
	local v375 = v367[math.min(v373, v374)] - v372
	local v376 = v375.X
	local v377 = v375.Z
	local v378 = Vector3.new(v376, 0, v377)
	local v379, v380, v381 = v_u_6.locate(#p365.Dense, 0.5, p366)
	local v382 = p365.Floor[v379]
	if not v382 then
		v382 = p365.Dense[v379]
		local v383 = v382 + Vector3.new(0, 3, 0)
		local v384 = workspace:Raycast(v383, Vector3.new(0, -15, 0), v_u_25)
		if v384 then
			local v385 = v_u_212
			local v386
			if v385 == nil then
				v386 = false
			else
				v386 = v384.Instance:IsDescendantOf(v385)
			end
			v382 = v384.Position + Vector3.new(0, v386 and 0.25 or 0, 0)
		end
		p365.Floor[v379] = v382
	end
	local v387 = p365.Floor[v380]
	if not v387 then
		v387 = p365.Dense[v380]
		local v388 = v387 + Vector3.new(0, 3, 0)
		local v389 = workspace:Raycast(v388, Vector3.new(0, -15, 0), v_u_25)
		if v389 then
			local v390 = v_u_212
			local v391
			if v390 == nil then
				v391 = false
			else
				v391 = v389.Instance:IsDescendantOf(v390)
			end
			v387 = v389.Position + Vector3.new(0, v391 and 0.25 or 0, 0)
		end
		p365.Floor[v380] = v387
	end
	return v382:Lerp(v387, v381), v378
end
local function v_u_412(p393, p_u_394, p395) -- name: projectOnto
	local v_u_396 = p393.Dense
	local function v405(p397, p398) -- name: search
		-- upvalues: (copy) v_u_396, (copy) p_u_394
		local v399 = (1 / 0)
		for v400 = p397, p398 do
			local v401 = v_u_396[v400] - p_u_394
			local v402 = v401.X
			local v403 = v401.Z
			local v404 = Vector3.new(v402, 0, v403).Magnitude
			if v404 >= v399 then
				continue
			end
			p397 = v400
			v399 = v404
		end
		return p397, v399
	end
	local v406 = p395 - 80
	local v407 = math.max(1, v406)
	local v408 = #v_u_396
	local v409 = p395 + 80
	local v410, v411 = v405(v407, (math.min(v408, v409)))
	if v411 > 7 then
		v410, v411 = v405(1, #v_u_396)
	end
	return (v410 - 1) * 0.5, v411, v410
end
local v_u_413 = nil
local v_u_414 = nil
local v_u_415 = nil
local v_u_416 = 0
local v_u_417 = 0
local v_u_418 = 1
local v_u_419 = 0
local v_u_420 = false
local v_u_421 = true
local v_u_422 = 0
local v_u_423 = false
local function v_u_432(p424) -- name: spawnGroup
	-- upvalues: (ref) v_u_416, (copy) v_u_309, (copy) v_u_319
	local v425 = v_u_416 - 6
	local v426 = math.max(v425, 0)
	local v427 = p424.Total - 3
	for v428 = 1, 3 do
		local v429 = v426 + (3 - v428) * 2.6
		if v427 - v429 < 2 then
			continue
		end
		for _, v431 in v_u_309 do
			if v431.Active then
				continue
			end
		end
		local v431 = v_u_319(#v_u_309 + 1)
		v431.Active = true
		v431.Trail = p424
		v431.Along = v429
		v431.Traveled = 0
		v431.Stop = v427
	end
end
local function v_u_460(p433) -- name: draw
	-- upvalues: (ref) v_u_419, (ref) v_u_420, (ref) v_u_416, (ref) v_u_417, (ref) v_u_414, (ref) v_u_421, (copy) v_u_309, (ref) v_u_422, (ref) v_u_423, (copy) v_u_320, (copy) v_u_321, (copy) v_u_392, (copy) v_u_332
	local v434 = v_u_419
	local v435
	if v_u_420 then
		v435 = p433
	else
		v435 = -p433
	end
	local v436 = v434 + v435 * 3
	v_u_419 = math.clamp(v436, 0, 1)
	local v437 = v_u_416
	local v438 = v_u_417 - v_u_416
	local v439 = p433 * 12
	v_u_416 = v437 + v438 * math.min(1, v439)
	local v440 = v_u_414
	if v_u_419 <= 0 or not v440 then
		if not v_u_421 then
			v_u_421 = true
			for _, v441 in v_u_309 do
				v441.Active = false
				if v441.Transparency == 1 then
					continue
				end
				local v442 = v441.Transparency - 1
				local _ = math.abs(v442) < 0.02
				v441.Transparency = 1
				for _, v443 in v441.Parts do
					v443.Transparency = 1
				end
			end
		end
		v_u_422 = 1
	else
		v_u_421 = false
		if v_u_420 and not v_u_423 then
			v_u_422 = v_u_422 + p433
			if v_u_422 >= 1 then
				v_u_423 = true
			end
		end
		table.clear(v_u_320)
		table.clear(v_u_321)
		for _, v444 in v_u_309 do
			local v445 = v444.Trail
			if not (v444.Active and v445) then
				continue
			end
			local v446 = p433 * 15
			v444.Along = v444.Along + v446
			v444.Traveled = v444.Traveled + v446
			local v447 = v444.Stop - v444.Along
			if v447 <= 0 then
				v444.Active = false
				if v444.Transparency == 1 then
					continue
				end
				local v448 = v444.Transparency - 1
				local _ = math.abs(v448) < 0.02
				v444.Transparency = 1
				for _, v449 in v444.Parts do
					v449.Transparency = 1
				end
			else
				local v450 = v444.Traveled / 2
				local v451 = math.clamp(v450, 0, 1)
				local v452 = v447 / 6
				local v453 = v451 * math.clamp(v452, 0, 1) * v_u_419
				local v454, v455 = v_u_392(v445, v444.Along)
				if v455.Magnitude > 0.01 then
					v_u_332(v444, v454, v455.Unit)
				end
				local v456 = (1 - v453) / 0.02 + 0.5
				local v457 = math.floor(v456) * 0.02
				if v444.Transparency == v457 then
					continue
				end
				local v458 = v444.Transparency - v457
				if math.abs(v458) < 0.02 and v457 ~= 1 then
					continue
				end
				v444.Transparency = v457
				for _, v459 in v444.Parts do
					v459.Transparency = v457
				end
			end
		end
		if #v_u_320 > 0 then
			workspace:BulkMoveTo(v_u_320, v_u_321, Enum.BulkMoveMode.FireCFrameChanged)
		end
	end
end
local v_u_461 = false
local function v_u_463() -- name: prewarm
	-- upvalues: (ref) v_u_461, (copy) v_u_319
	if not v_u_461 then
		v_u_461 = true
		for v462 = 1, 24 do
			v_u_319(v462)
			if v462 % 4 ~= 0 then
				continue
			end
			task.wait()
		end
	end
end
local function v_u_498(p464) -- name: track
	-- upvalues: (ref) v_u_333, (ref) v_u_413, (copy) v_u_7, (ref) v_u_420, (copy) v_u_11, (ref) v_u_414, (ref) v_u_423, (copy) v_u_412, (ref) v_u_418, (ref) v_u_417, (copy) v_u_463, (copy) v_u_364, (ref) v_u_422, (ref) v_u_416, (copy) v_u_432
	local v465 = false
	local v466 = nil
	while p464 == v_u_333 do
		local v467 = v_u_413
		local v468 = v_u_7.getLocalCharacter()
		local v469
		if v468 then
			v469 = v_u_7.getRootPart(v468)
		else
			v469 = v468
		end
		if v467 and (v469 and v_u_7.isAliveCharacter(v468)) then
			local v470 = v469.Position
			local v471 = v470 - v467.Points[#v467.Points]
			local v472 = v471.X
			local v473 = v471.Z
			local v474 = Vector3.new(v472, 0, v473).Magnitude
			local v475 = v_u_11.IsInside(v470)
			if v475 then
				v465 = v475
			elseif v474 <= v467.Radius then
				v465 = true
			elseif v465 then
				local v476 = v467.Radius * 1.6
				v465 = v474 <= math.max(v476, 20)
			end
			if v465 then
				v_u_420 = false
				v_u_414 = nil
				task.wait(0.1)
			else
				local v477 = v_u_414
				local v478 = v477 == nil and true or v_u_423
				if v477 then
					local v479, v480, v481 = v_u_412(v477, v470, v_u_418)
					v_u_417 = v479
					v_u_418 = v481
					if v480 > 7 then
						v466 = v466 or os.clock()
						v478 = os.clock() - v466 >= 0.75
					else
						v466 = nil
					end
				end
				if v478 then
					v466 = nil
					v_u_463()
					if p464 ~= v_u_333 then
						return
					end
					local v482 = v_u_364(v467, v470, p464)
					if p464 ~= v_u_333 then
						return
					end
					v_u_414 = v482
					v_u_423 = false
					v_u_422 = 0
					v_u_418 = 1
					v_u_416 = 0
					v_u_417 = 0
					if v482 then
						local v_u_483 = v469.Position
						local v_u_484 = v482.Dense
						local function v493(p485, p486) -- name: search
							-- upvalues: (copy) v_u_484, (copy) v_u_483
							local v487 = (1 / 0)
							for v488 = p485, p486 do
								local v489 = v_u_484[v488] - v_u_483
								local v490 = v489.X
								local v491 = v489.Z
								local v492 = Vector3.new(v490, 0, v491).Magnitude
								if v492 >= v487 then
									continue
								end
								p485 = v488
								v487 = v492
							end
							return p485, v487
						end
						local v494 = #v_u_484
						local v495, v496 = v493(1, (math.min(v494, 81)))
						if v496 > 7 then
							v495, v496 = v493(1, #v_u_484)
						end
						local v497 = (v495 - 1) * 0.5
						v_u_418 = v495
						v_u_416 = v497
						v_u_417 = v497
						v_u_432(v482)
					end
				end
				v_u_420 = v_u_414 ~= nil
				task.wait(0.1)
			end
		else
			v_u_420 = false
			task.wait(0.1)
		end
	end
end
local function v_u_503() -- name: sync
	-- upvalues: (copy) v_u_9, (copy) v_u_255, (ref) v_u_413, (ref) v_u_333, (ref) v_u_414, (ref) v_u_420, (ref) v_u_419, (ref) v_u_421, (copy) v_u_309, (ref) v_u_415, (copy) v_u_10, (copy) v_u_460, (copy) v_u_498
	local v499
	if v_u_9() then
		v499 = v_u_255()
	else
		v499 = nil
	end
	if v499 and (v_u_413 and v499.Key == v_u_413.Key) then
		return
	else
		v_u_333 = v_u_333 + 1
		v_u_413 = v499
		v_u_414 = nil
		if v499 then
			v_u_419 = 0
			v_u_421 = true
			for _, v500 in v_u_309 do
				v500.Active = false
				if v500.Transparency == 1 then
					continue
				end
				local v501 = v500.Transparency - 1
				local _ = math.abs(v501) < 0.02
				v500.Transparency = 1
				for _, v502 in v500.Parts do
					v502.Transparency = 1
				end
			end
			if not v_u_415 then
				v_u_415 = v_u_10.BindToHeartbeat("TutorialGuide.Draw", v_u_460)
			end
			task.spawn(v_u_498, v_u_333)
		else
			v_u_420 = false
		end
	end
end
function v1.Start() -- name: Start
	-- upvalues: (copy) v_u_12, (copy) v_u_503
	v_u_12:GetAttributeChangedSignal("TutorialGuide"):Connect(v_u_503)
	v_u_503()
end
return v1
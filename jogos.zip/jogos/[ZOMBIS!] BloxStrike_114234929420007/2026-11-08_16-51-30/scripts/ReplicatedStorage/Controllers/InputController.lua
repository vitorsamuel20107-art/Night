-- NIGHT Analyzer | ReplicatedStorage.Controllers.InputController
-- ModuleScript | 357 linhas | 9835 bytes | hash 3ddb1aef

local v_u_1 = {}
local v_u_2 = game:GetService("ContextActionService")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("UserInputService")
local v5 = game:GetService("Players")
require(script:WaitForChild("Types"))
local v_u_6 = require(v3.Controllers.DataController)
local v_u_7 = require(v3.Components.Common.CharacterResolver)
local v_u_8 = require(v3.Interface.MenuState)
local v_u_9 = require(v3.Database.Security.Router)
local v_u_10 = require(v3.Database.Custom.GameStats.UI.Settings.Pages)
local v_u_11 = require(script:WaitForChild("KeybindParser"))
local v_u_12 = script:WaitForChild("Actions")
local v_u_13 = v5.LocalPlayer
local v_u_14 = {}
local v_u_15 = {}
local v_u_16 = {}
local v_u_17 = {}
local v_u_18 = { "Computer", "Console" }
local function v_u_28(p19, p20, p21) -- name: handleInput
	-- upvalues: (copy) v_u_16, (copy) v_u_8, (copy) v_u_15
	local v22 = v_u_16[p19]
	if v22 then
		local v23 = v_u_8.GetMenuFrame()
		local v24 = v_u_8.GetCurrentScreen()
		local v25 = v_u_8.GetMainGui()
		if v25 then
			v25 = v25:FindFirstChild("Gameplay")
		end
		local v26
		if v25 then
			v26 = v25:FindFirstChild("Bottom")
		else
			v26 = v25
		end
		if v25 then
			v25 = v25:FindFirstChild("Middle")
		end
		if v25 then
			v25 = v25:FindFirstChild("TeamSelection")
		end
		local v27 = v25 and v25:IsA("GuiObject") and (v25.Visible and (v26 and v26:IsA("GuiObject")))
		if v27 then
			v27 = not v26.Visible
		end
		if ((v24 ~= nil or v23 and v23.Visible == true) and true or v27 == true) and (v22.Category ~= "UI Keys" and v22.Category ~= "Communication Options" and p20 == Enum.UserInputState.Begin) then
			v22.IsActive = false
			return
		elseif v_u_15[v22.Group] == true then
			v22.IsActive = p20 == Enum.UserInputState.Begin
			task.spawn(v22.Callback, p20, p21)
		elseif p20 ~= Enum.UserInputState.Begin and v22.IsActive then
			v22.IsActive = false
			task.spawn(v22.Callback, p20, p21)
		end
	else
		return
	end
end
local function v_u_32(p29) -- name: unbindActionKeys
	-- upvalues: (copy) v_u_16, (copy) v_u_2, (copy) v_u_17, (copy) v_u_14
	local v30 = v_u_16[p29]
	if v30 then
		v_u_2:UnbindAction(p29)
		for _, v31 in ipairs(v30.Keybinds) do
			if typeof(v31) == "string" then
				if v_u_17[v31] ~= p29 then
					continue
				end
				v_u_17[v31] = nil
			else
				if v_u_14[v31] ~= p29 then
					continue
				end
				v_u_14[v31] = nil
			end
		end
		v30.Keybinds = {}
	end
end
function v_u_1.registerAction(p33) -- name: registerAction
	-- upvalues: (copy) v_u_16
	v_u_16[p33.Name] = {
		["Category"] = nil,
		["Callback"] = nil,
		["Group"] = nil,
		["BindPriority"] = nil,
		["Name"] = nil,
		["IsActive"] = false,
		["Keybinds"] = nil,
		["Category"] = p33.Category,
		["Callback"] = p33.Callback,
		["Group"] = p33.Group,
		["BindPriority"] = p33.BindPriority,
		["Name"] = p33.Name,
		["Keybinds"] = {}
	}
end
function v_u_1.bindKeybinds(p_u_34, p35) -- name: bindKeybinds
	-- upvalues: (copy) v_u_16, (copy) v_u_32, (copy) v_u_17, (copy) v_u_14, (copy) v_u_28, (copy) v_u_2
	local v36 = v_u_16[p_u_34]
	if v36 then
		v_u_32(p_u_34)
		local v37 = {}
		local v38 = {}
		for _, v39 in ipairs(p35) do
			if typeof(v39) == "string" then
				if v39 ~= "ScrollWheelUp" and v39 ~= "ScrollWheelDown" then
					continue
				end
				local v40 = v_u_17[v39]
				if v40 then
					warn((("[InputController] %*: %* is already bound to %*, keybind dropped"):format(p_u_34, v39, v40)))
				else
					table.insert(v37, v39)
					v_u_17[v39] = p_u_34
				end
			else
				local v41 = v_u_14[v39]
				if v41 then
					warn((("[InputController] %*: %* is already bound to %*, keybind dropped"):format(p_u_34, tostring(v39), v41)))
				else
					table.insert(v37, v39)
					table.insert(v38, v39)
					v_u_14[v39] = p_u_34
				end
			end
		end
		v36.Keybinds = v37
		if #v38 > 0 then
			local function v44(_, p42, p43)
				-- upvalues: (ref) v_u_28, (copy) p_u_34
				v_u_28(p_u_34, p42, p43)
			end
			if v36.BindPriority ~= nil then
				v_u_2:BindActionAtPriority(p_u_34, v44, false, v36.BindPriority, table.unpack(v38))
				return
			end
			v_u_2:BindAction(p_u_34, v44, false, table.unpack(v38))
		end
	end
end
function v_u_1.loadActionsFromDatabase(p45) -- name: loadActionsFromDatabase
	-- upvalues: (copy) v_u_10, (copy) v_u_32, (copy) v_u_18, (copy) v_u_11, (copy) v_u_1, (copy) v_u_14
	local v46 = {}
	for _, v47 in pairs(p45) do
		for v48, v49 in pairs(v47) do
			if typeof(v49) ~= "table" then
				continue
			end
			local v50 = v_u_10.GetSetting("Keybinds", v48)
			if v50 and v50.IsEnabled == false then
				v_u_32(v48)
			else
				local v51 = {}
				for _, v52 in ipairs(v_u_18) do
					local v53 = v49[v52]
					if not v53 or v53 == "" then
						continue
					end
					local v54 = v_u_11.parse(v53)
					if not v54 then
						continue
					end
					table.insert(v51, v54)
				end
				v46[v48] = v51
			end
		end
	end
	local v55 = v46["Switch Viewmodel Left/Right Hand"] == nil
	if v55 then
		v_u_32("Switch Viewmodel Left/Right Hand")
	end
	for v56 in pairs(v46) do
		v_u_32(v56)
	end
	for v57, v58 in pairs(v46) do
		v_u_1.bindKeybinds(v57, v58)
	end
	if v55 then
		local v59 = v_u_10.GetSetting("Keybinds", "Switch Viewmodel Left/Right Hand")
		if v59 then
			v59 = v_u_11.parse(v59.Default.Computer)
		end
		if typeof(v59) == "EnumItem" and v_u_14[v59] == nil then
			v_u_1.bindKeybinds("Switch Viewmodel Left/Right Hand", { v59 })
		end
	end
end
function v_u_1.isActionActive(p60) -- name: isActionActive
	-- upvalues: (copy) v_u_16
	local v61 = v_u_16[p60]
	return v61 and v61.IsActive or false
end
function v_u_1.enableGroup(p62) -- name: enableGroup
	-- upvalues: (copy) v_u_15
	v_u_15[p62] = true
end
function v_u_1.disableGroup(p63) -- name: disableGroup
	-- upvalues: (copy) v_u_15
	v_u_15[p63] = nil
end
function v_u_1.GetActionKeybind(p64) -- name: GetActionKeybind
	-- upvalues: (copy) v_u_16
	local v65 = v_u_16[p64]
	if v65 and #v65.Keybinds ~= 0 then
		local v66 = v65.Keybinds[1]
		if typeof(v66) == "string" then
			return v66
		else
			return tostring(v66):match("%.(%w+)$") or tostring(v66)
		end
	else
		return nil
	end
end
function v_u_1.Initialize() -- name: Initialize
	-- upvalues: (copy) v_u_12, (copy) v_u_1, (copy) v_u_7, (copy) v_u_13, (copy) v_u_2, (copy) v_u_6, (copy) v_u_9
	for _, v67 in ipairs(v_u_12:GetChildren()) do
		if not v67:IsA("ModuleScript") then
			continue
		end
		v_u_1.registerAction((require(v67)))
	end
	v_u_1.enableGroup("Default")
	v_u_7.observeCharacter(v_u_13, function(p68)
		-- upvalues: (ref) v_u_2
		if p68 then
			v_u_2:UnbindAction("jumpAction")
		end
		return function() end
	end)
	v_u_6.CreateListener(v_u_13, "Settings.Keyboard/Mouse", function(p69)
		-- upvalues: (ref) v_u_1
		if p69 then
			v_u_1.loadActionsFromDatabase(p69)
		end
	end)
	v_u_9.observerRouter("RebindKeybinds", function()
		-- upvalues: (ref) v_u_6, (ref) v_u_13, (ref) v_u_1
		local v70 = v_u_6.Get(v_u_13, "Settings.Keyboard/Mouse")
		if not v70 then
			return false
		end
		v_u_1.loadActionsFromDatabase(v70)
		return true
	end)
end
function v_u_1.getActionKeybinds(p71) -- name: getActionKeybinds
	-- upvalues: (copy) v_u_16
	local v72 = {}
	local v73 = v_u_16[p71]
	if v73 then
		for _, v74 in ipairs(v73.Keybinds) do
			if typeof(v74) == "string" then
				continue
			end
			table.insert(v72, v74)
		end
	end
	return v72
end
function v_u_1.isBindingPressed(p75) -- name: isBindingPressed
	-- upvalues: (copy) v_u_4
	if typeof(p75) == "EnumItem" then
		if p75.EnumType == Enum.KeyCode then
			if p75 == Enum.KeyCode.ButtonR2 and true or p75 == Enum.KeyCode.ButtonL2 then
				for _, v76 in v_u_4:GetConnectedGamepads() do
					for _, v77 in v_u_4:GetGamepadState(v76) do
						if v77.KeyCode ~= p75 or v77.Position.Z <= 0.3 then
							continue
						end
						return true
					end
				end
				return false
			end
			local v78 = p75.Name
			if not (string.match(v78, "^Button") or string.match(v78, "^DPad")) then
				return v_u_4:IsKeyDown(p75)
			end
			for _, v79 in v_u_4:GetConnectedGamepads() do
				if not v_u_4:IsGamepadButtonDown(v79, p75) then
					continue
				end
				return true
			end
			return false
		elseif p75.EnumType == Enum.UserInputType then
			return v_u_4:IsMouseButtonPressed(p75)
		else
			return false
		end
	else
		return false
	end
end
function v_u_1.isActionPressed(p80, p81) -- name: isActionPressed
	-- upvalues: (copy) v_u_1
	local v82 = v_u_1.getActionKeybinds(p80)
	if #v82 == 0 then
		v82 = p81 or v82
	end
	for _, v83 in ipairs(v82) do
		if not v_u_1.isBindingPressed(v83) then
			continue
		end
		return true
	end
	return false
end
function v_u_1.Start() -- name: Start
	-- upvalues: (copy) v_u_4, (copy) v_u_17, (copy) v_u_28
	v_u_4.InputChanged:Connect(function(p84)
		-- upvalues: (ref) v_u_17, (ref) v_u_28
		if p84.UserInputType == Enum.UserInputType.MouseWheel then
			local v85 = p84.Position.Z
			if v85 > 0 then
				local v86 = v_u_17.ScrollWheelUp
				if v86 then
					v_u_28(v86, Enum.UserInputState.Begin, {
						["UserInputType"] = nil,
						["Delta"] = Vector3.new(0, 1, 0),
						["UserInputType"] = Enum.UserInputType.MouseWheel
					})
					task.defer(v_u_28, v86, Enum.UserInputState.End, {
						["UserInputType"] = nil,
						["Delta"] = Vector3.new(0, 1, 0),
						["UserInputType"] = Enum.UserInputType.MouseWheel
					})
				end
			else
				if v85 < 0 then
					local v87 = v_u_17.ScrollWheelDown
					if not v87 then
						return
					end
					v_u_28(v87, Enum.UserInputState.Begin, {
						["UserInputType"] = nil,
						["Delta"] = Vector3.new(0, -1, 0),
						["UserInputType"] = Enum.UserInputType.MouseWheel
					})
					task.defer(v_u_28, v87, Enum.UserInputState.End, {
						["UserInputType"] = nil,
						["Delta"] = Vector3.new(0, -1, 0),
						["UserInputType"] = Enum.UserInputType.MouseWheel
					})
				end
				return
			end
		else
			return
		end
	end)
end
return v_u_1
-- NIGHT Analyzer | ReplicatedStorage.Controllers.TimerController
-- ModuleScript | 123 linhas | 3114 bytes | hash 0ffcc149

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = {}
local v_u_4 = {}
local function v_u_7(p5) -- name: WaitForTimersLoaded
	-- upvalues: (copy) v_u_2
	local v6 = 0
	if not v_u_2:GetAttribute("TimersLoaded") then
		v6 = v6 + task.wait()
		if p5 > v6 then
			continue
		end
	end
end
function v_u_1.GetTimer(p8) -- name: GetTimer
	-- upvalues: (copy) v_u_2
	local v9 = v_u_2:GetAttribute((("timers_source/%*"):format(p8)))
	local v10 = typeof(v9) == "number"
	assert(v10, "Timer attribute is not a number.")
	return v9
end
function v_u_1.GetSecondsRemaining(p11) -- name: GetSecondsRemaining
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v12 = v_u_2:GetAttribute((("timers_source/%*"):format(p11)))
	if typeof(v12) == "number" then
		local v13 = workspace:GetServerTimeNow()
		if v12 > 1000000000000 then
			local v14 = v12 / 1000 - v13
			return math.max(0, v14)
		elseif v12 > 1000000000 then
			local v15 = v12 - v13
			return math.max(0, v15)
		else
			local v16 = v_u_4[p11]
			if v16 and v16.Tick == v12 then
				local v17 = v12 - (v13 - v16.At)
				return math.max(0, v17)
			else
				v_u_4[p11] = {
					["Tick"] = v12,
					["At"] = v13
				}
				return math.max(0, v12)
			end
		end
	else
		return nil
	end
end
function v_u_1.ObserveRunning(p_u_18, p_u_19) -- name: ObserveRunning
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v_u_20 = nil
	local v_u_21 = nil
	local v_u_22 = nil
	local function v_u_23() -- name: onExpiry
		-- upvalues: (ref) v_u_21, (ref) v_u_22
		v_u_21 = nil
		v_u_22()
	end
	v_u_22 = function() -- name: update
		-- upvalues: (ref) v_u_21, (ref) v_u_1, (copy) p_u_18, (copy) v_u_23, (ref) v_u_20, (copy) p_u_19
		if v_u_21 then
			task.cancel(v_u_21)
			v_u_21 = nil
		end
		local v24 = v_u_1.GetSecondsRemaining(p_u_18)
		local v25
		if v24 == nil then
			v25 = false
		else
			v25 = v24 > 0
		end
		if v25 then
			v_u_21 = task.delay(v24, v_u_23)
		end
		if v25 ~= v_u_20 then
			v_u_20 = v25
			p_u_19(v25)
		end
	end
	v_u_2:GetAttributeChangedSignal((("timers_source/%*"):format(p_u_18))):Connect(v_u_22)
	v_u_22()
end
function v_u_1.ListenToTimerChanged(p26, p27) -- name: ListenToTimerChanged
	-- upvalues: (copy) v_u_1, (copy) v_u_3
	local v28 = v_u_1.GetTimer(p26)
	v_u_3[p26] = v_u_3[p26] or {}
	local v29 = v_u_3[p26]
	table.insert(v29, p27)
	p27(v28)
end
function v_u_1.Initialize() -- name: Initialize
	-- upvalues: (copy) v_u_7, (copy) v_u_2, (copy) v_u_3, (copy) v_u_1
	v_u_7(10)
	for v30 in v_u_2:GetAttributes() do
		if not string.find(string.lower(v30), "timers_source") then
			continue
		end
		local v_u_31 = string.gsub(v30, "timers_source/", "")
		local v32 = v_u_3[v_u_31]
		if v32 and #v32 ~= 0 then
			local v33 = v_u_1.GetTimer(v_u_31)
			for _, v34 in v32 do
				v34(v33)
			end
		end
		v_u_2:GetAttributeChangedSignal(v30):Connect(function()
			-- upvalues: (copy) v_u_31, (ref) v_u_3, (ref) v_u_1
			local v35 = v_u_31
			local v36 = v_u_3[v35]
			if v36 then
				if #v36 == 0 then
					return
				end
				local v37 = v_u_1.GetTimer(v35)
				for _, v38 in v36 do
					v38(v37)
				end
			end
		end)
	end
end
return v_u_1
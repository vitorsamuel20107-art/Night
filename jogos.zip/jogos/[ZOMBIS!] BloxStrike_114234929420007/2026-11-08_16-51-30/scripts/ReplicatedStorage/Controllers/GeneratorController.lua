-- NIGHT Analyzer | ReplicatedStorage.Controllers.GeneratorController
-- ModuleScript | 600 linhas | 15723 bytes | hash 6805bbf6

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(v_u_2.Controllers.RunServiceController)
local v_u_5 = require(v_u_2.Classes.Sound)
local v_u_6 = require(v_u_2.Packages.Observers)
local v7 = require(v_u_2.Packages.Signal)
local v_u_8 = require(v_u_2.Shared.Janitor)
local v_u_9 = require(v_u_2.Components.Common.GeneratorProtocol)
local v_u_10 = require(v_u_2.Database.Components.GameState)
local v_u_11 = v_u_9.HEALTH_ATTRIBUTE
local v_u_12 = v_u_9.MAX_HEALTH_ATTRIBUTE
local v_u_13 = v_u_9.DESTROYED_ATTRIBUTE
local v_u_14 = v_u_9.KEY_ATTRIBUTE
local v_u_15 = v_u_9.TIER_TEXTURES
local v_u_16 = #v_u_15 + 1
local v_u_17 = {
	0,
	4,
	10,
	20,
	32
}
local v_u_18 = {
	Color3.fromRGB(200, 200, 200),
	Color3.fromRGB(170, 170, 170),
	Color3.fromRGB(110, 110, 110),
	Color3.fromRGB(55, 55, 55),
	Color3.fromRGB(25, 25, 25)
}
local v_u_19 = {
	2,
	2.5,
	3.5,
	4.5,
	5.5
}
local v_u_20 = {
	0,
	0,
	3,
	9,
	2
}
local v_u_21 = {
	1.2,
	1,
	0.8,
	0.6,
	0
}
local v_u_22 = {
	1,
	0.96,
	0.9,
	0.82,
	0
}
local v_u_23 = Color3.fromRGB(230, 238, 255)
local v_u_24 = Color3.fromRGB(214, 41, 41)
local v_u_25 = Color3.fromRGB(165, 183, 212)
local v_u_26 = {}
local v_u_27 = v7.new()
v_u_1.StateChanged = v_u_27
local v_u_28 = nil
local v_u_29 = nil
local v_u_30 = false
local function v_u_33(p31) -- name: makeSmoke
	local v32 = Instance.new("ParticleEmitter")
	v32.Name = "Smoke"
	v32.Texture = "rbxasset://textures/particles/smoke_main.dds"
	v32.Rate = 0
	v32.Lifetime = NumberRange.new(2.5, 4)
	v32.Speed = NumberRange.new(2, 4)
	v32.SpreadAngle = Vector2.new(12, 12)
	v32.Rotation = NumberRange.new(0, 360)
	v32.RotSpeed = NumberRange.new(-20, 20)
	v32.Acceleration = Vector3.new(0, 1.5, 0)
	v32.Drag = 1
	v32.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.35), NumberSequenceKeypoint.new(0.7, 0.75), NumberSequenceKeypoint.new(1, 1) })
	v32.LightInfluence = 0.9
	v32.EmissionDirection = Enum.NormalId.Top
	v32.Parent = p31
	return v32
end
local function v_u_39(p34, p35, p36) -- name: makeSparks
	local v37 = Instance.new("ParticleEmitter")
	v37.Name = p35
	v37.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	v37.Rate = 0
	v37.Lifetime = NumberRange.new(0.3, 0.8)
	local v38
	if p36 then
		v38 = NumberRange.new(6, 14)
	else
		v38 = NumberRange.new(14, 30)
	end
	v37.Speed = v38
	v37.SpreadAngle = Vector2.new(70, 70)
	v37.Acceleration = Vector3.new(0, -40, 0)
	v37.Drag = 2
	v37.LightEmission = 1
	v37.LightInfluence = 0
	v37.Brightness = 3
	v37.Color = ColorSequence.new(Color3.fromRGB(255, 220, 140), Color3.fromRGB(255, 120, 40))
	v37.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.25), NumberSequenceKeypoint.new(1, 0.05) })
	v37.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
	v37.EmissionDirection = Enum.NormalId.Top
	v37.Parent = p34
	return v37
end
local function v_u_43(p40) -- name: collectFadeTargets
	local v41 = {}
	for _, v42 in p40:GetDescendants() do
		if v42:IsA("GuiObject") then
			v41[#v41 + 1] = {
				["Instance"] = nil,
				["Property"] = "BackgroundTransparency",
				["Base"] = nil,
				["Instance"] = v42,
				["Base"] = v42.BackgroundTransparency
			}
			if v42:IsA("TextLabel") then
				v41[#v41 + 1] = {
					["Instance"] = nil,
					["Property"] = "TextTransparency",
					["Base"] = nil,
					["Instance"] = v42,
					["Base"] = v42.TextTransparency
				}
			else
				if not v42:IsA("ImageLabel") then
					continue
				end
				v41[#v41 + 1] = {
					["Instance"] = nil,
					["Property"] = "ImageTransparency",
					["Base"] = nil,
					["Instance"] = v42,
					["Base"] = v42.ImageTransparency
				}
			end
		else
			if not v42:IsA("UIStroke") then
				continue
			end
			v41[#v41 + 1] = {
				["Instance"] = nil,
				["Property"] = "Transparency",
				["Base"] = nil,
				["Instance"] = v42,
				["Base"] = v42.Transparency
			}
		end
	end
	return v41
end
local function v_u_49(p44, p45) -- name: makeMarker
	-- upvalues: (copy) v_u_2, (copy) v_u_43
	local v46 = v_u_2.Assets.UI.Survival.GeneratorStatus:Clone()
	local v47 = p44.Size.Y / 2 + 2.5
	v46.StudsOffsetWorldSpace = Vector3.new(0, v47, 0)
	local v48 = v46.Panel
	v48.Letter.Text = p45
	v46.Parent = p44
	return {
		["Gui"] = nil,
		["Bar"] = nil,
		["Amount"] = nil,
		["Letter"] = nil,
		["LetterStroke"] = nil,
		["Fade"] = nil,
		["Visible"] = 1,
		["Gui"] = v46,
		["Bar"] = v48.Track.Bar,
		["Amount"] = v48.Amount,
		["Letter"] = v48.Letter,
		["LetterStroke"] = v48.Letter.UIStroke,
		["Fade"] = v_u_43(v46)
	}
end
local function v_u_63(p50, p51) -- name: refreshMarker
	-- upvalues: (copy) v_u_24, (copy) v_u_23, (copy) v_u_25
	local v52 = p50.Destroyed
	local v53
	if p50.MaxHealth > 0 then
		local v54 = p50.Health / p50.MaxHealth
		v53 = math.clamp(v54, 0, 1)
	else
		v53 = 0
	end
	p51.Bar.Size = UDim2.fromScale(v53, 1)
	local v55 = p51.Bar
	local v56
	if v52 or v53 <= 0.25 then
		v56 = v_u_24
	else
		v56 = v_u_23
	end
	v55.BackgroundColor3 = v56
	local v57 = p51.Amount
	local v58
	if v52 then
		v58 = "OFFLINE"
	else
		local v59 = v53 * 100 + 0.5
		v58 = ("%*%%"):format((math.floor(v59)))
	end
	v57.Text = v58
	local v60 = p51.Amount
	local v61
	if v52 then
		v61 = v_u_24
	else
		v61 = Color3.new(1, 1, 1)
	end
	v60.TextColor3 = v61
	local v62
	if v52 then
		v62 = v_u_24
	else
		v62 = v_u_25
	end
	p51.Letter.TextColor3 = v62
	p51.LetterStroke.Color = v62
end
local function v_u_70(p64) -- name: refresh
	-- upvalues: (copy) v_u_9, (copy) v_u_16, (copy) v_u_15, (copy) v_u_17, (copy) v_u_18, (copy) v_u_19, (copy) v_u_20, (copy) v_u_21, (copy) v_u_22, (ref) v_u_29, (copy) v_u_63
	local v65 = p64.Visuals
	if v65 then
		local v66 = v_u_9.TierFor(p64.Health, p64.MaxHealth)
		local v67
		if p64.Destroyed then
			v67 = v_u_16
		else
			v67 = v66
		end
		local v68 = v65.Part
		if v66 ~= v65.Tier and v68:IsA("MeshPart") then
			v68.TextureID = v_u_15[v66] or v_u_15[#v_u_15]
		end
		v65.Tier = v66
		v65.Smoke.Rate = v_u_17[v67]
		v65.Smoke.Color = ColorSequence.new(v_u_18[v67])
		v65.Smoke.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v_u_19[v67] * 0.5), NumberSequenceKeypoint.new(1, v_u_19[v67] * 1.6) })
		v65.Embers.Rate = v_u_20[v67]
		v65.Light.Brightness = v_u_21[v67]
		v65.Light.Enabled = v_u_21[v67] > 0
		local v69 = v65.Hum
		if v_u_22[v67] > 0 then
			if not (v69 and v69.Parent) and v_u_29 then
				v69 = v_u_29:play({
					["Parent"] = nil,
					["Name"] = "Generator Hum",
					["Parent"] = v68
				})
				v65.Hum = v69
			end
			if v69 then
				v69.PlaybackSpeed = v_u_22[v67]
			end
		elseif v69 then
			v69:Destroy()
			v65.Hum = nil
		end
		v_u_63(p64, v65.Marker)
	end
end
local function v_u_76(p71) -- name: detachVisuals
	local v72 = p71.Visuals
	if v72 then
		p71.Visuals = nil
		local v73 = {
			v72.Smoke,
			v72.Sparks,
			v72.Embers,
			v72.Light,
			v72.Marker.Gui
		}
		if v72.Hum then
			local v74 = v72.Hum
			table.insert(v73, v74)
		end
		for _, v75 in v73 do
			if not v75.Parent then
				continue
			end
			v75:Destroy()
		end
	end
end
local function v_u_80(p77, p78) -- name: attachVisuals
	-- upvalues: (copy) v_u_76, (copy) v_u_33, (copy) v_u_39, (copy) v_u_49, (copy) v_u_70
	v_u_76(p77)
	local v79 = Instance.new("PointLight")
	v79.Name = "Glow"
	v79.Color = Color3.fromRGB(255, 190, 120)
	v79.Range = 14
	v79.Shadows = false
	v79.Parent = p78
	p77.Visuals = {
		["Part"] = nil,
		["Smoke"] = nil,
		["Sparks"] = nil,
		["Embers"] = nil,
		["Light"] = nil,
		["Hum"] = nil,
		["Marker"] = nil,
		["Tier"] = 0,
		["Part"] = p78,
		["Smoke"] = v_u_33(p78),
		["Sparks"] = v_u_39(p78, "HitSparks", false),
		["Embers"] = v_u_39(p78, "Embers", true),
		["Light"] = v79,
		["Marker"] = v_u_49(p78, p77.Key)
	}
	v_u_70(p77)
end
local function v_u_89(p81) -- name: flicker
	-- upvalues: (copy) v_u_26, (copy) v_u_21
	local v82 = p81 * 23
	local v83 = math.sin(v82) * 0.5
	local v84 = p81 * 7.3
	local v85 = v83 * math.sin(v84) + 0.5
	for _, v86 in v_u_26 do
		local v87 = v86.Visuals
		if not v87 or (v86.Destroyed or v87.Tier < 3) then
			continue
		end
		local v88 = v87.Tier >= 4 and 0.6 or 0.24
		v87.Light.Brightness = v_u_21[v87.Tier] * (1 - v88 * v85)
	end
end
local function v_u_106() -- name: fadeMarkers
	-- upvalues: (copy) v_u_3, (copy) v_u_26, (ref) v_u_30
	local v90 = v_u_3.CurrentCamera
	if v90 then
		local v91 = v90.ViewportSize
		local v92 = v91.X / 2
		local v93 = v91.Y / 2
		local v94 = math.max(v93, 1)
		for _, v95 in v_u_26 do
			local v96 = v95.Visuals
			if not v96 then
				continue
			end
			local v97, v98 = v90:WorldToViewportPoint(v96.Part.Position)
			local v99 = 1
			if v_u_30 then
				v99 = 0
			elseif v98 then
				local v100 = v97.X - v92
				local v101 = v97.Y - v93
				local v102 = v100 * v100 + v101 * v101
				local v103 = (math.sqrt(v102) / v94 - 0.3) / 0.3
				v99 = math.clamp(v103, 0, 1)
			end
			local v104 = v96.Marker
			if v99 == v104.Visible then
				continue
			end
			v104.Visible = v99
			for _, v105 in v104.Fade do
				v105.Instance[v105.Property] = v105.Base + (1 - v105.Base) * (1 - v99)
			end
		end
	end
end
local function v_u_107() -- name: update
	-- upvalues: (copy) v_u_89, (copy) v_u_106
	v_u_89(os.clock())
	v_u_106()
end
local function v_u_139(p_u_108) -- name: observeGenerator
	-- upvalues: (copy) v_u_26, (copy) v_u_14, (copy) v_u_11, (copy) v_u_12, (copy) v_u_13, (copy) v_u_8, (ref) v_u_28, (copy) v_u_4, (copy) v_u_107, (copy) v_u_76, (copy) v_u_27, (copy) v_u_80, (copy) v_u_70, (ref) v_u_29
	if not p_u_108:IsA("Model") or v_u_26[p_u_108] then
		return nil
	end
	local v109 = p_u_108:GetAttribute(v_u_14)
	local v_u_110 = {
		["Model"] = nil,
		["Key"] = nil,
		["Visuals"] = nil,
		["Health"] = nil,
		["MaxHealth"] = nil,
		["Destroyed"] = nil,
		["Model"] = p_u_108,
		["Key"] = typeof(v109) ~= "string" and "?" or v109
	}
	local v111 = v_u_11
	v_u_110.Health = tonumber(p_u_108:GetAttribute(v111)) or 0
	local v112 = v_u_12
	v_u_110.MaxHealth = tonumber(p_u_108:GetAttribute(v112)) or 1
	v_u_110.Destroyed = p_u_108:GetAttribute(v_u_13) == true
	local v_u_113 = v_u_8.new()
	v_u_26[p_u_108] = v_u_110
	if not v_u_28 then
		v_u_28 = v_u_4.BindToRenderSteppedEvent("GeneratorController.Update", v_u_107)
	end
	v_u_113:Add(function()
		-- upvalues: (ref) v_u_26, (copy) p_u_108, (ref) v_u_76, (copy) v_u_110, (ref) v_u_28, (ref) v_u_27
		v_u_26[p_u_108] = nil
		v_u_76(v_u_110)
		if next(v_u_26) == nil then
			if v_u_28 then
				v_u_28:Disconnect()
				v_u_28 = nil
			end
			v_u_27:Fire({
				["Key"] = "",
				["Health"] = 0,
				["MaxHealth"] = 0,
				["Destroyed"] = false,
				["Drop"] = 0
			})
		end
	end, true)
	local v114 = p_u_108:FindFirstChildWhichIsA("MeshPart") or p_u_108:FindFirstChildWhichIsA("BasePart")
	if v114 then
		v_u_80(v_u_110, v114)
	end
	v_u_113:Add(p_u_108.ChildAdded:Connect(function(p115)
		-- upvalues: (copy) v_u_110, (ref) v_u_80
		if p115:IsA("BasePart") and (not v_u_110.Visuals or p115:IsA("MeshPart")) then
			v_u_80(v_u_110, p115)
		end
	end))
	v_u_113:Add(p_u_108.ChildRemoved:Connect(function(p116)
		-- upvalues: (copy) v_u_110, (ref) v_u_76, (copy) p_u_108, (ref) v_u_80
		local v117 = v_u_110.Visuals
		if v117 and v117.Part == p116 then
			v_u_76(v_u_110)
			local v118 = p_u_108
			local v119 = v118:FindFirstChildWhichIsA("MeshPart") or v118:FindFirstChildWhichIsA("BasePart")
			if v119 then
				v_u_80(v_u_110, v119)
			end
		end
	end))
	v_u_113:Add(p_u_108:GetAttributeChangedSignal(v_u_14):Connect(function()
		-- upvalues: (copy) p_u_108, (ref) v_u_14, (copy) v_u_110, (ref) v_u_70, (ref) v_u_27
		local v120 = p_u_108:GetAttribute(v_u_14)
		v_u_110.Key = typeof(v120) ~= "string" and "?" or v120
		v_u_70(v_u_110)
		local v121 = v_u_110
		v_u_27:Fire({
			["Key"] = nil,
			["Health"] = nil,
			["MaxHealth"] = nil,
			["Destroyed"] = nil,
			["Drop"] = 0,
			["Key"] = v121.Key,
			["Health"] = v121.Health,
			["MaxHealth"] = v121.MaxHealth,
			["Destroyed"] = v121.Destroyed
		})
	end))
	v_u_113:Add(p_u_108:GetAttributeChangedSignal(v_u_11):Connect(function()
		-- upvalues: (copy) p_u_108, (ref) v_u_11, (copy) v_u_110, (ref) v_u_29, (ref) v_u_70, (ref) v_u_27
		local v122 = p_u_108
		local v123 = v_u_11
		local v124 = tonumber(v122:GetAttribute(v123)) or 0
		local v125 = v_u_110.Health - v124
		v_u_110.Health = v124
		local v126 = v_u_110.Visuals
		if v125 > 0 and (not v_u_110.Destroyed and v126) then
			local v127 = v126.Sparks
			local v128 = 18 * v125 / 6
			local v129 = math.round(v128)
			v127:Emit((math.clamp(v129, 6, 60)))
			if v_u_29 then
				v_u_29:play({
					["Parent"] = nil,
					["Name"] = "Generator Hit",
					["Parent"] = v126.Part
				})
			end
		end
		v_u_70(v_u_110)
		local v130 = v_u_110
		local v131 = math.max(v125, 0)
		v_u_27:Fire({
			["Key"] = v130.Key,
			["Health"] = v130.Health,
			["MaxHealth"] = v130.MaxHealth,
			["Destroyed"] = v130.Destroyed,
			["Drop"] = v131
		})
	end))
	v_u_113:Add(p_u_108:GetAttributeChangedSignal(v_u_12):Connect(function()
		-- upvalues: (copy) v_u_110, (copy) p_u_108, (ref) v_u_12, (ref) v_u_70, (ref) v_u_27
		local v132 = p_u_108
		local v133 = v_u_12
		v_u_110.MaxHealth = tonumber(v132:GetAttribute(v133)) or 1
		v_u_70(v_u_110)
		local v134 = v_u_110
		v_u_27:Fire({
			["Key"] = nil,
			["Health"] = nil,
			["MaxHealth"] = nil,
			["Destroyed"] = nil,
			["Drop"] = 0,
			["Key"] = v134.Key,
			["Health"] = v134.Health,
			["MaxHealth"] = v134.MaxHealth,
			["Destroyed"] = v134.Destroyed
		})
	end))
	v_u_113:Add(p_u_108:GetAttributeChangedSignal(v_u_13):Connect(function()
		-- upvalues: (copy) p_u_108, (ref) v_u_13, (copy) v_u_110, (ref) v_u_29, (ref) v_u_70, (ref) v_u_27
		local v135 = p_u_108:GetAttribute(v_u_13) == true
		local v136
		if v135 then
			v136 = not v_u_110.Destroyed
		else
			v136 = v135
		end
		v_u_110.Destroyed = v135
		local v137 = v136 and v_u_110.Visuals
		if v137 then
			if v_u_29 then
				v_u_29:play({
					["Parent"] = nil,
					["Name"] = "Generator Destroyed",
					["Parent"] = v137.Part
				})
			end
			v137.Sparks:Emit(72)
			v137.Smoke:Emit(24)
		end
		v_u_70(v_u_110)
		local v138 = v_u_110
		v_u_27:Fire({
			["Key"] = nil,
			["Health"] = nil,
			["MaxHealth"] = nil,
			["Destroyed"] = nil,
			["Drop"] = 0,
			["Key"] = v138.Key,
			["Health"] = v138.Health,
			["MaxHealth"] = v138.MaxHealth,
			["Destroyed"] = v138.Destroyed
		})
	end))
	v_u_27:Fire({
		["Key"] = nil,
		["Health"] = nil,
		["MaxHealth"] = nil,
		["Destroyed"] = nil,
		["Drop"] = 0,
		["Key"] = v_u_110.Key,
		["Health"] = v_u_110.Health,
		["MaxHealth"] = v_u_110.MaxHealth,
		["Destroyed"] = v_u_110.Destroyed
	})
	return function()
		-- upvalues: (copy) v_u_113
		v_u_113:Destroy()
	end
end
function v_u_1.GetStates() -- name: GetStates
	-- upvalues: (copy) v_u_26
	local v140 = {}
	for _, v141 in v_u_26 do
		v140[v141.Key] = {
			["Key"] = nil,
			["Health"] = nil,
			["MaxHealth"] = nil,
			["Destroyed"] = nil,
			["Drop"] = 0,
			["Key"] = v141.Key,
			["Health"] = v141.Health,
			["MaxHealth"] = v141.MaxHealth,
			["Destroyed"] = v141.Destroyed
		}
	end
	return v140
end
function v_u_1.Bind(p142) -- name: Bind
	-- upvalues: (copy) v_u_27, (copy) v_u_1
	local v_u_143 = v_u_27:Connect(p142)
	for _, v144 in v_u_1.GetStates() do
		task.spawn(p142, v144)
	end
	return function()
		-- upvalues: (copy) v_u_143
		v_u_143:Disconnect()
	end
end
function v_u_1.Start() -- name: Start
	-- upvalues: (ref) v_u_29, (copy) v_u_5, (copy) v_u_10, (ref) v_u_30, (copy) v_u_6, (copy) v_u_9, (copy) v_u_139, (copy) v_u_3
	v_u_29 = v_u_5.new("Survival")
	v_u_10.ListenToState(function(_, p145)
		-- upvalues: (ref) v_u_30
		v_u_30 = p145 == "Game Ending"
	end)
	local v146 = { v_u_3 }
	v_u_6.observeTag(v_u_9.TAG, v_u_139, v146)
end
return v_u_1
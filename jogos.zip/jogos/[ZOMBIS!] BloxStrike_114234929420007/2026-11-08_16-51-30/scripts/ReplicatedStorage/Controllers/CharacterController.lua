-- NIGHT Analyzer | ReplicatedStorage.Controllers.CharacterController
-- ModuleScript | 23 linhas | 756 bytes | hash 737de34c

local v_u_1 = require(script.LocalCharacter)
local v_u_2 = require(script.RemoteCharacters)
return {
	["Initialize"] = function() -- name: Initialize
		-- upvalues: (copy) v_u_1, (copy) v_u_2
		v_u_1.Initialize()
		v_u_2.Initialize()
	end,
	["Start"] = v_u_1.Start,
	["getCurrentCharacter"] = v_u_1.getCurrentCharacter,
	["GetWalkState"] = v_u_1.GetWalkState,
	["GetSprintState"] = v_u_1.GetSprintState,
	["GetCrouchState"] = v_u_1.GetCrouchState,
	["walk"] = v_u_1.walk,
	["sprint"] = v_u_1.sprint,
	["crouch"] = v_u_1.crouch,
	["jump"] = v_u_1.jump,
	["PredictDoorUse"] = v_u_1.PredictDoorUse,
	["IsDoorInUseRange"] = v_u_1.IsDoorInUseRange,
	["TrackCharacter"] = v_u_2.Track,
	["UntrackCharacter"] = v_u_2.Untrack,
	["GetRemoteShell"] = v_u_2.GetShell
}
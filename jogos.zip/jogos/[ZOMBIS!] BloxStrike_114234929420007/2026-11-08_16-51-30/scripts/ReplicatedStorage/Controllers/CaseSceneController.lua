-- NIGHT Analyzer | ReplicatedStorage.Controllers.CaseSceneController
-- ModuleScript | 1474 linhas | 43011 bytes | hash fb781a1c

local v_u_1 = {}
local v_u_2 = game:GetService("ContextActionService")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game:GetService("Lighting")
local v7 = game:GetService("Players")
local v_u_8 = game:GetService("RunService")
local v_u_9 = v7.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainGui", (1 / 0))
local v_u_10 = require(script:WaitForChild("SceneRegistry"))
local v_u_11 = require(script:WaitForChild("ConsoleBoardAnimator"))
require(script:WaitForChild("ConsoleItemRoller"))
require(v_u_3.Database.Custom.ConsoleTypes)
require(v_u_3.Database.Custom.Types)
local v_u_12 = require(v_u_3.Database.Custom.GameStats.Rarities)
local v_u_13 = require(v_u_3.Database.Components.Libraries.Skins)
local v_u_14 = require(v_u_3.Database.Components.Libraries.Cases)
local v15 = require(v_u_3.Shared.Janitor)
local v_u_16 = require(v_u_3.Components.Common.SceneParking)
local v_u_17 = require(v_u_3.Controllers.MenuSceneController)
local v_u_18 = require(v_u_3.Controllers.CameraController)
local v_u_19 = require(v_u_3.Controllers.RunServiceController)
local v_u_20 = require(v_u_3.Database.Security.Router)
local v_u_21 = require(v_u_3.Interface.MenuState)
local v_u_22 = require(v_u_3.Database.Custom.Constants)
local v_u_23 = workspace.CurrentCamera
local v_u_24 = false
local v_u_25 = {}
local v_u_26 = nil
local v_u_27 = nil
local v_u_28 = nil
local v_u_29 = v15.new()
local v_u_30 = false
local v_u_31 = nil
local v_u_32 = {}
local v_u_33 = false
local v_u_34 = nil
local v_u_35 = nil
local v_u_36 = 0
local v_u_37 = nil
local v_u_38 = {}
local v_u_39 = nil
local v_u_40 = nil
local function v_u_41(...) -- name: DebugLog end
local v_u_42 = false
local v_u_43 = nil
local v_u_44 = nil
local v_u_45 = nil
local v_u_46 = 0
local v_u_47 = 1
local v_u_48 = 0
local v_u_49 = nil
local v_u_50 = false
local v_u_51 = false
local function v_u_57() -- name: hideMenuFrames
	-- upvalues: (copy) v_u_21, (ref) v_u_24, (copy) v_u_17
	v_u_21.EnterCaseScene()
	local v52 = v_u_21.GetMenuFrame()
	if v52 then
		v_u_24 = v_u_17.IsActive()
		if v_u_24 then
			v_u_17.HideMenuScene(true, true)
			v_u_17.SetMusicVolumeMultiplier(0.5, 0.5)
		end
		v_u_21.SetBlurEnabled(false)
		v52.BackgroundTransparency = 1
		local v53 = v52:FindFirstChild("Pattern")
		if v53 then
			v53.Visible = false
		end
		local v54 = v52:FindFirstChild("Top")
		if v54 then
			v54.Visible = false
		end
		local v55 = v52:FindFirstChild("Store")
		if v55 then
			v55.Visible = true
		end
		for _, v56 in v52:GetChildren() do
			if not v56:IsA("Frame") or (v56.Name == "Top" or (v56.Name == "Store" or v56.Name == "OpenCase")) then
				continue
			end
			v56.Visible = false
		end
	end
end
local function v_u_61(p58) -- name: hideViewmodel
	-- upvalues: (ref) v_u_32
	for _, v59 in p58:GetDescendants() do
		if v59:IsA("BasePart") or v59:IsA("Texture") then
			if v59.Transparency >= 1 then
				continue
			end
			v59:SetAttribute("_CaseScenePrevTransparency", v59.Transparency)
			v59.Transparency = 1
		else
			if not (v59:IsA("SurfaceGui") and v59.Enabled) then
				continue
			end
			v59:SetAttribute("_CaseScenePrevSurfaceGuiEnabled", true)
			v59.Enabled = false
		end
	end
	local v60 = v_u_32
	table.insert(v60, p58)
end
local function v_u_64() -- name: hideViewmodels
	-- upvalues: (ref) v_u_32, (ref) v_u_28, (copy) v_u_23, (copy) v_u_61
	v_u_32 = {}
	local v62 = v_u_28 and v_u_28.AssetFolder or nil
	for _, v63 in v_u_23:GetChildren() do
		if not v63:IsA("Model") or v63.Name == v62 then
			continue
		end
		v_u_61(v63)
	end
end
local function v_u_68() -- name: showViewmodels
	-- upvalues: (ref) v_u_32
	for _, v65 in v_u_32 do
		if not (v65 and v65.Parent) then
			continue
		end
		for _, v66 in v65:GetDescendants() do
			if v66:IsA("BasePart") or v66:IsA("Texture") then
				local v67 = v66:GetAttribute("_CaseScenePrevTransparency")
				if v67 == nil then
					if not v66:IsA("Texture") then
						continue
					end
					v66.Transparency = 0.3
				else
					v66.Transparency = v67
					v66:SetAttribute("_CaseScenePrevTransparency", nil)
				end
			else
				if not v66:IsA("SurfaceGui") or v66:GetAttribute("_CaseScenePrevSurfaceGuiEnabled") == nil then
					continue
				end
				v66.Enabled = true
				v66:SetAttribute("_CaseScenePrevSurfaceGuiEnabled", nil)
			end
		end
	end
	v_u_32 = {}
end
local function v_u_72(p69) -- name: applyCaseFog
	-- upvalues: (copy) v_u_6
	local v70 = p69:FindFirstChild("CaseFog", true)
	if v70 and v70:IsA("Atmosphere") then
		for _, v71 in v_u_6:GetChildren() do
			if not v71:IsA("Atmosphere") then
				continue
			end
			v71:Destroy()
		end
		v70:Clone().Parent = v_u_6
	end
end
local function v_u_80() -- name: restoreMenuFrames
	-- upvalues: (copy) v_u_21, (ref) v_u_24, (copy) v_u_17
	local v73 = v_u_21.GetMenuFrame()
	if v73 and v73.Visible then
		local v74 = v_u_21.GetScreenBeforeCaseScene()
		local v75 = v_u_24
		v_u_24 = false
		v_u_21.ExitCaseScene()
		if v75 then
			v_u_17.ShowMenuScene()
			v_u_17.SetMusicVolumeMultiplier(1, 0.5)
		else
			v_u_17.ApplyMapLighting()
		end
		local v76 = v73:FindFirstChild("Top")
		if v76 then
			v76.Visible = true
		end
		local v77 = v73:FindFirstChild(v74 or "Dashboard")
		if v77 then
			v77.Visible = true
		elseif v74 then
			return
		end
		local v78
		if v74 == nil or v74 == "Dashboard" then
			v78 = false
		else
			v78 = v74 ~= "Play"
		end
		v_u_21.SetBlurEnabled(v78)
		v73.BackgroundTransparency = v78 and 0.15 or 1
		local v79 = v73:FindFirstChild("Pattern")
		if v79 then
			v79.Visible = not v78
		end
	else
		v_u_24 = false
		v_u_21.ExitCaseScene()
		v_u_17.ApplyMapLighting()
	end
end
local function v_u_88(p81, p82) -- name: setupCaseModel
	-- upvalues: (copy) v_u_3
	local v83 = p81:FindFirstChild("CaseMod")
	if v83 and v83:GetAttribute("IsDynamicModel") then
		v83:Destroy()
	end
	local v84 = v_u_3.Assets:FindFirstChild("CaseModels")
	if not v84 then
		warn("[CaseSceneController]: CaseModels folder not found in ReplicatedStorage.Assets")
		return nil
	end
	local v85 = v84:FindFirstChild(p82)
	if not v85 then
		warn("[CaseSceneController]: Case model not found for case: " .. p82)
		return nil
	end
	local v86 = v85:Clone()
	v86.Name = "CaseMod"
	v86:SetAttribute("IsDynamicModel", true)
	local v87 = p81:FindFirstChild("CasePivot")
	if v87 then
		v86:PivotTo(v87.CFrame)
	else
		warn("[CaseSceneController]: CasePivot not found in CaseScene")
	end
	v86.Parent = p81
	return v86
end
local function v_u_95(p89, p90) -- name: findAnimationController
	local v91 = p90.ConsoleColumnCount ~= nil
	local v92
	if v91 then
		v92 = p89:FindFirstChild("ConsoleLaptop", true)
	elseif p90.InteractionType == "Drag" then
		v92 = p89:FindFirstChild("Pack")
	else
		v92 = p89:FindFirstChild("CaseMod")
	end
	if not v92 then
		return nil
	end
	local v93
	if v91 then
		v93 = v92:FindFirstChildWhichIsA("AnimationController", true)
	else
		v93 = v92:FindFirstChildOfClass("AnimationController")
	end
	local v94 = not v93 or v93:FindFirstChildOfClass("Animator")
	if not v94 then
		v94 = Instance.new("Animator")
		v94.Parent = v93
	end
	return v94
end
local function v_u_103(p96, p97, p98) -- name: loadAnimations
	-- upvalues: (copy) v_u_95, (ref) v_u_38
	if p97.InteractionType == "Click" then
		if p98 then
			p98 = p98:FindFirstChildOfClass("AnimationController")
		end
	else
		p98 = false
	end
	local v99
	if p98 then
		v99 = p98:FindFirstChildOfClass("Animator")
		if not v99 then
			v99 = Instance.new("Animator")
			v99.Parent = p98
		end
	else
		v99 = v_u_95(p96, p97)
	end
	if v99 then
		for v100, v101 in p97.Animations do
			if not v101 then
				continue
			end
			local v102 = Instance.new("Animation")
			v102.AnimationId = v101
			v_u_38[v100] = v99:LoadAnimation(v102)
			v102:Destroy()
		end
	else
		warn("[CaseSceneController]: No animator found for scene")
	end
end
local function v_u_107(p104, p105) -- name: setEffectsEnabled
	if p104 then
		for _, v106 in p104:GetDescendants() do
			if not (v106:IsA("Beam") or v106:IsA("ParticleEmitter")) then
				continue
			end
			v106.Enabled = p105
		end
	end
end
local function v_u_112(p108, p109, p110) -- name: setCaseEffects
	-- upvalues: (ref) v_u_26, (copy) v_u_107
	local v111 = v_u_26
	if v111 then
		v111 = v_u_26:FindFirstChild("CaseMod")
	end
	if v111 then
		v_u_107(v111:FindFirstChild("IdleEffect"), p108)
		v_u_107(v111:FindFirstChild("OpeningEffect"), p109)
		if p110 ~= nil then
			v_u_107(v111:FindFirstChild("EffectsPart"), p110)
		end
	end
end
local function v_u_117(p113, p114) -- name: setupKeyframeSounds
	-- upvalues: (copy) v_u_20, (copy) v_u_29
	for v115, v_u_116 in p114 do
		v_u_29:Add((p113:GetMarkerReachedSignal(v115):Connect(function()
			-- upvalues: (ref) v_u_20, (copy) v_u_116
			v_u_20.broadcastRouter("RunStoreSound", v_u_116)
		end)))
	end
end
local function v_u_121(p118, p_u_119) -- name: playConsoleAnimationSound
	-- upvalues: (copy) v_u_29, (copy) v_u_20
	v_u_29:Remove(p_u_119)
	local v120 = v_u_20.broadcastRouter("RunStoreSound", p118)
	if v120 then
		v_u_29:Add(v120, "Destroy", p_u_119)
		v120.Destroying:Once(function()
			-- upvalues: (ref) v_u_29, (copy) p_u_119
			v_u_29:RemoveNoClean(p_u_119)
		end)
	end
end
local function v_u_134() -- name: playInspectAnimations
	-- upvalues: (ref) v_u_38, (ref) v_u_28, (copy) v_u_112, (copy) v_u_121, (copy) v_u_19, (copy) v_u_29, (copy) v_u_117, (copy) v_u_20, (ref) v_u_26
	if v_u_38.CaseFall then
		local v122
		if v_u_28 == nil then
			v122 = false
		else
			v122 = v_u_28.ConsoleColumnCount ~= nil
		end
		if v122 or v_u_38.CloseIdle then
			v_u_112(true, false, true)
			local v_u_123 = v_u_38.CaseFall
			local v124
			if v_u_28 == nil then
				v124 = false
			else
				v124 = v_u_28.ConsoleColumnCount ~= nil
			end
			if v124 then
				local v125 = v_u_121
				local v126 = v_u_28
				if v126 then
					v126 = v_u_28.Sounds
				end
				v125(v126 and v126.Enter or "Console Enter Animation", "ConsoleEnterSound")
				v_u_123:Play()
				local v_u_127 = nil
				v_u_127 = v_u_19.BindToHeartbeat(v_u_19.CreateBindingName("CaseSceneController.ConsoleEnterAnimationFreeze"), function()
					-- upvalues: (copy) v_u_123, (ref) v_u_127
					if v_u_123.Length > 0 and v_u_123.TimePosition >= v_u_123.Length - 0.05 then
						v_u_123:AdjustSpeed(0)
						v_u_127:Disconnect()
					end
				end)
				v_u_29:Add(v_u_127, "Disconnect", "ConsoleEnterAnimationFreeze")
			else
				local v128 = v_u_28
				if v128 then
					v128 = v_u_28.AnimationKeyframeSounds
				end
				if v128 then
					v128 = v128.CaseFall
				end
				if v128 then
					v_u_117(v_u_123, v128)
				else
					local v129 = v_u_28
					if v129 then
						v129 = v_u_28.Sounds
					end
					local v_u_130 = v129 and v129.Drop or "Case Fall"
					v_u_29:Add((v_u_123:GetMarkerReachedSignal("Dropped"):Connect(function()
						-- upvalues: (ref) v_u_20, (copy) v_u_130
						v_u_20.broadcastRouter("RunStoreSound", v_u_130)
					end)))
				end
				v_u_29:Add((v_u_123:GetMarkerReachedSignal(v128 and v128.Drop and "Drop" or "Dropped"):Connect(function()
					-- upvalues: (ref) v_u_26
					local v131 = v_u_26
					if v131 then
						v131 = v_u_26:FindFirstChild("DropParticle")
					end
					if v131 then
						for _, v132 in v131:GetChildren() do
							if not v132:IsA("ParticleEmitter") then
								continue
							end
							local v133 = v132:GetAttribute("EmitCount")
							if typeof(v133) ~= "number" or v133 <= 0 then
								continue
							end
							v132:Emit(v133)
						end
					end
				end)))
				v_u_123:Play()
				v_u_38.CloseIdle.Looped = true
				v_u_38.CloseIdle:Play()
			end
		end
	end
end
local function v_u_146() -- name: playOpeningAnimations
	-- upvalues: (ref) v_u_38, (ref) v_u_28, (copy) v_u_29, (copy) v_u_121, (ref) v_u_26, (copy) v_u_107, (copy) v_u_19, (copy) v_u_117, (copy) v_u_20
	if v_u_38.CaseOpening then
		if v_u_38.CloseIdle then
			v_u_38.CloseIdle:Stop()
		end
		local v_u_135 = v_u_38.CaseOpening
		local v136
		if v_u_28 == nil then
			v136 = false
		else
			v136 = v_u_28.ConsoleColumnCount ~= nil
		end
		if v136 then
			v_u_29:Remove("ConsoleEnterSound")
			local v137 = v_u_121
			local v138 = v_u_28
			if v138 then
				v138 = v_u_28.Sounds
			end
			v137(v138 and v138.Opening or "Console Open Animation", "ConsoleOpenSound")
			local v139 = v_u_26
			if v139 then
				v139 = v_u_26:FindFirstChild("CaseMod")
			end
			if v139 then
				v_u_107(v139:FindFirstChild("IdleEffect"), false)
				v_u_107(v139:FindFirstChild("OpeningEffect"), true)
			end
			v_u_135:Play(0.1, 1, 1)
			local v_u_140 = nil
			v_u_140 = v_u_19.BindToHeartbeat(v_u_19.CreateBindingName("CaseSceneController.ConsoleAnimationFreeze"), function()
				-- upvalues: (copy) v_u_135, (ref) v_u_140
				if v_u_135.Length > 0 and v_u_135.TimePosition >= v_u_135.Length - 0.05 then
					v_u_135:AdjustSpeed(0)
					v_u_140:Disconnect()
				end
			end)
			v_u_29:Add(v_u_140, "Disconnect", nil)
		else
			local v141 = v_u_28
			if v141 then
				v141 = v_u_28.AnimationKeyframeSounds
			end
			if v141 then
				v141 = v141.CaseOpening
			end
			if v141 then
				v_u_117(v_u_135, v141)
			else
				local v142 = v_u_20.broadcastRouter
				local v143 = "RunStoreSound"
				local v144 = v_u_28
				if v144 then
					v144 = v_u_28.Sounds
				end
				v142(v143, v144 and v144.Opening or "Case Opening")
			end
			local v145 = v_u_26
			if v145 then
				v145 = v_u_26:FindFirstChild("CaseMod")
			end
			if v145 then
				v_u_107(v145:FindFirstChild("IdleEffect"), false)
				v_u_107(v145:FindFirstChild("OpeningEffect"), true)
			end
			v_u_135:Play()
			if v_u_38.OpenIdle then
				v_u_38.OpenIdle.Looped = true
				v_u_38.OpenIdle:Play()
			end
		end
	else
		return
	end
end
local function v_u_148() -- name: stopAllAnimations
	-- upvalues: (ref) v_u_38, (ref) v_u_40
	for _, v147 in v_u_38 do
		if not v147.IsPlaying then
			continue
		end
		v147:Stop()
	end
	if v_u_40 then
		v_u_40:Stop()
		v_u_40:Destroy()
		v_u_40 = nil
	end
end
local function v_u_158() -- name: finishCharmOpeningAndStartRoll
	-- upvalues: (copy) v_u_41, (ref) v_u_40, (ref) v_u_45, (ref) v_u_49, (copy) v_u_9, (ref) v_u_38, (ref) v_u_43, (copy) v_u_20, (ref) v_u_28
	v_u_41("finishCharmOpeningAndStartRoll called")
	if v_u_40 then
		v_u_40:Stop()
	end
	v_u_45 = nil
	if v_u_49 then
		v_u_49.Enabled = false
	end
	local v149 = v_u_9:FindFirstChild("CameraPerspective")
	if v149 then
		v149.Interactable = true
	end
	local v_u_150 = v_u_38.PackOpening
	v_u_41("  packOpeningTrack:", v_u_150 and "exists" or "nil")
	v_u_41("  CharmDragCallback:", v_u_43 and "exists" or "nil")
	if v_u_150 then
		local v151 = v_u_20.broadcastRouter
		local v152 = "RunStoreSound"
		local v153 = v_u_28
		if v153 then
			v153 = v_u_28.Sounds
		end
		v151(v152, v153 and v153.DragLoop or "Charm Drag Loop")
		if not v_u_150.IsPlaying then
			v_u_150:Play()
		end
		v_u_150:AdjustSpeed(1)
		v_u_150.Looped = false
		local v154 = v_u_150.Length - v_u_150.TimePosition - 0.1
		local v155 = math.max(0, v154)
		task.delay(v155, function()
			-- upvalues: (copy) v_u_150, (ref) v_u_43
			if v_u_150.IsPlaying then
				v_u_150:AdjustSpeed(0)
				v_u_150.TimePosition = v_u_150.Length * 0.99
				local v156 = v_u_43
				if v156 then
					v_u_43 = nil
					v156()
				end
			end
		end)
	else
		v_u_41("  No packOpeningTrack, calling callback directly")
		if v_u_43 then
			v_u_41("  Calling CharmDragCallback")
		end
		local v157 = v_u_43
		if v157 then
			v_u_43 = nil
			v157()
		end
	end
end
local function v_u_167(p159, p160) -- name: updateCharmAnimationProgress
	-- upvalues: (ref) v_u_38, (ref) v_u_48, (ref) v_u_42, (copy) v_u_158, (ref) v_u_40, (ref) v_u_45, (ref) v_u_46
	local v161 = v_u_38.PackOpening
	if v161 then
		local v162 = math.clamp(p159, 0, 1)
		local v163
		if v_u_48 > 0 then
			v163 = v_u_48
		else
			v163 = v161.Length
		end
		if not v161.IsPlaying then
			v161:Play()
			v161:AdjustSpeed(0)
		end
		v161.TimePosition = v163 * v162
		if v162 >= 1 then
			v_u_42 = false
			v_u_158()
		end
		if v_u_40 and p160 then
			local v164 = not v_u_45 and 0 or (p160 - v_u_45).Magnitude
			v_u_45 = p160
			if v164 > 0.001 then
				v_u_46 = tick()
				if not v_u_40.IsPlaying then
					v_u_40:Play()
				end
				local v165 = v_u_40
				local v166 = v164 * 20
				v165.PlaybackSpeed = math.clamp(v166, 0, 0.7) + 0.8
			end
		end
	end
end
local function v_u_202(p168) -- name: setupCharmDragDetector
	-- upvalues: (ref) v_u_26, (copy) v_u_2, (ref) v_u_50, (ref) v_u_43, (ref) v_u_42, (ref) v_u_44, (ref) v_u_47, (ref) v_u_38, (ref) v_u_28, (ref) v_u_48, (copy) v_u_9, (ref) v_u_49, (copy) v_u_29, (ref) v_u_51, (copy) v_u_19, (ref) v_u_45, (ref) v_u_46, (ref) v_u_40, (copy) v_u_3, (copy) v_u_158, (copy) v_u_167, (copy) v_u_4, (ref) v_u_30, (ref) v_u_31, (copy) v_u_20
	if v_u_26 then
		local v_u_169 = v_u_26:FindFirstChild("Pack")
		if v_u_169 then
			local v_u_170 = v_u_169:FindFirstChild("Drag")
			if v_u_170 then
				local v_u_171 = v_u_170:FindFirstChildOfClass("DragDetector")
				if v_u_171 then
					v_u_2:UnbindAction("Fire")
					v_u_2:UnbindAction("Secondary Fire")
					v_u_50 = true
					v_u_43 = p168
					v_u_42 = false
					v_u_44 = v_u_170.Position
					v_u_47 = v_u_171.MaxDragTranslation.Magnitude
					if v_u_47 <= 0 then
						v_u_47 = 1
					end
					local v_u_172 = v_u_38.PackOpening
					if v_u_172 then
						local v173 = v_u_28
						if v173 then
							v173 = v_u_28.DragSettings
						end
						local v_u_174 = v173 and v173.EndKeyframe or "DragEndPoint"
						local v175, v176 = pcall(function()
							-- upvalues: (copy) v_u_172, (copy) v_u_174
							return v_u_172:GetTimeOfKeyframe(v_u_174)
						end)
						if v175 and v176 then
							v_u_48 = v176
						else
							v_u_48 = v_u_172.Length
							warn("[CaseSceneController]: " .. v_u_174 .. " keyframe not found, using full animation length")
						end
					end
					v_u_171.Enabled = true
					local v177 = v_u_9:FindFirstChild("CameraPerspective")
					if v177 then
						v177.Interactable = false
					end
					local v178 = v_u_170:FindFirstChildOfClass("SurfaceGui")
					if v178 then
						v178.Enabled = true
						v_u_49 = v178
						local v179 = v178:FindFirstChildOfClass("Frame")
						local v_u_180
						if v179 then
							v_u_180 = v179:FindFirstChildOfClass("ImageLabel")
						else
							v_u_180 = v179
						end
						if v179 and v_u_180 then
							v_u_29:Add(v179.MouseEnter:Connect(function()
								-- upvalues: (ref) v_u_51, (copy) v_u_180
								v_u_51 = true
								v_u_180.ImageTransparency = 1
							end), "Disconnect", "CharmImageHoverEnter")
							v_u_29:Add(v179.MouseLeave:Connect(function()
								-- upvalues: (ref) v_u_51, (copy) v_u_180
								v_u_51 = false
								v_u_180.ImageTransparency = 0
							end), "Disconnect", "CharmImageHoverLeave")
							local v_u_181 = 0
							v_u_29:Add(v_u_19.BindToRenderStep("CaseSceneController.CharmImageBreathing", function(p182)
								-- upvalues: (ref) v_u_51, (ref) v_u_181, (copy) v_u_180
								if not v_u_51 then
									v_u_181 = v_u_181 + p182 * 2
									local v183 = v_u_181
									v_u_180.ImageTransparency = (math.sin(v183) + 1) / 2 * 0.2
								end
							end), "Disconnect", "CharmImageBreathing")
						end
					end
					v_u_29:Add(v_u_171.DragStart:Connect(function()
						-- upvalues: (ref) v_u_42, (ref) v_u_45, (copy) v_u_170, (ref) v_u_46, (ref) v_u_40, (ref) v_u_3, (ref) v_u_28, (copy) v_u_169, (ref) v_u_29
						v_u_42 = true
						v_u_45 = v_u_170.Position
						v_u_46 = tick()
						if not v_u_40 then
							local v184 = require(v_u_3.Database.Audio.Store)
							local v185 = v_u_28
							if v185 then
								v185 = v_u_28.Sounds
							end
							local v186 = v184[v185 and v185.DragStart or "Charm Drag Start"]
							if v186 and (v186.Identifiers and v186.Identifiers[1]) then
								local v187 = Instance.new("Sound")
								v187.Name = "DragProgress"
								v187.SoundId = "rbxassetid://" .. v186.Identifiers[1]
								v187.Volume = v186.Properties.Volume or 1
								v187.Looped = true
								v187.PlaybackSpeed = 0.8
								v187.Parent = v_u_169
								v_u_40 = v187
								v_u_29:Add(v187, "Destroy")
							end
						end
					end), "Disconnect", "CharmDragStart")
					v_u_29:Add(v_u_19.BindToHeartbeat("CaseSceneController.CharmDragSoundCheck", function()
						-- upvalues: (ref) v_u_42, (ref) v_u_40, (ref) v_u_46
						if v_u_42 and (v_u_40 and (v_u_40.IsPlaying and tick() - v_u_46 > 0.05)) then
							v_u_40:Stop()
						end
					end), "Disconnect", "CharmDragSoundCheck")
					v_u_29:Add(v_u_171.DragContinue:Connect(function()
						-- upvalues: (ref) v_u_42, (ref) v_u_44, (copy) v_u_170, (ref) v_u_47, (ref) v_u_28, (copy) v_u_171, (ref) v_u_158, (ref) v_u_167
						if v_u_42 and v_u_44 then
							local v188 = (v_u_170.Position - v_u_44).Magnitude / v_u_47
							local v189 = math.clamp(v188, 0, 1)
							local v190 = v_u_28
							if v190 then
								v190 = v_u_28.DragSettings
							end
							if (v190 and v190.Threshold or 0.5) <= v189 then
								v_u_42 = false
								v_u_171.Enabled = false
								v_u_170.Position = v_u_44
								v_u_158()
							else
								v_u_167(v189, v_u_170.Position)
							end
						else
							return
						end
					end), "Disconnect", "CharmDragContinue")
					v_u_29:Add(v_u_171.DragEnd:Connect(function()
						-- upvalues: (ref) v_u_42, (ref) v_u_44, (ref) v_u_40, (copy) v_u_170, (ref) v_u_47, (ref) v_u_28, (copy) v_u_171, (ref) v_u_158, (ref) v_u_38, (ref) v_u_45
						if v_u_42 and v_u_44 then
							v_u_42 = false
							if v_u_40 then
								v_u_40:Stop()
							end
							local v191 = (v_u_170.Position - v_u_44).Magnitude / v_u_47
							local v192 = math.clamp(v191, 0, 1)
							v_u_170.Position = v_u_44
							local v193 = v_u_28
							if v193 then
								v193 = v_u_28.DragSettings
							end
							local v194 = v193 and v193.Threshold or 0.8
							if math.max(v194, 0.8) <= v192 then
								v_u_171.Enabled = false
								v_u_158()
							else
								if v_u_38.PackOpening then
									v_u_38.PackOpening.TimePosition = 0
								end
								v_u_45 = nil
							end
						else
							return
						end
					end), "Disconnect", "CharmDragEnd")
					v_u_29:Add(v_u_4.InputBegan:Connect(function(p195, p196)
						-- upvalues: (ref) v_u_30, (ref) v_u_31, (copy) v_u_171, (ref) v_u_42, (ref) v_u_44, (copy) v_u_170, (ref) v_u_40, (ref) v_u_20, (ref) v_u_28, (ref) v_u_158
						if v_u_30 and v_u_31 == "Unboxing" then
							local v197 = p195.UserInputType == Enum.UserInputType.Gamepad1
							local v198 = p195.UserInputType == Enum.UserInputType.Keyboard
							if v198 and p196 then
								return
							else
								if v197 then
									v197 = p195.KeyCode == Enum.KeyCode.ButtonX and true or p195.KeyCode == Enum.KeyCode.ButtonA
								end
								if v198 then
									v198 = p195.KeyCode == Enum.KeyCode.Return and true or p195.KeyCode == Enum.KeyCode.Space
								end
								if v197 or v198 then
									v_u_171.Enabled = false
									if v_u_42 then
										v_u_42 = false
										if v_u_44 then
											v_u_170.Position = v_u_44
										end
									end
									if v_u_40 then
										v_u_40:Stop()
									end
									local v199 = v_u_20.broadcastRouter
									local v200 = "RunStoreSound"
									local v201 = v_u_28
									if v201 then
										v201 = v_u_28.Sounds
									end
									v199(v200, v201 and v201.DragStart or "Charm Drag Start")
									v_u_158()
								end
							end
						else
							return
						end
					end), "Disconnect", "CharmControllerSkip")
				else
					warn("[CaseSceneController]: DragDetector not found on Drag part")
				end
			else
				warn("[CaseSceneController]: Drag part not found in Pack")
				return
			end
		else
			warn("[CaseSceneController]: Pack not found in CharmScene")
			return
		end
	else
		return
	end
end
function v_u_1.ShowCaseScene(p203, p204) -- name: ShowCaseScene
	-- upvalues: (copy) v_u_41, (ref) v_u_30, (copy) v_u_10, (copy) v_u_14, (copy) v_u_25, (copy) v_u_16, (ref) v_u_27, (ref) v_u_28, (ref) v_u_26, (ref) v_u_31, (copy) v_u_23, (copy) v_u_57, (ref) v_u_24, (copy) v_u_17, (copy) v_u_72, (copy) v_u_64, (copy) v_u_29, (copy) v_u_61, (copy) v_u_88, (copy) v_u_103, (copy) v_u_134, (copy) v_u_18, (copy) v_u_19, (ref) v_u_33, (ref) v_u_34, (ref) v_u_35, (ref) v_u_36, (copy) v_u_5, (ref) v_u_37, (copy) v_u_112, (ref) v_u_50, (copy) v_u_20, (ref) v_u_42, (ref) v_u_43, (ref) v_u_44, (ref) v_u_45, (ref) v_u_46, (ref) v_u_47, (ref) v_u_48, (ref) v_u_49, (ref) v_u_51, (copy) v_u_148, (ref) v_u_38
	v_u_41("ShowCaseScene called")
	v_u_41("  caseType:", p203 or "nil")
	v_u_41("  caseName:", p204 or "nil")
	v_u_41("  IsCaseSceneActive:", v_u_30)
	if v_u_30 then
		v_u_41("  BLOCKED: Scene already active")
		return
	else
		local v205 = v_u_10.GetSceneForCase
		local v206 = p203 or "Case"
		local v207
		if p204 then
			v207 = v_u_14.GetCaseByName(p204)
		else
			v207 = nil
		end
		local v208 = v205(v206, v207)
		v_u_41("  sceneName:", v208)
		local v_u_209 = v_u_10.GetConfig(v208)
		if v_u_209 then
			v_u_41("  config.AssetFolder:", v_u_209.AssetFolder)
			v_u_41("  config.InteractionType:", v_u_209.InteractionType)
			local v210 = v_u_25[v_u_209.AssetFolder]
			if v210 then
				v_u_16.Unpark(v210)
				v_u_27 = v208
				v_u_28 = v_u_209
				v_u_26 = v210
				if v_u_209.InteractionType == "Drag" then
					local v211 = v210:FindFirstChild("Pack")
					if v211 then
						v211 = v211:FindFirstChild("Drag")
					end
					if v211 then
						v211 = v211:FindFirstChildOfClass("SurfaceGui")
					end
					if v211 then
						v211.Enabled = false
					end
				end
				v_u_31 = "Inspecting"
				local v212 = v_u_26
				if v212 then
					v212 = v_u_26:FindFirstChild("Camera")
				end
				local v213
				if v212 then
					v213 = v212:FindFirstChild("Inspecting")
				else
					v213 = nil
				end
				if v213 then
					v_u_23.CameraType = Enum.CameraType.Scriptable
					v_u_23.CFrame = v213.CFrame
					v_u_23.Focus = v213.CFrame
					v_u_57()
					if not v_u_24 then
						v_u_17.ApplyMenuSceneLighting()
					end
					v_u_72(v210)
					v_u_64()
					v_u_29:Add(v_u_23.ChildAdded:Connect(function(p214)
						-- upvalues: (copy) v_u_209, (ref) v_u_61
						if p214:IsA("Model") and p214.Name ~= v_u_209.AssetFolder then
							v_u_61(p214)
						end
					end), "Disconnect", "ViewmodelListener")
					local v215 = nil
					if p204 and v_u_209.InteractionType == "Click" then
						local v216
						if v_u_28 == nil then
							v216 = false
						else
							v216 = v_u_28.ConsoleColumnCount ~= nil
						end
						if not v216 then
							v215 = v_u_88(v210, p204)
						end
					end
					v_u_103(v210, v_u_209, v215)
					if v_u_209.InteractionType == "Click" then
						v_u_134()
					end
					v_u_18.setFOVLock("CaseScene", true, 50)
					v_u_18.setForceLockOverride("CaseScene", true)
					local v217 = Enum.RenderPriority.Camera.Value + 10
					v_u_19.BindToRenderStep("CaseSceneController.CameraUpdate", v217, function()
						-- upvalues: (ref) v_u_26, (ref) v_u_23, (ref) v_u_33, (ref) v_u_34, (ref) v_u_35, (ref) v_u_36, (ref) v_u_5, (ref) v_u_37, (ref) v_u_31
						if v_u_26 then
							v_u_23.CameraType = Enum.CameraType.Scriptable
							if v_u_33 and (v_u_34 and v_u_35) then
								local v218 = (tick() - v_u_36) / 0.8
								local v219 = math.min(v218, 1)
								v_u_23.CFrame = v_u_34:Lerp(v_u_35, (v_u_5:GetValue(v219, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)))
								v_u_23.Focus = v_u_23.CFrame
								if v219 >= 1 then
									v_u_33 = false
									v_u_23.CFrame = v_u_35
									if v_u_37 then
										local v220 = v_u_37
										v_u_37 = nil
										v220()
									end
									v_u_34 = nil
									v_u_35 = nil
									return
								end
							else
								local v221 = v_u_31
								local v222 = v_u_26
								if v222 then
									v222 = v_u_26:FindFirstChild("Camera")
								end
								local v223
								if v222 and (v221 == "Inspecting" or v221 == "Unboxing") then
									v223 = v222:FindFirstChild(v221)
								else
									v223 = nil
								end
								if v223 then
									v_u_23.CFrame = v223.CFrame
									v_u_23.Focus = v223.CFrame
								end
							end
						end
					end)
					v_u_29:Add(function()
						-- upvalues: (ref) v_u_19
						v_u_19.UnbindFromRenderStep("CaseSceneController.CameraUpdate")
					end, true, "CameraUpdate")
					v_u_29:Add(function()
						-- upvalues: (ref) v_u_41, (ref) v_u_31, (ref) v_u_33, (ref) v_u_34, (ref) v_u_35, (ref) v_u_37, (ref) v_u_112, (ref) v_u_50, (ref) v_u_20, (ref) v_u_42, (ref) v_u_43, (ref) v_u_44, (ref) v_u_45, (ref) v_u_46, (ref) v_u_47, (ref) v_u_48, (ref) v_u_49, (ref) v_u_51, (ref) v_u_26, (ref) v_u_148, (ref) v_u_38
						v_u_41("CaseSceneCleanup running")
						v_u_31 = nil
						v_u_33 = false
						v_u_34 = nil
						v_u_35 = nil
						v_u_37 = nil
						v_u_112(false, false, false)
						if v_u_50 then
							v_u_20.broadcastRouter("RebindKeybinds")
							v_u_50 = false
						end
						v_u_42 = false
						v_u_43 = nil
						v_u_44 = nil
						v_u_45 = nil
						v_u_46 = 0
						v_u_47 = 1
						v_u_48 = 0
						v_u_49 = nil
						v_u_51 = false
						if v_u_26 then
							local v224 = v_u_26:FindFirstChild("CaseMod")
							if v224 and v224:GetAttribute("IsDynamicModel") then
								v224:Destroy()
							end
						end
						v_u_148()
						v_u_38 = {}
						v_u_41("CaseSceneCleanup complete")
					end, true, "CaseSceneCleanup")
					v_u_30 = true
					v_u_41("ShowCaseScene complete, IsCaseSceneActive = true")
				else
					warn("[CaseSceneController]: Scene missing Camera.Inspecting")
					v_u_16.Park(v210)
					v_u_26 = nil
					v_u_27 = nil
					v_u_28 = nil
					v_u_31 = nil
				end
			else
				warn("[CaseSceneController]: Scene was never staged: " .. v_u_209.AssetFolder)
				return
			end
		else
			warn("[CaseSceneController]: No config found for scene: " .. v208)
			v_u_41("  BLOCKED: No config found")
			return
		end
	end
end
function v_u_1.TransitionToUnboxing(p_u_225) -- name: TransitionToUnboxing
	-- upvalues: (copy) v_u_41, (ref) v_u_30, (ref) v_u_26, (ref) v_u_28, (ref) v_u_31, (copy) v_u_146, (ref) v_u_33, (ref) v_u_34, (copy) v_u_23, (ref) v_u_35, (ref) v_u_36, (ref) v_u_37, (copy) v_u_202
	v_u_41("TransitionToUnboxing called")
	v_u_41("  IsCaseSceneActive:", v_u_30)
	v_u_41("  CurrentScene:", v_u_26 and "exists" or "nil")
	v_u_41("  CurrentSceneConfig:", v_u_28 and "exists" or "nil")
	v_u_41("  CurrentCaseSceneState:", v_u_31 or "nil")
	v_u_41("  callback:", p_u_225 and "provided" or "nil")
	if v_u_30 and (v_u_26 and v_u_28) then
		if v_u_31 == "Unboxing" then
			v_u_41("  BLOCKED: Already in Unboxing state")
			return
		else
			local v226 = v_u_26
			if v226 then
				v226 = v_u_26:FindFirstChild("Camera")
			end
			local v227
			if v226 then
				v227 = v226:FindFirstChild("Unboxing")
			else
				v227 = nil
			end
			if v227 then
				v_u_41("  InteractionType:", v_u_28.InteractionType)
				if v_u_28.InteractionType == "Click" then
					v_u_41("  Playing opening animations and starting camera lerp")
					v_u_146()
					local v228 = v_u_31
					local v229 = v_u_26
					if v229 then
						v229 = v_u_26:FindFirstChild("Camera")
					end
					local v230
					if v229 and (v228 == "Inspecting" or v228 == "Unboxing") then
						v230 = v229:FindFirstChild(v228)
					else
						v230 = nil
					end
					v_u_33 = true
					local v231
					if v230 then
						v231 = v230.CFrame
					else
						v231 = v_u_23.CFrame
					end
					v_u_34 = v231
					v_u_35 = v227.CFrame
					v_u_36 = tick()
					v_u_37 = p_u_225
				else
					v_u_41("  Starting camera lerp, will setup drag detector after")
					local function v232()
						-- upvalues: (ref) v_u_41, (ref) v_u_202, (copy) p_u_225
						v_u_41("  Camera lerp complete, setting up drag detector")
						v_u_202(p_u_225)
					end
					local v233 = v_u_31
					local v234 = v_u_26
					if v234 then
						v234 = v_u_26:FindFirstChild("Camera")
					end
					local v235
					if v234 and (v233 == "Inspecting" or v233 == "Unboxing") then
						v235 = v234:FindFirstChild(v233)
					else
						v235 = nil
					end
					v_u_33 = true
					local v236
					if v235 then
						v236 = v235.CFrame
					else
						v236 = v_u_23.CFrame
					end
					v_u_34 = v236
					v_u_35 = v227.CFrame
					v_u_36 = tick()
					v_u_37 = v232
				end
				v_u_31 = "Unboxing"
				v_u_41("  TransitionToUnboxing complete, CurrentCaseSceneState = Unboxing")
			else
				warn("[CaseSceneController]: Scene missing Camera.Unboxing")
				v_u_41("  BLOCKED: Missing Camera.Unboxing")
			end
		end
	else
		v_u_41("  BLOCKED: Scene not active or missing config")
		return
	end
end
function v_u_1.TransitionToInspecting(p237) -- name: TransitionToInspecting
	-- upvalues: (ref) v_u_30, (ref) v_u_26, (ref) v_u_31, (ref) v_u_33, (ref) v_u_34, (copy) v_u_23, (ref) v_u_35, (ref) v_u_36, (ref) v_u_37
	if v_u_30 and v_u_26 then
		if v_u_31 == "Inspecting" then
			return
		else
			local v238 = v_u_26
			if v238 then
				v238 = v_u_26:FindFirstChild("Camera")
			end
			local v239
			if v238 then
				v239 = v238:FindFirstChild("Inspecting")
			else
				v239 = nil
			end
			if v239 then
				local v240 = v_u_31
				local v241 = v_u_26
				if v241 then
					v241 = v_u_26:FindFirstChild("Camera")
				end
				local v242
				if v241 and (v240 == "Inspecting" or v240 == "Unboxing") then
					v242 = v241:FindFirstChild(v240)
				else
					v242 = nil
				end
				v_u_33 = true
				local v243
				if v242 then
					v243 = v242.CFrame
				else
					v243 = v_u_23.CFrame
				end
				v_u_34 = v243
				v_u_35 = v239.CFrame
				v_u_36 = tick()
				v_u_37 = p237
				v_u_31 = "Inspecting"
			else
				warn("[CaseSceneController]: Scene missing Camera.Inspecting")
			end
		end
	else
		return
	end
end
function v_u_1.BeginConsoleOpening() -- name: BeginConsoleOpening
	-- upvalues: (ref) v_u_39, (copy) v_u_29, (ref) v_u_28, (copy) v_u_11, (ref) v_u_26, (copy) v_u_8, (ref) v_u_38, (ref) v_u_31, (copy) v_u_1, (copy) v_u_202
	local v244 = v_u_39
	if v244 then
		v244:PlayReset()
		if v_u_39 ~= v244 then
			return
		end
	end
	if v_u_39 then
		v_u_29:Remove("ConsoleAnimator")
		v_u_39 = nil
	end
	local v245 = v_u_28
	local v_u_246 = v_u_11.new(v_u_26, v245.ConsoleColumnCount)
	v_u_29:Add(v_u_246, "Cancel", "ConsoleAnimator")
	v_u_39 = v_u_246
	v_u_246:Start()
	v_u_8.RenderStepped:Wait()
	local v247 = v_u_38.CaseFall
	v_u_29:Remove("ConsoleEnterAnimationFreeze")
	if v247 and v247.IsPlaying then
		v247:Stop(0.1)
	end
	v_u_29:Remove("ConsoleEnterSound")
	local function v248() -- name: setSceneReady
		-- upvalues: (ref) v_u_39, (copy) v_u_246
		if v_u_39 == v_u_246 then
			v_u_246:SetSceneReady()
		end
	end
	if v_u_31 == "Unboxing" then
		if v_u_28 and v_u_28.InteractionType == "Drag" then
			local v249 = v_u_38.PackOpening
			if v249 and v249.IsPlaying then
				v249:Stop()
			end
			v_u_202(v248)
		else
			v_u_246:SetSceneReady()
		end
	else
		v_u_1.TransitionToUnboxing(v248)
		return
	end
end
local v_u_250 = {
	["Special"] = "Drop Gold",
	["Red"] = "Drop Red",
	["Pink"] = "Drop Pink",
	["Purple"] = "Drop Purple",
	["Blue"] = "Drop Blue"
}
local function v_u_254(p251) -- name: getRollerItem
	-- upvalues: (copy) v_u_13, (copy) v_u_12
	local v252 = v_u_13.GetSkinInformation(p251.skin.weaponName, p251.skin.skinName)
	local v253
	if v252 then
		if v252.wearImages and v252.wearImages[1] then
			v253 = v252.wearImages[1].assetId
		elseif v252.charmImages and v252.charmImages[1] then
			v253 = v252.charmImages[1].assetId
		else
			v253 = v252.imageAssetId or ""
		end
	else
		v253 = ""
	end
	return {
		["Image"] = v253,
		["Color"] = (v_u_12[p251.isSpecial and "Special" or p251.rarity] or v_u_12.Stock).Color
	}
end
local function v_u_267(p255, p256, p257) -- name: findGrantedContent
	local v258
	if p257 then
		local v259 = string.lower
		local v260 = p257.Name
		v258 = v259((tostring(v260)))
	else
		v258 = nil
	end
	local v261
	if p257 then
		local v262 = string.lower
		local v263 = p257.Skin
		v261 = v262((tostring(v263)))
	else
		v261 = nil
	end
	local v264 = nil
	for _, v265 in { p256.contents, p256.specialContents or {} } do
		for _, v266 in v265 do
			if p255.grantedSkinId ~= nil and v266.skinId == p255.grantedSkinId then
				return v266
			end
			if v264 or (string.lower(v266.skin.weaponName) ~= v258 or string.lower(v266.skin.skinName) ~= v261) then
				continue
			end
			v264 = v266
		end
	end
	return v264
end
local function v_u_281(p268, p269) -- name: buildRollerPlan
	-- upvalues: (copy) v_u_254, (copy) v_u_250
	if not (p268 and p269) then
		return nil
	end
	local v270 = (p268.isSpecial or p268.rarity == "Special") and "Special" or p268.rarity
	local v271 = {}
	local v272 = {}
	for _, v273 in { p269.contents, p269.specialContents or {} } do
		for _, v274 in v273 do
			local v275 = ("%*|%*"):format(v274.skin.weaponName, v274.skin.skinName)
			local v276
			if v270 == "Special" then
				v276 = v274.isSpecial or v274.rarity == "Special"
			elseif v274.rarity == v270 then
				v276 = not v274.isSpecial
			else
				v276 = false
			end
			if not v276 or v271[v275] then
				continue
			end
			v271[v275] = true
			table.insert(v272, v274)
		end
	end
	if #v272 < 2 then
		return nil
	end
	local v277 = {}
	local v278 = nil
	for _, v279 in v272 do
		local v280 = v_u_254(v279)
		table.insert(v277, v280)
		if v279 ~= p268 then
			continue
		end
		v278 = v280
	end
	return v278 and {
		["Pool"] = v277,
		["Winner"] = v278,
		["LandingSound"] = v_u_250[v270]
	} or nil
end
function v_u_1.ResolveConsoleOpening(p282, p283, p284, p285) -- name: ResolveConsoleOpening
	-- upvalues: (ref) v_u_39, (copy) v_u_29, (copy) v_u_267, (copy) v_u_281
	local v286 = v_u_39
	if not v286 then
		return false
	end
	local v287
	if p282.finalColumnIndex < v286.ColumnCount then
		v287 = p282.columnCount == nil and true or p282.columnCount == v286.ColumnCount
	else
		v287 = false
	end
	for _, v288 in p282.path do
		if v288.columnIndex < v286.ColumnCount then
			continue
		end
		v287 = false
	end
	if not v287 then
		warn((("[CaseSceneController]: Console outcome doesn\'t fit the %*-column board (columnCount %*)"):format(v286.ColumnCount, p282.columnCount)))
		if v_u_39 then
			v_u_29:Remove("ConsoleAnimator")
			v_u_39 = nil
		end
		return false
	end
	local v289
	if p284 then
		v289 = v_u_267(p282, p284, p285)
	else
		v289 = nil
	end
	local v290 = v_u_281(v289, p284)
	local v291
	if v289 then
		v291 = (v289.isSpecial or v289.rarity == "Special") and "Special" or v289.rarity
	else
		v291 = nil
	end
	v286:Resolve(p282, p283, v290, v291)
	return true
end
function v_u_1.SkipConsoleOpening() -- name: SkipConsoleOpening
	-- upvalues: (ref) v_u_39
	if v_u_39 then
		v_u_39:Skip()
	end
end
function v_u_1.CancelConsoleOpening() -- name: CancelConsoleOpening
	-- upvalues: (ref) v_u_39, (copy) v_u_29, (ref) v_u_38, (ref) v_u_31, (copy) v_u_1
	if v_u_39 then
		v_u_29:Remove("ConsoleAnimator")
		v_u_39 = nil
	end
	v_u_29:Remove("ConsoleOpenSound")
	local v292 = v_u_38.CaseOpening
	if v292 and v292.IsPlaying then
		v292:Stop(0.1)
	end
	if v_u_31 == "Unboxing" then
		v_u_1.TransitionToInspecting()
	end
end
function v_u_1.IsConsoleOpening() -- name: IsConsoleOpening
	-- upvalues: (ref) v_u_39
	return v_u_39 ~= nil
end
function v_u_1.ArmDragOpening(p293) -- name: ArmDragOpening
	-- upvalues: (ref) v_u_30, (ref) v_u_26, (ref) v_u_28, (ref) v_u_31, (ref) v_u_38, (copy) v_u_202
	if not v_u_30 or (not v_u_26 or (not v_u_28 or (v_u_28.InteractionType ~= "Drag" or v_u_31 ~= "Unboxing"))) then
		return false
	end
	local v294 = v_u_38.PackOpening
	if v294 and v294.IsPlaying then
		v294:Stop()
	end
	v_u_202(p293)
	return true
end
function v_u_1.HideCaseScene(p295) -- name: HideCaseScene
	-- upvalues: (copy) v_u_41, (ref) v_u_30, (ref) v_u_39, (copy) v_u_29, (copy) v_u_23, (copy) v_u_18, (copy) v_u_22, (copy) v_u_3, (copy) v_u_80, (copy) v_u_17, (ref) v_u_24, (copy) v_u_21, (copy) v_u_68, (ref) v_u_26, (copy) v_u_16, (ref) v_u_27, (ref) v_u_28, (ref) v_u_31
	v_u_41("HideCaseScene called")
	v_u_41("  IsCaseSceneActive:", v_u_30)
	v_u_41("  skipFrameRestore:", p295 or false)
	if v_u_30 then
		if v_u_39 then
			v_u_29:Remove("ConsoleAnimator")
			v_u_39 = nil
		end
		v_u_41("  Running CaseSceneJanitor:Cleanup()")
		v_u_29:Cleanup()
		v_u_23.CameraType = Enum.CameraType.Custom
		v_u_18.setFOVLock("CaseScene", false)
		v_u_18.updateCameraFOV(v_u_22.DEFAULT_CAMERA_FOV)
		local v296 = require(v_u_3.Controllers.SpectateController).GetCurrentSpectateInstance()
		if v296 then
			v296:UpdateScopeState()
		end
		v_u_18.setForceLockOverride("CaseScene", false)
		if p295 then
			if workspace:FindFirstChild("Map") then
				v_u_17.ApplyMapLighting()
			elseif v_u_24 then
				v_u_17.ApplyMenuSceneLighting()
			end
			v_u_21.ExitCaseScene()
			v_u_24 = false
		else
			v_u_80()
		end
		v_u_68()
		if v_u_26 then
			v_u_16.Park(v_u_26)
		end
		v_u_26 = nil
		v_u_27 = nil
		v_u_28 = nil
		v_u_30 = false
		v_u_31 = nil
		v_u_41("HideCaseScene complete, IsCaseSceneActive = false")
	else
		v_u_41("  BLOCKED: Scene not active")
	end
end
function v_u_1.IsActive() -- name: IsActive
	-- upvalues: (ref) v_u_30
	return v_u_30
end
function v_u_1.ApplyCaseSceneLighting() -- name: ApplyCaseSceneLighting
	-- upvalues: (ref) v_u_30, (ref) v_u_26, (copy) v_u_17, (copy) v_u_72
	if v_u_30 and v_u_26 then
		v_u_17.ApplyMenuSceneLighting()
		v_u_72(v_u_26)
	end
end
function v_u_1.WaitForOpeningAnimation() -- name: WaitForOpeningAnimation
	-- upvalues: (ref) v_u_38
	local v297 = v_u_38.CaseOpening
	if v297 and v297.IsPlaying then
		v297.Stopped:Wait()
	end
end
function v_u_1.Initialize() -- name: Initialize
	-- upvalues: (copy) v_u_3, (copy) v_u_10, (copy) v_u_25, (copy) v_u_16, (copy) v_u_4, (ref) v_u_30, (copy) v_u_1, (copy) v_u_20
	local v298 = v_u_3:FindFirstChild("Assets")
	if v298 then
		for _, v299 in v_u_10.GetAllSceneNames() do
			local v300 = v_u_10.GetConfig(v299)
			local v301
			if v300 then
				v301 = v298:FindFirstChild(v300.AssetFolder)
			else
				v301 = v300
			end
			if not (v300 and v301) then
				continue
			end
			local v302 = v301:FindFirstChildWhichIsA("Model")
			if v302 then
				local v303 = v302:Clone()
				v303.Name = v300.AssetFolder
				v_u_25[v300.AssetFolder] = v303
				v_u_16.Park(v303)
			else
				warn("[CaseSceneController]: No model found in Assets." .. v300.AssetFolder)
			end
		end
		v_u_4.InputBegan:Connect(function(p304, p305)
			-- upvalues: (ref) v_u_30, (ref) v_u_1
			if p305 or (p304.KeyCode ~= Enum.KeyCode.Escape or not v_u_30) then
				return
			elseif v_u_1.IsConsoleOpening() then
				v_u_1.SkipConsoleOpening()
			else
				v_u_1.HideCaseScene()
			end
		end)
		v_u_20.observerRouter("CaseSceneCloseForGameEnd", function()
			-- upvalues: (ref) v_u_1
			v_u_1.HideCaseScene(true)
		end)
	else
		warn("[CaseSceneController]: Assets folder not found in ReplicatedStorage")
	end
end
function v_u_1.Start() -- name: Start end
v_u_20.observerRouter("IsCaseSceneRolling", function()
	-- upvalues: (ref) v_u_30, (ref) v_u_31
	local v306 = v_u_30
	if v306 then
		v306 = v_u_31 == "Unboxing"
	end
	return v306
end)
return v_u_1
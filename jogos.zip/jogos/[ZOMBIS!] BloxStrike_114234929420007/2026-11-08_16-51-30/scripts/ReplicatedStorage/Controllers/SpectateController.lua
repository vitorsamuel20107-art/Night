-- NIGHT Analyzer | ReplicatedStorage.Controllers.SpectateController
-- ModuleScript | 1183 linhas | 32142 bytes | hash d1e68340

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("GuiService")
local v_u_5 = game:GetService("Players")
local v_u_6 = game:GetService("CollectionService")
require(script:WaitForChild("Types"))
local v_u_7 = v_u_5.LocalPlayer
local v_u_8 = require(v_u_2.Controllers.InventoryController)
local v_u_9 = require(v_u_2.Controllers.CameraController)
local v_u_10 = require(v_u_2.Components.Common.CharacterGeneration)
local v_u_11 = require(v_u_2.Components.Common.ClientCharacterPresentation)
local v_u_12 = require(v_u_2.Components.Common.CharacterResolver)
local v_u_13 = require(v_u_2.Components.Common.Participants)
local v_u_14 = require(v_u_2.Controllers.CharacterController.RemoteCharacters)
local v_u_15 = require(v_u_2.Components.Common.IsPlayingTeam)
local v_u_16 = require(v_u_2.Database.Components.CharacterActions)
local v_u_17 = require(v_u_2.Controllers.RunServiceController)
local v_u_18 = require(v_u_2.Controllers.BlackMarketSceneController)
local v_u_19 = require(v_u_2.Interface.MenuState)
local v_u_20 = require(v_u_2.Classes.Spectate)
local v_u_21 = require(v_u_2.Classes.Freecam)
local v_u_22 = require(v_u_2.Classes.Ragdoll)
local v_u_23 = require(v_u_2.Packages.Observers)
local v_u_24 = require(v_u_2.Shared.Promise)
local v25 = require(v_u_2.Packages.Signal)
local v_u_26 = require(v_u_2.Database.Security.Remotes)
local v_u_27 = require(v_u_2.Database.Security.Router)
local v_u_28 = workspace.CurrentCamera
local v_u_29 = v25.new()
v_u_1.ListenToSpectate = v_u_29
local v_u_30 = v25.new()
v_u_1.ListenToFreecam = v_u_30
local v_u_31 = require(v_u_2.Database.Custom.Constants)
local v_u_32 = {
	"TeamSelection",
	"BuyMenu",
	"Leaderboard",
	"Votekick",
	"VIPMenu",
	"EndScreen",
	"Halftime"
}
local v_u_33 = "First-Person"
local v_u_34 = {}
local v_u_35 = 0
local v_u_36 = false
local v_u_37 = 1
local v_u_38 = 1
local v_u_39 = 0
local v_u_40 = 0
local v_u_41 = nil
local v_u_42 = 0
local v_u_43 = nil
local v_u_44 = nil
local v_u_45 = { "First-Person", "Third-Person", "Free-Cam" }
local v_u_46 = nil
local v_u_47 = nil
local function v_u_49() -- name: GetSpectateBombModel
	-- upvalues: (copy) v_u_6
	for _, v48 in ipairs(v_u_6:GetTagged("Bomb")) do
		if not (v48:IsA("Model") and (v48.PrimaryPart and v48:IsDescendantOf(workspace))) then
			continue
		end
		return v48
	end
	return nil
end
local function v_u_59() -- name: GetKillerPlayer
	-- upvalues: (copy) v_u_7, (copy) v_u_13, (copy) v_u_15, (ref) v_u_36, (copy) v_u_12
	local v50 = v_u_7:GetAttribute("LastKiller")
	local v51 = v_u_7:GetAttribute("LastKillerKey")
	if v50 or v51 then
		v_u_7:SetAttribute("LastKiller", nil)
		v_u_7:SetAttribute("LastKillerKey", nil)
		local v52 = v_u_13.FromKey(v51)
		if v52 then
			v50 = v52
		elseif v50 then
			v50 = v_u_13.FromName(v50)
		end
		if v50 then
			local v53
			if v50 == v_u_7 then
				v53 = false
			else
				local v54
				if v_u_15(v50:GetAttribute("Team")) and (v50 ~= v_u_7 or not v_u_36) then
					if v_u_13.IsBot(v50) then
						v54 = v_u_13.IsAlive(v50)
					else
						v54 = v_u_12.isAlivePlayer(v50)
					end
				else
					v54 = false
				end
				if v54 then
					local v55 = workspace:GetAttribute("ServerGamemode")
					local v56 = (v55 ~= "Competitive" and v55 ~= "Deathmatch" and "Casual" or v55) == "Competitive" and v_u_15(v_u_7:GetAttribute("Team"))
					if v56 then
						local v57 = v_u_7
						local v58
						if v_u_15(v57:GetAttribute("Team")) and (v57 ~= v_u_7 or not v_u_36) then
							if v_u_13.IsBot(v57) then
								v58 = v_u_13.IsAlive(v57)
							else
								v58 = v_u_12.isAlivePlayer(v57)
							end
						else
							v58 = false
						end
						v56 = not v58
					end
					v53 = not v56 or v_u_7:GetAttribute("Team") == v50:GetAttribute("Team")
				else
					v53 = false
				end
			end
			if v53 then
				return v50
			end
		end
	end
	return nil
end
local function v_u_66() -- name: ShouldBeSpectating
	-- upvalues: (copy) v_u_19, (copy) v_u_27, (copy) v_u_7, (copy) v_u_15, (ref) v_u_36, (copy) v_u_13, (copy) v_u_12, (copy) v_u_2
	if not v_u_19.IsCaseSceneActive() then
		local v60
		if v_u_19.WantsMainMenu() then
			local v61 = v_u_19.GetMenuFrame()
			if v61 == nil then
				v60 = false
			else
				v60 = v61.Visible == true
			end
		else
			v60 = false
		end
		if not v60 then
			if v_u_27.broadcastRouter("IsEndScreenActive") == true then
				return false
			end
			local v62 = v_u_7
			local v63
			if v_u_15(v62:GetAttribute("Team")) and (v62 ~= v_u_7 or not v_u_36) then
				if v_u_13.IsBot(v62) then
					v63 = v_u_13.IsAlive(v62)
				else
					v63 = v_u_12.isAlivePlayer(v62)
				end
			else
				v63 = false
			end
			if v63 or not v_u_15(v_u_7:GetAttribute("Team")) then
				return false
			end
			local v64 = require(v_u_2.Database.Components.GameState).GetState()
			local v65
			if v64 == "Game Ending" then
				v65 = false
			else
				v65 = v64 ~= "Map Voting"
			end
			return v65
		end
	end
	return false
end
local function v_u_69() -- name: StartSpectatingOnDeath
	-- upvalues: (copy) v_u_66, (copy) v_u_12, (copy) v_u_22, (ref) v_u_46, (ref) v_u_47, (copy) v_u_9, (copy) v_u_31, (copy) v_u_59, (copy) v_u_1
	if v_u_66() then
		local v67 = v_u_12.getLocalCharacter()
		if v67 then
			v_u_22.HideCharacterLocally(v67)
		end
		if v_u_46 or v_u_47 then
			return
		else
			v_u_9.updateCameraFOV(v_u_31.DEFAULT_CAMERA_FOV)
			v_u_9.setPerspective(true, false)
			local v68 = v_u_59()
			if v68 then
				v_u_1.SetNextPlayer(v68)
			else
				v_u_1.Next()
			end
		end
	else
		return
	end
end
local function v_u_76() -- name: UpdateCharacters
	-- upvalues: (copy) v_u_7, (copy) v_u_34, (copy) v_u_13, (copy) v_u_15, (ref) v_u_36, (copy) v_u_12
	local v70 = workspace:GetAttribute("ServerGamemode")
	local v71 = (v70 ~= "Competitive" and v70 ~= "Deathmatch" and "Casual" or v70) == "Competitive"
	local v72 = v_u_7:GetAttribute("Team")
	table.clear(v_u_34)
	for _, v73 in ipairs((v_u_13.GetAll())) do
		if v71 and (v72 ~= "Spectators" and v73:GetAttribute("Team") ~= v72) or v73 == v_u_7 then
			continue
		end
		local v74
		if v_u_15(v73:GetAttribute("Team")) and (v73 ~= v_u_7 or not v_u_36) then
			if v_u_13.IsBot(v73) then
				v74 = v_u_13.IsAlive(v73)
			else
				v74 = v_u_12.isAlivePlayer(v73)
			end
		else
			v74 = false
		end
		if not v74 then
			continue
		end
		local v75 = v_u_34
		table.insert(v75, v73)
	end
end
local function v_u_82() -- name: IsSpectateInputBlockedByUi
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_19, (copy) v_u_32
	if v_u_4.MenuIsOpen then
		return true
	end
	if v_u_3:GetFocusedTextBox() ~= nil then
		return true
	end
	local v77 = v_u_19.GetMenuFrame()
	if v77 and v77.Visible then
		return true
	end
	local v78 = v_u_19.GetMainGui()
	if not v78 then
		return false
	end
	local v79 = v78:FindFirstChild("Gameplay")
	if v79 then
		v79 = v79:FindFirstChild("Middle")
	end
	if not v79 then
		return false
	end
	for _, v80 in v_u_32 do
		local v81 = v79:FindFirstChild(v80)
		if not (v81 and (v81:IsA("GuiObject") and v81.Visible)) then
			continue
		end
		return true
	end
	return false
end
function v_u_1.GetCurrentSpectateInstance() -- name: GetCurrentSpectateInstance
	-- upvalues: (ref) v_u_46
	return v_u_46
end
function v_u_1.IsLocalPlayerDead() -- name: IsLocalPlayerDead
	-- upvalues: (ref) v_u_36
	return v_u_36
end
function v_u_1.IsTakingOverCamera() -- name: IsTakingOverCamera
	-- upvalues: (copy) v_u_19, (copy) v_u_66, (copy) v_u_7
	local v83
	if v_u_19.WantsMainMenu() then
		local v84 = v_u_19.GetMenuFrame()
		if v84 == nil then
			v83 = false
		else
			v83 = v84.Visible == true
		end
	else
		v83 = false
	end
	if v83 then
		return false
	else
		return v_u_66() or v_u_7:GetAttribute("IsSpectating") == true
	end
end
function v_u_1.IsFreecamActive() -- name: IsFreecamActive
	-- upvalues: (ref) v_u_47, (ref) v_u_46
	local v85
	if v_u_47 == nil then
		if v_u_46 == nil then
			v85 = false
		else
			v85 = v_u_46.FreecamInstance ~= nil
		end
	else
		v85 = true
	end
	return v85
end
function v_u_1.CanSwitchPerspective() -- name: CanSwitchPerspective
	-- upvalues: (ref) v_u_46, (copy) v_u_7, (copy) v_u_15, (ref) v_u_36, (copy) v_u_13, (copy) v_u_12
	local v86
	if v_u_46 == nil then
		v86 = false
	else
		local v87 = workspace:GetAttribute("ServerGamemode")
		local v88 = (v87 ~= "Competitive" and v87 ~= "Deathmatch" and "Casual" or v87) == "Competitive" and v_u_15(v_u_7:GetAttribute("Team"))
		if v88 then
			local v89 = v_u_7
			local v90
			if v_u_15(v89:GetAttribute("Team")) and (v89 ~= v_u_7 or not v_u_36) then
				if v_u_13.IsBot(v89) then
					v90 = v_u_13.IsAlive(v89)
				else
					v90 = v_u_12.isAlivePlayer(v89)
				end
			else
				v90 = false
			end
			v88 = not v90
		end
		v86 = not v88
	end
	return v86
end
function v_u_1.IsSpectatingNow() -- name: IsSpectatingNow
	-- upvalues: (ref) v_u_46, (ref) v_u_47, (copy) v_u_7
	return (v_u_46 ~= nil or v_u_47 ~= nil) and true or v_u_7:GetAttribute("IsSpectating") == true
end
function v_u_1.GetPlayer() -- name: GetPlayer
	-- upvalues: (copy) v_u_7, (copy) v_u_15, (ref) v_u_36, (copy) v_u_13, (copy) v_u_12, (ref) v_u_46
	local v91 = v_u_7
	local v92
	if v_u_15(v91:GetAttribute("Team")) and (v91 ~= v_u_7 or not v_u_36) then
		if v_u_13.IsBot(v91) then
			v92 = v_u_13.IsAlive(v91)
		else
			v92 = v_u_12.isAlivePlayer(v91)
		end
	else
		v92 = false
	end
	if v92 then
		return v_u_7
	elseif v_u_46 then
		return v_u_46.Player
	else
		return nil
	end
end
function v_u_1.SetNextPlayer(p93) -- name: SetNextPlayer
	-- upvalues: (ref) v_u_46, (ref) v_u_41, (copy) v_u_7, (copy) v_u_15, (ref) v_u_36, (copy) v_u_13, (copy) v_u_12, (copy) v_u_1, (copy) v_u_26, (ref) v_u_42, (copy) v_u_14, (copy) v_u_10, (copy) v_u_11, (ref) v_u_33, (copy) v_u_20
	local v94 = v_u_46
	if v94 then
		v94 = v_u_46.Player
	end
	v_u_41 = nil
	local v95
	if p93 == v_u_7 then
		v95 = false
	else
		local v96
		if v_u_15(p93:GetAttribute("Team")) and (p93 ~= v_u_7 or not v_u_36) then
			if v_u_13.IsBot(p93) then
				v96 = v_u_13.IsAlive(p93)
			else
				v96 = v_u_12.isAlivePlayer(p93)
			end
		else
			v96 = false
		end
		if v96 then
			local v97 = workspace:GetAttribute("ServerGamemode")
			local v98 = (v97 ~= "Competitive" and v97 ~= "Deathmatch" and "Casual" or v97) == "Competitive" and v_u_15(v_u_7:GetAttribute("Team"))
			if v98 then
				local v99 = v_u_7
				local v100
				if v_u_15(v99:GetAttribute("Team")) and (v99 ~= v_u_7 or not v_u_36) then
					if v_u_13.IsBot(v99) then
						v100 = v_u_13.IsAlive(v99)
					else
						v100 = v_u_12.isAlivePlayer(v99)
					end
				else
					v100 = false
				end
				v98 = not v100
			end
			v95 = not v98 or v_u_7:GetAttribute("Team") == p93:GetAttribute("Team")
		else
			v95 = false
		end
	end
	if v95 then
		local v101 = v_u_13.IsBot(p93)
		local v102 = v_u_26.Spectate.SpectatePlayer.Send
		local v103
		if v101 then
			local v104 = v_u_13.Key
			v103 = tostring(v104(p93))
		else
			v103 = p93.Name
		end
		v102(v103)
		local v105
		if v101 then
			v105 = v_u_13.Character(p93)
		else
			v105 = v_u_12.getPlayerCharacter(p93)
		end
		if v101 and not v_u_12.isAliveCharacter(v105) then
			v_u_41 = p93
			v_u_42 = os.clock()
			return
		else
			local v106 = v94 == p93
			local v107 = v_u_46
			if v107 then
				v107 = v_u_46.Character == v105
			end
			local v108
			if v_u_15(p93:GetAttribute("Team")) and (p93 ~= v_u_7 or not v_u_36) then
				if v_u_13.IsBot(p93) then
					v108 = v_u_13.IsAlive(p93)
				else
					v108 = v_u_12.isAlivePlayer(p93)
				end
			else
				v108 = false
			end
			if v106 and (v107 and v108) then
				if not v101 then
					v_u_14.SetPinnedPlayer(p93)
				end
				return
			else
				v_u_1.Stop(false, true)
				if not v101 then
					v_u_14.SetPinnedPlayer(p93)
					local v109 = p93:GetAttribute(v_u_10.AttributeName)
					if typeof(v109) == "number" then
						v_u_11.Create(p93, v109)
					end
					v105 = v_u_12.getPlayerCharacter(p93)
				end
				if v105 and (v108 and v_u_12.resolve(v105)) then
					local v110 = workspace:GetAttribute("ServerGamemode")
					local v111 = (v110 ~= "Competitive" and v110 ~= "Deathmatch" and "Casual" or v110) == "Competitive" and v_u_15(v_u_7:GetAttribute("Team"))
					if v111 then
						local v112 = v_u_7
						local v113
						if v_u_15(v112:GetAttribute("Team")) and (v112 ~= v_u_7 or not v_u_36) then
							if v_u_13.IsBot(v112) then
								v113 = v_u_13.IsAlive(v112)
							else
								v113 = v_u_12.isAlivePlayer(v112)
							end
						else
							v113 = false
						end
						v111 = not v113
					end
					local v114 = v111 and "First-Person" or v_u_33
					local v115
					if v101 then
						v115 = v_u_20.newBot(p93, v105, v114)
					else
						v115 = v_u_20.new(p93, v105, v114)
					end
					v_u_46 = v115
					if v_u_33 ~= "First-Person" then
						v115:Switch(v_u_33)
					end
					v_u_1.ListenToSpectate:Fire(p93)
					v115.StopSpectating:Once(function()
						-- upvalues: (ref) v_u_1
						v_u_1.Stop(false, true)
						v_u_1.Next()
					end)
				else
					v_u_14.SetPinnedPlayer(nil)
					v_u_1.Next()
				end
			end
		end
	else
		v_u_1.Next()
		return
	end
end
function v_u_1.Switch() -- name: Switch
	-- upvalues: (copy) v_u_7, (copy) v_u_15, (ref) v_u_36, (copy) v_u_13, (copy) v_u_12, (ref) v_u_33, (ref) v_u_37, (ref) v_u_46, (ref) v_u_47, (copy) v_u_45
	local v116 = workspace:GetAttribute("ServerGamemode")
	local v117 = (v116 ~= "Competitive" and v116 ~= "Deathmatch" and "Casual" or v116) == "Competitive" and v_u_15(v_u_7:GetAttribute("Team"))
	if v117 then
		local v118 = v_u_7
		local v119
		if v_u_15(v118:GetAttribute("Team")) and (v118 ~= v_u_7 or not v_u_36) then
			if v_u_13.IsBot(v118) then
				v119 = v_u_13.IsAlive(v118)
			else
				v119 = v_u_12.isAlivePlayer(v118)
			end
		else
			v119 = false
		end
		v117 = not v119
	end
	if v117 then
		v_u_33 = "First-Person"
		v_u_37 = 1
		if v_u_46 then
			v_u_46:Switch("First-Person")
		end
		if v_u_47 then
			v_u_47:Destroy()
			v_u_47 = nil
		end
	else
		v_u_37 = v_u_37 + 1 > #v_u_45 and 1 or v_u_37 + 1
		v_u_33 = v_u_45[v_u_37]
		if v_u_46 then
			v_u_46:Switch(v_u_33)
		end
	end
end
function v_u_1.UpdateIndex(p120) -- name: UpdateIndex
	-- upvalues: (copy) v_u_76, (copy) v_u_34, (ref) v_u_41, (ref) v_u_46, (ref) v_u_38, (copy) v_u_24, (copy) v_u_15, (copy) v_u_7, (ref) v_u_36, (copy) v_u_13, (copy) v_u_12, (copy) v_u_1
	v_u_76()
	if #v_u_34 > 0 then
		local v121 = not v_u_41 and v_u_46
		if v121 then
			v121 = v_u_46.Player
		end
		if v121 then
			v121 = table.find(v_u_34, v121)
		end
		if v121 then
			v_u_38 = v121
		end
		v_u_38 = v_u_38 + p120
		if v_u_38 <= 0 then
			v_u_38 = #v_u_34
		elseif v_u_38 > #v_u_34 then
			v_u_38 = 1
		end
	end
	return v_u_24.new(function(p122, p123)
		-- upvalues: (ref) v_u_34, (ref) v_u_38, (ref) v_u_15, (ref) v_u_7, (ref) v_u_36, (ref) v_u_13, (ref) v_u_12, (ref) v_u_76, (ref) v_u_1
		local v124 = v_u_34[v_u_38]
		if v124 then
			local v125
			if v_u_15(v124:GetAttribute("Team")) and (v124 ~= v_u_7 or not v_u_36) then
				if v_u_13.IsBot(v124) then
					v125 = v_u_13.IsAlive(v124)
				else
					v125 = v_u_12.isAlivePlayer(v124)
				end
			else
				v125 = false
			end
			if v125 then
				p122(v124)
				return
			end
		end
		v_u_76()
		if #v_u_34 > 0 then
			v_u_38 = 1
			p122(v_u_34[1])
		else
			v_u_1.Stop(false, false)
			p123("No players alive to spectate")
		end
	end)
end
local function v_u_128(p126) -- name: SpectateByOffset
	-- upvalues: (copy) v_u_1
	return v_u_1.UpdateIndex(p126):andThen(function(p127)
		-- upvalues: (ref) v_u_1
		v_u_1.SetNextPlayer(p127)
	end):catch(function() end)
end
function v_u_1.Next() -- name: Next
	-- upvalues: (copy) v_u_128
	return v_u_128(1)
end
function v_u_1.Previous() -- name: Previous
	-- upvalues: (copy) v_u_128
	return v_u_128(-1)
end
function v_u_1.IsControllerPress(p129) -- name: IsControllerPress
	-- upvalues: (copy) v_u_3
	if string.match(p129.UserInputType.Name, "^Gamepad%d+$") then
		return true
	end
	for _, v130 in v_u_3:GetConnectedGamepads() do
		for _, v131 in v_u_3:GetGamepadState(v130) do
			if v131.KeyCode ~= Enum.KeyCode.ButtonR2 and v131.KeyCode ~= Enum.KeyCode.ButtonL2 or v131.Position.Z <= 0.1 then
				continue
			end
			return true
		end
	end
	return false
end
function v_u_1.RequestSwitch(p132) -- name: RequestSwitch
	-- upvalues: (copy) v_u_1, (copy) v_u_7, (copy) v_u_15, (ref) v_u_36, (copy) v_u_13, (copy) v_u_12, (ref) v_u_46, (ref) v_u_47, (ref) v_u_40
	if v_u_1.IsSpectatingNow() then
		local v133 = v_u_7
		local v134
		if v_u_15(v133:GetAttribute("Team")) and (v133 ~= v_u_7 or not v_u_36) then
			if v_u_13.IsBot(v133) then
				v134 = v_u_13.IsAlive(v133)
			else
				v134 = v_u_12.isAlivePlayer(v133)
			end
		else
			v134 = false
		end
		if v134 and (v_u_46 == nil and v_u_47 == nil) then
			return
		else
			local v135 = os.clock()
			if v135 - v_u_40 < 0.15 then
				return
			else
				v_u_40 = v135
				if p132 < 0 then
					v_u_1.Previous()
				else
					v_u_1.Next()
				end
			end
		end
	else
		return
	end
end
function v_u_1.Stop(p136, p137) -- name: Stop
	-- upvalues: (ref) v_u_44, (copy) v_u_7, (ref) v_u_43, (copy) v_u_14, (ref) v_u_41, (ref) v_u_46, (copy) v_u_26, (ref) v_u_47, (copy) v_u_29
	if v_u_44 and v_u_7.ReplicationFocus == v_u_44 then
		v_u_7.ReplicationFocus = nil
	end
	v_u_43 = nil
	v_u_44 = nil
	v_u_14.SetPinnedPlayer(nil)
	v_u_41 = nil
	if v_u_46 then
		v_u_46:Destroy()
		v_u_46 = nil
	end
	if p136 and v_u_7:GetAttribute("IsSpectating") then
		v_u_26.Spectate.StopSpectating.Send()
	end
	if p137 and v_u_47 then
		v_u_47:Destroy()
		v_u_47 = nil
	end
	v_u_29:Fire()
end
function v_u_1.Broadcast() -- name: Broadcast
	-- upvalues: (copy) v_u_7, (ref) v_u_39, (copy) v_u_8, (copy) v_u_19, (copy) v_u_18, (copy) v_u_26, (copy) v_u_28
	local v138 = v_u_7:GetAttribute("Spectators")
	local v139 = v138 and v138 > 0 and 0.016666666666666666 or 0.2
	if v139 <= v_u_39 then
		local v140 = v_u_8.getCurrentEquipped()
		v_u_39 = v_u_39 - v139
		if v140 then
			local v141 = v_u_7.PlayerGui:FindFirstChild("MainGui")
			if v141 then
				v141 = v_u_7.PlayerGui.MainGui:FindFirstChild("Menu")
			end
			if v141 then
				v141 = v141:FindFirstChild("Inspect")
			end
			if v141 and v141.Visible or (v_u_19.IsCaseSceneActive() or v_u_18.IsActive()) then
				return
			end
			v_u_26.Spectate.UpdateCameraCFrame.Send({
				["CameraCFrame"] = v_u_28.CFrame,
				["UserId"] = v_u_7.UserId
			})
		end
	end
end
local function v_u_149() -- name: UpdatePendingBotTarget
	-- upvalues: (ref) v_u_41, (copy) v_u_12, (copy) v_u_13, (copy) v_u_1, (copy) v_u_7, (copy) v_u_15, (ref) v_u_36, (ref) v_u_42, (ref) v_u_46
	local v142 = v_u_41
	if v142 then
		if v_u_12.isAliveCharacter(v_u_13.Character(v142)) then
			v_u_1.SetNextPlayer(v142)
		else
			local v143
			if v142 == v_u_7 then
				v143 = false
			else
				local v144
				if v_u_15(v142:GetAttribute("Team")) and (v142 ~= v_u_7 or not v_u_36) then
					if v_u_13.IsBot(v142) then
						v144 = v_u_13.IsAlive(v142)
					else
						v144 = v_u_12.isAlivePlayer(v142)
					end
				else
					v144 = false
				end
				if v144 then
					local v145 = workspace:GetAttribute("ServerGamemode")
					local v146 = (v145 ~= "Competitive" and v145 ~= "Deathmatch" and "Casual" or v145) == "Competitive" and v_u_15(v_u_7:GetAttribute("Team"))
					if v146 then
						local v147 = v_u_7
						local v148
						if v_u_15(v147:GetAttribute("Team")) and (v147 ~= v_u_7 or not v_u_36) then
							if v_u_13.IsBot(v147) then
								v148 = v_u_13.IsAlive(v147)
							else
								v148 = v_u_12.isAlivePlayer(v147)
							end
						else
							v148 = false
						end
						v146 = not v148
					end
					v143 = not v146 or v_u_7:GetAttribute("Team") == v142:GetAttribute("Team")
				else
					v143 = false
				end
			end
			if not v143 or os.clock() - v_u_42 > 1.5 then
				v_u_41 = nil
				if v_u_46 then
					v_u_1.SetNextPlayer(v_u_46.Player)
				end
			end
		end
	else
		return
	end
end
function v_u_1.Render(p150) -- name: Render
	-- upvalues: (ref) v_u_35, (ref) v_u_39, (copy) v_u_7, (copy) v_u_15, (ref) v_u_36, (copy) v_u_13, (copy) v_u_12, (ref) v_u_33, (ref) v_u_37, (ref) v_u_46, (ref) v_u_47, (copy) v_u_1, (ref) v_u_44, (ref) v_u_43, (copy) v_u_18, (copy) v_u_27, (copy) v_u_28, (copy) v_u_9, (copy) v_u_66, (copy) v_u_19, (copy) v_u_3, (copy) v_u_82, (copy) v_u_149, (copy) v_u_76, (copy) v_u_34, (ref) v_u_41, (ref) v_u_38, (copy) v_u_49, (copy) v_u_31, (copy) v_u_21, (copy) v_u_30
	v_u_35 = v_u_35 + p150
	v_u_39 = v_u_39 + p150
	local v151 = workspace:GetAttribute("ServerGamemode")
	local v152 = (v151 ~= "Competitive" and v151 ~= "Deathmatch" and "Casual" or v151) == "Competitive" and v_u_15(v_u_7:GetAttribute("Team"))
	if v152 then
		local v153 = v_u_7
		local v154
		if v_u_15(v153:GetAttribute("Team")) and (v153 ~= v_u_7 or not v_u_36) then
			if v_u_13.IsBot(v153) then
				v154 = v_u_13.IsAlive(v153)
			else
				v154 = v_u_12.isAlivePlayer(v153)
			end
		else
			v154 = false
		end
		v152 = not v154
	end
	if v152 then
		local v155 = workspace:GetAttribute("ServerGamemode")
		local v156 = (v155 ~= "Competitive" and v155 ~= "Deathmatch" and "Casual" or v155) == "Competitive" and v_u_15(v_u_7:GetAttribute("Team"))
		if v156 then
			local v157 = v_u_7
			local v158
			if v_u_15(v157:GetAttribute("Team")) and (v157 ~= v_u_7 or not v_u_36) then
				if v_u_13.IsBot(v157) then
					v158 = v_u_13.IsAlive(v157)
				else
					v158 = v_u_12.isAlivePlayer(v157)
				end
			else
				v158 = false
			end
			v156 = not v158
		end
		if v156 then
			v_u_33 = "First-Person"
			v_u_37 = 1
			if v_u_46 and v_u_46.PerspectiveState ~= "First-Person" then
				v_u_46:Switch("First-Person")
			end
			if v_u_47 then
				v_u_47:Destroy()
				v_u_47 = nil
			end
		end
	end
	if v_u_36 then
		local v159 = v_u_7
		local v160
		if v_u_13.IsBot(v159) then
			v160 = v_u_13.IsAlive(v159)
		else
			v160 = v_u_12.isAlivePlayer(v159)
		end
		if v160 then
			v_u_36 = false
		end
	end
	local v161 = v_u_7
	local v162
	if v_u_15(v161:GetAttribute("Team")) and (v161 ~= v_u_7 or not v_u_36) then
		if v_u_13.IsBot(v161) then
			v162 = v_u_13.IsAlive(v161)
		else
			v162 = v_u_12.isAlivePlayer(v161)
		end
	else
		v162 = false
	end
	if v162 then
		v_u_1.Broadcast()
		if v_u_44 and v_u_7.ReplicationFocus == v_u_44 then
			v_u_7.ReplicationFocus = nil
		end
		v_u_43 = nil
		v_u_44 = nil
		if v_u_46 then
			v_u_1.Stop(true, true)
		end
		if v_u_47 then
			v_u_47:Destroy()
			v_u_47 = nil
		end
		local v163 = v_u_7
		local v164
		if v_u_15(v163:GetAttribute("Team")) and (v163 ~= v_u_7 or not v_u_36) then
			if v_u_13.IsBot(v163) then
				v164 = v_u_13.IsAlive(v163)
			else
				v164 = v_u_12.isAlivePlayer(v163)
			end
		else
			v164 = false
		end
		if v164 and not v_u_18.IsActive() and v_u_27.broadcastRouter("IsEndScreenActive") ~= true then
			local v165 = v_u_12.getLocalCharacter()
			local v166 = v_u_12.getCameraPart(v165) or v_u_12.getRootPart(v165)
			if v166 then
				v_u_28.CameraType = Enum.CameraType.Custom
				v_u_28.CameraSubject = v166
			end
			v_u_9.setPerspective(true, false)
			return
		end
	elseif v_u_66() or v_u_7:GetAttribute("IsSpectating") then
		local v167
		if v_u_19.WantsMainMenu() then
			local v168 = v_u_19.GetMenuFrame()
			if v168 == nil then
				v167 = false
			else
				v167 = v168.Visible == true
			end
		else
			v167 = false
		end
		if not v167 and v_u_27.broadcastRouter("IsEndScreenActive") ~= true then
			if v_u_19.IsCaseSceneActive() or v_u_18.IsActive() then
				return
			end
			if v_u_3.MouseBehavior ~= Enum.MouseBehavior.LockCenter and not (v_u_82() or (v_u_19.IsCaseSceneActive() or v_u_19.IsInspectActive())) then
				v_u_9.resetForceLockOverride()
			end
			v_u_149()
			if v_u_46 then
				if v_u_44 and v_u_7.ReplicationFocus == v_u_44 then
					v_u_7.ReplicationFocus = nil
				end
				v_u_43 = nil
				v_u_44 = nil
				if v_u_27.broadcastRouter("IsInspectActive") then
					return
				end
				v_u_46:Render(p150)
				if v_u_47 then
					v_u_47:Destroy()
					v_u_47 = nil
					return
				end
				return
			else
				if v_u_35 >= 0.2 then
					v_u_35 = 0
					v_u_76()
					if #v_u_34 > 0 then
						local v169 = not v_u_41 and v_u_46
						if v169 then
							v169 = v_u_46.Player
						end
						if v169 then
							v169 = table.find(v_u_34, v169)
						end
						if v169 then
							v_u_38 = v169
						end
						v_u_38 = v_u_38 + 1
						if v_u_38 <= 0 then
							v_u_38 = #v_u_34
						elseif v_u_38 > #v_u_34 then
							v_u_38 = 1
						end
					end
				end
				if v_u_41 then
					return
				end
				if v_u_34[v_u_38] then
					if v_u_44 and v_u_7.ReplicationFocus == v_u_44 then
						v_u_7.ReplicationFocus = nil
					end
					v_u_43 = nil
					v_u_44 = nil
					v_u_1.Next()
					return
				end
				if v152 then
					v_u_43 = not (v_u_43 and v_u_43.Parent) and v_u_49()
					if v_u_43 then
						v_u_9.setPerspective(false, false)
						v_u_9.updateCameraFOV(v_u_31.DEFAULT_CAMERA_FOV)
					end
					if v_u_43 then
						local v170 = v_u_43
						local v171
						if v170 and v170.Parent then
							local v172 = v170.PrimaryPart
							if v172 then
								if v_u_44 ~= v172 then
									v_u_44 = v172
									v_u_7.ReplicationFocus = v172
								end
								v_u_28.CameraType = Enum.CameraType.Follow
								v_u_28.CameraSubject = v172
								v171 = true
							else
								v171 = false
							end
						else
							v171 = false
						end
						if v171 then
							if v_u_47 then
								v_u_47:Destroy()
								v_u_47 = nil
							end
						else
							if v_u_44 and v_u_7.ReplicationFocus == v_u_44 then
								v_u_7.ReplicationFocus = nil
							end
							v_u_43 = nil
							v_u_44 = nil
							if v_u_47 then
								v_u_47:Destroy()
								v_u_47 = nil
							end
						end
					else
						if v_u_44 and v_u_7.ReplicationFocus == v_u_44 then
							v_u_7.ReplicationFocus = nil
						end
						v_u_43 = nil
						v_u_44 = nil
						if v_u_47 then
							v_u_47:Destroy()
							v_u_47 = nil
						end
						return
					end
				else
					if v_u_44 and v_u_7.ReplicationFocus == v_u_44 then
						v_u_7.ReplicationFocus = nil
					end
					v_u_43 = nil
					v_u_44 = nil
					if not v_u_47 then
						local v173 = v_u_21.new()
						v_u_47 = v173
						v173:Start()
						v_u_30:Fire(true)
						return
					end
					return
				end
			end
		end
		if v_u_46 then
			v_u_1.Stop(false, true)
			return
		end
		if v_u_44 and v_u_7.ReplicationFocus == v_u_44 then
			v_u_7.ReplicationFocus = nil
		end
		v_u_43 = nil
		v_u_44 = nil
	else
		if v_u_46 then
			v_u_1.Stop(false, true)
			return
		end
		if v_u_44 and v_u_7.ReplicationFocus == v_u_44 then
			v_u_7.ReplicationFocus = nil
		end
		v_u_43 = nil
		v_u_44 = nil
	end
end
function v_u_1.Initialize() -- name: Initialize
	-- upvalues: (copy) v_u_23, (copy) v_u_7, (copy) v_u_19, (copy) v_u_82, (copy) v_u_9, (copy) v_u_31, (ref) v_u_46, (copy) v_u_59, (copy) v_u_1, (copy) v_u_26, (copy) v_u_13, (copy) v_u_12, (ref) v_u_36, (copy) v_u_69, (copy) v_u_15, (ref) v_u_33, (ref) v_u_37, (copy) v_u_2, (copy) v_u_17
	v_u_23.observeAttribute(v_u_7, "IsSpectating", function(p174)
		-- upvalues: (ref) v_u_7, (ref) v_u_19, (ref) v_u_82, (ref) v_u_9, (ref) v_u_31, (ref) v_u_46, (ref) v_u_59, (ref) v_u_1
		if p174 then
			v_u_7:SetAttribute("PendingSpectateRequestAt", nil)
			if not v_u_19.IsCaseSceneActive() then
				local v175
				if v_u_19.WantsMainMenu() then
					local v176 = v_u_19.GetMenuFrame()
					if v176 == nil then
						v175 = false
					else
						v175 = v176.Visible == true
					end
				else
					v175 = false
				end
				if not v175 then
					if not (v_u_82() or (v_u_19.IsCaseSceneActive() or v_u_19.IsInspectActive())) then
						v_u_9.resetForceLockOverride()
					end
					v_u_9.updateCameraFOV(v_u_31.DEFAULT_CAMERA_FOV)
					v_u_9.setPerspective(true, false)
					if not v_u_46 then
						local v177 = v_u_59()
						if v177 then
							v_u_1.SetNextPlayer(v177)
						else
							v_u_1.Next()
						end
					end
				end
			end
		end
		return function()
			-- upvalues: (ref) v_u_1
			v_u_1.Stop(false, true)
		end
	end)
	v_u_26.Character.CharacterDied.Listen(function()
		-- upvalues: (ref) v_u_7, (ref) v_u_13, (ref) v_u_12, (ref) v_u_36, (ref) v_u_69
		local v178 = v_u_7
		local v179
		if v_u_13.IsBot(v178) then
			v179 = v_u_13.IsAlive(v178)
		else
			v179 = v_u_12.isAlivePlayer(v178)
		end
		if v179 then
			v_u_36 = false
		else
			v_u_36 = true
			v_u_69()
		end
	end)
	v_u_7.CharacterAdded:Connect(function(p_u_180)
		-- upvalues: (ref) v_u_36, (ref) v_u_7, (ref) v_u_15, (ref) v_u_12, (ref) v_u_19, (ref) v_u_33, (ref) v_u_37, (ref) v_u_1, (ref) v_u_26, (ref) v_u_46, (ref) v_u_13, (ref) v_u_69
		v_u_36 = false
		local v181 = v_u_15(v_u_7:GetAttribute("Team"))
		local v182 = v_u_12.isAliveCharacter(p_u_180)
		local v183 = v_u_7:GetAttribute("PendingSpectateRequestAt")
		local v184
		if v183 == nil then
			v184 = false
		else
			v184 = os.clock() - v183 < 3
		end
		if v181 and v182 then
			v_u_19.SetWantsMainMenu(false)
			v_u_33 = "First-Person"
			v_u_37 = 1
			v_u_1.Stop(not v184, true)
			if not v184 and v_u_7:GetAttribute("IsSpectating") then
				v_u_26.Spectate.StopSpectating.Send()
			end
		elseif v_u_46 and v_u_46.Player then
			local v185 = v_u_26.Spectate.SpectatePlayer.Send
			local v186
			if v_u_46.IsBot then
				local v187 = v_u_13.Key
				local v188 = v_u_46.Player
				v186 = tostring(v187(v188))
			else
				v186 = v_u_46.Player.Name
			end
			v185(v186)
		end
		local v_u_189 = p_u_180:GetAttributeChangedSignal("Dead"):Connect(function()
			-- upvalues: (copy) p_u_180, (ref) v_u_69
			if p_u_180:GetAttribute("Dead") then
				v_u_69()
			end
		end)
		local v_u_190 = nil
		v_u_190 = p_u_180.AncestryChanged:Connect(function(_, p191)
			-- upvalues: (copy) v_u_189, (ref) v_u_190
			if not p191 then
				v_u_189:Disconnect()
				v_u_190:Disconnect()
			end
		end)
	end)
	require(v_u_2.Database.Components.GameState).ListenToState(function(_, p192)
		-- upvalues: (ref) v_u_1
		if p192 == "Game Ending" or p192 == "Map Voting" then
			v_u_1.Stop(false, true)
		end
	end)
	v_u_17.BindToRenderStep("SpectateController.Render", function(p193)
		-- upvalues: (ref) v_u_1
		v_u_1.Render(p193)
	end)
end
function v_u_1.Start() -- name: Start
	-- upvalues: (copy) v_u_26, (ref) v_u_46, (copy) v_u_5, (copy) v_u_10, (copy) v_u_16, (copy) v_u_3, (copy) v_u_7, (copy) v_u_1, (copy) v_u_82, (copy) v_u_4, (copy) v_u_28
	v_u_26.Character.Action.Listen(function(p194)
		-- upvalues: (ref) v_u_46, (ref) v_u_5, (ref) v_u_10, (ref) v_u_16
		if v_u_46 and typeof(p194) == "table" then
			local v195 = p194.UserId
			local v196
			if typeof(v195) == "number" then
				v196 = v_u_5:GetPlayerByUserId(p194.UserId)
			else
				v196 = nil
			end
			if v196 and v196 == v_u_46.Player then
				if v_u_10.Get(v196.Character) == p194.Generation then
					local v197 = v_u_16.ToName(p194.ActionId)
					if v197 then
						v_u_46:AddSpectateEvent(v197)
					end
				end
			else
				return
			end
		else
			return
		end
	end)
	v_u_3.InputBegan:Connect(function(p198)
		-- upvalues: (ref) v_u_7, (ref) v_u_1, (ref) v_u_82, (ref) v_u_4
		if v_u_7:GetAttribute("IsPlayerChatting") or not v_u_1.IsSpectatingNow() then
			return
		elseif p198.KeyCode == Enum.KeyCode.Space then
			v_u_1.Switch()
			return
		elseif p198.KeyCode == Enum.KeyCode.ButtonA then
			if not v_u_82() and v_u_4.SelectedObject == nil then
				v_u_1.Switch()
			end
			return
		else
			local v199 = p198.KeyCode == Enum.KeyCode.ButtonL1
			if v199 or p198.KeyCode == Enum.KeyCode.ButtonR1 then
				if not v_u_82() then
					v_u_1.RequestSwitch(v199 and -1 or 1)
				end
				return
			else
				local v200 = p198.UserInputType == Enum.UserInputType.MouseButton1
				if v200 or p198.UserInputType == Enum.UserInputType.MouseButton2 then
					if not (v_u_82() or v_u_1.IsControllerPress(p198)) then
						v_u_1.RequestSwitch(v200 and -1 or 1)
					end
				else
					return
				end
			end
		end
	end)
	if v_u_3.TouchEnabled then
		v_u_3.TouchStarted:Connect(function(p201, p202)
			-- upvalues: (ref) v_u_7, (ref) v_u_1, (ref) v_u_28
			if not (p202 or v_u_7:GetAttribute("IsPlayerChatting")) then
				v_u_1.RequestSwitch(p201.Position.X < v_u_28.ViewportSize.X / 2 and -1 or 1)
			end
		end)
	end
end
return v_u_1
-- NIGHT Analyzer | ReplicatedStorage.Controllers.WarmupEffectsController
-- ModuleScript | 544 linhas | 14355 bytes | hash 15b97771

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = game:GetService("Lighting")
local v_u_4 = game:GetService("Workspace")
local v5 = game:GetService("Players")
local v_u_6 = require(v_u_1.Database.Components.GameState)
local v_u_7 = require(v_u_1.Database.Security.Router)
local v_u_8 = require(v_u_1.Interface.MenuState)
local v_u_9 = v5.LocalPlayer
local v_u_10 = {
	["WarmupColorCorrection"] = true,
	["FlashbangColorCorrection"] = true,
	["DamageColorCorrection"] = true,
	["DownedColorCorrection"] = true
}
local v_u_11 = {
	"Brightness",
	"Contrast",
	"Saturation",
	"TintColor"
}
local v12 = {}
local v_u_13 = nil
local function v_u_18() -- name: getBestMapColorCorrection
	-- upvalues: (ref) v_u_13, (copy) v_u_3, (copy) v_u_10
	local v14 = v_u_13
	if v14 and (v14.Enabled and (v14:IsDescendantOf(v_u_3) and not v_u_10[v14.Name])) then
		return v14
	end
	local v15 = nil
	local v16 = nil
	for _, v17 in ipairs(v_u_3:GetDescendants()) do
		if not v17:IsA("ColorCorrectionEffect") or v_u_10[v17.Name] then
			continue
		end
		if v17.Enabled then
			v15 = v15 or v17
		end
		if v16 then
			continue
		end
		v16 = v17
	end
	v_u_13 = v15 or v16
	return v_u_13
end
local function v_u_22() -- name: findActiveViewmodelModel
	-- upvalues: (copy) v_u_4
	local v19 = v_u_4.CurrentCamera
	if not v19 then
		return nil
	end
	for _, v20 in ipairs(v19:GetChildren()) do
		if not (v20:IsA("Model") and v20:FindFirstChild("Stats")) then
			continue
		end
		return v20
	end
	for _, v21 in ipairs(v19:GetDescendants()) do
		if not (v21:IsA("Model") and v21:FindFirstChild("Stats")) then
			continue
		end
		return v21
	end
	return nil
end
local function v_u_25(p23, p24) -- name: getViewmodelModelFromInstance
	while p23 and p23 ~= p24 do
		if p23:IsA("Model") and p23:FindFirstChild("Stats") then
			return p23
		end
		p23 = p23.Parent
	end
	return nil
end
function v12.Start() -- name: Start
	-- upvalues: (copy) v_u_1, (copy) v_u_8, (copy) v_u_9, (copy) v_u_18, (copy) v_u_11, (copy) v_u_2, (copy) v_u_7, (copy) v_u_4, (copy) v_u_22, (copy) v_u_25, (copy) v_u_6
	local v26 = v_u_1:FindFirstChild("Assets")
	if v26 then
		v26 = v26:FindFirstChild("Warmup")
	end
	if not (v26 and v26:IsA("Folder")) then
		warn("[WarmupEffectsController] Missing ReplicatedStorage.Assets.Warmup")
		return
	end
	local v_u_27 = v26:FindFirstChild("ColorCorrection")
	local v_u_28 = v26:FindFirstChild("ViewmodelHighlight")
	if not (v_u_27 and v_u_27:IsA("ColorCorrectionEffect")) then
		warn("[WarmupEffectsController] Missing Assets.Warmup.ColorCorrection (ColorCorrectionEffect)")
		return
	end
	if not (v_u_28 and v_u_28:IsA("Highlight")) then
		warn("[WarmupEffectsController] Missing Assets.Warmup.ViewmodelHighlight (Highlight)")
		return
	end
	local v_u_29 = 0
	local v_u_30 = nil
	local v_u_31 = false
	local function v_u_93() -- name: startBuyPeriodEffects
		-- upvalues: (ref) v_u_29, (ref) v_u_30, (ref) v_u_18, (ref) v_u_11, (copy) v_u_27, (ref) v_u_2, (ref) v_u_7, (ref) v_u_4, (ref) v_u_22, (copy) v_u_28, (ref) v_u_25
		v_u_29 = v_u_29 + 1
		if v_u_30 then
			v_u_30()
			v_u_30 = nil
		end
		v_u_29 = v_u_29 + 1
		local v_u_32 = v_u_29
		local v_u_33 = false
		local v_u_34 = false
		local v_u_35 = nil
		local v_u_36 = nil
		local v_u_37 = v_u_18()
		local v_u_38 = nil
		local v_u_39
		if v_u_37 then
			v_u_39 = v_u_37.Enabled or false
		else
			v_u_39 = false
		end
		local v_u_40 = nil
		if v_u_37 then
			v_u_40 = {}
			for _, v41 in v_u_11 do
				v_u_40[v41] = v_u_37[v41]
			end
			v_u_37.Enabled = true
			local v42 = v_u_27
			for _, v43 in v_u_11 do
				v_u_37[v43] = v42[v43]
			end
		else
			warn("[WarmupEffectsController] No map ColorCorrectionEffect found under Lighting; warmup CC tween skipped")
		end
		local function v_u_46(p44) -- name: startFinalCountdownTweens
			-- upvalues: (ref) v_u_33, (ref) v_u_35, (ref) v_u_36, (copy) v_u_37, (ref) v_u_40, (ref) v_u_38, (ref) v_u_2
			if not v_u_33 and p44 > 0 then
				v_u_33 = true
				v_u_35 = os.clock()
				v_u_36 = p44
				if v_u_37 and v_u_40 then
					if v_u_38 then
						v_u_38:Cancel()
						v_u_38 = nil
					end
					local v45 = v_u_2:Create(v_u_37, TweenInfo.new(p44, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v_u_40)
					v_u_38 = v45
					v45:Play()
				end
			end
		end
		local v_u_47 = nil
		local v_u_48 = nil
		local v_u_49 = {}
		local v_u_50 = nil
		local v_u_51 = false
		local v_u_52 = false
		local function v_u_59(p_u_53) -- name: startHighlightTweenIfPossible
			-- upvalues: (ref) v_u_51, (ref) v_u_48, (ref) v_u_47, (ref) v_u_33, (ref) v_u_35, (ref) v_u_36, (ref) v_u_2
			if v_u_51 then
				if p_u_53.Parent then
					p_u_53:Destroy()
				end
				if v_u_48 == p_u_53 then
					v_u_48 = nil
				end
				return
			elseif v_u_47 or not v_u_33 then
				return
			else
				local v54
				if v_u_33 and (v_u_35 and v_u_36) then
					local v55 = v_u_36 - (os.clock() - v_u_35)
					v54 = math.max(0, v55)
				else
					v54 = 0
				end
				if v54 <= 0 then
					v_u_51 = true
					p_u_53.FillTransparency = 1
					p_u_53.OutlineTransparency = 1
					p_u_53:Destroy()
					if v_u_48 == p_u_53 then
						v_u_48 = nil
					end
				else
					local v_u_56 = v_u_2:Create(p_u_53, TweenInfo.new(v54, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["FillTransparency"] = 1,
						["OutlineTransparency"] = 1
					})
					v_u_47 = v_u_56
					v_u_56.Completed:Connect(function(p57)
						-- upvalues: (ref) v_u_47, (copy) v_u_56, (ref) v_u_51, (copy) p_u_53, (ref) v_u_48
						if v_u_47 == v_u_56 then
							v_u_47 = nil
						end
						if p57 == Enum.PlaybackState.Completed then
							v_u_51 = true
						end
						local v58 = p_u_53
						if v58.Parent then
							v58:Destroy()
						end
						if v_u_48 == v58 then
							v_u_48 = nil
						end
					end)
					v_u_56:Play()
				end
			end
		end
		local function v_u_65() -- name: ensureHighlightAttached
			-- upvalues: (ref) v_u_29, (copy) v_u_32, (ref) v_u_51, (ref) v_u_33, (ref) v_u_35, (ref) v_u_36, (ref) v_u_47, (ref) v_u_48, (ref) v_u_4, (ref) v_u_50, (ref) v_u_22, (ref) v_u_28, (copy) v_u_59
			if v_u_29 == v_u_32 and not v_u_51 then
				if v_u_33 then
					local v60
					if v_u_33 and (v_u_35 and v_u_36) then
						local v61 = v_u_36 - (os.clock() - v_u_35)
						v60 = math.max(0, v61)
					else
						v60 = 0
					end
					if v60 <= 0 then
						v_u_51 = true
						if v_u_47 then
							v_u_47:Cancel()
							v_u_47 = nil
						end
						if v_u_48 then
							v_u_48:Destroy()
							v_u_48 = nil
						end
						return
					end
				end
				local v62 = v_u_4.CurrentCamera
				if v62 then
					local v63 = v_u_50
					if not (v63 and v63:IsDescendantOf(v62)) then
						v63 = v_u_22()
						v_u_50 = v63
					end
					if v63 then
						local v64 = v_u_48
						if not v64 or v64.Parent == nil then
							v64 = v_u_28:Clone()
							v_u_48 = v64
							v_u_47 = nil
						end
						if v64.Parent ~= v63 then
							v64.Parent = v63
						end
						if v64.Adornee ~= v63 then
							v64.Adornee = v63
						end
						v_u_59(v64)
					end
				else
					return
				end
			else
				return
			end
		end
		v_u_65()
		local function v_u_82(p_u_66) -- name: bindToCamera
			-- upvalues: (copy) v_u_49, (ref) v_u_51, (ref) v_u_25, (ref) v_u_50, (ref) v_u_52, (ref) v_u_29, (copy) v_u_32, (copy) v_u_65, (ref) v_u_48, (ref) v_u_28
			for _, v67 in v_u_49 do
				v67:Disconnect()
			end
			table.clear(v_u_49)
			if p_u_66 then
				local v68 = v_u_49
				local v69 = p_u_66.ChildAdded
				local function v72(p70)
					-- upvalues: (ref) v_u_51, (ref) v_u_25, (copy) p_u_66, (ref) v_u_50, (ref) v_u_52, (ref) v_u_29, (ref) v_u_32, (ref) v_u_65
					if not v_u_51 then
						local v71 = v_u_25(p70, p_u_66)
						if v71 then
							v_u_50 = v71
						end
						if not v_u_52 and v_u_29 == v_u_32 then
							if v_u_51 then
								return
							end
							v_u_52 = true
							task.defer(function()
								-- upvalues: (ref) v_u_52, (ref) v_u_65
								v_u_52 = false
								v_u_65()
							end)
						end
					end
				end
				table.insert(v68, v69:Connect(v72))
				local v73 = v_u_49
				local v74 = p_u_66.ChildRemoved
				local function v76(p75)
					-- upvalues: (ref) v_u_51, (ref) v_u_50, (ref) v_u_52, (ref) v_u_29, (ref) v_u_32, (ref) v_u_65
					if not v_u_51 then
						if v_u_50 == p75 or v_u_50 and v_u_50:IsDescendantOf(p75) then
							v_u_50 = nil
						end
						if not v_u_52 and v_u_29 == v_u_32 then
							if v_u_51 then
								return
							end
							v_u_52 = true
							task.defer(function()
								-- upvalues: (ref) v_u_52, (ref) v_u_65
								v_u_52 = false
								v_u_65()
							end)
						end
					end
				end
				table.insert(v73, v74:Connect(v76))
				local v77 = v_u_49
				local v78 = p_u_66.DescendantAdded
				local function v81(p79)
					-- upvalues: (ref) v_u_51, (ref) v_u_48, (ref) v_u_28, (ref) v_u_25, (copy) p_u_66, (ref) v_u_50, (ref) v_u_52, (ref) v_u_29, (ref) v_u_32, (ref) v_u_65
					if not v_u_51 and (p79 ~= v_u_48 and (not p79:IsA("Highlight") or p79.Name ~= v_u_28.Name)) then
						local v80 = v_u_25(p79, p_u_66)
						if v80 then
							v_u_50 = v80
							if not v_u_52 and v_u_29 == v_u_32 then
								if v_u_51 then
									return
								end
								v_u_52 = true
								task.defer(function()
									-- upvalues: (ref) v_u_52, (ref) v_u_65
									v_u_52 = false
									v_u_65()
								end)
							end
						end
					end
				end
				table.insert(v77, v78:Connect(v81))
			end
		end
		v_u_82(v_u_4.CurrentCamera)
		local v_u_83 = v_u_4:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
			-- upvalues: (ref) v_u_50, (copy) v_u_82, (ref) v_u_4, (ref) v_u_52, (ref) v_u_29, (copy) v_u_32, (ref) v_u_51, (copy) v_u_65
			v_u_50 = nil
			v_u_82(v_u_4.CurrentCamera)
			if not v_u_52 and v_u_29 == v_u_32 then
				if v_u_51 then
					return
				end
				v_u_52 = true
				task.defer(function()
					-- upvalues: (ref) v_u_52, (ref) v_u_65
					v_u_52 = false
					v_u_65()
				end)
			end
		end)
		local v_u_86 = v_u_4:GetAttributeChangedSignal("Timer"):Connect(function()
			-- upvalues: (ref) v_u_29, (copy) v_u_32, (ref) v_u_4, (ref) v_u_51, (ref) v_u_47, (ref) v_u_48, (ref) v_u_34, (ref) v_u_7, (ref) v_u_33, (copy) v_u_46, (copy) v_u_59, (ref) v_u_52, (copy) v_u_65
			if v_u_29 == v_u_32 then
				local v84 = v_u_4:GetAttribute("Timer")
				if typeof(v84) == "number" then
					if v84 <= 0 then
						v_u_51 = true
						if v_u_47 then
							v_u_47:Cancel()
							v_u_47 = nil
						end
						if v_u_48 then
							v_u_48:Destroy()
							v_u_48 = nil
						end
					else
						if not v_u_34 and v84 <= 2 then
							v_u_34 = true
							v_u_7.broadcastRouter("RunRoundSound", "Round Start Countdown")
						end
						if not v_u_33 and v84 <= 3 then
							v_u_46((math.min(3, v84)))
							local v85 = v_u_48
							if v85 then
								v_u_59(v85)
								return
							end
							if not v_u_52 and v_u_29 == v_u_32 then
								if v_u_51 then
									return
								end
								v_u_52 = true
								task.defer(function()
									-- upvalues: (ref) v_u_52, (ref) v_u_65
									v_u_52 = false
									v_u_65()
								end)
							end
						end
					end
				else
					return
				end
			else
				return
			end
		end)
		local v87 = v_u_4:GetAttribute("Timer")
		if typeof(v87) == "number" and v87 > 0 then
			if not v_u_34 and v87 <= 2 then
				v_u_34 = true
				v_u_7.broadcastRouter("RunRoundSound", "Round Start Countdown")
			end
			if v87 <= 3 then
				v_u_46((math.min(3, v87)))
				local v88 = v_u_48
				if v88 then
					v_u_59(v88)
				elseif not v_u_52 and (v_u_29 == v_u_32 and not v_u_51) then
					v_u_52 = true
					task.defer(function()
						-- upvalues: (ref) v_u_52, (copy) v_u_65
						v_u_52 = false
						v_u_65()
					end)
				end
			end
		end
		v_u_30 = function()
			-- upvalues: (ref) v_u_52, (ref) v_u_38, (ref) v_u_47, (copy) v_u_49, (copy) v_u_83, (copy) v_u_86, (ref) v_u_48, (copy) v_u_37, (ref) v_u_40, (ref) v_u_11, (copy) v_u_39
			v_u_52 = false
			if v_u_38 then
				v_u_38:Cancel()
				v_u_38 = nil
			end
			if v_u_47 then
				v_u_47:Cancel()
				v_u_47 = nil
			end
			for _, v89 in v_u_49 do
				v89:Disconnect()
			end
			table.clear(v_u_49)
			v_u_83:Disconnect()
			v_u_86:Disconnect()
			if v_u_48 then
				v_u_48:Destroy()
				v_u_48 = nil
			end
			if v_u_37 and v_u_40 then
				local v90 = v_u_37
				local v91 = v_u_40
				for _, v92 in v_u_11 do
					v90[v92] = v91[v92]
				end
				v_u_37.Enabled = v_u_39
			end
		end
	end
	local function v97() -- name: updateState
		-- upvalues: (ref) v_u_6, (ref) v_u_8, (ref) v_u_9, (ref) v_u_31, (copy) v_u_93, (ref) v_u_29, (ref) v_u_30
		if v_u_6.GetState() == "Buy Period" then
			local v94
			if v_u_8.IsInspectActive() or v_u_8.IsCaseSceneActive() then
				v94 = false
			else
				local v95 = v_u_8.GetMenuFrame()
				if v95 and v95.Visible then
					v94 = false
				else
					local v96 = v_u_9:GetAttribute("IsSpectating") == true
					v94 = v_u_9.Character ~= nil and true or v96
				end
			end
			if v94 then
				if not v_u_31 then
					v_u_31 = true
					v_u_93()
					return
				end
			elseif v_u_31 then
				v_u_31 = false
				v_u_29 = v_u_29 + 1
				if v_u_30 then
					v_u_30()
					v_u_30 = nil
				end
			end
		else
			if v_u_31 then
				v_u_31 = false
				v_u_29 = v_u_29 + 1
				if v_u_30 then
					v_u_30()
					v_u_30 = nil
				end
			end
			return
		end
	end
	v_u_6.ListenToState(v97)
	v_u_8.OnScreenChanged:Connect(v97)
	v_u_8.OnInspectStateChanged:Connect(v97)
	v_u_8.OnCaseSceneStateChanged:Connect(v97)
	v_u_9.CharacterAdded:Connect(v97)
	v_u_9.CharacterRemoving:Connect(v97)
	v_u_9:GetAttributeChangedSignal("IsSpectating"):Connect(v97)
	if v_u_6.GetState() == "Buy Period" then
		local v98
		if v_u_8.IsInspectActive() or v_u_8.IsCaseSceneActive() then
			v98 = false
		else
			local v99 = v_u_8.GetMenuFrame()
			if v99 and v99.Visible then
				v98 = false
			else
				local v100 = v_u_9:GetAttribute("IsSpectating") == true
				v98 = v_u_9.Character ~= nil and true or v100
			end
		end
		if v98 then
			if not v_u_31 then
				v_u_31 = true
				v_u_93()
			end
		elseif v_u_31 then
			v_u_31 = false
			v_u_29 = v_u_29 + 1
			if v_u_30 then
				v_u_30()
				v_u_30 = nil
			end
		end
	else
		if v_u_31 then
			v_u_31 = false
			v_u_29 = v_u_29 + 1
			if v_u_30 then
				v_u_30()
				v_u_30 = nil
			end
		end
		return
	end
end
return v12
-- NIGHT Analyzer | ReplicatedStorage.Controllers.MedalAutoClipController
-- ModuleScript | 34 linhas | 1242 bytes | hash 031630fc

local v1 = {}
local v2 = game:GetService("ReplicatedStorage")
local v3 = game:GetService("RunService")
local v_u_4 = require(v2:WaitForChild("Shared"):WaitForChild("MedalClipper"))
local v_u_5 = require(v2.Database.Security.Remotes)
local v_u_6 = v3:IsStudio()
local function v_u_15(p7) -- name: triggerMedalClip
	-- upvalues: (copy) v_u_6, (copy) v_u_4
	if v_u_6 then
		print("[MedalAutoClipController]", "Received clip request", ("eventId=%*"):format(p7.EventId), ("eventName=%*"):format(p7.EventName), ("duration=%*"):format(p7.Duration), (("captureDelayMs=%*"):format(p7.CaptureDelayMs or 0)))
	end
	local v8 = v_u_4.TriggerClip
	local v9 = v_u_4
	local v10 = p7.EventId
	local v11 = p7.EventName
	local v12 = {
		["duration"] = p7.Duration,
		["captureDelayMs"] = p7.CaptureDelayMs,
		["contextTags"] = p7.ContextTags
	}
	local v13, v14 = pcall(v8, v9, v10, v11, v12)
	if v13 then
		if v_u_6 then
			print("[MedalAutoClipController]", "Medal TriggerClip completed", p7.EventName)
		end
	else
		warn((("[MedalAutoClipController] Failed to trigger Medal clip: %*"):format(v14)))
	end
end
function v1.Initialize() -- name: Initialize
	-- upvalues: (copy) v_u_5, (copy) v_u_15
	v_u_5.Collaborations.MedalAutoClip.Listen(v_u_15)
end
return v1
-- NIGHT Analyzer | ReplicatedStorage.Controllers.EntityController.Entities.AmmoCrate
-- ModuleScript | 90 linhas | 2358 bytes | hash 1e7a6813

local v_u_1 = {}
v_u_1.__index = v_u_1
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Players")
local v_u_4 = require(v2.Controllers.SurvivalVoiceController)
local v_u_5 = require(v2.Database.Security.Remotes)
local v_u_6 = require(v2.Database.Security.Router)
local v_u_7 = v2:WaitForChild("Assets"):WaitForChild("ItemDrops"):WaitForChild("AmmoCrate")
local v_u_8 = { 3, 12 }
local function v_u_12(p9, p10) -- name: AttemptEntityPickup
	-- upvalues: (copy) v_u_5
	if p10 and (p10 - p9.Position).Magnitude <= 6 then
		local v11 = os.clock()
		if v11 - p9.LastRequest >= 0.5 then
			p9.LastRequest = v11
			v_u_5.Entity.InteractWithEntity.Send({
				["EntityId"] = nil,
				["Action"] = "Pickup",
				["EntityId"] = p9.EntityId
			})
		end
	else
		return
	end
end
local function v_u_24(p13, p14) -- name: UpdateBlink
	-- upvalues: (copy) v_u_8
	local v15 = p13.Lifetime
	if v15 then
		local v16 = v15 - 5
		local v17
		if v16 <= p14 then
			local v18 = (p14 - v16) / 5
			local v19 = math.clamp(v18, 0, 1)
			local v20 = v_u_8[1] + (v_u_8[2] - v_u_8[1]) * v19
			v17 = (p14 - v16) * v20 % 1 >= 0.5
		else
			v17 = false
		end
		if v17 ~= p13.IsFaded then
			p13.IsFaded = v17
			for v21, v23 in p13.BlinkParts do
				if v17 then
					local v23 = 1 - (1 - v23) * 0.25
				end
				v21.Transparency = v23
			end
		end
	else
		return
	end
end
function v_u_1.new(p25, _, p26, p27) -- name: new
	-- upvalues: (copy) v_u_7, (copy) v_u_1
	local v28 = {
		["EntityId"] = nil,
		["Position"] = nil,
		["Model"] = nil,
		["LastRequest"] = 0,
		["Lifetime"] = nil,
		["BlinkParts"] = nil,
		["IsFaded"] = false,
		["EntityId"] = p25,
		["Position"] = p26,
		["Model"] = v_u_7:Clone(),
		["Lifetime"] = p27,
		["BlinkParts"] = {}
	}
	local v29 = v_u_1
	return setmetatable(v28, v29)
end
function v_u_1.TrackPart(p30, p31) -- name: TrackPart
	if p31.Transparency < 1 then
		p30.BlinkParts[p31] = p31.Transparency
	end
end
function v_u_1.Step(p32, p33, p34) -- name: Step
	-- upvalues: (copy) v_u_24, (copy) v_u_12
	v_u_24(p32, p33)
	v_u_12(p32, p34)
end
function v_u_1.Destroy(p35, p36) -- name: Destroy
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_6
	p35.Model:Destroy()
	if p36 == v_u_3.LocalPlayer.UserId then
		v_u_4.OnAmmoCrate()
		v_u_6.broadcastRouter("RunInterfaceSound", "Successful Buy Menu Purchase")
	end
end
return v_u_1
-- NIGHT Analyzer | ReplicatedStorage.Controllers.EntityController.Entities.Health
-- ModuleScript | 53 linhas | 1522 bytes | hash e8c551b0

local v_u_1 = {}
v_u_1.__index = v_u_1
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Players")
local v_u_4 = require(v2.Controllers.SurvivalVoiceController)
local v_u_5 = require(v2.Database.Security.Remotes)
local v_u_6 = require(v2.Database.Security.Router)
local v_u_7 = v2:WaitForChild("Assets"):WaitForChild("ItemDrops"):WaitForChild("Health")
local function v_u_11(p8, p9) -- name: AttemptEntityPickup
	-- upvalues: (copy) v_u_3, (copy) v_u_5
	if p9 and (p9 - p8.Position).Magnitude <= 6 then
		local v10 = os.clock()
		if v10 - p8.LastRequest < 0.5 then
			return
		elseif not v_u_3.LocalPlayer:GetAttribute("BuyMenu") then
			p8.LastRequest = v10
			v_u_5.Entity.InteractWithEntity.Send({
				["EntityId"] = nil,
				["Action"] = "Pickup",
				["EntityId"] = p8.EntityId
			})
		end
	else
		return
	end
end
function v_u_1.new(p12, _, p13) -- name: new
	-- upvalues: (copy) v_u_7, (copy) v_u_1
	local v14 = {
		["EntityId"] = nil,
		["Position"] = nil,
		["Model"] = nil,
		["LastRequest"] = 0,
		["EntityId"] = p12,
		["Position"] = p13,
		["Model"] = v_u_7:Clone()
	}
	local v15 = v_u_1
	return setmetatable(v14, v15)
end
function v_u_1.Step(p16, _, p17) -- name: Step
	-- upvalues: (copy) v_u_11
	v_u_11(p16, p17)
end
function v_u_1.Destroy(p18, p19) -- name: Destroy
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_6
	p18.Model:Destroy()
	if p19 == v_u_3.LocalPlayer.UserId then
		v_u_4.OnHealthKit()
		v_u_6.broadcastRouter("DeathmatchHealthClaimed")
	end
end
return v_u_1
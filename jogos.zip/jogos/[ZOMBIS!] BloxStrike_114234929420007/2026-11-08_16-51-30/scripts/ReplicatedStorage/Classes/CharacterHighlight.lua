-- NIGHT Analyzer | ReplicatedStorage.Classes.CharacterHighlight
-- ModuleScript | 83 linhas | 2638 bytes | hash d9c249c0

local v_u_1 = {}
v_u_1.__index = v_u_1
local v2 = game:GetService("ReplicatedStorage")
require(script:WaitForChild("Types"))
local v_u_3 = require(v2.Controllers.RunServiceController)
local v_u_4 = require(v2.Shared.Janitor)
local v_u_5 = require(v2.Shared.Spring)
local v_u_6 = require(v2.Components.Common.CharacterResolver)
local function v_u_10(p7, p8) -- name: applyFill
	local v9
	if p7.OutlineOnly then
		v9 = p7.Properties.OutlineColor:Lerp(Color3.new(1, 1, 1), 0.2)
		p8 = 0.9
	else
		v9 = p7.Properties.FillColor
	end
	if p7.AppliedFillColor ~= v9 then
		p7.Highlight.FillColor = v9
		p7.AppliedFillColor = v9
	end
	if p7.AppliedFillTransparency ~= p8 then
		p7.Highlight.FillTransparency = p8
		p7.AppliedFillTransparency = p8
	end
end
function v_u_1.UpdateState(p11, p12) -- name: UpdateState
	-- upvalues: (copy) v_u_10
	if p11.Highlight and p11.Highlight.Parent then
		if p11.IsEnabled ~= p12 then
			if p12 then
				v_u_10(p11, p11.CurrentTransparency:getPosition())
			end
			p11.Highlight.Enabled = p12
			p11.IsEnabled = p12
		end
	end
end
function v_u_1.new(p_u_13, p14) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_5, (copy) v_u_6, (copy) v_u_3, (copy) v_u_10
	local v15 = v_u_1
	local v_u_16 = setmetatable({}, v15)
	v_u_16.Janitor = v_u_4.new()
	v_u_16.CurrentTransparency = v_u_5.new(0.95, 1.5, 0.6)
	v_u_16.Properties = p14
	v_u_16.Character = p_u_13
	local v17 = v_u_16.Janitor:Add(Instance.new("Highlight", p_u_13))
	v17.Enabled = false
	v17.OutlineTransparency = p14.OutlineTransparency
	v17.FillTransparency = p14.FillTransparency
	v17.OutlineColor = p14.OutlineColor
	v17.DepthMode = p14.DepthMode
	v17.FillColor = p14.FillColor
	v_u_16.Highlight = v17
	v_u_16.IsEnabled = false
	v_u_16.OutlineOnly = false
	if v_u_6.isAliveCharacter(p_u_13) then
		v_u_16.Janitor:Add(p_u_13:GetAttributeChangedSignal("Dead"):Connect(function()
			-- upvalues: (copy) p_u_13, (copy) v_u_16
			if p_u_13:GetAttribute("Dead") then
				v_u_16:Destroy()
			end
		end))
	end
	local v18 = v_u_3.CreateBindingName("Classes.CharacterHighlight.Pulse")
	v_u_16.Janitor:Add(v_u_3.BindToHeartbeat(v18, function(p19)
		-- upvalues: (copy) v_u_16, (ref) v_u_10
		if v_u_16.IsEnabled and (v_u_16.Highlight and v_u_16.Highlight.Parent) then
			local v20 = v_u_16.CurrentTransparency:getPosition()
			v_u_16.CurrentTransparency:update(p19)
			if v20 >= 0.8 then
				v_u_16.CurrentTransparency:setGoal(0.6)
			elseif v20 <= 0.6 then
				v_u_16.CurrentTransparency:setGoal(0.8)
			end
			v_u_10(v_u_16, v20)
		end
	end))
	return v_u_16
end
function v_u_1.Destroy(p21) -- name: Destroy
	p21.Janitor:Destroy()
end
return v_u_1
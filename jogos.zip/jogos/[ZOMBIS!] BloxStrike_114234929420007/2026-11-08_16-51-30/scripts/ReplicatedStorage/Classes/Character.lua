-- NIGHT Analyzer | ReplicatedStorage.Classes.Character
-- ModuleScript | 594 linhas | 20184 bytes | hash c35acb2e

local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("Workspace")
local v5 = v2.MovementV2
local v_u_6 = require(v5.Buttons)
local v_u_7 = require(v5.JumpInputSampler)
local v_u_8 = require(v2.Components.Common.CharacterGeneration)
local v_u_9 = require(v2.Components.Common.CharacterResolver)
local v_u_10 = require(v2.Components.Common.IsSurvivalMode)
local v_u_11 = require(v2.Components.Common.SurvivalDowned)
local v_u_12 = require(v2.Shared.Janitor)
local v_u_13 = require(v5.Simulation.PlayerContacts)
local v_u_14 = require(v5.Client.PredictionErrorSmoother)
local v_u_15 = require(v5.Simulation.Config)
local v_u_16 = require(v5.Simulation.State)
local v_u_17 = require(v5.RootFrame)
local v_u_18 = require(v5.RuntimeKinematics)
local v_u_19 = require(v2.Packages.Signal)
local v_u_20 = require(script.Classes.CharacterAnimator)
local v_u_21 = v1.LocalPlayer
local v_u_22 = {}
v_u_22.__index = v_u_22
local v23 = -v_u_11.EYE_DROP
local v_u_24 = Vector3.new(0, v23, 0)
local v_u_25 = 150 * v_u_15.Default.HammerUnitToStud
local v_u_26 = v_u_14.ContactMinDistance
local function v_u_33(p27) -- name: finiteHorizontalInput
	if p27.X == p27.X and (p27.Y == p27.Y and p27.Z == p27.Z) then
		local v28 = p27.X
		if math.abs(v28) ~= (1 / 0) then
			local v29 = p27.Y
			if math.abs(v29) ~= (1 / 0) then
				local v30 = p27.Z
				if math.abs(v30) ~= (1 / 0) then
					local v31 = p27.X
					local v32 = p27.Z
					return Vector3.new(v31, 0, v32)
				end
			end
		end
	end
	return Vector3.new(0, 0, 0)
end
local function v_u_46(p34, p35, p36, p37) -- name: applyAutomaticAirStrafe
	-- upvalues: (copy) v_u_3
	local v38 = v_u_3.PreferredInput
	if (v38 == Enum.PreferredInput.Touch and true or v38 == Enum.PreferredInput.Gamepad) and (not p37.OnGround and p37.MovementMode == "Walking") then
		local v39 = p34.X
		if math.abs(v39) <= 0.2 then
			local v40 = p36 - p35
			local v41 = math.sin(v40)
			local v42 = p36 - p35
			local v43 = math.cos(v42)
			local v44 = math.atan2(v41, v43)
			if math.abs(v44) <= 0.00017453292519943296 then
				return p34
			end
			local v45 = v44 < 0 and 1 or -1
			return Vector2.new(v45, p34.Y)
		end
	end
	return p34
end
local function v_u_53(p47) -- name: syncCameraPart
	local v48 = p47.CameraPart
	local v49 = p47.HumanoidRootPart
	if v48.Parent and v49.Parent then
		local v50 = 2 + p47.StepCameraOffsetY
		local v51 = Vector3.new(0, v50, 0) + p47.CameraOffset
		local v52 = v48:FindFirstChild("CameraPartWeld")
		if v52 == nil or not v52:IsA("Weld") then
			v48.CFrame = v49.CFrame * CFrame.new(v51)
		else
			v52.Part0 = v49
			v52.Part1 = v48
			v52.C0 = CFrame.new(v51)
			v52.C1 = CFrame.identity
		end
	else
		return
	end
end
local function v_u_96(p54, p55, p56) -- name: updateCameraOffset
	-- upvalues: (copy) v_u_17, (copy) v_u_11, (copy) v_u_21, (copy) v_u_24, (copy) v_u_53
	local v57 = p54.IsPlantingBomb and 1 or 0
	local v58 = p55 / 0.12
	if p54.VisualPlantCameraAlpha < v57 then
		local v59 = p54.VisualPlantCameraAlpha + v58
		p54.VisualPlantCameraAlpha = math.min(v57, v59)
	else
		local v60 = p54.VisualPlantCameraAlpha - v58
		p54.VisualPlantCameraAlpha = math.max(v57, v60)
	end
	local v61 = p54.MovementState.DuckAmount
	local v62 = math.clamp(v61, 0, 1)
	local v63 = p54.VisualDuckAmount
	local v64 = math.max(p55, 0) * -20
	local v65 = 1 - math.exp(v64)
	local v66 = v63 + (v62 - v63) * v65
	local v67 = v62 - v66
	if math.abs(v67) <= 0.001 then
		v66 = v62
	end
	p54.VisualDuckAmount = v66
	local v68 = p54.MovementState.OnGround and 0 or v62
	local v69 = p54.VisualDuckRootAmount
	local v70 = math.max(p55, 0) * -20
	local v71 = 1 - math.exp(v70)
	local v72 = v69 + (v68 - v69) * v71
	local v73 = v68 - v72
	if math.abs(v73) > 0.001 then
		v68 = v72
	end
	p54.VisualDuckRootAmount = v68
	local v74 = p56 or v_u_17.getDuckRootVerticalOffset(v62, p54.MovementState.OnGround)
	local v75 = v_u_17.getDuckRootVerticalOffset
	local v76 = p54.VisualDuckRootAmount
	local v77 = math.clamp(v76, 0, 1)
	p54.CameraDuckRootCompensationY = v75(v77 * v77 * (3 - v77 * 2), false) - v74
	local v78 = v_u_11.IsDowned(v_u_21) and 1 or 0
	local v79 = p55 / 0.35
	if p54.VisualDownedCameraAlpha < v78 then
		local v80 = p54.VisualDownedCameraAlpha + v79
		p54.VisualDownedCameraAlpha = math.min(v78, v80)
	else
		local v81 = p54.VisualDownedCameraAlpha - v79
		p54.VisualDownedCameraAlpha = math.max(v78, v81)
	end
	local v82 = p54.VisualDuckAmount
	local v83 = math.clamp(v82, 0, 1)
	local v84 = v83 * v83 * (3 - v83 * 2)
	local v85 = p54.DefaultCameraOffset
	local v86 = v85:Lerp(v85 + p54.CrouchCameraOffset, v84)
	local v87 = p54.CameraDuckRootCompensationY
	local v88 = v86 + Vector3.new(0, v87, 0)
	local v89 = v85 + Vector3.new(0, -0.9, 0)
	local v90 = p54.VisualPlantCameraAlpha
	local v91 = math.clamp(v90, 0, 1)
	local v92 = v88:Lerp(v89, v91 * v91 * (3 - v91 * 2))
	local v93 = v85 + v_u_24
	local v94 = p54.VisualDownedCameraAlpha
	local v95 = math.clamp(v94, 0, 1)
	p54.CameraOffset = v92:Lerp(v93, v95 * v95 * (3 - v95 * 2))
	v_u_53(p54)
end
local function v_u_113(p97, p98, p99, p100, p101) -- name: updateStepCameraOffset
	-- upvalues: (copy) v_u_15, (copy) v_u_25
	local v102 = p97.StepSmoothRootY
	local v103 = p97.StepSmoothLastDuckAmount ~= p98.DuckAmount
	local v104 = p97.StepSmoothWasOnGround ~= p98.OnGround
	p97.StepSmoothLastDuckAmount = p98.DuckAmount
	p97.StepSmoothWasOnGround = p98.OnGround
	local v105 = v_u_15.Default.MaxStepHeight
	if not p101 and (typeof(v102) == "number" and (p98.OnGround and not (v104 or v103))) then
		local v106 = p99 - v102
		if math.abs(v106) <= v105 * 2 then
			if v102 < p99 then
				local v107 = v102 + v_u_25 * p100
				local v108 = math.min(v107, p99)
				local v109 = p99 - v105
				v102 = math.max(v108, v109)
			elseif p99 < v102 then
				local v110 = v102 - v_u_25 * p100
				local v111 = math.max(v110, p99)
				local v112 = p99 + v105
				v102 = math.min(v111, v112)
			end
			p97.StepSmoothRootY = v102
			p97.StepCameraOffsetY = v102 - p99
			return
		end
	end
	p97.StepSmoothRootY = p99
	p97.StepCameraOffsetY = 0
end
function v_u_22.new(p_u_114, p115) -- name: new
	-- upvalues: (copy) v_u_9, (copy) v_u_8, (copy) v_u_4, (copy) v_u_16, (copy) v_u_17, (copy) v_u_12, (copy) v_u_21, (copy) v_u_20, (copy) v_u_19, (copy) v_u_22, (copy) v_u_18, (copy) v_u_96
	local v116 = v_u_9.getCameraPart(p_u_114)
	local v117 = ("%* has no CameraPart"):format((p_u_114:GetFullName()))
	local v118 = assert(v116, v117)
	local v119 = v_u_8.Get(p_u_114)
	local v120 = assert(v119, "local shell has no CharacterGeneration")
	local v121 = v_u_4.CurrentCamera
	local v122, v123
	if v121 == nil then
		local _ = CFrame.identity
		v122 = 0
		v123 = 0
	else
		local v124, v125
		v124, v122, v125 = v121.CFrame:ToEulerAnglesYXZ()
		CFrame.Angles(0, v122, 0)
		local v126 = v121.CFrame.LookVector.Y
		v123 = math.clamp(v126, -1, 1)
	end
	local v127 = v_u_16.new(v_u_17.rootToSimulationPosition(p115.Position, "Standing"), nil, select(2, p115.CFrame:ToEulerAnglesYXZ()), 0)
	local v128 = {
		["Janitor"] = v_u_12.new(),
		["Character"] = p_u_114,
		["Player"] = v_u_21,
		["Generation"] = v120,
		["HumanoidRootPart"] = p115,
		["CameraPart"] = v118,
		["CharacterAnimator"] = v_u_20.new(p_u_114),
		["MovementState"] = v127,
		["Support"] = v_u_16.noneSupport(),
		["GlobalVelocity"] = Vector3.new(0, 0, 0),
		["GlobalDirection"] = Vector3.new(0, 0, 0),
		["LatestMoveVector"] = Vector2.zero,
		["PreviousFrameMoveVector"] = Vector2.zero,
		["CurrentFrameMoveVector"] = Vector2.zero,
		["PreviousFrameLookYaw"] = v122,
		["CurrentFrameLookYaw"] = v122,
		["LastSampledLookYaw"] = v122,
		["CurrentFrameVerticalLook"] = v123,
		["InputFramePrepared"] = false,
		["CrouchInputDown"] = false,
		["JumpInputDown"] = false,
		["JumpPulsePending"] = false,
		["JumpPulseNeedsRelease"] = false,
		["IsWalking"] = false,
		["IsSprinting"] = false,
		["IsCrouching"] = false,
		["IsClimbing"] = false,
		["IsJumping"] = false,
		["IsPlantingBomb"] = false,
		["OnGround"] = true,
		["DefaultCameraOffset"] = v_u_21:GetAttribute("DefaultCameraOffset") or Vector3.new(0, -0.15, 0),
		["CrouchCameraOffset"] = v_u_21:GetAttribute("CrouchCameraOffset") or Vector3.new(0, -1.4, 0),
		["CameraOffset"] = Vector3.new(0, 0, 0),
		["VisualDuckAmount"] = v127.DuckAmount,
		["VisualDuckRootAmount"] = 0,
		["CameraDuckRootCompensationY"] = 0,
		["VisualPlantCameraAlpha"] = 0,
		["VisualDownedCameraAlpha"] = 0,
		["StepSmoothRootY"] = p115.Position.Y,
		["StepSmoothLastDuckAmount"] = v127.DuckAmount,
		["StepSmoothWasOnGround"] = v127.OnGround,
		["StepCameraOffsetY"] = 0,
		["LastPresentedAt"] = os.clock(),
		["LastExactPresentationTick"] = nil,
		["SnapNextPresentation"] = true,
		["PredictionErrorOffset"] = Vector3.new(0, 0, 0),
		["PredictionErrorElapsedSeconds"] = 0,
		["PreservePredictionPresentation"] = false,
		["PendingPredictionPositionDelta"] = Vector3.new(0, 0, 0),
		["IsDestroyed"] = false,
		["Crouching"] = v_u_19.new(),
		["Climbing"] = v_u_19.new(),
		["Walking"] = v_u_19.new(),
		["Landed"] = v_u_19.new()
	}
	local v129 = v_u_22
	local v_u_130 = setmetatable(v128, v129)
	v_u_130.CharacterAnimator.Player = v_u_21
	p115.Anchored = true
	p115.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
	p115.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
	v_u_130.Janitor:Add(v_u_130.Crouching)
	v_u_130.Janitor:Add(v_u_130.Climbing)
	v_u_130.Janitor:Add(v_u_130.Walking)
	v_u_130.Janitor:Add(v_u_130.Landed)
	v_u_130.Janitor:Add(function()
		-- upvalues: (copy) v_u_130, (ref) v_u_18, (copy) p_u_114
		v_u_130.CharacterAnimator:destroy()
		v_u_18.clear(p_u_114)
	end)
	v_u_130.Janitor:Add(v_u_21:GetAttributeChangedSignal("DefaultCameraOffset"):Connect(function()
		-- upvalues: (copy) v_u_130, (ref) v_u_21
		v_u_130.DefaultCameraOffset = v_u_21:GetAttribute("DefaultCameraOffset") or Vector3.new(0, -0.15, 0)
	end))
	v_u_130.Janitor:Add(v_u_21:GetAttributeChangedSignal("CrouchCameraOffset"):Connect(function()
		-- upvalues: (copy) v_u_130, (ref) v_u_21
		v_u_130.CrouchCameraOffset = v_u_21:GetAttribute("CrouchCameraOffset") or Vector3.new(0, -1.4, 0)
	end))
	v_u_96(v_u_130, 0)
	v_u_18.write(p_u_114, Vector3.new(0, 0, 0), true, p115.Position)
	return v_u_130
end
function v_u_22.MatchesGeneration(p131, p132) -- name: MatchesGeneration
	-- upvalues: (copy) v_u_8
	local v133 = not p131.IsDestroyed
	if v133 then
		if p131.Character.Parent == nil or (p131.Character:GetAttribute("Dead") == true or p131.Generation ~= p132) then
			v133 = false
		else
			v133 = v_u_8.Get(p131.Character) == p132
		end
	end
	return v133
end
function v_u_22.MoveFunction(p134, p135, p136) -- name: MoveFunction
	-- upvalues: (copy) v_u_4, (copy) v_u_33
	if not p134.IsDestroyed then
		local v137 = v_u_4.CurrentCamera
		local v138
		if v137 == nil then
			v138 = CFrame.identity
		else
			local _, v139, _ = v137.CFrame:ToEulerAnglesYXZ()
			v138 = CFrame.Angles(0, v139, 0)
			local v140 = v137.CFrame.LookVector.Y
			math.clamp(v140, -1, 1)
		end
		local v141 = v_u_33(p135)
		if not p136 then
			v141 = v138:VectorToObjectSpace(v141)
		end
		local v142 = v141.X
		local v143 = math.clamp(v142, -1, 1)
		local v144 = v141.Z
		local v145 = math.clamp(v144, -1, 1)
		local v146 = Vector3.new(v143, 0, v145)
		p134.GlobalDirection = v138:VectorToWorldSpace(v146)
		p134.LatestMoveVector = Vector2.new(v146.X, v146.Z)
	end
end
function v_u_22.PrepareInputFrame(p147) -- name: PrepareInputFrame
	-- upvalues: (copy) v_u_4
	if p147.IsDestroyed then
		return
	else
		local v148 = v_u_4.CurrentCamera
		local v149, v150
		if v148 == nil then
			local _ = CFrame.identity
			v149 = 0
			v150 = 0
		else
			local v151, v152
			v151, v149, v152 = v148.CFrame:ToEulerAnglesYXZ()
			CFrame.Angles(0, v149, 0)
			local v153 = v148.CFrame.LookVector.Y
			v150 = math.clamp(v153, -1, 1)
		end
		if p147.InputFramePrepared then
			p147.PreviousFrameMoveVector = p147.CurrentFrameMoveVector
			p147.CurrentFrameMoveVector = p147.LatestMoveVector
			p147.PreviousFrameLookYaw = p147.CurrentFrameLookYaw
			p147.CurrentFrameLookYaw = v149
			p147.CurrentFrameVerticalLook = v150
		else
			p147.PreviousFrameMoveVector = p147.LatestMoveVector
			p147.CurrentFrameMoveVector = p147.LatestMoveVector
			p147.PreviousFrameLookYaw = v149
			p147.CurrentFrameLookYaw = v149
			p147.CurrentFrameVerticalLook = v150
			p147.InputFramePrepared = true
		end
	end
end
function v_u_22.ToggleWalkState(p154, p155) -- name: ToggleWalkState
	if p154.IsWalking ~= p155 then
		p154.IsWalking = p155
		p154.Walking:Fire(p155)
	end
end
function v_u_22.ToggleSprintState(p156, p157) -- name: ToggleSprintState
	p156.IsSprinting = p157
end
function v_u_22.ToggleCrouchInput(p158, p159) -- name: ToggleCrouchInput
	p158.CrouchInputDown = p159
end
function v_u_22.SetJumpInput(p160, p161) -- name: SetJumpInput
	if p161 == nil then
		p160.JumpPulsePending = true
	else
		p160.JumpInputDown = p161
	end
end
function v_u_22.PlantBomb(p162) -- name: PlantBomb
	p162.IsPlantingBomb = true
end
function v_u_22.CancelBombPlant(p163) -- name: CancelBombPlant
	p163.IsPlantingBomb = false
end
function v_u_22.SampleInput(p164, p165) -- name: SampleInput
	-- upvalues: (copy) v_u_46, (copy) v_u_11, (copy) v_u_21, (copy) v_u_6, (copy) v_u_10, (copy) v_u_7
	if not p164:MatchesGeneration(p165.Mapping.Generation) then
		return nil
	end
	local v166 = p165.FrameSampleAlpha or 1
	local v167 = math.clamp(v166, 0, 1)
	local v168 = p164.PreviousFrameMoveVector
	local v169 = p164.CurrentFrameMoveVector
	local v170 = v168.X
	local v171 = math.sign(v170)
	local v172 = v169.X
	local v173
	if v171 == math.sign(v172) then
		local v174 = v168.Y
		local v175 = math.sign(v174)
		local v176 = v169.Y
		v173 = v175 ~= math.sign(v176)
	else
		v173 = true
	end
	if v173 then
		if v167 < 0.5 then
			v169 = v168
		end
	else
		v169 = v168:Lerp(v169, v167)
	end
	local v177 = p164.PreviousFrameLookYaw
	local v178 = p164.PreviousFrameLookYaw
	local v179 = p164.CurrentFrameLookYaw
	local v180 = v179 - v178
	local v181 = math.sin(v180)
	local v182 = v179 - v178
	local v183 = math.cos(v182)
	local v184 = v177 + math.atan2(v181, v183) * v167
	local v185 = v_u_46(v169, p164.LastSampledLookYaw, v184, p165.State)
	p164.LastSampledLookYaw = v184
	local v186 = v_u_11.IsDowned(v_u_21)
	local v187 = v_u_6.with(0, v_u_6.Walk, p164.IsWalking)
	local v188 = v_u_6.with
	local v189 = v_u_6.Sprint
	local v190 = p164.IsSprinting == true and not v186
	if v190 then
		v190 = v_u_10()
	end
	local v191 = v188(v187, v189, v190)
	local v192 = v_u_6.with
	local v193 = v_u_6.Duck
	local v194
	if p164.CrouchInputDown == true then
		v194 = not v186
	else
		v194 = false
	end
	local v195 = v192(v191, v193, v194)
	local v196, v197, v198 = v_u_7.sample(p164.JumpInputDown, p164.JumpPulsePending, p164.JumpPulseNeedsRelease)
	p164.JumpPulsePending = v197
	p164.JumpPulseNeedsRelease = v198
	local v199 = v_u_6.with
	local v200 = v_u_6.Jump
	local v201
	if v196 == true then
		v201 = not v186
	else
		v201 = false
	end
	local v202 = v199(v195, v200, v201)
	return {
		["Move"] = v185,
		["LookYaw"] = v184,
		["VerticalLook"] = p164.CurrentFrameVerticalLook,
		["Buttons"] = v202
	}
end
function v_u_22.Present(p203, p204, p205, p206, p207) -- name: Present
	-- upvalues: (copy) v_u_17, (copy) v_u_14, (copy) v_u_113, (copy) v_u_13, (copy) v_u_18, (copy) v_u_96
	local v208 = p206.Mapping
	local v209
	if v208 == nil then
		v209 = p203.Generation
	else
		v209 = v208.Generation
	end
	if p203:MatchesGeneration(v209) then
		local v210 = os.clock()
		local v211 = v210 - p203.LastPresentedAt
		local v212 = math.clamp(v211, 0, 0.1)
		p203.LastPresentedAt = v210
		local v213 = v_u_17.cframe(p204)
		local v214 = v_u_17.cframe(p207 or p204)
		local v215 = p203.SnapNextPresentation
		if v215 then
			p203.LastExactPresentationTick = p206.ServerTick
		end
		local v216
		if v215 then
			v216 = v215
		elseif p203.LastExactPresentationTick == nil then
			v216 = false
		else
			v216 = p206.ServerTick == p203.LastExactPresentationTick
		end
		local v217 = p206.TickFraction or 0
		local v218 = math.clamp(v217, 0, 1)
		local v219
		if v216 then
			v219 = v213
		else
			v219 = v214:Lerp(v213, v218)
		end
		if not v216 then
			p203.LastExactPresentationTick = nil
		end
		p203.SnapNextPresentation = false
		local v220 = p203.PreservePredictionPresentation == true
		p203.PreservePredictionPresentation = false
		local v221 = p203.PendingPredictionPositionDelta
		p203.PendingPredictionPositionDelta = Vector3.new(0, 0, 0)
		if v216 then
			p203.PredictionErrorOffset = Vector3.new(0, 0, 0)
			p203.PredictionErrorElapsedSeconds = 0
		elseif v220 then
			local v222 = v_u_14.remainingOffset(p203.PredictionErrorOffset, p203.PredictionErrorElapsedSeconds) - v221
			p203.PredictionErrorOffset = v_u_14.clampOffset(v222)
			p203.PredictionErrorElapsedSeconds = 0
		end
		local v223 = v_u_14.remainingOffset(p203.PredictionErrorOffset, p203.PredictionErrorElapsedSeconds)
		if not v216 and v223.Magnitude > v_u_14.Epsilon then
			v219 = v219 + v223
			p203.PredictionErrorElapsedSeconds = p203.PredictionErrorElapsedSeconds + v212
			if v_u_14.remainingOffset(p203.PredictionErrorOffset, p203.PredictionErrorElapsedSeconds).Magnitude <= v_u_14.Epsilon then
				p203.PredictionErrorOffset = Vector3.new(0, 0, 0)
				p203.PredictionErrorElapsedSeconds = 0
			end
		end
		v_u_113(p203, p204, v219.Position.Y, v212, v215)
		p203.HumanoidRootPart.CFrame = v219
		p203.HumanoidRootPart.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
		p203.HumanoidRootPart.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
		local v224 = v_u_13.toWorldVelocity(p204.Velocity, p205)
		p203.MovementState = p204
		p203.Support = p205
		local v225 = v224.X
		local v226 = v224.Z
		p203.GlobalVelocity = Vector3.new(v225, 0, v226)
		p203.OnGround = p204.OnGround
		local v227 = not p204.OnGround
		if v227 then
			v227 = v224.Y > 0
		end
		p203.IsJumping = v227
		local v228 = p204.DuckAmount > 0.5
		if v228 ~= p203.IsCrouching then
			p203.IsCrouching = v228
			p203.Crouching:Fire(v228)
		end
		local v229 = p204.MovementMode == "Ladder"
		if v229 ~= p203.IsClimbing then
			p203.IsClimbing = v229
			p203.Climbing:Fire(v229)
		end
		v_u_18.write(p203.Character, v224, p204.OnGround, v213.Position)
		p203.CharacterAnimator:updateLocomotion(v224, p204.OnGround, v228, v229)
		local v230 = p207 or p204
		local v231 = v_u_17.getDuckRootVerticalOffset(v230.DuckAmount, v230.OnGround)
		local v232 = v_u_17.getDuckRootVerticalOffset(p204.DuckAmount, p204.OnGround)
		if not v216 then
			v232 = v231 + (v232 - v231) * v218
		end
		v_u_96(p203, v212, v232)
	end
end
function v_u_22.OnStepEvents(p233, p234) -- name: OnStepEvents
	if p234.Jumped then
		p233.CharacterAnimator:noteJumpEvent()
	end
	if p234.Landed then
		local v235 = p234.ImpactVelocityY
		local v236 = typeof(v235) ~= "number" and 0 or p234.ImpactVelocityY
		local v237 = p233.Landed
		local v238 = -v236
		v237:Fire(math.max(0, v238), p233.MovementState.DuckAmount)
	end
end
function v_u_22.OnReconciled(p239, p240) -- name: OnReconciled
	-- upvalues: (copy) v_u_14
	if v_u_14.isHardSnapCorrection(p240) then
		p239.SnapNextPresentation = true
		p239.PreservePredictionPresentation = false
		p239.PendingPredictionPositionDelta = Vector3.new(0, 0, 0)
		p239.PredictionErrorOffset = Vector3.new(0, 0, 0)
		p239.PredictionErrorElapsedSeconds = 0
		p239.StepSmoothRootY = nil
		p239.StepCameraOffsetY = 0
	else
		local v241 = p240.PresentationPositionDelta
		if typeof(v241) == "Vector3" and p240.PresentationPositionDelta.Magnitude > v_u_14.Epsilon then
			p239.PendingPredictionPositionDelta = p239.PendingPredictionPositionDelta + p240.PresentationPositionDelta
			p239.PreservePredictionPresentation = true
		end
	end
end
function v_u_22.OnPlayerContactCorrection(p242, p243, p244) -- name: OnPlayerContactCorrection
	-- upvalues: (copy) v_u_26
	if v_u_26 < p243 then
		p242.PreservePredictionPresentation = true
		p242.PendingPredictionPositionDelta = p242.PendingPredictionPositionDelta + p244
	end
end
function v_u_22.Destroy(p245) -- name: Destroy
	if not p245.IsDestroyed then
		p245.IsDestroyed = true
		p245.Janitor:Destroy()
	end
end
return v_u_22
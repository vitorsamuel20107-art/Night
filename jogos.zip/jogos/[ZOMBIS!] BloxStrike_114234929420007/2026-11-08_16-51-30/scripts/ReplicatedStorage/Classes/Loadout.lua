-- NIGHT Analyzer | ReplicatedStorage.Classes.Loadout
-- ModuleScript | 168 linhas | 4965 bytes | hash d9d12189

local v_u_1 = {}
v_u_1.__index = v_u_1
local v2 = game:GetService("ReplicatedStorage")
local v3 = game:GetService("Players")
require(v2.Database.Custom.Types)
require(script:WaitForChild("Types"))
local v_u_4 = require(v2.Controllers.RunServiceController)
local v_u_5 = v3.LocalPlayer
local v_u_6 = require(v2.Components.Common.GetWeaponProperties)
local v_u_7 = require(v2.Database.Custom.GameStats.NumberSlots)
local v8 = require(v2.Components.Grenade)
local v9 = require(v2.Components.Weapon)
local v10 = require(v2.Components.Melee)
local v11 = require(v2.Components.C4)
local v_u_12 = require(v2.Components.Common.CharacterResolver)
local v_u_13 = require(v2.Shared.Janitor)
local v_u_14 = {
	["Grenade"] = v8,
	["Weapon"] = v9,
	["Melee"] = v10,
	["C4"] = v11
}
function v_u_1.setCurrentEquipped(p15, p16) -- name: setCurrentEquipped
	p15.PreviousEquipped = p15.CurrentEquipped
	p15.CurrentEquipped = p16
end
function v_u_1.getNextInventorySlotFromPriority(p17) -- name: getNextInventorySlotFromPriority
	-- upvalues: (copy) v_u_7
	local v18 = -1
	local v19 = nil
	for v20, v21 in ipairs(p17.Inventory) do
		local v22 = v_u_7.Priorities[v20] or 0
		if #v21._items < 1 or v18 >= v22 then
			continue
		end
		v19 = v20
		v18 = v22
	end
	return v19
end
function v_u_1.getInventoryItemFromLoadout(p23, p24) -- name: getInventoryItemFromLoadout
	local v25 = nil
	local v26 = nil
	local v27 = nil
	for v28, v29 in ipairs(p23.Inventory) do
		for v30, v31 in ipairs(v29._items) do
			if v31.Identifier ~= p24 then
				continue
			end
			v27 = v30
			v26 = v28
			v25 = v31
		end
	end
	return v25, v26, v27
end
function v_u_1.removeInventoryItem(p32, p33) -- name: removeInventoryItem
	local v34, v35, v36 = p32:getInventoryItemFromLoadout(p33)
	local v37
	if v34 then
		v37 = p32.Inventory[v35]
	else
		v37 = v34
	end
	if v37 then
		table.remove(v37._items, v36)
		if p32.CurrentEquipped == v34 then
			p32:setCurrentEquipped(nil)
		end
		v34:destroy()
	end
end
function v_u_1.grantPlayerInventoryItem(p38, p39, p40, p41, p42, p43, p44, p45, p46, p47, p48, p49, p50) -- name: grantPlayerInventoryItem
	-- upvalues: (copy) v_u_6, (copy) v_u_14, (copy) v_u_5
	local v51 = p38.Inventory[p39]
	local v52 = ("%* does not exist in player inventory"):format(p39)
	assert(v51, v52)
	local v53 = v_u_6(p42)
	local v54 = ("Client couldn\'t find weapon properties for \"%*\""):format(p42)
	assert(v53, v54)
	local v55 = v_u_14[v53.Class]
	local v56 = ("Client couldn\'t find weapon component for \"%*\""):format(p42)
	assert(v55, v56)
	debug.profilebegin("Loadout.grantPlayerInventoryItem")
	debug.profilebegin("Loadout.grantPlayerInventoryItem.Component.new")
	local v57 = v55.new
	local v58 = v_u_5
	local v59, v_u_60 = pcall(v57, v58, p40, p41, p39, p42, p43, p44, p45, p46, p47, p48, p49, p50)
	debug.profileend()
	if not v59 then
		debug.profileend()
		error(v_u_60, 2)
	end
	debug.profilebegin("Loadout.grantPlayerInventoryItem.InsertAndCleanup")
	local v61 = v51._items
	table.insert(v61, v_u_60)
	p38.Janitor:Add(function()
		-- upvalues: (copy) v_u_60
		if v_u_60 then
			local v62 = v_u_60
			if getmetatable(v62) and not v_u_60.IsDestroyed then
				v_u_60:destroy()
			end
		end
	end)
	debug.profileend()
	debug.profileend()
end
function v_u_1.new(p63) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_13, (copy) v_u_4, (copy) v_u_12, (copy) v_u_5
	debug.profilebegin("Loadout.new")
	local v64 = v_u_1
	local v_u_65 = setmetatable({}, v64)
	v_u_65.Janitor = v_u_13.new()
	v_u_65.IsDestroyed = false
	v_u_65.Inventory = p63
	v_u_65.Janitor:Add(v_u_4.BindToRenderStep("Classes.Loadout.RenderEquippedViewmodel", function(p66)
		-- upvalues: (copy) v_u_65, (ref) v_u_12, (ref) v_u_5
		if v_u_65.IsDestroyed then
			return
		else
			local v67 = v_u_12.getPlayerCharacter(v_u_5)
			if not (v67 and v67:GetAttribute("Dead")) then
				if v_u_65.CurrentEquipped and v_u_65.CurrentEquipped.Viewmodel.IsEquipped then
					debug.profilebegin("Loadout.RenderEquippedViewmodel")
					v_u_65.CurrentEquipped.Viewmodel:render(p66)
					debug.profileend()
				end
			end
		end
	end))
	debug.profileend()
	return v_u_65
end
function v_u_1.destroy(p68) -- name: destroy
	if not p68.IsDestroyed then
		debug.profilebegin("Loadout.destroy")
		p68.IsDestroyed = true
		if p68.CurrentEquipped then
			if p68.CurrentEquipped.unequip then
				p68.CurrentEquipped:unequip()
			end
			if p68.CurrentEquipped.destroy and not p68.CurrentEquipped.IsDestroyed then
				p68.CurrentEquipped:destroy()
			end
			p68.CurrentEquipped = nil
		end
		if p68.PreviousEquipped then
			if p68.PreviousEquipped.destroy and not p68.PreviousEquipped.IsDestroyed then
				p68.PreviousEquipped:destroy()
			end
			p68.PreviousEquipped = nil
		end
		if p68.Inventory then
			for _, v69 in ipairs(p68.Inventory) do
				if not v69._items then
					continue
				end
				table.clear(v69._items)
			end
		end
		p68.Janitor:Destroy()
		p68.Janitor = nil
		p68.Inventory = nil
		debug.profileend()
	end
end
return v_u_1
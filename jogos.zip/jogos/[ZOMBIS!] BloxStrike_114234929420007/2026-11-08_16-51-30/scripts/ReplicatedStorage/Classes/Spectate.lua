-- NIGHT Analyzer | ReplicatedStorage.Classes.Spectate
-- ModuleScript | 1008 linhas | 33246 bytes | hash 7eeac273

local v_u_1 = {}
v_u_1.__index = v_u_1
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("HttpService")
local v4 = game:GetService("Players")
require(script:WaitForChild("Types"))
local v_u_5 = v4.LocalPlayer
local v_u_6 = require(v_u_2.Controllers.CameraController)
local v_u_7 = require(v_u_2.Controllers.DataController)
local v_u_8 = require(v_u_2.Components.Common.CharacterResolver)
local v_u_9 = require(v_u_2.Components.Common.Participants)
local v_u_10 = require(v_u_2.Components.Common.CharacterGeneration)
local v_u_11 = require(v_u_2.Components.Common.GetWeaponCameraKick)
local v_u_12 = require(v_u_2.Database.Custom.Constants)
local v_u_13 = require(v_u_2.Database.Components.Common.RemoveFromArray)
local v_u_14 = require(v_u_2.Components.Common.VFXLibary.CreateMuzzleFlash.Camera)
local v_u_15 = require(v_u_2.Components.Common.VFXLibary.CreateZeusBeam)
local v_u_16 = require(v_u_2.Components.Common.VFXLibary.CreateTracer)
local v_u_17 = require(v_u_2.Classes.WeaponComponent)
local v_u_18 = require(v_u_2.Classes.Freecam)
local v_u_19 = require(v_u_2.Classes.Ragdoll)
local v_u_20 = require(v_u_2.Components.Weapon.Classes.Bullet)
local v_u_21 = require(v_u_2.Shared.Janitor)
local v_u_22 = require(v_u_2.Packages.Signal)
local v_u_23 = require(v_u_2.Shared.Spring)
local v_u_24 = require(v_u_2.Database.Security.Remotes)
local v_u_25 = workspace:WaitForChild("Debris")
local v_u_26 = workspace.CurrentCamera
local v_u_27 = RaycastParams.new()
v_u_27.FilterType = Enum.RaycastFilterType.Exclude
v_u_27.IgnoreWater = true
local v_u_28 = {
	["Heavy Swing"] = true,
	["BackStab"] = true,
	["Swing1"] = true,
	["Swing2"] = true,
	["Inspect"] = true,
	["Reload"] = true,
	["Throw"] = true,
	["Use"] = true
}
local v_u_29 = {
	["NoSuppressorShoot"] = true,
	["ShootRight"] = true,
	["ShootLeft"] = true,
	["Shoot"] = true,
	["SlamFire"] = true
}
local v_u_30 = { 37, 60 }
local v_u_31 = {
	["Right Arm"] = true,
	["Left Arm"] = true,
	["HumanoidRootPart"] = true,
	["ViewmodelLight"] = true
}
local function v_u_35(p32, p33) -- name: getTransparencyState
	local v34 = p32.Transparencies[p33]
	if not v34 then
		v34 = {
			["Transparency"] = p33.Transparency,
			["Textures"] = {}
		}
		p32.Transparencies[p33] = v34
	end
	return v34
end
local function v_u_44(p36, p37) -- name: cacheAndHideInstance
	-- upvalues: (copy) v_u_35
	if p37:IsA("BasePart") then
		local v38 = v_u_35(p36, p37)
		for _, v39 in p37:GetChildren() do
			if not v39:IsA("Texture") or table.find(v38.Textures, v39) then
				continue
			end
			local v40 = v38.Textures
			table.insert(v40, v39)
			v39.Parent = nil
		end
		if p37.Transparency < 1 then
			p37.Transparency = 1
			return
		end
	elseif p37:IsA("Texture") then
		local v41 = p37.Parent
		if v41 and v41:IsA("BasePart") then
			local v42 = v_u_35(p36, v41)
			if not table.find(v42.Textures, p37) then
				local v43 = v42.Textures
				table.insert(v43, p37)
			end
			p37.Parent = nil
			return
		end
	elseif p37:IsA("BillboardGui") then
		p37.Enabled = false
	end
end
local function v_u_50(p45) -- name: syncSpectatedRechargeAfterShot
	if p45 and (p45.Properties and p45.Properties.RechargeTime) then
		local v46 = p45.Properties.Rounds
		local v47 = tonumber(v46) or 0
		local v48 = p45.Rounds
		local v49 = (tonumber(v48) or v47) - 1
		p45.Rounds = math.max(v49, 0)
		p45.RechargeStartTime = workspace:GetServerTimeNow()
	end
end
local function v_u_62(p51) -- name: recreateSpectatedShotEffects
	-- upvalues: (copy) v_u_26, (copy) v_u_25, (copy) v_u_27, (copy) v_u_16, (copy) v_u_15, (copy) v_u_7, (copy) v_u_5, (copy) v_u_14
	local v52 = { p51.Character, v_u_26, v_u_25 }
	local v53 = workspace:FindFirstChild("Map")
	local v54
	if v53 then
		v54 = v53:FindFirstChild("Barriers")
	else
		v54 = nil
	end
	if v54 then
		table.insert(v52, v54)
	end
	v_u_27.FilterDescendantsInstances = v52
	local v55 = p51.WeaponComponent
	local v56
	if v55 then
		v56 = v55.Bullet
	else
		v56 = v55
	end
	if v56 and v56._updateShotSpread then
		v56:_updateShotSpread(v55.Properties.AimingOptions, v55.IsAiming)
	end
	local v57 = workspace:Raycast(v_u_26.CFrame.Position, v_u_26.CFrame.LookVector * p51.WeaponComponent.Properties.Range, v_u_27)
	local v58 = v57 and v57.Distance or p51.WeaponComponent.Properties.Range
	local v59 = p51.WeaponComponent.Viewmodel.Model.Interactables:FindFirstChild("MuzzlePart")
	if v59 then
		v_u_16(v58, v59.Position, v_u_26.CFrame.LookVector)
		if p51.WeaponComponent.Properties.MuzzleType == "Zeus x27" then
			v_u_15(v59)
		end
		if v_u_7.Get(v_u_5, "Settings.Video.Presets.Muzzle Flash") ~= false then
			local v60 = p51.WeaponComponent.Properties
			local v61 = v60.HasSuppressor
			if v61 then
				v61 = p51.CurrentEquipped.IsSuppressed
			end
			v_u_14(v59, v61 and "Suppressor" or v60.MuzzleType)
		end
	end
end
local function v_u_66(p63) -- name: destroySpectatedWeaponComponent
	if p63.WeaponComponent then
		local v64 = p63.WeaponComponent
		if v64.Bullet then
			v64.Bullet:destroy()
			v64.Bullet = nil
		end
		if v64.Janitor then
			v64.Janitor:Destroy()
		end
		p63.WeaponComponent = nil
	end
	for _, v65 in p63.ParkedWeapons do
		if v65.Bullet then
			v65.Bullet:destroy()
			v65.Bullet = nil
		end
		if not v65.Janitor then
			continue
		end
		v65.Janitor:Destroy()
	end
	table.clear(p63.ParkedWeapons)
	table.clear(p63.ParkedOrder)
end
local function v_u_76(p67) -- name: parkSpectatedWeaponComponent
	local v68 = p67.WeaponComponent
	p67.WeaponComponent = nil
	local v69 = v68.Viewmodel
	local v70 = v68.Identifier
	if v69 and (v70 and not p67.ParkedWeapons[v70]) then
		if v68 and (v68.Bullet and v68.Properties.ShootingOptions == "Revolver") then
			local v71 = v68.Properties.FireModes
			if v71 then
				v71 = v71.Secondary or v71.Primary
			end
			local v72 = v71 and v71.Spread or v68.Properties.Spread
			v68.Bullet:setSpreadConfig(v72)
		end
		v68.IsChargeFiring = false
		v68.ChargeStartTick = 0
		if v68.CharacterAnimator then
			v68.CharacterAnimator:destroy()
			v68.CharacterAnimator = nil
		end
		if v69.Bobble and v69.Bobble.IsAiming then
			v69:unaim()
		end
		v69:unequip()
		p67.ParkedWeapons[v70] = v68
		local v73 = p67.ParkedOrder
		table.insert(v73, v70)
		if #p67.ParkedOrder > 6 then
			local v74 = table.remove(p67.ParkedOrder, 1)
			local v75 = p67.ParkedWeapons[v74]
			if v75.Bullet then
				v75.Bullet:destroy()
				v75.Bullet = nil
			end
			if v75.Janitor then
				v75.Janitor:Destroy()
			end
			p67.ParkedWeapons[v74] = nil
		end
	else
		if v68.Bullet then
			v68.Bullet:destroy()
			v68.Bullet = nil
		end
		if v68.Janitor then
			v68.Janitor:Destroy()
		end
	end
end
function v_u_1.UpdateCameraCFrame(p77, p78) -- name: UpdateCameraCFrame
	-- upvalues: (copy) v_u_23
	if p77.CameraPositionSpring and p77.CameraRotationSpring then
		if (p78.Position - p77.CameraPositionSpring:getPosition()).Magnitude > 8 then
			p77.CameraRotationSpring:reset(p78.LookVector)
			p77.CameraPositionSpring:reset(p78.Position)
		end
	else
		p77.CameraRotationSpring = v_u_23.new(1, 35, p78.LookVector)
		p77.CameraPositionSpring = v_u_23.new(1, 35, p78.Position)
	end
	p77.CameraRotationSpring:setGoal(p78.LookVector)
	p77.CameraPositionSpring:setGoal(p78.Position)
end
function v_u_1.UpdateSuppressorState(p79, p80) -- name: UpdateSuppressorState
	local v81 = p80.Viewmodel.Model:FindFirstChild("Silencer", true)
	if v81 and p80.Properties.HasSuppressor then
		v81.Transparency = p79.CurrentEquipped.IsSuppressed and 0 or 1
	end
end
function v_u_1.UpdateSuppressor(p82) -- name: UpdateSuppressor
	if p82.WeaponComponent and p82.WeaponComponent.Viewmodel then
		local v_u_83 = p82.WeaponComponent.Viewmodel.Model:FindFirstChild("Silencer", true)
		if v_u_83 then
			local v84 = p82.WeaponComponent.Viewmodel.Animation
			local v85 = v84:getAnimation("RemoveSuppressor")
			local v_u_86 = v84:getAnimation("AddSuppressor")
			local v87 = p82.WeaponComponent.Janitor
			if v87 then
				v87:Add(v85:GetMarkerReachedSignal("ScrewOnEnd"):Connect(function()
					-- upvalues: (copy) v_u_83
					v_u_83.Transparency = 1
				end))
				local v_u_88 = false
				v87:Add(v85.Ended:Connect(function()
					-- upvalues: (copy) v_u_88, (copy) v_u_83
					if v_u_88 == (v_u_83.Transparency < 1) then
						v_u_83.Transparency = v_u_88 and 0 or 1
					end
				end))
				v87:Add(v_u_86:GetPropertyChangedSignal("IsPlaying"):Connect(function()
					-- upvalues: (copy) v_u_86, (copy) v_u_83
					if v_u_86.IsPlaying then
						task.delay(0.016666666666666666, function()
							-- upvalues: (ref) v_u_83
							v_u_83.Transparency = 0
						end)
					end
				end))
				local v_u_89 = true
				v87:Add(v_u_86.Ended:Connect(function()
					-- upvalues: (copy) v_u_89, (copy) v_u_83
					if v_u_89 == (v_u_83.Transparency < 1) then
						v_u_83.Transparency = v_u_89 and 0 or 1
					end
				end))
			end
			p82:UpdateSuppressorState(p82.WeaponComponent)
		end
	else
		return
	end
end
function v_u_1.Switch(p90, p91) -- name: Switch
	-- upvalues: (copy) v_u_8, (copy) v_u_26, (copy) v_u_6, (copy) v_u_66, (copy) v_u_12, (copy) v_u_18, (copy) v_u_24
	if v_u_8.isAliveCharacter(p90.Character) then
		p90.PendingPerspective = nil
		p90.PerspectiveState = p91
		if p90.FreecamInstance then
			p90.FreecamInstance:Stop()
			p90.FreecamInstance:Destroy()
			p90.FreecamInstance = nil
		end
		if p91 == "First-Person" then
			p90.TransparencyState = true
			p90:SetCharacterTransparency(true)
			v_u_26.CameraType = Enum.CameraType.Scriptable
			v_u_26.CameraSubject = p90.CameraPart
			if p90.CurrentEquipped then
				p90:SetEquipped(p90.CurrentEquipped, false)
			end
			p90:UpdateScopeState()
			v_u_6.setPerspective(true, false)
		elseif p91 == "Third-Person" or p91 == "Free-Cam" then
			p90.TransparencyState = false
			p90:SetCharacterTransparency(false)
			if p91 == "Third-Person" then
				v_u_26.CameraType = Enum.CameraType.Follow
				v_u_26.CameraSubject = p90.CameraPart
			end
			v_u_66(p90)
			v_u_6.updateCameraFOV(v_u_12.DEFAULT_CAMERA_FOV)
			if p91 == "Third-Person" then
				v_u_6.setPerspective(false, false, 8)
			else
				local v92 = p90.Janitor:Add(v_u_18.new())
				p90.FreecamInstance = v92
				v92:Start()
			end
		end
		v_u_24.Spectate.SetSpectatePerspective.Send(p90.PerspectiveState)
	elseif p90.Character.Parent ~= nil and not p90.Character:IsDescendantOf(workspace) then
		p90.PendingPerspective = p91
		v_u_26.CameraType = Enum.CameraType.Scriptable
	end
end
function v_u_1.SetEquipped(p_u_93, p94, p95) -- name: SetEquipped
	-- upvalues: (copy) v_u_76, (copy) v_u_17, (copy) v_u_9, (copy) v_u_20
	local v96 = p_u_93.WeaponComponent
	if v96 then
		v96 = p_u_93.WeaponComponent.Identifier
	end
	p_u_93.CurrentEquipped = p94
	if v96 == p94.Identifier then
		local v97 = p_u_93.WeaponComponent
		if v97 then
			v97.IsSuppressed = p94.IsSuppressed
			v97.Rounds = p94.Rounds
			v97.Capacity = p94.Capacity
			v97.RechargeStartTime = p94.RechargeStartTime
		end
		p_u_93:UpdateSuppressorState(p_u_93.WeaponComponent)
	else
		if p_u_93.WeaponComponent then
			p_u_93:SetWeaponViewmodelTransparency(false)
			v_u_76(p_u_93)
		end
		if p_u_93.PerspectiveState == "First-Person" then
			local v98 = p94.Identifier
			local v99 = p_u_93.ParkedWeapons[v98]
			if v99 then
				p_u_93.ParkedWeapons[v98] = nil
				table.remove(p_u_93.ParkedOrder, (table.find(p_u_93.ParkedOrder, v98)))
			end
			if v99 then
				if v99.StatTrack ~= p94.StatTrack then
					v99:updateStatTrackCounter(p94.StatTrack)
				end
				if v99 then
					v99.IsSuppressed = p94.IsSuppressed
					v99.Rounds = p94.Rounds
					v99.Capacity = p94.Capacity
					v99.RechargeStartTime = p94.RechargeStartTime
				end
				p_u_93.WeaponComponent = v99
				p_u_93.TransparencyState = true
				p_u_93:SetCharacterTransparency(true)
				v99.Viewmodel:equip(not p95)
				if v99.Properties.HasSuppressor then
					p_u_93:UpdateSuppressorState(v99)
				end
				p_u_93:UpdateScopeState()
				p_u_93.CurrentEquippedChanged:Fire(p_u_93.CurrentEquipped)
				return
			end
			local function v114()
				-- upvalues: (ref) v_u_17, (copy) p_u_93
				local v100 = v_u_17.new
				local v101 = p_u_93.Player
				local v102 = p_u_93.CurrentEquipped.Identifier
				local v103 = p_u_93.CurrentEquipped._id
				local v104 = 1
				local v105 = p_u_93.CurrentEquipped.Name
				local v106 = p_u_93.CurrentEquipped.Skin
				local v107 = p_u_93.CurrentEquipped.Float
				local v108 = p_u_93.CurrentEquipped.StatTrack
				local v109 = p_u_93.CurrentEquipped.NameTag
				local v110 = p_u_93.CurrentEquipped.OriginalOwner
				local v111 = p_u_93.CurrentEquipped.Charm
				local v112 = p_u_93.CurrentEquipped.Stickers
				local v113
				if p_u_93.IsBot then
					v113 = p_u_93.Character
				else
					v113 = nil
				end
				return v100(v101, v102, v103, v104, v105, v106, v107, v108, v109, v110, v111, v112, v113)
			end
			local v115, v116 = pcall(v114)
			if not (v115 and v116) then
				warn((("[Spectate] Failed to create viewmodel for %* (%* | %*): %*"):format(v_u_9.Name(p_u_93.Player), p_u_93.CurrentEquipped.Name, p_u_93.CurrentEquipped.Skin, (tostring(v116)))))
				p_u_93.TransparencyState = false
				if not pcall(function()
					-- upvalues: (copy) p_u_93
					p_u_93:SetCharacterTransparency(false)
				end) then
					warn("[Spectate] Failed to restore character transparency after viewmodel creation failure")
				end
				p_u_93:Switch("Third-Person")
				p_u_93.CurrentEquippedChanged:Fire(p_u_93.CurrentEquipped)
				return
			end
			if v116.Properties and v116.Properties.Spread then
				local v117 = v_u_20.new(v116, v116.Properties)
				v116.Bullet = v117
				if v116.Janitor then
					v116.Janitor:Add(v117, "destroy", "SpectateBullet")
				end
			end
			if v116 then
				v116.IsSuppressed = p94.IsSuppressed
				v116.Rounds = p94.Rounds
				v116.Capacity = p94.Capacity
				v116.RechargeStartTime = p94.RechargeStartTime
			end
			p_u_93.WeaponComponent = v116
			p_u_93.TransparencyState = true
			p_u_93:SetCharacterTransparency(true)
			local v118 = v116.Viewmodel
			if v118 then
				v118:equip(not p95)
				if v116.Properties.HasSuppressor then
					p_u_93:UpdateSuppressor()
				end
			end
			p_u_93:UpdateScopeState()
		end
		p_u_93.CurrentEquippedChanged:Fire(p_u_93.CurrentEquipped)
	end
end
function v_u_1.UpdateScopeState(p119) -- name: UpdateScopeState
	-- upvalues: (copy) v_u_6, (copy) v_u_12, (copy) v_u_30
	if p119.PerspectiveState == "First-Person" and p119.CurrentEquipped then
		local v120 = p119.CurrentEquipped.Name
		local v121 = v120 == "AWP" and true or v120 == "SSG 08"
		local v122 = v120 == "AUG" and true or v120 == "SG 553"
		local v123
		if p119.IsBot then
			v123 = p119.Character
		else
			v123 = p119.Player
		end
		local v124 = v123:GetAttribute("ScopeIncrement") or 0
		local v125 = v124 > 0
		local v126 = p119.WeaponComponent
		if v126 then
			v126 = p119.WeaponComponent.Viewmodel
		end
		if v121 then
			local v127 = v126 and v126.Bobble
			if v127 then
				v127 = v126.Bobble.ScopeReticlePart
			end
			if v127 then
				v127 = v127:FindFirstChildOfClass("SurfaceGui")
			end
			if v127 then
				v127.Enabled = false
			end
			if v125 then
				v125 = v124 <= 2
			end
			local v128 = v_u_6.updateCameraFOV
			local v129
			if v125 then
				v129 = v_u_12.DEFAULT_CAMERA_FOV - v_u_30[v124]
			else
				v129 = v_u_12.DEFAULT_CAMERA_FOV
			end
			v128(v129)
			p119:SetWeaponViewmodelTransparency(v125)
		elseif v122 then
			if v126 then
				if v125 then
					if not v126.Hidden then
						v126:hide()
					end
					if v126.Bobble and (v126.Bobble.Scope and v126.Bobble.ScopeReticlePart) then
						v126:aim()
					end
					v_u_6.updateCameraFOV(v_u_12.DEFAULT_CAMERA_FOV - 15)
				else
					if v126.Hidden then
						v126:unhide()
					end
					if v126.Bobble and (v126.Bobble.Scope and v126.Bobble.ScopeReticlePart) then
						v126:unaim()
					end
					v_u_6.updateCameraFOV(v_u_12.DEFAULT_CAMERA_FOV)
				end
			end
		else
			v_u_6.updateCameraFOV(v_u_12.DEFAULT_CAMERA_FOV)
			p119:SetWeaponViewmodelTransparency(false)
		end
	else
		return
	end
end
function v_u_1.SetWeaponViewmodelTransparency(p130, p131) -- name: SetWeaponViewmodelTransparency
	-- upvalues: (copy) v_u_31
	if p130.WeaponComponent and (p130.WeaponComponent.Viewmodel and p130.WeaponComponent.Viewmodel.Model) then
		local v132 = p130.WeaponComponent.Viewmodel.Model
		if not p130.WeaponTransparencyCache then
			p130.WeaponTransparencyCache = {}
		end
		for _, v133 in ipairs(v132:GetDescendants()) do
			if not v133:IsA("BasePart") or v_u_31[v133.Name] then
				continue
			end
			if p131 then
				if not p130.WeaponTransparencyCache[v133] then
					p130.WeaponTransparencyCache[v133] = v133.Transparency
				end
				v133.Transparency = 1
			else
				local v134 = p130.WeaponTransparencyCache[v133]
				if v134 == nil then
					continue
				end
				v133.Transparency = v134
				p130.WeaponTransparencyCache[v133] = nil
			end
		end
	end
end
function v_u_1.SetCharacterTransparency(p_u_135, p136) -- name: SetCharacterTransparency
	-- upvalues: (copy) v_u_21, (copy) v_u_44, (copy) v_u_13
	local v137 = p_u_135.Character:GetDescendants()
	if p136 then
		p_u_135.Character:SetAttribute("SpectatedFirstPerson", true)
		if not p_u_135.TransparencyJanitor then
			local v138 = p_u_135.Janitor:Add(v_u_21.new())
			p_u_135.TransparencyJanitor = v138
			v138:Add(p_u_135.Character.DescendantAdded:Connect(function(p139)
				-- upvalues: (copy) p_u_135, (ref) v_u_44
				if p_u_135.TransparencyState then
					v_u_44(p_u_135, p139)
				end
			end))
		end
		for _, v140 in ipairs(v137) do
			v_u_44(p_u_135, v140)
		end
	else
		if p_u_135.TransparencyJanitor then
			p_u_135.TransparencyJanitor:Destroy()
			p_u_135.TransparencyJanitor = nil
		end
		for v_u_141, v142 in pairs(p_u_135.Transparencies) do
			if not (v_u_141 and v_u_141.Parent) then
				continue
			end
			v_u_141.Transparency = v142.Transparency
			v_u_13(v142.Textures, function(_, p143)
				-- upvalues: (copy) v_u_141
				p143.Parent = v_u_141
				return true
			end)
		end
		for _, v144 in ipairs(v137) do
			if not v144:IsA("BillboardGui") then
				continue
			end
			v144.Enabled = true
		end
		p_u_135.Character:SetAttribute("SpectatedFirstPerson", nil)
	end
end
function v_u_1.AddSpectateEvent(p145, p146) -- name: AddSpectateEvent
	-- upvalues: (copy) v_u_62, (copy) v_u_29, (copy) v_u_11, (copy) v_u_50, (copy) v_u_28
	if p145.WeaponComponent and p145.WeaponComponent.Viewmodel then
		local v147 = p145.WeaponComponent.Viewmodel.Animation
		local v148 = p145.WeaponComponent
		if p146 == "RevolverChargeStart" then
			if v148 and (v148.Bullet and v148.Properties.ShootingOptions == "Revolver") then
				local v149 = v148.Properties.FireModes
				if v149 then
					v149 = v149.Primary
				end
				local v150 = v149 and v149.Spread or v148.Properties.Spread
				v148.Bullet:setSpreadConfig(v150)
			end
			v148.IsChargeFiring = true
			v148.ChargeStartTick = tick()
			v147:stopAnimations()
			v147:play("Shoot")
			v147:play("Idle")
			return
		elseif p146 == "RevolverChargeCancel" then
			if v148 and (v148.Bullet and v148.Properties.ShootingOptions == "Revolver") then
				local v151 = v148.Properties.FireModes
				if v151 then
					v151 = v151.Secondary or v151.Primary
				end
				local v152 = v151 and v151.Spread or v148.Properties.Spread
				v148.Bullet:setSpreadConfig(v152)
			end
			v148.IsChargeFiring = false
			v148.ChargeStartTick = 0
			v147:stopAnimations()
			v147:play("Idle")
			return
		elseif p146 == "RevolverChargeRelease" then
			if v148 and (v148.Bullet and v148.Properties.ShootingOptions == "Revolver") then
				local v153 = v148.Properties.FireModes
				if v153 then
					v153 = v153.Primary
				end
				local v154 = v153 and v153.Spread or v148.Properties.Spread
				v148.Bullet:setSpreadConfig(v154)
			end
			v_u_62(p145)
			if v148 and (v148.Bullet and v148.Properties.ShootingOptions == "Revolver") then
				local v155 = v148.Properties.FireModes
				if v155 then
					v155 = v155.Secondary or v155.Primary
				end
				local v156 = v155 and v155.Spread or v148.Properties.Spread
				v148.Bullet:setSpreadConfig(v156)
			end
			v148.IsChargeFiring = false
			v148.ChargeStartTick = 0
		elseif v_u_29[p146] then
			if p145.IsBot then
				local v157 = v148.Viewmodel.Model:FindFirstChild("CameraShake")
				if v157 then
					local v158, v159 = v_u_11(v157)
					p145.KickRotationSpring:setDampingRatio(v158.Damper)
					p145.KickRotationSpring:setFrequency(v158.Speed)
					p145.KickRotationSpring:setPosition(v158.Value * 0.017453292519943295)
					p145.KickPositionSpring:setDampingRatio(v159.Damper)
					p145.KickPositionSpring:setFrequency(v159.Speed)
					p145.KickPositionSpring:setPosition(v159.Value)
				end
				v148.Viewmodel.Bobble:addScopeKick()
			end
			if v148.Properties.ShootingOptions == "Revolver" then
				local v160 = p146 == "SlamFire" and "Secondary" or "Primary"
				if v148 and (v148.Bullet and v148.Properties.ShootingOptions == "Revolver") then
					local v161 = v148.Properties.FireModes
					if v161 then
						v161 = v160 == "Secondary" and v161.Secondary or v161.Primary
					end
					local v162 = v161 and v161.Spread or v148.Properties.Spread
					v148.Bullet:setSpreadConfig(v162)
				end
				if v160 == "Secondary" then
					if v148 and (v148.Bullet and v148.Properties.ShootingOptions == "Revolver") then
						local v163 = v148.Properties.FireModes
						if v163 then
							v163 = v163.Secondary or v163.Primary
						end
						local v164 = v163 and v163.Spread or v148.Properties.Spread
						v148.Bullet:setSpreadConfig(v164)
					end
					v148.IsChargeFiring = false
					v148.ChargeStartTick = 0
				else
					v148.IsChargeFiring = false
					v148.ChargeStartTick = 0
				end
			end
			v_u_50(v148)
			local v165 = not v147:getAnimation(p146) and "Shoot" or p146
			v147:stopAnimations()
			v147:play(v165)
			v147:play("Idle")
			v_u_62(p145)
			if v148.Properties.ShootingOptions == "Revolver" and p146 ~= "SlamFire" then
				if v148 and (v148.Bullet and v148.Properties.ShootingOptions == "Revolver") then
					local v166 = v148.Properties.FireModes
					if v166 then
						v166 = v166.Secondary or v166.Primary
					end
					local v167 = v166 and v166.Spread or v148.Properties.Spread
					v148.Bullet:setSpreadConfig(v167)
				end
				v148.IsChargeFiring = false
				v148.ChargeStartTick = 0
				return
			end
		else
			if p146 == "Remove Suppressor" or p146 == "Add Suppressor" then
				v147:stopAnimations()
				v147:play(string.gsub(p146, " ", ""))
				v147:play("Idle")
				return
			end
			if p146 == "Switch Fire Mode" then
				v147:stopAnimations()
				v147:play("Switch")
				v147:play("Idle")
				return
			end
			if p146 == "StartThrow" then
				v147:stopAnimations()
				v147:play("StartThrow")
				local v168 = v147:play("ThrowIdle")
				if v168 then
					v168.Looped = true
					return
				end
			else
				if p146 == "Cancel Plant" or p146 == "CancelThrow" then
					v147:stopAnimations()
					v147:play("Idle")
					return
				end
				if p146 == "ReloadStart" or p146 == "ReloadEnd" then
					if v147:getAnimation(p146) then
						v147:stopAnimations()
						v147:play(p146)
						v147:play("Idle")
						return
					end
				elseif v_u_28[p146] or (p146 == "Inspect" or string.match(p146, "^Inspect%d+$") ~= nil) then
					local v169 = (p146 == "Inspect" and true or string.match(p146, "^Inspect%d+$") ~= nil) and not v147:getAnimation(p146) and "Inspect" or p146
					local v170 = p146 == "Reload" and (not v147:getAnimation("Reload") and v147:getAnimation("ReloadAction")) and "ReloadAction" or v169
					v147:stopAnimations()
					v147:play(v170)
					v147:play("Idle")
				end
			end
		end
	else
		return
	end
end
local function v_u_183(p171, p172) -- name: updateSpectatorAutomaticScope
	if p171.PerspectiveState == "First-Person" and p171.CurrentEquipped then
		local v173 = p171.CurrentEquipped.Name
		if v173 == "AUG" or v173 == "SG 553" then
			local v174
			if p171.IsBot then
				v174 = p171.Character
			else
				v174 = p171.Player
			end
			if (v174:GetAttribute("ScopeIncrement") or 0) <= 0 then
				return
			else
				local v175 = p171.WeaponComponent
				local v176
				if v175 then
					v176 = v175.Viewmodel
				else
					v176 = v175
				end
				if v176 and (v176.Bobble and (v176.Bobble.IsAiming and v175.Bullet)) then
					local v177 = v175.Bullet:getBaseSpread() or 0
					local v178 = v177 - (p171.LastSpreadValue or 0)
					local v179 = math.abs(v178)
					local v180 = (p171.LastScopeUpdateTime or 0) + p172
					if v179 < 0.01 and v180 < 0.03333333333333333 then
						p171.LastScopeUpdateTime = v180
					else
						p171.LastScopeUpdateTime = 0
						p171.LastSpreadValue = v177
						local v181 = v176.Bobble.ScopeReticlePart
						if v181 then
							v181 = v181:FindFirstChildOfClass("SurfaceGui")
						end
						if v181 then
							v181 = v181:FindFirstChild("Frame")
						end
						if v181 then
							v181 = v181:FindFirstChild("Frame")
						end
						if v181 then
							local v182 = math.clamp(v177, 0, 2) * 2
							v181.Size = UDim2.fromScale(v182 + 2.5, v182 + 2.5)
							v181.Position = UDim2.fromScale(0.5, 0.5)
						end
					end
				else
					return
				end
			end
		else
			return
		end
	else
		return
	end
end
function v_u_1.Render(p184, p185, p186) -- name: Render
	-- upvalues: (copy) v_u_2, (copy) v_u_10, (copy) v_u_26, (copy) v_u_6, (copy) v_u_183
	if p184.PerspectiveState ~= "Free-Cam" then
		if not p186 and p184.IsBot then
			local v187 = require(v_u_2.Controllers.CharacterController.BotCharacters)
			local v188 = p184.Character:GetAttribute("ActorId")
			local v189 = v_u_10.Get(p184.Character)
			if type(v188) == "number" and v189 then
				p186 = v187.GetCamera(v188, v189)
			end
		end
		if not (p186 or (p184.IsBot or p184.HasRemoteCamera)) then
			p186 = require(v_u_2.Controllers.CharacterController.RemoteCharacters).GetCamera(p184.Player)
		end
		if p186 then
			p184:UpdateCameraCFrame(p186)
		end
		if p184.CameraPositionSpring and p184.CameraRotationSpring then
			p184.CameraPositionSpring:update(p185)
			p184.CameraRotationSpring:update(p185)
			if p184.PerspectiveState == "First-Person" then
				v_u_26.CFrame = CFrame.lookAt(p184.CameraPositionSpring:getPosition(), p184.CameraPositionSpring:getPosition() + p184.CameraRotationSpring:getPosition())
				if p186 then
					v_u_26.CFrame = p186
				end
				if p184.IsBot then
					p184.KickRotationSpring:update(p185)
					p184.KickPositionSpring:update(p185)
					local v190 = p184.KickRotationSpring:getPosition()
					local v191 = v_u_26
					v191.CFrame = v191.CFrame * (CFrame.new(p184.KickPositionSpring:getPosition()) * CFrame.Angles(v190.X, v190.Y, v190.Z))
					v_u_26.FieldOfView = v_u_6.getTargetFOV()
				end
				if p184.WeaponComponent and p184.WeaponComponent.Viewmodel then
					p184.WeaponComponent.Viewmodel:render(p185)
				end
				local v192 = p184.WeaponComponent
				if v192 and (v192.Bullet and v192.Bullet.updateSpread) then
					v192.Bullet:updateSpread(p185)
				end
				v_u_183(p184, p185)
			end
		end
	end
end
function v_u_1.new(p193, p194, p195, p196) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_8, (copy) v_u_9, (copy) v_u_21, (copy) v_u_22, (copy) v_u_23, (copy) v_u_26, (copy) v_u_2, (copy) v_u_5, (copy) v_u_3, (copy) v_u_24, (copy) v_u_19, (copy) v_u_6, (copy) v_u_12, (copy) v_u_66
	local v197 = v_u_1
	local v_u_198 = setmetatable({}, v197)
	local v199 = v_u_8.resolve(p194)
	local v200 = ("[Spectate] Invalid player character rig for %*"):format((v_u_9.Name(p193)))
	assert(v199, v200)
	local v201 = p195 or "First-Person"
	v_u_198.Janitor = v_u_21.new()
	v_u_198.CurrentEquippedChanged = v_u_198.Janitor:Add(v_u_22.new())
	v_u_198.StopSpectating = v_u_198.Janitor:Add(v_u_22.new())
	v_u_198.RootPart = v199.RootPart
	v_u_198.CameraPart = v199.CameraPart
	v_u_198.Character = p194
	v_u_198.Player = p193
	v_u_198.IsBot = p196 == true
	v_u_198.KickRotationSpring = v_u_23.new(1, 1, Vector3.new(0, 0, 0))
	v_u_198.KickPositionSpring = v_u_23.new(1, 1, Vector3.new(0, 0, 0))
	v_u_198.PerspectiveState = v201
	v_u_198.TransparencyState = v201 == "First-Person"
	v_u_198.Transparencies = {}
	v_u_198.WeaponTransparencyCache = {}
	v_u_198.ParkedWeapons = {}
	v_u_198.ParkedOrder = {}
	v_u_198.LastScopeUpdateTime = 0
	v_u_198.LastSpreadValue = 0
	v_u_198:SetCharacterTransparency(v_u_198.TransparencyState)
	v_u_198:Switch(v_u_198.PerspectiveState)
	if not v_u_198.IsBot and (v_u_198.PerspectiveState == "First-Person" and v_u_198.Character:IsDescendantOf(workspace)) then
		v_u_26.CFrame = require(v_u_2.Controllers.CharacterController.RemoteCharacters).GetCamera(v_u_198.Player) or v_u_198.CameraPart.CFrame
	end
	v_u_5.ReplicationFocus = v_u_198.RootPart
	v_u_198.Janitor:Add(function()
		-- upvalues: (ref) v_u_5
		v_u_5.ReplicationFocus = nil
	end)
	if v_u_198.Player:GetAttribute("CurrentEquipped") then
		v_u_198:SetEquipped(v_u_3:JSONDecode((v_u_198.Player:GetAttribute("CurrentEquipped"))), false)
	end
	v_u_198.Janitor:Add(v_u_198.Player:GetAttributeChangedSignal("CurrentEquipped"):Connect(function()
		-- upvalues: (copy) v_u_198, (ref) v_u_3
		local v202 = v_u_198.Player:GetAttribute("CurrentEquipped")
		if v202 then
			v_u_198:SetEquipped(v_u_3:JSONDecode(v202), true)
			task.defer(function()
				-- upvalues: (ref) v_u_198
				if v_u_198.TransparencyState and v_u_198.PerspectiveState == "First-Person" then
					v_u_198:SetCharacterTransparency(true)
				end
			end)
		end
	end))
	if v_u_198.IsBot then
		local v203 = require(v_u_2.Controllers.CharacterController.BotCharacters)
		v_u_198.Janitor:Add(v203.CombatEvent:Connect(function(p204)
			-- upvalues: (copy) v_u_198
			if p204.ActorId == v_u_198.Character:GetAttribute("ActorId") then
				v_u_198:AddSpectateEvent(p204.Kind == "Shoot" and "Shoot" or p204.Kind)
			end
		end))
		v_u_198.Janitor:Add(v_u_198.Player:GetAttributeChangedSignal("ObjectiveAction"):Connect(function()
			-- upvalues: (copy) v_u_198
			v_u_198:AddSpectateEvent(v_u_198.Player:GetAttribute("ObjectiveAction") == "Planting" and "Use" or "Cancel Plant")
		end))
	else
		v_u_198.Janitor:Add(v_u_24.Spectate.UpdateCameraCFrame.Listen(function(p205)
			-- upvalues: (copy) v_u_198
			if p205.UserId == v_u_198.Player.UserId then
				v_u_198.HasRemoteCamera = true
				v_u_198:UpdateCameraCFrame(p205.CameraCFrame)
			end
		end))
		if v_u_198.Player:GetAttribute("ScopeIncrement") then
			v_u_198:UpdateScopeState()
		end
		v_u_198.Janitor:Add(v_u_198.Player:GetAttributeChangedSignal("ScopeIncrement"):Connect(function()
			-- upvalues: (copy) v_u_198
			v_u_198:UpdateScopeState()
		end))
	end
	local function v206() -- name: stopSpectating
		-- upvalues: (copy) v_u_198
		v_u_198.StopSpectating:Fire()
	end
	if v_u_8.getHealth(v_u_198.Character) <= 0 then
		task.defer(v206)
	end
	v_u_198.Janitor:Add(v_u_198.Character:GetAttributeChangedSignal("Health"):Connect(function()
		-- upvalues: (ref) v_u_8, (copy) v_u_198
		if v_u_8.getHealth(v_u_198.Character) <= 0 then
			v_u_198.StopSpectating:Fire()
		end
	end))
	if v_u_198.Character:GetAttribute("Dead") then
		task.defer(v206)
	end
	v_u_198.Janitor:Add(v_u_198.Character:GetAttributeChangedSignal("Dead"):Connect(function()
		-- upvalues: (copy) v_u_198
		if v_u_198.Character:GetAttribute("Dead") then
			v_u_198.StopSpectating:Fire()
		end
	end))
	v_u_198.Janitor:Add(v_u_24.UI.UIPlayerKilled.Listen(function(p207)
		-- upvalues: (ref) v_u_9, (copy) v_u_198
		local v208 = p207.Victim
		if v208 then
			local v209 = v_u_9.Key
			local v210 = v_u_198.Player
			if tostring(v209(v210)) == v208 then
				v_u_198.StopSpectating:Fire()
			end
		end
	end))
	v_u_198.Janitor:Add(v_u_198.Character.AncestryChanged:Connect(function(_, p211)
		-- upvalues: (copy) v_u_198, (ref) v_u_26, (ref) v_u_2
		if p211 then
			local v212 = v_u_198.PendingPerspective
			if v212 and v_u_198.Character:IsDescendantOf(workspace) then
				v_u_198:Switch(v212)
				if v212 == "First-Person" and not (v_u_198.IsBot or v_u_198.CameraPositionSpring) then
					local v213 = v_u_198
					v_u_26.CFrame = require(v_u_2.Controllers.CharacterController.RemoteCharacters).GetCamera(v213.Player) or v213.CameraPart.CFrame
				end
			end
		else
			v_u_198.StopSpectating:Fire()
		end
	end))
	v_u_198.Janitor:Add(function()
		-- upvalues: (copy) v_u_198, (ref) v_u_8, (ref) v_u_19, (ref) v_u_6, (ref) v_u_12
		v_u_198.TransparencyState = false
		if v_u_198.Character:GetAttribute("Dead") ~= false and true or v_u_8.getHealth(v_u_198.Character) <= 0 then
			v_u_19.HideCharacterLocally(v_u_198.Character)
			v_u_198.Character:SetAttribute("SpectatedFirstPerson", nil)
		elseif next(v_u_198.Transparencies) ~= nil then
			v_u_198:SetCharacterTransparency(false)
		end
		v_u_6.updateCameraFOV(v_u_12.DEFAULT_CAMERA_FOV)
	end)
	v_u_198.Janitor:Add(function()
		-- upvalues: (ref) v_u_66, (copy) v_u_198
		v_u_66(v_u_198)
	end)
	v_u_198.Janitor:Add(function()
		-- upvalues: (copy) v_u_198
		local v214 = v_u_198
		if v214.FreecamInstance then
			v214.FreecamInstance:Stop()
			v214.FreecamInstance:Destroy()
			v214.FreecamInstance = nil
		end
	end)
	return v_u_198
end
function v_u_1.newBot(p215, p216, p217) -- name: newBot
	-- upvalues: (copy) v_u_1
	local v218 = p216:GetAttribute("Bot") == true
	assert(v218, "Expected a bot presentation")
	return v_u_1.new(p215, p216, p217, true)
end
function v_u_1.Destroy(p219) -- name: Destroy
	p219.Janitor:Destroy()
end
return v_u_1
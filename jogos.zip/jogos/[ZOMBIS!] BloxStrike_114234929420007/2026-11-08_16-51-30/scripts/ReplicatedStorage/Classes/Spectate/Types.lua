-- NIGHT Analyzer | ReplicatedStorage.Classes.Spectate.Types
-- ModuleScript | 7 linhas | 209 bytes | hash ad86a5ef

local v1 = game:GetService("ReplicatedStorage")
require(v1.Database.Custom.Types)
require(v1.Classes.WeaponComponent)
require(v1.Classes.Freecam)
require(v1.Packages.Signal)
require(v1.Shared.Spring)
return {}
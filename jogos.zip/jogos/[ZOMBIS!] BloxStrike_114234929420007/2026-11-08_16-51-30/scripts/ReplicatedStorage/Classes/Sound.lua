-- NIGHT Analyzer | ReplicatedStorage.Classes.Sound
-- ModuleScript | 580 linhas | 15784 bytes | hash 256136ff

local v_u_1 = {}
v_u_1.__index = v_u_1
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("ContentProvider")
local v_u_4 = game:GetService("SoundService")
local v_u_5 = game:GetService("HttpService")
local v_u_6 = game:GetService("Players").LocalPlayer
local v_u_7 = require(v2:WaitForChild("Controllers"):WaitForChild("DataController"))
require(script:WaitForChild("Types"))
local v_u_8 = require(v2.Shared.Janitor)
local v9 = require(v2.Shared.ObjectPool)
local v_u_10 = v2:FindFirstChild("Sounds") or Instance.new("Folder", v2)
v_u_10.Name = "Sounds"
local v_u_11 = workspace:WaitForChild("Debris")
local v_u_12 = {
	["Interface"] = true,
	["Main Menu"] = true,
	["Store"] = true,
	["ArmsDealer"] = true
}
local v_u_13 = v_u_4:FindFirstChild("Gameplay")
if not v_u_13 then
	v_u_13 = Instance.new("SoundGroup")
	v_u_13.Name = "Gameplay"
	v_u_13.Parent = v_u_4
end
local v14 = Instance.new("Part")
v14.Size = Vector3.new(1, 1, 1)
v14.CanCollide = false
v14.CanTouch = false
v14.CanQuery = false
v14.CastShadow = false
v14.Anchored = true
v14.Transparency = 1
v14.Name = "Sound"
local v_u_16 = v9.new(v14, {
	["InitialSize"] = 8,
	["MaxRetained"] = 32,
	["Reset"] = nil,
	["Reset"] = function(p15) -- name: Reset
		p15.CFrame = CFrame.identity
	end
})
local v_u_17 = {}
local v_u_18 = {}
local v_u_19 = {}
local v_u_20 = {}
local v_u_21 = {}
local v_u_22 = 1
local v_u_23 = nil
local v_u_24 = nil
local v_u_25 = {}
local v_u_26 = {}
local function v_u_34(p27) -- name: TranslateSoundPath
	local v28 = string.split(p27, ".")
	local v29 = game
	for v30 = 2, #v28 do
		local v_u_31 = v28[v30]
		if v29 == game then
			local v32, v33 = pcall(function()
				-- upvalues: (copy) v_u_31
				return game:GetService(v_u_31)
			end)
			v29 = v32 and v33 and v33 or game:FindFirstChild(v_u_31)
		else
			v29 = v29:FindFirstChild(v_u_31)
		end
		if v29 then
			continue
		end
		error((("Path: \"%*\" does not exist"):format(p27)))
	end
	return v29
end
local function v_u_41(p35, p36, p37) -- name: CreateSoundInstance
	local v38 = Instance.new("Sound")
	v38.RollOffMaxDistance = p37.RollOffMaxDistance or 10000
	v38.RollOffMinDistance = p37.RollOffMinDistance or 10
	v38.TimePosition = p37.TimePosition or 0
	v38.RollOffMode = p37.RollOffMode or Enum.RollOffMode.Inverse
	v38.Looped = p37.Looped or false
	v38.SoundId = ("rbxassetid://%*"):format(p36)
	v38.Volume = p37.Volume or 0.5
	v38.Name = p35
	local v39 = p37.Pitch
	if typeof(v39) == "number" and v39 ~= 1 then
		local v40 = Instance.new("PitchShiftSoundEffect")
		v40.Name = "PitchShift"
		v40.Octave = math.clamp(v39, 0.5, 2)
		v40.Parent = v38
	end
	if p37.Persistent then
		v38:SetAttribute("Persistent", true)
	end
	if p37.WarmOnUse then
		v38:SetAttribute("WarmOnUse", true)
	end
	return v38
end
local function v_u_52(p_u_42, p43, p44) -- name: TrackMasterVolume
	-- upvalues: (ref) v_u_23, (ref) v_u_22, (copy) v_u_7, (copy) v_u_6, (copy) v_u_17
	local v45 = p44 or 1
	local v46 = {
		["BaseVolume"] = p43,
		["OtherMultiplier"] = v45
	}
	if not v_u_23 then
		local v47 = v_u_7.Get(v_u_6, "Settings.Audio.Audio.Master Volume") or 100
		v_u_22 = (tonumber(v47) or 100) / 100
		v_u_23 = v_u_7.CreateListener(v_u_6, "Settings.Audio.Audio.Master Volume", function(p48)
			-- upvalues: (ref) v_u_22, (ref) v_u_17
			v_u_22 = (tonumber(p48) or 100) / 100
			for v49, v50 in pairs(v_u_17) do
				if v49.Parent then
					v49.Volume = v50.BaseVolume * v_u_22 * v50.OtherMultiplier
					v49:SetAttribute("MasterVolumeMultiplier", v_u_22)
				else
					v_u_17[v49] = nil
				end
			end
		end)
	end
	local v51 = v_u_17[p_u_42] == nil
	v_u_17[p_u_42] = v46
	p_u_42:SetAttribute("BaseVolume", p43)
	p_u_42:SetAttribute("OtherVolumeMultiplier", v45)
	p_u_42.Volume = v46.BaseVolume * v_u_22 * v46.OtherMultiplier
	p_u_42:SetAttribute("MasterVolumeMultiplier", v_u_22)
	if v51 then
		p_u_42.Destroying:Once(function()
			-- upvalues: (ref) v_u_17, (copy) p_u_42
			v_u_17[p_u_42] = nil
		end)
	end
end
local function v_u_57(p53) -- name: IsVoiceable
	-- upvalues: (copy) v_u_20, (copy) v_u_21
	local v54 = v_u_20[p53]
	if v54 ~= nil then
		return v54
	end
	local v55 = not p53.Looped
	for _, v56 in p53:GetChildren() do
		if v56:IsA("PitchShiftSoundEffect") and not v_u_21[p53] then
			v_u_21[p53] = v56
		else
			v55 = false
		end
	end
	v_u_20[p53] = v55
	return v55
end
local function v_u_61() -- name: NewPositionalVoice
	-- upvalues: (copy) v_u_19, (copy) v_u_18
	local v58 = Instance.new("Attachment")
	v58.Name = "SoundVoice"
	local v59 = Instance.new("Sound")
	v59.Parent = v58
	v58.Parent = workspace.Terrain
	local v_u_60 = {
		["Attachment"] = nil,
		["Sound"] = nil,
		["PitchShift"] = nil,
		["Volume"] = nil,
		["Busy"] = true,
		["Attachment"] = v58,
		["Sound"] = v59,
		["Volume"] = {
			["BaseVolume"] = 0,
			["OtherMultiplier"] = 1
		}
	}
	v59.Ended:Connect(function()
		-- upvalues: (copy) v_u_60, (ref) v_u_19
		if v_u_60.Busy then
			v_u_60.Busy = false
			v_u_19[#v_u_19 + 1] = v_u_60
		end
	end)
	v_u_18[#v_u_18 + 1] = v_u_60
	return v_u_60
end
local function v_u_67() -- name: AcquirePositionalVoice
	-- upvalues: (copy) v_u_19, (copy) v_u_18, (copy) v_u_61
	local v62 = table.remove(v_u_19)
	while v62 do
		local v63
		if v62.Attachment.Parent == nil then
			v63 = false
		else
			v63 = v62.Sound.Parent == v62.Attachment
		end
		if v63 then
			v62.Busy = true
			return v62
		end
		local v64 = table.find(v_u_18, v62)
		if v64 then
			table.remove(v_u_18, v64)
		end
		v62 = table.remove(v_u_19)
	end
	if #v_u_18 < 96 then
		return v_u_61()
	end
	for _, v65 in v_u_18 do
		if v65.Sound.Playing then
			continue
		end
		local v66
		if v65.Attachment.Parent == nil then
			v66 = false
		else
			v66 = v65.Sound.Parent == v65.Attachment
		end
		if not v66 then
			continue
		end
		v65.Busy = true
		return v65
	end
	return nil
end
local function v_u_82(p68, p69, p70, p71, p72) -- name: PlayOnPositionalVoice
	-- upvalues: (copy) v_u_57, (copy) v_u_67, (copy) v_u_21, (ref) v_u_23, (ref) v_u_22, (copy) v_u_7, (copy) v_u_6, (copy) v_u_17
	if not v_u_57(p68) then
		return false
	end
	local v73 = v_u_67()
	if not v73 then
		return false
	end
	local v74 = v73.Sound
	v73.Attachment.WorldPosition = p69
	if v74.SoundId ~= p68.SoundId then
		v74.SoundId = p68.SoundId
	end
	if p72 then
		v74.RollOffMode = Enum.RollOffMode.InverseTapered
		v74.RollOffMaxDistance = 10000
		v74.RollOffMinDistance = 10000
	else
		v74.RollOffMode = p68.RollOffMode
		v74.RollOffMaxDistance = p68.RollOffMaxDistance
		v74.RollOffMinDistance = p68.RollOffMinDistance
	end
	v74.SoundGroup = p68.SoundGroup
	v74.PlaybackSpeed = p68.PlaybackSpeed
	local v75 = v_u_21[p68]
	if v75 then
		local v76 = v73.PitchShift
		if not v76 then
			v76 = Instance.new("PitchShiftSoundEffect")
			v76.Parent = v73.Sound
			v73.PitchShift = v76
		end
		v76.Octave = v75.Octave
		v76.Enabled = true
	elseif v73.PitchShift then
		v73.PitchShift.Enabled = false
	end
	v74.TimePosition = p68.TimePosition
	if not v_u_23 then
		local v77 = v_u_7.Get(v_u_6, "Settings.Audio.Audio.Master Volume") or 100
		v_u_22 = (tonumber(v77) or 100) / 100
		v_u_23 = v_u_7.CreateListener(v_u_6, "Settings.Audio.Audio.Master Volume", function(p78)
			-- upvalues: (ref) v_u_22, (ref) v_u_17
			v_u_22 = (tonumber(p78) or 100) / 100
			for v79, v80 in pairs(v_u_17) do
				if v79.Parent then
					v79.Volume = v80.BaseVolume * v_u_22 * v80.OtherMultiplier
					v79:SetAttribute("MasterVolumeMultiplier", v_u_22)
				else
					v_u_17[v79] = nil
				end
			end
		end)
	end
	local v81 = v73.Volume
	v81.BaseVolume = p70
	v81.OtherMultiplier = p71 or 1
	v_u_17[v74] = v81
	v74.Volume = p70 * v_u_22 * v81.OtherMultiplier
	v74:Play()
	return true
end
function v_u_1.play(p83, p84, p85) -- name: play
	-- upvalues: (copy) v_u_5, (copy) v_u_34, (copy) v_u_25, (copy) v_u_26, (ref) v_u_24, (copy) v_u_4, (copy) v_u_52
	local v86 = p84.Parent or p84.Path
	local v87 = ("Sound couldn\'t locate sound parent for %*"):format(p84.Name)
	assert(v86, v87)
	if not p83.Sounds then
		return nil
	end
	local v88 = p83.Sounds:FindFirstChild(p84.Name)
	if v88 then
		local v89 = v_u_5:GenerateGUID(false)
		local v90 = p84.Parent
		if p84.Path and not v90 then
			v90 = v_u_34(p84.Path)
		end
		if not v90 then
			return nil
		end
		local v91 = v88:GetChildren()
		local v92 = v91[math.random(1, #v91)]
		if v92:GetAttribute("Persistent") == true then
			local v_u_93 = v_u_25[v92]
			if not (v_u_93 and v_u_93:IsDescendantOf(game)) then
				if v_u_93 then
					v_u_26[v_u_93] = nil
				end
				v_u_93 = v92:Clone()
				local v94
				if v_u_24 and v_u_24.Parent then
					v94 = v_u_24
				else
					v94 = v_u_4:FindFirstChild("PersistentSounds")
					if not v94 then
						v94 = Instance.new("Folder")
						v94.Name = "PersistentSounds"
						v94.Parent = v_u_4
					end
					v_u_24 = v94
				end
				v_u_93.Parent = v94
				v_u_25[v92] = v_u_93
			end
			if not v_u_93.IsPlaying then
				local v_u_95 = (v_u_26[v_u_93] or 0) + 1
				v_u_26[v_u_93] = v_u_95
				v_u_93.Parent = v90
				v_u_93.TimePosition = 0
				v_u_52(v_u_93, v92.Volume, p85)
				v_u_93:Play()
				v_u_93.Ended:Once(function()
					-- upvalues: (ref) v_u_26, (copy) v_u_93, (copy) v_u_95, (ref) v_u_24, (ref) v_u_4
					if v_u_26[v_u_93] == v_u_95 then
						local v96 = v_u_93
						local v97
						if v_u_24 and v_u_24.Parent then
							v97 = v_u_24
						else
							v97 = v_u_4:FindFirstChild("PersistentSounds")
							if not v97 then
								v97 = Instance.new("Folder")
								v97.Name = "PersistentSounds"
								v97.Parent = v_u_4
							end
							v_u_24 = v97
						end
						v96.Parent = v97
					end
				end)
				return v_u_93
			end
		end
		local v_u_98 = v92:Clone()
		v_u_98.Parent = v90
		v_u_98.Name = v89
		v_u_52(v_u_98, v_u_98.Volume, p85)
		v_u_98:Play()
		v_u_98.Ended:Once(function()
			-- upvalues: (copy) v_u_98
			v_u_98:Destroy()
		end)
		return v_u_98
	end
end
function v_u_1.playOn(p99, p100, p101, p102) -- name: playOn
	-- upvalues: (copy) v_u_52
	local v103 = p99.Sounds
	if v103 then
		v103 = p99.Sounds:FindFirstChild(p101)
	end
	if not v103 or #v103:GetChildren() == 0 then
		return false
	end
	local v104 = v103:GetChildren()
	local v105 = v104[math.random(1, #v104)]
	if p100.SoundId ~= v105.SoundId then
		p100.SoundId = v105.SoundId
	end
	p100.RollOffMode = v105.RollOffMode
	p100.RollOffMinDistance = v105.RollOffMinDistance
	p100.RollOffMaxDistance = v105.RollOffMaxDistance
	p100.SoundGroup = v105.SoundGroup
	p100.Looped = false
	p100.TimePosition = 0
	v_u_52(p100, v105.Volume, p102)
	p100:Play()
	return true
end
function v_u_1.playOneTime(p106, p107, p108) -- name: playOneTime
	return p106:play(p107, p108)
end
function v_u_1.PlaySoundAtPosition(p_u_109, p110, p111, p112, p113, p114) -- name: PlaySoundAtPosition
	-- upvalues: (copy) v_u_82, (copy) v_u_16, (copy) v_u_11, (copy) v_u_5, (copy) v_u_52
	if p_u_109.IsDestroyed then
		return
	else
		local v115 = p_u_109.Sounds
		if v115 then
			v115 = p_u_109.Sounds:FindFirstChild(p110.Name)
		end
		if v115 then
			local v116 = v115:GetChildren()
			local v117 = v116[math.random(1, #v116)]
			local v118 = p110.Name == "Headshot" and true or p110.Name == "Helmet Headshot"
			if v118 then
				v118 = p113 == true
			end
			local v119 = v_u_82
			local v120 = p110.Position
			local v121
			if v118 and p114 then
				v121 = v117.Volume * 0
			else
				v121 = v117.Volume
			end
			if not v119(v117, v120, v121, p112, v118) then
				local v_u_122, v_u_123 = v_u_16:Acquire()
				p_u_109.Janitor:Add(function()
					-- upvalues: (ref) v_u_16, (copy) v_u_122, (copy) v_u_123
					v_u_16:Release(v_u_122, v_u_123)
				end)
				v_u_122.Position = p110.Position
				v_u_122.CollisionGroup = "Debris"
				v_u_122.Parent = v_u_11
				local v_u_124 = p_u_109.Janitor:Add(v117:Clone())
				local v125 = v_u_124.Volume
				v_u_124.Name = v_u_5:GenerateGUID(false)
				v_u_124.Parent = v_u_122
				if v118 then
					v_u_124.RollOffMode = Enum.RollOffMode.InverseTapered
					v_u_124.RollOffMaxDistance = 10000
					v_u_124.RollOffMinDistance = 10000
					if p114 then
						v125 = v125 * 0
					end
				end
				v_u_52(v_u_124, v125, p112)
				v_u_124:Play()
				if v_u_124.Looped and p111 then
					p_u_109.Janitor:Add(task.delay(p111, function()
						-- upvalues: (copy) p_u_109
						p_u_109:destroy()
					end), true)
				else
					p_u_109.Janitor:Add(v_u_124.Ended:Once(function()
						-- upvalues: (copy) p_u_109
						p_u_109:destroy()
					end))
				end
				p_u_109.Janitor:Add(v_u_124.AncestryChanged:Connect(function()
					-- upvalues: (copy) v_u_124, (copy) p_u_109
					if not v_u_124.Parent then
						p_u_109:destroy()
					end
				end))
			end
		else
			p_u_109:destroy()
			return
		end
	end
end
v_u_1.GameplaySoundGroup = v_u_13
local function v_u_131(p_u_126) -- name: WarmPersistentTemplate
	-- upvalues: (copy) v_u_25, (copy) v_u_26, (ref) v_u_24, (copy) v_u_4, (copy) v_u_3
	local v_u_127 = v_u_25[p_u_126]
	if not (v_u_127 and v_u_127:IsDescendantOf(game)) then
		if v_u_127 then
			v_u_26[v_u_127] = nil
		end
		v_u_127 = p_u_126:Clone()
		local v128
		if v_u_24 and v_u_24.Parent then
			v128 = v_u_24
		else
			v128 = v_u_4:FindFirstChild("PersistentSounds")
			if not v128 then
				v128 = Instance.new("Folder")
				v128.Name = "PersistentSounds"
				v128.Parent = v_u_4
			end
			v_u_24 = v128
		end
		v_u_127.Parent = v128
		v_u_25[p_u_126] = v_u_127
	end
	local v_u_129 = (v_u_26[v_u_127] or 0) + 1
	v_u_26[v_u_127] = v_u_129
	local function v130()
		-- upvalues: (ref) v_u_3, (copy) v_u_127
		v_u_3:PreloadAsync({ v_u_127 })
	end
	pcall(v130)
	if v_u_26[v_u_127] == v_u_129 and not v_u_127.IsPlaying then
		v_u_127.Volume = 0
		v_u_127:Play()
		task.delay(0.5, function()
			-- upvalues: (ref) v_u_26, (copy) v_u_127, (copy) v_u_129, (copy) p_u_126
			if v_u_26[v_u_127] == v_u_129 then
				v_u_127:Stop()
				v_u_127.TimePosition = 0
				v_u_127.Volume = p_u_126.Volume
			end
		end)
	end
end
function v_u_1.WarmPersistentSounds() -- name: WarmPersistentSounds
	-- upvalues: (ref) v_u_10, (copy) v_u_131
	for _, v132 in v_u_10:GetDescendants() do
		if not v132:IsA("Sound") or (v132:GetAttribute("Persistent") ~= true or v132:GetAttribute("WarmOnUse") == true) then
			continue
		end
		v_u_131(v132)
	end
end
function v_u_1.WarmPersistentSound(p133, p134) -- name: WarmPersistentSound
	-- upvalues: (ref) v_u_10, (copy) v_u_131
	local v135 = v_u_10:WaitForChild(p133):FindFirstChild(p134)
	if v135 then
		for _, v136 in v135:GetChildren() do
			if not v136:IsA("Sound") or v136:GetAttribute("Persistent") ~= true then
				continue
			end
			v_u_131(v136)
		end
	end
end
function v_u_1.createSoundGroup(p137) -- name: createSoundGroup
	-- upvalues: (ref) v_u_10, (copy) v_u_12, (ref) v_u_13, (copy) v_u_41
	local v138 = require(p137)
	local v139 = Instance.new("Folder", v_u_10)
	v139.Name = p137.Name
	local v140
	if v_u_12[p137.Name] then
		v140 = nil
	else
		v140 = v_u_13
	end
	for v141, v142 in pairs(v138) do
		if typeof(v142) ~= "table" then
			continue
		end
		local v143 = v142.Identifiers
		if typeof(v143) ~= "table" then
			continue
		end
		local v144 = Instance.new("Folder", v139)
		v144.Name = v141
		for v145, v146 in ipairs(v142.Identifiers) do
			local v147 = v_u_41(v145, v146, v142.Properties)
			v147.SoundGroup = v140
			v147.Parent = v144
		end
	end
end
function v_u_1.new(p148) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_8, (ref) v_u_10
	local v149 = v_u_1
	local v150 = setmetatable({}, v149)
	v150.Janitor = v_u_8.new()
	v150.IsDestroyed = false
	v150.SoundGroupName = p148
	v150.Sounds = v_u_10:WaitForChild(p148, 10)
	return v150
end
function v_u_1.destroy(p151) -- name: destroy
	if not p151.IsDestroyed then
		p151.IsDestroyed = true
		p151.Janitor:Destroy()
		p151.SoundGroupName = nil
		p151.Janitor = nil
		p151.Sounds = nil
	end
end
return v_u_1
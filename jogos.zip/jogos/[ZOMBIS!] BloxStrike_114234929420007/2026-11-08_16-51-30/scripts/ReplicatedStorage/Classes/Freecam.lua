-- NIGHT Analyzer | ReplicatedStorage.Classes.Freecam
-- ModuleScript | 414 linhas | 13184 bytes | hash e744a10e

local v_u_1 = {}
v_u_1.__index = v_u_1
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("GuiService")
local v5 = game:GetService("Players")
require(script:WaitForChild("Types"))
local v_u_6 = v5.LocalPlayer
local v_u_7 = require(v2.Controllers.CameraController)
local v_u_8 = require(v2.Controllers.InputController)
local v_u_9 = require(v2.Controllers.RunServiceController)
local v_u_10 = require(v2.Shared.Janitor)
local v_u_11 = workspace.CurrentCamera
local v_u_12 = Vector2.new(9.42477796076938, 5.497787143782138)
local v_u_13 = Vector2.new(4.71238898038469, 2.748893571891069)
local v_u_14 = Vector2.new(0.4, 0.3333333333333333)
local v_u_15 = Vector2.new(3.839724354387525, 2.6179938779914944)
local function v_u_29(p16, p17) -- name: ResolveTouchMoveVector
	-- upvalues: (copy) v_u_11
	local v18 = v_u_11.ViewportSize
	local v19 = v18.X
	local v20 = v18.Y
	local v21 = math.min(v19, v20) > 500 and 2 or 1
	local v22 = Vector2.new(p17.X - p16.X, p17.Y - p16.Y)
	local v23 = v22.Magnitude
	if v23 < v21 * 2 then
		return Vector3.new(0, 0, 0)
	end
	local v24 = v22.Unit
	local v25 = v23 / (v21 * 20)
	local v26 = v24 * math.min(v25, 1)
	local v27 = v26.X
	local v28 = v26.Y
	return Vector3.new(v27, 0, v28)
end
function v_u_1.UpdateMovement(p30, p31) -- name: UpdateMovement
	-- upvalues: (copy) v_u_8, (copy) v_u_4
	local v32 = Vector3.new(0, 0, 0)
	if v_u_8.isActionActive("Move Forward") then
		v32 = v32 + Vector3.new(0, 0, -1)
	end
	if v_u_8.isActionActive("Move Backward") then
		v32 = v32 + Vector3.new(0, 0, 1)
	end
	if v_u_8.isActionActive("Move Left (Strafe)") then
		v32 = v32 + Vector3.new(-1, 0, 0)
	end
	if v_u_8.isActionActive("Move Right (Strafe)") then
		v32 = v32 + Vector3.new(1, 0, 0)
	end
	local v33 = 40 * (v_u_8.isActionActive("Walk") and 0.2 or 1)
	if v32 ~= Vector3.new(0, 0, 0) then
		v32 = v32.Unit
	end
	local v34 = v32 + p30.TouchMoveVector
	if v_u_4.SelectedObject == nil and not v_u_4.MenuIsOpen then
		local v35 = p30.GamepadMove
		local v36 = v35.Magnitude
		local v37
		if v36 <= 0.15 then
			v37 = Vector2.zero
		else
			local v38 = v35.Unit
			local v39 = (v36 - 0.15) / 0.85
			v37 = v38 * math.min(v39, 1)
		end
		local v40 = v37.X
		local v41 = p30.GamepadRise - p30.GamepadFall
		local v42 = -v37.Y
		v34 = v34 + Vector3.new(v40, v41, v42)
	end
	if v34.Magnitude > 1 then
		v34 = v34.Unit
	end
	local v43 = p30.CameraCFrame
	local v44 = v43.LookVector
	local v45 = v43.RightVector * v34.X + Vector3.new(0, 1, 0) * v34.Y + v44 * -v34.Z
	local v46 = p30.CameraCFrame.Position + v45 * (v33 * p31)
	p30.CameraCFrame = CFrame.new(v46, v46 + v44)
	p30:UpdateMouseWheel(p31)
end
function v_u_1.UpdateMouseWheel(p47, _) -- name: UpdateMouseWheel
	-- upvalues: (copy) v_u_8
	local v48 = p47.MouseWheelDelta
	if v48 ~= 0 then
		local v49 = p47.CameraCFrame
		local v50 = v49.LookVector
		local v51 = 15 * (v_u_8.isActionActive("Walk") and 0.5 or 1)
		local v52 = v50 * (v48 > 0 and v51 and v51 or -v51)
		local v53 = v49.Position + v52
		p47.CameraCFrame = CFrame.new(v53, v53 + v50)
		p47.MouseWheelDelta = 0
	end
end
function v_u_1.UpdateRotation(p54, p55) -- name: UpdateRotation
	-- upvalues: (copy) v_u_3, (copy) v_u_8, (copy) v_u_11, (copy) v_u_12, (copy) v_u_13, (copy) v_u_4, (copy) v_u_15
	local v56
	if p54.MoveTouch ~= nil and true or p54.LookTouch ~= nil then
		v56 = Vector2.zero
	else
		v56 = v_u_3:GetMouseDelta()
	end
	local v57 = v_u_8.isActionActive("Walk") and 0.5 or 1
	local v58 = v_u_11.ViewportSize
	local v59 = v56.X / v58.X * (v_u_12.X * v57)
	local v60 = v56.Y / v58.Y * (v_u_12.Y * v57)
	local v61 = p54.TouchLookDelta
	if v61 ~= Vector2.zero then
		p54.TouchLookDelta = Vector2.zero
		v59 = v59 + v61.X / v58.X * (v_u_13.X * v57)
		v60 = v60 + v61.Y / v58.Y * (v_u_13.Y * v57)
	end
	local v62
	if v_u_4.SelectedObject ~= nil and true or v_u_4.MenuIsOpen then
		v62 = Vector2.zero
	else
		local v63 = p54.GamepadLook
		local v64 = v63.Magnitude
		if v64 <= 0.15 then
			v62 = Vector2.zero
		else
			local v65 = v63.Unit
			local v66 = (v64 - 0.15) / 0.85
			v62 = v65 * math.min(v66, 1)
		end
	end
	if v62 ~= Vector2.zero then
		local v67 = v62.Unit * v62.Magnitude ^ 2
		v59 = v59 + v67.X * v_u_15.X * v57 * p55
		v60 = v60 - v67.Y * v_u_15.Y * v57 * p55
	end
	local v68 = p54.CameraCFrame
	local v69 = v68.Position
	local v70 = v68.LookVector
	local v71 = v70.Y
	local v72 = math.asin(v71) - v60
	local v73 = math.clamp(v72, -1.3962634015954636, 1.3962634015954636)
	local v74 = v70.X
	local v75 = v70.Z
	local v76 = Vector3.new(v74, 0, v75)
	local v77 = v76.Magnitude
	local v78 = v77 < 0.001 and Vector3.new(0, 0, -1) or v76 / v77
	local v79 = -v78.X
	local v80 = -v78.Z
	local v81 = math.atan2(v79, v80) - v59
	local v82 = math.cos(v73)
	local v83 = -math.sin(v81) * v82
	local v84 = math.sin(v73)
	local v85 = -math.cos(v81) * v82
	local v86 = Vector3.new(v83, v84, v85)
	p54.CameraCFrame = CFrame.new(v69, v69 + v86)
end
function v_u_1.ReleaseEndedTouches(p87) -- name: ReleaseEndedTouches
	local v88 = p87.MoveTouch
	if v88 and v88.UserInputState == Enum.UserInputState.End then
		p87.MoveTouch = nil
		p87.TouchMoveVector = Vector3.new(0, 0, 0)
	end
	local v89 = p87.LookTouch
	if v89 and v89.UserInputState == Enum.UserInputState.End then
		p87.LookTouch = nil
	end
end
function v_u_1.ResetTouchInput(p90) -- name: ResetTouchInput
	p90.TouchLookDelta = Vector2.zero
	p90.TouchMoveVector = Vector3.new(0, 0, 0)
	p90.MoveTouch = nil
	p90.MoveTouchStartPosition = Vector3.new(0, 0, 0)
	p90.LookTouch = nil
end
function v_u_1.ResetGamepadInput(p91) -- name: ResetGamepadInput
	p91.GamepadMove = Vector2.zero
	p91.GamepadLook = Vector2.zero
	p91.GamepadRise = 0
	p91.GamepadFall = 0
end
function v_u_1.ShowTouchControls(p_u_92) -- name: ShowTouchControls
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_4
	local v_u_93
	if v_u_3.TouchEnabled then
		local v94 = v_u_6:FindFirstChildOfClass("PlayerGui")
		if v94 then
			v_u_93 = v94:FindFirstChild("TouchGui")
		else
			v_u_93 = nil
		end
	else
		v_u_93 = nil
	end
	if v_u_93 then
		local function v97() -- name: applyVisibility
			-- upvalues: (copy) v_u_93, (copy) p_u_92, (ref) v_u_4
			local v95 = v_u_93
			local v96 = p_u_92.IsActive
			if v96 then
				v96 = v_u_4.TouchControlsEnabled
			end
			v95.Enabled = v96
		end
		local v98 = p_u_92.IsActive
		if v98 then
			v98 = v_u_4.TouchControlsEnabled
		end
		v_u_93.Enabled = v98
		p_u_92.Janitor:Add(v_u_93:GetPropertyChangedSignal("Enabled"):Connect(v97), "Disconnect", "TouchControlsEnabledGuard")
		p_u_92.Janitor:Add(v_u_4:GetPropertyChangedSignal("TouchControlsEnabled"):Connect(v97), "Disconnect", "TouchControlsSettingGuard")
		p_u_92.Janitor:Add(function()
			-- upvalues: (copy) v_u_93, (ref) v_u_6, (ref) v_u_4
			local v99 = v_u_93
			local v100
			if v_u_6.Character == nil then
				v100 = false
			else
				v100 = v_u_4.TouchControlsEnabled
			end
			v99.Enabled = v100
		end, true, "RestoreTouchControls")
	end
end
function v_u_1.Render(p101, p102) -- name: Render
	-- upvalues: (copy) v_u_11
	p101:ReleaseEndedTouches()
	p101:UpdateMovement(p102)
	p101:UpdateRotation(p102)
	v_u_11.CFrame = p101.CameraCFrame
end
function v_u_1.Start(p_u_103) -- name: Start
	-- upvalues: (copy) v_u_11, (copy) v_u_7, (copy) v_u_3, (copy) v_u_9, (copy) v_u_6
	if not p_u_103.IsActive then
		p_u_103.IsActive = true
		p_u_103.CameraCFrame = v_u_11.CFrame
		p_u_103.MouseWheelDelta = 0
		p_u_103:ResetTouchInput()
		p_u_103:ResetGamepadInput()
		p_u_103:ShowTouchControls()
		v_u_11.CameraType = Enum.CameraType.Scriptable
		v_u_7.setMouseEnabled(false)
		p_u_103.Janitor:Add(v_u_3:GetPropertyChangedSignal("MouseBehavior"):Connect(function()
			-- upvalues: (copy) p_u_103, (ref) v_u_3
			if p_u_103.IsActive and v_u_3.MouseBehavior ~= Enum.MouseBehavior.LockCenter then
				v_u_3.MouseBehavior = Enum.MouseBehavior.LockCenter
			end
		end), "Disconnect", "EnforceMouseBehavior")
		v_u_9.BindToRenderStep("Freecam", Enum.RenderPriority.Camera.Value + 10, function(p104)
			-- upvalues: (copy) p_u_103
			if p_u_103.IsActive then
				p_u_103:Render(p104)
			end
		end)
		local v105 = workspace:FindFirstChild("Map")
		if v105 then
			v105 = v105:FindFirstChild("ReplicationFocus")
		end
		if v105 then
			v105 = v105:FindFirstChild("Focus")
		end
		if v105 then
			v_u_6.ReplicationFocus = v105
			p_u_103.Janitor:Add(function()
				-- upvalues: (ref) v_u_6
				v_u_6.ReplicationFocus = nil
			end, true, "ReplicationFocus")
		end
		p_u_103.Janitor:Add(function()
			-- upvalues: (ref) v_u_9
			v_u_9.UnbindFromRenderStep("Freecam")
		end, true)
	end
end
function v_u_1.Stop(p106) -- name: Stop
	-- upvalues: (copy) v_u_9, (copy) v_u_11
	if p106.IsActive then
		p106.IsActive = false
		v_u_9.UnbindFromRenderStep("Freecam")
		p106:ResetTouchInput()
		p106:ResetGamepadInput()
		local v107 = p106.Janitor
		if v107:Get("TouchControlsEnabledGuard") then
			v107:Remove("TouchControlsEnabledGuard")
		end
		local v108 = p106.Janitor
		if v108:Get("TouchControlsSettingGuard") then
			v108:Remove("TouchControlsSettingGuard")
		end
		local v109 = p106.Janitor
		if v109:Get("RestoreTouchControls") then
			v109:Remove("RestoreTouchControls")
		end
		v_u_11.CameraType = Enum.CameraType.Custom
		local v110 = p106.Janitor
		if v110:Get("EnforceMouseBehavior") then
			v110:Remove("EnforceMouseBehavior")
		end
		local v111 = p106.Janitor
		if v111:Get("ReplicationFocus") then
			v111:Remove("ReplicationFocus")
		end
	end
end
function v_u_1.new() -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_10, (copy) v_u_3, (copy) v_u_11, (copy) v_u_14, (copy) v_u_29
	local v112 = v_u_1
	local v_u_113 = setmetatable({}, v112)
	v_u_113.Janitor = v_u_10.new()
	v_u_113.CameraCFrame = CFrame.identity
	v_u_113.MouseWheelDelta = 0
	v_u_113.TouchLookDelta = Vector2.zero
	v_u_113.TouchMoveVector = Vector3.new(0, 0, 0)
	v_u_113.MoveTouchStartPosition = Vector3.new(0, 0, 0)
	v_u_113.GamepadMove = Vector2.zero
	v_u_113.GamepadLook = Vector2.zero
	v_u_113.GamepadRise = 0
	v_u_113.GamepadFall = 0
	v_u_113.IsActive = false
	v_u_113.Janitor:Add(v_u_3.InputBegan:Connect(function(p114, p115)
		-- upvalues: (copy) v_u_113, (ref) v_u_11, (ref) v_u_14
		if v_u_113.IsActive and (p114.UserInputType == Enum.UserInputType.Touch and not p115) then
			if not v_u_113.MoveTouch then
				local v116 = p114.Position
				local v117 = v_u_11.ViewportSize
				local v118
				if v117.X < v117.Y then
					v118 = v116.Y >= v117.Y * 0.6
				elseif v116.X <= v117.X * v_u_14.X then
					v118 = v116.Y >= v117.Y * v_u_14.Y
				else
					v118 = false
				end
				if v118 then
					v_u_113.MoveTouch = p114
					v_u_113.MoveTouchStartPosition = p114.Position
					v_u_113.TouchMoveVector = Vector3.new(0, 0, 0)
					return
				end
			end
			if not v_u_113.LookTouch then
				v_u_113.LookTouch = p114
			end
		end
	end), "Disconnect")
	v_u_113.Janitor:Add(v_u_3.InputChanged:Connect(function(p119, p120)
		-- upvalues: (copy) v_u_113, (ref) v_u_29
		if v_u_113.IsActive then
			local v121 = p119.UserInputType.Name
			if string.sub(v121, 1, 7) == "Gamepad" then
				local v122 = p119.KeyCode
				if v122 == Enum.KeyCode.Thumbstick1 then
					v_u_113.GamepadMove = Vector2.new(p119.Position.X, p119.Position.Y)
					return
				elseif v122 == Enum.KeyCode.Thumbstick2 then
					v_u_113.GamepadLook = Vector2.new(p119.Position.X, p119.Position.Y)
					return
				elseif v122 == Enum.KeyCode.ButtonR2 then
					v_u_113.GamepadRise = p119.Position.Z
				elseif v122 == Enum.KeyCode.ButtonL2 then
					v_u_113.GamepadFall = p119.Position.Z
				end
			elseif p119.UserInputType == Enum.UserInputType.MouseWheel then
				if not p120 then
					v_u_113.MouseWheelDelta = p119.Position.Z
				end
				return
			elseif p119.UserInputType == Enum.UserInputType.Touch then
				if p119 == v_u_113.MoveTouch then
					v_u_113.TouchMoveVector = v_u_29(v_u_113.MoveTouchStartPosition, p119.Position)
				elseif p119 == v_u_113.LookTouch then
					v_u_113.TouchLookDelta = v_u_113.TouchLookDelta + Vector2.new(p119.Delta.X, p119.Delta.Y)
				end
			else
				return
			end
		else
			return
		end
	end), "Disconnect")
	v_u_113.Janitor:Add(v_u_3.InputEnded:Connect(function(p123)
		-- upvalues: (copy) v_u_113
		local v124 = p123.UserInputType.Name
		if string.sub(v124, 1, 7) == "Gamepad" then
			local v125 = p123.KeyCode
			if v125 == Enum.KeyCode.Thumbstick1 then
				v_u_113.GamepadMove = Vector2.zero
				return
			elseif v125 == Enum.KeyCode.Thumbstick2 then
				v_u_113.GamepadLook = Vector2.zero
				return
			elseif v125 == Enum.KeyCode.ButtonR2 then
				v_u_113.GamepadRise = 0
			elseif v125 == Enum.KeyCode.ButtonL2 then
				v_u_113.GamepadFall = 0
			end
		elseif p123.UserInputType == Enum.UserInputType.Touch then
			if p123 == v_u_113.MoveTouch then
				v_u_113.MoveTouch = nil
				v_u_113.TouchMoveVector = Vector3.new(0, 0, 0)
			elseif p123 == v_u_113.LookTouch then
				v_u_113.LookTouch = nil
			end
		else
			return
		end
	end), "Disconnect")
	v_u_113.Janitor:Add(function()
		-- upvalues: (copy) v_u_113
		if v_u_113.IsActive then
			v_u_113:Stop()
		end
	end)
	return v_u_113
end
function v_u_1.Destroy(p126) -- name: Destroy
	p126.Janitor:Destroy()
end
return v_u_1
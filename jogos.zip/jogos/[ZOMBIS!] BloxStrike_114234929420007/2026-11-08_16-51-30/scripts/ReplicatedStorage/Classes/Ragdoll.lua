-- NIGHT Analyzer | ReplicatedStorage.Classes.Ragdoll
-- ModuleScript | 1312 linhas | 37403 bytes | hash f482a86d

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("CollectionService")
local v_u_4 = game:GetService("RunService")
require(script:WaitForChild("Types"))
local v_u_5 = require(script:WaitForChild("Rig"))
local v_u_6 = require(v1.Database.Components.GameState)
local v_u_7 = require(v1.Shared.Janitor)
local v_u_8 = require(v1.Packages.Signal)
local v_u_9 = require(v1.Components.Common.CharacterResolver)
local v_u_10 = {}
v_u_10.__index = v_u_10
local v_u_11 = workspace:WaitForChild("Debris")
local v12 = v_u_2.MaxPlayers * 2
local v_u_13 = math.clamp(v12, 4, 24)
local v_u_14 = CFrame.new(0, -100, 0)
local v_u_15 = {}
local v_u_16 = {}
local v_u_17 = {}
local v_u_18 = {}
local v_u_19 = {}
local v_u_20 = {}
local v_u_21 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_22 = {}
local v_u_23 = 1
local v_u_24 = false
local v_u_25 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_26 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_27 = {}
local v_u_28 = {}
local v_u_29 = {}
local v_u_30 = {}
local v_u_31 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_32 = {}
local v_u_33 = 0
local v_u_34 = 0
local v_u_35 = true
local v_u_36 = nil
local v_u_37 = {
	["AnimationController"] = true,
	["CharacterModel"] = true,
	["WeaponAttachments"] = true,
	["WeaponModel"] = true
}
local v_u_38 = {
	["RagdollReady"] = true,
	["RagdollStaged"] = true
}
local v_u_39 = {
	["Dead"] = true,
	["Ragdolled"] = true,
	["RagdollCreatedAt"] = true,
	["PreparedRagdoll"] = true,
	["ClientRagdoll"] = true
}
local function v_u_47(p40) -- name: runPreparationStage
	-- upvalues: (copy) v_u_22, (ref) v_u_24, (ref) v_u_23, (copy) v_u_4
	local v41 = {
		["Callback"] = nil,
		["Completed"] = false,
		["Succeeded"] = false,
		["Result"] = nil,
		["Callback"] = p40
	}
	local v42 = v_u_22
	table.insert(v42, v41)
	if not v_u_24 then
		v_u_24 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_23, (ref) v_u_22, (ref) v_u_4, (ref) v_u_24
			while v_u_23 <= #v_u_22 do
				v_u_4.Heartbeat:Wait()
				local v43 = v_u_22[v_u_23]
				v_u_23 = v_u_23 + 1
				local v44 = v43.Callback
				local v45, v46 = pcall(v44)
				v43.Succeeded = v45
				v43.Result = v46
				v43.Completed = true
			end
			table.clear(v_u_22)
			v_u_23 = 1
			v_u_24 = false
		end)
	end
	while not v41.Completed do
		v_u_4.Heartbeat:Wait()
	end
	if not v41.Succeeded then
		error(v41.Result, 0)
	end
	return v41.Result
end
local function v_u_49(p48) -- name: isVisualEffect
	return p48:IsA("ParticleEmitter") or p48:IsA("Trail") or (p48:IsA("Beam") or p48:IsA("Fire") or (p48:IsA("Smoke") or p48:IsA("Sparkles")))
end
local function v_u_51(p50) -- name: isExcludedRagdollContent
	-- upvalues: (copy) v_u_37
	return v_u_37[p50.Name] == true or p50:IsA("AnimationController") or (p50:IsA("Script") or p50:IsA("LocalScript") or (p50:IsA("ModuleScript") or p50:IsA("BillboardGui")) or (p50:IsA("SurfaceGui") or p50:IsA("Highlight") or (p50:IsA("ProximityPrompt") or p50:IsA("ClickDetector"))))
end
local function v_u_53(p52) -- name: clearCorpseDeathState
	-- upvalues: (copy) v_u_3
	p52:SetAttribute("PreparedRagdoll", true)
	p52:SetAttribute("Dead", nil)
	p52:SetAttribute("Ragdolled", nil)
	p52:SetAttribute("RagdollCreatedAt", nil)
	v_u_3:RemoveTag(p52, "Ragdoll")
end
local function v_u_62(p54, p55) -- name: configureCorpseClone
	-- upvalues: (copy) v_u_53, (copy) v_u_49, (copy) v_u_21
	p55.Name = ("__PreparedRagdoll_%*"):format(p54.Name)
	p55:SetAttribute("ClientRagdoll", true)
	v_u_53(p55)
	local v56 = {}
	local v57 = {}
	for _, v58 in p55:GetDescendants() do
		if v58:IsA("BasePart") or v58:IsA("Decal") then
			v58.LocalTransparencyModifier = 1
			table.insert(v56, v58)
		elseif v_u_49(v58) or v58:IsA("Light") then
			local v59 = {
				["Instance"] = v58,
				["Enabled"] = v58.Enabled
			}
			table.insert(v57, v59)
			v58.Enabled = false
		end
		if v58:IsA("Motor6D") or (v58:IsA("Weld") or v58:IsA("WeldConstraint")) then
			local v60 = v58.Part0
			local v61 = v58.Part1
			if (not v60 or v60:IsDescendantOf(p55)) and (not v61 or v61:IsDescendantOf(p55)) then
				continue
			end
			v58:Destroy()
		else
			if not v58:IsA("Highlight") then
				continue
			end
			v58:Destroy()
		end
	end
	v_u_21[p55] = {
		["Effects"] = v57,
		["Renderables"] = v56
	}
end
local function v_u_71(p63, p64) -- name: setCorpseVisible
	-- upvalues: (copy) v_u_21
	local v65 = v_u_21[p63]
	if v65 then
		local v66 = p64 and 0 or 1
		for _, v67 in v65.Renderables do
			if not v67.Parent then
				continue
			end
			v67.LocalTransparencyModifier = v66
		end
		for _, v68 in v65.Effects do
			if not v68.Instance.Parent then
				continue
			end
			local v69 = v68.Instance
			local v70
			if p64 then
				v70 = v68.Enabled
			else
				v70 = p64
			end
			v69.Enabled = v70
		end
	end
end
local function v_u_78(p72) -- name: getCorpsePoolKey
	-- upvalues: (copy) v_u_9
	local v73 = v_u_9.getPlayerFromCharacter(p72)
	local v74
	if v73 then
		local v75 = v73.UserId
		v74 = tostring(v75)
	else
		v74 = p72.Name
	end
	local v76 = p72:GetAttribute("CharacterName")
	local v77 = p72:GetAttribute("EquippedGloves")
	return table.concat({ v74, tostring(v76 or ""), (tostring(v77 or "")) }, "\0")
end
local function v_u_86(p79, p80) -- name: syncCorpseAppearance
	-- upvalues: (copy) v_u_38, (copy) v_u_39, (copy) v_u_53
	for _, v81 in p79:GetChildren() do
		local v82 = p80:FindFirstChild(v81.Name)
		if v81:IsA("BasePart") and (v82 and v82:IsA("BasePart")) then
			if v82.Color == v81.Color then
				continue
			end
			v82.Color = v81.Color
		else
			if not (v81:IsA("BodyColors") and (v82 and v82:IsA("BodyColors"))) then
				continue
			end
			v82.HeadColor3 = v81.HeadColor3
			v82.LeftArmColor3 = v81.LeftArmColor3
			v82.LeftLegColor3 = v81.LeftLegColor3
			v82.RightArmColor3 = v81.RightArmColor3
			v82.RightLegColor3 = v81.RightLegColor3
			v82.TorsoColor3 = v81.TorsoColor3
		end
	end
	for v83 in p80:GetAttributes() do
		if v_u_38[v83] then
			continue
		end
		p80:SetAttribute(v83, nil)
	end
	for v84, v85 in p79:GetAttributes() do
		if v_u_38[v84] or v_u_39[v84] then
			continue
		end
		p80:SetAttribute(v84, v85)
	end
	p80.Name = ("__PreparedRagdoll_%*"):format(p79.Name)
	p80:SetAttribute("ClientRagdoll", true)
	v_u_53(p80)
end
local function v_u_94(p87) -- name: removePoolMembership
	-- upvalues: (copy) v_u_30, (copy) v_u_27, (copy) v_u_29, (copy) v_u_28, (ref) v_u_33
	v_u_30[p87] = nil
	local v88 = v_u_27[p87]
	v_u_27[p87] = nil
	if v88 then
		local v89 = v_u_29[v88]
		if v89 then
			for v90 = #v89, 1, -1 do
				if v89[v90] ~= p87 then
					continue
				end
				table.remove(v89, v90)
			end
			if #v89 == 0 then
				v_u_29[v88] = nil
			end
		end
		local v91 = (v_u_28[v88] or 1) - 1
		local v92 = v_u_28
		if v91 <= 0 then
			v91 = nil
		end
		v92[v88] = v91
		local v93 = v_u_33 - 1
		v_u_33 = math.max(0, v93)
	end
end
local function v_u_96(p95)
	-- upvalues: (copy) v_u_94, (copy) v_u_31, (copy) v_u_17, (copy) v_u_21, (copy) v_u_3
	v_u_94(p95)
	v_u_31[p95] = nil
	v_u_17[p95] = nil
	v_u_21[p95] = nil
	v_u_3:RemoveTag(p95, "Ragdoll")
	p95:Destroy()
end
v_u_36 = function(p_u_97)
	-- upvalues: (copy) v_u_31, (copy) v_u_27, (copy) v_u_11, (copy) v_u_5, (ref) v_u_96, (copy) v_u_30, (copy) v_u_71, (copy) v_u_53, (copy) v_u_14, (copy) v_u_29
	if v_u_31[p_u_97] or (not v_u_27[p_u_97] or (p_u_97.Parent ~= v_u_11 or not v_u_5.ResetPrepared(p_u_97))) then
		v_u_96(p_u_97)
		return
	elseif not v_u_30[p_u_97] then
		v_u_71(p_u_97, false)
		p_u_97.Name = "__PooledRagdoll"
		v_u_53(p_u_97)
		local function v98()
			-- upvalues: (copy) p_u_97, (ref) v_u_14
			p_u_97:PivotTo(v_u_14)
		end
		debug.profilebegin("Ragdoll.Pool.Park")
		local v99, v100 = pcall(v98)
		debug.profileend()
		if not v99 then
			error(v100, 0)
		end
		local v101 = v_u_27[p_u_97]
		local v102 = v_u_29[v101]
		if not v102 then
			v102 = {}
			v_u_29[v101] = v102
		end
		v_u_30[p_u_97] = true
		table.insert(v102, p_u_97)
	end
end
local function v_u_110(p103, p104) -- name: acquirePooledCorpse
	-- upvalues: (copy) v_u_29, (copy) v_u_30, (copy) v_u_11, (copy) v_u_27, (copy) v_u_31, (copy) v_u_5, (ref) v_u_96, (copy) v_u_86, (copy) v_u_71, (copy) v_u_14
	local v105 = v_u_29[p104]
	while v105 and #v105 > 0 do
		local v_u_106 = table.remove(v105)
		if #v105 == 0 then
			v_u_29[p104] = nil
		end
		if not v_u_30[v_u_106] then
			continue
		end
		v_u_30[v_u_106] = nil
		if v_u_106.Parent == v_u_11 and (v_u_27[v_u_106] == p104 and (not v_u_31[v_u_106] and v_u_5.ResetPrepared(v_u_106))) then
			v_u_86(p103, v_u_106)
			v_u_71(v_u_106, false)
			local function v107()
				-- upvalues: (copy) v_u_106, (ref) v_u_14
				v_u_106:PivotTo(v_u_14)
			end
			debug.profilebegin("Ragdoll.Pool.Park")
			local v108, v109 = pcall(v107)
			debug.profileend()
			if not v108 then
				error(v109, 0)
			end
			return v_u_106
		end
		v_u_96(v_u_106)
	end
	return nil
end
local function v_u_119(p_u_111, p112, p113) -- name: cloneCorpse
	-- upvalues: (copy) v_u_62
	if not p_u_111.Parent or p_u_111:GetAttribute("ClientRagdoll") == true then
		return nil
	end
	p_u_111.Archivable = true
	debug.profilebegin(p112)
	local v114, v_u_115 = pcall(function()
		-- upvalues: (copy) p_u_111
		return p_u_111:Clone()
	end)
	debug.profileend()
	if not v114 then
		error(v_u_115, 0)
	end
	local function v116()
		-- upvalues: (ref) v_u_62, (copy) p_u_111, (copy) v_u_115
		v_u_62(p_u_111, v_u_115)
	end
	debug.profilebegin(p113)
	local v117, v118 = pcall(v116)
	debug.profileend()
	if not v117 then
		error(v118, 0)
	end
	return v_u_115
end
local function v_u_163(p_u_120, p_u_121) -- name: scheduleReservePrewarm
	-- upvalues: (copy) v_u_6, (ref) v_u_35, (copy) v_u_28, (copy) v_u_32, (ref) v_u_34, (copy) v_u_9, (copy) v_u_2, (copy) v_u_47, (copy) v_u_25, (copy) v_u_26, (copy) v_u_51, (copy) v_u_119, (copy) v_u_5, (copy) v_u_14, (copy) v_u_27, (ref) v_u_33, (copy) v_u_13, (copy) v_u_11, (ref) v_u_36, (ref) v_u_96
	local v122 = v_u_6.GetState()
	local v123 = v_u_35
	if v123 then
		v123 = v122 == "Warmup" and true or v122 == "Buy Period"
	end
	if v123 and ((v_u_28[p_u_121] or 0) < 2 and v_u_32[p_u_121] == nil) then
		local v_u_124 = v_u_34
		v_u_32[p_u_121] = v_u_124
		local v_u_125 = v_u_9.getPlayerFromCharacter(p_u_120)
		task.spawn(function()
			-- upvalues: (ref) v_u_47, (copy) v_u_124, (ref) v_u_34, (copy) v_u_125, (ref) v_u_2, (ref) v_u_6, (ref) v_u_35, (copy) p_u_120, (ref) v_u_25, (ref) v_u_26, (ref) v_u_51, (ref) v_u_119, (ref) v_u_5, (ref) v_u_28, (copy) p_u_121, (ref) v_u_14, (ref) v_u_27, (ref) v_u_33, (ref) v_u_13, (ref) v_u_11, (ref) v_u_36, (ref) v_u_96, (ref) v_u_32
			local v_u_126 = nil
			local function v160()
				-- upvalues: (ref) v_u_47, (ref) v_u_124, (ref) v_u_34, (ref) v_u_125, (ref) v_u_2, (ref) v_u_6, (ref) v_u_35, (ref) p_u_120, (ref) v_u_25, (ref) v_u_26, (ref) v_u_51, (ref) v_u_126, (ref) v_u_119, (ref) v_u_5, (ref) v_u_28, (ref) p_u_121, (ref) v_u_14, (ref) v_u_27, (ref) v_u_33, (ref) v_u_13, (ref) v_u_11, (ref) v_u_36
				v_u_47(function()
					-- upvalues: (ref) v_u_124, (ref) v_u_34, (ref) v_u_125, (ref) v_u_2, (ref) v_u_6, (ref) v_u_35, (ref) p_u_120, (ref) v_u_25, (ref) v_u_26, (ref) v_u_51, (ref) v_u_126, (ref) v_u_119
					local v127
					if v_u_124 == v_u_34 and (v_u_125 == nil or v_u_125.Parent == v_u_2) then
						local v128 = v_u_6.GetState()
						local v129 = v_u_35
						if v129 then
							v129 = v128 == "Warmup" and true or v128 == "Buy Period"
						end
						v127 = not v129
					else
						v127 = true
					end
					if not v127 then
						local v130 = p_u_120
						local v131 = v_u_35
						if v131 then
							if v130.Parent == nil or (v130:GetAttribute("ClientRagdoll") == true or v130:GetAttribute("Dead") == true) then
								v131 = false
							else
								v131 = not v_u_25[v130]
							end
						end
						if v131 then
							if not v_u_26[p_u_120] then
								local v132 = p_u_120
								for _, v133 in v132:GetDescendants() do
									if not v_u_51(v133) then
										continue
									end
									v133.Archivable = false
								end
								v_u_26[v132] = true
							end
							v_u_126 = v_u_119(p_u_120, "Ragdoll.Pool.CloneReserve", "Ragdoll.Pool.ConfigureReserve")
							return
						end
					end
				end)
				if v_u_126 then
					local v134
					if v_u_124 == v_u_34 and (v_u_125 == nil or v_u_125.Parent == v_u_2) then
						local v135 = v_u_6.GetState()
						local v136 = v_u_35
						if v136 then
							v136 = v135 == "Warmup" and true or v135 == "Buy Period"
						end
						v134 = not v136
					else
						v134 = true
					end
					if not v134 then
						local v_u_137 = v_u_126
						if v_u_47(function()
							-- upvalues: (ref) v_u_124, (ref) v_u_34, (ref) v_u_125, (ref) v_u_2, (ref) v_u_6, (ref) v_u_35, (ref) p_u_120, (ref) v_u_25, (ref) v_u_5, (copy) v_u_137
							local v138
							if v_u_124 == v_u_34 and (v_u_125 == nil or v_u_125.Parent == v_u_2) then
								local v139 = v_u_6.GetState()
								local v140 = v_u_35
								if v140 then
									v140 = v139 == "Warmup" and true or v139 == "Buy Period"
								end
								v138 = not v140
							else
								v138 = true
							end
							if not v138 then
								local v141 = p_u_120
								local v142 = v_u_35
								if v142 then
									if v141.Parent == nil or (v141:GetAttribute("ClientRagdoll") == true or v141:GetAttribute("Dead") == true) then
										v142 = false
									else
										v142 = not v_u_25[v141]
									end
								end
								if v142 then
									local v143 = v_u_5.Prepare(v_u_137)
									if v143 then
										v143 = v_u_5.StagePrepared(v_u_137)
									end
									return v143
								end
							end
							return false
						end) == true and v_u_124 == v_u_34 then
							local v144 = v_u_6.GetState()
							local v145 = v_u_35
							if v145 then
								v145 = v144 == "Warmup" and true or v144 == "Buy Period"
							end
							if v145 then
								v_u_47(function()
									-- upvalues: (ref) v_u_124, (ref) v_u_34, (ref) v_u_125, (ref) v_u_2, (ref) v_u_6, (ref) v_u_35, (ref) v_u_28, (ref) p_u_121, (copy) v_u_137, (ref) v_u_14, (ref) v_u_27, (ref) v_u_33, (ref) v_u_13, (ref) v_u_11, (ref) v_u_36, (ref) v_u_126
									local v146
									if v_u_124 == v_u_34 and (v_u_125 == nil or v_u_125.Parent == v_u_2) then
										local v147 = v_u_6.GetState()
										local v148 = v_u_35
										if v148 then
											v148 = v147 == "Warmup" and true or v147 == "Buy Period"
										end
										v146 = not v148
									else
										v146 = true
									end
									if v146 or (v_u_28[p_u_121] or 0) >= 2 then
										return false
									end
									local v_u_149 = v_u_137
									local function v150()
										-- upvalues: (copy) v_u_149, (ref) v_u_14
										v_u_149:PivotTo(v_u_14)
									end
									debug.profilebegin("Ragdoll.Pool.Park")
									local v151, v152 = pcall(v150)
									debug.profileend()
									if not v151 then
										error(v152, 0)
									end
									local v153 = v_u_137
									local v154 = p_u_121
									local v155 = v_u_27[v153]
									local v156
									if v155 then
										v156 = v155 == v154
									elseif (v_u_28[v154] or 0) >= 2 or v_u_13 <= v_u_33 then
										v156 = false
									else
										v_u_27[v153] = v154
										v_u_28[v154] = (v_u_28[v154] or 0) + 1
										v_u_33 = v_u_33 + 1
										v156 = true
									end
									if not v156 then
										return false
									end
									local function v157()
										-- upvalues: (ref) v_u_137, (ref) v_u_11
										v_u_137.Parent = v_u_11
									end
									debug.profilebegin("Ragdoll.Pool.ParentReserve")
									local v158, v159 = pcall(v157)
									debug.profileend()
									if not v158 then
										error(v159, 0)
									end
									v_u_36(v_u_137)
									v_u_126 = nil
									return true
								end)
								return
							end
						end
						return
					end
				end
			end
			local v161, v162 = pcall(v160)
			if v_u_126 then
				v_u_96(v_u_126)
			end
			if v_u_32[p_u_121] == v_u_124 then
				v_u_32[p_u_121] = nil
			end
			if not v161 then
				warn((("[Ragdoll] Reserve prewarm failed: %*"):format(v162)))
			end
		end)
	end
end
function v_u_10.HideCharacterLocally(p164) -- name: HideCharacterLocally
	-- upvalues: (copy) v_u_49
	for _, v165 in p164:GetDescendants() do
		if v165:IsA("BasePart") then
			v165.LocalTransparencyModifier = 1
			v165.CanCollide = false
			v165.CanQuery = false
		elseif v165:IsA("Decal") then
			v165.LocalTransparencyModifier = 1
		else
			if not (v_u_49(v165) or (v165:IsA("BillboardGui") or (v165:IsA("SurfaceGui") or v165:IsA("Highlight")))) then
				continue
			end
			v165.Enabled = false
		end
	end
end
function v_u_10.PrepareCharacter(p_u_166) -- name: PrepareCharacter
	-- upvalues: (copy) v_u_18, (ref) v_u_35, (copy) v_u_25, (copy) v_u_20, (copy) v_u_4, (copy) v_u_78, (copy) v_u_110, (copy) v_u_19, (ref) v_u_36, (copy) v_u_163, (copy) v_u_47, (copy) v_u_26, (copy) v_u_51, (copy) v_u_119, (ref) v_u_96, (copy) v_u_5, (copy) v_u_14, (copy) v_u_27, (copy) v_u_28, (ref) v_u_33, (copy) v_u_13, (copy) v_u_11
	if v_u_18[p_u_166] then
		return true
	end
	local v167 = v_u_35
	if v167 then
		if p_u_166.Parent == nil or (p_u_166:GetAttribute("ClientRagdoll") == true or p_u_166:GetAttribute("Dead") == true) then
			v167 = false
		else
			v167 = not v_u_25[p_u_166]
		end
	end
	if not v167 then
		return false
	end
	local v168 = v_u_20[p_u_166]
	if not v168 then
		local v_u_169 = v_u_78(p_u_166)
		local v170 = v_u_110(p_u_166, v_u_169)
		if v170 then
			v_u_18[p_u_166] = v170
			if not v_u_19[p_u_166] then
				v_u_19[p_u_166] = p_u_166.AncestryChanged:Connect(function(_, p171)
					-- upvalues: (copy) p_u_166, (ref) v_u_20, (ref) v_u_36, (ref) v_u_18, (ref) v_u_19
					if p171 == nil then
						local v172 = p_u_166
						local v173 = v_u_20[v172]
						v_u_20[v172] = nil
						if v173 then
							v173.Cancelled = true
							local v174 = v173.Corpse
							v173.Corpse = nil
							if v174 then
								v_u_36(v174)
							end
						end
						local v175 = v_u_18[v172]
						v_u_18[v172] = nil
						if v175 then
							v_u_36(v175)
						end
						local v176 = p_u_166
						local v177 = v_u_19[v176]
						v_u_19[v176] = nil
						if v177 then
							v177:Disconnect()
						end
					end
				end)
			end
			v_u_163(p_u_166, v_u_169)
			return true
		end
		local v_u_178 = {
			["Corpse"] = nil,
			["Cancelled"] = false
		}
		v_u_20[p_u_166] = v_u_178
		if not v_u_19[p_u_166] then
			v_u_19[p_u_166] = p_u_166.AncestryChanged:Connect(function(_, p179)
				-- upvalues: (copy) p_u_166, (ref) v_u_20, (ref) v_u_36, (ref) v_u_18, (ref) v_u_19
				if p179 == nil then
					local v180 = p_u_166
					local v181 = v_u_20[v180]
					v_u_20[v180] = nil
					if v181 then
						v181.Cancelled = true
						local v182 = v181.Corpse
						v181.Corpse = nil
						if v182 then
							v_u_36(v182)
						end
					end
					local v183 = v_u_18[v180]
					v_u_18[v180] = nil
					if v183 then
						v_u_36(v183)
					end
					local v184 = p_u_166
					local v185 = v_u_19[v184]
					v_u_19[v184] = nil
					if v185 then
						v185:Disconnect()
					end
				end
			end)
		end
		local function v225()
			-- upvalues: (ref) v_u_47, (copy) p_u_166, (copy) v_u_178, (ref) v_u_20, (ref) v_u_35, (ref) v_u_25, (ref) v_u_26, (ref) v_u_51, (ref) v_u_119, (ref) v_u_96, (ref) v_u_5, (ref) v_u_14, (copy) v_u_169, (ref) v_u_27, (ref) v_u_28, (ref) v_u_33, (ref) v_u_13, (ref) v_u_11, (ref) v_u_18, (ref) v_u_163
			v_u_47(function()
				-- upvalues: (ref) p_u_166, (ref) v_u_178, (ref) v_u_20, (ref) v_u_35, (ref) v_u_25, (ref) v_u_26, (ref) v_u_51, (ref) v_u_119, (ref) v_u_96
				local v186 = p_u_166
				local v187 = v_u_178
				local v188 = v_u_20[v186] == v187 and (not v187.Cancelled and v_u_35)
				if v188 then
					if v186.Parent == nil or (v186:GetAttribute("ClientRagdoll") == true or v186:GetAttribute("Dead") == true) then
						v188 = false
					else
						v188 = not v_u_25[v186]
					end
				end
				if v188 then
					if not v_u_26[p_u_166] then
						local function v191()
							-- upvalues: (ref) p_u_166, (ref) v_u_51, (ref) v_u_26
							local v189 = p_u_166
							for _, v190 in v189:GetDescendants() do
								if not v_u_51(v190) then
									continue
								end
								v190.Archivable = false
							end
							v_u_26[v189] = true
						end
						debug.profilebegin("Ragdoll.Prepare.MarkNonArchivable")
						local v192, v193 = pcall(v191)
						debug.profileend()
						if not v192 then
							error(v193, 0)
						end
					end
					local v194 = v_u_119(p_u_166, "Ragdoll.Prepare.Clone", "Ragdoll.Prepare.ConfigureClone")
					if v194 then
						local v195 = p_u_166
						local v196 = v_u_178
						local v197 = v_u_20[v195] == v196 and (not v196.Cancelled and v_u_35)
						if v197 then
							if v195.Parent == nil or (v195:GetAttribute("ClientRagdoll") == true or v195:GetAttribute("Dead") == true) then
								v197 = false
							else
								v197 = not v_u_25[v195]
							end
						end
						if v197 then
							v_u_178.Corpse = v194
						else
							v_u_96(v194)
						end
					else
						return
					end
				else
					return
				end
			end)
			local v_u_198 = v_u_178.Corpse
			if v_u_198 then
				local v199 = p_u_166
				local v200 = v_u_178
				local v201 = v_u_20[v199] == v200 and (not v200.Cancelled and v_u_35)
				if v201 then
					if v199.Parent == nil or (v199:GetAttribute("ClientRagdoll") == true or v199:GetAttribute("Dead") == true) then
						v201 = false
					else
						v201 = not v_u_25[v199]
					end
				end
				if v201 then
					if v_u_47(function()
						-- upvalues: (ref) p_u_166, (ref) v_u_178, (ref) v_u_20, (ref) v_u_35, (ref) v_u_25, (copy) v_u_198, (ref) v_u_5
						local v202 = p_u_166
						local v203 = v_u_178
						local v204 = v_u_20[v202] == v203 and (not v203.Cancelled and v_u_35)
						if v204 then
							if v202.Parent == nil or (v202:GetAttribute("ClientRagdoll") == true or v202:GetAttribute("Dead") == true) then
								v204 = false
							else
								v204 = not v_u_25[v202]
							end
						end
						if v204 then
							v204 = v_u_178.Corpse == v_u_198
						end
						if not v204 then
							return false
						end
						local v205 = v_u_5.Prepare(v_u_198)
						if v205 then
							v205 = v_u_5.StagePrepared(v_u_198)
						end
						return v205
					end) == true then
						local v206 = p_u_166
						local v207 = v_u_178
						local v208 = v_u_20[v206] == v207 and (not v207.Cancelled and v_u_35)
						if v208 then
							if v206.Parent == nil or (v206:GetAttribute("ClientRagdoll") == true or v206:GetAttribute("Dead") == true) then
								v208 = false
							else
								v208 = not v_u_25[v206]
							end
						end
						if v208 then
							v208 = v_u_178.Corpse == v_u_198
						end
						if v208 then
							if v_u_47(function()
								-- upvalues: (ref) p_u_166, (ref) v_u_178, (ref) v_u_20, (ref) v_u_35, (ref) v_u_25, (copy) v_u_198, (ref) v_u_14, (ref) v_u_169, (ref) v_u_27, (ref) v_u_28, (ref) v_u_33, (ref) v_u_13, (ref) v_u_11
								local v209 = p_u_166
								local v210 = v_u_178
								local v211 = v_u_20[v209] == v210 and (not v210.Cancelled and v_u_35)
								if v211 then
									if v209.Parent == nil or (v209:GetAttribute("ClientRagdoll") == true or v209:GetAttribute("Dead") == true) then
										v211 = false
									else
										v211 = not v_u_25[v209]
									end
								end
								if v211 then
									v211 = v_u_178.Corpse == v_u_198
								end
								if not v211 then
									return false
								end
								local v_u_212 = v_u_198
								local function v213()
									-- upvalues: (copy) v_u_212, (ref) v_u_14
									v_u_212:PivotTo(v_u_14)
								end
								debug.profilebegin("Ragdoll.Pool.Park")
								local v214, v215 = pcall(v213)
								debug.profileend()
								if not v214 then
									error(v215, 0)
								end
								local v216 = v_u_198
								local v217 = v_u_169
								local v218 = v_u_27[v216]
								if v218 then
									local _ = v218 == v217
								elseif (v_u_28[v217] or 0) < 2 and v_u_13 > v_u_33 then
									v_u_27[v216] = v217
									v_u_28[v217] = (v_u_28[v217] or 0) + 1
									v_u_33 = v_u_33 + 1
								end
								local function v219()
									-- upvalues: (ref) v_u_198, (ref) v_u_11
									v_u_198.Parent = v_u_11
								end
								debug.profilebegin("Ragdoll.Prepare.ParentInitialPoolSlot")
								local v220, v221 = pcall(v219)
								debug.profileend()
								if not v220 then
									error(v221, 0)
								end
								return true
							end) == true then
								local v222 = p_u_166
								local v223 = v_u_178
								local v224 = v_u_20[v222] == v223 and (not v223.Cancelled and v_u_35)
								if v224 then
									if v222.Parent == nil or (v222:GetAttribute("ClientRagdoll") == true or v222:GetAttribute("Dead") == true) then
										v224 = false
									else
										v224 = not v_u_25[v222]
									end
								end
								if v224 then
									v224 = v_u_178.Corpse == v_u_198
								end
								if v224 then
									v_u_18[p_u_166] = v_u_198
									v_u_178.Corpse = nil
									v_u_20[p_u_166] = nil
									v_u_163(p_u_166, v_u_169)
									return true
								end
							end
							return false
						end
					end
					return false
				end
			end
			return false
		end
		local v226, v227 = pcall(v225)
		if v_u_20[p_u_166] == v_u_178 then
			v_u_20[p_u_166] = nil
		end
		if v_u_178.Corpse then
			v_u_36(v_u_178.Corpse)
			v_u_178.Corpse = nil
		end
		if not v226 then
			local v228 = v_u_19[p_u_166]
			v_u_19[p_u_166] = nil
			if v228 then
				v228:Disconnect()
			end
			error(v227, 0)
		end
		if v227 ~= true and not v_u_18[p_u_166] then
			local v229 = v_u_19[p_u_166]
			v_u_19[p_u_166] = nil
			if v229 then
				v229:Disconnect()
			end
		end
		return v227 == true
	end
	while v_u_20[p_u_166] == v168 do
		local v230 = v_u_35
		if v230 then
			if p_u_166.Parent == nil or (p_u_166:GetAttribute("ClientRagdoll") == true or p_u_166:GetAttribute("Dead") == true) then
				v230 = false
			else
				v230 = not v_u_25[p_u_166]
			end
		end
		if not v230 then
			break
		end
		v_u_4.Heartbeat:Wait()
	end
	return v_u_18[p_u_166] ~= nil
end
function v_u_10.ActivateCharacter(p_u_231, p_u_232) -- name: ActivateCharacter
	-- upvalues: (copy) v_u_16, (copy) v_u_25, (copy) v_u_10, (copy) v_u_26, (copy) v_u_51, (copy) v_u_5, (copy) v_u_18, (copy) v_u_20, (ref) v_u_36, (copy) v_u_19, (copy) v_u_119, (ref) v_u_96, (copy) v_u_27, (copy) v_u_78, (copy) v_u_28, (ref) v_u_33, (copy) v_u_13, (copy) v_u_17, (copy) v_u_71, (copy) v_u_11, (copy) v_u_6
	if p_u_231:GetAttribute("ClientRagdoll") == true then
		return p_u_231
	end
	local v233 = v_u_16[p_u_231]
	if v233 and v233.Parent then
		return v233
	end
	if v_u_25[p_u_231] then
		v_u_10.HideCharacterLocally(p_u_231)
		return p_u_231
	end
	if not v_u_26[p_u_231] then
		local function v236()
			-- upvalues: (copy) p_u_231, (ref) v_u_51, (ref) v_u_26
			local v234 = p_u_231
			for _, v235 in v234:GetDescendants() do
				if not v_u_51(v235) then
					continue
				end
				v235.Archivable = false
			end
			v_u_26[v234] = true
		end
		debug.profilebegin("Ragdoll.Activate.MarkNonArchivable")
		local v237, v238 = pcall(v236)
		debug.profileend()
		if not v237 then
			error(v238, 0)
		end
	end
	local function v239()
		-- upvalues: (ref) v_u_5, (copy) p_u_231
		return v_u_5.CapturePose(p_u_231)
	end
	debug.profilebegin("Ragdoll.Activate.CapturePose")
	local v240, v_u_241 = pcall(v239)
	debug.profileend()
	if not v240 then
		error(v_u_241, 0)
	end
	local function v246()
		-- upvalues: (copy) p_u_231, (ref) v_u_18, (ref) v_u_20, (ref) v_u_36, (ref) v_u_19
		local v242 = p_u_231
		local v243 = v_u_18[v242]
		v_u_18[v242] = nil
		local v244 = v_u_20[v242]
		v_u_20[v242] = nil
		if v244 then
			v244.Cancelled = true
			if v243 then
				if v244.Corpse then
					v_u_36(v244.Corpse)
					v244.Corpse = nil
				end
			else
				v243 = v244.Corpse
				v244.Corpse = nil
			end
		end
		local v245 = v_u_19[v242]
		v_u_19[v242] = nil
		if v245 then
			v245:Disconnect()
		end
		return v243
	end
	debug.profilebegin("Ragdoll.Activate.TakePrepared")
	local v247, v248 = pcall(v246)
	debug.profileend()
	if not v247 then
		error(v248, 0)
	end
	local v_u_249 = v248 or v_u_119(p_u_231, "Ragdoll.Activate.Clone", "Ragdoll.Activate.ConfigureFallbackClone")
	if not v_u_249 then
		return p_u_231
	end
	if not v_u_5.IsPrepared(v_u_249) then
		local function v250()
			-- upvalues: (ref) v_u_5, (copy) v_u_249
			return v_u_5.Prepare(v_u_249)
		end
		debug.profilebegin("Ragdoll.Activate.CompletePreparation")
		local v251, v252 = pcall(v250)
		debug.profileend()
		if not v251 then
			error(v252, 0)
		end
		if v252 ~= true then
			v_u_96(v_u_249)
			return p_u_231
		end
	end
	if not v_u_27[v_u_249] then
		local v253 = v_u_78(p_u_231)
		local v254 = v_u_27[v_u_249]
		if v254 then
			local _ = v254 == v253
		elseif (v_u_28[v253] or 0) < 2 and v_u_13 > v_u_33 then
			v_u_27[v_u_249] = v253
			v_u_28[v253] = (v_u_28[v253] or 0) + 1
			v_u_33 = v_u_33 + 1
		end
	end
	local function v255()
		-- upvalues: (copy) v_u_249, (copy) p_u_231, (ref) v_u_16, (ref) v_u_17
		v_u_249.Name = p_u_231.Name
		v_u_249:SetAttribute("PreparedRagdoll", nil)
		v_u_249:SetAttribute("Dead", true)
		v_u_16[p_u_231] = v_u_249
		v_u_17[v_u_249] = p_u_231
	end
	debug.profilebegin("Ragdoll.Activate.ConfigureClone")
	local v256, v257 = pcall(v255)
	debug.profileend()
	if not v256 then
		error(v257, 0)
	end
	local function v258()
		-- upvalues: (ref) v_u_5, (copy) v_u_249, (copy) v_u_241, (copy) p_u_232
		v_u_5.Activate(v_u_249, v_u_241, p_u_232)
	end
	debug.profilebegin("Ragdoll.Activate.Rig")
	local v259, v260 = pcall(v258)
	debug.profileend()
	if not v259 then
		error(v260, 0)
	end
	local function v261()
		-- upvalues: (ref) v_u_71, (copy) v_u_249
		v_u_71(v_u_249, true)
	end
	debug.profilebegin("Ragdoll.Activate.Reveal")
	local v262, v263 = pcall(v261)
	debug.profileend()
	if not v262 then
		error(v263, 0)
	end
	local function v264()
		-- upvalues: (copy) v_u_249, (ref) v_u_11
		if v_u_249.Parent ~= v_u_11 then
			v_u_249.Parent = v_u_11
		end
	end
	debug.profilebegin("Ragdoll.Activate.Parent")
	local v265, v266 = pcall(v264)
	debug.profileend()
	if not v265 then
		error(v266, 0)
	end
	local function v269()
		-- upvalues: (copy) p_u_231, (copy) v_u_249, (ref) v_u_10
		local v267 = p_u_231:FindFirstChild("CharacterModel")
		if v267 then
			v267:Destroy()
		end
		local v268 = v_u_249:FindFirstChild("CharacterModel")
		if v268 then
			v268:Destroy()
		end
		v_u_10.HideCharacterLocally(p_u_231)
	end
	debug.profilebegin("Ragdoll.Activate.Cleanup")
	local v270, v271 = pcall(v269)
	debug.profileend()
	if not v270 then
		error(v271, 0)
	end
	local v272 = task.delay
	local v273
	if v_u_6.GetState() == "Warmup" then
		v273 = workspace:GetAttribute("Gamemode") == "Deathmatch"
	else
		v273 = false
	end
	v272(v273 and 10 or 15, function()
		-- upvalues: (ref) v_u_16, (copy) p_u_231, (copy) v_u_249, (ref) v_u_17, (ref) v_u_36
		if v_u_16[p_u_231] == v_u_249 then
			local v274 = p_u_231
			local v275 = v_u_16[v274]
			v_u_16[v274] = nil
			if v275 then
				v_u_17[v275] = nil
				v_u_36(v275)
			end
		end
	end)
	return v_u_249
end
function v_u_10.RetireCorpseLocally(p_u_276) -- name: RetireCorpseLocally
	-- upvalues: (copy) v_u_17, (copy) v_u_25, (copy) v_u_16, (copy) v_u_31, (copy) v_u_18, (copy) v_u_20, (ref) v_u_36, (copy) v_u_19, (copy) v_u_10
	task.defer(function()
		-- upvalues: (copy) p_u_276, (ref) v_u_17, (ref) v_u_25, (ref) v_u_16, (ref) v_u_31, (ref) v_u_18, (ref) v_u_20, (ref) v_u_36, (ref) v_u_19, (ref) v_u_10
		local v277 = p_u_276
		local v278 = v_u_17[v277] or v277
		v_u_25[v278] = true
		local v279 = v_u_16[v278]
		if v279 then
			v_u_31[v279] = true
		end
		local v280 = v_u_18[v278]
		if v280 then
			v_u_31[v280] = true
		end
		local v281 = v_u_20[v278]
		if v281 and v281.Corpse then
			v_u_31[v281.Corpse] = true
		end
		local v282 = v_u_20[v278]
		v_u_20[v278] = nil
		if v282 then
			v282.Cancelled = true
			local v283 = v282.Corpse
			v282.Corpse = nil
			if v283 then
				v_u_36(v283)
			end
		end
		local v284 = v_u_18[v278]
		v_u_18[v278] = nil
		if v284 then
			v_u_36(v284)
		end
		local v285 = v_u_19[v278]
		v_u_19[v278] = nil
		if v285 then
			v285:Disconnect()
		end
		local v286 = v_u_16[v278]
		v_u_16[v278] = nil
		if v286 then
			v_u_17[v286] = nil
			v_u_36(v286)
		end
		if v278.Parent then
			local v287 = v278:FindFirstChild("CharacterModel")
			if v287 then
				v287:Destroy()
			end
			v_u_10.HideCharacterLocally(v278)
		end
	end)
end
function v_u_10.RecycleAll() -- name: RecycleAll
	-- upvalues: (copy) v_u_15, (copy) v_u_16, (copy) v_u_17, (ref) v_u_36
	local v288 = {}
	for v289 in v_u_15 do
		table.insert(v288, v289)
	end
	for _, v290 in v288 do
		v290:Destroy()
	end
	local v291 = {}
	for v292 in v_u_16 do
		table.insert(v291, v292)
	end
	for _, v293 in v291 do
		local v294 = v_u_16[v293]
		v_u_16[v293] = nil
		if not v294 then
			continue
		end
		v_u_17[v294] = nil
		v_u_36(v294)
	end
end
function v_u_10.DestroyAll() -- name: DestroyAll
	-- upvalues: (ref) v_u_34, (copy) v_u_10, (copy) v_u_18, (copy) v_u_20, (copy) v_u_31, (ref) v_u_36, (copy) v_u_19, (copy) v_u_27, (ref) v_u_96, (copy) v_u_29, (copy) v_u_30, (copy) v_u_28, (copy) v_u_32, (ref) v_u_33
	v_u_34 = v_u_34 + 1
	v_u_10.RecycleAll()
	local v295 = {}
	for v296 in v_u_18 do
		v295[v296] = true
	end
	for v297 in v_u_20 do
		v295[v297] = true
	end
	for v298 in v295 do
		local v299 = v_u_18[v298]
		if v299 then
			v_u_31[v299] = true
		end
		local v300 = v_u_20[v298]
		if v300 and v300.Corpse then
			v_u_31[v300.Corpse] = true
		end
		local v301 = v_u_20[v298]
		v_u_20[v298] = nil
		if v301 then
			v301.Cancelled = true
			local v302 = v301.Corpse
			v301.Corpse = nil
			if v302 then
				v_u_36(v302)
			end
		end
		local v303 = v_u_18[v298]
		v_u_18[v298] = nil
		if v303 then
			v_u_36(v303)
		end
		local v304 = v_u_19[v298]
		v_u_19[v298] = nil
		if not v304 then
			continue
		end
		v304:Disconnect()
	end
	local v305 = {}
	for v306 in v_u_27 do
		table.insert(v305, v306)
	end
	for _, v307 in v305 do
		v_u_96(v307)
	end
	table.clear(v_u_29)
	table.clear(v_u_30)
	table.clear(v_u_28)
	table.clear(v_u_32)
	v_u_33 = 0
end
function v_u_10.SetEnabled(p308) -- name: SetEnabled
	-- upvalues: (ref) v_u_35, (copy) v_u_10, (copy) v_u_2
	if v_u_35 == p308 then
		return
	else
		v_u_35 = p308
		if p308 then
			for _, v309 in v_u_2:GetPlayers() do
				local v_u_310 = v309.Character
				if not v_u_310 then
					continue
				end
				task.spawn(function()
					-- upvalues: (ref) v_u_10, (copy) v_u_310
					local v311 = v_u_10.PrepareCharacter
					local v312 = v_u_310
					local v313, v314 = pcall(v311, v312)
					if not v313 then
						warn((("[Ragdoll] Re-enabled prewarm failed: %*"):format(v314)))
					end
				end)
			end
		else
			v_u_10.DestroyAll()
		end
	end
end
function v_u_10.OnceAppearanceReady(_, p315) -- name: OnceAppearanceReady
	p315()
end
function v_u_10.SetupCharacterAppearance(_) -- name: SetupCharacterAppearance end
function v_u_10.new(p316, p317) -- name: new
	-- upvalues: (copy) v_u_10, (copy) v_u_7, (copy) v_u_17, (copy) v_u_31, (copy) v_u_8, (copy) v_u_5, (copy) v_u_15, (copy) v_u_6
	local v318 = v_u_10
	local v_u_319 = setmetatable({}, v318)
	v_u_319.Janitor = v_u_7.new()
	v_u_319.SourceCharacter = v_u_17[p316] or p316
	v_u_319.CharacterModel = v_u_10.ActivateCharacter(v_u_319.SourceCharacter, p317.Velocity)
	if p317.Finisher == "Charred" or (p317.Finisher == "Gold" or p317.Finisher == "Melted") then
		v_u_31[v_u_319.CharacterModel] = true
	end
	v_u_319.OnDestroy = v_u_319.Janitor:Add(v_u_8.new())
	v_u_319.OnAppearanceBuilt = v_u_319.Janitor:Add(v_u_8.new())
	v_u_319.IsAppearanceBuilt = true
	v_u_319.IsDestroyed = false
	v_u_5.ApplyImpulse(v_u_319.CharacterModel, p317)
	v_u_319.Janitor:Add(v_u_319.CharacterModel.AncestryChanged:Connect(function(_, p320)
		-- upvalues: (copy) v_u_319
		if p320 == nil then
			v_u_319:Destroy()
		end
	end))
	v_u_15[v_u_319] = true
	local v321 = task.delay
	local v322
	if v_u_6.GetState() == "Warmup" then
		v322 = workspace:GetAttribute("Gamemode") == "Deathmatch"
	else
		v322 = false
	end
	v321(v322 and 10 or 15, function()
		-- upvalues: (copy) v_u_319
		v_u_319:Destroy()
	end)
	return v_u_319
end
function v_u_10.Destroy(p323) -- name: Destroy
	-- upvalues: (copy) v_u_15, (copy) v_u_16, (copy) v_u_17, (ref) v_u_36
	if not p323.IsDestroyed then
		p323.IsDestroyed = true
		v_u_15[p323] = nil
		p323.OnDestroy:Fire()
		local v324 = p323.SourceCharacter
		local v325 = v_u_16[v324]
		v_u_16[v324] = nil
		if v325 then
			v_u_17[v325] = nil
			v_u_36(v325)
		end
		task.defer(p323.Janitor.Destroy, p323.Janitor)
	end
end
v_u_6.ListenToState(function(_, p326)
	-- upvalues: (copy) v_u_10, (copy) v_u_18, (copy) v_u_163, (copy) v_u_78
	if p326 == "Buy Period" then
		v_u_10.RecycleAll()
	end
	if p326 == "Warmup" or p326 == "Buy Period" then
		for v327 in v_u_18 do
			v_u_163(v327, v_u_78(v327))
		end
	end
end)
v_u_2.PlayerRemoving:Connect(function(p328)
	-- upvalues: (copy) v_u_27, (copy) v_u_30, (ref) v_u_96, (copy) v_u_31
	local v329 = ("%*\0"):format(p328.UserId)
	local v330 = {}
	for v331, v332 in v_u_27 do
		local v333 = #v329
		if string.sub(v332, 1, v333) ~= v329 then
			continue
		end
		table.insert(v330, v331)
	end
	for _, v334 in v330 do
		if v_u_30[v334] then
			v_u_96(v334)
		else
			v_u_31[v334] = true
		end
	end
end)
v_u_10.Rig = v_u_5
return v_u_10
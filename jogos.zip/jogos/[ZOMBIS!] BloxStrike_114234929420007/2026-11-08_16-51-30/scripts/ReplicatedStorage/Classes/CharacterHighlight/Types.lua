-- NIGHT Analyzer | ReplicatedStorage.Classes.CharacterHighlight.Types
-- ModuleScript | 3 linhas | 91 bytes | hash b736d770

local v1 = game:GetService("ReplicatedStorage")
require(v1.Database.Custom.Types)
return {}
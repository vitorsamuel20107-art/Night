-- NIGHT Analyzer | ReplicatedStorage.Classes.Character.Classes.CharacterAnimator
-- ModuleScript | 516 linhas | 12863 bytes | hash 7585d6ba

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("RunService")
local v_u_3 = require(v1.Shared.Janitor)
local v_u_4 = require(v1.Components.Common.CharacterResolver)
local v_u_5 = require(v1.Components.Common.SurvivalDowned)
local v_u_6 = require(v1.Components.Common.GetWeaponProperties)
local v_u_7 = v1:WaitForChild("Assets"):WaitForChild("CharacterAnimations")
local v_u_8 = {}
v_u_8.__index = v_u_8
local v_u_9 = {
	["Add Suppressor"] = "AddSuppressor",
	["Remove Suppressor"] = "RemoveSuppressor",
	["Switch Fire Mode"] = "Switch"
}
local v_u_10 = {
	["FR"] = "ForwardRight",
	["FL"] = "ForwardLeft",
	["F"] = "Forward",
	["BR"] = "BackwardRight",
	["BL"] = "BackwardLeft",
	["B"] = "Backward",
	["R"] = "Right",
	["L"] = "Left"
}
local v_u_11 = nil
local function v_u_16() -- name: getMovementAnimationNames
	-- upvalues: (ref) v_u_11, (copy) v_u_7
	if v_u_11 then
		return v_u_11
	end
	local v12 = {
		["CharacterIdle"] = true
	}
	for _, v13 in ipairs({ "Crouch", "Movement" }) do
		local v14 = v_u_7:FindFirstChild(v13)
		if not v14 then
			continue
		end
		for _, v15 in ipairs(v14:GetDescendants()) do
			if not v15:IsA("Animation") then
				continue
			end
			v12[v15.Name] = true
		end
	end
	v_u_11 = v12
	return v12
end
function v_u_8.play(p17, p18, ...) -- name: play
	local v19 = p17.Animations[p18]
	if v19 then
		v19:Play(...)
	end
	return v19
end
function v_u_8.stop(p20, p21, ...) -- name: stop
	local v22 = p20.Animations[p21]
	if v22 and v22.IsPlaying then
		v22:Stop(...)
	end
end
function v_u_8.setBlinded(p23, p24) -- name: setBlinded
	local v25 = p23.Animations.Blinded
	if v25 then
		if p24 then
			if not v25.Looped then
				v25.Looped = true
			end
			if not v25.IsPlaying then
				v25:Play(0.2)
				return
			end
		elseif v25.IsPlaying then
			v25:Stop(0.2)
		end
	end
end
function v_u_8.setDowned(p_u_26, p27) -- name: setDowned
	-- upvalues: (copy) v_u_5, (copy) v_u_2
	if p27 == (p_u_26.DownedConnection ~= nil) or p_u_26.IsDestroyed then
		return
	else
		local v_u_28 = v_u_5.GetPoseJoints(p_u_26.Character)
		if p27 then
			p_u_26:stopAnimations(0.2, "Idle")
			local v29 = p_u_26.Animations.Idle
			if v29 and not v29.IsPlaying then
				v29:Play(0.2)
			end
			local v_u_30 = {}
			local v_u_31 = {}
			local v_u_32 = {}
			for v33, v34 in v_u_28 do
				v_u_30[v33] = v34.Part1.Name
				v_u_31[v33] = v34.Transform
				v_u_32[v33] = v34.Transform
			end
			local v_u_35 = p_u_26.Character:FindFirstChild("RightHand")
			local v_u_36 = os.clock()
			p_u_26.DownedConnection = v_u_2.PreSimulation:Connect(function(p37)
				-- upvalues: (copy) p_u_26, (ref) v_u_5, (copy) v_u_36, (copy) v_u_28, (copy) v_u_30, (copy) v_u_32, (copy) v_u_31, (copy) v_u_35
				local v38 = p_u_26.DownedAimPitch
				local v39
				if v38 and p_u_26.WeaponSlot == v_u_5.LAST_STAND_SLOT then
					v39 = v_u_5.GetAimPose(v38)
				else
					v39 = nil
				end
				local v40 = (os.clock() - v_u_36) / 0.35
				local v41 = math.clamp(v40, 0, 1)
				local v42 = p37 * -12
				local v43 = 1 - math.exp(v42)
				for v44, v45 in v_u_28 do
					local v46 = v_u_30[v44]
					local v47 = v39 and v39[v46] or v_u_5.POSE[v46]
					local v48 = v_u_32
					local v49
					if v41 < 1 then
						v49 = v_u_31[v44]:Lerp(v47, v41 * v41 * (3 - v41 * 2))
					else
						v49 = v_u_32[v44]:Lerp(v47, v43)
					end
					v48[v44] = v49
					v45.Transform = v_u_32[v44]
				end
				local v50
				if v39 and v_u_35 then
					v50 = v_u_35:FindFirstChild("WeaponAttachment")
				else
					v50 = nil
				end
				if v50 and v50:IsA("Motor6D") then
					v50.Transform = CFrame.identity
				end
			end)
		else
			p_u_26.DownedConnection:Disconnect()
			p_u_26.DownedConnection = nil
			for _, v51 in v_u_28 do
				v51.Transform = CFrame.identity
			end
			local v52 = p_u_26.Animations.Idle
			if v52 and not v52.IsPlaying then
				v52:Play(0.2)
			end
		end
	end
end
function v_u_8.setDownedAim(p53, p54) -- name: setDownedAim
	p53.DownedAimPitch = p54
end
function v_u_8.stopAnimations(p55, p56, p57) -- name: stopAnimations
	for v58, v59 in pairs(p55.Animations) do
		if not v59.IsPlaying or v58 == p57 then
			continue
		end
		v59:Stop(p56 or 0)
	end
	p55.CurrentMovementAnimation = nil
	p55.LastMovementAnimationSpeed = nil
	p55.IsJumping = false
end
function v_u_8.freezeAnimations(p60) -- name: freezeAnimations
	for _, v61 in pairs(p60.Animations) do
		if not v61.IsPlaying then
			continue
		end
		v61:AdjustSpeed(0)
	end
end
function v_u_8.adjustAnimationSpeed(p62, p63, p64) -- name: adjustAnimationSpeed
	local v65 = p62.Animations[p63]
	if v65 then
		v65:AdjustSpeed(v65.Length / p64)
	end
end
function v_u_8.unregister(p66, p67) -- name: unregister
	local v68 = p66.Animations[p67]
	if v68 then
		if v68.IsPlaying then
			v68:Stop()
		end
		p66.Animations[p67] = nil
		p66.WeaponAnimationNames[p67] = nil
		v68:Destroy()
	end
end
function v_u_8.register(p69, p70, p71) -- name: register
	local v72 = p69.Animator
	if v72 then
		p69:unregister(p70)
		local v73 = v72.LoadAnimation
		local v74, v75 = pcall(v73, v72, p71)
		if v74 then
			p69.Animations[p70] = v75
		end
	end
end
local function v_u_78(p76) -- name: stopActionAnimations
	for v77 in pairs(p76.WeaponAnimationNames) do
		if v77 == "Idle" then
			continue
		end
		p76:stop(v77, 0.2)
	end
end
function v_u_8.setWeapon(p79, p80, p81, p82) -- name: setWeapon
	-- upvalues: (copy) v_u_6
	if p79.WeaponName == p80 and p79.WeaponIdentifier == p81 then
		local v83 = p79.Animations.Idle
		if v83 and not v83.IsPlaying then
			v83:Play()
		end
		return
	else
		for v84 in pairs(p79.WeaponAnimationNames) do
			p79:unregister(v84)
		end
		p79.WeaponName = p80
		p79.WeaponIdentifier = p81
		p79.WeaponSlot = nil
		if p80 then
			local v85 = v_u_6(p80)
			local v86
			if v85 then
				v86 = v85.Slot
			else
				v86 = v85
			end
			p79.WeaponSlot = v86
			if v85 then
				v85 = v85.CharacterAnimations
			end
			if v85 then
				for _, v87 in ipairs(v85:GetChildren()) do
					if not v87:IsA("Animation") then
						continue
					end
					p79:register(v87.Name, v87)
					p79.WeaponAnimationNames[v87.Name] = true
				end
				if p79.Animations.Idle then
					p79:play("Idle")
				end
				if p82 and p79.Animations.Equip then
					p79:play("Equip", 0.2)
				end
			end
		else
			return
		end
	end
end
local function v_u_94(p88, p89) -- name: resolveActionAnimationName
	-- upvalues: (copy) v_u_9, (copy) v_u_6
	local v90 = p89 == "NoSuppressorShoot" and "Shoot" or p89
	local v91 = v_u_9[v90]
	if v91 then
		return v91
	end
	if v90 == "Swing1" or v90 == "Swing2" then
		return not p88.Animations[v90] and "Swing" or v90
	end
	if v90 == "Shoot" and p88.WeaponName then
		local v92 = v_u_6(p88.WeaponName)
		local v93
		if p88.Player then
			v93 = p88.Player:GetAttribute("ScopeIncrement")
		else
			v93 = nil
		end
		if v92 and (v92.AimingOptions == "AutomaticScope" and (v93 or 0) > 0) then
			return "AimShoot"
		end
	end
	return v90
end
function v_u_8.playAction(p95, p96) -- name: playAction
	-- upvalues: (copy) v_u_78, (copy) v_u_94
	if typeof(p96) == "string" and p96 ~= "" then
		if p96 == "Cancel Plant" or (p96 == "CancelThrow" or p96 == "RevolverChargeCancel") then
			v_u_78(p95)
			return
		else
			local v97 = (p96 == "RevolverChargeStart" or p96 == "RevolverChargeRelease") and "Shoot" or p96
			if v97 == "StartThrow" then
				v_u_78(p95)
				if p95.Animations.StartThrow then
					p95:play("StartThrow", 0.2)
				end
				if p95.Animations.ThrowIdle then
					p95:play("ThrowIdle")
				end
				return
			else
				if v97 == "Throw" then
					p95:stop("StartThrow", 0.2)
					p95:stop("ThrowIdle", 0.2)
				end
				local v98 = v_u_94(p95, v97)
				if v98 and p95.Animations[v98] then
					v_u_78(p95)
					p95:play(v98, 0.2)
				end
			end
		end
	else
		return
	end
end
local function v_u_103(p99) -- name: stopMovementAnimations
	-- upvalues: (copy) v_u_16
	local v100 = v_u_16()
	for v101, v102 in pairs(p99.Animations) do
		if v101 == "Jump" or not (v100[v101] and v102.IsPlaying) then
			continue
		end
		p99:stop(v101, 0.2)
	end
end
local function v_u_112(p104, p105) -- name: getMovementAnimationFromVelocity
	-- upvalues: (copy) v_u_10
	local v106 = p104.RootPart
	if not v106 then
		return nil
	end
	local v107 = p105 * Vector3.new(1, 0, 1)
	if v107.Magnitude < 0.1 then
		return nil
	end
	local v108 = v106.CFrame
	local v109 = v107.Unit
	local v110 = v108.RightVector:Dot(v109)
	local v111 = v108.LookVector:Dot(v109)
	return v_u_10[table.concat({
		v111 > 0.3 and "F" or "",
		v111 < -0.3 and "B" or "",
		v110 < -0.3 and "L" or "",
		v110 > 0.3 and "R" or ""
	})]
end
function v_u_8.noteJumpEvent(p113) -- name: noteJumpEvent
	-- upvalues: (copy) v_u_103
	if not p113.IsDestroyed then
		local v114 = p113.Animations.Jump
		if v114 ~= nil then
			if not v114.Looped then
				v114.Looped = true
			end
			if not v114.IsPlaying then
				p113:play("Jump", 0.2)
			end
		end
		p113.IsJumping = true
		p113.CurrentMovementAnimation = nil
		p113.LastMovementAnimationSpeed = nil
		v_u_103(p113)
	end
end
function v_u_8.updateLocomotion(p115, p116, p117, p118, p119) -- name: updateLocomotion
	-- upvalues: (copy) v_u_103, (copy) v_u_112
	if p115.DownedConnection then
		return
	end
	local v120 = not p119
	if v120 then
		v120 = not p117
	end
	if v120 then
		local v121 = p115.Animations.Jump
		if v121 ~= nil then
			if not v121.Looped then
				v121.Looped = true
			end
			if not v121.IsPlaying then
				p115:play("Jump", 0.2)
			end
		end
		p115.IsJumping = true
		p115.CurrentMovementAnimation = nil
		p115.LastMovementAnimationSpeed = nil
		v_u_103(p115)
		return
	end
	if p115.IsJumping then
		p115:stop("Jump", 0.2)
		p115.IsJumping = false
	end
	local v122 = (p116 * Vector3.new(1, 0, 1)).Magnitude
	local v123 = v_u_112(p115, p116)
	local v124 = p115.Animations.CrouchIdle
	local v125
	if p118 then
		if v122 <= 0.1 or not v123 then
			p115.LastMovementAnimationSpeed = nil
			if v124 and not v124.IsPlaying then
				p115.CurrentMovementAnimation = nil
				v_u_103(p115)
				p115:play("CrouchIdle", 0.2)
			end
			return
		end
		v125 = ("Crouch%*"):format(v123)
		if v124 and v124.IsPlaying then
			p115:stop("CrouchIdle", 0.2)
		end
	else
		if v124 and v124.IsPlaying then
			p115:stop("CrouchIdle", 0.2)
		end
		v125 = v123 or "CharacterIdle"
	end
	local v126
	if v125 then
		v126 = p115.Animations[v125]
	else
		v126 = nil
	end
	local v127 = p115.CurrentMovementAnimation ~= v125
	if v126 and v125 ~= "CharacterIdle" then
		local v128 = v122 / (p118 and 12 or 16)
		local v129 = p115.LastMovementAnimationSpeed
		if v127 or v129 == nil then
			v126:AdjustSpeed(v128)
			p115.LastMovementAnimationSpeed = v128
			if v127 then
				p115.CurrentMovementAnimation = v125
				v_u_103(p115)
			end
			if v126 and not v126.IsPlaying then
				v126:Play(0.15)
			end
			return
		else
			local v130 = v128 - v129
			if math.abs(v130) >= 0.03 then
				v126:AdjustSpeed(v128)
				p115.LastMovementAnimationSpeed = v128
				if v127 then
					p115.CurrentMovementAnimation = v125
					v_u_103(p115)
				end
				if v126 and not v126.IsPlaying then
					v126:Play(0.15)
				end
			else
				if v127 then
					p115.CurrentMovementAnimation = v125
					v_u_103(p115)
				end
				if v126 and not v126.IsPlaying then
					v126:Play(0.15)
				end
			end
		end
	else
		p115.LastMovementAnimationSpeed = nil
		if v127 then
			p115.CurrentMovementAnimation = v125
			v_u_103(p115)
		end
		if v126 and not v126.IsPlaying then
			v126:Play(0.15)
		end
		return
	end
end
function v_u_8.new(p131, p132) -- name: new
	-- upvalues: (copy) v_u_8, (copy) v_u_3, (copy) v_u_4, (copy) v_u_7
	local v133 = v_u_8
	local v134 = setmetatable({}, v133)
	v134.Janitor = v_u_3.new()
	v134.Character = p131
	local v135 = v_u_4.getRootPart(p131)
	local v136 = ("%* has no HumanoidRootPart"):format((p131:GetFullName()))
	v134.RootPart = assert(v135, v136)
	local v137 = v_u_4.getAnimator(p131)
	local v138 = ("%* has no Animator"):format((p131:GetFullName()))
	v134.Animator = assert(v137, v138)
	v134.Animations = {}
	v134.WeaponAnimationNames = {}
	v134.IsJumping = false
	v134.IsDestroyed = false
	if not (p132 and p132.SkipBaseAnimations) then
		local v139 = v_u_7:FindFirstChild("Zombie")
		for _, v140 in ipairs(v_u_7:GetDescendants()) do
			if not v140:IsA("Animation") or v139 and v140:IsDescendantOf(v139) then
				continue
			end
			v134:register(v140.Name, v140)
		end
	end
	return v134
end
function v_u_8.destroy(p141) -- name: destroy
	if not p141.IsDestroyed then
		p141.IsDestroyed = true
		if p141.DownedConnection then
			p141.DownedConnection:Disconnect()
			p141.DownedConnection = nil
		end
		for _, v142 in pairs(p141.Animations) do
			if v142.IsPlaying then
				v142:Stop()
			end
			v142:Destroy()
		end
		table.clear(p141.Animations)
		table.clear(p141.WeaponAnimationNames)
		p141.Janitor:Destroy()
		p141.Animator = nil
		p141.RootPart = nil
		p141.Player = nil
	end
end
return v_u_8
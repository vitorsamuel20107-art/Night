-- NIGHT Analyzer | ReplicatedStorage.Classes.Ragdoll.Configuration.RigConfiguration
-- ModuleScript | 440 linhas | 11907 bytes | hash 7d19a748

local v1 = {
	["BodyParts"] = table.freeze({
		["Head"] = {
			["CanCollide"] = true,
			["Massless"] = false
		},
		["UpperTorso"] = {
			["CanCollide"] = true,
			["Massless"] = false
		},
		["LowerTorso"] = {
			["CanCollide"] = true,
			["Massless"] = false
		},
		["LeftUpperArm"] = {
			["CanCollide"] = false,
			["Massless"] = true
		},
		["LeftLowerArm"] = {
			["CanCollide"] = false,
			["Massless"] = true
		},
		["LeftHand"] = {
			["CanCollide"] = false,
			["Massless"] = true
		},
		["RightUpperArm"] = {
			["CanCollide"] = false,
			["Massless"] = true
		},
		["RightLowerArm"] = {
			["CanCollide"] = false,
			["Massless"] = true
		},
		["RightHand"] = {
			["CanCollide"] = false,
			["Massless"] = true
		},
		["LeftUpperLeg"] = {
			["CanCollide"] = false,
			["Massless"] = true
		},
		["LeftLowerLeg"] = {
			["CanCollide"] = false,
			["Massless"] = true
		},
		["LeftFoot"] = {
			["CanCollide"] = false,
			["Massless"] = true
		},
		["RightUpperLeg"] = {
			["CanCollide"] = false,
			["Massless"] = true
		},
		["RightLowerLeg"] = {
			["CanCollide"] = false,
			["Massless"] = true
		},
		["RightFoot"] = {
			["CanCollide"] = false,
			["Massless"] = true
		}
	})
}
local v2 = CFrame.fromMatrix(Vector3.new(0, 0, 0), Vector3.new(0, 1, 0), Vector3.new(-1, -0, -0), Vector3.new(0, 0, 1))
v1.JointOrder = table.freeze({
	"Neck",
	"Waist",
	"LeftShoulder",
	"RightShoulder",
	"LeftElbow",
	"RightElbow",
	"LeftWrist",
	"RightWrist",
	"LeftHip",
	"RightHip",
	"LeftKnee",
	"RightKnee",
	"LeftAnkle",
	"RightAnkle"
})
local v3 = table.freeze
local v4 = {
	["Neck"] = {
		{
			["Kind"] = "BallSocket",
			["Part0"] = "UpperTorso",
			["Part1"] = "Head",
			["Attachment0"] = nil,
			["Attachment1"] = nil,
			["LimitsEnabled"] = true,
			["UpperAngle"] = 45,
			["TwistLimitsEnabled"] = true,
			["TwistLowerAngle"] = -45,
			["TwistUpperAngle"] = 45,
			["MaxFrictionTorque"] = 30,
			["Radius"] = 0.15,
			["Restitution"] = 0,
			["Attachment0"] = CFrame.new(0, 0.75, 0),
			["Attachment1"] = CFrame.new(0, -0.5, 0)
		}
	},
	["Waist"] = {
		{
			["Kind"] = "BallSocket",
			["Part0"] = "LowerTorso",
			["Part1"] = "UpperTorso",
			["Attachment0"] = nil,
			["Attachment1"] = nil,
			["LimitsEnabled"] = false,
			["UpperAngle"] = 45,
			["TwistLimitsEnabled"] = false,
			["TwistLowerAngle"] = -45,
			["TwistUpperAngle"] = 45,
			["MaxFrictionTorque"] = 0,
			["Radius"] = 0.15,
			["Restitution"] = 0,
			["Attachment0"] = CFrame.new(-0.0322222114, 0.24981612, 0.0711319149) * v2,
			["Attachment1"] = CFrame.new(-0.0344865322, -0.750000119, 0.0731166005) * v2
		},
		{
			["Kind"] = "Hinge",
			["Part0"] = "LowerTorso",
			["Part1"] = "UpperTorso",
			["Attachment0"] = nil,
			["Attachment1"] = nil,
			["LimitsEnabled"] = true,
			["LowerAngle"] = -20,
			["UpperAngle"] = 20,
			["ActuatorType"] = nil,
			["AngularResponsiveness"] = 45,
			["AngularSpeed"] = 35,
			["AngularVelocity"] = 0,
			["MotorMaxAcceleration"] = 500000,
			["MotorMaxTorque"] = 0,
			["ServoMaxTorque"] = 5,
			["TargetAngle"] = 80,
			["Radius"] = 0.15,
			["Restitution"] = 0,
			["Attachment0"] = CFrame.new(0, 0.250000089, 0),
			["Attachment1"] = CFrame.new(0, -0.749815941, 0),
			["ActuatorType"] = Enum.ActuatorType.Servo
		}
	},
	["LeftShoulder"] = {
		{
			["Kind"] = "BallSocket",
			["Part0"] = "LeftUpperArm",
			["Part1"] = "UpperTorso",
			["Attachment0"] = nil,
			["Attachment1"] = nil,
			["LimitsEnabled"] = true,
			["UpperAngle"] = 45,
			["TwistLimitsEnabled"] = true,
			["TwistLowerAngle"] = -180,
			["TwistUpperAngle"] = 180,
			["MaxFrictionTorque"] = 30,
			["Radius"] = 0.15,
			["Restitution"] = 0,
			["Attachment0"] = CFrame.new(0.5, 0.238000005, 0),
			["Attachment1"] = CFrame.new(-1, 0.5, 0)
		}
	},
	["RightShoulder"] = {
		{
			["Kind"] = "BallSocket",
			["Part0"] = "RightUpperArm",
			["Part1"] = "UpperTorso",
			["Attachment0"] = nil,
			["Attachment1"] = nil,
			["LimitsEnabled"] = true,
			["UpperAngle"] = 45,
			["TwistLimitsEnabled"] = true,
			["TwistLowerAngle"] = -180,
			["TwistUpperAngle"] = 180,
			["MaxFrictionTorque"] = 30,
			["Radius"] = 0.15,
			["Restitution"] = 0,
			["Attachment0"] = CFrame.new(-0.5, 0.238000005, 0),
			["Attachment1"] = CFrame.new(1, 0.5, 0)
		}
	},
	["LeftElbow"] = {
		{
			["Kind"] = "Hinge",
			["Part0"] = "LeftLowerArm",
			["Part1"] = "LeftUpperArm",
			["Attachment0"] = nil,
			["Attachment1"] = nil,
			["LimitsEnabled"] = true,
			["LowerAngle"] = -90,
			["UpperAngle"] = 0,
			["ActuatorType"] = nil,
			["AngularResponsiveness"] = 45,
			["AngularSpeed"] = 0,
			["AngularVelocity"] = 0,
			["MotorMaxAcceleration"] = 500000,
			["MotorMaxTorque"] = 0,
			["ServoMaxTorque"] = 0,
			["TargetAngle"] = 0,
			["Radius"] = 0.15,
			["Restitution"] = 0,
			["Attachment0"] = CFrame.new(0, 0.388368845, 0),
			["Attachment1"] = CFrame.new(0, -0.486131668, 0),
			["ActuatorType"] = Enum.ActuatorType.None
		}
	},
	["RightElbow"] = {
		{
			["Kind"] = "Hinge",
			["Part0"] = "RightLowerArm",
			["Part1"] = "RightUpperArm",
			["Attachment0"] = nil,
			["Attachment1"] = nil,
			["LimitsEnabled"] = true,
			["LowerAngle"] = -90,
			["UpperAngle"] = 0,
			["ActuatorType"] = nil,
			["AngularResponsiveness"] = 45,
			["AngularSpeed"] = 0,
			["AngularVelocity"] = 0,
			["MotorMaxAcceleration"] = 500000,
			["MotorMaxTorque"] = 0,
			["ServoMaxTorque"] = 0,
			["TargetAngle"] = 0,
			["Radius"] = 0.15,
			["Restitution"] = 0,
			["Attachment0"] = CFrame.new(0, 0.388368845, 0),
			["Attachment1"] = CFrame.new(0, -0.486131668, 0),
			["ActuatorType"] = Enum.ActuatorType.None
		}
	},
	["LeftWrist"] = {
		{
			["Kind"] = "Hinge",
			["Part0"] = "LeftHand",
			["Part1"] = "LeftLowerArm",
			["Attachment0"] = nil,
			["Attachment1"] = nil,
			["LimitsEnabled"] = true,
			["LowerAngle"] = -0.0001,
			["UpperAngle"] = 0,
			["ActuatorType"] = nil,
			["AngularResponsiveness"] = 45,
			["AngularSpeed"] = 0,
			["AngularVelocity"] = 0,
			["MotorMaxAcceleration"] = 500000,
			["MotorMaxTorque"] = 0,
			["ServoMaxTorque"] = 0,
			["TargetAngle"] = 0,
			["Radius"] = 0.15,
			["Restitution"] = 0,
			["Attachment0"] = CFrame.new(0, 0.125, 0),
			["Attachment1"] = CFrame.new(0, -0.38786912, 0),
			["ActuatorType"] = Enum.ActuatorType.None
		}
	},
	["RightWrist"] = {
		{
			["Kind"] = "Hinge",
			["Part0"] = "RightHand",
			["Part1"] = "RightLowerArm",
			["Attachment0"] = nil,
			["Attachment1"] = nil,
			["LimitsEnabled"] = true,
			["LowerAngle"] = -0.0001,
			["UpperAngle"] = 0,
			["ActuatorType"] = nil,
			["AngularResponsiveness"] = 45,
			["AngularSpeed"] = 0,
			["AngularVelocity"] = 0,
			["MotorMaxAcceleration"] = 500000,
			["MotorMaxTorque"] = 0,
			["ServoMaxTorque"] = 0,
			["TargetAngle"] = 0,
			["Radius"] = 0.15,
			["Restitution"] = 0,
			["Attachment0"] = CFrame.new(0, 0.125, 0),
			["Attachment1"] = CFrame.new(0, -0.38786912, 0),
			["ActuatorType"] = Enum.ActuatorType.None
		}
	},
	["LeftHip"] = {
		{
			["Kind"] = "BallSocket",
			["Part0"] = "LeftUpperLeg",
			["Part1"] = "LowerTorso",
			["Attachment0"] = nil,
			["Attachment1"] = nil,
			["LimitsEnabled"] = true,
			["UpperAngle"] = 45,
			["TwistLimitsEnabled"] = true,
			["TwistLowerAngle"] = -90,
			["TwistUpperAngle"] = 90,
			["MaxFrictionTorque"] = 30,
			["Radius"] = 0.15,
			["Restitution"] = 0,
			["Attachment0"] = CFrame.new(0, 0.4120000005, 0),
			["Attachment1"] = CFrame.new(-0.5, -0.25, 0)
		}
	},
	["RightHip"] = {
		{
			["Kind"] = "BallSocket",
			["Part0"] = "RightUpperLeg",
			["Part1"] = "LowerTorso",
			["Attachment0"] = nil,
			["Attachment1"] = nil,
			["LimitsEnabled"] = true,
			["UpperAngle"] = 45,
			["TwistLimitsEnabled"] = true,
			["TwistLowerAngle"] = -90,
			["TwistUpperAngle"] = 90,
			["MaxFrictionTorque"] = 30,
			["Radius"] = 0.15,
			["Restitution"] = 0,
			["Attachment0"] = CFrame.new(0, 0.4120000005, 0),
			["Attachment1"] = CFrame.new(0.5, -0.25, 0)
		}
	},
	["LeftKnee"] = {
		{
			["Kind"] = "Hinge",
			["Part0"] = "LeftLowerLeg",
			["Part1"] = "LeftUpperLeg",
			["Attachment0"] = nil,
			["Attachment1"] = nil,
			["LimitsEnabled"] = true,
			["LowerAngle"] = 90,
			["UpperAngle"] = 0,
			["ActuatorType"] = nil,
			["AngularResponsiveness"] = 45,
			["AngularSpeed"] = 60,
			["AngularVelocity"] = 0,
			["MotorMaxAcceleration"] = 500000,
			["MotorMaxTorque"] = 0,
			["ServoMaxTorque"] = 0,
			["TargetAngle"] = 80,
			["Radius"] = 0.15,
			["Restitution"] = 0,
			["Attachment0"] = CFrame.new(0, 0.462723136, 0),
			["Attachment1"] = CFrame.new(0, -0.4120000005, 0),
			["ActuatorType"] = Enum.ActuatorType.None
		}
	},
	["RightKnee"] = {
		{
			["Kind"] = "Hinge",
			["Part0"] = "RightLowerLeg",
			["Part1"] = "RightUpperLeg",
			["Attachment0"] = nil,
			["Attachment1"] = nil,
			["LimitsEnabled"] = true,
			["LowerAngle"] = 90,
			["UpperAngle"] = 0,
			["ActuatorType"] = nil,
			["AngularResponsiveness"] = 45,
			["AngularSpeed"] = 60,
			["AngularVelocity"] = 0,
			["MotorMaxAcceleration"] = 500000,
			["MotorMaxTorque"] = 0,
			["ServoMaxTorque"] = 0,
			["TargetAngle"] = 80,
			["Radius"] = 0.15,
			["Restitution"] = 0,
			["Attachment0"] = CFrame.new(0, 0.462723136, 0),
			["Attachment1"] = CFrame.new(0, -0.4120000005, 0),
			["ActuatorType"] = Enum.ActuatorType.None
		}
	},
	["LeftAnkle"] = {
		{
			["Kind"] = "Hinge",
			["Part0"] = "LeftFoot",
			["Part1"] = "LeftLowerLeg",
			["Attachment0"] = nil,
			["Attachment1"] = nil,
			["LimitsEnabled"] = true,
			["LowerAngle"] = 0,
			["UpperAngle"] = 0,
			["ActuatorType"] = nil,
			["AngularResponsiveness"] = 45,
			["AngularSpeed"] = 0,
			["AngularVelocity"] = 0,
			["MotorMaxAcceleration"] = 500000,
			["MotorMaxTorque"] = 0,
			["ServoMaxTorque"] = 0,
			["TargetAngle"] = 0,
			["Radius"] = 0.15,
			["Restitution"] = 0,
			["Attachment0"] = CFrame.new(0, 0.125, 0),
			["Attachment1"] = CFrame.new(0, -0.463, 0),
			["ActuatorType"] = Enum.ActuatorType.None
		}
	},
	["RightAnkle"] = {
		{
			["Kind"] = "Hinge",
			["Part0"] = "RightFoot",
			["Part1"] = "RightLowerLeg",
			["Attachment0"] = nil,
			["Attachment1"] = nil,
			["LimitsEnabled"] = true,
			["LowerAngle"] = 0,
			["UpperAngle"] = 0,
			["ActuatorType"] = nil,
			["AngularResponsiveness"] = 45,
			["AngularSpeed"] = 0,
			["AngularVelocity"] = 0,
			["MotorMaxAcceleration"] = 500000,
			["MotorMaxTorque"] = 0,
			["ServoMaxTorque"] = 0,
			["TargetAngle"] = 0,
			["Radius"] = 0.15,
			["Restitution"] = 0,
			["Attachment0"] = CFrame.new(0, 0.125, 0),
			["Attachment1"] = CFrame.new(0, -0.463, 0),
			["ActuatorType"] = Enum.ActuatorType.None
		}
	}
}
v1.Joints = v3(v4)
local v5 = CFrame.new(0, 0, 0, 0.535461783, -0.0941229165, 0.839298308, -0.0081747584, 0.9931463, 0.116591692, -0.844519913, -0.0692914277, 0.53102243)
local v6 = CFrame.new(0, 0, 0, -0.535461783, 0.0941229165, -0.839298308, -0.0081747584, 0.9931463, 0.116591692, 0.844519913, 0.0692914277, -0.53102243)
v1.Colliders = table.freeze({
	["Head"] = CFrame.new(-0.0200119019, 0.124855995, 0.0889816284) * v5,
	["LeftFoot"] = CFrame.new(-0.0200119019, 0.124856293, 0.0892562866) * v5,
	["LeftHand"] = CFrame.new(-0.0200119019, 0.12490201, 0.0892562866) * v5,
	["LeftLowerArm"] = CFrame.new(-0.0200119019, 0.048927784, 0.0892562866) * v5,
	["LeftLowerLeg"] = CFrame.new(-0.0200119019, 0.225759506, 0.0892562866) * v5,
	["LeftUpperArm"] = CFrame.new(0.0200119019, 0.456183195, -0.0892562866) * v6,
	["RightFoot"] = CFrame.new(-0.0200119019, 0.124856174, 0.0892562866) * v5,
	["RightHand"] = CFrame.new(-0.0200119019, 0.12490201, 0.0892562866) * v5,
	["RightLowerArm"] = CFrame.new(-0.0200119019, 0.048927784, 0.0892562866) * v5,
	["RightLowerLeg"] = CFrame.new(-0.0200119019, 0.225759506, 0.0892562866) * v5,
	["RightUpperArm"] = CFrame.new(0.0200119019, 0.456183195, -0.0892562866) * v6,
	["UpperTorso"] = CFrame.new(-0.0200119019, 0.124873638, 0.0892562866) * v5
})
v1.ColliderSize = Vector3.new(0.5, 0.5, 0.5)
return v1
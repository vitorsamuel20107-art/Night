-- NIGHT Analyzer | ReplicatedStorage.Classes.Ragdoll.Configuration.R6Configuration
-- ModuleScript | 65 linhas | 1380 bytes | hash 5ac570d0

local v1 = {
	["BodyParts"] = table.freeze({
		["Head"] = {
			["CanCollide"] = true,
			["Massless"] = false
		},
		["UpperTorso"] = {
			["CanCollide"] = true,
			["Massless"] = false
		},
		["LeftUpperArm"] = {
			["CanCollide"] = true,
			["Massless"] = false
		},
		["RightUpperArm"] = {
			["CanCollide"] = true,
			["Massless"] = false
		},
		["LeftUpperLeg"] = {
			["CanCollide"] = true,
			["Massless"] = false
		},
		["RightUpperLeg"] = {
			["CanCollide"] = true,
			["Massless"] = false
		}
	}),
	["JointOrder"] = table.freeze({
		"Neck",
		"Left Shoulder",
		"Right Shoulder",
		"Left Hip",
		"Right Hip"
	})
}
local function v4(p2, p3) -- name: socket
	return {
		{
			["Kind"] = "BallSocket",
			["Part0"] = "UpperTorso",
			["Part1"] = nil,
			["FromMotor"] = true,
			["LimitsEnabled"] = true,
			["UpperAngle"] = nil,
			["TwistLimitsEnabled"] = false,
			["TwistLowerAngle"] = -45,
			["TwistUpperAngle"] = 45,
			["MaxFrictionTorque"] = 20,
			["Radius"] = 0.15,
			["Restitution"] = 0,
			["Part1"] = p2,
			["UpperAngle"] = p3
		}
	}
end
v1.Joints = table.freeze({
	["Neck"] = v4("Head", 40),
	["Left Shoulder"] = v4("LeftUpperArm", 100),
	["Right Shoulder"] = v4("RightUpperArm", 100),
	["Left Hip"] = v4("LeftUpperLeg", 70),
	["Right Hip"] = v4("RightUpperLeg", 70)
})
v1.Colliders = table.freeze({})
v1.ColliderSize = Vector3.new(0.5, 0.5, 0.5)
return v1
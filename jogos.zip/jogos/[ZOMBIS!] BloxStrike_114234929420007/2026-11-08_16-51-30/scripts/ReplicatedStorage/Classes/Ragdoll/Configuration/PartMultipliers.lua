-- NIGHT Analyzer | ReplicatedStorage.Classes.Ragdoll.Configuration.PartMultipliers
-- ModuleScript | 18 linhas | 275 bytes | hash 9b116770

return table.freeze({
	["Head"] = {
		["Minimum"] = 55,
		["Maximum"] = 65
	},
	["HumanoidRootPart"] = {
		["Minimum"] = 35,
		["Maximum"] = 50
	},
	["UpperTorso"] = {
		["Minimum"] = 35,
		["Maximum"] = 50
	},
	["LowerTorso"] = {
		["Minimum"] = 35,
		["Maximum"] = 50
	}
})
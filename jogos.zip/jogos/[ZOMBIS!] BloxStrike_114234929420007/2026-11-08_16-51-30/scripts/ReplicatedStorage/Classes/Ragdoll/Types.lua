-- NIGHT Analyzer | ReplicatedStorage.Classes.Ragdoll.Types
-- ModuleScript | 4 linhas | 119 bytes | hash d7c30328

local v1 = game:GetService("ReplicatedStorage")
require(v1.Database.Custom.Types)
require(v1.Packages.Signal)
return {}
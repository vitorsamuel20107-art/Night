-- NIGHT Analyzer | ReplicatedStorage.Classes.Ragdoll.Rig
-- ModuleScript | 903 linhas | 23697 bytes | hash 70a22028

local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = require(v2.Components.Common.GetWeaponProperties)
local v_u_5 = require(script.Parent.Configuration.PartMultipliers)
local v_u_6 = require(script.Parent.Configuration.RigConfiguration)
local v_u_7 = require(script.Parent.Configuration.R6Configuration)
local v_u_8 = {}
local v_u_9 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_10 = setmetatable({}, {
	["__mode"] = "k"
})
function v_u_8.IsR6(p11) -- name: IsR6
	local v12 = p11:FindFirstChild("HumanoidRootPart")
	local v13
	if v12 == nil then
		v13 = false
	else
		v13 = v12:FindFirstChild("RootJoint") ~= nil
	end
	return v13
end
local function v_u_19(p14, p15) -- name: isBodyMotor
	local v16 = p15.Part0
	local v17 = p15.Part1
	local v18 = v16 ~= nil and (v17 ~= nil and (v16.Parent == p14 and v17.Parent == p14)) and not (v16:HasTag("CharacterAccessory") or v17:HasTag("CharacterAccessory"))
	if v18 then
		if v16.Name == "CameraPart" then
			v18 = false
		else
			v18 = v17.Name ~= "CameraPart"
		end
	end
	return v18
end
local function v_u_26(p20) -- name: collectBodyMotors
	-- upvalues: (copy) v_u_8, (copy) v_u_7, (copy) v_u_6, (copy) v_u_19
	local v21
	if v_u_8.IsR6(p20) then
		v21 = v_u_7
	else
		v21 = v_u_6
	end
	local v22 = {}
	for _, v23 in p20:GetDescendants() do
		if not v23:IsA("Motor6D") or (v21.Joints[v23.Name] == nil or (v22[v23.Name] ~= nil or not v_u_19(p20, v23))) then
			continue
		end
		v22[v23.Name] = v23
	end
	local v24 = {}
	for _, v25 in v21.JointOrder do
		if v22[v25] then
			continue
		end
		table.insert(v24, v25)
	end
	return v22, v24
end
local function v_u_31(p27) -- name: waitForBodyMotors
	-- upvalues: (copy) v_u_26
	local v28 = os.clock() + 3
	debug.profilebegin("Ragdoll.Prepare.ResolveMotors")
	local v29, v30 = v_u_26(p27)
	debug.profileend()
	while #v30 > 0 and (p27.Parent and os.clock() < v28) do
		task.wait(0.05)
		debug.profilebegin("Ragdoll.Prepare.ResolveMotors")
		v29, v30 = v_u_26(p27)
		debug.profileend()
	end
	return v29, v30
end
local function v_u_41(p32, p33, p34) -- name: preparedPartPhysics
	local v35 = p34:HasTag("CharacterAccessory")
	local v36 = p34.Name == "HumanoidRootPart" and true or p34.Name == "CameraPart"
	local v37 = p34:GetAttribute("RagdollCollider") == true
	local v38
	if p34.Parent == p32 then
		v38 = p33.BodyParts[p34.Name]
	else
		v38 = nil
	end
	local v39 = (v37 or (v35 or (v36 or v38 == nil))) and true or v38.Massless
	local v40 = not v37 and (v38 ~= nil and v38.CanCollide)
	if v40 then
		v40 = not v35
		if v40 then
			v40 = not v36
		end
	end
	return v39, v40
end
local function v_u_48(p42, p43, p44) -- name: configurePreparedBodyPart
	-- upvalues: (copy) v_u_41
	local v45, v46 = v_u_41(p42, p43, p44)
	local v47
	if p44.Parent == p42 then
		v47 = not p44:HasTag("CharacterAccessory")
	else
		v47 = false
	end
	if p44.Anchored ~= v47 then
		p44.Anchored = v47
	end
	p44.CanCollide = false
	p44.CanQuery = false
	p44.CanTouch = false
	if p44.CollisionGroup ~= "Debris" then
		p44.CollisionGroup = "Debris"
	end
	if p44.Massless ~= v45 then
		p44.Massless = v45
	end
	return v46
end
local function v_u_51(p49) -- name: enablePreparedConstraints
	for _, v50 in p49:GetDescendants() do
		if not v50:IsA("Constraint") then
			continue
		end
		v50.Enabled = true
	end
end
local function v_u_70(p52, p53, p54, p55, p56, p57) -- name: createConstraint
	local v58 = p52:FindFirstChild(p56.Part0)
	if not (v58 and v58:IsA("BasePart")) then
		v58 = nil
	end
	local v59 = p52:FindFirstChild(p56.Part1)
	if not (v59 and v59:IsA("BasePart")) then
		v59 = nil
	end
	if v58 and v59 then
		local v60 = ("Ragdoll_%*_%*"):format(p54, p55)
		local v61 = p56.FromMotor == true
		local v62 = ("%*_0"):format(v60)
		local v63
		if v61 then
			v63 = p57.C0
		else
			v63 = p56.Attachment0
		end
		local v64 = Instance.new("Attachment")
		v64.Name = v62
		v64.CFrame = v63
		v64.Parent = v58
		local v65 = ("%*_1"):format(v60)
		local v66
		if v61 then
			v66 = p57.C1
		else
			v66 = p56.Attachment1
		end
		local v67 = Instance.new("Attachment")
		v67.Name = v65
		v67.CFrame = v66
		v67.Parent = v59
		local v68 = p56.Kind == "BallSocket"
		local v69 = Instance.new(v68 and "BallSocketConstraint" or "HingeConstraint")
		v69.Name = "Constraint"
		v69.Attachment0 = v64
		v69.Attachment1 = v67
		v69.LimitsEnabled = p56.LimitsEnabled
		if v68 then
			v69.UpperAngle = p56.UpperAngle
			v69.TwistLimitsEnabled = p56.TwistLimitsEnabled
			v69.TwistLowerAngle = p56.TwistLowerAngle
			v69.TwistUpperAngle = p56.TwistUpperAngle
			v69.MaxFrictionTorque = p56.MaxFrictionTorque
		else
			v69.LowerAngle = p56.LowerAngle
			v69.UpperAngle = p56.UpperAngle
			v69.ActuatorType = p56.ActuatorType
			v69.AngularResponsiveness = p56.AngularResponsiveness
			v69.AngularSpeed = p56.AngularSpeed
			v69.AngularVelocity = p56.AngularVelocity
			v69.MotorMaxAcceleration = p56.MotorMaxAcceleration
			v69.MotorMaxTorque = p56.MotorMaxTorque
			v69.ServoMaxTorque = p56.ServoMaxTorque
			v69.TargetAngle = p56.TargetAngle
		end
		v69.Radius = p56.Radius
		v69.Restitution = p56.Restitution
		v69.Enabled = false
		v69.Parent = p53
	end
end
local function v_u_79(p71) -- name: createColliders
	-- upvalues: (copy) v_u_8, (copy) v_u_7, (copy) v_u_6
	local v72 = Instance.new("Folder")
	v72.Name = "RagdollColliders"
	local v73
	if v_u_8.IsR6(p71) then
		v73 = v_u_7
	else
		v73 = v_u_6
	end
	for v74, v75 in v73.Colliders do
		local v76 = p71:FindFirstChild(v74)
		if not (v76 and v76:IsA("BasePart")) then
			v76 = nil
		end
		if not v76 then
			continue
		end
		local v77 = Instance.new("Part")
		v77.Name = ("Collider_%*"):format(v74)
		v77.Shape = Enum.PartType.Ball
		v77.Size = v73.ColliderSize
		v77.Transparency = 1
		v77.Anchored = false
		v77.CanCollide = false
		v77.CanQuery = false
		v77.CanTouch = false
		v77.Massless = true
		v77.CFrame = v76.CFrame * v75
		v77:SetAttribute("RagdollCollider", true)
		v77.Parent = v72
		local v78 = Instance.new("WeldConstraint")
		v78.Name = "Weld"
		v78.Part0 = v77
		v78.Part1 = v76
		v78.Parent = v77
	end
	v72.Parent = p71
	return v72
end
function v_u_8.IsPrepared(p80) -- name: IsPrepared
	local v81 = p80:FindFirstChild("RagdollJoints")
	local v82 = p80:FindFirstChild("RagdollColliders")
	local v83 = p80:GetAttribute("RagdollReady") == true and (v81 ~= nil and v81:IsA("Folder"))
	if v83 then
		if v82 == nil then
			v83 = false
		else
			v83 = v82:IsA("Folder")
		end
	end
	return v83
end
local function v_u_115(p_u_84) -- name: prepare
	-- upvalues: (copy) v_u_8, (copy) v_u_31, (copy) v_u_7, (copy) v_u_6, (copy) v_u_70, (copy) v_u_79
	if v_u_8.IsPrepared(p_u_84) then
		return true
	end
	local v_u_85, v86 = v_u_31(p_u_84)
	if #v86 > 0 then
		local v87 = table.concat(v86, ", ")
		warn((("[Ragdoll] Skipping preparation for %*; missing body motors: %*"):format(p_u_84:GetFullName(), v87)))
		return false
	end
	local function v112()
		-- upvalues: (copy) p_u_84, (ref) v_u_8, (ref) v_u_7, (ref) v_u_6, (copy) v_u_85, (ref) v_u_70, (ref) v_u_79
		local function v90()
			-- upvalues: (ref) p_u_84
			for _, v88 in { "RagdollJoints", "RagdollColliders" } do
				local v89 = p_u_84:FindFirstChild(v88)
				if not v89 then
					continue
				end
				v89:Destroy()
			end
		end
		debug.profilebegin("Ragdoll.Prepare.ClearStale")
		local v91, v92 = pcall(v90)
		debug.profileend()
		if not v91 then
			error(v92, 0)
		end
		local function v103()
			-- upvalues: (ref) p_u_84, (ref) v_u_8, (ref) v_u_7, (ref) v_u_6, (ref) v_u_85, (ref) v_u_70
			local v93 = Instance.new("Folder")
			v93.Name = "RagdollJoints"
			v93.Parent = p_u_84
			local v94 = p_u_84
			local v95
			if v_u_8.IsR6(v94) then
				v95 = v_u_7
			else
				v95 = v_u_6
			end
			local v96 = 0
			for _, v97 in v95.JointOrder do
				local v98 = v_u_85[v97]
				v96 = v96 + 1
				local v99 = Instance.new("Folder")
				v99.Name = string.format("%02d_%s", v96, v98.Name)
				v99.Parent = v93
				local v100 = Instance.new("ObjectValue")
				v100.Name = "Motor"
				v100.Value = v98
				v100.Parent = v99
				for v101, v102 in v95.Joints[v97] do
					v_u_70(p_u_84, v99, v96, v101, v102, v98)
				end
			end
			return v93
		end
		debug.profilebegin("Ragdoll.Prepare.Joints")
		local v104, v105 = pcall(v103)
		debug.profileend()
		if not v104 then
			error(v105, 0)
		end
		local function v106()
			-- upvalues: (ref) v_u_79, (ref) p_u_84
			v_u_79(p_u_84)
		end
		debug.profilebegin("Ragdoll.Prepare.Colliders")
		local v107, v108 = pcall(v106)
		debug.profileend()
		if not v107 then
			error(v108, 0)
		end
		local function v109()
			-- upvalues: (ref) p_u_84
			p_u_84:SetAttribute("RagdollReady", true)
		end
		debug.profilebegin("Ragdoll.Prepare.Finalize")
		local v110, v111 = pcall(v109)
		debug.profileend()
		if not v110 then
			error(v111, 0)
		end
		return true
	end
	debug.profilebegin("Ragdoll.Prepare.Construct")
	local v113, v114 = pcall(v112)
	debug.profileend()
	if not v113 then
		error(v114, 0)
	end
	return v114
end
function v_u_8.Prepare(p116) -- name: Prepare
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_115
	if v_u_8.IsPrepared(p116) then
		return true
	end
	if v_u_9[p116] then
		task.wait()
		if v_u_8.IsPrepared(p116) then
			return true
		end
		if p116.Parent then
			continue
		end
		return false
	end
	v_u_9[p116] = true
	local v117 = v_u_115
	local v118, v119 = pcall(v117, p116)
	v_u_9[p116] = nil
	if not v118 then
		error(v119, 0)
	end
	return v119
end
function v_u_8.CapturePose(p120) -- name: CapturePose
	local v121 = {}
	for _, v122 in p120:GetChildren() do
		if not v122:IsA("BasePart") or v122:HasTag("CharacterAccessory") then
			continue
		end
		v121[v122.Name] = v122.CFrame
	end
	return v121
end
function v_u_8.MatchPreparedMass(p123) -- name: MatchPreparedMass
	-- upvalues: (copy) v_u_8, (copy) v_u_7, (copy) v_u_6, (copy) v_u_41
	if v_u_8.IsPrepared(p123) then
		local v124
		if v_u_8.IsR6(p123) then
			v124 = v_u_7
		else
			v124 = v_u_6
		end
		for _, v125 in p123:QueryDescendants("BasePart") do
			local v126 = v_u_41(p123, v124, v125)
			if v125.Massless == v126 then
				continue
			end
			v125.Massless = v126
		end
	end
end
function v_u_8.StagePrepared(p_u_127) -- name: StagePrepared
	-- upvalues: (copy) v_u_8, (copy) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_48, (copy) v_u_51
	if not v_u_8.IsPrepared(p_u_127) then
		return false
	end
	if p_u_127:GetAttribute("RagdollStaged") == true and v_u_10[p_u_127] then
		return true
	end
	local v_u_128 = {}
	local v_u_129 = {}
	local v_u_130
	if v_u_8.IsR6(p_u_127) then
		v_u_130 = v_u_7
	else
		v_u_130 = v_u_6
	end
	local function v135()
		-- upvalues: (copy) p_u_127, (ref) v_u_48, (copy) v_u_130, (copy) v_u_129, (copy) v_u_128
		for _, v131 in p_u_127:QueryDescendants("BasePart") do
			local v132 = v_u_48(p_u_127, v_u_130, v131)
			v131.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
			v131.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
			if v132 then
				local v133 = v_u_129
				table.insert(v133, v131)
			end
			if v131.Parent ~= p_u_127 or v131:HasTag("CharacterAccessory") then
				continue
			end
			local v134 = v_u_128
			table.insert(v134, v131)
		end
	end
	debug.profilebegin("Ragdoll.Prepare.StageParts")
	local v136, v137 = pcall(v135)
	debug.profileend()
	if not v136 then
		error(v137, 0)
	end
	local v138 = {}
	local v_u_139 = {}
	for v140, v141 in v_u_128 do
		v138[v140] = v141.CFrame
	end
	local function v147()
		-- upvalues: (copy) p_u_127, (copy) v_u_139, (ref) v_u_51
		local v142 = p_u_127:FindFirstChild("RagdollJoints")
		for _, v143 in v142:GetChildren() do
			local v144 = v143:FindFirstChild("Motor")
			local v145
			if v144 and v144:IsA("ObjectValue") then
				v145 = v144.Value
			else
				v145 = nil
			end
			if not (v145 and v145:IsA("Motor6D")) then
				v145 = nil
			end
			if not v145 then
				continue
			end
			local v146 = v_u_139
			table.insert(v146, v145)
		end
		v_u_51(v142)
	end
	debug.profilebegin("Ragdoll.Prepare.EnableConstraints")
	local v148, v149 = pcall(v147)
	debug.profileend()
	if not v148 then
		error(v149, 0)
	end
	v_u_10[p_u_127] = {
		["BodyParts"] = v_u_128,
		["CollidingParts"] = v_u_129,
		["Motors"] = v_u_139,
		["PoseCFrames"] = v138
	}
	p_u_127:SetAttribute("RagdollStaged", true)
	return true
end
function v_u_8.StagePooled(p150, p151) -- name: StagePooled
	-- upvalues: (copy) v_u_8, (copy) v_u_7, (copy) v_u_6, (copy) v_u_41, (copy) v_u_10
	if not v_u_8.IsPrepared(p150) then
		return false
	end
	local v152 = {}
	local v153 = {}
	local v154 = {}
	local v155
	if v_u_8.IsR6(p150) then
		v155 = v_u_7
	else
		v155 = v_u_6
	end
	for _, v156 in p150:QueryDescendants("BasePart") do
		v152[#v152 + 1] = v156
		local _, v157 = v_u_41(p150, v155, v156)
		if v157 then
			v154[#v154 + 1] = v156
		end
		if v156.Parent ~= p150 or v156:HasTag("CharacterAccessory") then
			continue
		end
		v153[#v153 + 1] = v156
	end
	local v158 = {}
	local v159 = {}
	for _, v160 in p150:FindFirstChild("RagdollJoints"):GetChildren() do
		local v161 = v160:FindFirstChild("Motor")
		local v162
		if v161 and v161:IsA("ObjectValue") then
			v162 = v161.Value
		else
			v162 = nil
		end
		if not (v162 and v162:IsA("Motor6D")) then
			v162 = nil
		end
		local v163
		if v162 == nil or p151 == nil then
			v163 = false
		else
			v163 = p151[v162.Name] == true
		end
		if v162 and not v163 then
			v159[#v159 + 1] = v162
		end
		for _, v164 in v160:GetDescendants() do
			if not v164:IsA("Constraint") then
				continue
			end
			v164.Enabled = false
			if v163 then
				continue
			end
			v158[#v158 + 1] = v164
		end
	end
	v_u_10[p150] = {
		["BodyParts"] = v153,
		["CollidingParts"] = v154,
		["Motors"] = v159,
		["PoseCFrames"] = {},
		["Pooled"] = {
			["Parts"] = v152,
			["Constraints"] = v158
		}
	}
	p150:SetAttribute("RagdollStaged", true)
	return true
end
function v_u_8.ResetPrepared(p_u_165) -- name: ResetPrepared
	-- upvalues: (copy) v_u_8, (copy) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_48, (copy) v_u_51
	if not v_u_8.IsPrepared(p_u_165) then
		return false
	end
	if not (v_u_10[p_u_165] or v_u_8.StagePrepared(p_u_165)) then
		return false
	end
	local v_u_166 = v_u_10[p_u_165]
	local v_u_167
	if v_u_8.IsR6(p_u_165) then
		v_u_167 = v_u_7
	else
		v_u_167 = v_u_6
	end
	local function v169()
		-- upvalues: (copy) p_u_165, (ref) v_u_48, (copy) v_u_167
		for _, v168 in p_u_165:QueryDescendants("BasePart") do
			v_u_48(p_u_165, v_u_167, v168)
			v168.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
			v168.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
		end
	end
	debug.profilebegin("Ragdoll.Pool.ResetParts")
	local v170, v171 = pcall(v169)
	debug.profileend()
	if not v170 then
		error(v171, 0)
	end
	local function v174()
		-- upvalues: (copy) v_u_166, (copy) p_u_165, (ref) v_u_51
		for _, v172 in v_u_166.Motors do
			if not v172.Parent then
				continue
			end
			v172.Enabled = true
		end
		local v173 = p_u_165:FindFirstChild("RagdollJoints")
		if v173 and v173:IsA("Folder") then
			v_u_51(v173)
		end
	end
	debug.profilebegin("Ragdoll.Pool.ResetJoints")
	local v175, v176 = pcall(v174)
	debug.profileend()
	if not v175 then
		error(v176, 0)
	end
	return true
end
function v_u_8.Activate(p_u_177, p_u_178, p_u_179, p_u_180, p_u_181) -- name: Activate
	-- upvalues: (copy) v_u_8, (copy) v_u_10, (copy) v_u_1, (copy) v_u_3
	if p_u_177:GetAttribute("Ragdolled") == true then
		return false
	end
	if not (v_u_8.IsPrepared(p_u_177) or v_u_8.Prepare(p_u_177)) then
		return false
	end
	if not (v_u_10[p_u_177] or v_u_8.StagePrepared(p_u_177)) then
		return false
	end
	local v_u_182 = v_u_10[p_u_177]
	local v_u_183 = v_u_182.BodyParts
	debug.profilebegin("Ragdoll.Activate.DisableMotors")
	local v185, v186 = pcall(function()
		-- upvalues: (copy) v_u_182
		for _, v184 in v_u_182.Motors do
			v184.Enabled = false
		end
	end)
	debug.profileend()
	if not v185 then
		error(v186, 0)
	end
	if p_u_178 then
		debug.profilebegin("Ragdoll.Activate.ApplyPose")
		local v191, v192 = pcall(function()
			-- upvalues: (copy) v_u_183, (copy) v_u_182, (copy) p_u_178, (copy) p_u_177
			for v187, v188 in v_u_183 do
				v_u_182.PoseCFrames[v187] = p_u_178[v188.Name] or v188.CFrame
			end
			if p_u_177:IsDescendantOf(workspace) then
				workspace:BulkMoveTo(v_u_183, v_u_182.PoseCFrames, Enum.BulkMoveMode.FireCFrameChanged)
			else
				for v189, v190 in v_u_183 do
					v190.CFrame = v_u_182.PoseCFrames[v189]
				end
			end
		end)
		debug.profileend()
		if not v191 then
			error(v192, 0)
		end
	end
	local v_u_193 = v_u_182.Pooled
	if v_u_193 then
		debug.profilebegin("Ragdoll.Activate.ReleasePooled")
		local v198, v199 = pcall(function()
			-- upvalues: (copy) v_u_193, (copy) v_u_182, (copy) v_u_183
			for _, v194 in v_u_193.Constraints do
				v194.Enabled = true
			end
			for _, v195 in v_u_193.Parts do
				if not v195.CanQuery then
					continue
				end
				v195.CanQuery = false
			end
			for _, v196 in v_u_182.CollidingParts do
				if v196.CollisionGroup ~= "Debris" then
					v196.CollisionGroup = "Debris"
				end
				v196.CanCollide = true
			end
			for _, v197 in v_u_183 do
				if not v197.Anchored then
					continue
				end
				v197.Anchored = false
			end
		end)
		debug.profileend()
		if not v198 then
			error(v199, 0)
		end
	else
		debug.profilebegin("Ragdoll.Activate.ReleaseParts")
		local v202, v203 = pcall(function()
			-- upvalues: (copy) v_u_182, (copy) v_u_183
			for _, v200 in v_u_182.CollidingParts do
				v200.CanCollide = true
			end
			for _, v201 in v_u_183 do
				v201.Anchored = false
			end
		end)
		debug.profileend()
		if not v202 then
			error(v203, 0)
		end
	end
	debug.profilebegin("Ragdoll.Activate.ApplyVelocity")
	local v205, v206 = pcall(function()
		-- upvalues: (copy) v_u_183, (copy) p_u_179
		for _, v204 in v_u_183 do
			v204.AssemblyLinearVelocity = p_u_179 or Vector3.new(0, 0, 0)
			v204.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
		end
	end)
	debug.profileend()
	if not v205 then
		error(v206, 0)
	end
	local function v225()
		-- upvalues: (copy) p_u_177, (ref) v_u_1, (copy) p_u_180, (copy) p_u_181, (ref) v_u_10, (ref) v_u_3
		p_u_177:SetAttribute("Ragdolled", true)
		p_u_177:SetAttribute("RagdollCreatedAt", workspace:GetServerTimeNow())
		v_u_1:AddTag(p_u_177, "Ragdoll")
		local v_u_207 = p_u_177
		local v208 = p_u_180 or 5
		local v_u_209 = p_u_181
		local v_u_210 = v_u_207:GetAttribute("RagdollCreatedAt")
		task.delay(v208, function()
			-- upvalues: (ref) v_u_10, (copy) v_u_207, (copy) v_u_210, (ref) v_u_3, (copy) v_u_209
			local v211 = 0
			local v212 = 0
			local v213 = v_u_10[v_u_207]
			local v214
			if v213 then
				v214 = v213.BodyParts
			else
				v214 = v_u_207:QueryDescendants("BasePart")
			end
			local v215
			if v_u_207.Parent == nil or v_u_207:GetAttribute("Ragdolled") ~= true then
				v215 = false
			else
				v215 = v_u_207:GetAttribute("RagdollCreatedAt") == v_u_210
			end
			if v215 then
				local v216 = v_u_3.Heartbeat:Wait()
				local v217
				if v_u_207.Parent == nil or v_u_207:GetAttribute("Ragdolled") ~= true then
					v217 = false
				else
					v217 = v_u_207:GetAttribute("RagdollCreatedAt") == v_u_210
				end
				if v217 then
					v211 = v211 + v216
					local v218 = true
					local v219 = false
					local v220 = false
					for _, v221 in v214 do
						if v221.Anchored or v221.Parent == nil then
							continue
						end
						local v222 = v221.AssemblyLinearVelocity.Magnitude
						if v222 >= 0.13 or v221.AssemblyAngularVelocity.Magnitude >= 0.13 then
							v218 = false
						end
						v219 = v222 >= 6 and true or v219
						if v221.Position.Y >= -400 then
							continue
						end
						v220 = true
					end
					v212 = not v218 and 0 or v212 + v216
					if v212 < 0.2 and ((v_u_209 or 2.5) > v211 or v219) and not v220 then
						break
					end
					if v213 and v213.Pooled then
						for _, v223 in v214 do
							if v223.Anchored then
								continue
							end
							v223.Anchored = true
						end
					else
						for _, v224 in v_u_207:QueryDescendants("BasePart") do
							v224.Anchored = true
						end
					end
				else
					return
				end
			else
				return
			end
		end)
	end
	debug.profilebegin("Ragdoll.Activate.Finalize")
	local v226, v227 = pcall(v225)
	debug.profileend()
	if not v226 then
		error(v227, 0)
	end
	return true
end
function v_u_8.Deactivate(p228) -- name: Deactivate
	-- upvalues: (copy) v_u_10, (copy) v_u_1
	local v229 = v_u_10[p228]
	local v230
	if v229 then
		v230 = v229.Pooled
	else
		v230 = v229
	end
	if v229 and v230 then
		for _, v231 in v230.Constraints do
			v231.Enabled = false
		end
		for _, v232 in v229.Motors do
			v232.Enabled = true
		end
		p228:SetAttribute("Ragdolled", nil)
		p228:SetAttribute("RagdollCreatedAt", nil)
		v_u_1:RemoveTag(p228, "Ragdoll")
	else
		v_u_10[p228] = nil
		local v233 = p228:FindFirstChild("RagdollJoints")
		if v233 and v233:IsA("Folder") then
			for _, v234 in v233:GetDescendants() do
				if not v234:IsA("Constraint") then
					continue
				end
				v234.Enabled = false
			end
			for _, v235 in v233:GetChildren() do
				local v236 = v235:FindFirstChild("Motor")
				local v237
				if v236 and v236:IsA("ObjectValue") then
					v237 = v236.Value
				else
					v237 = nil
				end
				if not (v237 and v237:IsA("Motor6D")) then
					v237 = nil
				end
				if not v237 then
					continue
				end
				v237.Enabled = true
			end
		elseif v229 then
			for _, v238 in v229.Motors do
				v238.Enabled = true
			end
		end
		p228:SetAttribute("RagdollStaged", nil)
		p228:SetAttribute("Ragdolled", nil)
		p228:SetAttribute("RagdollCreatedAt", nil)
		v_u_1:RemoveTag(p228, "Ragdoll")
	end
end
function v_u_8.ApplyImpulse(p239, p240) -- name: ApplyImpulse
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_8, (copy) v_u_7, (copy) v_u_6
	local v241 = p239:FindFirstChild(p240.Part)
	if v241 and v241:IsA("BasePart") then
		local v242 = v_u_4(p240.Weapon)
		if v242 then
			local v243 = p240.Direction
			local v244 = typeof(v243) ~= "Vector3" and 0 or v243.Magnitude
			local v245 = (v244 ~= v244 or v244 < 0.001) and Vector3.new(-0, -1, -0) or v243 / v244
			local v246 = p240.DirectionMultiplier
			local v247 = typeof(v246) ~= "number" and 1 or p240.DirectionMultiplier
			local v248 = (v242.RagdollMultiplier or 45) * v247
			local v249 = v_u_5[v241.Name]
			local v250
			if v249 then
				v250 = v248 * (math.random(v249.Minimum, v249.Maximum) / 100)
			else
				v250 = v248
			end
			local v251 = (v241.Name == "Head" and 1 or 0) + 2.5
			v241.AssemblyLinearVelocity = (v245 * v250 + Vector3.new(-0, -5, -0)) * v251
			local v252 = (v245 * v248 + Vector3.new(-0, -5, -0)) * v251 * 0.1
			local v253
			if v_u_8.IsR6(p239) then
				v253 = v_u_7
			else
				v253 = v_u_6
			end
			local v254 = v253.BodyParts
			for _, v255 in p239:GetChildren() do
				if not v255:IsA("BasePart") or (v255 == v241 or (v254[v255.Name] == nil or (v255.Anchored or v255:HasTag("CharacterAccessory")))) then
					continue
				end
				v255.AssemblyLinearVelocity = v255.AssemblyLinearVelocity + v252
			end
		end
	else
		return
	end
end
function v_u_8.DisableJoint(p256, p257) -- name: DisableJoint
	local v258 = p256:FindFirstChild("RagdollJoints")
	if v258 and v258:IsA("Folder") then
		for _, v259 in v258:GetChildren() do
			local v260 = v259:FindFirstChild("Motor")
			local v261
			if v260 and v260:IsA("ObjectValue") then
				v261 = v260.Value
			else
				v261 = nil
			end
			if not (v261 and v261:IsA("Motor6D")) then
				v261 = nil
			end
			if not v261 or v261.Name ~= p257 then
				continue
			end
			for _, v262 in v259:GetDescendants() do
				if not (v262:IsA("BallSocketConstraint") or v262:IsA("HingeConstraint")) then
					continue
				end
				v262.Enabled = false
			end
			return
		end
	end
end
return v_u_8
-- NIGHT Analyzer | ReplicatedStorage.Classes.Loadout.Types
-- ModuleScript | 7 linhas | 207 bytes | hash 1ffacfd3

local v1 = game:GetService("ReplicatedStorage")
require(v1.Database.Custom.Types)
require(v1.Components.Grenade)
require(v1.Components.Weapon)
require(v1.Components.Melee)
require(v1.Components.C4)
return {}
-- NIGHT Analyzer | ReplicatedStorage.Classes.WeaponComponent
-- ModuleScript | 116 linhas | 3129 bytes | hash f3cd6578

local v1 = {}
local v2 = game:GetService("ReplicatedStorage")
require(v2.Database.Custom.Types)
require(script:WaitForChild("Types"))
local v_u_3 = require(v2.Database.Components.Libraries.Skins)
local v_u_4 = require(v2.Components.Common.GetWeaponProperties)
local v_u_5 = require(v2.Shared.Janitor)
local v_u_6 = require(script.Classes.CharacterAnimator)
local v_u_7 = require(script.Classes.Viewmodel)
function v1.new(p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20) -- name: new
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_6, (copy) v_u_7, (copy) v_u_3
	debug.profilebegin("WeaponComponent.new")
	local v_u_21 = {}
	debug.profilebegin("WeaponComponent.new.Janitor")
	v_u_21.Janitor = v_u_5.new()
	v_u_21.IsDestroyed = false
	debug.profileend()
	v_u_21.OriginalOwner = p17
	v_u_21.Identifier = p9
	v_u_21.StatTrack = p15
	v_u_21.Stickers = p19
	v_u_21.NameTag = p16
	v_u_21.Player = p8
	v_u_21.Character = p20
	v_u_21.Float = p14
	v_u_21.Name = p12
	v_u_21.Charm = p18
	v_u_21.Skin = p13
	v_u_21.Slot = p11
	v_u_21._id = p10
	debug.profilebegin("WeaponComponent.new.GetWeaponProperties")
	v_u_21.Properties = v_u_4(p12)
	debug.profileend()
	debug.profilebegin("WeaponComponent.new.CharacterAnimator")
	v_u_21.CharacterAnimator = v_u_6.new(v_u_21.Player, p12, p20)
	debug.profileend()
	debug.profilebegin("WeaponComponent.new.Viewmodel")
	local v22 = v_u_7.claim(v_u_21, p12, p13)
	local v23, v24
	if v22 then
		v23 = v22
		v24 = true
	else
		local v25 = v_u_7.new
		v24, v23 = pcall(v25, v_u_21, p12, p13)
	end
	debug.profileend()
	if not v24 then
		debug.profileend()
		error(v23, 2)
	end
	v_u_21.Viewmodel = v23
	debug.profilebegin("WeaponComponent.new.CleanupCallbacks")
	v_u_21.Janitor:Add(function()
		-- upvalues: (copy) v_u_21
		if v_u_21.CharacterAnimator then
			v_u_21.CharacterAnimator:destroy()
			v_u_21.CharacterAnimator = nil
		end
	end)
	v_u_21.Janitor:Add(function()
		-- upvalues: (copy) v_u_21
		if v_u_21.Viewmodel then
			v_u_21.Viewmodel:release()
			v_u_21.Viewmodel = nil
		end
	end)
	debug.profileend()
	function v_u_21.updateStatTrackCounter(p26, p27)
		-- upvalues: (ref) v_u_3
		p26.StatTrack = p27
		if p26.StatTrack then
			local v28 = p26.Viewmodel.Model:FindFirstChild("KillTrak", true)
			if v28 then
				v28.Screen.SurfaceGui.TextLabel.Text = v_u_3.GetKillTrackValue(p27, p26.Name)
			end
		end
	end
	if v22 and p15 then
		v_u_21:updateStatTrackCounter(p15)
	end
	debug.profileend()
	return v_u_21
end
function v1.destroy(p29) -- name: destroy
	debug.profilebegin("WeaponComponent.destroy")
	if p29.CharacterAnimator then
		p29.CharacterAnimator:destroy()
		p29.CharacterAnimator = nil
	end
	if p29.Viewmodel then
		p29.Viewmodel:release()
		p29.Viewmodel = nil
	end
	if p29.Janitor then
		p29.Janitor:Destroy()
		p29.Janitor = nil
	end
	p29.updateStatTrackCounter = nil
	p29.OriginalOwner = nil
	p29.Properties = nil
	p29.Identifier = nil
	p29.StatTrack = nil
	p29.Stickers = nil
	p29.NameTag = nil
	p29.Player = nil
	p29.Character = nil
	p29.Float = nil
	p29.Name = nil
	p29.Charm = nil
	p29.Skin = nil
	p29.Slot = nil
	p29._id = nil
	debug.profileend()
end
return v1
-- NIGHT Analyzer | ReplicatedStorage.Classes.WeaponComponent.Classes.Viewmodel.Classes.Bobble
-- ModuleScript | 471 linhas | 14154 bytes | hash f66f61e9

local v_u_1 = {}
v_u_1.__index = v_u_1
local v2 = game:GetService("ReplicatedStorage")
local v3 = game:GetService("Players")
require(script:WaitForChild("Types"))
local v_u_4 = require(v2.Shared.Janitor)
local v_u_5 = require(v2.Shared.Spring)
local v_u_6 = require(v2.MovementV2.RuntimeKinematics)
local v_u_7 = require(v2.MovementV2.SpeedProfile)
local v_u_8 = require(v2.Components.Common.CharacterResolver)
local v_u_9 = require(v2.Components.Common.GetWeaponProperties)
local v_u_10 = require(v2.Components.Common.IsSurvivalMode)
local v_u_11 = require(v2.Components.Common.LocalFootsteps)
local v_u_12 = workspace.CurrentCamera
local v_u_13 = v3.LocalPlayer
local v_u_14 = Vector2.new(0.02, 0.015) / 50
local v_u_15 = Vector2.new(0.68, 7)
local v_u_16 = Vector2.new(1, 9)
local v_u_17 = Vector2.new(1, 18)
local v_u_18 = Vector2.new(5, 3.5)
local v_u_19 = {
	["Primary"] = {
		["Hand"] = Vector3.new(0.002, -0.25, -0.343),
		["Rotation"] = Vector3.new(0, 55, 20),
		["Bob"] = 1,
		["Pump"] = 0
	},
	["Secondary"] = {
		["Hand"] = Vector3.new(0.023, -0.14, -0.239),
		["Rotation"] = Vector3.new(-5, 30, 15),
		["Bob"] = 1.1,
		["Pump"] = 0.35
	},
	["Melee"] = {
		["Hand"] = Vector3.new(0.051, -0.118, -0.303),
		["Rotation"] = Vector3.new(-5, 30, 15),
		["Bob"] = 1.25,
		["Pump"] = 1
	},
	["Grenade"] = {
		["Hand"] = Vector3.new(0.056, -0.165, -0.217),
		["Rotation"] = Vector3.new(-5, 30, 15),
		["Bob"] = 1.15,
		["Pump"] = 0.6
	},
	["C4"] = {
		["Hand"] = Vector3.new(0.023, -0.14, -0.239),
		["Rotation"] = Vector3.new(-5, 30, 15),
		["Bob"] = 1.1,
		["Pump"] = 0.4
	}
}
local v_u_20 = v_u_19.Primary
local v_u_21 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_22 = {}
local v_u_23 = v_u_10()
workspace:GetAttributeChangedSignal("Gamemode"):Connect(function()
	-- upvalues: (ref) v_u_23, (copy) v_u_10
	v_u_23 = v_u_10()
end)
local function v_u_27(p24, p25) -- name: toggleScopeVisibility
	for _, v26 in pairs(p24:GetDescendants()) do
		if v26:IsA("MeshPart") then
			v26.Transparency = p25 == true and 0 or 1
		else
			if not v26:IsA("SurfaceGui") then
				continue
			end
			v26.Enabled = p25
		end
	end
end
local function v_u_37(p28, p29) -- name: applySkinToScope
	if p28.ClassName == "Model" and p29.ClassName == "Model" then
		local function v32(p30) -- name: clearSurfaceAppearances
			for _, v31 in pairs(p30:GetChildren()) do
				if v31.ClassName ~= "SurfaceAppearance" then
					continue
				end
				v31:Destroy()
			end
		end
		for _, v33 in pairs(p28:GetChildren()) do
			local v34 = p29:FindFirstChild(v33.Name)
			if not v34 then
				continue
			end
			local v35 = v34:FindFirstChildWhichIsA("SurfaceAppearance")
			if not v35 then
				continue
			end
			local v36 = v35:Clone()
			v36.Name = v34.Name
			v32(v33)
			v36.Parent = v33
		end
	end
end
function v_u_1.addScopeKick(p38) -- name: addScopeKick
	if not p38.IsDestroyed and p38.ScopeSpring then
		p38.ScopeSpring:impulse(Vector2.new(5, 1))
	end
end
function v_u_1.getMovementVelocity(p39) -- name: getMovementVelocity
	-- upvalues: (copy) v_u_6, (copy) v_u_12
	local v40 = p39.Character
	if not v40 then
		p39.IsInAir = false
		return Vector3.new(0, 0, 0), Vector3.new(0, 0, 0)
	end
	local v41, _, _, _, v42 = v_u_6.resolve(v40, v40.PrimaryPart)
	p39.IsInAir = not v42
	if v41.Magnitude <= 0.1 then
		return Vector3.new(0, 0, 0), Vector3.new(0, 0, 0)
	end
	local v43 = v41.Unit
	local v44 = v41.Magnitude
	local v45 = v43 * math.min(v44, 50)
	return v45, v_u_12.CFrame:VectorToObjectSpace(v45)
end
function v_u_1.wantsSprintGrip(p46) -- name: wantsSprintGrip
	-- upvalues: (ref) v_u_23
	local v47 = v_u_23 and not p46.IsDestroyed
	if v47 then
		if p46.SprintSpring:getGoal() == 0 then
			local v48 = p46.SprintSpring:getPosition()
			v47 = math.abs(v48) < 0.001
		else
			v47 = false
		end
	end
	return v47
end
function v_u_1.setSprintGrip(p49, p50) -- name: setSprintGrip
	-- upvalues: (copy) v_u_22
	p49.SprintPivot = p50
	v_u_22[p49.SprintWeaponName] = p50
end
function v_u_1.getSprintCFrame(p51, p52, p53, p54) -- name: getSprintCFrame
	-- upvalues: (copy) v_u_21, (copy) v_u_7, (copy) v_u_17, (copy) v_u_15, (copy) v_u_16, (copy) v_u_11, (copy) v_u_18
	local v55 = os.clock()
	local v56 = p51.Character
	local v57
	if v56 then
		v57 = v_u_21[v56]
	else
		v57 = v56
	end
	if v55 - p51.SprintRenderedAt > 0.25 and (v57 and v55 - v57.At <= 0.25) then
		p51.SprintSpring:reset(v57.Alpha)
		p51.SprintPhase = v57.Phase
	end
	p51.SprintRenderedAt = v55
	if p54 or p51.IsAiming then
		p51.SprintBlockedUntil = v55 + 0.35
	end
	local v58 = v55 < p51.SprintBlockedUntil
	local v59 = p51.SprintRunSpeed
	local v60 = math.max(v59, 1)
	local v61 = v60 * 1.04
	local v62 = v60 + (v_u_7.SprintSpeed - v60) * 0.75
	local v63 = v61 + 0.5
	local v64 = math.max(v62, v63)
	local v65
	if v58 or v61 >= p53 then
		v65 = 0
	else
		local v66 = (p53 - v61) / (v64 - v61)
		v65 = math.clamp(v66, 0, 1)
	end
	local v67 = p51.SprintSpring
	local v68 = v67:getGoal()
	if v58 then
		local v69 = v_u_17
		v67:setDampingRatio(v69.X)
		v67:setFrequency(v69.Y)
	elseif v68 < v65 then
		local v70 = v_u_15
		v67:setDampingRatio(v70.X)
		v67:setFrequency(v70.Y)
	elseif v65 < v68 then
		local v71 = v_u_16
		v67:setDampingRatio(v71.X)
		v67:setFrequency(v71.Y)
	end
	v67:setGoal(v65)
	v67:update(p52)
	p51.SprintGroundSpring:setGoal(p51.IsInAir and 0.25 or 1)
	p51.SprintGroundSpring:update(p52)
	local v72 = v67:getPosition()
	if v65 == 0 and math.abs(v72) < 0.001 then
		p51.SprintPhase = 0
		if v56 then
			local v73 = v_u_21[v56]
			if v73 then
				v73.Alpha = 0
				v73.Phase = 0
				v73.At = v55
			else
				v_u_21[v56] = {
					["Alpha"] = 0,
					["Phase"] = 0,
					["At"] = nil,
					["At"] = v55
				}
			end
		end
		return CFrame.identity
	end
	if p51.FollowsLocalStride then
		p51.SprintPhase = v_u_11.getPhase() * 0.5
	elseif not p51.IsInAir then
		p51.SprintPhase = (p51.SprintPhase + p52 * p53 * 0.06) % 1
	end
	if v56 then
		local v74 = p51.SprintPhase
		local v75 = v_u_21[v56]
		if v75 then
			v75.Alpha = v72
			v75.Phase = v74
			v75.At = v55
		else
			v_u_21[v56] = {
				["Alpha"] = v72,
				["Phase"] = v74,
				["At"] = v55
			}
		end
	end
	p51.SprintNoiseTime = p51.SprintNoiseTime + p52 * 0.8
	local v76 = p51.SprintPose
	local v77 = p51.SprintPhase * 3.141592653589793 * 2
	local v78 = math.sin(v77)
	local v79 = math.abs(v78) - 0.5
	local v80 = v77 - 0.6
	local v81 = math.sin(v80)
	local v82 = v77 - 0.3
	local v83 = math.sin(v82) * v76.Pump
	local v84 = math.max(v72, 0) * v76.Bob * p51.SprintGroundSpring:getPosition()
	local v85 = p51.SprintNoiseTime
	local v86 = p51.SprintNoiseSeed
	local v87 = math.noise(v85, 0.5, v86)
	local v88 = math.noise(v85, 7.5, v86)
	local v89 = math.noise
	local v90 = Vector3.new(v87, v88, v89(v85, 13.5, v86)) * 2 * Vector3.new(1.2, 1, 1.5)
	local v91 = v78 * 0.03
	local v92 = v79 * 0.033
	local v93 = v83 * 0.018
	local v94 = Vector3.new(v91, v92, v93) * v84
	local v95 = v79 * 2.5 + v83 * 9
	local v96 = v81 * v_u_18.X
	local v97 = v81 * v_u_18.Y
	local v98 = (Vector3.new(v95, v96, v97) + v90) * v84
	local v99 = p51.SprintPivot
	local v100 = CFrame.new((v76.Hand - v99) * v72 + v94)
	local v101 = v76.Rotation * v72 + v98
	local v102 = CFrame.new(v99)
	local v103 = CFrame.Angles
	local v104 = v101.X
	local v105 = math.rad(v104)
	local v106 = v101.Y
	local v107 = math.rad(v106)
	local v108 = v101.Z
	return v100 * (v102 * v103(v105, v107, (math.rad(v108))) * CFrame.new(-v99))
end
function v_u_1.getNextCFrame(p109, p110, p111) -- name: getNextCFrame
	-- upvalues: (copy) v_u_12, (copy) v_u_14, (ref) v_u_23
	if p109.IsDestroyed then
		return CFrame.identity, Vector3.new(0, 0, 0), Vector3.new(0, 0, 0)
	end
	local v112 = (p110 <= 0 or p110 ~= p110) and 0.016666666666666666 or p110
	local v113, v114 = p109:getMovementVelocity()
	local v115 = v113 * Vector3.new(1, 0, 1)
	local v116 = v114 * Vector3.new(1, 0, 1)
	local v117 = v113.Magnitude
	local v118 = v115.Magnitude
	local v119 = v_u_12.CFrame
	local v120, v121, _ = v119:ToObjectSpace(p109.LastCameraCFrame):ToOrientation()
	local v122 = Vector2.new(v120, v121) / v112
	local v123 = v112 * v117 * 0.1
	local v124 = p109.RenderTime + v123
	local v125 = v122.Y
	local v126 = -v122.X
	local v127 = Vector3.new(0.0011111111, 0.0011111111, 0) * Vector3.new(v125, v126, 0)
	local v128 = v127 ~= v127 and Vector3.new(0, 0, 0) or v127
	local v129 = v116.X
	local v130 = -v118
	local v131 = v116.X
	local v132 = math.abs(v131)
	local v133 = v114.Z
	local v134 = math.abs(v133)
	local v135 = math.max(v132, v134)
	local v136 = Vector3.new(0.0004, 0.0007, 0.0011) * Vector3.new(v129, v130, v135)
	local v137 = Vector2.new
	local v138 = v124 * 3.141592653589793 * 2
	local v139 = math.sin(v138)
	local v140 = v124 * 3.141592653589793 * 4
	local v141 = v137(v139, (math.sin(v140))) * (v_u_14 * 0.5) * v118
	if p109.IsInAir then
		v136 = v136 + Vector3.new(0, -0.02, 0)
		v141 = v141 * 0.3
	end
	local v142 = CFrame.identity
	if v_u_23 then
		v142 = p109:getSprintCFrame(v112, v118, p111 == true)
		local v143 = p109.SprintSpring:getPosition()
		v141 = v141 * (1 - math.clamp(v143, 0, 1) * 0.6)
	end
	p109.MovementShiftSpring:setGoal(v136)
	p109.CameraShiftSpring:setGoal(v128)
	p109.BobbleSpring:setGoal(v141)
	p109.ScopeSpring:setGoal(Vector2.zero)
	p109.LowerSpring:setGoal(p109.IsLowered and 1 or 0)
	p109.MovementShiftSpring:update(v112)
	p109.CameraShiftSpring:update(v112)
	p109.BobbleSpring:update(v112)
	p109.ScopeSpring:update(v112)
	p109.LowerSpring:update(v112)
	p109.LastCameraCFrame = v119
	p109.RenderTime = v124
	local v144 = p109.MovementShiftSpring:getPosition()
	local v145 = p109.CameraShiftSpring:getPosition()
	local v146 = p109.BobbleSpring:getPosition()
	local v147 = v146.X
	local v148 = v146.Y
	local v149 = Vector3.new(v147, v148, 0)
	local v150 = p109.ScopeSpring:getPosition()
	local v151 = -v144.X * 250
	local v152 = math.rad(v151)
	local v153
	if p109.IsAiming then
		v153 = 0.08726646259971647
		v152 = 0
	else
		v153 = 0
	end
	local v154 = v144 + v145 + v149
	local v155 = v149 + v144
	local v156 = v150.X
	local v157 = v150.Y
	local v158 = Vector3.new(v156, v157, 0)
	return v142 * CFrame.new(v154) * CFrame.Angles(0, v153, v152), v155, v158
end
function v_u_1.getLowered(p159) -- name: getLowered
	return p159.LowerSpring:getPosition()
end
function v_u_1.setIsAiming(p160, p161) -- name: setIsAiming
	-- upvalues: (copy) v_u_27
	p160.IsAiming = p161
	v_u_27(p160.Scope, p161)
	v_u_27(p160.ScopeReticlePart, p161)
end
function v_u_1.setLowered(p162, p163, p164) -- name: setLowered
	if not p162.IsDestroyed then
		p162.IsLowered = p163
		if p164 then
			p162.LowerSpring:reset(p163 and 1 or 0)
		end
	end
end
function v_u_1.setModel(p165, p166) -- name: setModel
	-- upvalues: (copy) v_u_9, (copy) v_u_19, (copy) v_u_20, (copy) v_u_7, (copy) v_u_22, (copy) v_u_12, (copy) v_u_27, (copy) v_u_37
	if p166 then
		if p165.Scope then
			p165.Scope:Destroy()
			p165.Scope = nil
		end
		if p165.ScopeReticlePart then
			p165.ScopeReticlePart:Destroy()
			p165.ScopeReticlePart = nil
		end
		local v167 = p166.Name
		local v168 = v_u_9(v167)
		p165.SprintPose = v168 and v_u_19[v168.Slot] or v_u_20
		local v169 = v_u_7.resolveWeaponSpeeds
		if v168 then
			v168 = v168.WalkSpeed
		end
		p165.SprintRunSpeed = v169(v167, v168)
		p165.SprintWeaponName = v167
		p165.SprintPivot = v_u_22[v167] or Vector3.new(0.13, -0.14, -0.24)
		if v167 == "AUG" or v167 == "SG 553" then
			local v170 = p166:FindFirstChild("Weapon")
			if v170 and v170:FindFirstChild("ScopeSplit") then
				local v171 = v170.ScopeSplit
				local v172 = v171:FindFirstChild("Part")
				if v172 then
					p165.ScopeReticlePart = p165.Janitor:Add(v172:Clone())
					p165.ScopeReticlePart.Parent = v_u_12
				end
				local v173 = p165.Janitor:Add(v171:Clone())
				p165.Scope = v173
				v173.Parent = v_u_12
				v_u_27(v173, false)
				if v167 == "AUG" then
					local v174 = v173:FindFirstChild("Part")
					if v174 then
						v174 = v174:FindFirstChild("SurfaceGui")
					end
					if v174 then
						v174 = v174:FindFirstChild("Frame")
					end
					if v174 then
						v174.Visible = false
					end
				end
				v_u_37(v173, v170)
				v171:Destroy()
			end
		end
	end
end
function v_u_1.new(p175) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_8, (copy) v_u_5, (copy) v_u_16, (copy) v_u_20, (copy) v_u_7, (copy) v_u_12, (copy) v_u_13
	local v176 = v_u_1
	local v_u_177 = setmetatable({}, v176)
	v_u_177.Janitor = v_u_4.new()
	v_u_177.IsDestroyed = false
	v_u_177.Character = p175.Character or v_u_8.getPlayerCharacter(p175.Player)
	v_u_177.IsAiming = false
	v_u_177.CameraShiftSpring = v_u_5.new(0.7, 18, Vector3.new(0, 0, 0))
	v_u_177.MovementShiftSpring = v_u_5.new(1, 15, Vector3.new(0, 0, 0))
	v_u_177.BobbleSpring = v_u_5.new(1, 20, Vector2.zero)
	v_u_177.ScopeSpring = v_u_5.new(1, 20, Vector2.zero)
	v_u_177.SprintSpring = v_u_5.new(v_u_16.X, v_u_16.Y, 0)
	v_u_177.SprintGroundSpring = v_u_5.new(1, 12, 1)
	v_u_177.LowerSpring = v_u_5.new(1, 12, 0)
	v_u_177.SprintPose = v_u_20
	v_u_177.SprintPivot = Vector3.new(0.13, -0.14, -0.24)
	v_u_177.SprintWeaponName = ""
	v_u_177.SprintRunSpeed = v_u_7.DefaultBaseSpeed
	v_u_177.SprintPhase = 0
	v_u_177.SprintBlockedUntil = 0
	v_u_177.SprintNoiseTime = 0
	v_u_177.SprintNoiseSeed = Random.new():NextNumber(0, 1000)
	v_u_177.SprintRenderedAt = (-1 / 0)
	v_u_177.FollowsLocalStride = false
	v_u_177.LastCameraCFrame = v_u_12.CFrame
	v_u_177.RenderTime = 0
	v_u_177.IsInAir = false
	v_u_177.IsLowered = false
	if not p175.Character then
		v_u_177.Janitor:Add(v_u_8.observeCharacter(p175.Player, function(p178)
			-- upvalues: (copy) v_u_177
			v_u_177.Character = p178
			return function() end
		end))
		v_u_177.FollowsLocalStride = p175.Player == v_u_13
	end
	return v_u_177
end
function v_u_1.destroy(p179) -- name: destroy
	if not p179.IsDestroyed then
		p179.IsDestroyed = true
		p179.Janitor:Destroy()
		p179.Janitor = nil
		p179.CameraShiftSpring = nil
		p179.MovementShiftSpring = nil
		p179.BobbleSpring = nil
		p179.ScopeSpring = nil
		p179.SprintSpring = nil
		p179.SprintGroundSpring = nil
		p179.LowerSpring = nil
		p179.Character = nil
		p179.Scope = nil
		p179.ScopeReticlePart = nil
	end
end
return v_u_1
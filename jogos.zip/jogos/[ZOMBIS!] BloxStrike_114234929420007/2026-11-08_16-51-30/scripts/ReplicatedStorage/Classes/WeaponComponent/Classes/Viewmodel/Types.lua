-- NIGHT Analyzer | ReplicatedStorage.Classes.WeaponComponent.Classes.Viewmodel.Types
-- ModuleScript | 6 linhas | 220 bytes | hash e2bd47f8

local v1 = game:GetService("ReplicatedStorage")
require(v1.Database.Custom.Types)
require(script.Parent.Parent.Parent.Parent.Sound)
require(script.Parent.Classes.Animation)
require(script.Parent.Classes.Bobble)
return {}
-- NIGHT Analyzer | ReplicatedStorage.Classes.WeaponComponent.Classes.Viewmodel.Classes.Animation.Types
-- ModuleScript | 4 linhas | 155 bytes | hash 2ac4b2a4

local v1 = game:GetService("ReplicatedStorage")
require(v1.Database.Custom.Types)
require(script.Parent.Parent.Parent.Parent.Parent.Parent.Sound)
return {}
-- NIGHT Analyzer | ReplicatedStorage.Classes.WeaponComponent.Classes.Viewmodel
-- ModuleScript | 1265 linhas | 36982 bytes | hash f3cba773

local v_u_1 = {}
v_u_1.__index = v_u_1
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("HttpService")
local v_u_4 = game:GetService("Players")
require(script:WaitForChild("Types"))
local v_u_5 = v_u_2:WaitForChild("Assets"):WaitForChild("MuzzleFlashes"):WaitForChild("Camera")
local v_u_6 = require(v_u_2.Controllers.DataController)
local v_u_7 = require(v_u_2.Components.Common.CharacterResolver)
local v_u_8 = require(v_u_2.Controllers.RunServiceController)
local v_u_9 = require(v_u_2.Components.Common.VFXLibary.CreateMuzzleFlash.GetMuzzleFlash)
local v_u_10 = require(v_u_2.Database.Components.Common.AttachGlovesToViewmodel)
local v_u_11 = require(v_u_2.Database.Components.Libraries.Skins)
local v_u_12 = require(v_u_2.Classes.Sound)
local v_u_13 = require(v_u_2.Shared.Janitor)
local v_u_14 = require(v_u_2.Shared.BakedViewmodelMirror)
local v_u_15 = require(v_u_2.Shared.ViewmodelHand)
local v_u_16 = require(v_u_2.Database.Security.Router)
local v_u_17 = require(script.Classes.Animation)
local v_u_18 = require(script.Classes.Bobble)
local v_u_19 = workspace.CurrentCamera
local v_u_20 = table.freeze({})
local v_u_21 = {
	"Weapon",
	"WeaponL",
	"WeaponR",
	"CharmBase"
}
local v_u_22 = CFrame.new(0, 10000, 0)
local v_u_23 = {}
local v_u_24 = 0
local v_u_25 = nil
local v_u_26 = {}
local function v_u_33(p27, p28) -- name: updateTransparency
	for _, v29 in ipairs(p27:GetDescendants()) do
		if v29:IsA("BasePart") then
			local v30 = v29:GetAttribute("HiddenTransparency")
			if p28 then
				local v31 = v29.Transparency
				v29.Transparency = 1
				if v30 then
					continue
				end
				v29:SetAttribute("HiddenTransparency", v31)
			else
				if not v30 then
					continue
				end
				v29.Transparency = v30
			end
		else
			if not v29:IsA("Texture") then
				continue
			end
			if p28 then
				if v29.Transparency >= 1 then
					continue
				end
				v29:SetAttribute("HiddenTransparency", v29.Transparency)
				v29.Transparency = 1
			else
				local v32 = v29:GetAttribute("HiddenTransparency")
				if v32 == nil then
					continue
				end
				v29.Transparency = v32
				v29:SetAttribute("HiddenTransparency", nil)
			end
		end
	end
end
local function v_u_37(p34) -- name: stripWeaponGeometry
	-- upvalues: (copy) v_u_21
	for _, v35 in ipairs(v_u_21) do
		local v36 = p34:FindFirstChild(v35)
		if not v36 then
			continue
		end
		v36:Destroy()
	end
end
local function v_u_53(p38, p39, p40) -- name: getCarryOverKey
	-- upvalues: (copy) v_u_4
	if p38.Character or (p38.Player ~= v_u_4.LocalPlayer or p39 == "C4") then
		return nil
	end
	local v41 = p38.Charm
	local v42
	if type(v41) == "table" then
		v42 = ("%*:%*:%*"):format(v41.Skin, v41.Pattern, v41.Position)
	else
		v42 = tostring(v41)
	end
	local v43 = table.concat
	local v44 = {}
	local v45 = p38.ViewmodelCameraWeapon or p39
	local v46 = p38.Float
	local v47 = tostring(v46)
	local v48
	if p38.StatTrack == nil then
		v48 = false
	else
		v48 = p38.StatTrack ~= false
	end
	local v49 = tostring(v48)
	local v50 = p38.NameTag
	local v51 = tostring(v50)
	local v52 = p38.ViewmodelHideWeaponGeometry == true
	__set_list(v44, 1, {v45, p39, p40, v47, v49, v51, v42, (tostring(v52))})
	return v43(v44, "|")
end
local function v_u_60(p54) -- name: getCharacterKey
	local v55 = p54:GetAttribute("Team")
	local v56 = p54:GetAttribute("CharacterName") or workspace:GetAttribute(v55 == "Counter-Terrorists" and "CTCharacter" or "TCharacter")
	local v57 = p54:FindFirstChild("Body Colors")
	local v58 = p54:FindFirstChild("Torso") or p54:FindFirstChild("UpperTorso")
	local v59
	if v57 then
		v59 = v57.TorsoColor3
	elseif v58 and v58:IsA("BasePart") then
		v59 = v58.Color
	else
		v59 = nil
	end
	return table.concat({
		tostring(v55),
		tostring(v56),
		tostring(p54:GetAttribute("EquippedGloves")),
		not v59 and "" or v59:ToHex()
	}, "|")
end
local function v_u_64() -- name: flushCarryOver
	-- upvalues: (copy) v_u_4, (copy) v_u_26, (copy) v_u_64
	if v_u_4.LocalPlayer:GetAttribute("Dead") ~= true then
		local v61 = os.clock()
		for v62 = #v_u_26, 1, -1 do
			local v63 = v_u_26[v62]
			if not v63.Viewmodel.IsDestroyed then
				if v63.ExpiresAt > v61 then
					continue
				end
				table.remove(v_u_26, v62)
				v63.Viewmodel:destroy()
				task.delay(0, v_u_64)
				return
			end
			table.remove(v_u_26, v62)
		end
	end
end
v_u_4.LocalPlayer:GetAttributeChangedSignal("Dead"):Connect(function()
	-- upvalues: (copy) v_u_4, (copy) v_u_26, (copy) v_u_64
	if v_u_4.LocalPlayer:GetAttribute("Dead") ~= true and #v_u_26 ~= 0 then
		local v65 = os.clock() + 5
		for _, v66 in v_u_26 do
			local v67 = v66.ExpiresAt
			v66.ExpiresAt = math.max(v67, v65)
		end
		task.delay(5.1, v_u_64)
	end
end)
local function v_u_83(p68) -- name: weldLooseParts
	local v69 = p68.PrimaryPart
	if v69 then
		local v70 = p68:GetDescendants()
		local v71 = {}
		for _, v72 in ipairs(v70) do
			if not ((v72:IsA("JointInstance") or v72:IsA("WeldConstraint")) and v72.Enabled) then
				continue
			end
			local v73 = v72.Part0
			local v74 = v72.Part1
			if not (v73 and v74) then
				continue
			end
			v71[v73] = v71[v73] or {}
			v71[v74] = v71[v74] or {}
			local v75 = v71[v73]
			table.insert(v75, v74)
			local v76 = v71[v74]
			table.insert(v76, v73)
		end
		local v77 = { v69 }
		local v78 = {
			[v69] = true
		}
		while #v77 > 0 do
			for _, v79 in v71[table.remove(v77)] or {} do
				if v78[v79] then
					continue
				end
				v78[v79] = true
				table.insert(v77, v79)
			end
		end
		local v80 = p68:FindFirstChild("CharmBase")
		for _, v81 in ipairs(v70) do
			if not v81:IsA("BasePart") or (v81 == v69 or v80 and v81:IsDescendantOf(v80)) then
				continue
			end
			v81.Anchored = false
			if v78[v81] then
				continue
			end
			local v82 = Instance.new("Weld")
			v82.Name = "LooseWeld"
			v82.Part0 = v69
			v82.Part1 = v81
			v82.C0 = v69.CFrame:ToObjectSpace(v81.CFrame)
			v82.Parent = v81
		end
	end
end
local function v_u_87(p84, p85) -- name: getChargeGuiObject
	if p84 then
		p84 = p84:FindFirstChild("Interactables")
	end
	if p84 then
		p84 = p84:FindFirstChild("Charge", true)
	end
	if p84 then
		p84 = p84:FindFirstChildOfClass("SurfaceGui")
	end
	if p84 then
		local v86 = p84:FindFirstChild(p85)
		if v86 and v86:IsA(p85) then
			return v86
		else
			return p84:FindFirstChildWhichIsA(p85)
		end
	else
		return nil
	end
end
local function v_u_100(p88) -- name: getRechargeChargeAlpha
	local v89
	if p88 then
		v89 = p88.Properties
	else
		v89 = p88
	end
	if not v89 then
		return nil
	end
	local v90 = v89.RechargeTime
	local v91 = v89.Rounds
	if not v90 or (not v91 or v91 <= 0) then
		return nil
	end
	local v92 = p88.Rounds
	local v93 = (tonumber(v92) or v91) / v91
	local v94 = math.clamp(v93, 0, 1)
	if v94 >= 1 then
		return 1
	end
	local v95 = p88.RechargeStartTime
	local v96 = tonumber(v95)
	if not v96 then
		return v94
	end
	local v97 = workspace:GetServerTimeNow() - v96
	local v98 = math.max(v97, 0) / v90
	local v99 = v94 + math.clamp(v98, 0, 1) / v91
	return math.clamp(v99, 0, 1)
end
local v_u_101 = Color3.fromRGB(125, 20, 20)
local v_u_102 = Color3.fromRGB(255, 235, 140)
local v_u_103 = Color3.fromRGB(40, 223, 213)
local function v_u_119(p104, p105) -- name: updateChargeFrame
	-- upvalues: (copy) v_u_87, (copy) v_u_100, (copy) v_u_103, (copy) v_u_101, (copy) v_u_102
	local v106 = p104.ChargeFillFrame
	if not (v106 and v106.Parent) then
		v106 = v_u_87(p104.Model, "Frame")
		p104.ChargeFillFrame = v106
		local v107
		if v106 then
			v107 = v106.Size or nil
		else
			v107 = nil
		end
		p104.ChargeFillBaseSize = v107
	end
	local v108 = p104.ChargeTextLabel
	if not (v108 and v108.Parent) then
		v108 = v_u_87(p104.Model, "TextLabel")
		p104.ChargeTextLabel = v108
	end
	local v109 = p104.ChargeFillBaseSize
	if v106 and v109 then
		local v110 = v_u_100(p104.WeaponComponent) or 1
		local v111 = p104.DisplayedChargeAlpha
		local v112
		if v111 == nil or v110 < v111 then
			v112 = v110
		else
			local v113 = p105 * 3.5
			local v114 = math.clamp(v113, 0, 1)
			v112 = v111 + (v110 - v111) * v114
		end
		local v115 = v110 - v112
		if math.abs(v115) > 0.001 then
			v110 = v112
		end
		local v116 = v110 >= 0.999 and 1 or v110
		p104.DisplayedChargeAlpha = v116
		v106.Size = UDim2.new(v109.X.Scale, v109.X.Offset, 0.8 * v116, 0)
		local v117
		if v116 >= 0.999 then
			v117 = v_u_103
		else
			v117 = v_u_101:Lerp(v_u_102, v116)
		end
		v106.BackgroundColor3 = v117
		if v108 then
			local v118 = v116 * 100
			v108.Text = ("%*%%"):format((math.round(v118)))
			v108.TextColor3 = v117
		end
	end
end
local function v_u_122(p120) -- name: isSprintBlocked
	local v121 = p120.WeaponComponent
	return (p120.Inspecting == true or (v121 == nil or (v121.IsShooting == true or (v121.IsBurstShooting == true or (v121.IsFireHeld == true or (v121.IsAlternativeFireHeld == true or (v121.IsChargeFiring == true or (v121.IsAiming == true or (v121.IsInspecting == true or v121.ThrowStarted == true))))))))) and true or v121.IsPlanting == true
end
local function v_u_128(p123) -- name: findGripPart
	local v124 = p123:FindFirstChild("Right Arm")
	if v124 and v124:IsA("BasePart") then
		local v125 = -v124.Size.Z / 2
		return v124, Vector3.new(0, 0, v125)
	end
	local v126 = p123:FindFirstChild("Weapon")
	local v127 = v126 and v126:FindFirstChild("Handle") or p123:FindFirstChild("Handle", true)
	if not (v127 and v127:IsA("BasePart")) then
		v127 = nil
	end
	return v127, Vector3.new(0, 0, 0)
end
local v_u_129 = {}
local v_u_130 = {}
local function v_u_134(p131) -- name: singleAssemblyRoot
	local v132 = p131.PrimaryPart
	if v132 == nil then
		return nil
	end
	for _, v133 in p131:GetDescendants() do
		if not v133:IsA("BasePart") or v133.AssemblyRootPart == v132 then
			continue
		end
		return nil
	end
	return v132
end
local function v_u_144(p135, p136, p137) -- name: pivotModel
	-- upvalues: (copy) v_u_134, (copy) v_u_129, (copy) v_u_130
	local v138 = os.clock()
	local v139 = p135[p136]
	if v139 == nil or v139.CheckAt <= v138 then
		v139 = {
			["Root"] = v_u_134(p136),
			["CheckAt"] = v138 + 0.5
		}
		p135[p136] = v139
	end
	local v140 = v139.Root
	if v140 == nil or (v140.Parent == nil or p136.PrimaryPart ~= v140) then
		p136:PivotTo(p137)
	else
		local v141 = v_u_129
		local v142 = v_u_130
		local v143 = p137 * v140.PivotOffset:Inverse()
		v141[1] = v140
		v142[1] = v143
		workspace:BulkMoveTo(v_u_129, v_u_130, Enum.BulkMoveMode.FireCFrameChanged)
	end
end
function v_u_1.aim(p145) -- name: aim
	-- upvalues: (copy) v_u_19
	p145.Bobble:setIsAiming(true)
	if p145.MuzzlePartWeld then
		local v146 = v_u_19.CFrame
		local v147 = p145.Model.WorldPivot
		local v148 = p145.MuzzlePartWeld.Part0.CFrame
		if p145.Mirror then
			v147 = p145.Mirror:ToNormalPose(p145.Model:GetPivot())
			v148 = p145.Mirror:ToNormalPose(v148)
		end
		local v149 = v146 + v146.UpVector * -0.5 + v147.LookVector * 1 + v147.RightVector * 0.1
		p145.MuzzlePartWeld.C0 = v148:Inverse() * v149
	end
end
function v_u_1.unaim(p150) -- name: unaim
	p150.Bobble:setIsAiming(false)
	if p150.OriginalC0 and p150.MuzzlePartWeld then
		p150.MuzzlePartWeld.C0 = p150.OriginalC0
	end
end
function v_u_1.unhide(p151) -- name: unhide
	-- upvalues: (copy) v_u_33
	if p151.Hidden then
		v_u_33(p151.Model, false)
		p151.Hidden = false
	end
end
function v_u_1.hide(p152) -- name: hide
	-- upvalues: (copy) v_u_33
	if not p152.Hidden then
		v_u_33(p152.Model, true)
		p152.Hidden = true
	end
end
function v_u_1.setLowered(p153, p154) -- name: setLowered
	if p153.Bobble then
		p153.Bobble:setLowered(p154)
	end
end
function v_u_1.equip(p155, p156) -- name: equip
	-- upvalues: (copy) v_u_19
	p155.IsEquipped = true
	if p155.Model then
		if p155.Mirror then
			p155.Mirror:PrepareEquip()
		end
		p155.Model.Parent = v_u_19
		if p155.LargeWeaponModel then
			p155.LargeWeaponModel.Parent = v_u_19
		end
		p155.Animation:stopAnimations()
		p155.Animation:play("Idle")
		p155:unhide()
		if not p156 then
			p155.Animation:play(p155.Animation:pickVariant("Equip"))
		end
	end
end
function v_u_1.unequip(p157) -- name: unequip
	-- upvalues: (ref) v_u_25, (copy) v_u_19, (copy) v_u_144, (copy) v_u_22
	p157.IsEquipped = false
	p157.Animation:stopAnimations()
	p157.LastViewmodelPosition = nil
	if p157.Bobble then
		p157.Bobble:setLowered(false, true)
	end
	local v158 = p157.Model
	if v158 and v158:IsDescendantOf(workspace) then
		local v159 = v_u_25
		if not v159 or v159.Parent ~= v_u_19 then
			v159 = Instance.new("Folder")
			v159.Name = "ViewmodelStash"
			v159.Parent = v_u_19
			v_u_25 = v159
		end
		v158.Parent = v159
		v_u_144(p157.PivotPlans, v158, v_u_22)
	end
	if p157.LargeWeaponModel then
		p157.LargeWeaponModel.Parent = nil
	end
end
function v_u_1.applyCharmImpulse(p160, p161) -- name: applyCharmImpulse
	if p160.LargeCharmModel and p160.LargeCharmModel.PrimaryPart then
		local v162 = p160.CharmMassCache
		if p160.CharmMassCacheModel ~= p160.LargeCharmModel or typeof(v162) ~= "number" then
			v162 = 0
			for _, v163 in ipairs(p160.LargeCharmModel:GetDescendants()) do
				if not v163:IsA("BasePart") then
					continue
				end
				v162 = v162 + v163:GetMass()
			end
			p160.CharmMassCache = v162
			p160.CharmMassCacheModel = p160.LargeCharmModel
		end
		p160.LargeCharmModel.PrimaryPart:ApplyImpulse(p161 * 10 * v162)
	end
end
function v_u_1.render(p164, p165) -- name: render
	-- upvalues: (copy) v_u_119, (copy) v_u_6, (copy) v_u_20, (copy) v_u_122, (copy) v_u_19, (copy) v_u_15, (copy) v_u_144, (copy) v_u_128
	local v166 = p164.Model
	if v166 then
		v166 = p164.Model:FindFirstChild("Stats")
	end
	if v166 then
		debug.profilebegin("Viewmodel.render.UpdateChargeFrame")
		v_u_119(p164, p165)
		debug.profileend()
		debug.profilebegin("Viewmodel.render.GetViewmodelSettings")
		local v167 = v_u_6.Get(p164.Player, "Settings.Game.Viewmodel") or v_u_20
		debug.profileend()
		if p164.Bobble or p164.Inspecting then
			debug.profilebegin("Viewmodel.render.BobbleNextCFrame")
			local v168, v169, v170 = p164.Bobble:getNextCFrame(p165, (v_u_122(p164)))
			debug.profileend()
			local v171 = v166.Rotation.Value
			local v172 = not p164.Bobble and 0 or p164.Bobble:getLowered()
			if v172 ~= 0 then
				v171 = v171 + Vector3.new(-0.45, 0.6, 0.25) * v172
			end
			local v173 = CFrame.Angles(v171.X, v171.Y, v171.Z) * CFrame.new(v166.Default.Value) * CFrame.new((v167["X Offset"] or 0) / 100, (v167["Y Offset"] or 0) / 100, (v167["Z Offset"] or 0) / 100)
			local v174 = v_u_19.CFrame * v168 * v173
			debug.profilebegin("Viewmodel.render.PivotModel")
			local v175 = p164.PivotPlans
			local v176 = p164.Mirror
			if v176 then
				local v177 = not p164.WeaponComponent.Character
				if v177 then
					v177 = v_u_15.IsPlayerLeftHanded(p164.Player)
				end
				v176:SetLeftHanded(v177)
				v_u_144(v175, p164.Model, v176:GetDisplayPose(v_u_19.CFrame, v174))
				v176:UpdateSurfaces()
			else
				v_u_144(v175, p164.Model, v174)
			end
			debug.profileend()
			if p164.Bobble:wantsSprintGrip() and p164.Animation:isIdle() then
				local v178 = p164.SprintGripPart
				local v179 = p164.SprintGripOffset
				if v178 == nil or (v178.Parent == nil or v179 == nil) then
					v178, v179 = v_u_128(p164.Model)
					p164.SprintGripPart = v178
					p164.SprintGripOffset = v179
				end
				if v178 and v179 then
					local v180 = p164.Model:GetPivot()
					local v181 = v178.CFrame
					if v176 then
						v180 = v176:ToNormalPose(v180)
						v181 = v176:ToNormalPose(v181)
					end
					local v182 = v181:PointToWorldSpace(v179)
					p164.Bobble:setSprintGrip(v173:PointToWorldSpace(v180:PointToObjectSpace(v182)))
				end
			end
			if p164.LargeWeaponModel and p164.SmallWeaponModel then
				local v183 = p164.SmallWeaponModel:GetPivot()
				if v176 then
					v183 = v176:ToNormalPose(v183)
				end
				debug.profilebegin("Viewmodel.render.PivotLargeWeaponModel")
				v_u_144(v175, p164.LargeWeaponModel, v183)
				debug.profileend()
				local v184 = v174.Position
				if p164.LastViewmodelPosition then
					p164:applyCharmImpulse(-(v184 - p164.LastViewmodelPosition) * 0.2)
				end
				p164.LastViewmodelPosition = v184
			end
			if p164.Bobble.Scope and p164.Bobble.IsAiming then
				debug.profilebegin("Viewmodel.render.Scope")
				local v185 = v_u_19.CFrame
				local v186 = v170.X * -v185.LookVector + v170.Y * -v185.UpVector
				p164.Bobble.Scope:PivotTo(v185 + v185.LookVector * 0.15 + v169 + v186)
				if p164.Bobble.ScopeReticlePart then
					p164.Bobble.ScopeReticlePart.CFrame = v185 * CFrame.Angles(1.5707963267948966, 1.5707963267948966, -1.5707963267948966) + v185.LookVector * 0.15
				end
				debug.profileend()
			end
		end
	end
end
function v_u_1.attachSleeves(p187, p188) -- name: attachSleeves
	-- upvalues: (copy) v_u_2
	local v189 = v_u_2.Assets.Sleeves:FindFirstChild(p188)
	if v189 then
		for _, v190 in ipairs(v189:GetChildren()) do
			local v191 = p187.Model:FindFirstChild(v190.Name)
			if not v191 then
				continue
			end
			local v192 = v190:Clone()
			v192.CastShadow = false
			v192.CanCollide = false
			v192.CanTouch = false
			v192.Anchored = false
			v192.CanQuery = false
			v192.Name = "Sleeve"
			local v193 = v191.Size.X * 1.3
			local v194 = v191.Size.Y * 1.4
			local v195 = v191.Size.Z * 0.79
			v192.Size = Vector3.new(v193, v194, v195)
			local v196 = v191.Size.Z / 2 - v192.Size.Z / 2
			v192.Parent = v191
			local v197 = Instance.new("Motor6D", v192)
			v197.Part0 = v191
			v197.Part1 = v192
			v197.C1 = CFrame.new(0, -0.02, -v196)
		end
	end
end
function v_u_1.addAttachments(p198, p199) -- name: addAttachments
	-- upvalues: (copy) v_u_16, (copy) v_u_23, (copy) v_u_11, (ref) v_u_24, (copy) v_u_10
	debug.profilebegin("Viewmodel.addAttachments")
	local v200 = nil
	local v201 = nil
	local v202 = nil
	if type(p199) == "string" then
		local v203 = p198.Player
		local v204 = v_u_16.broadcastRouter("GetInventoryItemFromIdentifier", v203, p199)
		if v204 then
			v200 = v204.Name
			v201 = v204.Skin
			v202 = v204.Float
		else
			v200 = nil
			v201 = nil
			v202 = nil
		end
	elseif type(p199) == "table" then
		local v205 = p199.SkinIdentifier
		if type(v205) == "string" and v205 ~= "" then
			local v206 = p198.Player
			local v207 = v_u_16.broadcastRouter("GetInventoryItemFromIdentifier", v206, v205)
			if v207 then
				v200 = v207.Name
				v201 = v207.Skin
				v202 = v207.Float
			else
				v200 = nil
				v201 = nil
				v202 = nil
			end
		end
		if not v200 then
			local v208 = p199.Name
			if type(v208) == "string" then
				local v209 = p199.Skin
				if type(v209) == "string" then
					v200 = p199.Name
					v201 = p199.Skin
					local v210 = p199.Float
					if typeof(v210) == "number" then
						v202 = p199.Float
					else
						v202 = nil
					end
				end
			end
		end
	end
	if v200 and v201 then
		debug.profilebegin("Viewmodel.addAttachments.GetGloves")
		local v211 = ("%*|%*|%*"):format(v200, v201, v202 or "")
		local v212 = v_u_23[v211]
		if not v212 then
			local v213 = v_u_11.GetGloves(v200, v201, v202)
			v212 = v_u_23[v211]
			if v212 then
				if v213 then
					v213:Destroy()
				end
			elseif v213 then
				if v_u_24 >= 8 then
					for _, v214 in v_u_23 do
						v214:Destroy()
					end
					table.clear(v_u_23)
					v_u_24 = 0
				end
				v_u_23[v211] = v213
				v_u_24 = v_u_24 + 1
				v212 = v213
			else
				v212 = v213
			end
		end
		debug.profileend()
		if v212 then
			debug.profilebegin("Viewmodel.addAttachments.AttachGloves")
			v_u_10(v212:GetChildren(), p198.Model)
			debug.profileend()
		end
	end
	debug.profileend()
end
function v_u_1.construct(p215, p216, p217) -- name: construct
	-- upvalues: (copy) v_u_13, (copy) v_u_11, (copy) v_u_37, (copy) v_u_60, (copy) v_u_3, (copy) v_u_9, (copy) v_u_5, (copy) v_u_83, (copy) v_u_2, (copy) v_u_4, (copy) v_u_14
	debug.profilebegin("Viewmodel.construct")
	if p215.ModelJanitor then
		debug.profilebegin("Viewmodel.construct.DestroyModelJanitor")
		p215.ModelJanitor:Destroy()
		debug.profileend()
	end
	p215.ModelJanitor = v_u_13.new()
	p215.Mirror = nil
	p215.CharmModel = nil
	p215.LargeWeaponModel = nil
	p215.SmallWeaponModel = nil
	p215.LargeCharmModel = nil
	p215.LastViewmodelPosition = nil
	p215.ChargeFillFrame = nil
	p215.ChargeTextLabel = nil
	p215.ChargeFillBaseSize = nil
	p215.DisplayedChargeAlpha = nil
	if p215.Animation then
		debug.profilebegin("Viewmodel.construct.StopAnimations")
		p215.Animation:stopAnimations()
		debug.profileend()
	end
	if p215.Model then
		debug.profilebegin("Viewmodel.construct.DestroyPreviousModel")
		p215.Model:Destroy()
		debug.profileend()
		p215.Model = nil
		p215.SprintGripPart = nil
		p215.SprintGripOffset = nil
	end
	local v218 = p215.CameraModelWeapon or p215.Weapon
	local v219 = p215.Team
	if v218 ~= "Smoke Grenade" or v219 ~= "Counter-Terrorists" and v219 ~= "Terrorists" then
		v219 = nil
	end
	debug.profilebegin("Viewmodel.construct.GetCameraModel")
	p215.Model = v_u_11.GetCameraModel(v218, p215.Skin, p215.Float, p215.StatTrack, p215.NameTag, p215.Charm, p215.Stickers, v219)
	debug.profileend()
	if not p215.Model and p215.HideWeaponGeometry then
		debug.profilebegin("Viewmodel.construct.GetBaseWeaponModel")
		p215.Model = v_u_11.GetBaseWeaponModel(v218, "Camera")
		debug.profileend()
	end
	if not p215.Model then
		debug.profileend()
		error((("Viewmodel.construct: Failed to get camera model for weapon \"%*\" with skin \"%*\""):format(v218, p215.Skin)))
	end
	p215.Model.Name = v218
	if p215.HideWeaponGeometry then
		debug.profilebegin("Viewmodel.construct.StripWeaponGeometry")
		v_u_37(p215.Model)
		debug.profileend()
	end
	p215.CharacterKey = v_u_60(p216)
	p215.Team = p216:GetAttribute("Team") or p215.Team
	local v220 = p216:GetAttribute("CharacterName")
	if type(v220) ~= "string" or v220 == "" then
		v220 = workspace:GetAttribute(p215.Team == "Counter-Terrorists" and "CTCharacter" or "TCharacter")
	end
	if type(v220) == "string" and v220 ~= "" then
		p215:attachSleeves(v220)
	end
	local v221 = p216:GetAttribute("EquippedGloves")
	if type(v221) == "string" and v221 ~= "" then
		debug.profilebegin("Viewmodel.construct.DecodeEquippedGloves")
		local v222 = v_u_3.JSONDecode
		local v223 = v_u_3
		local v224, v225 = pcall(v222, v223, v221)
		debug.profileend()
		if v224 and v225 then
			p215:addAttachments(v225)
		else
			p215:addAttachments(v221)
		end
	end
	debug.profilebegin("Viewmodel.construct.SetupDescendants")
	for _, v226 in ipairs(p215.Model:GetDescendants()) do
		if not v226:IsA("BasePart") then
			continue
		end
		v226.CollisionGroup = "Viewmodel"
		v226.CanCollide = false
		v226.CastShadow = false
		v226.CanQuery = true
		v226.CanTouch = false
		if v226.Name ~= "HumanoidRootPart" and v226.Name ~= "ViewmodelLight" then
			continue
		end
		v226.Transparency = 1
	end
	debug.profileend()
	debug.profilebegin("Viewmodel.construct.SetupArmColors")
	local v227 = p216:FindFirstChild("Body Colors")
	local v228 = nil
	if v227 then
		v228 = v227.TorsoColor3
	else
		local v229 = p216:FindFirstChild("Torso") or p216:FindFirstChild("UpperTorso")
		if v229 and v229:IsA("BasePart") then
			v228 = v229.Color
		end
	end
	if v228 then
		for _, v230 in ipairs({ "Right Arm", "Left Arm" }) do
			local v231 = p215.Model:FindFirstChild(v230)
			if not (v231 and v231:IsA("BasePart")) then
				continue
			end
			v231.Color = v228
		end
	end
	debug.profileend()
	debug.profilebegin("Viewmodel.construct.CacheMuzzleParts")
	local v232 = p215.Model:FindFirstChild("Interactables")
	local v233 = not v232 or v232:FindFirstChild("MuzzlePart", true) or (v232:FindFirstChild("MuzzlePartL", true) or v232:FindFirstChild("MuzzlePartR", true))
	p215.MuzzlePart = v233
	if v232 then
		p215.MuzzlePartL = v232:FindFirstChild("MuzzlePartL", true)
		p215.MuzzlePartR = v232:FindFirstChild("MuzzlePartR", true)
		if p215.MuzzlePartL and p215.MuzzlePartL:IsA("BasePart") then
			p215.MuzzlePartL.Transparency = 1
		end
		if p215.MuzzlePartR and p215.MuzzlePartR:IsA("BasePart") then
			p215.MuzzlePartR.Transparency = 1
		end
	end
	if p215.MuzzlePart and p215.MuzzlePart:IsA("BasePart") then
		p215.MuzzlePart.Transparency = 1
	end
	debug.profileend()
	debug.profilebegin("Viewmodel.construct.ScaleTo")
	p215.Model:ScaleTo(0.1)
	debug.profileend()
	debug.profilebegin("Viewmodel.construct.CacheMuzzleWeld")
	if p215.MuzzlePart and not p215.MuzzlePart:FindFirstChild("WeldConstraint", true) then
		for _, v234 in ipairs(p215.Model:GetDescendants()) do
			if not v234:IsA("Weld") or v234.Part1 ~= v233 and v234.Part0 ~= v233 then
				continue
			end
			p215.MuzzlePartWeld = v234
			p215.OriginalC0 = v234.C0
		end
	end
	debug.profileend()
	local v235 = p217.Properties
	if v235 then
		if v235.ShootingOptions == "Dual" then
			local v236 = p215.MuzzlePartL
			if v236 and v235.MuzzleType then
				v_u_9(v236, v_u_5, v235.MuzzleType, "Motor6D")
				if v235.HasSuppressor then
					v_u_9(v236, v_u_5, "Suppressor", "Motor6D")
				end
			end
			local v237 = p215.MuzzlePartR
			if v237 and v235.MuzzleType then
				v_u_9(v237, v_u_5, v235.MuzzleType, "Motor6D")
				if v235.HasSuppressor then
					v_u_9(v237, v_u_5, "Suppressor", "Motor6D")
				end
			end
		else
			local v238 = p215.MuzzlePart
			if v238 and v235.MuzzleType then
				v_u_9(v238, v_u_5, v235.MuzzleType, "Motor6D")
				if v235.HasSuppressor then
					v_u_9(v238, v_u_5, "Suppressor", "Motor6D")
				end
			end
		end
	end
	debug.profilebegin("Viewmodel.construct.FindCharmModel")
	local v239 = p215.Model:FindFirstChild("CharmBase", true)
	if v239 and v239:IsA("Model") then
		local v240 = v239:FindFirstChildOfClass("Model")
		if v240 and v240.PrimaryPart then
			p215.CharmModel = v240
		end
	end
	debug.profileend()
	if p215.CharmModel then
		debug.profilebegin("Viewmodel.construct.SetupCharmPhysics")
		p215:setupCharmPhysics()
		debug.profileend()
	end
	debug.profilebegin("Viewmodel.construct.SetModelReferences")
	if p215.Animation then
		p215.Animation:setModel(p215.Model)
	end
	if p215.Bobble then
		local v241 = p215.Bobble
		v241.Character = p216
		v241:setModel(p215.Model)
	end
	debug.profileend()
	v_u_83(p215.Model)
	local v242 = v_u_2:FindFirstChild("ViewmodelMirrors")
	local v243 = p215.Player == v_u_4.LocalPlayer and not p217.Character
	if v243 then
		v243 = not p215.Inspecting
	end
	if v242 then
		v242 = v_u_14.new(p215.Model, v242, v243)
	end
	if v242 and p215.ModelJanitor then
		p215.Mirror = v242
		p215.ModelJanitor:Add(v242, "Destroy")
	end
	debug.profilebegin("Viewmodel.construct.FinalEquipState")
	if p215.IsEquipped then
		p215:equip(false)
	else
		p215:unequip()
	end
	debug.profileend()
	debug.profileend()
end
function v_u_1.setupCharmPhysics(p_u_244) -- name: setupCharmPhysics
	-- upvalues: (copy) v_u_21, (copy) v_u_8
	debug.profilebegin("Viewmodel.setupCharmPhysics")
	local v245 = p_u_244.CharmModel.Parent
	if v245 and v245.PrimaryPart then
		p_u_244.CharmModel:PivotTo(v245.PrimaryPart.CFrame * CFrame.new(0, 0, -1))
		local v_u_246 = p_u_244.CharmModel
		local v247 = p_u_244.Model
		local v_u_248 = v247:FindFirstChild("Weapon") or (v247:FindFirstChild("WeaponL") or v247:FindFirstChild("WeaponR"))
		if v_u_248 then
			debug.profilebegin("Viewmodel.setupCharmPhysics.CloneLargeProxy")
			local v_u_249 = Instance.new("Model")
			v_u_249.Name = p_u_244.Model.Name
			local v250 = {}
			for _, v251 in ipairs(v_u_21) do
				local v252 = p_u_244.Model:FindFirstChild(v251)
				if not v252 then
					continue
				end
				local v253 = v252:Clone()
				v250[v252] = v253
				local v254 = v253:GetDescendants()
				for v255, v256 in v252:GetDescendants() do
					v250[v256] = v254[v255]
				end
				v253.Parent = v_u_249
			end
			v_u_249.WorldPivot = p_u_244.Model:GetPivot()
			debug.profileend()
			local v_u_257 = v_u_249:FindFirstChild("Weapon") or (v_u_249:FindFirstChild("WeaponL") or v_u_249:FindFirstChild("WeaponR"))
			if v_u_257 then
				debug.profilebegin("Viewmodel.setupCharmPhysics.TrimLargeProxy")
				for _, v258 in ipairs(v_u_249:GetDescendants()) do
					if v258.Name == "ViewmodelLight" then
						v258:Destroy()
					elseif v258:IsA("JointInstance") or (v258:IsA("WeldConstraint") or v258:IsA("NoCollisionConstraint")) then
						local v259 = v258.Part0
						local v260
						if v259 == nil or v259:IsDescendantOf(v_u_249) then
							v260 = true
						else
							local v261 = v250[v259]
							if v261 then
								v258.Part0 = v261
								v260 = true
							else
								v260 = false
							end
						end
						if v260 then
							local v262 = v258.Part1
							local v263
							if v262 == nil or v262:IsDescendantOf(v_u_249) then
								v263 = true
							else
								local v264 = v250[v262]
								if v264 then
									v258.Part1 = v264
									v263 = true
								else
									v263 = false
								end
							end
							if v263 then
								continue
							end
						end
						v258:Destroy()
					else
						if not v258:IsA("Constraint") then
							continue
						end
						local v265 = v258.Attachment0
						local v266
						if v265 == nil or v265:IsDescendantOf(v_u_249) then
							v266 = true
						else
							local v267 = v250[v265]
							if v267 then
								v258.Attachment0 = v267
								v266 = true
							else
								v266 = false
							end
						end
						if v266 then
							local v268 = v258.Attachment1
							local v269
							if v268 == nil or v268:IsDescendantOf(v_u_249) then
								v269 = true
							else
								local v270 = v250[v268]
								if v270 then
									v258.Attachment1 = v270
									v269 = true
								else
									v269 = false
								end
							end
							if v269 then
								continue
							end
						end
						v258:Destroy()
					end
				end
				debug.profileend()
				debug.profilebegin("Viewmodel.setupCharmPhysics.ScaleAndPivotProxy")
				v_u_249:ScaleTo(1 / p_u_244.Model:GetScale())
				v_u_249:PivotTo(v_u_248.Parent:GetPivot())
				if v_u_257.PrimaryPart then
					v_u_257.PrimaryPart.Anchored = true
				end
				local v271 = v_u_249:GetBoundingBox()
				if v_u_249.PrimaryPart then
					v_u_249.PrimaryPart.PivotOffset = v_u_249.PrimaryPart.CFrame:ToObjectSpace(v271)
				else
					v_u_249.WorldPivot = v271
				end
				v_u_249.PrimaryPart = v_u_257.PrimaryPart
				debug.profileend()
				debug.profilebegin("Viewmodel.setupCharmPhysics.ConfigureProxyDescendants")
				for _, v272 in ipairs(v_u_249:GetDescendants()) do
					if v272:IsA("BasePart") then
						v272.Transparency = 1
						v272.CanCollide = true
					elseif v272:IsA("Decal") or (v272:IsA("Texture") or v272:IsA("Beam")) then
						v272.Transparency = 1
					else
						if not (v272:IsA("SurfaceGui") or v272:IsA("ParticleEmitter")) then
							continue
						end
						v272.Enabled = false
					end
				end
				debug.profileend()
				debug.profilebegin("Viewmodel.setupCharmPhysics.FindLargeCharm")
				local v273 = v_u_249:FindFirstChild("CharmBase", true)
				local v274
				if v273 and v273:IsA("Model") then
					v274 = v273:FindFirstChildOfClass("Model")
					if v274 then
						for _, v275 in ipairs(v274:GetDescendants()) do
							if not v275:IsA("BasePart") then
								continue
							end
							v275.CanCollide = true
							v275.CollisionGroup = "Charm"
						end
					end
				else
					v274 = nil
				end
				debug.profileend()
				p_u_244.LargeWeaponModel = v_u_257.Parent
				p_u_244.SmallWeaponModel = v_u_248
				p_u_244.LargeCharmModel = v274
				if v274 and p_u_244.ModelJanitor then
					local v276 = v_u_8.CreateBindingName("Classes.Viewmodel.CharmSync")
					p_u_244.ModelJanitor:Add(v_u_8.BindToPostSimulation(v276, function()
						-- upvalues: (copy) p_u_244, (copy) v_u_246, (copy) v_u_257, (copy) v_u_248
						local v277 = p_u_244.LargeCharmModel
						if p_u_244.IsEquipped and (v277 and (v277.PrimaryPart and v_u_246.PrimaryPart)) then
							local v278 = v_u_257:GetPivot():ToObjectSpace(v277:GetPivot())
							local v279 = CFrame.new(v278.Position / 10) * CFrame.fromOrientation(v278:ToOrientation())
							v_u_246:PivotTo(v_u_248:GetPivot() * v279)
						end
					end))
				end
				if p_u_244.CharmModel.PrimaryPart then
					p_u_244.CharmModel.PrimaryPart.Anchored = true
				end
				if p_u_244.ModelJanitor then
					p_u_244.ModelJanitor:Add(function()
						-- upvalues: (copy) v_u_249, (copy) p_u_244
						v_u_249:Destroy()
						p_u_244.LargeWeaponModel = nil
						p_u_244.SmallWeaponModel = nil
						p_u_244.LargeCharmModel = nil
					end)
					debug.profileend()
				else
					debug.profileend()
				end
			else
				v_u_249:Destroy()
				debug.profileend()
				return
			end
		else
			debug.profileend()
			return
		end
	else
		debug.profileend()
		return
	end
end
function v_u_1.new(p280, p281, p282, p283) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_13, (copy) v_u_53, (copy) v_u_12, (copy) v_u_17, (copy) v_u_18, (copy) v_u_7
	debug.profilebegin("Viewmodel.new")
	local v284 = v_u_1
	local v_u_285 = setmetatable({}, v284)
	v_u_285.Janitor = v_u_13.new()
	v_u_285.ModelJanitor = v_u_13.new()
	v_u_285.IsDestroyed = false
	v_u_285.Inspecting = p283
	v_u_285.Player = p280.Player
	v_u_285.Team = (p280.Character or v_u_285.Player):GetAttribute("Team")
	v_u_285.WeaponComponent = p280
	v_u_285.Weapon = p281
	v_u_285.CameraModelWeapon = p280.ViewmodelCameraWeapon or p281
	v_u_285.HideWeaponGeometry = p280.ViewmodelHideWeaponGeometry == true
	v_u_285.Skin = p282
	v_u_285.StatTrack = p280.StatTrack
	v_u_285.Stickers = p280.Stickers
	v_u_285.NameTag = p280.NameTag
	v_u_285.Float = p280.Float
	v_u_285.Charm = p280.Charm
	v_u_285.Hidden = false
	v_u_285.IsEquipped = false
	v_u_285.PivotPlans = setmetatable({}, {
		["__mode"] = "k"
	})
	local v286
	if p283 then
		v286 = nil
	else
		v286 = v_u_53(p280, p281, p282)
	end
	v_u_285.CarryOverKey = v286
	debug.profilebegin("Viewmodel.new.Sound")
	v_u_285.Sound = v_u_12.new(v_u_285.CameraModelWeapon)
	debug.profileend()
	debug.profilebegin("Viewmodel.new.Animation")
	v_u_285.Animation = v_u_17.new(v_u_285.Player, v_u_285.Sound)
	debug.profileend()
	debug.profilebegin("Viewmodel.new.Bobble")
	v_u_285.Bobble = v_u_18.new(p280)
	debug.profileend()
	local v287 = p280.Character or v_u_285.Player.Character
	if v287 then
		debug.profilebegin("Viewmodel.new.InitialConstruct")
		local v288 = v_u_285.construct
		local v289, v290 = pcall(v288, v_u_285, v287, p280)
		debug.profileend()
		if not v289 then
			debug.profileend()
			error(v290, 2)
		end
	end
	if not p280.Character then
		local v_u_291 = v287
		v_u_285.Janitor:Add(v_u_7.observeCharacter(v_u_285.Player, function(p292)
			-- upvalues: (ref) v_u_291, (copy) v_u_285
			if p292 and p292 ~= v_u_291 then
				v_u_285:adoptCharacter(p292)
			end
			v_u_291 = nil
			return function() end
		end))
	end
	v_u_285.Janitor:Add(function()
		-- upvalues: (copy) v_u_285
		if v_u_285.ModelJanitor then
			v_u_285.ModelJanitor:Destroy()
			v_u_285.ModelJanitor = nil
		end
	end)
	debug.profileend()
	return v_u_285
end
function v_u_1.adoptCharacter(p293, p294) -- name: adoptCharacter
	-- upvalues: (copy) v_u_60
	if p293.Model and p293.CharacterKey == v_u_60(p294) then
		p293.Bobble.Character = p294
	elseif p293.WeaponComponent then
		p293:construct(p294, p293.WeaponComponent)
	end
end
function v_u_1.release(p295) -- name: release
	-- upvalues: (copy) v_u_26, (copy) v_u_64
	local v296 = p295.CarryOverKey
	if p295.IsDestroyed or not (p295.Model and v296) then
		p295:destroy()
	else
		if p295.Bobble.IsAiming then
			p295:unaim()
		end
		p295:unequip()
		p295.WeaponComponent = nil
		local v297 = v_u_26
		local v298 = {
			["Viewmodel"] = p295,
			["Key"] = v296,
			["ExpiresAt"] = os.clock() + 5
		}
		table.insert(v297, v298)
		task.delay(5.1, v_u_64)
	end
end
function v_u_1.claim(p299, p300, p301) -- name: claim
	-- upvalues: (copy) v_u_53, (copy) v_u_26
	local v302 = v_u_53(p299, p300, p301)
	if not v302 then
		return nil
	end
	for v303, v304 in v_u_26 do
		local v305 = v304.Viewmodel
		if v304.Key ~= v302 or v305.IsDestroyed then
			continue
		end
		table.remove(v_u_26, v303)
		v305.WeaponComponent = p299
		v305.StatTrack = p299.StatTrack
		local v306 = v305.Player.Character
		if v306 then
			local v307 = v305.adoptCharacter
			if not pcall(v307, v305, v306) then
				v305:destroy()
				return nil
			end
		end
		return v305
	end
	return nil
end
function v_u_1.destroy(p308) -- name: destroy
	if not p308.IsDestroyed then
		debug.profilebegin("Viewmodel.destroy")
		p308.IsDestroyed = true
		if p308.Animation then
			p308.Animation:stopAnimations()
			p308.Animation:destroy()
			p308.Animation = nil
		end
		if p308.Bobble then
			p308.Bobble:destroy()
			p308.Bobble = nil
		end
		if p308.Sound then
			p308.Sound:destroy()
			p308.Sound = nil
		end
		if p308.Model then
			p308.Model.Parent = nil
			p308.Model:Destroy()
			p308.Model = nil
		end
		p308.Janitor:Destroy()
		p308.Janitor = nil
		p308.StatTrack = nil
		p308.Stickers = nil
		p308.NameTag = nil
		p308.Player = nil
		p308.Weapon = nil
		p308.Float = nil
		p308.Charm = nil
		p308.Skin = nil
		p308.Team = nil
		p308.MuzzlePartWeld = nil
		p308.MuzzlePartL = nil
		p308.MuzzlePartR = nil
		p308.MuzzlePart = nil
		p308.OriginalC0 = nil
		p308.CharmModel = nil
		p308.LargeCharmModel = nil
		p308.LargeWeaponModel = nil
		debug.profileend()
	end
end
return v_u_1
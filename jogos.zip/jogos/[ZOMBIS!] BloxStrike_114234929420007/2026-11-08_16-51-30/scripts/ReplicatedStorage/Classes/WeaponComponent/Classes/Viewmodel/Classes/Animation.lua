-- NIGHT Analyzer | ReplicatedStorage.Classes.WeaponComponent.Classes.Viewmodel.Classes.Animation
-- ModuleScript | 596 linhas | 16181 bytes | hash 8d45e2fe

local v_u_1 = {}
v_u_1.__index = v_u_1
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("ReplicatedFirst")
local v_u_4 = game:GetService("ContentProvider")
local v5 = game:GetService("Players")
require(script:WaitForChild("Types"))
local v_u_6 = require(v2.Controllers.RunServiceController)
local v_u_7 = v5.LocalPlayer
local v_u_8 = v_u_7:WaitForChild("PlayerGui")
local v_u_9 = require(v2.Components.Common.GetWeaponProperties)
local v_u_10 = require(v2.Components.Common.VFXLibary.FlashEffect)
local v_u_11 = require(v2.Shared.Janitor)
local v_u_12 = require(v2.Database.Security.Remotes)
local v_u_13 = {
	"7",
	"73",
	"735",
	"7355",
	"73556",
	"735560",
	"7355608"
}
local v_u_14 = {}
local function v_u_19(p15) -- name: preloadClips
	-- upvalues: (copy) v_u_14, (copy) v_u_9, (copy) v_u_4
	if v_u_14[p15] then
		return
	else
		v_u_14[p15] = true
		local v16 = v_u_9(p15)
		if v16 then
			v16 = v16.CameraAnimations
		end
		if typeof(v16) == "Instance" then
			local v17 = {}
			for _, v18 in v16:GetChildren() do
				if not v18:IsA("Animation") then
					continue
				end
				table.insert(v17, v18)
			end
			task.spawn(v_u_4.PreloadAsync, v_u_4, v17)
		end
	end
end
local function v_u_26(p20, p21) -- name: shouldSkipDuplicateSoundEvent
	local v22 = tick()
	local v23 = p20:GetAttribute("LastSoundEventName")
	local v24 = p20:GetAttribute("LastSoundEventTick")
	if v23 == p21 and type(v24) == "number" then
		local v25 = v22 - v24
		if v25 >= 0 and v25 <= 0.02 then
			return true
		end
	end
	p20:SetAttribute("LastSoundEventName", p21)
	p20:SetAttribute("LastSoundEventTick", v22)
	return false
end
local function v_u_37(p_u_27, p28, p29, p30, p31, p32, p33) -- name: handleAnimationSoundEvent
	-- upvalues: (copy) v_u_26, (copy) v_u_7, (copy) v_u_10, (copy) v_u_8, (copy) v_u_12
	if p_u_27.IsDestroyed then
		return
	else
		if p32 then
			p32 = p32:FindFirstChild(p30)
		end
		if p32 and (#p32:GetChildren() > 0 and not v_u_26(p28, p30)) then
			local v34 = p29 == "Inspect" and true or string.match(p29, "^Inspect%d+$") ~= nil
			if not v34 then
				local v35 = string.gsub(p29, "%d+$", "")
				if v35 == "" then
					v35 = p29
				end
				v34 = v35 == "Equip"
			end
			local v_u_36 = (p33 == v_u_7 or v34) and p31:play({
				["Parent"] = v_u_8,
				["Name"] = p30
			}, (v_u_10.GetAudioFadeMultiplier()))
			if v_u_36 then
				p_u_27.ActiveSounds[v_u_36] = p29
				v_u_36.Ended:Once(function()
					-- upvalues: (copy) p_u_27, (copy) v_u_36
					if not p_u_27.IsDestroyed then
						p_u_27.ActiveSounds[v_u_36] = nil
					end
				end)
			end
			if not v34 and (v_u_7 == p33 and (p30 ~= "Prepare" or p31.SoundGroupName ~= "R8 Revolver")) then
				v_u_12.Sound.ReplicateSound.Send({
					["Class"] = p31.SoundGroupName,
					["Name"] = p30
				})
			end
		else
			return
		end
	end
end
local function v_u_57(p38, p_u_39, p_u_40) -- name: connectTrackSoundEvents
	-- upvalues: (copy) v_u_37
	local v_u_41 = p38.Sound
	local v_u_42 = v_u_41.Sounds
	local v_u_43 = p38.Player
	local v_u_44 = {}
	local v_u_45 = setmetatable({}, {
		["__mode"] = "v"
	})
	v_u_45.instance = p38
	local function v48(p46) -- name: onSoundEvent
		-- upvalues: (copy) v_u_45, (ref) v_u_37, (copy) p_u_39, (copy) p_u_40, (copy) v_u_41, (copy) v_u_42, (copy) v_u_43
		local v47 = v_u_45.instance
		if v47 then
			v_u_37(v47, p_u_39, p_u_40, p46, v_u_41, v_u_42, v_u_43)
		end
	end
	local v49 = p_u_39.KeyframeReached
	table.insert(v_u_44, v49:Connect(v48))
	if v_u_42 then
		for _, v50 in ipairs(v_u_42:GetChildren()) do
			if not v50:IsA("Folder") then
				continue
			end
			local v_u_51 = v50.Name
			local v52 = p_u_39:GetMarkerReachedSignal(v_u_51)
			local function v55()
				-- upvalues: (copy) v_u_51, (copy) v_u_45, (ref) v_u_37, (copy) p_u_39, (copy) p_u_40, (copy) v_u_41, (copy) v_u_42, (copy) v_u_43
				local v53 = v_u_51
				local v54 = v_u_45.instance
				if v54 then
					v_u_37(v54, p_u_39, p_u_40, v53, v_u_41, v_u_42, v_u_43)
				end
			end
			table.insert(v_u_44, v52:Connect(v55))
		end
	end
	return function()
		-- upvalues: (copy) v_u_44
		for _, v56 in ipairs(v_u_44) do
			v56:Disconnect()
		end
		table.clear(v_u_44)
	end
end
function v_u_1.getAnimation(p58, p59) -- name: getAnimation
	p58:ensureLoaded()
	return p58.Animations[p59]
end
function v_u_1.hasInspectAnimation(p60) -- name: hasInspectAnimation
	p60:ensureLoaded()
	local v61 = p60.VariantGroups.Inspect
	return v61 and #v61 > 0 and true or p60.Animations.Inspect ~= nil
end
local function v_u_75(p62) -- name: computeVariantProbabilities
	local v63 = #p62
	local v64 = 0
	local v65 = 0
	local v66 = {}
	for _, v67 in ipairs(p62) do
		if v67.weight == nil then
			v65 = v65 + 1
		else
			local v68 = v67.weight
			v64 = v64 + math.max(v68, 0)
		end
	end
	local v69 = 1 - v65 / v63
	local v70 = math.max(0, v69)
	local v71 = v63 - v65
	for v72, v73 in ipairs(p62) do
		if v73.weight == nil then
			v66[v72] = 1 / v63
		elseif v64 > 0 then
			local v74 = v73.weight
			v66[v72] = v70 * (math.max(v74, 0) / v64)
		else
			v66[v72] = v70 / v71
		end
	end
	return v66
end
local function v_u_83(p76, p77) -- name: rollVariant
	-- upvalues: (copy) v_u_75
	if not p76 or #p76 == 0 then
		return p77
	end
	if #p76 == 1 then
		return p76[1].name
	end
	local v78 = v_u_75(p76)
	local v79 = math.random()
	local v80 = 0
	for v81, v82 in ipairs(p76) do
		v80 = v80 + v78[v81]
		if v79 >= v80 then
			continue
		end
		return v82.name
	end
	return p76[#p76].name
end
function v_u_1.pickVariant(p84, p85) -- name: pickVariant
	-- upvalues: (copy) v_u_83
	p84:ensureLoaded()
	return v_u_83(p84.VariantGroups[p85], p85)
end
function v_u_1.pickInspectVariant(p86) -- name: pickInspectVariant
	-- upvalues: (copy) v_u_83
	p86:ensureLoaded()
	local v87 = os.clock()
	if p86.LastInspectVariant and (p86.LastInspectCancelTime and (v87 - p86.LastInspectCancelTime <= 1 and p86.Animations[p86.LastInspectVariant])) then
		return p86.LastInspectVariant
	end
	local v88 = v_u_83(p86.VariantGroups.Inspect, "Inspect")
	p86.LastInspectVariant = v88
	return v88
end
function v_u_1.markInspectCancel(p89) -- name: markInspectCancel
	p89.LastInspectCancelTime = os.clock()
end
function v_u_1.adjustAnimationSpeed(p90, p91, p92) -- name: adjustAnimationSpeed
	local v93 = p90:getAnimation(p91)
	if v93 then
		v93:AdjustSpeed(v93.Length / p92)
	end
end
function v_u_1.play(p94, p95, ...) -- name: play
	local v96 = p94:getAnimation(p95)
	if v96 then
		v96:Play(...)
	end
	return v96
end
function v_u_1.stop(p97, p98, p99) -- name: stop
	local v100 = p97.Animations[p98]
	if v100 and v100.IsPlaying then
		v100:Stop(p99 or 0)
	end
end
function v_u_1.cancelCrossfade(p101) -- name: cancelCrossfade
	if p101.CrossfadeConnection then
		p101.CrossfadeConnection:Disconnect()
		p101.CrossfadeConnection = nil
	end
	if p101.CrossfadeTempTrack then
		p101.CrossfadeTempTrack:Stop(0)
		p101.CrossfadeTempTrack:Destroy()
		p101.CrossfadeTempTrack = nil
	end
end
function v_u_1.crossfadeRestart(p_u_102, p103, p104) -- name: crossfadeRestart
	-- upvalues: (copy) v_u_57, (copy) v_u_6
	local v_u_105 = p104 or 0.25
	p_u_102:cancelCrossfade()
	local v106 = p_u_102.VariantGroups
	local v107 = string.gsub(p103, "%d+$", "")
	if v107 == "" then
		v107 = p103
	end
	local v108 = v106[v107]
	if v108 then
		for _, v109 in ipairs(v108) do
			if v109.name == p103 then
				continue
			end
			local v110 = p_u_102.Animations[v109.name]
			if not (v110 and v110.IsPlaying) then
				continue
			end
			v110:Stop(0)
		end
	end
	local v_u_111 = p_u_102:getAnimation(p103)
	if not v_u_111 then
		return nil
	end
	if not v_u_111.IsPlaying then
		v_u_111:Play(0, 1, 1)
		return v_u_111
	end
	local v112 = v_u_111.WeightCurrent
	local v_u_113 = math.max(v112, 0.5)
	local v_u_114 = v_u_111.Animation
	local v115, v_u_116
	if v_u_114 then
		v115, v_u_116 = pcall(function()
			-- upvalues: (copy) p_u_102, (copy) v_u_114
			return p_u_102.Animator:LoadAnimation(v_u_114)
		end)
	else
		v115 = false
		v_u_116 = nil
	end
	if not (v115 and v_u_116) then
		v_u_111:Stop(0)
		v_u_111:Play(0, 1, 1)
		return v_u_111
	end
	local v_u_117 = v_u_57(p_u_102, v_u_116, p103)
	v_u_116:Play(0, 0.01, 1)
	v_u_116.TimePosition = 0
	p_u_102.CrossfadeTempTrack = v_u_116
	local v_u_118 = tick()
	local v119 = v_u_6.CreateBindingName("Classes.Viewmodel.Animation.Crossfade")
	p_u_102.CrossfadeConnection = v_u_6.BindToRenderStep(v119, function()
		-- upvalues: (copy) p_u_102, (copy) v_u_117, (copy) v_u_118, (copy) v_u_105, (copy) v_u_111, (copy) v_u_113, (ref) v_u_116
		if p_u_102.IsDestroyed then
			v_u_117()
			p_u_102:cancelCrossfade()
		else
			local v120 = (tick() - v_u_118) / v_u_105
			local v121 = math.clamp(v120, 0, 1)
			local v122 = v121 * 3 * v121 - v121 * 2 * v121 * v121
			v_u_111:AdjustWeight(v_u_113 * (1 - v122), 0)
			v_u_116:AdjustWeight(math.max(v122, 0.01), 0)
			if v121 >= 1 then
				v_u_117()
				local v123 = v_u_116.TimePosition
				v_u_111:Stop(0)
				v_u_111:Play(0, 1, 1)
				v_u_111.TimePosition = v123
				v_u_111:AdjustWeight(1, 0)
				p_u_102:cancelCrossfade()
			end
		end
	end)
	return v_u_111
end
function v_u_1.crossfadeTo(p_u_124, p125, p126) -- name: crossfadeTo
	-- upvalues: (copy) v_u_6
	p_u_124:cancelCrossfade()
	local v_u_127 = {}
	local v_u_128 = p126 or 0.25
	for v129, v130 in pairs(p_u_124.Animations) do
		if not v130.IsPlaying or (v129 == "Idle" or v129 == p125) then
			continue
		end
		local v131 = {
			["track"] = v130,
			["startWeight"] = v130.WeightCurrent
		}
		table.insert(v_u_127, v131)
	end
	local v_u_132 = p_u_124:getAnimation(p125)
	local v_u_133 = p125 == "Idle"
	if not (v_u_132 or v_u_133) then
		return nil
	end
	if not v_u_133 then
		v_u_132:Play(0, 0, 1)
	end
	local v_u_134 = tick()
	local v135 = v_u_6.CreateBindingName("Classes.Viewmodel.Animation.Crossfade")
	p_u_124.CrossfadeConnection = v_u_6.BindToRenderStep(v135, function()
		-- upvalues: (copy) p_u_124, (copy) v_u_134, (copy) v_u_128, (copy) v_u_127, (copy) v_u_133, (copy) v_u_132
		if p_u_124.IsDestroyed then
			p_u_124:cancelCrossfade()
		else
			local v136 = (tick() - v_u_134) / v_u_128
			local v137 = math.clamp(v136, 0, 1)
			local v138 = 1 - v137
			local v139 = v138 * 3 * v138 - v138 * 2 * v138 * v138
			for _, v140 in ipairs(v_u_127) do
				v140.track:AdjustWeight(v140.startWeight * v139, 0)
			end
			if not v_u_133 then
				v_u_132:AdjustWeight(1 - v139, 0)
			end
			if v137 >= 1 then
				for _, v141 in ipairs(v_u_127) do
					if not v141.track.IsPlaying then
						continue
					end
					v141.track:Stop(0)
				end
				if v_u_133 and v_u_132 then
					v_u_132:Play(0, 1, 1)
				elseif v_u_132 then
					v_u_132:AdjustWeight(1, 0)
				end
				p_u_124:cancelCrossfade()
			end
		end
	end)
	return v_u_132
end
function v_u_1.isIdle(p142) -- name: isIdle
	if p142.CrossfadeTempTrack then
		return false
	end
	for v143, v144 in pairs(p142.Animations) do
		if v143 == "Idle" or not v144.IsPlaying then
			continue
		end
		return false
	end
	return true
end
function v_u_1.stopAnimations(p145, p146) -- name: stopAnimations
	p145:cancelCrossfade()
	for _, v147 in pairs(p145.Animations) do
		if not v147.IsPlaying then
			continue
		end
		v147:Stop(p146 or 0)
	end
	p145:stopSounds()
end
function v_u_1.stopSounds(p148) -- name: stopSounds
	for v149, v151 in pairs(p148.ActiveSounds) do
		if v151 then
			local v151 = string.find(v151, "Shoot") ~= nil
		end
		if v151 then
			continue
		end
		p148.ActiveSounds[v149] = nil
		if not (v149 and v149.Parent) then
			continue
		end
		v149:Destroy()
	end
end
function v_u_1.unregister(p152, p153) -- name: unregister
	local v154 = p152.Animations[p153]
	if v154 then
		p152.Janitor:Remove("AnimationSoundConnections_" .. p153)
		p152.Janitor:RemoveNoClean("AnimationCleanup_" .. p153)
		p152.Animations[p153] = nil
		if v154.IsPlaying then
			v154:Stop()
		end
		v154:Destroy()
	end
end
function v_u_1.register(p_u_155, p_u_156, p_u_157) -- name: register
	-- upvalues: (copy) v_u_57
	p_u_155:unregister(p_u_156)
	local v158, v159 = pcall(function()
		-- upvalues: (copy) p_u_155, (copy) p_u_157
		return p_u_155.Animator:LoadAnimation(p_u_157)
	end)
	if v158 then
		p_u_155.Animations[p_u_156] = v159
		local v_u_160 = setmetatable({}, {
			["__mode"] = "v"
		})
		v_u_160.instance = p_u_155
		p_u_155.Janitor:Add(function()
			-- upvalues: (copy) v_u_160, (copy) p_u_156
			local v161 = v_u_160.instance
			if v161 and not v161.IsDestroyed then
				v161:unregister(p_u_156)
			end
		end, true, "AnimationCleanup_" .. p_u_156)
		p_u_155.Janitor:Add(v_u_57(p_u_155, v159, p_u_156), true, "AnimationSoundConnections_" .. p_u_156)
	end
end
function v_u_1.construct(p162) -- name: construct
	-- upvalues: (copy) v_u_9
	local v163 = v_u_9(p162.Animation)
	if v163 then
		local v164 = v163.CameraAnimations
		if typeof(v164) == "Instance" and v164:IsA("Folder") then
			p162.VariantGroups = {}
			for _, v165 in ipairs(v164:GetChildren()) do
				if not v165:IsA("Animation") then
					continue
				end
				p162:register(v165.Name, v165)
				if not p162.Animations[v165.Name] then
					continue
				end
				local v166 = v165.Name
				local v167 = string.gsub(v166, "%d+$", "")
				if v167 == "" then
					v167 = v166
				end
				local v168 = v165:FindFirstChildWhichIsA("IntValue") or v165:FindFirstChildWhichIsA("NumberValue")
				local v169 = p162.VariantGroups[v167]
				if not v169 then
					v169 = {}
					p162.VariantGroups[v167] = v169
				end
				local v170 = {
					["name"] = v165.Name
				}
				local v171
				if v168 then
					v171 = v168.Value
				else
					v171 = nil
				end
				v170.weight = v171
				table.insert(v169, v170)
			end
		end
	else
		return
	end
end
function v_u_1.setModel(p172, p173) -- name: setModel
	-- upvalues: (copy) v_u_19
	if p173 then
		p172.Animation = p173.Name
		p172.Model = p173
		p172.Animator = p173:WaitForChild("AnimationController"):WaitForChild("Animator")
		p172:stopAnimations()
		for v174 in table.clone(p172.Animations) do
			p172:unregister(v174)
		end
		p172.VariantGroups = {}
		p172.Loaded = false
		v_u_19(p173.Name)
		if p172.Animation == "C4" then
			local v175 = p173:FindFirstChild("Weapon")
			if v175 then
				v175 = p173.Weapon:FindFirstChild("Interactive")
			end
			if v175 and v175:FindFirstChild("SurfaceGui") then
				v175.SurfaceGui.TextLabel.Text = "*******"
			end
		end
	end
end
function v_u_1.ensureLoaded(p_u_176) -- name: ensureLoaded
	-- upvalues: (copy) v_u_3, (copy) v_u_13, (copy) v_u_7
	local v177 = p_u_176.Model
	if not p_u_176.Loaded and (not p_u_176.IsDestroyed and (v177 and p_u_176.Animator)) then
		p_u_176.Loaded = true
		local v178 = not v177:IsDescendantOf(game)
		local v179 = v177.Parent
		if v178 then
			v177.Parent = v_u_3
		end
		p_u_176:construct()
		if v178 then
			v177.Parent = v179
		end
		if p_u_176.Animation == "C4" then
			local v_u_180 = v177:FindFirstChild("Weapon")
			if v_u_180 then
				v_u_180 = v177.Weapon:FindFirstChild("Interactive")
			end
			for _, v181 in pairs(p_u_176.Animations) do
				p_u_176.Janitor:Add(v181.KeyframeReached:Connect(function(p182)
					-- upvalues: (ref) v_u_13, (copy) v_u_180, (copy) p_u_176, (ref) v_u_7
					if table.find(v_u_13, p182) then
						if v_u_180 and v_u_180:FindFirstChild("SurfaceGui") then
							v_u_180.SurfaceGui.TextLabel.Text = string.rep("*", 7 - #p182) .. p182
						end
						p_u_176.Sound:play({
							["Parent"] = v_u_7.PlayerGui,
							["Name"] = p182
						})
					end
				end))
			end
		end
	end
end
function v_u_1.new(p183, p184) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_11
	local v185 = v_u_1
	local v186 = setmetatable({}, v185)
	v186.Janitor = v_u_11.new()
	v186.IsDestroyed = false
	v186.Player = p183
	v186.ActiveSounds = {}
	v186.Animations = {}
	v186.VariantGroups = {}
	v186.Sound = p184
	return v186
end
function v_u_1.destroy(p187) -- name: destroy
	if not p187.IsDestroyed then
		p187.IsDestroyed = true
		p187:stopAnimations()
		for v188 in pairs(p187.Animations) do
			p187:unregister(v188)
		end
		p187:stopSounds()
		table.clear(p187.ActiveSounds)
		table.clear(p187.Animations)
		table.clear(p187.VariantGroups)
		p187.Animation = nil
		p187.Animator = nil
		p187.Player = nil
		p187.Sound = nil
		p187.Janitor:Destroy()
		p187.Janitor = nil
	end
end
return v_u_1
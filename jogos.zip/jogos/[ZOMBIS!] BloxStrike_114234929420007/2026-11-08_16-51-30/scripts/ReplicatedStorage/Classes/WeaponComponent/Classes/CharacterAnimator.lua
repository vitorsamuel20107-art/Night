-- NIGHT Analyzer | ReplicatedStorage.Classes.WeaponComponent.Classes.CharacterAnimator
-- ModuleScript | 98 linhas | 2436 bytes | hash baad513d

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Classes.Character.Classes.CharacterAnimator)
local v_u_3 = require(v1.Components.Common.GetWeaponProperties)
local v_u_4 = require(v1.Components.Common.CharacterResolver)
local v_u_5 = require(v1.Shared.Janitor)
local v_u_6 = {}
v_u_6.__index = v_u_6
local function v_u_12(p7, p8) -- name: bind
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	if p7._animator then
		p7._animator:destroy()
		p7._animator = nil
		p7.Animations = {}
	end
	if not p7.IsDestroyed and p8 then
		local v9 = v_u_2.new(p8, {
			["SkipBaseAnimations"] = true
		})
		v9.Player = p7.Player
		v9.WeaponName = p7.Weapon
		local v10 = v_u_3(p7.Weapon)
		if v10 then
			v10 = v10.CharacterAnimations
		end
		if v10 then
			for _, v11 in ipairs(v10:GetChildren()) do
				if not v11:IsA("Animation") then
					continue
				end
				v9:register(v11.Name, v11)
				v9.WeaponAnimationNames[v11.Name] = true
			end
		end
		p7._animator = v9
		p7.Animations = v9.Animations
	end
end
function v_u_6.getAnimation(p13, p14) -- name: getAnimation
	return p13.Animations[p14]
end
function v_u_6.play(p15, p16, ...) -- name: play
	local v17 = p15._animator
	if v17 then
		return v17:play(p16, ...)
	else
		return nil
	end
end
function v_u_6.stop(p18, p19, ...) -- name: stop
	local v20 = p18._animator
	if v20 then
		v20:stop(p19, ...)
	end
end
function v_u_6.stopAnimations(p21, p22) -- name: stopAnimations
	local v23 = p21._animator
	if v23 then
		v23:stopAnimations(p22)
	end
end
function v_u_6.adjustAnimationSpeed(p24, p25, p26) -- name: adjustAnimationSpeed
	local v27 = p24._animator
	if v27 then
		v27:adjustAnimationSpeed(p25, p26)
	end
end
function v_u_6.new(p28, p29, p30) -- name: new
	-- upvalues: (copy) v_u_6, (copy) v_u_5, (copy) v_u_12, (copy) v_u_4
	local v31 = v_u_6
	local v_u_32 = setmetatable({}, v31)
	v_u_32.Janitor = v_u_5.new()
	v_u_32.IsDestroyed = false
	v_u_32.Player = p28
	v_u_32.Weapon = p29
	v_u_32.Animations = {}
	if p30 then
		v_u_12(v_u_32, p30)
		return v_u_32
	else
		v_u_32.Janitor:Add(v_u_4.observeCharacter(p28, function(p33)
			-- upvalues: (ref) v_u_12, (copy) v_u_32
			v_u_12(v_u_32, p33)
		end))
		return v_u_32
	end
end
function v_u_6.destroy(p34) -- name: destroy
	if not p34.IsDestroyed then
		p34.IsDestroyed = true
		if p34._animator then
			p34._animator:destroy()
			p34._animator = nil
		end
		p34.Animations = {}
		p34.Janitor:Destroy()
	end
end
return v_u_6
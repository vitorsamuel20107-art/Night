-- NIGHT Analyzer | ReplicatedStorage.Classes.WeaponComponent.Types
-- ModuleScript | 5 linhas | 181 bytes | hash 6c133f62

local v1 = game:GetService("ReplicatedStorage")
require(v1.Database.Custom.Types)
require(script.Parent.Classes.CharacterAnimator)
require(script.Parent.Classes.Viewmodel)
return {}
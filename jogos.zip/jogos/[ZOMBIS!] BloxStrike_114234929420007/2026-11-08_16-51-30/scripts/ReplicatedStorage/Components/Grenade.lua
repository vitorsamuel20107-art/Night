-- NIGHT Analyzer | ReplicatedStorage.Components.Grenade
-- ModuleScript | 362 linhas | 11775 bytes | hash eace697e

local v_u_1 = {}
v_u_1.__index = v_u_1
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Players")
require(v2.Database.Custom.Types)
local v_u_5 = require(v2.Classes.WeaponComponent)
local v_u_6 = require(v2.Controllers.InputController)
local v_u_7 = require(v2.Database.Components.GameState)
local v_u_8 = require(v2.Components.Common.CharacterResolver)
local v_u_9 = require(v2.Components.Common.SurvivalDowned)
local v_u_10 = require(v2.Components.Common.GetCharacterVelocity)
local v_u_11 = require(v2.Components.Common.ReplicateCharacterAction)
local v_u_12 = require(v2.Database.Security.Remotes)
local v_u_13 = require(v2.Database.Security.Router)
local v_u_14 = workspace.CurrentCamera
local v_u_15 = { "StartThrow", "ThrowIdle" }
local function v_u_20(p16, p17) -- name: stopPlayingTracks
	for v18, v19 in pairs(p16.Animations) do
		if not v19.IsPlaying or (v19.Name == "Idle" or p17 and v19.Name == "Equip") then
			continue
		end
		p16:stop(v18)
	end
end
function v_u_1.stopAllAnimations(p21) -- name: stopAllAnimations
	-- upvalues: (copy) v_u_20
	if p21.CharacterAnimator and (p21.Viewmodel and p21.Viewmodel.Animation) then
		v_u_20(p21.CharacterAnimator, false)
		v_u_20(p21.Viewmodel.Animation, false)
	end
end
function v_u_1.StartThrow(p22) -- name: StartThrow
	-- upvalues: (copy) v_u_7, (copy) v_u_9, (copy) v_u_4, (copy) v_u_8, (copy) v_u_13, (copy) v_u_14, (copy) v_u_20, (copy) v_u_11
	if not p22.IsDestroyed then
		local v23
		if workspace:GetAttribute("ServerGamemode") == "Competitive" then
			v23 = v_u_7.GetState() == "Buy Period"
		else
			v23 = false
		end
		if not v23 and (p22.EquipTime <= 0 or tick() - p22.EquipTime >= 0.7) then
			local v24
			if p22.LastThrowTime > 0 then
				v24 = tick() - p22.LastThrowTime < 0.7
			else
				v24 = false
			end
			if not v24 and (not p22.ThrowStarted or p22.ThrowFinished) and not v_u_9.AreHandsBusy(v_u_4.LocalPlayer) then
				if p22.ThrowFinished then
					p22.ThrowFinished = false
					p22.ThrowStarted = false
					p22.Janitor:Remove("ThrowGrenadeFinished")
					p22.Janitor:Remove("ThrowGrenadeStoppedFallback")
				end
				local v25 = v_u_8.getLocalCharacter()
				if v25 and v25:GetAttribute("Dead") then
					return
				else
					p22.ThrowStarted = true
					v_u_13.broadcastRouter("Cancel Sprint")
					if p22.Viewmodel and (not p22.Viewmodel.IsDestroyed and p22.Viewmodel.Model) then
						if p22.Viewmodel.Model.Parent ~= v_u_14 then
							if not p22.Viewmodel.equip then
								return
							end
							p22.Viewmodel:equip(false)
						end
						if p22.Viewmodel.Hidden then
							p22.Viewmodel:unhide()
						end
						local v26
						if p22.LastThrowTime > 0 then
							v26 = tick() - p22.LastThrowTime < 0.7
						else
							v26 = false
						end
						if v26 then
							p22.ThrowStarted = false
							return
						elseif not p22.Viewmodel.IsDestroyed then
							local v27 = p22.Viewmodel.Animation.Animations.Equip
							if v27 then
								v27 = v27.IsPlaying
							end
							if v27 then
								v_u_20(p22.Viewmodel.Animation, true)
								v_u_20(p22.CharacterAnimator, true)
							else
								p22:stopAllAnimations()
							end
							p22.CharacterAnimator:play("StartThrow")
							p22.CharacterAnimator:play("ThrowIdle")
							v_u_11("StartThrow")
							if p22.Viewmodel and (not p22.Viewmodel.IsDestroyed and (p22.Viewmodel.Model and p22.Viewmodel.Model.Parent == v_u_14)) then
								local v28 = p22.Viewmodel.Animation:play("ThrowIdle")
								p22.Viewmodel.Animation:play("StartThrow")
								if v28 then
									v28.Looped = true
								end
							end
						end
					else
						return
					end
				end
			end
		end
	end
end
function v_u_1.Throw(p_u_29, p_u_30) -- name: Throw
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_14, (copy) v_u_3, (copy) v_u_20, (copy) v_u_15, (copy) v_u_11, (copy) v_u_13
	if p_u_29.ThrowFinished then
		return
	else
		local v31
		if workspace:GetAttribute("ServerGamemode") == "Competitive" then
			v31 = v_u_7.GetState() == "Buy Period"
		else
			v31 = false
		end
		if v31 then
			if p_u_29.ThrowStarted and not p_u_29.ThrowFinished then
				p_u_29:Cancel()
			end
			return
		else
			local v32 = v_u_8.getLocalCharacter()
			if v32 and v32:GetAttribute("Dead") then
				return
			elseif p_u_29.Viewmodel and (not p_u_29.Viewmodel.IsDestroyed and p_u_29.Viewmodel.Model) then
				if p_u_29.Viewmodel.Model.Parent ~= v_u_14 then
					if not p_u_29.Viewmodel.equip then
						p_u_29.ThrowStarted = false
						return
					end
					p_u_29.Viewmodel:equip(false)
					v_u_3.Heartbeat:Wait()
					if p_u_29.Viewmodel.Model.Parent ~= v_u_14 then
						p_u_29.ThrowStarted = false
						return
					end
				end
				if p_u_29.Viewmodel.Hidden then
					p_u_29.Viewmodel:unhide()
				end
				if p_u_29.Viewmodel.Animation then
					p_u_29.Janitor:Remove("ThrowGrenadeFinished")
					p_u_29.Janitor:Remove("ThrowGrenadeStoppedFallback")
					local v33 = p_u_29.Viewmodel.Animation.Animations.Equip
					if v33 then
						v33 = v33.IsPlaying
					end
					if v33 then
						p_u_29.Viewmodel.Animation:stop("Equip")
						p_u_29.CharacterAnimator:stop("Equip")
						v_u_20(p_u_29.Viewmodel.Animation, false)
						v_u_20(p_u_29.CharacterAnimator, false)
						v_u_3.Heartbeat:Wait()
					else
						for _, v34 in { p_u_29.Viewmodel.Animation, p_u_29.CharacterAnimator } do
							for _, v35 in v_u_15 do
								if not v34.Animations[v35] then
									continue
								end
								v34:stop(v35)
							end
						end
					end
					if p_u_29.Viewmodel and (not p_u_29.Viewmodel.IsDestroyed and p_u_29.Viewmodel.Animation) then
						local v36 = p_u_29.Viewmodel.Animation:play(p_u_30)
						if v36 then
							local v37 = tick()
							while v36.Length == 0 and tick() - v37 < 0.5 do
								v_u_3.Heartbeat:Wait()
							end
							if p_u_29.IsDestroyed or (not p_u_29.Viewmodel or p_u_29.Viewmodel.IsDestroyed) then
								p_u_29.ThrowStarted = false
								return
							else
								p_u_29.CharacterAnimator:play("Throw")
								v_u_11("Throw")
								p_u_29.ThrowCompleted = false
								local function v_u_38() -- name: completeThrow
									-- upvalues: (copy) p_u_29, (ref) v_u_13, (copy) p_u_30
									if p_u_29.ThrowCompleted then
										return
									else
										p_u_29.ThrowCompleted = true
										if not p_u_29.IsDestroyed and p_u_29.Identifier then
											p_u_29.ThrowFinished = true
											p_u_29.ThrowStarted = false
											p_u_29.LastThrowTime = tick()
											if v_u_13.broadcastRouter("PredictGrenadeThrow", p_u_29.Identifier, p_u_30) ~= true then
												p_u_29.ThrowFinished = false
												p_u_29.ThrowCompleted = false
												warn("[Grenade] Could not queue ordered grenade transition")
											end
										end
									end
								end
								if v36.IsPlaying then
									local function v39() -- name: fallbackThrow
										-- upvalues: (copy) p_u_29, (copy) v_u_38
										if not p_u_29.ThrowCompleted and (not p_u_29.IsDestroyed and (p_u_29.ThrowStarted and not p_u_29.ThrowFinished)) then
											v_u_38()
										end
									end
									p_u_29.Janitor:Add(v36:GetMarkerReachedSignal("Throw"):Once(v_u_38), "Disconnect", "ThrowGrenadeFinished")
									p_u_29.Janitor:Add(v36.Stopped:Once(function()
										-- upvalues: (copy) p_u_29, (copy) v_u_38
										task.delay(0.05, function()
											-- upvalues: (ref) p_u_29, (ref) v_u_38
											if not (p_u_29.ThrowCompleted or p_u_29.IsDestroyed) then
												v_u_38()
											end
										end)
									end), "Disconnect", "ThrowGrenadeStoppedFallback")
									if v36.Length > 0 then
										local v_u_40 = task.delay(v36.Length * 0.7, v39)
										p_u_29.Janitor:Add(function()
											-- upvalues: (copy) v_u_40
											task.cancel(v_u_40)
										end, false, "ThrowGrenadeDelayFallback2")
									end
									local v_u_41 = task.delay(2, v39)
									p_u_29.Janitor:Add(function()
										-- upvalues: (copy) v_u_41
										task.cancel(v_u_41)
									end, false, "ThrowGrenadeDelayFallback3")
								else
									p_u_29.ThrowStarted = false
								end
							end
						else
							p_u_29.ThrowStarted = false
							return
						end
					else
						p_u_29.ThrowStarted = false
						return
					end
				else
					p_u_29.ThrowStarted = false
					return
				end
			else
				p_u_29.ThrowStarted = false
				return
			end
		end
	end
end
function v_u_1.Cancel(p42) -- name: Cancel
	-- upvalues: (copy) v_u_11
	if not p42.ThrowFinished then
		p42.Janitor:Remove("ThrowGrenadeFinished")
		p42.Janitor:Remove("ThrowGrenadeStoppedFallback")
		p42.Janitor:Remove("ThrowGrenadeDelayFallback2")
		p42.Janitor:Remove("ThrowGrenadeDelayFallback3")
		p42.ThrowFinished = false
		p42.ThrowStarted = false
		p42.ThrowCompleted = false
		p42:stopAllAnimations()
		v_u_11("CancelThrow")
	end
end
function v_u_1.inspect(p_u_43) -- name: inspect
	-- upvalues: (copy) v_u_11
	if not p_u_43.IsInspecting then
		if p_u_43.ThrowStarted and not p_u_43.ThrowFinished then
			p_u_43:Cancel()
		end
		p_u_43.IsInspecting = true
		p_u_43:stopAllAnimations()
		local v44 = p_u_43.Viewmodel.Animation:play("Inspect")
		v_u_11("Inspect")
		task.delay(v44.Length, function()
			-- upvalues: (copy) p_u_43
			p_u_43.IsInspecting = false
		end)
	end
end
function v_u_1.reload(_) -- name: reload end
function v_u_1.drop(p45) -- name: drop
	-- upvalues: (copy) v_u_7, (copy) v_u_12, (copy) v_u_10, (copy) v_u_8, (copy) v_u_14
	if workspace:GetAttribute("Gamemode") == "Deathmatch" or (v_u_7.GetState() == "Warmup" or not p45.Properties.Droppable) then
		return false
	end
	p45:unequip()
	v_u_12.Inventory.DropWeapon.Send({
		["CharacterVelocity"] = v_u_10(v_u_8.getLocalCharacter()),
		["Direction"] = v_u_14.CFrame.LookVector,
		["Identifier"] = p45.Identifier
	})
	return true
end
function v_u_1.equip(p_u_46) -- name: equip
	-- upvalues: (copy) v_u_7, (copy) v_u_6
	p_u_46.EquipTime = tick()
	p_u_46.Janitor:Remove("EquipDelayThrow")
	p_u_46.Viewmodel.Animation:stopAnimations()
	p_u_46.CharacterAnimator:stopAnimations()
	p_u_46.ThrowStarted = false
	p_u_46.ThrowFinished = false
	p_u_46.ThrowCompleted = false
	p_u_46.CharacterAnimator:play("Idle")
	p_u_46.CharacterAnimator:play("Equip")
	p_u_46.Viewmodel:equip(false)
	local v_u_47 = task.delay(0.7, function()
		-- upvalues: (copy) p_u_46, (ref) v_u_7, (ref) v_u_6
		if p_u_46.IsDestroyed then
			return
		elseif v_u_7.GetState() ~= "Buy Period" then
			if v_u_6.isActionPressed("Fire", { Enum.UserInputType.MouseButton1, Enum.KeyCode.ButtonR2 }) then
				p_u_46:StartThrow()
			end
		end
	end)
	p_u_46.Janitor:Add(function()
		-- upvalues: (copy) v_u_47
		task.cancel(v_u_47)
	end, false, "EquipDelayThrow")
end
function v_u_1.unequip(p48) -- name: unequip
	p48.Janitor:Remove("EquipDelayThrow")
	p48.CharacterAnimator:stopAnimations()
	p48.Viewmodel:unequip()
	p48.IsInspecting = false
	if p48.ThrowStarted and not p48.ThrowFinished then
		p48:Cancel()
	end
end
function v_u_1.new(p49, p50, p51, p52, p53, p54, p55, p56, p57, p58, p59, p60, _) -- name: new
	-- upvalues: (copy) v_u_5, (copy) v_u_1
	local v61 = v_u_5.new(p49, p50, p51, p52, p53, p54, p55, p56, p57, p58, p59, p60)
	local v62 = v_u_1
	local v63 = setmetatable(v61, v62)
	v63.IsInspecting = false
	v63.ThrowStarted = false
	v63.ThrowFinished = false
	v63.ThrowCompleted = false
	v63.LastThrowTime = 0
	v63.EquipTime = 0
	return v63
end
function v_u_1.destroy(p64) -- name: destroy
	-- upvalues: (copy) v_u_5
	if not p64.IsDestroyed then
		p64.IsDestroyed = true
		if p64.Janitor then
			p64.Janitor:Destroy()
			p64.Janitor = nil
		end
		p64.ThrowFinished = nil
		p64.ThrowStarted = nil
		p64.ThrowCompleted = nil
		p64.IsInspecting = nil
		v_u_5.destroy(p64)
	end
end
return v_u_1
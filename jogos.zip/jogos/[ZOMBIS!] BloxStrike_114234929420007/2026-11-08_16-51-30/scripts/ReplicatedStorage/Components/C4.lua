-- NIGHT Analyzer | ReplicatedStorage.Components.C4
-- ModuleScript | 244 linhas | 8292 bytes | hash 8d4d83a2

local v_u_1 = {}
v_u_1.__index = v_u_1
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("Players")
require(v_u_2.Database.Custom.Types)
local v_u_5 = require(v_u_2.Controllers.RunServiceController)
local v_u_6 = require(v_u_2.Classes.WeaponComponent)
local v_u_7 = require(v_u_2.Database.Components.GameState)
local v_u_8 = require(v_u_2.Components.Common.CharacterResolver)
local v_u_9 = require(v_u_2.Components.Common.IsTutorialMode)
local v_u_10 = require(v_u_2.Components.Common.GetCharacterVelocity)
local v_u_11 = require(v_u_2.Components.Common.ReplicateCharacterAction)
local v_u_12 = require(v_u_2.MovementV2.RuntimeKinematics)
local v_u_13 = require(v_u_2.Database.Security.Remotes)
local v_u_14 = require(v_u_2.Database.Security.Router)
local v_u_15 = workspace.CurrentCamera
local v_u_16 = workspace:WaitForChild("Debris")
local v_u_17 = nil
local v_u_18 = (-1 / 0)
local v_u_19 = RaycastParams.new()
v_u_19.FilterType = Enum.RaycastFilterType.Exclude
v_u_19.IgnoreWater = true
local function v_u_28() -- name: PlayerCanPlantC4
	-- upvalues: (copy) v_u_8, (copy) v_u_19, (copy) v_u_15, (copy) v_u_16, (copy) v_u_12, (copy) v_u_4
	local v20 = v_u_8.getLocalCharacter()
	v_u_19.FilterDescendantsInstances = { v20, v_u_15, v_u_16 }
	if not (v_u_8.isAliveCharacter(v20) and v_u_12.isOnGround(v20)) then
		return false
	end
	local v21 = v20.PrimaryPart
	if not v21 then
		return false
	end
	local v22 = { v_u_15, v_u_16 }
	for _, v23 in ipairs(v_u_4:GetPlayers()) do
		if not v23.Character then
			continue
		end
		local v24 = v23.Character
		table.insert(v22, v24)
	end
	local v25 = workspace:FindFirstChild("Map")
	local v26
	if v25 then
		v26 = v25:FindFirstChild("Barriers")
	else
		v26 = nil
	end
	if v26 then
		table.insert(v22, v26)
	end
	v_u_19.FilterDescendantsInstances = v22
	local v27 = workspace:Raycast(v21.Position, Vector3.new(-0, -5, -0), v_u_19)
	return v27 and (v27.Instance:HasTag("PlantArea") and v27.Instance:GetAttribute("Site")) and true or false
end
local function v_u_33(p29) -- name: NotifyPlantCancelled
	-- upvalues: (copy) v_u_9, (copy) v_u_3, (copy) v_u_2, (copy) v_u_8, (ref) v_u_18, (copy) v_u_14
	local v30 = nil
	local v31
	if p29 == nil and v_u_9() then
		if v_u_3.PreferredInput == Enum.PreferredInput.Touch then
			v31 = "Keep holding the <b>Shoot</b> button until the bomb is planted"
		else
			local v32 = require(v_u_2.Interface.Screens.Gameplay.Middle.Tips).GetActionKeyText("Fire")
			v31 = not v32 and "Keep holding the fire button until the bomb is planted" or ("Keep holding <b>%*</b> until the bomb is planted"):format(v32)
		end
	else
		v31 = p29 == "LeftPlantArea" and v_u_8.isAliveCharacter(v_u_8.getLocalCharacter()) and "Stay on the ground inside the bombsite until the bomb is planted" or v30
	end
	if v31 and os.clock() - v_u_18 >= 2 then
		v_u_18 = os.clock()
		v_u_14.broadcastRouter("CreateNotification", "Plant Cancelled", v31, 3)
	end
end
local function v_u_36() -- name: NotifyPlantOffSite
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (ref) v_u_18, (copy) v_u_12, (copy) v_u_14
	local v34 = v_u_8.getLocalCharacter()
	if v_u_9() and v_u_8.isAliveCharacter(v34) then
		if os.clock() - v_u_18 >= 2 then
			v_u_18 = os.clock()
			local v35 = v_u_12.isOnGround(v34) and "Plant the bomb at the bombsite" or "Stand on the ground inside the bombsite to plant the bomb"
			v_u_14.broadcastRouter("CreateNotification", "Can\'t Plant Here", v35, 3)
		end
	else
		return
	end
end
function v_u_1.stopAllAnimations(p37) -- name: stopAllAnimations
	if p37.CharacterAnimator and (p37.Viewmodel and p37.Viewmodel.Animation) then
		for v38, v39 in pairs(p37.CharacterAnimator.Animations) do
			if not v39.IsPlaying or v39.Name == "Idle" then
				continue
			end
			p37.CharacterAnimator:stop(v38)
		end
		for v40, v41 in pairs(p37.Viewmodel.Animation.Animations) do
			if not v41.IsPlaying or v41.Name == "Idle" then
				continue
			end
			p37.Viewmodel.Animation:stop(v40)
		end
		p37.Viewmodel.Animation:stopSounds()
	end
end
function v_u_1.reload(_) -- name: reload end
function v_u_1.shoot(p_u_42) -- name: shoot
	-- upvalues: (copy) v_u_28, (copy) v_u_36, (copy) v_u_11, (copy) v_u_13, (copy) v_u_14
	if p_u_42.IsPlanting then
		return
	else
		local v43 = tick()
		if v43 - p_u_42.PlantStartedTick < 0.5 then
			return
		else
			p_u_42.Janitor:Remove("BombAnimationEnded")
			if v_u_28() then
				p_u_42.IsInspecting = false
				p_u_42.IsPlanting = true
				p_u_42.PlantStartedTick = v43
				p_u_42:stopAllAnimations()
				v_u_11("Use")
				local v44 = p_u_42.Viewmodel.Animation:play("Use")
				p_u_42.CharacterAnimator:play("Use")
				v_u_13.C4.Start.Send(p_u_42.Identifier)
				v_u_14.broadcastRouter("Plant Bomb")
				p_u_42.Janitor:Add(v44.Ended:Connect(function()
					-- upvalues: (copy) p_u_42, (ref) v_u_28, (ref) v_u_13, (ref) v_u_14
					if p_u_42.IsPlanting then
						if v_u_28() then
							v_u_13.C4.Planted.Send(p_u_42.Identifier)
							p_u_42.IsPlanting = false
						end
						v_u_14.broadcastRouter("Cancel Bomb Plant")
					end
				end), "Disconnect", "BombAnimationEnded")
			else
				v_u_36()
			end
		end
	end
end
function v_u_1.cancel(p45, p46) -- name: cancel
	-- upvalues: (copy) v_u_11, (copy) v_u_13, (copy) v_u_14, (copy) v_u_33
	if p45.IsPlanting then
		p45.Viewmodel.Model.Weapon.Interactive.SurfaceGui.TextLabel.Text = "*******"
		p45.IsPlanting = false
		p45:stopAllAnimations()
		v_u_11("Cancel Plant")
		v_u_13.C4.Cancel.Send(p45.Identifier)
		v_u_14.broadcastRouter("Cancel Bomb Plant")
		p45.Janitor:Remove("BombAnimationEnded")
		v_u_33(p46)
	end
end
function v_u_1.inspect(p_u_47) -- name: inspect
	-- upvalues: (copy) v_u_11
	if not (p_u_47.IsInspecting or p_u_47.IsPlanting) then
		p_u_47.IsInspecting = true
		p_u_47:stopAllAnimations()
		local v48 = p_u_47.Viewmodel.Animation:play("Inspect")
		v_u_11("Inspect")
		task.delay(v48.Length, function()
			-- upvalues: (copy) p_u_47
			p_u_47.IsInspecting = false
		end)
	end
end
function v_u_1.drop(p49) -- name: drop
	-- upvalues: (copy) v_u_7, (copy) v_u_9, (copy) v_u_13, (copy) v_u_10, (copy) v_u_8, (copy) v_u_15
	if workspace:GetAttribute("Gamemode") == "Deathmatch" or (v_u_7.GetState() == "Warmup" or (v_u_9() or (p49.IsPlanting or not p49.Properties.Droppable))) then
		return false
	end
	p49:unequip()
	v_u_13.Inventory.DropWeapon.Send({
		["CharacterVelocity"] = v_u_10(v_u_8.getLocalCharacter()),
		["Direction"] = v_u_15.CFrame.LookVector,
		["Identifier"] = p49.Identifier
	})
	return true
end
function v_u_1.equip(p50) -- name: equip
	-- upvalues: (ref) v_u_17
	p50.Viewmodel.Animation:stopAnimations()
	p50.CharacterAnimator:stopAnimations()
	p50.CharacterAnimator:play("Idle")
	p50.CharacterAnimator:play("Equip")
	p50.Viewmodel:equip(false)
	v_u_17 = p50
end
function v_u_1.unequip(p51) -- name: unequip
	-- upvalues: (ref) v_u_17
	if p51.IsPlanting then
		p51:cancel("Unequipped")
	end
	p51.CharacterAnimator:stopAnimations()
	p51.Viewmodel:unequip()
	if v_u_17 and v_u_17 == p51 then
		v_u_17 = nil
	end
end
function v_u_1.new(p52, p53, p54, p55, p56, p57, p58, p59, p60, p61, p62, p63, _) -- name: new
	-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_5, (copy) v_u_28
	local v64 = v_u_6.new(p52, p53, p54, p55, p56, p57, p58, p59, p60, p61, p62, p63)
	local v65 = v_u_1
	local v_u_66 = setmetatable(v64, v65)
	v_u_66.IsInspecting = false
	v_u_66.IsPlanting = false
	v_u_66.PlantStartedTick = 0
	v_u_66.Janitor:Add(v_u_5.BindToHeartbeat(("Components.C4.%*.PlantValidation"):format(p53), function(_)
		-- upvalues: (copy) v_u_66, (ref) v_u_28
		if v_u_66.IsPlanting and not v_u_28() then
			v_u_66:cancel("LeftPlantArea")
		end
	end))
	return v_u_66
end
function v_u_1.destroy(p67) -- name: destroy
	-- upvalues: (ref) v_u_17, (copy) v_u_6
	if not p67.IsDestroyed then
		p67.IsDestroyed = true
		if p67.IsPlanting then
			p67:cancel("Destroyed")
		end
		if v_u_17 and v_u_17 == p67 then
			v_u_17 = nil
		end
		if p67.Janitor then
			p67.Janitor:Destroy()
			p67.Janitor = nil
		end
		p67.PlantStartedTick = nil
		p67.IsInspecting = nil
		p67.IsPlanting = nil
		v_u_6.destroy(p67)
	end
end
v_u_13.C4.ForceCancel.Listen(function()
	-- upvalues: (ref) v_u_17
	if v_u_17 and v_u_17.IsPlanting then
		v_u_17:cancel("Server")
	end
end)
return v_u_1
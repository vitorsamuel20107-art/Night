-- NIGHT Analyzer | ReplicatedStorage.Components.Melee
-- ModuleScript | 428 linhas | 13534 bytes | hash dfae207a

local v_u_1 = {}
v_u_1.__index = v_u_1
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("HttpService")
local v4 = game:GetService("Players")
require(v_u_2.Database.Custom.Types)
local v_u_5 = require(v_u_2.Controllers.HapticsController)
local v_u_6 = require(v_u_2.Controllers.SoundController)
local v_u_7 = require(v_u_2.Controllers.InputController)
local v_u_8 = require(v_u_2.Components.Common.GetRayIgnore)
local v_u_9 = require(v_u_2.Components.Common.CharacterResolver)
local v_u_10 = require(v_u_2.Components.Common.SurvivalDowned)
local v_u_11 = require(v_u_2.Components.Common.HordeProtocol)
local v_u_12 = require(v_u_2.Components.Common.GetCharacterVelocity)
local v_u_13 = require(v_u_2.Components.Common.ReplicateCharacterAction)
local v_u_14 = require(v_u_2.Components.Common.WeaponTimings)
local v_u_15 = require(v_u_2.Database.Components.GameState)
local v_u_16 = require(v_u_2.Components.Common.VFXLibary.CreateBloodSplatter)
local v_u_17 = require(v_u_2.Components.Common.VFXLibary.CreateMarker)
local v_u_18 = require(v_u_2.Components.Common.VFXLibary.CreateImpact)
local v_u_19 = require(v_u_2.Components.Common.VFXLibary.BreakGlass)
local v_u_20 = require(v_u_2.Classes.WeaponComponent)
local v_u_21 = require(v_u_2.Database.Security.Remotes)
local v_u_22 = require(v_u_2.Database.Security.Router)
local v_u_23 = v4.LocalPlayer
local v_u_24 = workspace.CurrentCamera
local function v_u_31(p25, p26) -- name: isBackStab
	-- upvalues: (copy) v_u_9
	local v27 = v_u_9.getRootPart(p25)
	local v28 = v_u_9.getRootPart(p26)
	if v27 and v28 then
		local v29 = v28.CFrame.LookVector:Dot((v27.Position - v28.Position).Unit)
		local v30 = math.acos(v29)
		return math.deg(v30) > 100
	end
end
local function v_u_37(p32) -- name: getBotVictimKey
	-- upvalues: (copy) v_u_2
	local v33 = p32:FindFirstAncestorOfClass("Model")
	while v33 ~= nil and v33:GetAttribute("Bot") ~= true do
		v33 = v33:FindFirstAncestorOfClass("Model")
	end
	local v34 = v_u_2:FindFirstChild("Combatants")
	local v35
	if v33 == nil or v34 == nil then
		v35 = nil
	else
		v35 = v34:FindFirstChild((tostring(v33:GetAttribute("CombatantId"))))
	end
	local v36
	if v35 == nil then
		v36 = nil
	else
		v36 = v35:GetAttribute("UserId")
	end
	if typeof(v36) == "number" then
		return v36
	else
		return nil
	end
end
local function v_u_46(p38) -- name: getHordeServerPart
	-- upvalues: (copy) v_u_11
	local v39 = p38:FindFirstAncestorOfClass("Model")
	local v40
	if v39 then
		v40 = v39:GetAttribute(v_u_11.ID_ATTRIBUTE)
	else
		v40 = nil
	end
	if typeof(v40) == "number" then
		local v41 = workspace:FindFirstChild(v_u_11.HITBOX_FOLDER)
		local v42
		if v41 then
			v42 = v41:FindFirstChild(v_u_11.modelName(v40))
		else
			v42 = nil
		end
		if v42 then
			local v43 = v39:FindFirstChild("Head")
			local v44
			if p38.Name == "Head" or p38.Name == "Helmet" then
				v44 = true
			elseif v43 == nil then
				v44 = false
			else
				v44 = p38:IsDescendantOf(v43)
			end
			local v45 = v42:FindFirstChild(v44 and "Head" or "Torso")
			if v45 and v45:IsA("BasePart") then
				return v45
			else
				return nil
			end
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_1.stopAllAnimations(p47) -- name: stopAllAnimations
	if p47.CharacterAnimator and (p47.Viewmodel and p47.Viewmodel.Animation) then
		p47.Viewmodel.Animation:cancelCrossfade()
		for v48, v49 in pairs(p47.CharacterAnimator.Animations) do
			if not v49.IsPlaying or v49.Name == "Idle" then
				continue
			end
			p47.CharacterAnimator:stop(v48)
		end
		for v50, v51 in pairs(p47.Viewmodel.Animation.Animations) do
			if not v51.IsPlaying or v51.Name == "Idle" then
				continue
			end
			p47.Viewmodel.Animation:stop(v50)
		end
	end
end
function v_u_1.reload(p52) -- name: reload
	if p52.IsInspecting or p52.IsInspectFadingOut then
		p52:cancelInspect(0.25)
	end
end
function v_u_1.shoot(p_u_53, p54) -- name: shoot
	-- upvalues: (copy) v_u_9, (copy) v_u_14, (copy) v_u_10, (copy) v_u_22, (copy) v_u_6, (copy) v_u_8, (copy) v_u_24, (copy) v_u_46, (copy) v_u_37, (copy) v_u_18, (copy) v_u_16, (copy) v_u_31, (copy) v_u_19, (copy) v_u_17, (copy) v_u_21, (copy) v_u_13, (copy) v_u_5, (copy) v_u_3, (copy) v_u_23, (copy) v_u_7
	local v55 = v_u_9.getPlayerCharacter(p_u_53.Player)
	if tick() - p_u_53.WeaponEquippedTick <= v_u_14.MELEE_EQUIP_LOCKOUT or (not v55 or (not v_u_9.isAliveCharacter(v55) or v_u_10.AreHandsBusy(p_u_53.Player))) then
		return
	elseif p_u_53.Properties.FireRate and not p_u_53.IsShooting then
		if p_u_53.IsInspecting or p_u_53.IsInspectFadingOut then
			p_u_53:cancelInspect(0.25)
		end
		p_u_53:stopAllAnimations()
		p_u_53.IsInspecting = false
		p_u_53.IsInspectFadingOut = false
		p_u_53.IsShooting = true
		v_u_22.broadcastRouter("Cancel Sprint")
		v_u_22.broadcastRouter("UpdatePlayerNoiseCone", "Melee", v55.PrimaryPart.Position, v_u_6.GetMeleeRange(p_u_53.Name), nil)
		local v56 = RaycastParams.new()
		v56.FilterType = Enum.RaycastFilterType.Exclude
		v56.FilterDescendantsInstances = v_u_8()
		v56.IgnoreWater = true
		local v57 = v_u_24.CFrame.LookVector * p_u_53.Properties.Range
		local v58 = v_u_24.CFrame.Position
		local v59 = workspace:Raycast(v58, v57, v56) or workspace:Spherecast(v58, 1.5, v57, v56)
		local v60 = p54 and "Heavy Swing" or ("Swing%*"):format((math.random(1, 2)))
		if v59 then
			local v61 = v59.Instance
			local v62 = v_u_46(v61)
			local v63 = v62 ~= nil
			local v64 = v62 or v61
			local v65 = v_u_9.getPlayerFromInstance(v64)
			local v66
			if v65 == nil then
				v66 = v_u_37(v64)
			else
				v66 = nil
			end
			local v67 = v59.Position
			local v68 = v59.Material
			local v69 = v59.Normal
			if v63 then
				v_u_18(v61, "Blood Splatter", v67, v69, false, true, true)
				v_u_16(v67, v_u_24.CFrame.LookVector)
				local v70 = v61:FindFirstAncestorOfClass("Model")
				v60 = p54 and (v70 and v_u_31(v55, v70)) and "BackStab" or v60
			else
				local v71 = v_u_9.isPlayerCharacter
				local v72
				if v64 then
					v72 = v64:FindFirstAncestorOfClass("Model") or nil
				else
					v72 = nil
				end
				if v71(v72) then
					local v73 = v_u_9.getImpactMaterial(v64, "Blood Splatter")
					v_u_18(v64, v73, v67, v69, false, true, true)
					if v73 == "Blood Splatter" then
						v_u_16(v67, v_u_24.CFrame.LookVector)
					end
					v60 = p54 and v_u_31(v_u_9.getLocalCharacter(), (v64:FindFirstAncestorOfClass("Model"))) and "BackStab" or v60
				else
					local v74 = v64.Parent
					v_u_18(v64, v68.Name, v67, v69, false, true, true)
					if v74 and v74:HasTag("BreakableGlass") then
						v_u_19(v64, v67, v57.Unit)
					elseif not v64:HasTag("BreakableGlass") then
						v_u_17(v64, "Melee", v67, v69)
					end
				end
			end
			local v75 = v_u_21.Melee.MeleeAttack.Send
			local v76 = {
				["Direction"] = v_u_24.CFrame.LookVector * p_u_53.Properties.Range,
				["Material"] = v59.Material.Name,
				["Distance"] = v59.Distance
			}
			local v77
			if v65 == nil and v66 == nil then
				v77 = v64
			else
				v77 = nil
			end
			v76.Instance = v77
			local v78
			if v65 == nil then
				v78 = v66
			else
				v78 = v65.UserId
			end
			v76.VictimUserId = v78
			local v79
			if v65 == nil and v66 == nil then
				v79 = nil
			else
				v79 = v64.Name
			end
			v76.HitPartName = v79
			v76.Position = v59.Position
			v76.Normal = v59.Normal
			v76.MeleeAttack = v60
			v76.Identifier = p_u_53.Identifier
			v75(v76)
		end
		v_u_13(v60)
		p_u_53.Viewmodel.Animation:play(v60)
		local v80 = (v60 == "Swing1" or v60 == "Swing") and "Swing" or v60
		v_u_5.vibrate(Enum.VibrationMotor.Small, 1.15, 0.2)
		p_u_53.CharacterAnimator:play(v80)
		task.delay(p_u_53.Properties.FireRate * (p54 and 2.05 or 1), function()
			-- upvalues: (copy) p_u_53, (ref) v_u_3, (ref) v_u_23, (ref) v_u_7
			if not p_u_53.IsDestroyed then
				p_u_53.IsShooting = false
				if p_u_53.Identifier ~= v_u_3:JSONDecode(v_u_23:GetAttribute("CurrentEquipped") or "[]").Identifier then
					return
				end
				local v81 = v_u_7.isActionPressed("Fire", { Enum.UserInputType.MouseButton1, Enum.KeyCode.ButtonR2 }) or p_u_53.IsFireHeld
				local v82 = v_u_7.isActionPressed("Secondary Fire", { Enum.UserInputType.MouseButton2, Enum.KeyCode.ButtonL2 })
				if v81 or v82 then
					p_u_53:shoot(v82)
				end
			end
		end)
	end
end
function v_u_1.releaseFireInput(p83) -- name: releaseFireInput
	p83.IsFireHeld = false
end
function v_u_1.cancelInspect(p_u_84, p85, p86) -- name: cancelInspect
	if p_u_84.IsInspecting or p_u_84.IsInspectFadingOut then
		local v87 = p_u_84.InspectDelayThread
		if v87 then
			task.cancel(v87)
			p_u_84.InspectDelayThread = nil
		end
		local v88 = p86 or 0.3
		local v_u_89 = p85 or 1.2
		p_u_84.IsInspectFadingOut = true
		p_u_84.IsInspecting = false
		p_u_84.Viewmodel.Animation:markInspectCancel()
		local v90 = p_u_84.CancelDelayThread
		if v90 then
			task.cancel(v90)
			p_u_84.CancelDelayThread = nil
		end
		local v91 = p_u_84.FadeCompleteThread
		if v91 then
			task.cancel(v91)
			p_u_84.FadeCompleteThread = nil
		end
		p_u_84.CancelDelayThread = task.delay(v88, function()
			-- upvalues: (copy) p_u_84, (copy) v_u_89
			if p_u_84.IsDestroyed then
				return
			elseif p_u_84.IsInspectFadingOut then
				p_u_84.Viewmodel.Animation:crossfadeTo("Idle", v_u_89)
				p_u_84.FadeCompleteThread = task.delay(v_u_89, function()
					-- upvalues: (ref) p_u_84
					if not p_u_84.IsDestroyed then
						p_u_84.FadeCompleteThread = nil
						p_u_84.IsInspectFadingOut = false
					end
				end)
			end
		end)
	end
end
function v_u_1.inspect(p_u_92) -- name: inspect
	-- upvalues: (copy) v_u_13
	if p_u_92.IsShooting then
		return
	elseif p_u_92.IsInspecting and not p_u_92.IsInspectFadingOut then
		return
	else
		local v93 = p_u_92.IsInspectFadingOut == true
		if v93 then
			p_u_92.IsInspectFadingOut = false
			local v94 = p_u_92.CancelDelayThread
			if v94 then
				task.cancel(v94)
				p_u_92.CancelDelayThread = nil
			end
			local v95 = p_u_92.FadeCompleteThread
			if v95 then
				task.cancel(v95)
				p_u_92.FadeCompleteThread = nil
			end
			p_u_92.Viewmodel.Animation:cancelCrossfade()
		end
		p_u_92.IsInspecting = true
		p_u_92.IsShooting = false
		local v96 = p_u_92.InspectDelayThread
		if v96 then
			task.cancel(v96)
			p_u_92.InspectDelayThread = nil
		end
		local v97 = p_u_92.Viewmodel.Animation:pickInspectVariant()
		if v93 then
			if not p_u_92.Viewmodel.Animation:crossfadeRestart(v97, 0.25) then
				p_u_92:stopAllAnimations()
				p_u_92.Viewmodel.Animation:play(v97)
			end
			v_u_13("Inspect")
			local v98 = p_u_92.Viewmodel.Animation:getAnimation(v97)
			if v98 then
				local v99 = v98.Length
				p_u_92.InspectDelayThread = task.delay(v99, function()
					-- upvalues: (copy) p_u_92
					if not p_u_92.IsDestroyed then
						p_u_92.InspectDelayThread = nil
						p_u_92.IsInspecting = false
					end
				end)
			end
		else
			p_u_92:stopAllAnimations()
			local v100 = p_u_92.Viewmodel.Animation:play(v97)
			v_u_13("Inspect")
			local v101 = v100.Length
			p_u_92.InspectDelayThread = task.delay(v101, function()
				-- upvalues: (copy) p_u_92
				if not p_u_92.IsDestroyed then
					p_u_92.InspectDelayThread = nil
					p_u_92.IsInspecting = false
				end
			end)
		end
	end
end
function v_u_1.drop(p102) -- name: drop
	-- upvalues: (copy) v_u_15, (copy) v_u_21, (copy) v_u_12, (copy) v_u_9, (copy) v_u_24
	if workspace:GetAttribute("Gamemode") == "Deathmatch" or (v_u_15.GetState() == "Warmup" or workspace:GetAttribute("VIPKnifeDropEnabled") ~= true) then
		return false
	end
	p102:unequip()
	v_u_21.Inventory.DropWeapon.Send({
		["CharacterVelocity"] = v_u_12(v_u_9.getLocalCharacter()),
		["Direction"] = v_u_24.CFrame.LookVector,
		["Identifier"] = p102.Identifier
	})
	return true
end
function v_u_1.equip(p103) -- name: equip
	p103.Viewmodel.Animation:stopAnimations()
	p103.CharacterAnimator:stopAnimations()
	p103.CharacterAnimator:play("Idle")
	p103.CharacterAnimator:play("Equip")
	p103.WeaponEquippedTick = tick()
	p103.Viewmodel:equip(false)
	p103.IsInspectFadingOut = false
	p103.IsInspecting = false
	p103.IsShooting = false
	p103.IsFireHeld = false
end
function v_u_1.unequip(p104) -- name: unequip
	p104.CharacterAnimator:stopAnimations()
	p104.Viewmodel:unequip()
	p104.IsInspectFadingOut = false
	p104.IsInspecting = false
	p104.IsShooting = false
	p104.IsFireHeld = false
end
function v_u_1.new(p105, p106, p107, p108, p109, p110, p111, p112, p113, p114, p115, p116, _) -- name: new
	-- upvalues: (copy) v_u_20, (copy) v_u_1
	local v117 = v_u_20.new(p105, p106, p107, p108, p109, p110, p111, p112, p113, p114, p115, p116)
	local v118 = v_u_1
	local v119 = setmetatable(v117, v118)
	v119.IsInspectFadingOut = false
	v119.IsInspecting = false
	v119.IsShooting = false
	v119.IsFireHeld = false
	v119.AlternativeSwitchTick = 0
	v119.WeaponEquippedTick = 0
	return v119
end
function v_u_1.destroy(p120) -- name: destroy
	-- upvalues: (copy) v_u_20
	if not p120.IsDestroyed then
		p120.IsDestroyed = true
		local v121 = p120.InspectDelayThread
		if v121 then
			task.cancel(v121)
			p120.InspectDelayThread = nil
		end
		local v122 = p120.CancelDelayThread
		if v122 then
			task.cancel(v122)
			p120.CancelDelayThread = nil
		end
		local v123 = p120.FadeCompleteThread
		if v123 then
			task.cancel(v123)
			p120.FadeCompleteThread = nil
		end
		if p120.Janitor then
			p120.Janitor:Destroy()
			p120.Janitor = nil
		end
		p120.IsInspectFadingOut = nil
		p120.IsInspecting = nil
		p120.IsShooting = nil
		p120.IsFireHeld = nil
		p120.AlternativeSwitchTick = nil
		p120.WeaponEquippedTick = nil
		v_u_20.destroy(p120)
	end
end
return v_u_1
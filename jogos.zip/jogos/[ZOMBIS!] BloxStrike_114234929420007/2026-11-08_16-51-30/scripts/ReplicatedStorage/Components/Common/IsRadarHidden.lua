-- NIGHT Analyzer | ReplicatedStorage.Components.Common.IsRadarHidden
-- ModuleScript | 7 linhas | 255 bytes | hash af38a2ef

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Components.Common.IsSurvivalMode)
local v_u_3 = require(v1.Components.Common.IsTutorialMode)
return function()
	-- upvalues: (copy) v_u_3, (copy) v_u_2
	return v_u_3() or v_u_2()
end
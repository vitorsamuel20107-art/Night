-- NIGHT Analyzer | ReplicatedStorage.Components.Common.GeneratorProtocol
-- ModuleScript | 30 linhas | 851 bytes | hash d231b584

local v_u_6 = {
	["ASSET_NAME"] = "Generator",
	["SPAWNS_FOLDER"] = "GeneratorSpawns",
	["INTERACTABLE_FOLDER"] = "Interactable",
	["GENERATORS_FOLDER"] = "Generators",
	["KEY_ATTRIBUTE"] = "Generator",
	["HEALTH_ATTRIBUTE"] = "Health",
	["MAX_HEALTH_ATTRIBUTE"] = "MaxHealth",
	["DESTROYED_ATTRIBUTE"] = "Destroyed",
	["TAG"] = "SurvivalGenerator",
	["TIER_TEXTURES"] = table.freeze({
		"rbxassetid://82417477410867",
		"rbxassetid://84731451880094",
		"rbxassetid://82524592324406",
		"rbxassetid://136240493163749"
	}),
	["TIER_THRESHOLDS"] = table.freeze({ 0.75, 0.5, 0.25 }),
	["TierFor"] = function(p1, p2) -- name: TierFor
		-- upvalues: (copy) v_u_6
		local v3 = p2 <= 0 and 0 or p1 / p2
		for v4, v5 in v_u_6.TIER_THRESHOLDS do
			if v5 >= v3 then
				continue
			end
			return v4
		end
		return #v_u_6.TIER_THRESHOLDS + 1
	end
}
return v_u_6
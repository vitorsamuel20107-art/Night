-- NIGHT Analyzer | ReplicatedStorage.Components.Common.EndScreenTiming
-- ModuleScript | 3 linhas | 43 bytes | hash 00782ba6

return table.freeze({
	["DURATION"] = 14
})
-- NIGHT Analyzer | ReplicatedStorage.Components.Common.VFXLibary.CreateMuzzleFlash.EmitParticles
-- ModuleScript | 45 linhas | 974 bytes | hash 2ea161ae

local v_u_1 = {}
local function v_u_7(p_u_2) -- name: getEmitterConfigs
	-- upvalues: (copy) v_u_1
	local v3 = v_u_1[p_u_2]
	if v3 then
		return v3
	end
	local v4 = {}
	for _, v5 in ipairs(p_u_2:GetDescendants()) do
		if not v5:IsA("ParticleEmitter") then
			continue
		end
		local v6 = {
			["Emitter"] = v5,
			["Delay"] = v5:GetAttribute("EmitDelay") or 0,
			["Count"] = v5:GetAttribute("EmitCount") or 1
		}
		table.insert(v4, v6)
	end
	v_u_1[p_u_2] = v4
	p_u_2.Destroying:Once(function()
		-- upvalues: (ref) v_u_1, (copy) p_u_2
		v_u_1[p_u_2] = nil
	end)
	return v4
end
return function(p8)
	-- upvalues: (copy) v_u_7
	for _, v_u_9 in ipairs((v_u_7(p8))) do
		local v_u_10 = v_u_9.Emitter
		if v_u_9.Delay > 0 then
			task.delay(v_u_9.Delay, function()
				-- upvalues: (copy) v_u_10, (copy) v_u_9
				if v_u_10.Parent then
					v_u_10:Emit(v_u_9.Count)
				end
			end)
		else
			if not v_u_10.Parent then
				continue
			end
			v_u_10:Emit(v_u_9.Count)
		end
	end
end
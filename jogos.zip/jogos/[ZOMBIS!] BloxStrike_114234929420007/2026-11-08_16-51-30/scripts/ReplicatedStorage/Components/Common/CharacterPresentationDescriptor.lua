-- NIGHT Analyzer | ReplicatedStorage.Components.Common.CharacterPresentationDescriptor
-- ModuleScript | 16 linhas | 589 bytes | hash 61260b35

local v1 = {
	["Attributes"] = table.freeze({
		["CharacterName"] = "PresentationCharacterName",
		["Generation"] = "PresentationGeneration",
		["SpawnPosition"] = "PresentationSpawnPosition",
		["SpawnYaw"] = "PresentationSpawnYaw",
		["BodyColor"] = "PresentationBodyColor",
		["EquippedGloves"] = "PresentationEquippedGloves",
		["Health"] = "Health",
		["MaxHealth"] = "MaxHealth"
	}),
	["OwnedAttribute"] = "ClientOwnedCharacterPresentation",
	["OwnerUserIdAttribute"] = "PresentationOwnerUserId",
	["VisibleAttribute"] = "ClientCharacterPresentationVisible"
}
return table.freeze(v1)
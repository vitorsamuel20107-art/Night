-- NIGHT Analyzer | ReplicatedStorage.Components.Common.HordeProtocol
-- ModuleScript | 88 linhas | 2669 bytes | hash 7f04c493

local v1 = require(game:GetService("ReplicatedStorage").MovementV2.Simulation.Config)
local v2 = {
	["STREAM_REMOTE"] = "HordeStream",
	["HITBOX_FOLDER"] = "Horde",
	["SPAWNS_FOLDER"] = "ZombieSpawns",
	["SHELL_FOLDER"] = "HordeShells",
	["ID_ATTRIBUTE"] = "HordeId",
	["ZOMBIE_CHARACTER_FOLDER"] = "Zombies",
	["ARCHETYPE_NORMAL"] = 1,
	["ARCHETYPE_HEAVY"] = 2,
	["ARCHETYPE_FLAMING"] = 3,
	["ARCHETYPE_FLAMING_HEAVY"] = 4
}
v2.ARCHETYPE_FOLDERS = table.freeze({
	[v2.ARCHETYPE_NORMAL] = "Normal",
	[v2.ARCHETYPE_HEAVY] = "Heavy",
	[v2.ARCHETYPE_FLAMING] = "Flaming",
	[v2.ARCHETYPE_FLAMING_HEAVY] = "Heavy"
})
v2.ARCHETYPE_BURSTS = table.freeze({
	[v2.ARCHETYPE_FLAMING] = true,
	[v2.ARCHETYPE_FLAMING_HEAVY] = true
})
v2.POSITION_SCALE = 20
v2.HEADER_BYTES = 10
v2.BYTES_PER_ZOMBIE = 10
v2.HEALTH_STEPS = 31
v2.STATE_IDLE = 0
v2.STATE_WALK = 1
v2.STATE_RUN = 2
v2.STATE_ATTACK = 3
v2.STATE_DEAD = 4
v2.STATE_STUNNED = 5
v2.STATE_AIRBORNE = 6
v2.LINK_GRAVITY = v1.Default.Gravity
local v_u_3 = v2.POSITION_SCALE
function v2.modelName(p4) -- name: modelName
	return ("Zombie%*"):format(p4)
end
function v2.writeHeader(p5, p6, p7) -- name: writeHeader
	buffer.writeu16(p5, 0, p6)
	buffer.writef64(p5, 2, p7)
end
function v2.readHeader(p8) -- name: readHeader
	return buffer.readu16(p8, 0), buffer.readf64(p8, 2)
end
function v2.writeRecord(p9, p10, p11, p12, p13, p14, p15, p16, p17) -- name: writeRecord
	-- upvalues: (copy) v_u_3
	buffer.writeu16(p9, p10, p11)
	local v18 = p10 + 2
	local v19 = p12 * v_u_3
	local v20 = math.round(v19)
	local v21 = math.clamp(v20, -32768, 32767)
	buffer.writei16(p9, v18, v21)
	local v22 = p10 + 4
	local v23 = p13 * v_u_3
	local v24 = math.round(v23)
	local v25 = math.clamp(v24, -32768, 32767)
	buffer.writei16(p9, v22, v25)
	local v26 = p10 + 6
	local v27 = p14 * v_u_3
	local v28 = math.round(v27)
	local v29 = math.clamp(v28, -32768, 32767)
	buffer.writei16(p9, v26, v29)
	local v30 = p10 + 8
	local v31 = p15 % 6.283185307179586 / 6.283185307179586 * 255 + 0.5
	local v32 = math.floor(v31)
	buffer.writeu8(p9, v30, v32)
	local v33 = p10 + 9
	local v34 = p16 + p17 * 8
	buffer.writeu8(p9, v33, v34)
end
function v2.readRecord(p35, p36) -- name: readRecord
	-- upvalues: (copy) v_u_3
	local v37 = buffer.readu16(p35, p36)
	local v38 = p36 + 2
	local v39 = buffer.readi16(p35, v38) / v_u_3
	local v40 = p36 + 4
	local v41 = buffer.readi16(p35, v40) / v_u_3
	local v42 = p36 + 6
	local v43 = buffer.readi16(p35, v42) / v_u_3
	local v44 = p36 + 8
	local v45 = buffer.readu8(p35, v44) / 255 * 6.283185307179586
	local v46 = p36 + 9
	local v47 = buffer.readu8(p35, v46)
	return v37, v39, v41, v43, v45, v47 % 8, v47 // 8
end
return v2
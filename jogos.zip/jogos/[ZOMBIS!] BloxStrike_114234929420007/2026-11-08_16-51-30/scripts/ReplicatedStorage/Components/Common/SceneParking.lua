-- NIGHT Analyzer | ReplicatedStorage.Components.Common.SceneParking
-- ModuleScript | 28 linhas | 664 bytes | hash 38c31cf9

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Workspace")
local v3 = {}
local v_u_4 = nil
function v3.Park(p_u_5) -- name: Park
	-- upvalues: (ref) v_u_4, (copy) v_u_1
	local function v8()
		-- upvalues: (copy) p_u_5, (ref) v_u_4, (ref) v_u_1
		local v6 = p_u_5
		local v7 = v_u_4
		if not v7 or v7.Parent ~= v_u_1 then
			v7 = Instance.new("Folder")
			v7.Name = "ParkedScenes"
			v7.Archivable = false
			v7.Parent = v_u_1
			v_u_4 = v7
		end
		v6.Parent = v7
	end
	pcall(v8)
end
function v3.Unpark(p9) -- name: Unpark
	-- upvalues: (copy) v_u_2
	if p9.Parent ~= v_u_2 then
		p9.Parent = v_u_2
	end
end
return table.freeze(v3)
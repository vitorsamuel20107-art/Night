-- NIGHT Analyzer | ReplicatedStorage.Components.Common.PredictSearch
-- ModuleScript | 67 linhas | 1245 bytes | hash 0955cdd3

local function v_u_17(p1, p2, p3) -- name: distanceWithin
	local v4 = #p1 - #p2
	if p3 < math.abs(v4) then
		return p3 + 1
	end
	local v5 = {}
	local v6 = {}
	for v7 = 0, #p2 do
		v5[v7] = v7
	end
	for v8 = 1, #p1 do
		v6[0] = v8
		local v9 = v8
		for v10 = 1, #p2 do
			local v11 = string.byte(p1, v8) == string.byte(p2, v10) and 0 or 1
			local v12 = v5[v10] + 1
			local v13 = v6[v10 - 1] + 1
			local v14 = v5[v10 - 1] + v11
			v6[v10] = math.min(v12, v13, v14)
			local v15 = v6[v10]
			v9 = math.min(v9, v15)
		end
		if p3 < v9 then
			return p3 + 1
		end
		local v16 = v5
		v5 = v6
		v6 = v16
	end
	return v5[#p2]
end
return function(p18, p19, p20)
	-- upvalues: (copy) v_u_17
	if p19 == "" then
		return nil
	end
	local v21 = (1 / 0)
	local v22 = (1 / 0)
	local v23 = nil
	for _, v24 in p18 do
		local v25 = (1 / 0)
		local v26 = (1 / 0)
		local v27 = string.find(v24, p19, 1, true)
		if v27 == 1 then
			v27 = #v24
			v25 = 1
		elseif v27 then
			v25 = 2
		elseif v21 >= 3 and p20 <= #p19 then
			v27 = v_u_17(p19, v24, 3)
			if v27 <= 3 then
				v25 = 3
			else
				v27 = v26
			end
		else
			v27 = v26
		end
		if v25 >= v21 and (v25 ~= v21 or v27 >= v22) then
			continue
		end
		v23 = v24
		v22 = v27
		v21 = v25
	end
	return v23
end
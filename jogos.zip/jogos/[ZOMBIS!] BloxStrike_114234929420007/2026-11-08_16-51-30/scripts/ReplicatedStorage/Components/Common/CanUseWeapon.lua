-- NIGHT Analyzer | ReplicatedStorage.Components.Common.CanUseWeapon
-- ModuleScript | 12 linhas | 399 bytes | hash a4948ba5

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Components.Common.SurvivalDowned)
return function(p3, p4)
	-- upvalues: (copy) v_u_2
	local v5
	if p3 == nil or (p3:GetAttribute("IsPlantingBomb") == true or (p3:GetAttribute("IsDefusingBomb") == true or p3:GetAttribute("IsRescuingHostage") == true)) then
		v5 = false
	else
		v5 = v_u_2.CanUseSlot(p3, p4)
	end
	return v5
end
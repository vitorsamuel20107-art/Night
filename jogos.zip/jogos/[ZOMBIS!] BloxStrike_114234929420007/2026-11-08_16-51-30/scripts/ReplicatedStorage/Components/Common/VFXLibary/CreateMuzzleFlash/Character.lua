-- NIGHT Analyzer | ReplicatedStorage.Components.Common.VFXLibary.CreateMuzzleFlash.Character
-- ModuleScript | 163 linhas | 4786 bytes | hash f5d4d515

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Players")
local v_u_3 = require(v1.Shared.DebugFlags)
local v_u_4 = require(v1.Components.Common.GetWeaponProperties)
local v_u_5 = require(v1.Components.Common.VFXLibary.CreateZeusBeam)
local v_u_6 = require(v1.Components.Common.CharacterGeneration)
local v_u_7 = require(v1.Components.Common.ClientCharacterPresentation)
local v_u_8 = require(v1.Components.Common.IsTutorialMode)
local v_u_9 = require(script.Parent.EmitParticles)
local function v_u_13(p10, p11) -- name: executeMuzzleFlash
	-- upvalues: (copy) v_u_9
	debug.profilebegin("VFX.MuzzleFlash.Character.Execute")
	local v12 = p10:FindFirstChild(p11)
	if not v12 then
		debug.profileend()
		return nil
	end
	debug.profilebegin("VFX.MuzzleFlash.Character.EmitParticles")
	v_u_9(v12)
	debug.profileend()
	debug.profileend()
	return p10.Position
end
local function v_u_15(p14, ...) -- name: dlog
	-- upvalues: (copy) v_u_3
	if v_u_3.IsEnabled("WeaponFX") then
		warn(("[WeaponFX][MuzzleFlash.Character] " .. p14):format(...))
	end
end
local function v_u_20(p16) -- name: findTutorialDummy
	-- upvalues: (copy) v_u_8
	if not v_u_8() then
		return nil
	end
	for _, v17 in workspace:GetChildren() do
		if not v17:IsA("Folder") then
			continue
		end
		local v18 = v17.Name
		if string.sub(v18, 1, 8) ~= "Tutorial" then
			continue
		end
		for _, v19 in v17:GetChildren() do
			if not v19:IsA("Model") or (v19:GetAttribute("TutorialDummy") ~= true or v19:GetAttribute("DummyUserId") ~= p16) then
				continue
			end
			return v19
		end
	end
	return nil
end
local function v_u_25(p21, p22) -- name: findDummyWeaponModel
	local v23 = p21:FindFirstChild(p22)
	if v23 and v23:IsA("Model") then
		return v23
	end
	for _, v24 in p21:GetChildren() do
		if not (v24:IsA("Model") and v24:FindFirstChild("Interactables")) then
			continue
		end
		return v24
	end
	return nil
end
return function(p26, p27, p28, p29, p30, p31) -- name: tryCreate
	-- upvalues: (copy) v_u_2, (copy) v_u_20, (copy) v_u_15, (copy) v_u_4, (copy) v_u_7, (copy) v_u_6, (copy) v_u_25, (copy) v_u_5, (copy) v_u_13
	debug.profilebegin("VFX.MuzzleFlash.Character.TryCreate")
	local v32 = v_u_2:GetPlayerByUserId(p26)
	local v33
	if v32 then
		v33 = nil
	else
		v33 = v_u_20(p26)
	end
	if v32 or v33 then
		local v34
		if v32 then
			v34 = v32.Name
		else
			v34 = v33.Name
		end
		debug.profilebegin("VFX.MuzzleFlash.Character.TryCreate.GetWeaponProperties")
		local v35 = v_u_4(p28)
		debug.profileend()
		if v35 then
			debug.profilebegin("VFX.MuzzleFlash.Character.TryCreate.FindWeaponModel")
			local v36
			if v32 then
				local v37 = v_u_7.Create(v32, p27)
				if not (v37 and v_u_6.Matches(v37, p27)) then
					v_u_15("presentation missing player=%s generation=%s weapon=%s", v34, tostring(p27), (tostring(p28)))
					debug.profileend()
					debug.profileend()
					return
				end
				v36 = v37:FindFirstChild("WeaponModel")
				if v36 then
					v36 = v36:FindFirstChild("Equipped")
				end
				if not (v36 and v36:IsA("Model")) then
					v36 = nil
				end
			else
				v36 = v_u_25(v33, p28)
			end
			debug.profileend()
			if v36 then
				debug.profilebegin("VFX.MuzzleFlash.Character.TryCreate.FindMuzzlePart")
				local v38 = v36:FindFirstChild("Interactables")
				if v38 then
					local v39 = v38:FindFirstChild("MuzzlePart")
					if v35.ShootingOptions == "Dual" then
						v39 = v38:FindFirstChild("MuzzlePart" .. (p29 == "Left" and "L" or "R"))
					end
					if v39 then
						debug.profileend()
						if v35.MuzzleType == "Zeus x27" then
							debug.profilebegin("VFX.MuzzleFlash.Character.CreateZeusBeam")
							v_u_5(v39)
							debug.profileend()
						end
						if p31 then
							debug.profileend()
							return
						else
							local v40 = p30 or v35.MuzzleType
							if v40 then
								if not v_u_13(v39, v40) then
									v_u_15("executeMuzzleFlash failed player=%s weapon=%s override=%s", v34, tostring(p28), (tostring(p30)))
								end
								debug.profileend()
							else
								debug.profileend()
							end
						end
					else
						v_u_15("missing muzzle part player=%s weapon=%s shootingHand=%s", v34, tostring(p28), (tostring(p29)))
						debug.profileend()
						debug.profileend()
						return
					end
				else
					v_u_15("missing Interactables player=%s weapon=%s", v34, (tostring(p28)))
					debug.profileend()
					debug.profileend()
					return
				end
			else
				v_u_15("missing equipped presentation player=%s weapon=%s", v34, (tostring(p28)))
				debug.profileend()
				return
			end
		else
			v_u_15("weapon properties missing player=%s weapon=%s", v34, (tostring(p28)))
			debug.profileend()
			return
		end
	else
		v_u_15("player not found userId=%s weapon=%s", tostring(p26), (tostring(p28)))
		debug.profileend()
		return
	end
end
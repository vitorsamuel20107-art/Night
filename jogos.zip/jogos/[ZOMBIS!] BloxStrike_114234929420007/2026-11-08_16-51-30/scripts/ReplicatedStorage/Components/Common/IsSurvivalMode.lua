-- NIGHT Analyzer | ReplicatedStorage.Components.Common.IsSurvivalMode
-- ModuleScript | 3 linhas | 85 bytes | hash 343e2321

return function()
	return workspace:GetAttribute("Gamemode") == "Zombie Survival"
end
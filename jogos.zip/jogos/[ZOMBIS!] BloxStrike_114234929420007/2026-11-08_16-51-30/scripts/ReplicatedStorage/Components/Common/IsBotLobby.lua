-- NIGHT Analyzer | ReplicatedStorage.Components.Common.IsBotLobby
-- ModuleScript | 3 linhas | 72 bytes | hash d6ee66f9

return function()
	return workspace:GetAttribute("BotLobby") == true
end
-- NIGHT Analyzer | ReplicatedStorage.Components.Common.SurvivalBuyRules
-- ModuleScript | 122 linhas | 3308 bytes | hash fcce61b5

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Components.Common.IsSurvivalMode)
local v_u_3 = require(v1.Database.Custom.GameStats.Gamemodes.Survival)
local v_u_4 = require(v1.Database.Custom.GameStats.Grenades)
local v_u_46 = {
	["BUY_STATION_RADIUS"] = 9,
	["BUY_STATIONS_FOLDER"] = "BuyStation",
	["BUY_STATION_TAG"] = "SurvivalBuyStation",
	["BUY_STATION_ARRIVED_ATTRIBUTE"] = "ArrivedAt",
	["BUY_STATION_DEPARTED_ATTRIBUTE"] = "DepartedAt",
	["BUY_STATION_ARRIVE_SECONDS"] = 1.6,
	["BUY_STATION_DEPART_SECONDS"] = 1.5,
	["IsSurvival"] = v_u_2,
	["GetArmorPool"] = function(p5) -- name: GetArmorPool
		-- upvalues: (copy) v_u_2
		return p5 == "Kevlar + Helmet" and v_u_2() and 150 or 100
	end,
	["GetFullReserve"] = function(p6) -- name: GetFullReserve
		-- upvalues: (copy) v_u_2
		local v7 = p6.Capacity
		local v8 = tonumber(v7) or 0
		if v_u_2() then
			return v8 * 2
		else
			return v8
		end
	end,
	["IsSurvivalOnlyEquipment"] = function(p9) -- name: IsSurvivalOnlyEquipment
		-- upvalues: (copy) v_u_3
		return v_u_3.SurvivalOnlyEquipment[p9] == true
	end,
	["IsSold"] = function(p10) -- name: IsSold
		-- upvalues: (copy) v_u_3, (copy) v_u_2
		local v11 = v_u_3.UnsoldItems[p10]
		if v11 then
			v11 = v_u_2()
		end
		return not v11
	end,
	["GetGrenadeLimit"] = function(p12) -- name: GetGrenadeLimit
		-- upvalues: (copy) v_u_4, (copy) v_u_2
		local v13 = v_u_4[p12]
		return v13 and v_u_2() and (1 / 0) or v13
	end,
	["GetPrice"] = function(p14, p15) -- name: GetPrice
		-- upvalues: (copy) v_u_2, (copy) v_u_3
		if v_u_2() then
			return v_u_3.Prices[p14] or p15
		else
			return p15
		end
	end,
	["GetMissingAmmo"] = function(p16) -- name: GetMissingAmmo
		-- upvalues: (copy) v_u_46
		local v17 = p16.Properties
		if v17 then
			local v18 = v17.Rounds
			if typeof(v18) == "number" then
				local v19 = v17.Capacity
				if typeof(v19) == "number" then
					local v20 = v_u_46.GetFullReserve(v17)
					local v21 = p16.Rounds
					local v22
					if typeof(v21) == "number" then
						v22 = p16.Rounds
					else
						v22 = v17.Rounds
					end
					local v23 = p16.Capacity
					local v24
					if typeof(v23) == "number" then
						v24 = p16.Capacity
					else
						v24 = v20
					end
					local v25 = v17.Rounds - v22
					local v26 = math.max(v25, 0)
					local v27 = v20 - v24
					return v26 + math.max(v27, 0)
				end
			end
		end
		return 0
	end,
	["GetAmmoPrice"] = function(p28) -- name: GetAmmoPrice
		-- upvalues: (copy) v_u_46
		local v29 = 0
		for _, v30 in pairs(p28) do
			local v31 = v30._items
			if not v31 then
				continue
			end
			for _, v32 in ipairs(v31) do
				local v33 = v_u_46.GetMissingAmmo(v32)
				if v33 <= 0 then
					continue
				end
				local v34 = v32.Properties
				local v35 = v34.Rounds + v_u_46.GetFullReserve(v34)
				local v36 = v34.Rounds + v34.Capacity
				if v35 <= 0 or v36 <= 0 then
					continue
				end
				local v37 = v_u_46.GetPrice
				local v38 = v32.Name
				local v39 = v34.Cost
				local v40 = v37(v38, tonumber(v39) or 0) * 0.15
				local v41 = math.max(v40, 50)
				local v42 = v33 / v36
				local v43 = v35 / v36
				v29 = v29 + v41 * math.min(v42, v43)
			end
		end
		if v29 <= 0 then
			return 0
		end
		local v44 = v29 / 10
		local v45 = math.ceil(v44) * 10
		return math.max(v45, 10)
	end
}
return v_u_46
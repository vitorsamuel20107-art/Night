-- NIGHT Analyzer | ReplicatedStorage.Components.Common.BotWeaponModel
-- ModuleScript | 231 linhas | 5827 bytes | hash 4da09c0b

local v_u_1 = game:GetService("HttpService")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(script.Parent.GetWeaponProperties)
local v_u_4 = require(v_u_2.Database.Custom.GameStats.Character.Attachments)
local v_u_5 = require(script.Parent.VFXLibary.CreateMuzzleFlash.GetMuzzleFlash)
local v_u_6 = require(script.Parent.ThirdPersonWeaponStash)
local v_u_7 = {}
local v_u_8 = table.freeze({
	["MuzzlePart"] = true,
	["MuzzlePartL"] = true,
	["MuzzlePartR"] = true,
	["RootPart"] = true,
	["Hitbox"] = true,
	["Insert"] = true,
	["move"] = true
})
local v_u_9 = {}
function v_u_7.destroy(p10) -- name: destroy
	if p10 ~= nil then
		for _, v11 in p10.Motors do
			v11:Destroy()
		end
		p10.Model:Destroy()
	end
end
function v_u_7.stow(p12, p13) -- name: stow
	-- upvalues: (copy) v_u_9, (copy) v_u_7, (copy) v_u_6
	if p13 ~= nil then
		local v14 = v_u_9[p12]
		if v14 == nil then
			v14 = {}
			v_u_9[p12] = v14
		end
		v_u_7.destroy(v14[p13.Name])
		v14[p13.Name] = p13
		v_u_6.Park(p13.Model, p13.Motors)
	end
end
function v_u_7.clear(p15) -- name: clear
	-- upvalues: (copy) v_u_9, (copy) v_u_7
	local v16 = v_u_9[p15]
	if v16 ~= nil then
		v_u_9[p15] = nil
		for _, v17 in v16 do
			v_u_7.destroy(v17)
		end
	end
end
local function v_u_29(p18, p19, p20, p21, p22) -- name: joinMotor
	-- upvalues: (copy) v_u_6
	local v23 = CFrame.identity
	local v24 = CFrame.identity
	local v25 = p18.Model:FindFirstChild("Properties")
	if v25 then
		local v26 = v25:FindFirstChild("C0" .. p21)
		local v27 = v25:FindFirstChild("C1" .. p21)
		if v26 and v26:IsA("CFrameValue") then
			v23 = v26.Value
		end
		if v27 and v27:IsA("CFrameValue") then
			v24 = v27.Value
		end
	end
	v_u_6.PoseForJoint(p18.Model, p20, p19, v23, v24)
	local v28 = Instance.new("Motor6D")
	v28.Name = p22
	v28.C0 = v23
	v28.C1 = v24
	v28.Part0 = p19
	v28.Part1 = p20
	v28.Parent = p19
	p18.Motors[#p18.Motors + 1] = v28
end
local function v_u_37(p30, p31, p32, p33) -- name: joinHands
	-- upvalues: (copy) v_u_29
	local v34 = p31.Model
	if not p33 then
		v_u_29(p31, p32, v34.PrimaryPart, "", "WeaponAttachment")
		return true
	end
	local v35 = v34:FindFirstChild("HandleR", true)
	local v36 = v34:FindFirstChild("HandleL", true)
	if v35 == nil or (v36 == nil or not (v35:IsA("BasePart") and v36:IsA("BasePart"))) then
		return false
	end
	v_u_29(p31, p30:FindFirstChild("RightHand"), v35, "RIGHT", "WeaponAttachmentHandleR")
	v_u_29(p31, p30:FindFirstChild("LeftHand"), v36, "LEFT", "WeaponAttachmentHandleL")
	return true
end
function v_u_7.attach(p38, p39, p40) -- name: attach
	-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_4, (copy) v_u_9, (copy) v_u_6, (copy) v_u_37, (copy) v_u_7, (copy) v_u_1, (copy) v_u_8, (copy) v_u_5
	local v41 = v_u_3(p39)
	local v42 = v_u_2:FindFirstChild("Assets")
	local v43
	if v42 then
		v43 = v42:FindFirstChild("Weapons")
	else
		v43 = nil
	end
	local v44
	if v43 then
		v44 = v43:FindFirstChild(p39)
	else
		v44 = nil
	end
	local v45
	if v44 then
		v45 = v44:FindFirstChild("Character")
	else
		v45 = nil
	end
	local v46 = p38:FindFirstChild("WeaponModel")
	if v41 == nil or (v45 == nil or (not v45:IsA("Model") or v46 == nil)) then
		return nil
	end
	local v47 = v41.ShootingOptions == "Dual"
	local v48 = p38:FindFirstChild(v_u_4.WEAPON_JOINT_PARTS[p39] or v_u_4.DEFAULT_JOINT_PART)
	if v48 == nil or not v48:IsA("BasePart") then
		return nil
	end
	if v47 and (p38:FindFirstChild("LeftHand") == nil or p38:FindFirstChild("RightHand") == nil) then
		return nil
	end
	local v49 = v_u_9[p38]
	local v50
	if v49 then
		v50 = v49[p39]
	else
		v50 = nil
	end
	if v50 then
		v49[p39] = nil
		if v_u_6.TryUnpark(v50.Model, v46) then
			if not v_u_37(p38, v50, v48, v47) then
				v_u_7.destroy(v50)
				return nil
			end
			v_u_6.Release(v50.Motors)
			v50.Revision = p40
			v50.Model:SetAttribute("WeaponRevision", p40)
			return v50
		end
	end
	local v51 = p38:GetAttribute("BotLoadout")
	local v52
	if type(v51) == "string" then
		v52 = v_u_1:JSONDecode(v51)
	else
		v52 = nil
	end
	if v52 then
		v52 = v52.Weapons[p39]
	end
	local v53
	if v52 then
		v53 = require(v_u_2.Database.Components.Libraries.Skins).GetCharacterModel(p39, v52.Skin, v52.Float, false, false, false, {}, p38:GetAttribute("Team"))
	else
		v53 = v45:Clone()
	end
	if v53 == nil then
		return nil
	end
	if v53.PrimaryPart == nil then
		v53:Destroy()
		return nil
	end
	local v54 = {
		["Model"] = v53,
		["Name"] = p39,
		["Revision"] = p40,
		["Motors"] = {},
		["Muzzles"] = {},
		["MuzzleType"] = v41.MuzzleType
	}
	for _, v55 in v53:GetDescendants() do
		if v55:IsA("BasePart") then
			v55.CollisionGroup = "WeaponModel"
			v55.CanCollide = false
			v55.CanTouch = false
			v55.CanQuery = false
			v55.Anchored = false
			v55.Massless = true
			v55.CastShadow = false
			if not v_u_8[v55.Name] and v55.Name ~= "Silencer" then
				continue
			end
			v55.Transparency = 1
		else
			if not v55:IsA("BaseScript") then
				continue
			end
			v55:Destroy()
		end
	end
	if not v_u_37(p38, v54, v48, v47) then
		v53:Destroy()
		return nil
	end
	local v56
	if v42 then
		v56 = v42:FindFirstChild("MuzzleFlashes")
	else
		v56 = nil
	end
	local v57
	if v56 then
		v57 = v56:FindFirstChild("Character")
	else
		v57 = nil
	end
	local v58 = v53:FindFirstChild("Interactables")
	if v58 then
		for _, v59 in v47 and { "MuzzlePartR", "MuzzlePartL" } or { "MuzzlePart" } do
			local v60 = v58:FindFirstChild(v59)
			if not (v60 and v60:IsA("BasePart")) then
				continue
			end
			v54.Muzzles[#v54.Muzzles + 1] = v60
			if not (v57 and (v41.MuzzleType and v57:FindFirstChild(v41.MuzzleType))) then
				continue
			end
			v_u_5(v60, v57, v41.MuzzleType, "WeldConstraint")
		end
	end
	v53.Name = "Equipped"
	v53:SetAttribute("WeaponName", p39)
	v53:SetAttribute("WeaponRevision", p40)
	v53.Parent = v46
	return v54
end
return table.freeze(v_u_7)
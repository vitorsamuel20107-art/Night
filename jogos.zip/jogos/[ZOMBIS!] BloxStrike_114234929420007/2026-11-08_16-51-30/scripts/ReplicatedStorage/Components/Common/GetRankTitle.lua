-- NIGHT Analyzer | ReplicatedStorage.Components.Common.GetRankTitle
-- ModuleScript | 44 linhas | 748 bytes | hash 09222d06

local v_u_1 = table.freeze({
	table.freeze({
		["maxLevel"] = 5,
		["title"] = "Recruit"
	}),
	table.freeze({
		["maxLevel"] = 10,
		["title"] = "Private"
	}),
	table.freeze({
		["maxLevel"] = 15,
		["title"] = "Corporal"
	}),
	table.freeze({
		["maxLevel"] = 20,
		["title"] = "Sergeant"
	}),
	table.freeze({
		["maxLevel"] = 25,
		["title"] = "Master Sergeant"
	}),
	table.freeze({
		["maxLevel"] = 30,
		["title"] = "Lieutenant"
	}),
	table.freeze({
		["maxLevel"] = 35,
		["title"] = "Captain"
	}),
	table.freeze({
		["maxLevel"] = 40,
		["title"] = "Global Elite"
	})
})
return function(p2)
	-- upvalues: (copy) v_u_1
	for _, v3 in ipairs(v_u_1) do
		if p2 > v3.maxLevel then
			continue
		end
		return v3.title
	end
	return "Global Elite"
end
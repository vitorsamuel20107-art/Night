-- NIGHT Analyzer | ReplicatedStorage.Components.Common.InterfaceAnimations.AnimateZombiesPromotion
-- ModuleScript | 248 linhas | 7358 bytes | hash 30e26a53

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = require(v1.Controllers.RunServiceController)
local v_u_4 = require(v1.Database.Security.Router)
local v_u_5 = require(script.Parent.GuiShown)
local v_u_6 = require(script.Parent.Glints)
local v_u_7 = NumberRange.new(0.4, 3)
local function v_u_12(p8) -- name: glowsIn
	local v9 = {}
	if not p8 then
		return v9
	end
	for _, v10 in p8:GetChildren() do
		if v10.Name ~= "Glow" or not v10:IsA("ImageLabel") then
			continue
		end
		local v11 = {
			["Image"] = v10,
			["Transparency"] = v10.ImageTransparency
		}
		table.insert(v9, v11)
	end
	return v9
end
local function v_u_18(p13) -- name: inReadingOrder
	local v14 = {}
	for _, v15 in p13:GetChildren() do
		if not v15:IsA("GuiObject") then
			continue
		end
		table.insert(v14, v15)
	end
	table.sort(v14, function(p16, p17)
		if p16.LayoutOrder == p17.LayoutOrder then
			return p16.AbsolutePosition.X < p17.AbsolutePosition.X
		else
			return p16.LayoutOrder < p17.LayoutOrder
		end
	end)
	return v14
end
return function(p19)
	-- upvalues: (copy) v_u_18, (copy) v_u_12, (copy) v_u_4, (copy) v_u_6, (copy) v_u_2, (copy) v_u_7, (copy) v_u_3, (copy) v_u_5
	local v_u_20 = {}
	local v_u_21 = {}
	local v_u_22 = Random.new()
	local v23 = p19:FindFirstChild("Rewards")
	if v23 then
		v23 = v23:FindFirstChild("Items")
	end
	if v23 then
		for _, v24 in v_u_18(v23) do
			local v25 = v24:FindFirstChild("Icon")
			local v26 = v24:FindFirstChildOfClass("UIStroke")
			local v_u_27 = {
				["Scale"] = nil,
				["Stroke"] = nil,
				["StrokeThickness"] = nil,
				["Glows"] = nil,
				["Hovered"] = false,
				["Hover"] = 0
			}
			local v28 = not v25 or v25:FindFirstChild("PromotionScale")
			if not v28 then
				v28 = Instance.new("UIScale")
				v28.Name = "PromotionScale"
				v28.Parent = v25
			end
			v_u_27.Scale = v28
			v_u_27.Stroke = v26
			v_u_27.StrokeThickness = not v26 and 0 or v26.Thickness
			v_u_27.Glows = v_u_12(v24)
			v24.MouseEnter:Connect(function()
				-- upvalues: (copy) v_u_27, (ref) v_u_4
				v_u_27.Hovered = true
				v_u_4.broadcastRouter("RunInterfaceSound", "UI Highlight")
			end)
			v24.MouseLeave:Connect(function()
				-- upvalues: (copy) v_u_27
				v_u_27.Hovered = false
			end)
			table.insert(v_u_20, v_u_27)
			for _, v29 in v_u_6.Create(v24, 2, v_u_22, 5) do
				table.insert(v_u_21, v29)
			end
		end
	end
	local v_u_30 = v_u_12(p19:FindFirstChild("BG"))
	for _, v31 in v_u_12(p19:FindFirstChild("GlowEffect")) do
		table.insert(v_u_30, v31)
	end
	local v32 = p19:FindFirstChild("TitleGlow")
	if v32 and v32:IsA("ImageLabel") then
		local v33 = {
			["Image"] = v32,
			["Transparency"] = v32.ImageTransparency
		}
		table.insert(v_u_30, v33)
	end
	local v34 = p19:FindFirstChild("Join")
	local v_u_35 = not v34 or v34:FindFirstChild("PromotionScale")
	if not v_u_35 then
		v_u_35 = Instance.new("UIScale")
		v_u_35.Name = "PromotionScale"
		v_u_35.Parent = v34
	end
	local v_u_36 = {}
	local v_u_37 = false
	local v_u_38 = 0
	local v_u_39 = (-1 / 0)
	local v_u_40
	if v34 then
		for _, v41 in v_u_12(v34:FindFirstChild("GlowEffect")) do
			if v41.Transparency >= 1 then
				continue
			end
			table.insert(v_u_36, v41)
		end
		v_u_40 = v34:FindFirstChild("Shine")
		v34.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_37, (ref) v_u_39
			v_u_37 = true
			local v42 = os.clock()
			if v42 - v_u_39 > 0.75 then
				v_u_39 = v42
			end
		end)
		v34.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_37
			v_u_37 = false
		end)
	else
		v_u_40 = nil
	end
	local function v_u_47() -- name: rest
		-- upvalues: (ref) v_u_6, (copy) v_u_21, (copy) v_u_20, (copy) v_u_30, (copy) v_u_36, (copy) v_u_35, (ref) v_u_40
		v_u_6.Hide(v_u_21)
		for _, v43 in v_u_20 do
			if v43.Scale then
				v43.Scale.Scale = 1
			end
			if v43.Stroke then
				v43.Stroke.Thickness = v43.StrokeThickness
			end
			for _, v44 in v43.Glows do
				v44.Image.ImageTransparency = v44.Transparency
			end
		end
		for _, v45 in v_u_30 do
			v45.Image.ImageTransparency = v45.Transparency
		end
		for _, v46 in v_u_36 do
			v46.Image.ImageTransparency = v46.Transparency
		end
		if v_u_35 then
			v_u_35.Scale = 1
		end
		if v_u_40 then
			v_u_40.Position = UDim2.new(-0.3, v_u_40.Position.X.Offset, v_u_40.Position.Y.Scale, v_u_40.Position.Y.Offset)
		end
	end
	local v_u_48 = 0
	local function v_u_85(p49) -- name: step
		-- upvalues: (ref) v_u_2, (copy) v_u_47, (ref) v_u_6, (copy) v_u_21, (copy) v_u_22, (ref) v_u_7, (copy) v_u_20, (ref) v_u_48, (copy) v_u_30, (ref) v_u_38, (ref) v_u_37, (copy) v_u_35, (copy) v_u_36, (ref) v_u_39, (ref) v_u_40
		if v_u_2.ReducedMotionEnabled then
			v_u_47()
		else
			local v50 = os.clock()
			local v51 = p49 * -14
			local v52 = 1 - math.exp(v51)
			v_u_6.Step(v_u_21, v_u_22, v50, v_u_7)
			for v53, v54 in v_u_20 do
				local v55 = v54.Hovered and 1 or 0
				v54.Hover = v54.Hover + (v55 - v54.Hover) * v52
				local v56 = v55 - v54.Hover
				if math.abs(v56) < 0.001 then
					v54.Hover = v55
				end
				local v57 = (v50 - v_u_48 - 0.12 - (v53 - 1) * 0.08) / 0.4
				local v58 = math.clamp(v57, 0, 1)
				if v54.Scale then
					v54.Scale.Scale = ((v58 - 1) ^ 3 * 2.70158 + 1 + (v58 - 1) ^ 2 * 1.70158) * (v54.Hover * 0.15 + 1)
				end
				if v54.Stroke then
					v54.Stroke.Thickness = v54.StrokeThickness + v54.Hover * 1
				end
				for v59, v60 in v54.Glows do
					local v61 = v53 * 0.23 + v59 * 0.15
					local v62 = (v50 / 2.2 + v61) * 2 * 3.141592653589793
					local v63 = (math.sin(v62) + 1) / 2 * 0.22
					local v64 = v54.Hover * 0.25
					local v65 = v60.Image
					local v66 = v60.Transparency + v63 - v64
					v65.ImageTransparency = math.clamp(v66, 0, 1)
				end
			end
			for v67, v68 in v_u_30 do
				local v69 = v67 * 0.37
				local v70 = (v50 / 3.6 + v69) * 2 * 3.141592653589793
				local v71 = (math.sin(v70) + 1) / 2 * 0.15
				local v72 = v68.Image
				local v73 = v68.Transparency + v71
				v72.ImageTransparency = math.clamp(v73, 0, 1)
			end
			v_u_38 = v_u_38 + ((v_u_37 and 1 or 0) - v_u_38) * v52
			if v_u_35 then
				local v74 = v_u_35
				local v75 = (v50 / 1.6 + 0) * 2 * 3.141592653589793
				v74.Scale = (math.sin(v75) + 1) * 0.025 / 2 * (1 - v_u_38) + 1
			end
			for _, v76 in v_u_36 do
				local v77 = (v50 / 1.6 + 0.5) * 2 * 3.141592653589793
				local v78 = (math.sin(v77) + 1) / 2 * 0.22
				local v79 = v76.Image
				local v80 = v76.Transparency + v78 - v_u_38 * 0.22
				v79.ImageTransparency = math.clamp(v80, 0, 1)
			end
			if v50 - v_u_39 >= 3.2 then
				v_u_39 = v50
			end
			local v81 = (v50 - v_u_39) / 0.75
			local v82 = math.clamp(v81, 0, 1)
			local v83
			if v82 < 0.5 then
				v83 = v82 * 2 * v82
			else
				v83 = 1 - (v82 * -2 + 2) ^ 2 / 2
			end
			local v84 = v83 * 1.6 + -0.3
			if v_u_40 then
				v_u_40.Position = UDim2.new(v84, v_u_40.Position.X.Offset, v_u_40.Position.Y.Scale, v_u_40.Position.Y.Offset)
			end
		end
	end
	local v_u_86 = v_u_3.CreateBindingName("UI.Gamemodes.ZombiesPromotion")
	local v_u_87 = nil
	v_u_5.Observe(p19, function(p88)
		-- upvalues: (ref) v_u_48, (ref) v_u_39, (copy) v_u_20, (ref) v_u_87, (ref) v_u_3, (copy) v_u_86, (copy) v_u_85
		if p88 then
			v_u_48 = os.clock()
			v_u_39 = v_u_48 + 0.12 + #v_u_20 * 0.08 - 3.2
			v_u_87 = v_u_3.BindToRenderStep(v_u_86, v_u_85)
		elseif v_u_87 then
			v_u_87:Disconnect()
			v_u_87 = nil
		end
	end)
end
-- NIGHT Analyzer | ReplicatedStorage.Components.Common.CenterScreenRaycast
-- ModuleScript | 180 linhas | 4601 bytes | hash 8deb0ca8

local v_u_1 = {}
local v_u_2 = game:GetService("CollectionService")
local v3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("Players")
local v_u_5 = game:GetService("Workspace")
local v6 = require(v3.Controllers.RunServiceController)
local v_u_7 = require(v3.Components.Common.CharacterResolver)
local v_u_8 = v4.LocalPlayer
local v_u_9 = RaycastParams.new()
v_u_9.FilterType = Enum.RaycastFilterType.Exclude
v_u_9.IgnoreWater = true
local v_u_10 = 0
local v_u_11 = -1
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = 0
local v_u_16 = nil
v6.BindToHeartbeat("Components.CenterScreenRaycast.InvalidateCache", function()
	-- upvalues: (ref) v_u_10
	v_u_10 = v_u_10 + 1
end)
local function v_u_24(p17) -- name: ResolveRaycast
	-- upvalues: (copy) v_u_5, (copy) v_u_7, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16, (ref) v_u_10, (copy) v_u_9
	local v18 = v_u_5.CurrentCamera
	local v19 = v_u_7.getLocalCharacter()
	if not (v18 and v19) then
		v_u_11 = -1
		v_u_12 = nil
		v_u_13 = nil
		v_u_14 = nil
		v_u_15 = 0
		v_u_16 = nil
		return nil
	end
	local v20 = v18.CFrame
	local v21
	if v_u_11 == v_u_10 and (v_u_12 == v18 and (v_u_14 == v19 and v_u_13 == v20)) then
		v21 = p17 <= v_u_15
	else
		v21 = false
	end
	if v21 then
		return v_u_16
	end
	local v22 = v_u_5:FindFirstChild("Map")
	local v23
	if v22 then
		v23 = v22:FindFirstChild("Barriers")
	else
		v23 = nil
	end
	v_u_9.FilterDescendantsInstances = v23 and { v19, v18, v23 } or { v19, v18 }
	v_u_16 = v_u_5:Raycast(v20.Position, v20.LookVector * p17, v_u_9)
	v_u_11 = v_u_10
	v_u_12 = v18
	v_u_13 = v20
	v_u_14 = v19
	v_u_15 = p17
	return v_u_16
end
function v_u_1.GetResult(p25) -- name: GetResult
	-- upvalues: (copy) v_u_24
	local v26 = p25 or 10
	local v27 = v_u_24(v26)
	if v27 and v26 >= v27.Distance then
		return v27
	else
		return nil
	end
end
function v_u_1.GetInstance(p28) -- name: GetInstance
	-- upvalues: (copy) v_u_1
	local v29 = v_u_1.GetResult(p28)
	if v29 then
		return v29.Instance
	else
		return nil
	end
end
function v_u_1.FindTaggedAncestor(p30, p31) -- name: FindTaggedAncestor
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v32 = v_u_1.GetInstance(p31)
	while v32 do
		if v_u_2:HasTag(v32, p30) then
			return v32
		end
		v32 = v32.Parent
	end
	return nil
end
local function v_u_49(p33, p34, p35, p36, p37) -- name: RayEntersBox
	local v38 = p33:PointToObjectSpace(p35)
	local v39 = p33:VectorToObjectSpace(p36)
	local v40 = p34 / 2
	local v41 = 0
	for _, v42 in { "X", "Y", "Z" } do
		local v43 = v38[v42]
		local v44 = v39[v42]
		local v45 = v40[v42]
		if math.abs(v44) < 1e-6 then
			if v45 >= math.abs(v43) then
				continue
			end
			return nil
		end
		local v46 = (-v45 - v43) / v44
		local v47 = (v45 - v43) / v44
		if v47 >= v46 then
			local v48 = v46
			v46 = v47
			v47 = v48
		end
		v41 = math.max(v41, v47)
		p37 = math.min(p37, v46)
		if p37 >= v41 then
			continue
		end
		return nil
	end
	return v41
end
function v_u_1.FindTaggedModelInSight(p50, p51) -- name: FindTaggedModelInSight
	-- upvalues: (copy) v_u_1, (copy) v_u_5, (copy) v_u_7, (copy) v_u_2, (copy) v_u_49
	local v52 = p51 or 10
	local v53 = v_u_1.FindTaggedAncestor(p50, v52)
	if v53 and v53:IsA("Model") then
		return v53
	end
	local v54 = v_u_5.CurrentCamera
	if not (v54 and v_u_7.getLocalCharacter()) then
		return nil
	end
	local v55 = v54.CFrame.Position
	local v56 = v54.CFrame.LookVector
	local v57 = v_u_1.GetResult(v52)
	local v58 = (1 / 0)
	local v59 = nil
	for _, v60 in v_u_2:GetTagged(p50) do
		if not v60:IsA("Model") or v60:GetAttribute("Destroyed") == true then
			continue
		end
		local v61, v62 = v60:GetBoundingBox()
		if (v61.Position - v55).Magnitude > v52 + v62.Magnitude / 2 then
			continue
		end
		local v63 = v_u_49(v61, v62, v55, v56, v52)
		if v63 == nil or (v58 <= v63 or v57 and (v57.Distance < v63 - 0.25 and not v57.Instance:IsDescendantOf(v60))) then
			continue
		end
		v59 = v60
		v58 = v63
	end
	return v59
end
function v_u_1.GetHoveredHostage(p64) -- name: GetHoveredHostage
	-- upvalues: (copy) v_u_8, (copy) v_u_1
	if v_u_8:GetAttribute("Team") == "Counter-Terrorists" then
		local v65 = v_u_1.FindTaggedAncestor("Hostage", p64 or 5)
		if v65 and v65:IsA("Model") then
			if v65:GetAttribute("CanRescue") == true then
				local v66 = v65:GetAttribute("RescuingPlayer")
				if v66 and v66 ~= v_u_8.Name then
					return nil
				elseif v65:GetAttribute("CarryingPlayer") then
					return nil
				else
					return v65
				end
			else
				return nil
			end
		else
			return nil
		end
	else
		return nil
	end
end
return v_u_1
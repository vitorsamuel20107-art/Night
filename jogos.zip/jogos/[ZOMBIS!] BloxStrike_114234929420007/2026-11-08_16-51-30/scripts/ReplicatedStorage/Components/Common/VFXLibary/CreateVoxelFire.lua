-- NIGHT Analyzer | ReplicatedStorage.Components.Common.VFXLibary.CreateVoxelFire
-- ModuleScript | 224 linhas | 6097 bytes | hash 9b4766d7

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("TweenService")
game:GetService("Workspace")
local v3 = v1:WaitForChild("Assets"):WaitForChild("GrenadeParticles")
local v_u_4 = v3:WaitForChild("InnerFire")
local v_u_5 = v3:WaitForChild("OuterFire")
local v_u_6 = {}
local function v_u_10(p7) -- name: DisableEmitters
	for _, v8 in ipairs(p7:GetChildren()) do
		if not v8:IsA("BasePart") then
			continue
		end
		for _, v9 in ipairs(v8:GetDescendants()) do
			if not v9:IsA("ParticleEmitter") then
				continue
			end
			v9.Enabled = false
		end
	end
end
local function v_u_31(p11, p12) -- name: GetSurfaceCFrame
	local v13 = p12.Unit
	local v14 = v13.Y
	if math.abs(v14) > 0.99 then
		return CFrame.new(p11)
	end
	local v15 = v13.X
	local v16 = math.abs(v15)
	local v17 = v13.Z
	local v18
	if math.abs(v17) <= v16 then
		local v19 = v13.X
		local v20 = v13.Y
		v18 = Vector3.new(v19, v20, 0).Unit
	else
		local v21 = v13.Y
		local v22 = v13.Z
		v18 = Vector3.new(0, v21, v22).Unit
	end
	local v23 = v18.X
	local v24 = v18.Z
	local v25 = Vector3.new(v23, 0, v24)
	if v25.Magnitude < 0.01 then
		return CFrame.new(p11)
	end
	local v26 = v25.Unit
	local v27 = v26.Z
	local v28 = -v26.X
	local v29 = Vector3.new(v27, 0, v28)
	local v30 = v29:Cross(v18).Unit
	return CFrame.fromMatrix(p11, v29, v18, -v30)
end
local function v_u_40(p32, p33, p34, p35, p36, p37) -- name: CreateVoxel
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_31
	local v38 = (p36 and v_u_4 or v_u_5):Clone()
	v38.Name = p36 and "InnerFireVoxel" or "OuterFireVoxel"
	v38.Size = Vector3.new(p33, 0.2, p34)
	v38.CFrame = v_u_31(p32, p35)
	v38.Anchored = true
	v38.CanCollide = false
	v38.CanQuery = false
	v38.CanTouch = false
	v38.CastShadow = false
	v38.Parent = p37
	for _, v39 in ipairs(v38:GetDescendants()) do
		if not v39:IsA("ParticleEmitter") then
			continue
		end
		v39.Enabled = true
	end
	return v38
end
local v_u_90 = {
	["Create"] = function(p_u_41) -- name: Create
		-- upvalues: (copy) v_u_6, (copy) v_u_40, (copy) v_u_2, (copy) v_u_90
		debug.profilebegin("VFX.VoxelFire.Create")
		local v42 = Instance.new("Folder")
		v42.Name = "VoxelFire_" .. p_u_41.FireId
		v_u_6[p_u_41.FireId] = v42
		debug.profilebegin("VFX.VoxelFire.Create.CalculateCenter")
		local v43 = p_u_41.Voxels
		local v44 = Vector3.new(0, 0, 0)
		for _, v45 in ipairs(v43) do
			v44 = v44 + v45.Position
		end
		if #v43 > 0 then
			v44 = v44 / #v43
		end
		debug.profileend()
		local v46 = CFrame.identity
		debug.profilebegin("VFX.VoxelFire.Create.CreateVoxels")
		local v47 = (1 / 0)
		local v48 = nil
		local v49 = Vector3.new(0, 0, 0)
		for _, v50 in ipairs(p_u_41.Voxels) do
			local v51 = v50.Position
			local v52 = v51.X
			local v53 = v51.Z
			local v54 = Vector3.new(v52, 0, v53)
			local v55 = v44.X
			local v56 = v44.Z
			local v57 = (v54 - Vector3.new(v55, 0, v56)).Magnitude <= 4
			local v58 = v_u_40(v50.Position, v50.SizeX, v50.SizeZ, v50.Normal, v57, v42)
			local v59 = v50.Position
			local v60 = p_u_41.Position
			local v61 = v59.X
			local v62 = v59.Z
			local v63 = Vector3.new(v61, 0, v62)
			local v64 = v60.X
			local v65 = v60.Z
			local v66 = (v63 - Vector3.new(v64, 0, v65)).Magnitude
			if v66 >= v47 then
				continue
			end
			v49 = v58.Size
			v46 = v58.CFrame
			v48 = v58
			v47 = v66
		end
		v42.Parent = workspace:WaitForChild("Debris")
		debug.profileend()
		if v48 then
			debug.profilebegin("VFX.VoxelFire.Create.LandingBurstTween")
			local v67 = v49.X
			local v68 = v49.Z
			local v69 = Vector3.new(v67, 10, v68)
			local v70 = v46 + v46.UpVector * ((v69.Y - v49.Y) / 2)
			v48.Size = v69
			v48.CFrame = v70
			v_u_2:Create(v48, TweenInfo.new(2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Size"] = v49,
				["CFrame"] = v46
			}):Play()
			debug.profileend()
		end
		task.delay(p_u_41.Duration, function()
			-- upvalues: (ref) v_u_6, (copy) p_u_41, (ref) v_u_90
			if v_u_6[p_u_41.FireId] then
				v_u_90.Destroy(p_u_41.FireId)
			end
		end)
		debug.profileend()
	end,
	["Destroy"] = function(p71) -- name: Destroy
		-- upvalues: (copy) v_u_6, (copy) v_u_10
		debug.profilebegin("VFX.VoxelFire.Destroy")
		local v_u_72 = v_u_6[p71]
		if v_u_72 then
			v_u_10(v_u_72)
			task.delay(2, function()
				-- upvalues: (copy) v_u_72
				if v_u_72.Parent then
					v_u_72:Destroy()
				end
			end)
			v_u_6[p71] = nil
		end
		debug.profileend()
	end,
	["Update"] = function(p_u_73) -- name: Update
		-- upvalues: (copy) v_u_6, (copy) v_u_10, (copy) v_u_40
		debug.profilebegin("VFX.VoxelFire.Update")
		local v_u_74 = v_u_6[p_u_73.FireId]
		if v_u_74 then
			v_u_10(v_u_74)
			task.delay(0.3, function()
				-- upvalues: (copy) v_u_74, (copy) p_u_73, (ref) v_u_40
				debug.profilebegin("VFX.VoxelFire.Update.DelayedRebuild")
				if v_u_74.Parent then
					for _, v75 in ipairs(v_u_74:GetChildren()) do
						if not v75:IsA("BasePart") then
							continue
						end
						v75:Destroy()
					end
					if #p_u_73.Voxels == 0 then
						debug.profileend()
					else
						local v76 = p_u_73.Voxels
						local v77 = Vector3.new(0, 0, 0)
						for _, v78 in ipairs(v76) do
							v77 = v77 + v78.Position
						end
						if #v76 > 0 then
							v77 = v77 / #v76
						end
						local v79 = v_u_74.Parent
						v_u_74.Parent = nil
						for _, v80 in ipairs(p_u_73.Voxels) do
							local v81 = v80.Position
							local v82 = v81.X
							local v83 = v81.Z
							local v84 = Vector3.new(v82, 0, v83)
							local v85 = v77.X
							local v86 = v77.Z
							local v87 = (v84 - Vector3.new(v85, 0, v86)).Magnitude <= 4
							v_u_40(v80.Position, v80.SizeX, v80.SizeZ, v80.Normal, v87, v_u_74)
						end
						v_u_74.Parent = v79
						debug.profileend()
					end
				else
					debug.profileend()
					return
				end
			end)
			debug.profileend()
		else
			debug.profileend()
		end
	end,
	["DestroyAll"] = function() -- name: DestroyAll
		-- upvalues: (copy) v_u_6
		debug.profilebegin("VFX.VoxelFire.DestroyAll")
		for v88, v89 in pairs(v_u_6) do
			if v89.Parent then
				v89:Destroy()
			end
			v_u_6[v88] = nil
		end
		debug.profileend()
	end
}
return v_u_90
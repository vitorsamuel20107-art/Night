-- NIGHT Analyzer | ReplicatedStorage.Components.Common.VFXLibary.CreateMarker.Components.Melee
-- ModuleScript | 17 linhas | 434 bytes | hash d4bd25f8

local v1 = table.freeze
local v2 = {
	["Images"] = { "rbxassetid://88027686092020" },
	["Properties"] = {
		["Color3"] = Color3.fromRGB(56, 56, 56),
		["Transparency"] = function() -- name: Transparency
			return math.random(0, 4) / 10
		end,
		["Rotation"] = function() -- name: Rotation
			return math.random(-20, 20)
		end,
		["SizeRange"] = function() -- name: SizeRange
			return math.random(10, 12) / 10
		end
	}
}
return v1(v2)
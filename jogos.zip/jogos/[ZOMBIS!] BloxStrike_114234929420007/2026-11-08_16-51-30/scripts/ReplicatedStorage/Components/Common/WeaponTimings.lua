-- NIGHT Analyzer | ReplicatedStorage.Components.Common.WeaponTimings
-- ModuleScript | 124 linhas | 3197 bytes | hash cbc8c351

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = {
	["EQUIP_PULLOUT_FRACTION"] = 0.925,
	["DEFAULT_EQUIP_PULLOUT"] = 0.5,
	["EQUIP_ACTION_LOCKOUT"] = 1,
	["MELEE_EQUIP_LOCKOUT"] = 1,
	["BURST_SHOT_COUNT"] = 3,
	["BURST_SHOT_INTERVAL"] = 0.075,
	["BURST_COOLDOWN"] = 0.15
}
local v_u_3 = {}
local v_u_4 = false
function v_u_2.PulloutSeconds(p5) -- name: PulloutSeconds
	-- upvalues: (copy) v_u_2
	if p5 == nil or p5 <= 0 then
		return v_u_2.DEFAULT_EQUIP_PULLOUT
	else
		return p5 * v_u_2.EQUIP_PULLOUT_FRACTION
	end
end
local function v_u_13(p6) -- name: clipLength
	local v7 = 0
	if p6:IsA("KeyframeSequence") then
		for _, v8 in p6:GetKeyframes() do
			local v9 = v8.Time
			v7 = math.max(v7, v9)
		end
	else
		for _, v10 in p6:GetDescendants() do
			if not (v10:IsA("FloatCurve") or v10:IsA("RotationCurve")) then
				continue
			end
			for _, v11 in v10:GetKeys() do
				local v12 = v11.Time
				v7 = math.max(v7, v12)
			end
		end
	end
	if v7 > 0 then
		return v7
	else
		return nil
	end
end
local function v_u_24(p14, p15, p16, p17) -- name: fetchLength
	-- upvalues: (copy) v_u_13
	local v18 = p15:FindFirstChild(p16)
	if v18 == nil or not v18:IsA("Animation") then
		return nil
	end
	local v19 = p14.GetAnimationClipAsync
	local v20 = v18.AnimationId
	local v21, v22 = pcall(v19, p14, v20)
	if not v21 or v22 == nil then
		warn((("[WeaponTimings] %* %* clip unavailable: %*"):format(p17, p16, (tostring(v22)))))
		return nil
	end
	local v23 = v_u_13(v22)
	v22:Destroy()
	return v23
end
function v_u_2.Load() -- name: Load
	-- upvalues: (ref) v_u_4, (copy) v_u_1, (copy) v_u_3, (copy) v_u_24
	if not v_u_4 then
		v_u_4 = true
		local v25 = game:GetService("AnimationClipProvider")
		for _, v26 in v_u_1.Database.Custom.Weapons:GetChildren() do
			if not v26:IsA("ModuleScript") then
				continue
			end
			local v27 = require(v26)
			local v28 = v27.CameraAnimations
			if v27.Class ~= "Weapon" or typeof(v28) ~= "Instance" then
				continue
			end
			v_u_3[v26.Name] = {
				["Equip"] = v_u_24(v25, v28, "Equip", v26.Name),
				["Reload"] = v_u_24(v25, v28, "Reload", v26.Name)
			}
		end
	end
end
function v_u_2.DrawSeconds(p29) -- name: DrawSeconds
	-- upvalues: (copy) v_u_3, (copy) v_u_2
	local v30 = v_u_3[p29]
	local v31 = v_u_2.PulloutSeconds
	local v32
	if v30 then
		v32 = v30.Equip
	else
		v32 = nil
	end
	return v31(v32)
end
function v_u_2.MinShotInterval(p33) -- name: MinShotInterval
	-- upvalues: (copy) v_u_2
	local v34 = p33.FireRate or 0
	local v35 = p33.FireModes
	if v35 ~= nil then
		if v35.Primary ~= nil and v35.Primary.FireRate ~= nil then
			local v36 = v35.Primary.FireRate
			v34 = math.min(v34, v36)
		end
		if v35.Secondary ~= nil and v35.Secondary.FireRate ~= nil then
			local v37 = v35.Secondary.FireRate
			v34 = math.min(v34, v37)
		end
	end
	if p33.ShootingOptions == "Burst" then
		local v38 = (v_u_2.BURST_SHOT_INTERVAL * v_u_2.BURST_SHOT_COUNT + v_u_2.BURST_COOLDOWN) / v_u_2.BURST_SHOT_COUNT
		v34 = math.min(v34, v38)
	end
	return v34
end
function v_u_2.ReloadSeconds(p39) -- name: ReloadSeconds
	-- upvalues: (copy) v_u_3
	local v40 = v_u_3[p39]
	if v40 then
		return v40.Reload
	else
		return nil
	end
end
return table.freeze(v_u_2)
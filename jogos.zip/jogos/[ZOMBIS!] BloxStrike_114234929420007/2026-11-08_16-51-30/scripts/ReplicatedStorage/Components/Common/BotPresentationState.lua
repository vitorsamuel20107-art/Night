-- NIGHT Analyzer | ReplicatedStorage.Components.Common.BotPresentationState
-- ModuleScript | 83 linhas | 2149 bytes | hash 87e11bab

return table.freeze({
	["validate"] = function(p1) -- name: validate
		local v2
		if type(p1) == "table" then
			local v3 = p1.CombatantId
			if type(v3) == "number" and (v3 >= 1 and v3 <= 9007199254740991) then
				v2 = v3 % 1 == 0
			else
				v2 = false
			end
			if v2 then
				local v4 = p1.ActorId
				if type(v4) == "number" and (v4 >= 1 and v4 <= 4294967295) then
					v2 = v4 % 1 == 0
				else
					v2 = false
				end
				if v2 then
					local v5 = p1.Generation
					if type(v5) == "number" and (v5 >= 1 and v5 <= 65535) then
						v2 = v5 % 1 == 0
					else
						v2 = false
					end
					if v2 then
						local v6 = p1.DisplayName
						if type(v6) == "string" then
							local v7 = p1.Team
							if type(v7) == "string" then
								local v8 = p1.CharacterName
								if type(v8) == "string" and p1.CharacterName ~= "" then
									local v9 = p1.Health
									if type(v9) == "number" and p1.Health >= 0 then
										local v10 = p1.MaxHealth
										if type(v10) == "number" and (p1.MaxHealth > 0 and (p1.MaxHealth < (1 / 0) and p1.Health <= p1.MaxHealth)) then
											local v11 = p1.Dead
											v2 = type(v11) == "boolean"
										else
											v2 = false
										end
									else
										v2 = false
									end
								else
									v2 = false
								end
							else
								v2 = false
							end
						else
							v2 = false
						end
					end
				end
			end
		else
			v2 = false
		end
		return v2
	end,
	["sameLife"] = function(p12, p13) -- name: sameLife
		local v14
		if p12.CombatantId == p13.CombatantId and p12.ActorId == p13.ActorId then
			v14 = p12.Generation == p13.Generation
		else
			v14 = false
		end
		return v14
	end,
	["decide"] = function(p15, p16) -- name: decide
		if p15 == nil or (p15.Dead or p15.Health <= 0) then
			return "Destroy"
		end
		if p16 == nil then
			return "Hide"
		end
		if p16.UserId ~= 0 or (p16.ActorId ~= p15.ActorId or p16.Generation ~= p15.Generation) then
			return "Hide"
		end
		local v17 = p16.RenderPose
		return v17 == nil and "Hold" or (v17.UserId == 0 and (v17.ActorId == p15.ActorId and v17.Generation == p15.Generation) and "Present" or "Hide")
	end
})
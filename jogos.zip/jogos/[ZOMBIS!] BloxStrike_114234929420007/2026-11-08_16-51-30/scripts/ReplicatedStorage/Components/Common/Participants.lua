-- NIGHT Analyzer | ReplicatedStorage.Components.Common.Participants
-- ModuleScript | 238 linhas | 5909 bytes | hash ced6b4e4

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.CharacterResolver)
local v_u_32 = {
	["IsBot"] = function(p5) -- name: IsBot
		local v6
		if p5 == nil then
			v6 = false
		else
			v6 = not p5:IsA("Player")
		end
		return v6
	end,
	["BotKey"] = function(p7) -- name: BotKey
		return -(p7 + 1000)
	end,
	["Key"] = function(p8) -- name: Key
		if p8:IsA("Player") then
			return p8.UserId
		else
			return p8:GetAttribute("UserId")
		end
	end,
	["FromKey"] = function(p9) -- name: FromKey
		-- upvalues: (copy) v_u_1, (copy) v_u_2
		local v10 = tonumber(p9)
		if v10 == nil or v10 == 0 then
			return nil
		end
		if v10 > -1000 then
			return v_u_1:GetPlayerByUserId(v10)
		end
		local v11 = v_u_2:FindFirstChild("Combatants")
		if not v11 then
			return nil
		end
		local v12 = -v10 - 1000
		return v11:FindFirstChild((tostring(v12)))
	end,
	["Name"] = function(p13) -- name: Name
		if p13:IsA("Player") then
			return p13.Name
		else
			local v14 = p13:GetAttribute("DisplayName")
			if type(v14) == "string" then
				return v14
			else
				return p13.Name
			end
		end
	end,
	["DisplayName"] = function(p15) -- name: DisplayName
		-- upvalues: (copy) v_u_32
		if p15:IsA("Player") then
			return p15.DisplayName
		else
			return v_u_32.Name(p15)
		end
	end,
	["AvatarUserId"] = function(p16) -- name: AvatarUserId
		if p16:IsA("Player") then
			return p16.UserId
		end
		local v17 = p16:GetAttribute("AvatarUserId")
		return type(v17) ~= "number" and 1 or v17
	end,
	["HeadshotImage"] = function(p18, p19) -- name: HeadshotImage
		-- upvalues: (copy) v_u_32
		local v20 = p19 or 150
		return ("rbxthumb://type=AvatarHeadShot&id=%*&w=%*&h=%*"):format(v_u_32.AvatarUserId(p18), v20, v20)
	end,
	["IsAlive"] = function(p21) -- name: IsAlive
		-- upvalues: (copy) v_u_4
		if p21 == nil then
			return false
		end
		if p21:IsA("Player") then
			return v_u_4.isAlivePlayer(p21)
		end
		local v22 = p21:GetAttribute("Health")
		local v23
		if p21:GetAttribute("Dead") == true then
			v23 = false
		else
			v23 = type(v22) ~= "number" and true or v22 > 0
		end
		return v23
	end,
	["FromName"] = function(p24) -- name: FromName
		-- upvalues: (copy) v_u_1, (copy) v_u_2
		local v25 = v_u_1:FindFirstChild(p24)
		if v25 and v25:IsA("Player") then
			return v25
		end
		local v26 = v_u_2:FindFirstChild("Combatants")
		if v26 then
			for _, v27 in v26:GetChildren() do
				if v27:GetAttribute("DisplayName") ~= p24 then
					continue
				end
				return v27
			end
		end
		return nil
	end,
	["GetAll"] = function() -- name: GetAll
		-- upvalues: (copy) v_u_1, (copy) v_u_2
		local v28 = {}
		for _, v29 in v_u_1:GetPlayers() do
			v28[#v28 + 1] = v29
		end
		local v30 = v_u_2:FindFirstChild("Combatants")
		if v30 then
			for _, v31 in v30:GetChildren() do
				if not v31:IsA("Folder") then
					continue
				end
				v28[#v28 + 1] = v31
			end
		end
		return v28
	end
}
local v_u_33 = {}
local v_u_34 = nil
local v_u_35 = true
local v_u_36 = {}
local function v_u_37() -- name: markIndexDirty
	-- upvalues: (ref) v_u_35
	v_u_35 = true
end
local function v_u_42(p38) -- name: shellIndex
	-- upvalues: (ref) v_u_34, (ref) v_u_36, (copy) v_u_37, (ref) v_u_35, (copy) v_u_33
	if p38 ~= v_u_34 then
		for _, v39 in v_u_36 do
			v39:Disconnect()
		end
		v_u_36 = { p38.ChildAdded:Connect(v_u_37), p38.ChildRemoved:Connect(v_u_37) }
		v_u_34 = p38
		v_u_35 = true
	end
	if v_u_35 then
		v_u_35 = false
		table.clear(v_u_33)
		for _, v40 in p38:GetChildren() do
			if not v40:IsA("Model") or v40:GetAttribute("Bot") ~= true then
				continue
			end
			local v41 = v40:GetAttribute("CombatantId")
			if v41 == nil or v_u_33[v41] ~= nil then
				continue
			end
			v_u_33[v41] = v40
		end
	end
	return v_u_33
end
function v_u_32.Character(p43) -- name: Character
	-- upvalues: (copy) v_u_3, (copy) v_u_42, (ref) v_u_35
	if p43 == nil then
		return nil
	end
	if p43:IsA("Player") then
		return p43.Character
	end
	local v44 = p43:GetAttribute("CombatantId")
	local v45 = v_u_3:FindFirstChild("Characters")
	if not v45 or v44 == nil then
		return nil
	end
	local v46 = v_u_42(v45)[v44]
	if v46 ~= nil and v46.Parent ~= v45 then
		v_u_35 = true
		v46 = v_u_42(v45)[v44]
	end
	return v46
end
function v_u_32.Observe(p_u_47, p_u_48) -- name: Observe
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v_u_49 = {}
	local v_u_50 = {}
	local function v_u_52(p51) -- name: add
		-- upvalues: (copy) p_u_47
		if p51:IsA("Player") or p51:IsA("Folder") then
			task.spawn(p_u_47, p51)
		end
	end
	local function v_u_54(p53) -- name: remove
		-- upvalues: (copy) p_u_48
		if p_u_48 and (p53:IsA("Player") or p53:IsA("Folder")) then
			task.spawn(p_u_48, p53)
		end
	end
	local function v_u_58(p55) -- name: bindFolder
		-- upvalues: (copy) v_u_50, (copy) v_u_52, (copy) v_u_54, (copy) p_u_47
		for _, v56 in v_u_50 do
			v56:Disconnect()
		end
		table.clear(v_u_50)
		v_u_50[#v_u_50 + 1] = p55.ChildAdded:Connect(v_u_52)
		v_u_50[#v_u_50 + 1] = p55.ChildRemoved:Connect(v_u_54)
		for _, v57 in p55:GetChildren() do
			if not (v57:IsA("Player") or v57:IsA("Folder")) then
				continue
			end
			task.spawn(p_u_47, v57)
		end
	end
	v_u_49[#v_u_49 + 1] = v_u_1.PlayerAdded:Connect(v_u_52)
	v_u_49[#v_u_49 + 1] = v_u_1.PlayerRemoving:Connect(v_u_54)
	v_u_49[#v_u_49 + 1] = v_u_2.ChildAdded:Connect(function(p59)
		-- upvalues: (copy) v_u_58
		if p59.Name == "Combatants" then
			v_u_58(p59)
		end
	end)
	for _, v60 in v_u_1:GetPlayers() do
		if not (v60:IsA("Player") or v60:IsA("Folder")) then
			continue
		end
		task.spawn(p_u_47, v60)
	end
	local v61 = v_u_2:FindFirstChild("Combatants")
	if v61 then
		v_u_58(v61)
	end
	return function()
		-- upvalues: (copy) v_u_49, (copy) v_u_50
		for _, v62 in v_u_49 do
			v62:Disconnect()
		end
		for _, v63 in v_u_50 do
			v63:Disconnect()
		end
	end
end
return table.freeze(v_u_32)
-- NIGHT Analyzer | ReplicatedStorage.Components.Common.FarThrottle
-- ModuleScript | 32 linhas | 618 bytes | hash 0b898061

local v_u_1 = {}
v_u_1.__index = v_u_1
function v_u_1.new() -- name: new
	-- upvalues: (copy) v_u_1
	local v2 = v_u_1
	return setmetatable({
		["Frame"] = 0,
		["CameraPosition"] = nil
	}, v2)
end
function v_u_1.Begin(p3) -- name: Begin
	p3.Frame = p3.Frame + 1
	local v4 = workspace.CurrentCamera
	local v5
	if v4 then
		v5 = v4.CFrame.Position
	else
		v5 = nil
	end
	p3.CameraPosition = v5
end
function v_u_1.Skips(p6, p7, p8) -- name: Skips
	local v9 = p6.CameraPosition
	local v10
	if v9 == nil or (p6.Frame + p8) % 4 == 0 then
		v10 = false
	else
		v10 = (p7 - v9).Magnitude > 45
	end
	return v10
end
return v_u_1
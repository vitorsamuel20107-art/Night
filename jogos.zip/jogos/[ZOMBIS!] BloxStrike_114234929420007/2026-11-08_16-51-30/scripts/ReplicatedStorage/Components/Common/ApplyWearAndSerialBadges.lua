-- NIGHT Analyzer | ReplicatedStorage.Components.Common.ApplyWearAndSerialBadges
-- ModuleScript | 83 linhas | 2057 bytes | hash f34377d8

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Database.Components.Libraries.Skins)
local v_u_3 = require(script.Parent.CommaNumber)
local v_u_4 = {
	["Case"] = true,
	["Package"] = true
}
local function v_u_9(p5, p6) -- name: GetWearAbbreviation
	-- upvalues: (copy) v_u_2
	if typeof(p5) ~= "number" then
		return nil
	end
	if typeof(p6) == "table" then
		local v7 = p6.floatRange
		if typeof(v7) == "table" then
			local _, v8 = v_u_2.GetWearNameForFloat(p6, p5)
			if typeof(v8) == "string" then
				return v_u_2.GetAbbreviatedWearName(v8)
			else
				return nil
			end
		end
	end
	return nil
end
return function(p10, p11, p12)
	-- upvalues: (copy) v_u_9, (copy) v_u_4, (copy) v_u_3
	local v13 = p10:FindFirstChild("ItemContent")
	if v13 then
		local v14 = v13:FindFirstChild("Rarity")
		if v14 then
			local v15 = v_u_9
			local v16 = p11.Float
			local v17 = v15(tonumber(v16), p12)
			local v18 = v14:FindFirstChild("Condition")
			if v18 and v18:IsA("ImageLabel") then
				for _, v19 in v18:GetChildren() do
					if not v19:IsA("UIGradient") then
						continue
					end
					v19.Enabled = false
				end
				v18.Visible = v17 ~= nil
				if v17 then
					local v20 = v18:FindFirstChild("WearAbbreviation")
					if v20 and v20:IsA("TextLabel") then
						v20.Text = v17
					end
					local v21 = v18:FindFirstChild(v17 .. "Gradient")
					if v21 and v21:IsA("UIGradient") then
						v21.Enabled = true
					end
				end
			end
			local v22 = v14:FindFirstChild("Serial")
			if v22 and v22:IsA("ImageLabel") then
				local v23
				if v_u_4[p11.Type] then
					v23 = nil
				else
					local v24 = p11.Serial
					v23 = tonumber(v24)
				end
				local v25
				if v23 == nil then
					v25 = false
				else
					v25 = v23 > 0
				end
				v22.Visible = v25
				local v26 = v22:FindFirstChild("SerialText")
				if v26 and v26:IsA("TextLabel") then
					if v23 then
						v26.Text = ("#%*"):format((v_u_3(v23)))
					end
					v26.Size = UDim2.fromScale(v17 and 0.557 or 1, v26.Size.Y.Scale)
				end
			end
		end
	else
		return
	end
end
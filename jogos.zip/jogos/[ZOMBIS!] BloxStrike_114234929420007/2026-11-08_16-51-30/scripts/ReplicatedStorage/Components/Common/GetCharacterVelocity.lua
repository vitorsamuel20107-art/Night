-- NIGHT Analyzer | ReplicatedStorage.Components.Common.GetCharacterVelocity
-- ModuleScript | 12 linhas | 305 bytes | hash d513c945

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.MovementV2.RuntimeKinematics)
return function(p3) -- name: GetCharacterVelocity
	-- upvalues: (copy) v_u_2
	local v4
	if p3 then
		v4 = p3:FindFirstChild("HumanoidRootPart")
	else
		v4 = p3
	end
	return v_u_2.getVelocity(p3, v4)
end
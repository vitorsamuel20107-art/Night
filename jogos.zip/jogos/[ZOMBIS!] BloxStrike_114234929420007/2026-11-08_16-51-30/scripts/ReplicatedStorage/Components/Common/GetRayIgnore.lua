-- NIGHT Analyzer | ReplicatedStorage.Components.Common.GetRayIgnore
-- ModuleScript | 35 linhas | 936 bytes | hash f1571a1e

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = workspace.CurrentCamera
local v_u_3 = require(v1.Components.Common.CharacterResolver)
local v_u_4 = workspace:WaitForChild("Debris")
local v_u_5 = { "Cameras", "Barriers", "Ambience" }
local v_u_6 = { "Spawns", "Sites" }
return function()
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_5, (copy) v_u_6, (copy) v_u_3
	local v7 = { v_u_4, v_u_2 }
	local v8 = workspace:FindFirstChild("Map")
	if v8 then
		for _, v9 in v_u_5 do
			local v10 = v8:FindFirstChild(v9)
			if not v10 then
				continue
			end
			table.insert(v7, v10)
		end
		local v11 = v8:FindFirstChild("Zones")
		if v11 then
			for _, v12 in v_u_6 do
				local v13 = v11:FindFirstChild(v12)
				if not v13 then
					continue
				end
				table.insert(v7, v13)
			end
		end
	end
	local v14 = v_u_3.getLocalCharacter()
	if v14 and v14:IsDescendantOf(workspace) then
		table.insert(v7, v14)
	end
	return v7
end
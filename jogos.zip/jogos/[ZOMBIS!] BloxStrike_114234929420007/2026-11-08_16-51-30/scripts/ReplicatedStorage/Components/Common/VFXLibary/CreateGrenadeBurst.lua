-- NIGHT Analyzer | ReplicatedStorage.Components.Common.VFXLibary.CreateGrenadeBurst
-- ModuleScript | 107 linhas | 2773 bytes | hash 92c48bcd

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Classes.Sound)
local v_u_3 = require(v1.Shared.ObjectPool)
local v_u_4 = workspace:WaitForChild("Debris")
local v_u_5 = CFrame.new(0, -10000, 0)
local v_u_6 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_7 = {}
local v_u_8 = {}
local v_u_9 = {}
local function v_u_14(p10) -- name: prepareBurst
	-- upvalues: (copy) v_u_5, (copy) v_u_6
	p10.Anchored = true
	p10.CanCollide = false
	p10.CanQuery = false
	p10.CanTouch = false
	p10.CFrame = v_u_5
	local v11 = {}
	for _, v12 in p10:GetDescendants() do
		if not v12:IsA("ParticleEmitter") then
			continue
		end
		v11[#v11 + 1] = {
			["Emitter"] = v12,
			["Delay"] = v12:GetAttribute("EmitDelay") or 0,
			["Count"] = v12:GetAttribute("EmitCount") or 1
		}
	end
	local v13 = Instance.new("Sound")
	v13.Name = "Explode"
	v13.Parent = p10
	v_u_6[p10] = {
		["Emitters"] = v11,
		["Bang"] = v13
	}
end
local function v_u_16(p15) -- name: hideBurst
	-- upvalues: (copy) v_u_5
	p15.CFrame = v_u_5
end
local function v_u_21(p17) -- name: getHold
	local v18 = 0
	for _, v19 in p17:GetDescendants() do
		if not v19:IsA("ParticleEmitter") then
			continue
		end
		local v20 = (v19:GetAttribute("EmitDelay") or 0) + v19.Lifetime.Max
		v18 = math.max(v18, v20)
	end
	return v18 + 0.25
end
local function v_u_25(p22) -- name: getPool
	-- upvalues: (copy) v_u_7, (copy) v_u_3, (copy) v_u_14, (copy) v_u_16, (copy) v_u_4, (copy) v_u_8, (copy) v_u_21
	local v23 = v_u_7[p22]
	if v23 then
		return v23
	end
	local v24 = v_u_3.new(p22, {
		["MaxRetained"] = 6,
		["Prepare"] = nil,
		["Reset"] = nil,
		["InPlace"] = true,
		["StorageParent"] = nil,
		["StorageName"] = nil,
		["Prepare"] = v_u_14,
		["Reset"] = v_u_16,
		["StorageParent"] = v_u_4,
		["StorageName"] = ("GrenadeBursts_%*"):format(p22.Name)
	})
	v_u_7[p22] = v24
	v_u_8[p22] = v_u_21(p22)
	return v24
end
return function(p26, p27, p28)
	-- upvalues: (copy) v_u_25, (copy) v_u_6, (copy) v_u_9, (copy) v_u_2, (copy) v_u_8
	local v_u_29 = v_u_25(p26)
	local v_u_30, v_u_31 = v_u_29:Acquire()
	local v32 = v_u_6[v_u_30]
	v_u_30.CFrame = CFrame.new(p27)
	for _, v33 in v32.Emitters do
		local v_u_34 = v33.Emitter
		local v_u_35 = v33.Count
		if v33.Delay <= 0 then
			v_u_34:Emit(v_u_35)
		else
			task.delay(v33.Delay, function()
				-- upvalues: (copy) v_u_29, (copy) v_u_30, (copy) v_u_31, (copy) v_u_34, (copy) v_u_35
				if v_u_29:IsAcquired(v_u_30, v_u_31) then
					v_u_34:Emit(v_u_35)
				end
			end)
		end
	end
	if p28 then
		local v36 = v_u_9[p28]
		if not v36 then
			v36 = v_u_2.new(p28)
			v_u_9[p28] = v36
		end
		v36:playOn(v32.Bang, "Explode")
	end
	task.delay(v_u_8[p26], function()
		-- upvalues: (copy) v_u_29, (copy) v_u_30, (copy) v_u_31
		v_u_29:Release(v_u_30, v_u_31)
	end)
end
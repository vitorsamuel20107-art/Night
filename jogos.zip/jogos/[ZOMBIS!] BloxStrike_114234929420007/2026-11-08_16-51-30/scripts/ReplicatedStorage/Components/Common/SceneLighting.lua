-- NIGHT Analyzer | ReplicatedStorage.Components.Common.SceneLighting
-- ModuleScript | 104 linhas | 2488 bytes | hash aaf13831

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Lighting")
local v_u_3 = game:GetService("Players")
local v_u_4 = require(v1.Controllers.DataController)
local v_u_5 = v1.Database.Custom.GameStats.Maps
local v_u_6 = {
	"Ambient",
	"Brightness",
	"ColorShift_Bottom",
	"ColorShift_Top",
	"EnvironmentDiffuseScale",
	"EnvironmentSpecularScale",
	"GlobalShadows",
	"OutdoorAmbient",
	"ShadowSoftness",
	"ClockTime",
	"GeographicLatitude",
	"ExposureCompensation"
}
local v_u_7 = {}
local v_u_8 = {}
for _, v9 in v_u_6 do
	v_u_7[v9] = v_u_2[v9]
end
local function v_u_13(p10) -- name: replaceAssets
	-- upvalues: (copy) v_u_2
	for _, v11 in v_u_2:GetChildren() do
		if v11.Name == "Menu" then
			continue
		end
		v11:Destroy()
	end
	if p10 then
		for _, v12 in p10:GetChildren() do
			v12:Clone().Parent = v_u_2
		end
	end
end
function v_u_8.ApplyGlobalShadows(p14) -- name: ApplyGlobalShadows
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_2
	if v_u_4.Get(v_u_3.LocalPlayer, "Settings.Video.Presets.Global Shadows") == false then
		v_u_2.GlobalShadows = false
	elseif p14 ~= nil then
		v_u_2.GlobalShadows = p14
	end
end
function v_u_8.RestoreMap(p15, p16) -- name: RestoreMap
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_2, (copy) v_u_13, (copy) v_u_8
	if p15 == nil then
		p15 = workspace:GetAttribute("Map")
		if typeof(p15) ~= "string" then
			local v17 = workspace:FindFirstChild("Map")
			if v17 then
				p15 = v17:GetAttribute("MapName")
			else
				p15 = nil
			end
		end
	end
	if typeof(p15) ~= "string" then
		return p16
	end
	local v18 = v_u_5:FindFirstChild(p15)
	if not (v18 and v18:IsA("ModuleScript")) then
		return p16
	end
	local v19 = require(v18).Lighting
	if not v19 then
		return p16
	end
	local v20 = v19.Properties
	if v20 then
		p16 = v20.GlobalShadows
		for _, v21 in v_u_6 do
			v_u_2[v21] = v20[v21]
		end
	end
	v_u_13(v19.Assets)
	v_u_8.ApplyGlobalShadows(p16)
	return p16
end
function v_u_8.ApplyScene(p22, p23) -- name: ApplyScene
	-- upvalues: (copy) v_u_5, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_13, (copy) v_u_8
	local v24 = v_u_5:FindFirstChild(p22)
	local v25
	if v24 and v24:IsA("ModuleScript") then
		v25 = require(v24).Lighting
	else
		v25 = nil
	end
	local v26
	if v25 and v25.Properties then
		v26 = v25.Properties
	else
		v26 = v_u_7
	end
	for _, v27 in v_u_6 do
		v_u_2[v27] = v26[v27]
	end
	v_u_13(p23)
	v_u_8.ApplyGlobalShadows(v26.GlobalShadows)
	return v26.GlobalShadows
end
return v_u_8
-- NIGHT Analyzer | ReplicatedStorage.Components.Common.VFXLibary.PlayZeusDeath
-- ModuleScript | 73 linhas | 1886 bytes | hash b7ff14c4

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("CollectionService")
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("Debris")
local v_u_5 = v1:WaitForChild("Assets"):WaitForChild("Other")
local function v_u_13(p6) -- name: resolveVictimRagdoll
	-- upvalues: (copy) v_u_3, (copy) v_u_2
	local v7 = v_u_3:GetPlayerByUserId(p6)
	if not v7 then
		return nil
	end
	local v8 = (-1 / 0)
	local v9 = nil
	for _, v10 in v_u_2:GetTagged("Ragdoll") do
		if not v10:IsA("Model") or (v10.Name ~= v7.Name or not v10:IsDescendantOf(workspace)) then
			continue
		end
		local v11 = v10:GetAttribute("RagdollCreatedAt")
		local v12 = typeof(v11) ~= "number" and 0 or v11
		if v8 >= v12 then
			continue
		end
		v9 = v10
		v8 = v12
	end
	return v9
end
return function(p14)
	-- upvalues: (copy) v_u_5, (copy) v_u_13, (copy) v_u_4
	local v15 = tonumber(p14)
	if v15 then
		local v16 = v_u_5:FindFirstChild("ZeusDeath")
		if v16 and v16:IsA("ParticleEmitter") then
			local v17 = v_u_13(v15)
			if not v17 then
				local v18 = os.clock() + 0.5
				repeat
					task.wait(0.05)
					v17 = v_u_13(v15)
				until v17 or v18 <= os.clock()
			end
			if v17 then
				local v19 = v17:FindFirstChild("HumanoidRootPart")
				if v19 and v19:IsA("BasePart") then
					local v_u_20 = v16:Clone()
					v_u_20.Enabled = false
					v_u_20.Parent = v19
					local v21 = v_u_20:GetAttribute("EmitCount")
					if typeof(v21) == "number" and v21 > 0 then
						v_u_20:Emit(v21)
					else
						v_u_20.Enabled = true
						task.delay(0.15, function()
							-- upvalues: (copy) v_u_20
							if v_u_20 and v_u_20.Parent then
								v_u_20.Enabled = false
							end
						end)
					end
					local v22 = v_u_4
					local v23 = v_u_20.Lifetime.Max
					v22:AddItem(v_u_20, math.max(v23, 1) + 1)
				end
			else
				return
			end
		else
			return
		end
	else
		return
	end
end
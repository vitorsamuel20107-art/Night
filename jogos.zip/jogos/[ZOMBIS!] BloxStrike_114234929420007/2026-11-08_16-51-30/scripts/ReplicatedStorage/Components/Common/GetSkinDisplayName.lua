-- NIGHT Analyzer | ReplicatedStorage.Components.Common.GetSkinDisplayName
-- ModuleScript | 153 linhas | 4249 bytes | hash 13d4529c

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Database.Components.Libraries.Skins)
local v_u_3 = {
	["Zeus x27"] = "Taser"
}
local v_u_4 = table.freeze({
	["Lebron James"] = "LeGoat",
	["Medal.tv"] = "Medal"
})
local v_u_5 = {}
for v6, v7 in v_u_3 do
	v_u_5[v7:lower()] = v6
end
local v_u_8 = {}
local function v_u_18(p9, p10, p11) -- name: replaceCaseInsensitive
	if p10 == "" then
		return p9
	end
	local v12 = p9:lower()
	local v13 = 1
	local v14 = {}
	while true do
		local v15, v16 = v12:find(p10, v13, true)
		if not (v15 and v16) then
			break
		end
		local v17 = v15 - 1
		table.insert(v14, p9:sub(v13, v17))
		table.insert(v14, p11)
		v13 = v16 + 1
	end
	table.insert(v14, p9:sub(v13))
	return table.concat(v14)
end
function v_u_8.GetNameTag(p19) -- name: GetNameTag
	if typeof(p19) == "string" and p19 ~= "" then
		return p19
	else
		return nil
	end
end
function v_u_8.FormatNameLabelText(p20, p21) -- name: FormatNameLabelText
	-- upvalues: (copy) v_u_8
	if v_u_8.GetNameTag(p21) then
		return ("<i>%*</i>"):format((p20:gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;")))
	else
		return p20
	end
end
function v_u_8.ApplyNameLabel(p22, p23, p24) -- name: ApplyNameLabel
	-- upvalues: (copy) v_u_8
	if p22 and (p22:IsA("TextLabel") or (p22:IsA("TextButton") or p22:IsA("TextBox"))) then
		local v25 = v_u_8.GetNameTag(p24) ~= nil
		if p22:GetAttribute("NameTagRichTextDefault") == nil then
			p22:SetAttribute("NameTagRichTextDefault", p22.RichText)
		end
		if p22:GetAttribute("NameTagFontStyleDefault") == nil then
			p22:SetAttribute("NameTagFontStyleDefault", p22.FontFace.Style.Name)
		end
		local v26 = p22:GetAttribute("NameTagFontStyleDefault")
		local v27 = p22.FontFace
		local v28
		if v25 or v26 == "Italic" then
			v28 = Enum.FontStyle.Italic
		else
			v28 = Enum.FontStyle.Normal
		end
		p22.FontFace = Font.new(v27.Family, v27.Weight, v28)
		p22.RichText = v25 or p22:GetAttribute("NameTagRichTextDefault") == true
		p22.Text = v_u_8.FormatNameLabelText(p23, p24)
	end
end
function v_u_8.GetWeaponDisplayName(p29, p30) -- name: GetWeaponDisplayName
	-- upvalues: (copy) v_u_8, (copy) v_u_3, (copy) v_u_18
	local v31 = v_u_8.GetNameTag(p30)
	if v31 then
		return v31
	end
	if not p29 then
		return ""
	end
	local v32 = v_u_3[p29]
	if v32 then
		return v32
	end
	for v33, v34 in v_u_3 do
		p29 = v_u_18(p29, v33:lower(), v34)
	end
	return p29
end
function v_u_8.GetSkinDisplayName(p35, p36) -- name: GetSkinDisplayName
	-- upvalues: (copy) v_u_4
	if not p35 then
		return ""
	end
	if not p35:find("PATTERN") then
		return v_u_4[p35] or p35
	end
	local v37, v38 = table.unpack(p35:split("_PATTERN_"))
	if p36 then
		v37 = ("%* \226\128\162 Pattern %*"):format(v37, v38) or v37
	end
	return v37
end
function v_u_8.GetFullItemDisplayName(p39, p40, p41, p42, p43) -- name: GetFullItemDisplayName
	-- upvalues: (copy) v_u_2, (copy) v_u_8
	local v44 = v_u_2.GetSkinInformation(p39, p40)
	if not v44 then
		return ""
	end
	local v45 = p42 == nil and true or p42
	local v46 = v_u_8.GetWeaponDisplayName(v44.paintId, p43)
	if v46:find("PATTERN") then
		local v47, v48 = table.unpack(v46:split("_PATTERN_"))
		if v45 then
			v47 = ("%* \226\128\162 Pattern %*"):format(v47, v48) or v47
		end
		return v47
	end
	local v49 = ("%* | %*"):format(v46:split(" | ")[1], (v_u_8.GetSkinDisplayName(p40, v45)))
	local v50 = p41 and "KillTrak\226\132\162 " or ""
	if v44.type == "Melee" or v44.type == "Glove" then
		v50 = v50 .. "\226\152\133 "
	end
	return ("%*%*"):format(v50, v49)
end
function v_u_8.GetInternalSearchQuery(p51) -- name: GetInternalSearchQuery
	-- upvalues: (copy) v_u_5, (copy) v_u_18
	if not p51 then
		return ""
	end
	for v52, v53 in v_u_5 do
		p51 = v_u_18(p51, v52, v53)
	end
	return p51
end
function v_u_8.GetSearchIdentity(p54, p55) -- name: GetSearchIdentity
	-- upvalues: (copy) v_u_8
	local v56 = p54 or ""
	local v57 = v_u_8.GetWeaponDisplayName(v56)
	local v58 = v_u_8.GetSkinDisplayName(p55 or "", true)
	if v57 == v56 then
		return ("%* | %*"):format(v56, v58)
	else
		return ("%* | %* %*"):format(v57, v58, v56)
	end
end
return setmetatable(v_u_8, {
	["__call"] = function(_, p59, p60) -- name: __call
		-- upvalues: (copy) v_u_8
		return v_u_8.GetSkinDisplayName(p59, p60)
	end
})
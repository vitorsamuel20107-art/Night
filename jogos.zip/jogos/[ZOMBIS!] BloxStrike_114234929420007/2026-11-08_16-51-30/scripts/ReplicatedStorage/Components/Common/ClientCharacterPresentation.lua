-- NIGHT Analyzer | ReplicatedStorage.Components.Common.ClientCharacterPresentation
-- ModuleScript | 442 linhas | 12960 bytes | hash 56dc1de1

local v_u_1 = game:GetService("HttpService")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(v_u_3.Database.Components.Common.AttachGlovesToCharacter)
local v_u_6 = require(v_u_3.Database.Components.Libraries.Skins)
local v_u_7 = require(v_u_3.Components.Common.CharacterGeneration)
local v_u_8 = require(v_u_3.Components.Common.CharacterPresentationDescriptor)
local v_u_9 = require(v_u_3.Components.Common.CharacterResolver)
local v_u_10 = {}
local v_u_11 = v_u_8.Attributes
local v_u_12 = v_u_3:WaitForChild("Assets"):WaitForChild("Characters")
local v_u_13 = {}
local v_u_14 = {}
local v_u_15 = nil
local v_u_16 = {}
local v_u_17 = {}
local v_u_18 = {}
local v_u_19 = false
local v_u_20 = 0
local function v_u_35(p_u_21, p22) -- name: attachGloves
	-- upvalues: (copy) v_u_1, (copy) v_u_6, (copy) v_u_5
	if typeof(p22) == "string" and p22 ~= "" then
		local v23 = v_u_1.JSONDecode
		local v24 = v_u_1
		local v25, v26 = pcall(v23, v24, p22)
		if v25 and typeof(v26) == "table" then
			local v27 = v26.Name
			local v28 = v26.Skin
			local v29 = v26.Float
			if typeof(v27) == "string" and (typeof(v28) == "string" and typeof(v29) == "number") then
				local v_u_30 = v_u_6.GetCharacterGloves(v27, v28, v29)
				local v_u_31 = p_u_21:FindFirstChild("CharacterArmor")
				if v_u_30 ~= nil and v_u_31 ~= nil then
					local function v32()
						-- upvalues: (ref) v_u_5, (copy) v_u_30, (copy) p_u_21, (copy) v_u_31
						v_u_5(v_u_30:GetChildren(), p_u_21, v_u_31, {
							["collisionGroup"] = "Debris"
						})
					end
					local v33, v34 = pcall(v32)
					if not v33 then
						warn((("[CharacterPresentation] Failed to attach gloves to %*: %*"):format(p_u_21.Name, v34)))
					end
				end
			else
				return
			end
		else
			return
		end
	else
		return
	end
end
function v_u_10.GetCulledFolder() -- name: GetCulledFolder
	-- upvalues: (ref) v_u_15, (copy) v_u_3
	local v36 = v_u_15
	if v36 == nil or v36.Parent ~= v_u_3 then
		v36 = Instance.new("Folder")
		v36.Name = "_PVS_CulledCharacters"
		v36.Archivable = false
		v36.Parent = v_u_3
		v_u_15 = v36
	end
	return v36
end
function v_u_10.PrepareRuntimeRig(p37) -- name: PrepareRuntimeRig
	-- upvalues: (copy) v_u_9
	for _, v38 in p37:GetChildren() do
		if not v38:IsA("Humanoid") then
			continue
		end
		v38:Destroy()
	end
	if v_u_9.getCameraPart(p37) == nil then
		v_u_9.createCameraPart(p37)
	end
	v_u_9.getOrCreateAnimator(p37)
	for _, v39 in { "WeaponModel", "WeaponAttachments" } do
		local v40 = p37:FindFirstChild(v39)
		if v40 ~= nil then
			v40:Destroy()
		end
		local v41 = Instance.new("Folder")
		v41.Name = v39
		v41.Parent = p37
	end
	for _, v42 in p37:GetDescendants() do
		if not v42:IsA("BasePart") then
			continue
		end
		v42.CanCollide = false
		v42.CanTouch = false
		if v42.Name ~= "HumanoidRootPart" then
			continue
		end
		v42.Anchored = true
		v42.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
		v42.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
	end
end
local function v_u_49(p43) -- name: getRigKey
	-- upvalues: (copy) v_u_11
	local v44 = p43:GetAttribute(v_u_11.CharacterName)
	if typeof(v44) ~= "string" or v44 == "" then
		return nil
	end
	local v45 = p43:GetAttribute(v_u_11.BodyColor)
	local v46 = table.concat
	local v47 = {}
	local v48 = v_u_11.EquippedGloves
	__set_list(v47, 1, {v44, tostring(p43:GetAttribute(v48)), typeof(v45) ~= "Color3" and "" or v45:ToHex()})
	return v46(v47, "|")
end
local function v_u_57(p50) -- name: buildRig
	-- upvalues: (copy) v_u_11, (copy) v_u_12, (copy) v_u_10, (copy) v_u_35
	local v51 = p50:GetAttribute(v_u_11.CharacterName)
	if typeof(v51) ~= "string" or v51 == "" then
		return nil
	end
	local v52 = v_u_12:FindFirstChild(v51)
	if v52 == nil or not v52:IsA("Model") then
		warn((("[CharacterPresentation] Missing character template %*"):format((tostring(v51)))))
		return nil
	end
	local v53 = v52:Clone()
	v53.Archivable = true
	v53:SetAttribute("CharacterName", v51)
	v_u_10.PrepareRuntimeRig(v53)
	local v54 = p50:GetAttribute(v_u_11.EquippedGloves)
	if typeof(v54) == "string" then
		v53:SetAttribute("EquippedGloves", v54)
		v_u_35(v53, v54)
	end
	local v55 = p50:GetAttribute(v_u_11.BodyColor)
	if typeof(v55) ~= "Color3" then
		return v53
	end
	local v56 = v53:FindFirstChild("Body Colors")
	if v56 ~= nil then
		if not v56:IsA("BodyColors") then
			return v53
		end
		v56.HeadColor3 = v55
		v56.LeftArmColor3 = v55
		v56.RightArmColor3 = v55
		v56.LeftLegColor3 = v55
		v56.RightLegColor3 = v55
		v56.TorsoColor3 = v55
	end
	return v53
end
local function v_u_64() -- name: runSpareWorker
	-- upvalues: (copy) v_u_17, (ref) v_u_20, (copy) v_u_18, (copy) v_u_2, (copy) v_u_49, (copy) v_u_16, (copy) v_u_57, (ref) v_u_19
	while #v_u_17 > 0 do
		local v58 = os.clock()
		if v58 - v_u_20 < 1 then
			task.wait(1 - (v58 - v_u_20))
		else
			local v59 = table.remove(v_u_17, 1)
			v_u_18[v59] = nil
			local v60
			if v59.Parent == v_u_2 then
				v60 = v_u_49(v59)
			else
				v60 = nil
			end
			local v61 = v_u_16[v59]
			if v60 == nil or v61 ~= nil and v61.Key == v60 then
				continue
			end
			local v62 = v_u_16[v59]
			if v62 ~= nil then
				v_u_16[v59] = nil
				v62.Rig:Destroy()
			end
			local v63 = v_u_57(v59)
			if v63 ~= nil then
				v_u_16[v59] = {
					["Key"] = v60,
					["Rig"] = v63
				}
			end
			task.wait(0.1)
		end
	end
	v_u_19 = false
end
function v_u_10.IsOwned(p65) -- name: IsOwned
	-- upvalues: (copy) v_u_8
	local v66
	if p65 == nil then
		v66 = false
	else
		v66 = p65:GetAttribute(v_u_8.OwnedAttribute) == true
	end
	return v66
end
function v_u_10.Release(p67, p68) -- name: Release
	-- upvalues: (copy) v_u_10, (copy) v_u_14, (copy) v_u_13
	if not p68 then
		if v_u_10.IsOwned(p67.Character) then
			p68 = p67.Character
		else
			p68 = v_u_14[p67]
		end
	end
	if v_u_10.IsOwned(p68) then
		local v69 = v_u_13[p68]
		if v69 ~= nil then
			v_u_13[p68] = nil
			v69()
		end
		if v_u_14[p67] == p68 then
			v_u_14[p67] = nil
		end
		if p67.Character == p68 then
			p67.Character = nil
		end
		p68:Destroy()
	end
end
function v_u_10.Create(p_u_70, p71) -- name: Create
	-- upvalues: (copy) v_u_2, (copy) v_u_14, (copy) v_u_10, (copy) v_u_7, (ref) v_u_20, (copy) v_u_16, (copy) v_u_49, (copy) v_u_57, (copy) v_u_18, (copy) v_u_17, (ref) v_u_19, (copy) v_u_64, (copy) v_u_8, (copy) v_u_11, (copy) v_u_13, (copy) v_u_4
	if p_u_70.Parent ~= v_u_2 or typeof(p71) ~= "number" then
		return nil
	end
	local v72 = v_u_14[p_u_70]
	if v72 ~= nil and v72.Parent == nil then
		v_u_14[p_u_70] = nil
		v72 = nil
	end
	local v73
	if v_u_10.IsOwned(p_u_70.Character) then
		v73 = p_u_70.Character
	else
		v73 = v72
	end
	if v73 ~= nil and (v_u_7.Get(v73) == p71 and v73.Parent ~= nil) then
		if p_u_70.Character ~= v73 then
			p_u_70.Character = v73
		end
		return v73
	end
	if v73 ~= nil then
		v_u_10.Release(p_u_70, v73)
	end
	if v72 ~= nil and v72 ~= v73 then
		v_u_10.Release(p_u_70, v72)
	end
	v_u_20 = os.clock()
	local v74 = v_u_16[p_u_70]
	local v75
	if v74 == nil then
		v75 = nil
	else
		v_u_16[p_u_70] = nil
		if v74.Key == v_u_49(p_u_70) then
			v75 = v74.Rig
		else
			v74.Rig:Destroy()
			v75 = nil
		end
	end
	local v_u_76 = v75 or v_u_57(p_u_70)
	if v_u_76 == nil then
		return nil
	end
	if not v_u_18[p_u_70] then
		v_u_18[p_u_70] = true
		local v77 = v_u_17
		table.insert(v77, p_u_70)
		if not v_u_19 then
			v_u_19 = true
			task.spawn(v_u_64)
		end
	end
	v_u_76.Name = p_u_70.Name
	v_u_76:SetAttribute(v_u_8.OwnedAttribute, true)
	v_u_76:SetAttribute(v_u_8.OwnerUserIdAttribute, p_u_70.UserId)
	v_u_76:SetAttribute(v_u_8.VisibleAttribute, true)
	v_u_76:SetAttribute("CharacterType", "PlayerCustomCharacter")
	v_u_7.Set(v_u_76, p71)
	local v78 = p_u_70:GetAttribute(v_u_11.Health)
	v_u_76:SetAttribute("Health", v78 == nil and 100 or v78)
	local v79 = p_u_70:GetAttribute(v_u_11.MaxHealth)
	v_u_76:SetAttribute("MaxHealth", v79 == nil and 100 or v79)
	local v80 = p_u_70:GetAttribute("Dead")
	local v81 = "Dead"
	if v80 == nil then
		v80 = false
	end
	v_u_76:SetAttribute(v81, v80)
	local v82 = p_u_70:GetAttribute("CompetitivePlayerColor")
	local v83 = "CompetitivePlayerColor"
	if v82 == nil then
		v82 = nil
	end
	v_u_76:SetAttribute(v83, v82)
	local v84 = p_u_70:GetAttribute(v_u_11.SpawnPosition)
	local v85 = p_u_70:GetAttribute(v_u_11.SpawnYaw)
	if typeof(v84) == "Vector3" then
		v_u_76:PivotTo(CFrame.new(v84) * CFrame.Angles(0, typeof(v85) ~= "number" and 0 or v85, 0))
	else
		v_u_76:PivotTo(CFrame.new(0, -1000, 0))
	end
	local v_u_86 = {}
	local v87 = v_u_11.Health
	local function v89()
		-- upvalues: (ref) v_u_11, (copy) p_u_70, (copy) v_u_76
		local v88 = p_u_70:GetAttribute(v_u_11.Health)
		v_u_76:SetAttribute("Health", v88 == nil and 0 or v88)
	end
	v_u_86[#v_u_86 + 1] = p_u_70:GetAttributeChangedSignal(v87):Connect(v89)
	local v90 = v_u_11.MaxHealth
	local function v92()
		-- upvalues: (ref) v_u_11, (copy) p_u_70, (copy) v_u_76
		local v91 = p_u_70:GetAttribute(v_u_11.MaxHealth)
		v_u_76:SetAttribute("MaxHealth", v91 == nil and 100 or v91)
	end
	v_u_86[#v_u_86 + 1] = p_u_70:GetAttributeChangedSignal(v90):Connect(v92)
	v_u_86[#v_u_86 + 1] = p_u_70:GetAttributeChangedSignal("Dead"):Connect(function()
		-- upvalues: (copy) p_u_70, (copy) v_u_76
		local v93 = p_u_70:GetAttribute("Dead")
		local v94 = v_u_76
		local v95 = "Dead"
		if v93 == nil then
			v93 = false
		end
		v94:SetAttribute(v95, v93)
	end)
	v_u_86[#v_u_86 + 1] = p_u_70:GetAttributeChangedSignal("CompetitivePlayerColor"):Connect(function()
		-- upvalues: (copy) p_u_70, (copy) v_u_76
		local v96 = p_u_70:GetAttribute("CompetitivePlayerColor")
		local v97 = v_u_76
		local v98 = "CompetitivePlayerColor"
		if v96 == nil then
			v96 = nil
		end
		v97:SetAttribute(v98, v96)
	end)
	local v99 = v_u_11.BodyColor
	local function v103()
		-- upvalues: (copy) v_u_76, (copy) p_u_70, (ref) v_u_11
		local v100 = v_u_76
		local v101 = p_u_70:GetAttribute(v_u_11.BodyColor)
		if typeof(v101) == "Color3" then
			local v102 = v100:FindFirstChild("Body Colors")
			if v102 ~= nil then
				if not v102:IsA("BodyColors") then
					return
				end
				v102.HeadColor3 = v101
				v102.LeftArmColor3 = v101
				v102.RightArmColor3 = v101
				v102.LeftLegColor3 = v101
				v102.RightLegColor3 = v101
				v102.TorsoColor3 = v101
			end
		end
	end
	v_u_86[#v_u_86 + 1] = p_u_70:GetAttributeChangedSignal(v99):Connect(v103)
	if p_u_70 ~= v_u_2.LocalPlayer then
		local v_u_104 = v_u_49(p_u_70)
		local function v107() -- name: rebuildIfDescriptorChanged
			-- upvalues: (copy) v_u_76, (copy) p_u_70, (ref) v_u_2, (ref) v_u_49, (copy) v_u_104, (ref) v_u_7, (ref) v_u_10
			if v_u_76.Parent == nil or p_u_70.Parent ~= v_u_2 then
				return
			else
				local v105 = v_u_49(p_u_70)
				if v105 == nil or v105 == v_u_104 then
					return
				else
					local v106 = v_u_7.Get(v_u_76)
					if v106 ~= nil then
						v_u_10.Release(p_u_70, v_u_76)
						v_u_10.Create(p_u_70, v106)
					end
				end
			end
		end
		local v108 = v_u_11.CharacterName
		v_u_86[#v_u_86 + 1] = p_u_70:GetAttributeChangedSignal(v108):Connect(v107)
		local v109 = v_u_11.EquippedGloves
		v_u_86[#v_u_86 + 1] = p_u_70:GetAttributeChangedSignal(v109):Connect(v107)
	end
	v_u_13[v_u_76] = function()
		-- upvalues: (copy) v_u_86
		for _, v110 in v_u_86 do
			v110:Disconnect()
		end
	end
	v_u_86[#v_u_86 + 1] = v_u_76.Destroying:Connect(function()
		-- upvalues: (copy) v_u_76, (ref) v_u_13, (ref) v_u_14, (copy) p_u_70
		local v111 = v_u_76
		local v112 = v_u_13[v111]
		if v112 ~= nil then
			v_u_13[v111] = nil
			v112()
		end
		if v_u_14[p_u_70] == v_u_76 then
			v_u_14[p_u_70] = nil
		end
	end)
	v_u_76.Parent = v_u_4:FindFirstChild("Characters") or v_u_4
	v_u_14[p_u_70] = v_u_76
	p_u_70.Character = v_u_76
	return v_u_76
end
function v_u_10.ObserveLocalPlayer() -- name: ObserveLocalPlayer
	-- upvalues: (copy) v_u_2, (copy) v_u_11, (copy) v_u_10
	local v_u_113 = v_u_2.LocalPlayer
	local function v115() -- name: refresh
		-- upvalues: (copy) v_u_113, (ref) v_u_11, (ref) v_u_10
		local v114 = v_u_113:GetAttribute(v_u_11.Generation)
		if typeof(v114) == "number" and v_u_113:GetAttribute("Dead") ~= true then
			v_u_10.Create(v_u_113, v114)
		end
	end
	local v_u_116 = { v_u_113:GetAttributeChangedSignal(v_u_11.Generation):Connect(v115), v_u_113:GetAttributeChangedSignal(v_u_11.CharacterName):Connect(v115), v_u_113:GetAttributeChangedSignal("Dead"):Connect(v115) }
	local v117 = v_u_113:GetAttribute(v_u_11.Generation)
	if typeof(v117) == "number" and v_u_113:GetAttribute("Dead") ~= true then
		v_u_10.Create(v_u_113, v117)
	end
	return function()
		-- upvalues: (copy) v_u_116, (ref) v_u_10, (copy) v_u_113
		for _, v118 in v_u_116 do
			v118:Disconnect()
		end
		v_u_10.Release(v_u_113, v_u_113.Character)
	end
end
v_u_2.PlayerRemoving:Connect(function(p119) -- name: discardSpare
	-- upvalues: (copy) v_u_16
	local v120 = v_u_16[p119]
	if v120 ~= nil then
		v_u_16[p119] = nil
		v120.Rig:Destroy()
	end
end)
return v_u_10
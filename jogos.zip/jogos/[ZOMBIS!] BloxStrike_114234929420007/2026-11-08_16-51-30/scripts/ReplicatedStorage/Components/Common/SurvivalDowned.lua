-- NIGHT Analyzer | ReplicatedStorage.Components.Common.SurvivalDowned
-- ModuleScript | 195 linhas | 5977 bytes | hash a03c2da5

local v_u_1 = game:GetService("Players")
local v_u_2 = {
	["DOWNED_ATTRIBUTE"] = "IsDowned",
	["BLEED_OUT_AT_ATTRIBUTE"] = "DownedBleedOutAt",
	["BLEED_OUT_LEFT_ATTRIBUTE"] = "DownedBleedOutLeft",
	["REVIVED_BY_ATTRIBUTE"] = "RevivedBy",
	["REVIVER_COUNT_ATTRIBUTE"] = "ReviverCount",
	["REVIVE_ENDS_AT_ATTRIBUTE"] = "ReviveEndsAt",
	["REVIVING_ATTRIBUTE"] = "IsReviving",
	["BLEED_OUT_SECONDS"] = 35,
	["REVIVE_SECONDS"] = 4,
	["REVIVE_SPEED"] = table.freeze({
		1,
		1.6,
		2,
		2.35
	}),
	["REVIVE_RADIUS"] = 7,
	["REVIVE_HEIGHT_TOLERANCE"] = 5,
	["REVIVE_SERVER_SLACK"] = 1.5,
	["LAST_STAND_SLOT"] = "Secondary",
	["LAST_STAND_LOADOUT_PATH"] = "Loadout.Pistols.Options.1",
	["DOWNED_HEALTH"] = 1,
	["REVIVE_HEALTH_FRACTION"] = 0.5,
	["EYE_DROP"] = 3.3,
	["TOUCH_USE_IMAGE"] = "rbxassetid://126360878155762",
	["POSE"] = table.freeze({
		["LowerTorso"] = CFrame.new(0, -2.0131, 0.6566, 1, 0, 0, 0, 0.1415, -0.9899, 0, 0.9899, 0.1415),
		["UpperTorso"] = CFrame.identity,
		["Head"] = CFrame.new(0, 0, 0, 1, 0, 0, 0, 0.6886, 0.7251, 0, -0.7251, 0.6886),
		["LeftUpperArm"] = CFrame.new(0, 0, 0, 0.8301, 0.5456, 0.1154, -0.5484, 0.8362, -0.0086, -0.1012, -0.0561, 0.9933),
		["LeftLowerArm"] = CFrame.identity,
		["LeftHand"] = CFrame.identity,
		["RightUpperArm"] = CFrame.new(0, 0, 0, 0.9391, 0.2583, -0.2266, -0.3346, 0.8374, -0.4321, 0.0781, 0.4816, 0.8729),
		["RightLowerArm"] = CFrame.identity,
		["RightHand"] = CFrame.identity,
		["LeftUpperLeg"] = CFrame.new(0, 0, 0, 0.9433, 0.1854, 0.2755, -0.0777, 0.9298, -0.3597, -0.3228, 0.3179, 0.8915),
		["LeftLowerLeg"] = CFrame.identity,
		["LeftFoot"] = CFrame.identity,
		["RightUpperLeg"] = CFrame.new(0, 0, 0, 0.9883, -0.1495, 0.0315, 0.1504, 0.9882, -0.0294, -0.0267, 0.0338, 0.9991),
		["RightLowerLeg"] = CFrame.new(0, 0, 0, 1, 0, 0, 0, 0.9848, -0.1736, 0, 0.1736, 0.9848),
		["RightFoot"] = CFrame.new(0, 0, 0, 1, 0, 0, 0, 0.9962, 0.0872, 0, -0.0872, 0.9962)
	}),
	["AIM_ELBOW_LIFT"] = 0.08726646259971647,
	["AIM_FOREARM_BEND"] = 0.7853981633974483,
	["AIM_PITCH_MIN"] = -0.2617993877991494,
	["AIM_PITCH_MAX"] = 0.7853981633974483
}
local v_u_3 = v_u_2.POSE.LowerTorso:ToEulerAnglesXYZ()
function v_u_2.IsDowned(p4) -- name: IsDowned
	-- upvalues: (copy) v_u_2
	local v5
	if p4 == nil then
		v5 = false
	else
		v5 = p4:GetAttribute(v_u_2.DOWNED_ATTRIBUTE) == true
	end
	return v5
end
function v_u_2.IsReviving(p6) -- name: IsReviving
	-- upvalues: (copy) v_u_2
	local v7
	if p6 == nil then
		v7 = false
	else
		local v8 = v_u_2.REVIVING_ATTRIBUTE
		v7 = typeof(p6:GetAttribute(v8)) == "number"
	end
	return v7
end
function v_u_2.AreHandsBusy(p9) -- name: AreHandsBusy
	-- upvalues: (copy) v_u_2
	return v_u_2.IsDowned(p9) or v_u_2.IsReviving(p9)
end
function v_u_2.CanUseSlot(p10, p11) -- name: CanUseSlot
	-- upvalues: (copy) v_u_2
	if v_u_2.IsReviving(p10) then
		return false
	else
		return not v_u_2.IsDowned(p10) or p11 == v_u_2.LAST_STAND_SLOT
	end
end
function v_u_2.GetReviveTarget(p12) -- name: GetReviveTarget
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v13 = v_u_2.REVIVING_ATTRIBUTE
	local v14
	if p12 then
		v14 = p12:GetAttribute(v13)
	else
		v14 = nil
	end
	if typeof(v14) == "number" then
		return v_u_1:GetPlayerByUserId(v14)
	else
		return nil
	end
end
function v_u_2.GetReviver(p15) -- name: GetReviver
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v16 = v_u_2.REVIVED_BY_ATTRIBUTE
	local v17
	if p15 then
		v17 = p15:GetAttribute(v16)
	else
		v17 = nil
	end
	if typeof(v17) == "number" then
		return v_u_1:GetPlayerByUserId(v17)
	else
		return nil
	end
end
function v_u_2.GetReviverCount(p18) -- name: GetReviverCount
	-- upvalues: (copy) v_u_2
	local v19
	if p18 then
		v19 = p18:GetAttribute(v_u_2.REVIVER_COUNT_ATTRIBUTE)
	else
		v19 = nil
	end
	return typeof(v19) ~= "number" and 0 or v19
end
function v_u_2.GetReviveSpeed(p20) -- name: GetReviveSpeed
	-- upvalues: (copy) v_u_2
	if p20 <= 0 then
		return 0
	end
	local v21 = v_u_2.REVIVE_SPEED
	local v22 = #v21
	return v21[math.min(p20, v22)]
end
function v_u_2.GetBleedOutLeft(p23) -- name: GetBleedOutLeft
	-- upvalues: (copy) v_u_2
	local v24 = p23:GetAttribute(v_u_2.BLEED_OUT_LEFT_ATTRIBUTE)
	if typeof(v24) == "number" then
		return v24
	end
	local v25 = p23:GetAttribute(v_u_2.BLEED_OUT_AT_ATTRIBUTE)
	if typeof(v25) ~= "number" then
		return 0
	end
	local v26 = v25 - workspace:GetServerTimeNow()
	return math.max(v26, 0)
end
function v_u_2.GetReviveProgress(p27) -- name: GetReviveProgress
	-- upvalues: (copy) v_u_2
	local v28 = p27:GetAttribute(v_u_2.REVIVE_ENDS_AT_ATTRIBUTE)
	if typeof(v28) ~= "number" then
		return nil
	end
	local v29 = v_u_2.GetReviveSpeed
	local v30 = v_u_2.GetReviverCount(p27)
	local v31 = v29((math.max(v30, 1)))
	local v32 = 1 - (v28 - workspace:GetServerTimeNow()) * v31 / v_u_2.REVIVE_SECONDS
	return math.clamp(v32, 0, 1)
end
function v_u_2.IsInReviveRange(p33, p34, p35) -- name: IsInReviveRange
	-- upvalues: (copy) v_u_2
	local v36 = p35 or 0
	local v37 = p33.X - p34.X
	local v38 = p33.Z - p34.Z
	local v39
	if Vector3.new(v37, 0, v38).Magnitude <= v_u_2.REVIVE_RADIUS + v36 then
		local v40 = p33.Y - p34.Y
		v39 = math.abs(v40) <= v_u_2.REVIVE_HEIGHT_TOLERANCE + v36
	else
		v39 = false
	end
	return v39
end
function v_u_2.GetAimPose(p41) -- name: GetAimPose
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v42 = v_u_2.AIM_ELBOW_LIFT
	local v43 = v_u_2.AIM_FOREARM_BEND
	local v44 = v_u_2.AIM_PITCH_MIN
	local v45 = v_u_2.AIM_PITCH_MAX
	local v46 = math.clamp(p41, v44, v45)
	return {
		["RightUpperArm"] = CFrame.Angles(1.5707963267948966 - v_u_3 + v42, 0, 0),
		["RightLowerArm"] = CFrame.Angles(v43, 0, 0),
		["RightHand"] = CFrame.Angles(v46 - v42 - v43, 0, 0)
	}
end
function v_u_2.GetPoseJoints(p47) -- name: GetPoseJoints
	-- upvalues: (copy) v_u_2
	local v48 = {}
	for _, v49 in p47:GetDescendants() do
		if not (v49:IsA("Motor6D") and (v49.Part1 and v_u_2.POSE[v49.Part1.Name])) then
			continue
		end
		table.insert(v48, v49)
	end
	return v48
end
return table.freeze(v_u_2)
-- NIGHT Analyzer | ReplicatedStorage.Components.Common.MarketplaceHover
-- ModuleScript | 685 linhas | 20282 bytes | hash 6499f8bf

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("GuiService")
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = game:GetService("Workspace")
require(v_u_1.Database.Custom.Types)
local v_u_6 = require(v_u_1.Controllers.DataController)
local v_u_7 = require(v_u_1.Database.Security.Router)
local v_u_8 = require(v_u_1.Database.Components.Libraries.Collections)
local v_u_9 = require(v_u_1.Database.Components.Libraries.Cases)
local v_u_10 = require(v_u_1.Database.Components.Libraries.Skins)
local v_u_11 = require(v_u_1.Database.Components.MarketPlacePrices)
local v_u_12 = require(v_u_1.Database.Custom.GameStats.Rarities)
local v_u_13 = require(v_u_1.Components.Common.GetWeaponProperties)
local v_u_14 = require(v_u_1.Components.Common.CommaNumber)
local v_u_15 = require(v_u_1.Components.Common.GetSkinDisplayName)
local v_u_16 = table.freeze({
	["Stock"] = 0,
	["Blue"] = 1,
	["Purple"] = 2,
	["Pink"] = 3,
	["Red"] = 4,
	["Special"] = 5,
	["Forbidden"] = 6
})
local v_u_17 = {}
local v_u_18 = nil
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = {}
local v_u_24 = nil
local v_u_25 = nil
local v_u_26 = nil
local v_u_27 = nil
local v_u_28 = nil
local v_u_29 = 0
local v_u_30 = {}
local v_u_31 = {
	["Visible"] = false
}
local v_u_32 = v3.LocalPlayer
local function v_u_36(p33) -- name: findCaseCollectionName
	-- upvalues: (ref) v_u_17
	for _, v34 in ipairs(v_u_17) do
		for _, v35 in ipairs(v34.cases or {}) do
			if v35 ~= p33 then
				continue
			end
			return v34.name
		end
	end
	return nil
end
local function v_u_63(p37) -- name: getHoverPosition
	-- upvalues: (ref) v_u_18, (copy) v_u_5, (copy) v_u_2
	local v38 = v_u_18
	local v39 = v38.Parent
	local v40 = Vector2.zero
	local v41 = v_u_5.CurrentCamera and v_u_5.CurrentCamera.ViewportSize or Vector2.new(1920, 1080)
	if v39 and v39:IsA("GuiObject") then
		v40 = v39.AbsolutePosition
		v41 = v39.AbsoluteSize
	end
	local v42 = p37.AbsolutePosition
	local v43 = p37.AbsoluteSize
	local v44 = v38.AbsoluteSize
	local v45 = v_u_2:GetGuiInset()
	local v46 = v42.X + v43.X + 8
	local v47 = v42.X - v44.X - 8
	if v46 + v44.X <= v40.X + v41.X - 8 then
		v47 = v46
	end
	local v48 = v40.X + 8
	local v49 = v40.X + v41.X - v44.X - 8
	local v50 = math.max(v48, v49)
	local v51 = v40.Y + 8
	local v52 = v45.Y + 8
	local v53 = math.max(v51, v52)
	local v54 = v40.Y + v41.Y - v44.Y - 8
	local v55 = math.max(v53, v54)
	local v56 = v42.Y + v43.Y / 2
	local v57 = v38.AnchorPoint
	local v58 = Vector2.new(math.clamp(v47, v48, v50), (math.clamp(v56, v53, v55)))
	local v59 = UDim2.fromOffset
	local v60 = v58.X - v40.X + v44.X * v57.X + 0.5
	local v61 = math.floor(v60)
	local v62 = v58.Y - v40.Y + v44.Y * v57.Y + 0.5
	return v59(v61, (math.floor(v62)))
end
local function v_u_65() -- name: clearCollectionEntries
	-- upvalues: (ref) v_u_23
	for _, v64 in ipairs(v_u_23.Collection:GetChildren()) do
		if not v64:IsA("Frame") or v64.Name == "UIListLayout" then
			continue
		end
		v64:Destroy()
	end
end
local function v_u_72(p66) -- name: getPackageDescription
	-- upvalues: (copy) v_u_15
	local v67 = "This package contains the "
	for v68, v69 in ipairs(p66.contents) do
		local v70 = v69.skin.weaponName
		if v69.skin.type == "Melee" then
			v70 = ("\226\152\133 %*"):format(v70)
		end
		local v71 = v_u_15.GetSkinDisplayName(v69.skin.skinName, true)
		if v71 ~= "" then
			v70 = ("%* | %*"):format(v70, v71)
		end
		if v68 > 1 then
			v67 = v67 .. " and "
		end
		v67 = v67 .. v70
	end
	return v67 .. "."
end
local function v_u_79(p73, p74, p75) -- name: getDescription
	-- upvalues: (copy) v_u_72, (copy) v_u_10
	if p74 then
		if p74.caseType == "Package" then
			return v_u_72(p74)
		else
			return p74.description
		end
	else
		local v76 = p73.Type
		if v76 ~= "Weapon" and (v76 ~= "Melee" and v76 ~= "Glove") and v76 ~= "Zeus x27" then
			return not p75 and "" or p75.description
		end
		local v77 = p73.Type == "Melee" and "T Knife" or (p73.Type == "Glove" and "T Glove" or p73.Name)
		local v78 = v_u_10.GetSkinInformation(v77, "Stock")
		return not v78 and "" or v78.description
	end
end
local function v_u_102(p80) -- name: resolveHoverData
	-- upvalues: (copy) v_u_9, (copy) v_u_15, (copy) v_u_36, (copy) v_u_10, (copy) v_u_11, (copy) v_u_14, (copy) v_u_79
	local v81 = nil
	local v82 = nil
	local v83 = nil
	local v84, v85, v86, v87
	if p80.Type == "Case" or (p80.Type == "Package" or (p80.Type == "Charm Capsule" or p80.Type == "Sticker Capsule")) then
		v81 = v_u_9.GetCaseByName(p80.Skin)
		if not v81 then
			warn((("Failed to find case info for %* | %*"):format(p80.Name, p80.Skin)))
			return nil
		end
		v83 = v81.caseType
		v84 = v83 == "Charm Capsule" and "Charm Pack" or v83
		v85 = v_u_15.GetSkinDisplayName(v81.name, true)
		v86 = v81.caseRarity
		if v83 == "Case" then
			v87 = v_u_36(v81.name) or nil
		else
			v87 = nil
		end
	else
		v82 = v_u_10.GetSkinInformation(p80.Name, p80.Skin)
		if not v82 then
			warn((("Failed to find skin info for %* | %*"):format(p80.Name, p80.Skin)))
			return nil
		end
		v84 = v_u_15.GetWeaponDisplayName(p80.Name, p80.NameTag)
		if p80.StatTrack then
			v84 = ("KillTrak\226\132\162 %*"):format(v84) or v84
		end
		v85 = v_u_15.GetSkinDisplayName(p80.Skin, true)
		v86 = v82.rarity
		v87 = v82.collection
	end
	if p80.Type == "Melee" then
		v84 = ("\226\152\133 %*"):format(v84)
	end
	local v88 = nil
	local v89 = p80.StatTrack and true or false
	if p80.ShowFullPriceRange then
		local v90 = v_u_11.GetItemPrice(p80.Name, p80.Skin, v82 and v82.floatRange.min or p80.Float, v89)
		local v91 = v_u_11.GetItemPrice(p80.Name, p80.Skin, v82 and v82.floatRange.max or p80.Float, v89)
		if v90 and (v91 and v90.recentAveragePriceTradeTokens ~= v91.recentAveragePriceTradeTokens) then
			local v92 = v_u_14
			local v93 = v91.recentAveragePriceTradeTokens
			local v94 = v92((math.floor(v93)))
			local v95 = v_u_14
			local v96 = v90.recentAveragePriceTradeTokens
			v88 = ("%* - %*"):format(v94, (v95((math.floor(v96)))))
		elseif v90 or v91 then
			local v97 = v_u_14
			local v98 = (v90 or v91).recentAveragePriceTradeTokens
			v88 = v97((math.floor(v98)))
		end
	else
		local v99 = v_u_11.GetItemPrice(p80.Name, p80.Skin, p80.Float, v89)
		if v99 then
			local v100 = v_u_14
			local v101 = v99.recentAveragePriceTradeTokens
			v88 = v100((math.floor(v101)))
		end
	end
	return {
		["skinInfo"] = v82,
		["isCase"] = v83 == "Case" and true or v83 == "Package",
		["isCaseLike"] = v81 ~= nil,
		["displayName"] = v84,
		["skinName"] = v85,
		["description"] = v_u_79(p80, v81, v82),
		["rarityName"] = v86,
		["collectionName"] = v87,
		["itemValue"] = v88
	}
end
local function v_u_121(p103, p104) -- name: buildCollectionList
	-- upvalues: (copy) v_u_65, (copy) v_u_8, (ref) v_u_23, (copy) v_u_6, (copy) v_u_32, (copy) v_u_10, (copy) v_u_16, (ref) v_u_20, (copy) v_u_12
	v_u_65()
	local v105 = not p104
	if v105 then
		if p103 then
			v105 = v_u_8.GetCollectionByName(p103)
		else
			v105 = p103
		end
	end
	if v105 then
		local v106 = v_u_6.Get(v_u_32, "Inventory") or {}
		local v107 = {}
		for _, v108 in ipairs(v105.items) do
			local v109 = v108.itemName
			local v110 = v108.skinName
			local v111 = v_u_10.GetSkinInformation(v109, v110)
			local v112 = v111 and v111.rarity or "Stock"
			local v113 = false
			for _, v114 in v106 do
				if v114.Name ~= v109 or v114.Skin ~= v110 then
					continue
				end
				v113 = true
			end
			local v115 = {
				["itemName"] = v109,
				["skinName"] = v110,
				["rarity"] = v112,
				["rarityOrder"] = v_u_16[v112],
				["isOwned"] = v113
			}
			table.insert(v107, v115)
		end
		table.sort(v107, function(p116, p117)
			if p116.rarity == "Stock" or p117.rarity == "Stock" then
				return p116.rarity ~= "Stock"
			elseif p116.rarityOrder == p117.rarityOrder then
				return p116.itemName < p117.itemName
			else
				return p116.rarityOrder < p117.rarityOrder
			end
		end)
		for v118, v119 in v107 do
			local v120 = v_u_20:Clone()
			v120.Parent = v_u_23.Collection
			v120.LayoutOrder = v118
			v120.Visible = true
			v120.gun.Text = ("[%*] | %*"):format(v119.itemName, v119.skinName)
			v120.gun.TextColor3 = v_u_12[v119.rarity].Color
			v120.ImageLabel.Visible = v119.isOwned
		end
		v_u_23.CollectionName.Visible = true
		v_u_23.CollectionName.Text = ("%*:"):format(p103) or ""
		v_u_23.CollectionSpacer.Visible = true
		v_u_23.Collection.Visible = true
	else
		v_u_23.CollectionName.Visible = false
		v_u_23.CollectionName.Text = ""
		v_u_23.CollectionSpacer.Visible = false
		v_u_23.Collection.Visible = false
	end
end
local function v_u_130(p122) -- name: updateTeamDisplay
	-- upvalues: (ref) v_u_23, (copy) v_u_13
	v_u_23.TeamTitle.Text = "Team:"
	if p122.Type == "Melee" or (p122.Type == "Glove" or (p122.Type == "Badge" or (p122.Type == "Charm" or p122.Type == "Zeus x27"))) then
		local v123 = v_u_23.Team
		v123.CT.Visible = true
		v123.T.Visible = true
		v123.Label.Visible = true
		v123.Label.Text = "Both"
		return
	else
		local v124
		if p122.Type == "Weapon" then
			v124 = v_u_13(p122.Name)
		else
			v124 = false
		end
		if v124 then
			local v125 = v124.Team
			if v125 == "Counter-Terrorists" then
				local v126 = v_u_23.Team
				v126.CT.Visible = true
				v126.T.Visible = false
				v126.Label.Visible = v125 ~= nil
				if v125 then
					v126.Label.Text = v125
					return
				end
			elseif v125 == "Terrorists" then
				local v127 = v_u_23.Team
				v127.CT.Visible = false
				v127.T.Visible = true
				v127.Label.Visible = v125 ~= nil
				if v125 then
					v127.Label.Text = v125
					return
				end
			else
				local v128 = v_u_23.Team
				v128.CT.Visible = true
				v128.T.Visible = true
				v128.Label.Visible = true
				v128.Label.Text = "Both"
			end
		else
			local v129 = v_u_23.Team
			v129.CT.Visible = false
			v129.T.Visible = false
			v129.Label.Visible = false
		end
	end
end
local function v_u_143(p131, p132, p133) -- name: applyHoverData
	-- upvalues: (copy) v_u_15, (ref) v_u_23, (ref) v_u_22, (copy) v_u_8, (copy) v_u_121, (copy) v_u_12, (copy) v_u_10, (copy) v_u_130
	local v134 = p132.skinName == "Vanilla" and "" or (" | %*"):format(p132.skinName)
	local v135 = p132.collectionName
	v_u_15.ApplyNameLabel(v_u_23.ItemName, p132.displayName .. v134, p131.NameTag)
	v_u_23.PriceLabel.Text = p132.itemValue or "N/A"
	v_u_23.Information.Visible = not p132.isCaseLike
	if p133 then
		v_u_23.CollectionLabel.Visible = false
		v_u_23.Description.Visible = false
		v_u_23.CollectionName.Visible = false
		v_u_23.CollectionName.Text = ""
		v_u_23.CollectionSpacer.Visible = false
		v_u_23.Collection.Visible = false
		v_u_22 = nil
	else
		v_u_23.CollectionLabel.Text = v135 or ""
		v_u_23.CollectionLabel.Visible = v135 ~= nil
		v_u_23.Description.Text = p132.description
		v_u_23.Description.Visible = p132.description ~= ""
		local v136
		if v135 then
			v136 = v_u_8.GetCollectionByName(v135)
		else
			v136 = v135
		end
		if v136 then
			v_u_23.CollectionIcon.Image = v136.imageAssetId
		end
		v_u_23.CollectionIcon.Visible = v136 ~= nil
		local v137 = ("%*|%*"):format(v135 or "", p132.isCase)
		if v_u_22 ~= v137 then
			v_u_121(v135, p132.isCase)
			v_u_22 = v137
		end
	end
	v_u_23.Rarity.Text = (p132.rarityName == "Special" or p132.rarityName == "Forbidden") and "\226\152\133 Special" or p132.rarityName
	v_u_23.Rarity.TextColor3 = v_u_12[p132.rarityName].Color
	local v138 = p132.skinInfo
	if v138 then
		local v139 = p131.Type
		v138 = (v139 == "Weapon" or (v139 == "Melee" or v139 == "Glove")) and true or v139 == "Zeus x27"
	end
	if v138 then
		local _, v140 = v_u_10.GetWearNameForFloat(p132.skinInfo, p131.Float or p132.skinInfo.floatRange.max)
		v_u_23.ExteriorLabel.Text = v140
	end
	v_u_23.Exterior.Visible = v138 == true
	if p133 then
		if p131.HideWearDetails then
			v_u_23.Team.Visible = false
			v_u_23.TeamTitle.Visible = false
		else
			v_u_23.TeamTitle.Text = "Float:"
			v_u_23.TeamTitle.Visible = true
			local v141 = p131.Float and string.format("%.14f", p131.Float) or "N/A"
			local v142 = v_u_23.Team
			v142.CT.Visible = false
			v142.T.Visible = false
			v142.Label.Visible = v141 ~= nil
			if v141 then
				v142.Label.Text = v141
			end
			v_u_23.Team.Visible = true
		end
	else
		v_u_130(p131)
		return
	end
end
local function v_u_160() -- name: prepareCurrentHoverContent
	-- upvalues: (ref) v_u_18, (ref) v_u_24, (copy) v_u_102, (ref) v_u_27, (copy) v_u_31, (ref) v_u_26, (copy) v_u_143
	if not (v_u_18 and v_u_24) then
		return false
	end
	local v144 = v_u_102(v_u_24)
	if not v144 then
		v_u_27 = nil
		v_u_31.Visible = false
		if v_u_18 then
			v_u_18.Visible = false
		end
		return false
	end
	local v145 = v_u_26 == "TradeInfo"
	local v146 = table.concat
	local v147 = {}
	local v148 = v_u_24._id
	local v149 = v144.displayName
	local v150 = v144.skinName
	local v151 = v144.description
	local v152 = v144.rarityName or ""
	local v153 = v144.collectionName or ""
	local v154 = v144.itemValue or ""
	local v155 = tostring(v154)
	local v156 = v144.isCase
	local v157 = tostring(v156)
	local v158 = v144.isCaseLike
	__set_list(v147, 1, {v148, v149, v150, v151, v152, v153, v155, v157, tostring(v158), (tostring(v145))})
	local v159 = v146(v147, "\0")
	if v_u_27 ~= v159 then
		v_u_31.Visible = false
		if v_u_18 then
			v_u_18.Visible = false
		end
		v_u_143(v_u_24, v144, v145)
		v_u_27 = v159
	end
	return true
end
local function v_u_162(p161) -- name: canShowCurrentHover
	-- upvalues: (ref) v_u_18, (ref) v_u_24, (ref) v_u_25, (copy) v_u_31, (ref) v_u_19
	if not (v_u_18 and (v_u_24 and v_u_25)) then
		v_u_31.Visible = false
		if v_u_18 then
			v_u_18.Visible = false
		end
		return false
	end
	if v_u_25.Parent == nil or not v_u_25.Visible then
		v_u_31:Close(v_u_25)
		return false
	end
	if p161 or v_u_19 and v_u_19.Visible then
		return true
	end
	v_u_31:Close()
	return false
end
local function v_u_165(p_u_163) -- name: bindTemplateInvalidation
	-- upvalues: (copy) v_u_30, (copy) v_u_31
	for _, v164 in ipairs(v_u_30) do
		v164:Disconnect()
	end
	table.clear(v_u_30)
	v_u_30[1] = p_u_163:GetPropertyChangedSignal("AbsolutePosition"):Connect(function()
		-- upvalues: (ref) v_u_31, (copy) p_u_163
		v_u_31:Close(p_u_163)
	end)
	v_u_30[2] = p_u_163:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (copy) p_u_163, (ref) v_u_31
		if not p_u_163.Visible then
			v_u_31:Close(p_u_163)
		end
	end)
	v_u_30[3] = p_u_163.AncestryChanged:Connect(function()
		-- upvalues: (copy) p_u_163, (ref) v_u_31
		if p_u_163.Parent == nil then
			v_u_31:Close(p_u_163)
		end
	end)
end
local function v_u_177(p166) -- name: closeTradeInfoFromInput
	-- upvalues: (ref) v_u_26, (copy) v_u_31, (ref) v_u_18, (ref) v_u_25
	if v_u_26 == "TradeInfo" and (v_u_31.Visible and v_u_18) then
		local v167 = p166.UserInputType
		if v167 == Enum.UserInputType.MouseButton1 or v167 == Enum.UserInputType.Touch then
			local v168 = Vector2.new(p166.Position.X, p166.Position.Y)
			local v169 = v_u_18
			local v170 = v169.AbsolutePosition
			local v171 = v169.AbsoluteSize
			local v172
			if v168.X >= v170.X and (v168.X <= v170.X + v171.X and v168.Y >= v170.Y) then
				v172 = v168.Y <= v170.Y + v171.Y
			else
				v172 = false
			end
			if not v172 then
				if v_u_25 and v_u_25.Parent then
					local v173 = v_u_25
					local v174 = v173.AbsolutePosition
					local v175 = v173.AbsoluteSize
					local v176
					if v168.X >= v174.X and (v168.X <= v174.X + v175.X and v168.Y >= v174.Y) then
						v176 = v168.Y <= v174.Y + v175.Y
					else
						v176 = false
					end
					if v176 then
						return
					end
				end
				v_u_31:Close()
			end
		else
			return
		end
	else
		return
	end
end
function v_u_31.Initialize(_, p178, p179) -- name: Initialize
	-- upvalues: (ref) v_u_18, (ref) v_u_19, (ref) v_u_20, (copy) v_u_1, (ref) v_u_23, (copy) v_u_31, (copy) v_u_8, (ref) v_u_17, (copy) v_u_7
	v_u_18 = p178
	v_u_19 = p179
	v_u_20 = v_u_1.Assets.TradingUI.Templates:WaitForChild("CollectionNameTemplate")
	v_u_23 = {
		["ItemName"] = v_u_18.ItemName.Frame.ItemName,
		["CollectionLabel"] = v_u_18.ItemName.Frame.Collection,
		["CollectionIcon"] = v_u_18.ItemName.CollectionIcon,
		["Description"] = v_u_18.Description,
		["PriceLabel"] = v_u_18.Price.PriceHolder.Team.Label,
		["Information"] = v_u_18.Information,
		["Rarity"] = v_u_18.Information.Rarity.Label,
		["Exterior"] = v_u_18.Information.Exterior,
		["ExteriorLabel"] = v_u_18.Information.Exterior.Label,
		["Team"] = v_u_18.Information.Team.Team,
		["TeamTitle"] = v_u_18.Information.Team.Team.Label.Parent.Parent.Title,
		["Collection"] = v_u_18.Collection,
		["CollectionName"] = v_u_18.CollectionName,
		["CollectionSpacer"] = v_u_18.CollectionSpacer
	}
	v_u_31.Visible = false
	if v_u_18 then
		v_u_18.Visible = false
	end
	v_u_8.ObserveAvailableCollections(function(p180)
		-- upvalues: (ref) v_u_17
		v_u_17 = p180
	end)
	v_u_7.observerRouter("OpenTradeInfo", function(p181, p182)
		-- upvalues: (ref) v_u_31
		v_u_31:OpenTradeInfo(p181, p182)
	end)
end
function v_u_31.Start() -- name: Start
	-- upvalues: (ref) v_u_21, (copy) v_u_4, (copy) v_u_177
	if not v_u_21 then
		v_u_21 = v_u_4.InputBegan:Connect(v_u_177)
	end
end
function v_u_31.Open(_, p183, p_u_184) -- name: Open
	-- upvalues: (ref) v_u_29, (ref) v_u_24, (ref) v_u_25, (ref) v_u_26, (ref) v_u_27, (ref) v_u_28, (copy) v_u_165, (copy) v_u_160, (copy) v_u_162, (copy) v_u_31, (copy) v_u_63, (ref) v_u_18
	v_u_29 = v_u_29 + 1
	local v_u_185 = v_u_29
	v_u_24 = p183
	v_u_25 = p_u_184
	v_u_26 = "Inventory"
	v_u_27 = nil
	v_u_28 = nil
	v_u_165(p_u_184)
	if v_u_160() and v_u_162(false) then
		local v186 = v_u_63(p_u_184)
		if v_u_28 ~= v186 then
			v_u_18.Position = v186
			v_u_28 = v186
		end
		v_u_31.Visible = false
		if v_u_18 then
			v_u_18.Visible = false
		end
		task.delay(0.33, function()
			-- upvalues: (ref) v_u_29, (copy) v_u_185, (ref) v_u_25, (copy) p_u_184, (ref) v_u_26, (ref) v_u_162, (ref) v_u_27, (ref) v_u_160, (ref) v_u_63, (ref) v_u_28, (ref) v_u_18, (ref) v_u_31
			if v_u_29 == v_u_185 and (v_u_25 == p_u_184 and v_u_26 == "Inventory") then
				if v_u_162(false) then
					if v_u_27 ~= nil or v_u_160() then
						if v_u_25 then
							local v187 = v_u_63(v_u_25)
							if v_u_28 ~= v187 then
								v_u_18.Position = v187
								v_u_28 = v187
							end
						end
						v_u_31.Visible = true
						if v_u_18 then
							v_u_18.Visible = true
						end
					end
				else
					return
				end
			else
				return
			end
		end)
	else
		v_u_31:Close(p_u_184)
	end
end
function v_u_31.OpenTradeInfo(_, p188, p189) -- name: OpenTradeInfo
	-- upvalues: (copy) v_u_31, (ref) v_u_26, (ref) v_u_24, (ref) v_u_25, (ref) v_u_29, (ref) v_u_27, (ref) v_u_28, (copy) v_u_165, (ref) v_u_18, (copy) v_u_160, (copy) v_u_63
	if v_u_31.Visible and (v_u_26 == "TradeInfo" and (v_u_24 == p188 and v_u_25 == p189)) then
		v_u_31:Close(p189)
	else
		v_u_29 = v_u_29 + 1
		v_u_24 = p188
		v_u_25 = p189
		v_u_26 = "TradeInfo"
		v_u_27 = nil
		v_u_28 = nil
		v_u_165(p189)
		v_u_31.Visible = false
		if v_u_18 then
			v_u_18.Visible = false
		end
		local v190
		if v_u_18 and (v_u_24 and v_u_25) then
			if v_u_25.Parent == nil or not v_u_25.Visible then
				v_u_31:Close(v_u_25)
				v190 = false
			else
				v190 = true
			end
		else
			v_u_31.Visible = false
			if v_u_18 then
				v_u_18.Visible = false
				v190 = false
			else
				v190 = false
			end
		end
		local v191
		if v190 and (v_u_27 ~= nil or v_u_160()) then
			if v_u_25 then
				local v192 = v_u_63(v_u_25)
				if v_u_28 ~= v192 then
					v_u_18.Position = v192
					v_u_28 = v192
				end
			end
			v_u_31.Visible = true
			if v_u_18 then
				v_u_18.Visible = true
				v191 = true
			else
				v191 = true
			end
		else
			v191 = false
		end
		if not v191 then
			v_u_31:Close(p189)
		end
	end
end
function v_u_31.Close(_, p193) -- name: Close
	-- upvalues: (ref) v_u_25, (ref) v_u_29, (ref) v_u_24, (ref) v_u_26, (ref) v_u_22, (copy) v_u_30, (ref) v_u_27, (ref) v_u_28, (copy) v_u_31, (ref) v_u_18
	if not p193 or v_u_25 == p193 then
		v_u_29 = v_u_29 + 1
		v_u_24 = nil
		v_u_25 = nil
		v_u_26 = nil
		v_u_22 = nil
		for _, v194 in ipairs(v_u_30) do
			v194:Disconnect()
		end
		table.clear(v_u_30)
		v_u_27 = nil
		v_u_28 = nil
		v_u_31.Visible = false
		if v_u_18 then
			v_u_18.Visible = false
		end
	end
end
return v_u_31
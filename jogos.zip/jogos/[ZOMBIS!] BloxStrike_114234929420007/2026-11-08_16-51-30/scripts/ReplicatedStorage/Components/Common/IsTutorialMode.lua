-- NIGHT Analyzer | ReplicatedStorage.Components.Common.IsTutorialMode
-- ModuleScript | 3 linhas | 145 bytes | hash ad413921

return function()
	return workspace:GetAttribute("ServerGamemode") == "Tutorial" and true or workspace:GetAttribute("Gamemode") == "Tutorial"
end
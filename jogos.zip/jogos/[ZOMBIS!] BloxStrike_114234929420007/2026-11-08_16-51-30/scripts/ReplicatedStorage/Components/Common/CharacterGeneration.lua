-- NIGHT Analyzer | ReplicatedStorage.Components.Common.CharacterGeneration
-- ModuleScript | 42 linhas | 1057 bytes | hash 2f3193e2

local v_u_11 = {
	["AttributeName"] = "CharacterGeneration",
	["MaxValue"] = 65535,
	["IsValid"] = function(p1) -- name: IsValid
		-- upvalues: (copy) v_u_11
		local v2
		if typeof(p1) == "number" and (p1 % 1 == 0 and p1 >= 1) then
			v2 = p1 <= v_u_11.MaxValue
		else
			v2 = false
		end
		return v2
	end,
	["Get"] = function(p3) -- name: Get
		-- upvalues: (copy) v_u_11
		if p3 == nil then
			return nil
		else
			local v4 = p3:GetAttribute(v_u_11.AttributeName)
			if v_u_11.IsValid(v4) then
				return v4
			else
				return nil
			end
		end
	end,
	["Set"] = function(p5, p6) -- name: Set
		-- upvalues: (copy) v_u_11
		local v7 = v_u_11.IsValid(p6)
		assert(v7, "character generation must be a non-zero u16")
		p5:SetAttribute(v_u_11.AttributeName, p6)
	end,
	["Next"] = function(p8) -- name: Next
		-- upvalues: (copy) v_u_11
		return (not v_u_11.IsValid(p8) or p8 == v_u_11.MaxValue) and 1 or p8 + 1
	end,
	["Matches"] = function(p9, p10) -- name: Matches
		-- upvalues: (copy) v_u_11
		return v_u_11.Get(p9) == p10
	end
}
return table.freeze(v_u_11)
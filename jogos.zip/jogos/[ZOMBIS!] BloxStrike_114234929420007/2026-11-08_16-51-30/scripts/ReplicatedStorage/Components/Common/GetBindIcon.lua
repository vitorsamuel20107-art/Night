-- NIGHT Analyzer | ReplicatedStorage.Components.Common.GetBindIcon
-- ModuleScript | 19 linhas | 463 bytes | hash 7eb60fa9

local v_u_1 = game:GetService("UserInputService")
return function(p2)
	-- upvalues: (copy) v_u_1
	if p2 == nil or p2.EnumType ~= Enum.KeyCode then
		return nil
	else
		local v3 = p2.Name
		if (string.match(v3, "^Button") ~= nil or string.match(v3, "^DPad") ~= nil) and true or string.match(v3, "^Thumbstick") ~= nil then
			local v4 = v_u_1:GetImageForKeyCode(p2)
			if v4 == "" then
				return nil
			else
				return v4
			end
		else
			return nil
		end
	end
end
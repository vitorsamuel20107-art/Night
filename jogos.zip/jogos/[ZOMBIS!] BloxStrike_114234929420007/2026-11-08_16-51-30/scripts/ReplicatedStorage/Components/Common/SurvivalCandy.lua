-- NIGHT Analyzer | ReplicatedStorage.Components.Common.SurvivalCandy
-- ModuleScript | 34 linhas | 1152 bytes | hash 7e54db2f

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Components.Common.HordeProtocol)
local v_u_9 = {
	["COUNT_ATTRIBUTE"] = "SurvivalCandy",
	["PROFILE_FIELD"] = "Halloween2026Candy",
	["PIECES_PER_KILL"] = table.freeze({
		[v_u_2.ARCHETYPE_NORMAL] = 2.6,
		[v_u_2.ARCHETYPE_HEAVY] = 7.8,
		[v_u_2.ARCHETYPE_FLAMING_HEAVY] = 7.8
	}),
	["MAX_PIECES"] = 16,
	["LIFETIME"] = 30,
	["SERVER_GRACE"] = 3,
	["MAGNET_RADIUS"] = 16,
	["MAGNET_VERTICAL"] = 8,
	["CLAIM_RADIUS"] = 40,
	["TEMPLATE_FOLDER"] = "HalloweenCandies",
	["KINDS"] = table.freeze({ "CandyCorn", "HardCandy", "ChocolateBar" }),
	["MESH_IDS"] = table.freeze({
		["CandyCorn"] = 81252871358159,
		["ChocolateBar"] = 72250444065685,
		["HardCandy"] = 91317282706948
	}),
	["COLOR_MAP_ID"] = 126067301498450,
	["RollPieces"] = function(p3, p4) -- name: RollPieces
		-- upvalues: (copy) v_u_9, (copy) v_u_2
		local v5 = v_u_9.PIECES_PER_KILL[p3] or v_u_9.PIECES_PER_KILL[v_u_2.ARCHETYPE_NORMAL]
		local v6 = math.floor(v5)
		local v7 = v6 + (p4:NextNumber() < v5 - v6 and 1 or 0)
		local v8 = v_u_9.MAX_PIECES
		return math.clamp(v7, 0, v8)
	end
}
return table.freeze(v_u_9)
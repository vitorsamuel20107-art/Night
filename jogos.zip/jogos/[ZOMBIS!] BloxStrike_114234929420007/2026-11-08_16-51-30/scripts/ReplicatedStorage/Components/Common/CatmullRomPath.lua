-- NIGHT Analyzer | ReplicatedStorage.Components.Common.CatmullRomPath
-- ModuleScript | 100 linhas | 2613 bytes | hash 1f6d2f7c

local v1 = {}
local function v_u_4(p2, p3) -- name: straightDistance
	return (p2 - p3).Magnitude
end
function v1.spline(p5, p6) -- name: spline
	-- upvalues: (copy) v_u_4
	local v7 = #p5
	if v7 < 2 then
		return p5
	end
	local v8 = p6.Distance or v_u_4
	local v9 = p6.Alpha
	local v10 = { p5[1] }
	for v11 = 1, v7 - 1 do
		local v12 = p5[v11]
		local v13 = p5[v11 + 1]
		local v14
		if v11 > 1 then
			v14 = p5[v11 - 1]
		else
			v14 = v12 + (v12 - v13)
		end
		local v15
		if v11 + 2 <= v7 then
			v15 = p5[v11 + 2]
		else
			v15 = v13 + (v13 - v12)
		end
		local v16 = v8(v14, v12) ^ v9
		local v17 = math.max(v16, 0.0001)
		local v18 = v8(v12, v13) ^ v9
		local v19 = v17 + math.max(v18, 0.0001)
		local v20 = v8(v13, v15) ^ v9
		local v21 = v19 + math.max(v20, 0.0001)
		local v22 = p6.SamplesPerSpan
		if not v22 then
			local v23 = v8(v12, v13) / (p6.Step or 1)
			local v24 = math.ceil(v23)
			v22 = math.max(1, v24)
		end
		for v25 = 1, v22 do
			local v26 = v17 + (v19 - v17) * (v25 / v22)
			local v27 = v14 * ((v17 - v26) / v17) + v12 * (v26 / v17)
			local v28 = v12 * ((v19 - v26) / (v19 - v17)) + v13 * ((v26 - v17) / (v19 - v17))
			local v29 = v13 * ((v21 - v26) / (v21 - v19)) + v15 * ((v26 - v19) / (v21 - v19))
			local v30 = v27 * ((v19 - v26) / v19) + v28 * (v26 / v19)
			local v31 = v28 * ((v21 - v26) / (v21 - v17)) + v29 * ((v26 - v17) / (v21 - v17))
			local v32 = v30 * ((v19 - v26) / (v19 - v17)) + v31 * ((v26 - v17) / (v19 - v17))
			table.insert(v10, v32)
		end
	end
	return v10
end
function v1.resample(p33, p34, p35, p36) -- name: resample
	-- upvalues: (copy) v_u_4
	local v37 = p35 or v_u_4
	local v38 = { p33[1] }
	local v39 = p36 and { p36[1] } or {}
	local v40 = 0
	local v41 = 0
	for v42 = 2, #p33 do
		local v43 = p33[v42 - 1]
		local v44 = p33[v42]
		local v45 = v37(v43, v44)
		if v45 < 0.001 then
			continue
		end
		local v46 = p34 - v40
		while v46 <= v45 do
			local v47 = v46 / v45
			table.insert(v38, v43:Lerp(v44, v47))
			if p36 then
				local v48 = p36[v42 - 1]
				local v49 = p36[v42]
				local v50 = v46 / v45
				table.insert(v39, v48:Lerp(v49, v50))
			end
			v46 = v46 + p34
		end
		v40 = v45 - (v46 - p34)
		v41 = v41 + v45
	end
	if v37(v38[#v38], p33[#p33]) > 0.01 then
		local v51 = p33[#p33]
		table.insert(v38, v51)
		if p36 then
			local v52 = p36[#p36]
			table.insert(v39, v52)
		end
	end
	return v38, v41, v39
end
function v1.locate(p53, p54, p55) -- name: locate
	local v56 = p55 / p54 + 1
	local v57 = math.floor(v56)
	local v58 = math.clamp(v57, 1, p53)
	local v59 = v58 + 1
	return v58, math.min(v59, p53), v56 - math.floor(v56)
end
return v1
-- NIGHT Analyzer | ReplicatedStorage.Components.Common.RecycleFX
-- ModuleScript | 43 linhas | 1271 bytes | hash d1d095cc

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Players")
local v_u_3 = workspace:WaitForChild("Debris")
local v_u_4 = require(v1.Classes.Ragdoll)
local v_u_5 = require(v1.Shared.DebugFlags)
return function()
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_2, (copy) v_u_5
	local v6 = 0
	local v7 = 0
	for _, v_u_8 in v_u_3:GetChildren() do
		if v_u_8:IsA("Folder") then
			continue
		end
		local v9
		if v_u_8:GetAttribute("PersistentDebris") == true then
			v9 = true
		else
			local v10 = v_u_8.Name
			v9 = string.sub(v10, -7) == "_Weapon" and true or string.find(v_u_8.Name, "_WeaponAttachments", 1, true) ~= nil
		end
		if v9 then
			v6 = v6 + 1
		elseif v_u_8:IsA("Model") and (v_u_8:GetAttribute("CharacterType") ~= nil or v_u_8:FindFirstChildOfClass("Humanoid") ~= nil) then
			v6 = v6 + 1
			v_u_4.HideCharacterLocally(v_u_8)
		else
			v7 = v7 + 1
			if v_u_2:FindFirstChild(v_u_8.Name) then
				task.delay(0.5, function()
					-- upvalues: (copy) v_u_8
					if v_u_8 and v_u_8.Parent then
						v_u_8:Destroy()
					end
				end)
			else
				v_u_8:Destroy()
			end
		end
	end
	if v_u_5.IsEnabled("DebrisCleanup") then
		warn(("[DebrisCleanup][Client] CleanupDebris received: destroyed=%d skipped=%d"):format(v7, v6))
	end
end
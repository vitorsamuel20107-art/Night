-- NIGHT Analyzer | ReplicatedStorage.Components.Common.GetUserPlatform
-- ModuleScript | 23 linhas | 592 bytes | hash e9613059

local v_u_1 = game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
return function()
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v3 = {}
	if v_u_1.GamepadEnabled then
		table.insert(v3, "Console")
	end
	if v_u_1.VREnabled then
		table.insert(v3, "VR")
	end
	local v4 = v_u_2:IsStudio()
	if v4 then
		v4 = v_u_1.PreferredInput == Enum.PreferredInput.Touch
	end
	if (v_u_1.MouseEnabled or v_u_1.KeyboardEnabled) and not v4 then
		table.insert(v3, "PC")
	end
	if v_u_1.TouchEnabled and not table.find(v3, "PC") then
		table.insert(v3, "Mobile")
	end
	return v3
end
-- NIGHT Analyzer | ReplicatedStorage.Components.Common.GetBadgeName
-- ModuleScript | 31 linhas | 873 bytes | hash 89f4d38f

local v1 = game:GetService("ReplicatedStorage")
require(v1.Database.Custom.Types)
local v_u_2 = require(v1.Controllers.DataController)
local v_u_3 = require(v1.Database.Components.Libraries.Skins)
local v_u_4 = require(v1.Components.Common.GetSkinDisplayName)
return function(p5, p6)
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_4
	if not p5:IsA("Player") then
		return ""
	end
	local v7, v8 = v_u_2.Get(p5, "Loadout", "Inventory")
	if not (v7 and v8) then
		return ""
	end
	local v9 = v7[p6]
	if not (v9 and v9.Equipped) then
		return ""
	end
	local v10 = v9.Equipped["Equipped Badge"]
	if not v10 or v10 == "" then
		return ""
	end
	local v11 = nil
	for _, v12 in ipairs(v8) do
		if v12._id ~= v10 then
			continue
		end
		v11 = v12
	end
	return not v11 and "" or (not v_u_3.GetSkinInformation(v11.Name, v11.Skin) and "" or v_u_4.GetSkinDisplayName(v11.Skin))
end
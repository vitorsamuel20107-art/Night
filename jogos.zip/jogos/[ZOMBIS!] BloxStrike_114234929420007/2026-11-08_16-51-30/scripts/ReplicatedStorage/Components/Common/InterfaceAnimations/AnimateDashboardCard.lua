-- NIGHT Analyzer | ReplicatedStorage.Components.Common.InterfaceAnimations.AnimateDashboardCard
-- ModuleScript | 209 linhas | 6245 bytes | hash 38297a4d

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = require(v1.Database.Security.Router)
local v_u_4 = require(script.Parent.GuiShown)
local v_u_5 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v_u_6 = Color3.fromRGB(255, 196, 77)
local v_u_7 = TweenInfo.new(3, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, -1)
local v_u_8 = TweenInfo.new(1.6, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true)
local v_u_9 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v_u_10 = TweenInfo.new(0.9, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true)
local v_u_11 = TweenInfo.new(0.9, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
local v_u_12 = {
	{ 4, 0.85 },
	{ 8, 0.94 }
}
local function v_u_18(p13, p14, p15) -- name: createGlowStroke
	-- upvalues: (copy) v_u_6
	local v16 = Instance.new("Frame")
	v16.Name = "Glow"
	v16.BackgroundTransparency = 1
	v16.Size = UDim2.fromScale(1, 1)
	v16.ZIndex = 3
	local v17 = Instance.new("UIStroke")
	v17.Name = "GlowStroke"
	v17.Color = v_u_6
	v17.Thickness = p14
	v17.Transparency = p15
	v17.Parent = v16
	v16.Parent = p13
	return v17
end
local function v_u_26(p19) -- name: createGlowInstances
	-- upvalues: (copy) v_u_18, (copy) v_u_6, (copy) v_u_2, (copy) v_u_7, (copy) v_u_12
	local v20 = v_u_18(p19, 1.5, 0.3)
	local v21 = Instance.new("UIGradient")
	v21.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v_u_6), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 240, 190)), ColorSequenceKeypoint.new(1, v_u_6) })
	v21.Parent = v20
	local v22 = v_u_2:Create(v21, v_u_7, {
		["Rotation"] = 360
	})
	local v23 = {}
	for _, v24 in ipairs(v_u_12) do
		local v25 = v_u_18(p19, v24[1], v24[2])
		table.insert(v23, v25)
	end
	return v20, v23, v22
end
local function v_u_30(p27) -- name: createShineSweep
	local v28 = Instance.new("Frame")
	v28.Name = "Shine"
	v28.Active = false
	v28.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	v28.BorderSizePixel = 0
	v28.Size = UDim2.fromScale(1, 1)
	v28.ZIndex = 150
	local v29 = Instance.new("UIGradient")
	v29.Rotation = 20
	v29.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 1),
		NumberSequenceKeypoint.new(0.4, 1),
		NumberSequenceKeypoint.new(0.5, 0.55),
		NumberSequenceKeypoint.new(0.6, 1),
		NumberSequenceKeypoint.new(1, 1)
	})
	v29.Offset = Vector2.new(-1, 0)
	v29.Parent = v28
	v28.Parent = p27
	return v29
end
local function v_u_66(p_u_31, p32) -- name: setupCardEffects
	-- upvalues: (copy) v_u_26, (copy) v_u_12, (copy) v_u_2, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_4, (copy) v_u_30, (copy) v_u_11
	local v33, v34, v_u_35 = v_u_26(p_u_31)
	local v_u_36 = {}
	for v37, v38 in ipairs(v34) do
		local v39 = v_u_2
		local v40 = v_u_8
		local v41 = {
			["Transparency"] = v_u_12[v37][2] - 0.08
		}
		table.insert(v_u_36, v39:Create(v38, v40, v41))
	end
	local v_u_42 = { v_u_2:Create(v33, v_u_9, {
			["Transparency"] = 0,
			["Thickness"] = 2
		}) }
	local v_u_43 = { v_u_2:Create(v33, v_u_9, {
			["Transparency"] = 0.3,
			["Thickness"] = 1.5
		}) }
	for v44, v45 in ipairs(v34) do
		local v46 = v_u_2
		local v47 = v_u_9
		table.insert(v_u_42, v46:Create(v45, v47, {
			["Transparency"] = 1
		}))
		local v48 = v_u_2
		local v49 = v_u_9
		local v50 = {
			["Transparency"] = v_u_12[v44][2]
		}
		table.insert(v_u_43, v48:Create(v45, v49, v50))
	end
	local v_u_51 = false
	p32.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_51, (copy) v_u_36, (copy) v_u_42
		v_u_51 = true
		for v52, v53 in ipairs(v_u_36) do
			v53:Cancel()
			v_u_42[v52 + 1]:Play()
		end
		v_u_42[1]:Play()
	end)
	p32.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_51, (copy) v_u_43
		v_u_51 = false
		for _, v54 in ipairs(v_u_43) do
			v54:Play()
		end
	end)
	local v_u_55 = false
	v_u_43[1].Completed:Connect(function()
		-- upvalues: (ref) v_u_55, (ref) v_u_51, (copy) v_u_36
		if v_u_55 and not v_u_51 then
			for _, v56 in ipairs(v_u_36) do
				v56:Play()
			end
		end
	end)
	local v57 = p_u_31:FindFirstChild("Discount")
	if v57 then
		v57 = v57:FindFirstChild("Discount")
	end
	local v_u_58
	if v57 then
		v_u_58 = v_u_2:Create(v57, v_u_10, {
			["Rotation"] = v57.Rotation + 4
		})
	else
		v_u_58 = nil
	end
	v_u_4.Observe(p_u_31, function(p59)
		-- upvalues: (ref) v_u_55, (ref) v_u_51, (copy) v_u_36, (copy) v_u_35, (copy) v_u_58
		v_u_55 = p59
		local v60 = v_u_51 and {} or table.clone(v_u_36)
		local v61 = v_u_35
		table.insert(v60, v61)
		if v_u_58 then
			local v62 = v_u_58
			table.insert(v60, v62)
		end
		for _, v63 in v60 do
			if v_u_55 then
				v63:Play()
			else
				v63:Pause()
			end
		end
	end)
	local v_u_64 = v_u_30(p_u_31)
	task.spawn(function()
		-- upvalues: (ref) v_u_2, (copy) v_u_64, (ref) v_u_11, (copy) p_u_31, (ref) v_u_55
		local v65 = v_u_2:Create(v_u_64, v_u_11, {
			["Offset"] = Vector2.new(1, 0)
		})
		while p_u_31.Parent do
			if v_u_55 then
				v65:Play()
				v65.Completed:Wait()
				v_u_64.Offset = Vector2.new(-1, 0)
			end
			task.wait(2.5)
		end
	end)
end
return function(p67, p68)
	-- upvalues: (copy) v_u_66, (copy) v_u_2, (copy) v_u_5, (copy) v_u_3
	v_u_66(p67, p68)
	local v69 = p67.Size
	local v_u_70 = v_u_2:Create(p67, v_u_5, {
		["Size"] = UDim2.new(v69.X.Scale * 0.9, v69.X.Offset, v69.Y.Scale * 0.9, v69.Y.Offset)
	})
	local v_u_71 = v_u_2:Create(p67, v_u_5, {
		["Size"] = UDim2.new(v69.X.Scale * 0.95, v69.X.Offset, v69.Y.Scale * 0.95, v69.Y.Offset)
	})
	local v_u_72 = v_u_2:Create(p67, v_u_5, {
		["Size"] = UDim2.new(v69.X.Scale * 0.95, v69.X.Offset, v69.Y.Scale * 0.95, v69.Y.Offset)
	})
	local v_u_73 = v_u_2:Create(p67, v_u_5, {
		["Size"] = UDim2.new(v69.X.Scale * 1, v69.X.Offset, v69.Y.Scale * 1, v69.Y.Offset)
	})
	p68.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_3, (copy) v_u_72
		v_u_3.broadcastRouter("RunInterfaceSound", "UI Highlight")
		v_u_72:Play()
	end)
	p68.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_73
		v_u_73:Play()
	end)
	p68.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_3, (copy) v_u_70
		v_u_3.broadcastRouter("RunInterfaceSound", "UI Click")
		v_u_70:Play()
	end)
	p68.MouseButton1Up:Connect(function()
		-- upvalues: (copy) v_u_71
		v_u_71:Play()
	end)
end
-- NIGHT Analyzer | ReplicatedStorage.Components.Common.InterfaceAnimations.AnimateHalloweenWheel
-- ModuleScript | 565 linhas | 17090 bytes | hash 4f0db438

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = require(v1.Controllers.RunServiceController)
local v_u_4 = require(v1.Database.Security.Router)
local v_u_5 = require(script.Parent.GuiShown)
local v_u_6 = Vector2.new(0.4986, 0.497)
local v_u_7 = {
	359.4,
	44.6,
	89.5,
	134.2,
	179.1,
	224.3,
	269.4,
	314.3
}
local v_u_8 = {
	0.8,
	23.4,
	46.3,
	68.6,
	90.9,
	113.1,
	134.6,
	156.7,
	179.2,
	202.1,
	224,
	246.3,
	269,
	292,
	314.6,
	337.7
}
local function v_u_15(p9, p10) -- name: restCentre
	local v11 = p9.Parent
	local v12 = v11.AbsoluteSize
	local v13 = p9.AbsoluteSize
	local v14 = Vector2.new(p10.X.Scale * v12.X + p10.X.Offset, p10.Y.Scale * v12.Y + p10.Y.Offset)
	return v11.AbsolutePosition + v14 + (Vector2.new(0.5, 0.5) - p9.AnchorPoint) * v13
end
local v_u_16 = { "Normal", "ForwardBait", "BackwardBait" }
return function(p17, p_u_18, p_u_19)
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_15, (copy) v_u_8, (copy) v_u_4, (copy) v_u_2, (copy) v_u_3, (copy) v_u_5, (copy) v_u_16
	local v_u_20 = p17.Spinner
	local v_u_21 = p17.Pointer
	local v_u_22 = p17.Glow
	local v_u_23 = v_u_6 - Vector2.new(0.5, 0.5)
	local v_u_24 = {}
	for _, v25 in v_u_20:GetChildren() do
		if not v25:IsA("GuiObject") then
			continue
		end
		local v26 = v25.Position
		local v27 = Vector2.new(v26.X.Scale - 0.5, v26.Y.Scale - 0.5)
		local v28 = v27.X
		local v29 = -v27.Y
		local v30 = math.atan2(v28, v29)
		local v31 = math.deg(v30)
		local v32 = v_u_7[1]
		for _, v33 in v_u_7 do
			local v34 = (v33 - v31 + 180) % 360 - 180
			local v35 = math.abs(v34)
			local v36 = (v32 - v31 + 180) % 360 - 180
			if v35 >= math.abs(v36) then
				continue
			end
			v32 = v33
		end
		local v37 = math.rad(v32)
		local v38 = v27.Magnitude
		v25.Rotation = v32
		v25.Position = UDim2.fromScale(v_u_6.X + math.sin(v37) * v38, v_u_6.Y - math.cos(v37) * v38)
		table.insert(v_u_24, v25)
	end
	local v39 = #v_u_24
	local v_u_40 = 360 / math.max(v39, 1)
	local v_u_41 = v_u_20.Position
	local v_u_42 = v_u_21.Rotation
	local v43 = v_u_21.Size
	local v_u_44 = v_u_21.Position - UDim2.new(0, 0, 0.14 * v43.Y.Scale, 0.14 * v43.Y.Offset)
	v_u_21.Position = v_u_44
	local v_u_45 = v_u_22.ImageTransparency
	local v_u_46 = Random.new()
	local v_u_47 = v_u_20.Rotation
	local v_u_48 = 0
	local v_u_49 = 0
	local v_u_50 = true
	local v_u_51 = false
	local v_u_52 = 0
	local v_u_53 = os.clock() + 6
	local v_u_54 = "Idle"
	local v_u_55 = 12
	local v_u_56 = 0
	local v_u_57 = 0
	local v_u_58 = 0
	local v_u_59 = 0
	local v_u_60 = 0
	local v_u_61 = 1
	local v_u_62 = 0
	local v_u_63 = 0
	local v_u_64 = 0
	local v_u_65 = 0
	local v_u_66 = 1
	local v_u_67 = nil
	local v_u_68 = nil
	local v_u_69 = false
	local function v_u_83() -- name: measureFlapper
		-- upvalues: (copy) v_u_20, (copy) v_u_21, (ref) v_u_15, (copy) v_u_41, (copy) v_u_23, (copy) v_u_44, (copy) v_u_42
		local v70 = v_u_20.AbsoluteSize.X
		local v71 = v_u_21.AbsoluteSize.Y
		if v70 <= 0 or v71 <= 0 then
			return nil
		end
		local v72 = v_u_15(v_u_20, v_u_41) + v_u_23 * v_u_20.AbsoluteSize
		local v73 = v_u_15(v_u_21, v_u_44)
		local v74 = v_u_42
		local v75 = 0.31 * v71
		local v76 = math.rad(v74)
		local v77 = v73 - Vector2.new(-math.sin(v76), (math.cos(v76))) * v75
		local v78 = 0.4689 * v70
		local v79 = 0.0185 * v70
		local v80 = v72.Y - v78 - v77.Y + 0 * v79
		if v80 <= 0 then
			return nil
		end
		local v81 = 0.43 * (0.7250000000000001 - v80 / v71)
		local v82 = math.max(v81, 0) * v71
		return {
			["Centre"] = v72,
			["Pivot"] = v77,
			["RingRadius"] = v78,
			["PegRadius"] = v79,
			["Reach"] = v80,
			["EdgeAngle"] = math.atan2(v82, v80)
		}
	end
	local function v_u_98(p84, p85) -- name: pegContact
		local v86 = math.rad(p85)
		local v87 = p84.Centre + Vector2.new(math.sin(v86), -math.cos(v86)) * p84.RingRadius - p84.Pivot
		local v88 = v87.Magnitude
		local v89 = p84.Reach
		local v90 = p84.PegRadius
		if v88 > 0 then
			local v91 = v88 - v89
			if v90 > math.abs(v91) then
				local v92 = p84.EdgeAngle
				local v93 = (v88 * v88 + v89 * v89 - v90 * v90) / (2 * v88 * v89)
				local v94 = math.clamp(v93, -1, 1)
				local v95 = v92 + math.acos(v94)
				local v96 = v87.X
				local v97 = v87.Y
				return true, math.atan2(v96, v97), v95
			end
		end
		return false, 0, 0
	end
	local function v_u_107() -- name: pegWindow
		-- upvalues: (copy) v_u_83, (copy) v_u_98
		local v99 = v_u_83()
		if not v99 then
			return 4, 8.1
		end
		local v100 = 4
		local v101 = 8.1
		for v102 = 450, 0, -1 do
			local v103, v104, v105 = v_u_98(v99, -v102 / 10)
			if not v103 or math.abs(v104) >= v105 then
				continue
			end
			v100 = v102 / 10
		end
		for v106 = 0, 450 do
			if v_u_98(v99, v106 / 10) then
				continue
			end
			return v100, v106 / 10
		end
		return v100, v101
	end
	local function v_u_115(p108, p109) -- name: pegNear
		-- upvalues: (ref) v_u_8
		local v110 = v_u_8[1]
		for _, v111 in v_u_8 do
			local v112 = (v111 - p109 + 180) % 360 - 180
			local v113 = math.abs(v112)
			local v114 = (v110 - p109 + 180) % 360 - 180
			if v113 >= math.abs(v114) then
				continue
			end
			v110 = v111
		end
		return p108 + ((v110 - p108 + 180) % 360 - 180)
	end
	local function v_u_133(p116, p117) -- name: landingFor
		-- upvalues: (copy) v_u_115, (copy) v_u_40, (copy) v_u_107, (copy) v_u_46
		local v118 = p116.Rotation
		local v119 = v_u_115(v118, v118 + v_u_40 / 2)
		local v120 = v_u_115(v118, v118)
		local v121 = v_u_115(v118, v118 - v_u_40 / 2)
		local v122, v123 = v_u_107()
		if p117 == "Showcase" then
			return -(v120 - v123 - 2.4), 0, 0, 0
		end
		if p117 == "ForwardBait" then
			return -(v119 - v123 + 1), 0, 1.5, 1.2
		end
		if p117 == "BackwardBait" then
			local v124 = v121 - v123 + 1
			return -v124, v121 + v122 + 2.5 - v124, 0, 0
		end
		local v125 = v121 + v122 + 1
		local v126 = v120 - v123 - 1 - v125
		local v127 = math.max(v126, 0)
		local v128 = v120 + v122 + 1
		local v129 = v119 - v123 - 1 - v128
		local v130 = math.max(v129, 0)
		local v131 = v_u_46:NextNumber() * (v127 + v130)
		local v132
		if v131 < v127 then
			v132 = v125 + v131
		else
			v132 = v128 + v131 - v127
		end
		return -v132, 0, 0, 0
	end
	local function v_u_146(p134, p135, p136, p137) -- name: beginLanding
		-- upvalues: (copy) v_u_133, (ref) v_u_55, (ref) v_u_47, (ref) v_u_54, (ref) v_u_58, (ref) v_u_59, (ref) v_u_60, (ref) v_u_62, (ref) v_u_61, (ref) v_u_64, (ref) v_u_65, (ref) v_u_66, (ref) v_u_68, (ref) v_u_69, (ref) v_u_67
		local v138, v139, v140, v141 = v_u_133(p135, p137)
		local v142 = v_u_55
		local v143 = math.max(v142, 12)
		local v144 = v143 * 2 * 4.5 / 5
		local v145 = v144 + (v138 - (v_u_47 + v144)) % 360
		v_u_54 = "Landing"
		v_u_58 = v_u_47
		v_u_59 = v145
		v_u_60 = p134
		v_u_62 = v139
		v_u_61 = v145 * 5 / (v143 * 2 + 3 * v140)
		v_u_64 = v140
		v_u_65 = v141
		v_u_66 = v140 <= 0 and 1 or 2 * v141 / v140
		v_u_68 = p136
		v_u_69 = p137 == "Showcase"
		v_u_67 = nil
	end
	local function v_u_154() -- name: placeSpinner
		-- upvalues: (copy) v_u_20, (ref) v_u_47, (copy) v_u_23, (copy) v_u_41
		local v147 = v_u_20.Parent.AbsoluteSize
		local v148 = v_u_47
		local v149 = math.rad(v148)
		local v150 = math.cos(v149)
		local v151 = math.sin(v149)
		local v152 = v_u_23 * v_u_20.AbsoluteSize
		local v153 = v152 - Vector2.new(v152.X * v150 - v152.Y * v151, v152.X * v151 + v152.Y * v150)
		v_u_20.Rotation = v_u_47 % 360
		if v147.X > 0 and v147.Y > 0 then
			v_u_20.Position = v_u_41 + UDim2.fromScale(v153.X / v147.X, v153.Y / v147.Y)
		end
	end
	local function v_u_159() -- name: finishLandingNow
		-- upvalues: (ref) v_u_67, (copy) v_u_133, (ref) v_u_47, (ref) v_u_68, (ref) v_u_54, (ref) v_u_58, (ref) v_u_59, (ref) v_u_62, (ref) v_u_65, (copy) v_u_154, (ref) v_u_55, (ref) v_u_57
		if v_u_67 then
			local v155, v156, _, v157 = v_u_133(v_u_67.Slice, v_u_67.Style)
			v_u_47 = v155 - v156 + v157
			v_u_68 = v_u_67.OnLanded
			v_u_67 = nil
		elseif (v_u_54 == "Landing" or v_u_54 == "Creep") and true or v_u_54 == "RollBack" then
			v_u_47 = v_u_58 + v_u_59 - v_u_62 + v_u_65
		end
		v_u_154()
		v_u_54 = "Hold"
		v_u_55 = 0
		v_u_57 = os.clock() + 1
		local v158 = v_u_68
		v_u_68 = nil
		if v158 then
			task.defer(v158)
		end
	end
	local function v_u_186(p160, p161) -- name: advance
		-- upvalues: (ref) v_u_54, (ref) v_u_55, (ref) v_u_47, (ref) v_u_67, (ref) v_u_56, (copy) v_u_146, (ref) v_u_60, (ref) v_u_61, (ref) v_u_64, (ref) v_u_58, (ref) v_u_59, (ref) v_u_65, (ref) v_u_62, (ref) v_u_63, (ref) v_u_69, (ref) v_u_57, (ref) v_u_68, (ref) v_u_66, (copy) p_u_18, (ref) v_u_53, (copy) v_u_24, (copy) v_u_46
		if v_u_54 == "SpinUp" then
			local v162 = v_u_55
			local v163 = 720 - v_u_55
			local v164 = p161 * -4
			v_u_55 = v162 + v163 * (1 - math.exp(v164))
			v_u_47 = v_u_47 + v_u_55 * p161
			if v_u_67 and (v_u_55 >= 684 and p160 - v_u_56 >= 0.8) then
				v_u_146(p160, v_u_67.Slice, v_u_67.OnLanded, v_u_67.Style)
			end
			return
		elseif v_u_54 == "Landing" then
			local v165 = (p160 - v_u_60) / v_u_61
			local v166 = math.min(v165, 1)
			local v167 = v_u_64 * v_u_61
			local v168 = v_u_58
			local v169 = v_u_59 - v167
			local v170 = 1 - v166
			v_u_47 = v168 + v169 * ((1 - v170 ^ 4 - (1 - v170 ^ 5) * 0.6) * 2.5) + v167 * v166
			if v166 == 1 then
				if v_u_65 > 0 then
					v_u_54 = "Creep"
					return
				end
				if v_u_62 > 0 then
					local v171 = p160 + 0.1
					v_u_54 = "RollBack"
					v_u_63 = v171
					return
				end
				v_u_54 = v_u_69 and "Idle" or "Hold"
				v_u_55 = 0
				v_u_57 = p160 + 1
				local v172 = v_u_68
				v_u_68 = nil
				if v172 then
					task.spawn(v172)
				end
			end
			return
		elseif v_u_54 == "Creep" then
			local v173 = (p160 - v_u_60 - v_u_61) / v_u_66
			local v174 = math.clamp(v173, 0, 1)
			v_u_47 = v_u_58 + v_u_59 + v_u_65 * (1 - (1 - v174) ^ 2)
			if v174 == 1 then
				v_u_54 = v_u_69 and "Idle" or "Hold"
				v_u_55 = 0
				v_u_57 = p160 + 1
				local v175 = v_u_68
				v_u_68 = nil
				if v175 then
					task.spawn(v175)
				end
			end
			return
		elseif v_u_54 == "RollBack" then
			local v176 = (p160 - v_u_63) / 1.5
			local v177 = math.clamp(v176, 0, 1)
			local v178 = v_u_58 + v_u_59
			local v179 = v_u_62
			local v180
			if v177 < 0.3333333333333333 then
				local v181 = v177 * 1.5
				v180 = v181 * v181 * (3 - v181 * 2)
			else
				v180 = (1 - (1 - (v177 - 0.3333333333333333) * 1.5) ^ 3) * 0.5 + 0.5
			end
			v_u_47 = v178 - v179 * v180
			if v177 == 1 then
				v_u_54 = v_u_69 and "Idle" or "Hold"
				v_u_55 = 0
				v_u_57 = p160 + 1
				local v182 = v_u_68
				v_u_68 = nil
				if v182 then
					task.spawn(v182)
				end
			end
			return
		elseif v_u_54 == "Hold" then
			if v_u_57 <= p160 then
				v_u_54 = "Idle"
			end
		else
			local v183 = v_u_55
			local v184 = 12 - v_u_55
			local v185 = p161 * -1.5
			v_u_55 = v183 + v184 * (1 - math.exp(v185))
			v_u_47 = v_u_47 + v_u_55 * p161
			if p_u_18 and (v_u_53 <= p160 and #v_u_24 > 0) then
				v_u_54 = "SpinUp"
				v_u_56 = p160
				v_u_67 = {
					["Slice"] = nil,
					["Style"] = "Showcase",
					["OnLanded"] = nil,
					["Slice"] = v_u_24[v_u_46:NextInteger(1, #v_u_24)],
					["OnLanded"] = function() -- name: OnLanded
						-- upvalues: (ref) v_u_53
						v_u_53 = os.clock() + 6
					end
				}
			end
		end
	end
	local function v_u_230(p187, p188) -- name: simulatePointer
		-- upvalues: (copy) v_u_83, (ref) v_u_47, (ref) v_u_48, (ref) v_u_49, (ref) v_u_8, (copy) v_u_98, (ref) v_u_51, (copy) p_u_19, (ref) v_u_54, (ref) v_u_52, (ref) v_u_4, (ref) v_u_50, (copy) v_u_42, (copy) v_u_21, (copy) v_u_44
		local v189 = v_u_83()
		if not v189 or p188 <= 0 then
			return false
		end
		local v190 = v_u_47 - p187
		local v191 = p188 / 0.004166666666666667
		local v192 = math.ceil(v191)
		local v193 = math.abs(v190) / 1
		local v194 = math.ceil(v193)
		local v195 = math.max(v192, v194)
		local v196 = math.clamp(v195, 1, 240)
		local v197 = p188 / v196
		local v198 = false
		for v199 = 1, v196 do
			local v200 = p187 + v190 * v199 / v196
			local v201 = v_u_48
			v_u_49 = v_u_49 + (v_u_48 * -1024 - v_u_49 * 20.48) * v197
			v_u_48 = v_u_48 + v_u_49 * v197
			local v202 = false
			for _, v203 in v_u_8 do
				local v204 = (v200 + v203 + 180) % 360 - 180
				if math.abs(v204) > 90 then
					continue
				end
				local v205, v206, v207 = v_u_98(v189, v204)
				if not v205 then
					continue
				end
				local v208 = v_u_48 - v206
				if math.abs(v208) >= v207 then
					continue
				end
				v202 = true
				local v209
				if v206 <= v201 then
					v209 = v206 + v207
				else
					v209 = v206 - v207
				end
				v_u_48 = v209
			end
			if v202 then
				v198 = true
				local v210 = (v_u_48 - v201) / v197
				v_u_49 = math.clamp(v210, -26.17993877991494, 26.17993877991494)
			elseif v_u_51 and p_u_19 and (v_u_54 == "SpinUp" or (v_u_54 == "Landing" or v_u_54 == "Creep" or v_u_54 == "RollBack")) then
				local v211 = os.clock()
				if v211 - v_u_52 >= 0.035 then
					v_u_52 = v211
					v_u_4.broadcastRouter("RunInterfaceSound", "Halloween Wheel Tick")
				end
			end
			v_u_51 = v202
		end
		if not v198 then
			local v212 = v_u_48
			if math.abs(v212) < 0.00034906585039886593 then
				local v213 = v_u_49
				if math.abs(v213) < 0.00034906585039886593 then
					v_u_48 = 0
					v_u_49 = 0
					if not v_u_50 then
						v_u_50 = true
						local v214 = v_u_48
						local v215 = v_u_42 - math.deg(v214)
						local v216 = 0.31 * v_u_21.AbsoluteSize.Y
						local v217 = math.rad(v215)
						local v218 = Vector2.new(-math.sin(v217), (math.cos(v217))) * v216
						local v219 = v_u_42
						local v220 = math.rad(v219)
						local v221 = v218 - Vector2.new(-math.sin(v220), (math.cos(v220))) * v216
						v_u_21.Rotation = v215
						v_u_21.Position = v_u_44 + UDim2.fromOffset(v221.X, v221.Y)
					end
					return false
				end
			end
		end
		v_u_50 = false
		local v222 = v_u_48
		local v223 = v_u_42 - math.deg(v222)
		local v224 = 0.31 * v_u_21.AbsoluteSize.Y
		local v225 = math.rad(v223)
		local v226 = Vector2.new(-math.sin(v225), (math.cos(v225))) * v224
		local v227 = v_u_42
		local v228 = math.rad(v227)
		local v229 = v226 - Vector2.new(-math.sin(v228), (math.cos(v228))) * v224
		v_u_21.Rotation = v223
		v_u_21.Position = v_u_44 + UDim2.fromOffset(v229.X, v229.Y)
		return true
	end
	local v_u_231 = true
	local function v_u_237(p232) -- name: step
		-- upvalues: (ref) v_u_2, (ref) v_u_47, (copy) v_u_186, (copy) v_u_154, (ref) v_u_231, (copy) v_u_230, (copy) v_u_22, (copy) v_u_45
		if not v_u_2.ReducedMotionEnabled then
			local v233 = os.clock()
			local v234 = v_u_47
			v_u_186(v233, p232)
			v_u_154()
			if v_u_231 or v_u_47 ~= v234 then
				v_u_231 = v_u_230(v234, p232)
			end
			local v235 = v233 * 2 * 3.141592653589793 / 2.5
			local v236 = (1 - math.cos(v235)) / 2
			v_u_22.ImageTransparency = v_u_45 + (1 - v_u_45) * 0.35 * v236
		end
	end
	local v_u_238 = v_u_3.CreateBindingName("UI.HalloweenWheel")
	local v_u_239 = nil
	local v_u_240 = false
	local function v_u_242(p241) -- name: stepWhileNeeded
		-- upvalues: (copy) v_u_237, (ref) v_u_240, (ref) v_u_67, (ref) v_u_54, (ref) v_u_239
		v_u_237(p241)
		if not v_u_240 and (v_u_67 == nil and (v_u_54 ~= "SpinUp" and (v_u_54 ~= "Landing" and v_u_54 ~= "Creep")) and v_u_54 ~= "RollBack" and v_u_239) then
			v_u_239:Disconnect()
			v_u_239 = nil
		end
	end
	v_u_5.Observe(p17, function(p243)
		-- upvalues: (ref) v_u_240, (ref) v_u_239, (ref) v_u_3, (copy) v_u_238, (copy) v_u_242, (ref) v_u_67, (ref) v_u_54
		v_u_240 = p243
		if p243 then
			if not v_u_239 then
				v_u_239 = v_u_3.BindToRenderStep(v_u_238, v_u_242)
				return
			end
		elseif v_u_239 and (v_u_67 == nil and (v_u_54 ~= "SpinUp" and (v_u_54 ~= "Landing" and v_u_54 ~= "Creep")) and v_u_54 ~= "RollBack") then
			v_u_239:Disconnect()
			v_u_239 = nil
		end
	end)
	local v_u_249 = {
		["GetSlices"] = function() -- name: GetSlices
			-- upvalues: (copy) v_u_20
			local v244 = {}
			for _, v245 in v_u_20:GetChildren() do
				if not v245:IsA("GuiObject") then
					continue
				end
				table.insert(v244, v245)
			end
			return v244
		end,
		["Spin"] = function() -- name: Spin
			-- upvalues: (ref) v_u_54, (ref) v_u_56
			if v_u_54 ~= "SpinUp" and (v_u_54 ~= "Landing" and v_u_54 ~= "Creep" and v_u_54 ~= "RollBack") then
				v_u_54 = "SpinUp"
				v_u_56 = os.clock()
			end
		end,
		["LandOn"] = function(p246, p247, p248) -- name: LandOn
			-- upvalues: (ref) v_u_16, (copy) v_u_46, (ref) v_u_67, (ref) v_u_2, (ref) v_u_239, (copy) v_u_159, (ref) v_u_54, (copy) v_u_249
			v_u_67 = {
				["Slice"] = p246,
				["OnLanded"] = p247,
				["Style"] = p248 or v_u_16[v_u_46:NextInteger(1, #v_u_16)]
			}
			if v_u_2.ReducedMotionEnabled or not v_u_239 then
				v_u_159()
			elseif v_u_54 ~= "SpinUp" then
				v_u_249.Spin()
			end
		end,
		["Stop"] = function() -- name: Stop
			-- upvalues: (ref) v_u_54, (ref) v_u_67
			if v_u_54 == "SpinUp" then
				v_u_54 = "Idle"
			end
			v_u_67 = nil
		end,
		["IsSpinning"] = function() -- name: IsSpinning
			-- upvalues: (ref) v_u_54
			return (v_u_54 == "SpinUp" or (v_u_54 == "Landing" or v_u_54 == "Creep")) and true or v_u_54 == "RollBack"
		end
	}
	return v_u_249
end
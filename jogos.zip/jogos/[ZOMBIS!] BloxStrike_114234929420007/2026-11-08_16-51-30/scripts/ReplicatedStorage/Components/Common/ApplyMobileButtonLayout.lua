-- NIGHT Analyzer | ReplicatedStorage.Components.Common.ApplyMobileButtonLayout
-- ModuleScript | 68 linhas | 2277 bytes | hash a9d4094b

local v1 = game:GetService("ReplicatedStorage")
require(v1.Database.Custom.GameStats.UI.Mobile)
local function v_u_18(p2, p3) -- name: ApplyTransparency
	local v4 = math.clamp(p3, 0, 1)
	for _, v5 in ipairs(p2:GetDescendants()) do
		if v5:IsA("ImageLabel") or v5:IsA("ImageButton") then
			local v6 = v5.ImageTransparency
			local v7 = v5:GetAttribute("_MobileHUDBaseImageTransparency")
			if typeof(v7) == "number" then
				v6 = v7
			else
				v5:SetAttribute("_MobileHUDBaseImageTransparency", v6)
			end
			v5.ImageTransparency = v6 + (1 - v6) * v4
			local v8 = v5.BackgroundTransparency
			local v9 = v5:GetAttribute("_MobileHUDBaseBackgroundTransparency")
			if typeof(v9) == "number" then
				v8 = v9
			else
				v5:SetAttribute("_MobileHUDBaseBackgroundTransparency", v8)
			end
			v5.BackgroundTransparency = v8 + (1 - v8) * v4
		elseif v5:IsA("TextLabel") or v5:IsA("TextButton") then
			local v10 = v5.TextTransparency
			local v11 = v5:GetAttribute("_MobileHUDBaseTextTransparency")
			if typeof(v11) == "number" then
				v10 = v11
			else
				v5:SetAttribute("_MobileHUDBaseTextTransparency", v10)
			end
			v5.TextTransparency = v10 + (1 - v10) * v4
			local v12 = v5.BackgroundTransparency
			local v13 = v5:GetAttribute("_MobileHUDBaseBackgroundTransparency")
			if typeof(v13) == "number" then
				v12 = v13
			else
				v5:SetAttribute("_MobileHUDBaseBackgroundTransparency", v12)
			end
			v5.BackgroundTransparency = v12 + (1 - v12) * v4
		else
			if not v5:IsA("UIStroke") then
				continue
			end
			local v14 = v5.Transparency
			local v15 = v5:GetAttribute("_MobileHUDBaseImageTransparency")
			if typeof(v15) == "number" then
				v14 = v15
			else
				v5:SetAttribute("_MobileHUDBaseImageTransparency", v14)
			end
			v5.Transparency = v14 + (1 - v14) * v4
		end
	end
	local v16 = p2.BackgroundTransparency
	local v17 = p2:GetAttribute("_MobileHUDBaseBackgroundTransparency")
	if typeof(v17) == "number" then
		v16 = v17
	else
		p2:SetAttribute("_MobileHUDBaseBackgroundTransparency", v16)
	end
	p2.BackgroundTransparency = v16 + (1 - v16) * v4
end
return function(p19, p20)
	-- upvalues: (copy) v_u_18
	p19.Position = UDim2.fromScale(p20.Position.X, p20.Position.Y)
	p19.Size = UDim2.fromScale(p20.Size.X, p20.Size.Y)
	v_u_18(p19, p20.Transparency)
end
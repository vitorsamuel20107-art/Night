-- NIGHT Analyzer | ReplicatedStorage.Components.Common.VFXLibary.CreateImpact
-- ModuleScript | 282 linhas | 8485 bytes | hash 78dac563

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("HttpService")
local v_u_3 = game:GetService("Players")
local v4 = game:GetService("RunService")
require(v1.Database.Custom.Types)
local v_u_5 = require(v1.Classes.Sound)
local v_u_6 = require(v1.Shared.ObjectPool)
local v_u_7 = require(v1.Shared.DebugFlags)
local v_u_8 = require(v1.Components.Common.VFXLibary.FlashEffect)
local v_u_9 = require(v1.Components.Common.CharacterResolver)
local v_u_10 = require(v1.Components.Common.Participants)
local v_u_11 = require(script.Components.Materials)
local v_u_12 = v1:WaitForChild("Assets"):WaitForChild("Impacts")
local v_u_13 = workspace:WaitForChild("Debris")
local v_u_14 = CFrame.new(0, -10000, 0)
local v_u_15 = {}
local v_u_16 = {}
local v_u_17 = {}
local v_u_18 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_21(p19) -- name: hasParticleEmitter
	for _, v20 in ipairs(p19:GetDescendants()) do
		if not v20:IsA("ParticleEmitter") then
			continue
		end
		return true
	end
	return false
end
local function v_u_26(p22) -- name: getImpactTemplates
	-- upvalues: (copy) v_u_15, (copy) v_u_21
	local v23 = v_u_15[p22]
	if v23 then
		return v23
	end
	local v24 = {}
	for _, v25 in ipairs(p22:GetChildren()) do
		if not (v25:IsA("BasePart") and v_u_21(v25)) then
			continue
		end
		v24[#v24 + 1] = v25
	end
	v_u_15[p22] = v24
	return v24
end
local v_u_27 = {}
local function v_u_30(p28) -- name: resetImpactMarker
	-- upvalues: (copy) v_u_18, (copy) v_u_27, (copy) v_u_14
	for _, v29 in v_u_18[p28] or v_u_27 do
		v29.Emitter:Clear()
	end
	p28.CFrame = v_u_14
end
local function v_u_34(p31) -- name: prepareImpactMarker
	-- upvalues: (copy) v_u_14, (copy) v_u_18
	p31.CFrame = v_u_14
	p31.CollisionGroup = "Debris"
	p31.CanCollide = false
	p31.CanQuery = false
	p31.CanTouch = false
	p31.Anchored = true
	p31.Transparency = 1
	local v32 = {}
	for _, v33 in p31:GetDescendants() do
		if not v33:IsA("ParticleEmitter") then
			continue
		end
		v32[#v32 + 1] = {
			["Emitter"] = v33,
			["Delay"] = v33:GetAttribute("EmitDelay") or 0,
			["Count"] = v33:GetAttribute("EmitCount") or 1
		}
	end
	v_u_18[p31] = v32
end
local function v_u_40(p35) -- name: getImpactHold
	local v36 = 0
	for _, v37 in p35:GetDescendants() do
		if not v37:IsA("ParticleEmitter") then
			continue
		end
		local v38 = (v37:GetAttribute("EmitDelay") or 0) + v37.Lifetime.Max
		v36 = math.max(v36, v38)
	end
	local v39 = v36 + 0.25
	return math.min(v39, 5)
end
local function v_u_45(p41) -- name: getImpactPool
	-- upvalues: (copy) v_u_16, (copy) v_u_6, (copy) v_u_30, (copy) v_u_34, (copy) v_u_13, (copy) v_u_17, (copy) v_u_40
	local v42 = v_u_16[p41]
	if v42 then
		return v42
	end
	local v43 = {
		["InitialSize"] = 4,
		["MaxRetained"] = 60,
		["Reset"] = nil,
		["Prepare"] = nil,
		["InPlace"] = true,
		["StorageParent"] = nil,
		["StorageName"] = "ImpactMarkers",
		["Reset"] = v_u_30,
		["Prepare"] = v_u_34,
		["StorageParent"] = v_u_13
	}
	local v44 = v_u_6.new(p41, v43)
	v_u_16[p41] = v44
	v_u_17[p41] = v_u_40(p41)
	return v44
end
local function v_u_52(p46) -- name: createImpactMarker
	-- upvalues: (copy) v_u_26, (copy) v_u_45, (copy) v_u_17
	debug.profilebegin("VFX.Impact.CreateImpactMarker")
	local v47 = v_u_26(p46)
	if #v47 == 0 then
		debug.profileend()
		return nil, nil, nil, nil
	end
	local v48 = v47[math.random(1, #v47)]
	local v49 = v_u_45(v48)
	local v50, v51 = v49:Acquire()
	debug.profileend()
	return v50, v49, v51, v_u_17[v48]
end
if v4:IsClient() then
	task.defer(function()
		-- upvalues: (copy) v_u_12, (copy) v_u_26, (copy) v_u_45
		for _, v53 in v_u_12:GetChildren() do
			for _, v54 in v_u_26(v53) do
				v_u_45(v54)
				task.wait()
			end
		end
	end)
end
return function(p55, p56, p57, p58, p59, p60, p61, _, p62, p63, p64, p65)
	-- upvalues: (copy) v_u_3, (copy) v_u_12, (copy) v_u_11, (copy) v_u_10, (copy) v_u_2, (copy) v_u_9, (copy) v_u_8, (copy) v_u_7, (copy) v_u_5, (copy) v_u_52, (copy) v_u_18, (copy) v_u_27
	debug.profilebegin("VFX.Impact")
	local v66 = p56 == "Blood Splatter" and v_u_3.LocalPlayer:GetAttribute("SK") and "Blood Splatter_SK" or p56
	local v67 = v_u_12:FindFirstChild(v_u_11[v66] or v66)
	if v67 then
		local v68
		if v66 == "Blood Splatter" and (p55 and p55:IsA("BasePart")) then
			v68 = string.find(string.lower(p55.Name), "head", 1, true) ~= nil
		else
			v68 = false
		end
		local v69 = v68 or p63 ~= nil
		local v70 = p63 == true
		debug.profilebegin("VFX.Impact.ResolveSound")
		local v71 = v67.Name
		if v69 then
			v71 = "Headshot"
			if p55 and (not p60 and p63 == nil) then
				local v72 = p55:FindFirstAncestorOfClass("Model")
				local v73
				if v72 and v72:GetAttribute("Bot") == true then
					v73 = v72:GetAttribute("CombatantId")
				else
					v73 = nil
				end
				if typeof(v73) == "number" then
					local v74 = v_u_10.FromKey(v_u_10.BotKey(v73))
					local v75
					if v74 then
						local v76 = v74:GetAttribute("Armor")
						if typeof(v76) == "string" and v76 ~= "" then
							local v77 = v_u_2.JSONDecode
							local v78 = v_u_2
							local v79
							v79, v75 = pcall(v77, v78, v76)
							if not v79 or typeof(v75) ~= "table" then
								v75 = nil
							end
						else
							v75 = nil
						end
					else
						v75 = nil
					end
					if v75 == nil then
						v70 = false
					else
						v70 = v75.Type == "Kevlar + Helmet"
					end
				elseif v_u_9.isPlayerCharacter(v72) and v72:IsDescendantOf(workspace) then
					local v80 = v_u_9.getPlayerFromCharacter(v72)
					if v80 and v80:IsDescendantOf(v_u_3) then
						local v81 = v80:GetAttribute("Armor")
						local v82
						if typeof(v81) == "string" and v81 ~= "" then
							local v83 = v_u_2.JSONDecode
							local v84 = v_u_2
							local v85
							v85, v82 = pcall(v83, v84, v81)
							if not v85 or typeof(v82) ~= "table" then
								v82 = nil
							end
						else
							v82 = nil
						end
						if v82 == nil then
							v70 = false
						else
							v70 = v82.Type == "Kevlar + Helmet"
						end
					end
				end
			end
			if v70 then
				v71 = "Helmet Headshot"
			end
		end
		local v86 = v_u_9.getCutoutBoard(p55)
		local v87 = v86 and (v_u_9.isCutoutHeadshot(v86, p57) and "Helmet Headshot" or "Blood Splatter") or v71
		debug.profileend()
		if p59 or p65 == true then
			if v_u_7.IsEnabled("WeaponFX") then
				local v88 = warn
				local v89 = tostring(v66)
				local v90 = tostring(p57)
				local v91 = tostring(p59)
				local v92 = p65 == true
				v88(("[WeaponFX][Client][ImpactSound] skipped material=%s pos=%s exit=%s suppressed=%s"):format(v89, v90, v91, (tostring(v92))))
			end
		else
			debug.profilebegin("VFX.Impact.PlaySound")
			local v93 = v_u_8.IsFlashed()
			local v94 = v93 and 0 or 1
			if v_u_7.IsEnabled("WeaponFX") then
				warn(("[WeaponFX][Client][ImpactSound] play material=%s sound=%s pos=%s flashed=%s exit=%s melee=%s volumeMult=%s"):format(tostring(v66), tostring(v87), tostring(p57), tostring(v93), tostring(p59), tostring(p60), (tostring(v94))))
			end
			v_u_5.new("Bullet"):PlaySoundAtPosition({
				["Position"] = nil,
				["Class"] = "Bullet",
				["Name"] = nil,
				["Position"] = p57,
				["Name"] = v87
			}, nil, v94, p61 == true, p62 == true)
			debug.profileend()
		end
		if v66 == "Blood Splatter" and v70 then
			v67 = v_u_12:FindFirstChild("Helmet Headshot") or v67
		end
		if (v66 == "Blood Splatter" or not p60) and p64 ~= true then
			local v_u_95, v_u_96, v_u_97, v98 = v_u_52(v67)
			if not (v_u_95 and (v_u_96 and v_u_97)) then
				debug.profileend()
				return
			end
			debug.profilebegin("VFX.Impact.ParentMarker")
			if v69 and (v66 == "Blood Splatter" and (p55 and p55:IsA("BasePart"))) then
				v_u_95.CFrame = CFrame.new(p55.Position, p55.Position + Vector3.new(0, 1, 0))
			else
				v_u_95.CFrame = CFrame.new(p57, p57 + p58) + p58 * 0.1
			end
			debug.profileend()
			debug.profilebegin("VFX.Impact.EmitParticles")
			for _, v99 in v_u_18[v_u_95] or v_u_27 do
				local v_u_100 = v99.Emitter
				local v_u_101 = v99.Count
				if v99.Delay <= 0 then
					v_u_100:Emit(v_u_101)
				else
					task.delay(v99.Delay, function()
						-- upvalues: (copy) v_u_95, (copy) v_u_96, (copy) v_u_97, (copy) v_u_100, (copy) v_u_101
						if v_u_95.Parent and v_u_96:IsAcquired(v_u_95, v_u_97) then
							v_u_100:Emit(v_u_101)
						end
					end)
				end
			end
			debug.profileend()
			task.delay(v98 or 5, function()
				-- upvalues: (copy) v_u_96, (copy) v_u_95, (copy) v_u_97
				v_u_96:Release(v_u_95, v_u_97)
			end)
		end
	end
	debug.profileend()
end
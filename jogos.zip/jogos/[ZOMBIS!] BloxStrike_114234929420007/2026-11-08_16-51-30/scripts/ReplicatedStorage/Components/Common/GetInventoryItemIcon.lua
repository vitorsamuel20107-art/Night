-- NIGHT Analyzer | ReplicatedStorage.Components.Common.GetInventoryItemIcon
-- ModuleScript | 38 linhas | 1053 bytes | hash 70ae4c04

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Database.Components.Libraries.Skins)
local v_u_3 = {
	["Counter-Terrorists"] = "rbxassetid://120553709154808",
	["Terrorists"] = "rbxassetid://76834532512077"
}
local v_u_4 = {
	["Weapon"] = true,
	["Melee"] = true
}
local function v_u_10(p5) -- name: GetSkinRender
	-- upvalues: (copy) v_u_2
	local v6 = p5.Name
	if typeof(v6) == "string" then
		local v7 = p5.Skin
		local v8 = (typeof(v7) ~= "string" or p5.Skin == "") and "Stock" or p5.Skin
		local v9 = v_u_2.GetSkinInformation(p5.Name, v8)
		if v9 then
			if v9.wearImages and v9.wearImages[1] then
				return v9.wearImages[1].assetId
			else
				return v9.imageAssetId
			end
		else
			return nil
		end
	else
		return nil
	end
end
return function(p11, p12)
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_10
	if p11 and p11.Properties then
		return p11.Name == "Smoke Grenade" and typeof(p12) == "string" and v_u_3[p12] or (v_u_4[p11.Properties.Class] and v_u_10(p11) or p11.Properties.Icon)
	else
		return nil
	end
end
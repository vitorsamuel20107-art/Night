-- NIGHT Analyzer | ReplicatedStorage.Components.Common.InterfaceAnimations.AnimateHalloweenInfoPanel
-- ModuleScript | 159 linhas | 4408 bytes | hash 78c9c8f3

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = require(v1.Controllers.RunServiceController)
local v_u_4 = require(v1.Database.Security.Router)
local v_u_5 = require(script.Parent.GuiShown)
local v_u_6 = require(script.Parent.Glints)
local v_u_7 = NumberRange.new(0.4, 3)
local function v_u_12(p8) -- name: glowsIn
	local v9 = {}
	for _, v10 in p8:GetChildren() do
		if v10.Name ~= "Glow" or not v10:IsA("ImageLabel") then
			continue
		end
		local v11 = {
			["Image"] = v10,
			["Transparency"] = v10.ImageTransparency
		}
		table.insert(v9, v11)
	end
	return v9
end
local function v_u_18(p13) -- name: inReadingOrder
	local v14 = {}
	for _, v15 in p13:GetChildren() do
		if not v15:IsA("GuiObject") then
			continue
		end
		table.insert(v14, v15)
	end
	table.sort(v14, function(p16, p17)
		return p16.AbsolutePosition.X < p17.AbsolutePosition.X
	end)
	return v14
end
return function(p19)
	-- upvalues: (copy) v_u_4, (copy) v_u_18, (copy) v_u_12, (copy) v_u_6, (copy) v_u_2, (copy) v_u_7, (copy) v_u_3, (copy) v_u_5
	local v_u_20 = {}
	local v_u_21 = {}
	local v_u_22 = {}
	local v_u_23 = Random.new()
	local function v33(p24, p25, p26, p27) -- name: hoverable
		-- upvalues: (ref) v_u_4, (copy) v_u_20
		local v_u_28 = {
			["Scale"] = nil,
			["Amount"] = nil,
			["Hovered"] = false,
			["Value"] = 0
		}
		local v29 = p25:FindFirstChild("HoverScale")
		if not v29 then
			v29 = Instance.new("UIScale")
			v29.Name = "HoverScale"
			v29.Parent = p25
		end
		v_u_28.Scale = v29
		v_u_28.Amount = p26
		local function v30() -- name: hover
			-- upvalues: (copy) v_u_28, (ref) v_u_4
			v_u_28.Hovered = true
			v_u_4.broadcastRouter("RunInterfaceSound", "UI Highlight")
		end
		local function v31() -- name: unhover
			-- upvalues: (copy) v_u_28
			v_u_28.Hovered = false
		end
		p24.MouseEnter:Connect(v30)
		p24.MouseLeave:Connect(v31)
		if p27 then
			p27.SelectionGained:Connect(v30)
			p27.SelectionLost:Connect(v31)
		end
		local v32 = v_u_20
		table.insert(v32, v_u_28)
		return v_u_28
	end
	local v34 = p19:FindFirstChild("Rewards")
	if v34 then
		for _, v35 in v_u_18(v34) do
			local v36 = v33(v35, v35:FindFirstChild("Icon") or v35, 0.14, v35)
			local v37 = {
				["Glows"] = v_u_12(v35),
				["Hover"] = v36
			}
			table.insert(v_u_21, v37)
			for _, v38 in v_u_6.Create(v35, 2, v_u_23) do
				table.insert(v_u_22, v38)
			end
		end
	end
	local v39 = p19:FindFirstChild("BuyCandy")
	if v39 then
		for _, v40 in v_u_18(v39) do
			local v41 = v40:FindFirstChild("Amount")
			local v42 = v40:FindFirstChild("Buy")
			local v43 = {
				["Glows"] = v_u_12(v40),
				["Hover"] = v33(v40, v41 or v40, 0.1, v42)
			}
			table.insert(v_u_21, v43)
		end
	end
	local v44 = p19:FindFirstChild("CandyCounter")
	if v44 then
		local v45 = {
			["Glows"] = nil,
			["Hover"] = nil,
			["Glows"] = v_u_12(v44)
		}
		table.insert(v_u_21, v45)
		for _, v46 in v_u_6.Create(v44, 4, v_u_23, 6) do
			table.insert(v_u_22, v46)
		end
	end
	local function v_u_64(p47) -- name: step
		-- upvalues: (ref) v_u_2, (ref) v_u_6, (copy) v_u_22, (copy) v_u_23, (ref) v_u_7, (copy) v_u_20, (copy) v_u_21
		if v_u_2.ReducedMotionEnabled then
			v_u_6.Hide(v_u_22)
		else
			local v48 = os.clock()
			v_u_6.Step(v_u_22, v_u_23, v48, v_u_7)
			local v49 = p47 * -14
			local v50 = 1 - math.exp(v49)
			for _, v51 in v_u_20 do
				local v52 = v51.Hovered and 1 or 0
				if v51.Value == v52 then
					continue
				end
				v51.Value = v51.Value + (v52 - v51.Value) * v50
				local v53 = v52 - v51.Value
				if math.abs(v53) < 0.001 then
					v51.Value = v52
				end
				v51.Scale.Scale = v51.Amount * v51.Value + 1
			end
			for v54, v55 in v_u_21 do
				local v56 = not v55.Hover and 0 or v55.Hover.Value
				for v57, v58 in v55.Glows do
					local v59 = v54 * 0.23 + v57 * 0.15
					local v60 = (v48 / 2.2 + v59) * 2 * 3.141592653589793
					local v61 = (math.sin(v60) + 1) / 2 * 0.22
					local v62 = v58.Image
					local v63 = v58.Transparency + v61 - 0.2 * v56
					v62.ImageTransparency = math.clamp(v63, 0, 1)
				end
			end
		end
	end
	local v_u_65 = v_u_3.CreateBindingName("UI.HalloweenInfoPanel")
	local v_u_66 = nil
	v_u_5.Observe(p19, function(p67)
		-- upvalues: (ref) v_u_66, (ref) v_u_3, (copy) v_u_65, (copy) v_u_64
		if p67 then
			v_u_66 = v_u_3.BindToRenderStep(v_u_65, v_u_64)
		elseif v_u_66 then
			v_u_66:Disconnect()
			v_u_66 = nil
		end
	end)
end
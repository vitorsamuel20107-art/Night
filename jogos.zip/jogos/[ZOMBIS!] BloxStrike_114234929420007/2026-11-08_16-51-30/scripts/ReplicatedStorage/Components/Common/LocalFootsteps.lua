-- NIGHT Analyzer | ReplicatedStorage.Components.Common.LocalFootsteps
-- ModuleScript | 43 linhas | 1114 bytes | hash f96f4a3f

local v1 = {}
local v_u_2 = 0
local v_u_3 = 0.3
local v_u_4 = 0
local v_u_5 = (-1 / 0)
local v_u_6 = os.clock()
function v1.step() -- name: step
	-- upvalues: (ref) v_u_6, (ref) v_u_4, (ref) v_u_2, (ref) v_u_3, (ref) v_u_5
	local v7 = os.clock()
	local v8 = v7 - v_u_6
	v_u_6 = v7
	local v9 = v_u_4
	local v10 = -3 * v8
	local v11 = 3 * v8
	local v12 = math.clamp(v9, v10, v11)
	v_u_4 = v_u_4 - v12
	v_u_2 = (v_u_2 + v8 / v_u_3 + v12) % 2
	local v13 = v7 - v_u_5
	v_u_5 = v7
	if v13 >= 0.15 and v13 <= 0.9 then
		v_u_3 = v_u_3 + (v13 - v_u_3) * 0.5
	end
	local v14 = v_u_2
	v_u_4 = math.round(v14) - v_u_2
end
function v1.getPhase() -- name: getPhase
	-- upvalues: (ref) v_u_6, (ref) v_u_4, (ref) v_u_2, (ref) v_u_3
	local v15 = os.clock()
	local v16 = v15 - v_u_6
	v_u_6 = v15
	local v17 = v_u_4
	local v18 = -3 * v16
	local v19 = 3 * v16
	local v20 = math.clamp(v17, v18, v19)
	v_u_4 = v_u_4 - v20
	v_u_2 = (v_u_2 + v16 / v_u_3 + v20) % 2
	return v_u_2
end
function v1.isStepping(p21) -- name: isStepping
	-- upvalues: (ref) v_u_5, (ref) v_u_3
	return os.clock() - v_u_5 < v_u_3 * p21
end
return table.freeze(v1)
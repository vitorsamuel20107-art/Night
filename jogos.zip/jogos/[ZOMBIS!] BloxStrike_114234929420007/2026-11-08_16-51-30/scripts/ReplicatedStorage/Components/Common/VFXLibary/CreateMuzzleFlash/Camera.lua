-- NIGHT Analyzer | ReplicatedStorage.Components.Common.VFXLibary.CreateMuzzleFlash.Camera
-- ModuleScript | 15 linhas | 371 bytes | hash b036f304

local v_u_1 = require(script.Parent.EmitParticles)
return function(p2, p3)
	-- upvalues: (copy) v_u_1
	debug.profilebegin("VFX.MuzzleFlash.Camera")
	local v4 = p2:FindFirstChild(p3)
	if not v4 then
		debug.profileend()
		return nil
	end
	debug.profilebegin("VFX.MuzzleFlash.Camera.EmitParticles")
	v_u_1(v4)
	debug.profileend()
	debug.profileend()
	return p2.Position
end
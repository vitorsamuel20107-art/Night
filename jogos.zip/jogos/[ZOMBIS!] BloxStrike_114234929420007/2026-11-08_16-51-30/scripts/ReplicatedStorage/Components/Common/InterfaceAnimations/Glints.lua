-- NIGHT Analyzer | ReplicatedStorage.Components.Common.InterfaceAnimations.Glints
-- ModuleScript | 93 linhas | 2267 bytes | hash 1eed5de8

local v1 = {}
local v_u_2 = Color3.fromRGB(255, 244, 200)
local function v_u_11(p3, p4) -- name: createGlint
	-- upvalues: (copy) v_u_2
	local v5 = Instance.new("Frame")
	v5.Name = "Glint"
	v5.AnchorPoint = Vector2.new(0.5, 0.5)
	v5.Size = UDim2.fromOffset(11, 11)
	v5.BackgroundTransparency = 1
	v5.ZIndex = p4
	v5.Visible = false
	local v6 = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0), NumberSequenceKeypoint.new(1, 1) })
	for _, v7 in { false, true } do
		local v8 = Instance.new("Frame")
		v8.AnchorPoint = Vector2.new(0.5, 0.5)
		v8.Position = UDim2.fromScale(0.5, 0.5)
		local v9
		if v7 then
			v9 = UDim2.new(0, 2, 1, 0)
		else
			v9 = UDim2.new(1, 0, 0, 2)
		end
		v8.Size = v9
		v8.BackgroundColor3 = v_u_2
		v8.BorderSizePixel = 0
		v8.ZIndex = p4
		local v10 = Instance.new("UIGradient")
		v10.Rotation = v7 and 90 or 0
		v10.Transparency = v6
		v10.Parent = v8
		v8.Parent = v5
	end
	v5.Parent = p3
	return v5
end
function v1.Create(p12, p13, p14, p15) -- name: Create
	-- upvalues: (copy) v_u_11
	local v16 = {}
	for v17 = 1, p13 do
		local v18
		if p14 then
			v18 = p14:NextNumber(0, 1.8)
		else
			v18 = (v17 - 1) * (1.8 / p13)
		end
		local v19 = {
			["Frame"] = nil,
			["CycleStart"] = nil,
			["Cycle"] = 1.8,
			["Frame"] = v_u_11(p12, p15 or 4),
			["CycleStart"] = os.clock() + v18
		}
		table.insert(v16, v19)
	end
	return v16
end
function v1.Step(p20, p21, p22, p23) -- name: Step
	for _, v24 in p20 do
		local v25 = p22 - v24.CycleStart
		if v24.Cycle <= v25 then
			if p23 then
				v24.CycleStart = p22 + p21:NextNumber(p23.Min, p23.Max)
				v24.Cycle = 1.1
			else
				v24.CycleStart = p22
			end
			v25 = p22 - v24.CycleStart
			v24.Frame.Position = UDim2.fromScale(p21:NextNumber(0.12, 0.88), p21:NextNumber(0.12, 0.8))
		end
		local v26 = v25 / 1.1
		local v27 = v24.Frame
		local v28
		if v26 >= 0 then
			v28 = v26 <= 1
		else
			v28 = false
		end
		v27.Visible = v28
		if not v24.Frame.Visible then
			continue
		end
		local v29 = v26 * 3.141592653589793
		local v30 = math.sin(v29)
		v24.Frame.Size = UDim2.fromOffset(v30 * 11, v30 * 11)
		v24.Frame.Rotation = v26 * 45
	end
end
function v1.Hide(p31) -- name: Hide
	for _, v32 in p31 do
		v32.Frame.Visible = false
	end
end
return v1
-- NIGHT Analyzer | ReplicatedStorage.Components.Common.GetResolvedSkinInformation
-- ModuleScript | 51 linhas | 1266 bytes | hash a5ef91e7

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Database.Components.Libraries.Skins)
local v_u_3 = require(script.Parent.GetWeaponProperties)
local function v_u_8(p4) -- name: CreateFallbackStockInformation
	-- upvalues: (copy) v_u_3
	local v5 = v_u_3
	local v6, v7 = pcall(v5, p4)
	return v6 and v7 and {
		["paintId"] = "stock",
		["type"] = nil,
		["name"] = nil,
		["skin"] = "Stock",
		["rarity"] = "Stock",
		["floatRange"] = nil,
		["floatChances"] = nil,
		["charmImages"] = nil,
		["wearImages"] = nil,
		["supportsStatTrak"] = false,
		["statTrakChance"] = 0,
		["isEnabled"] = true,
		["isMarketplaceVisible"] = false,
		["collection"] = nil,
		["description"] = "Standard issue finish.",
		["caseRarity"] = "Stock",
		["imageAssetId"] = nil,
		["type"] = v7.Class,
		["name"] = p4,
		["floatRange"] = {
			["min"] = 0,
			["max"] = 0.07
		},
		["floatChances"] = {
			{
				["wear"] = "Factory New",
				["chance"] = 100
			}
		},
		["charmImages"] = {},
		["wearImages"] = {},
		["imageAssetId"] = v7.Icon or v7.ReverseIcon
	} or nil
end
return function(p9, p10)
	-- upvalues: (copy) v_u_2, (copy) v_u_8
	local v11 = v_u_2.GetSkinInformation(p9, p10)
	if v11 or p10 ~= "Stock" then
		return v11
	else
		return v_u_8(p9)
	end
end
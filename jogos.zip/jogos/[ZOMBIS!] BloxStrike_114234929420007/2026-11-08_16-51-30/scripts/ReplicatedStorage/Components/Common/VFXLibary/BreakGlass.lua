-- NIGHT Analyzer | ReplicatedStorage.Components.Common.VFXLibary.BreakGlass
-- ModuleScript | 192 linhas | 5282 bytes | hash 191ee963

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("TweenService")
local v3 = game:GetService("Players")
local v_u_4 = workspace:WaitForChild("Debris")
local v_u_5 = require(v1.Controllers.DataController)
local v_u_6 = v3.LocalPlayer
local v_u_7 = require(v1.Shared.Janitor)
local v_u_8 = require(v1.Classes.Sound)
local v_u_9 = Instance.new("WedgePart", script)
v_u_9.BottomSurface = Enum.SurfaceType.Smooth
v_u_9.TopSurface = Enum.SurfaceType.Smooth
v_u_9.Anchored = true
local function v_u_37(p10, p11, p12, p13) -- name: draw3dTriangle
	-- upvalues: (copy) v_u_9
	debug.profilebegin("VFX.BreakGlass.DrawTriangle")
	local v14 = p11 - p10
	local v15 = p12 - p10
	local v16 = p12 - p11
	local v17 = v14:Dot(v14)
	local v18 = v15:Dot(v15)
	local v19 = v16:Dot(v16)
	if v18 < v17 and v19 < v17 then
		local v20 = p12
		p12 = p10
		p10 = p11
		p11 = v20
	elseif v19 < v18 then
		if v17 >= v18 then
			local v21 = p11
			p11 = p10
			p10 = v21
		end
	else
		local v22 = p11
		p11 = p10
		p10 = v22
	end
	local v23 = p10 - p11
	local v24 = p12 - p11
	local v25 = p12 - p10
	local v26 = v24:Cross(v23).Unit
	local v27 = v25:Cross(v26).Unit
	local v28 = v25.Unit
	local v29 = v23:Dot(v27)
	local v30 = math.abs(v29)
	local v31 = v_u_9:Clone()
	local v32 = v23:Dot(v28)
	local v33 = math.abs(v32)
	v31.Size = Vector3.new(0, v30, v33)
	v31.CFrame = CFrame.fromMatrix((p11 + p10) / 2, v26, v27, v28)
	v31.Parent = p13
	local v34 = v_u_9:Clone()
	local v35 = v24:Dot(v28)
	local v36 = math.abs(v35)
	v34.Size = Vector3.new(0, v30, v36)
	v34.CFrame = CFrame.fromMatrix((p11 + p12) / 2, -v26, v27, -v28)
	v34.Parent = p13
	debug.profileend()
	return v31, v34
end
local function v_u_42(p38, p39) -- name: retireSourcePart
	p38.CollisionGroup = "Debris"
	p38.Transparency = 1
	p38.CanCollide = false
	p38.CastShadow = false
	p38.CanQuery = false
	p38.CanTouch = false
	p38.Anchored = true
	p39:Add(p38)
	local v40 = p38.Parent
	if v40 and (v40:IsA("Model") and v40:HasTag("BreakableGlass")) then
		p39:Add(v40)
		for _, v41 in ipairs(v40:GetDescendants()) do
			if not v41:IsA("Decal") then
				continue
			end
			v41:Destroy()
		end
	end
end
local v_u_43 = {
	{ 1, 1 },
	{ 0, 1 },
	{ -1, 1 },
	{ -1, 0 },
	{ -1, -1 },
	{ 0, -1 },
	{ 1, -1 },
	{ 1, 0 }
}
local v_u_44 = TweenInfo.new(0.25, Enum.EasingStyle.Linear, Enum.EasingDirection.In)
return function(p45, p46, p47)
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_7, (copy) v_u_8, (copy) v_u_42, (copy) v_u_43, (copy) v_u_37, (copy) v_u_4, (copy) v_u_2, (copy) v_u_44
	debug.profilebegin("VFX.BreakGlass")
	if p45 then
		debug.profilebegin("VFX.BreakGlass.GetSetting")
		local v48 = v_u_5.Get(v_u_6, "Settings.Video.Presets.Glass Shatter") ~= false
		debug.profileend()
		local v_u_49 = v_u_7.new()
		if v48 then
			debug.profilebegin("VFX.BreakGlass.BuildCornerPoints")
			local v50 = p45.Size
			local v51 = v50.Z > v50.X
			local v52
			if v51 then
				v52 = v50.Z
			else
				v52 = v50.X
			end
			local v53 = v52 * 0.5
			local v54 = v50.Y * 0.5
			local v55 = {}
			for v56, v57 in ipairs(v_u_43) do
				local v58 = v57[1] * v53
				local v59 = v57[2] * v54
				local v60 = p45.CFrame
				local v61
				if v51 then
					v61 = CFrame.new(0, v59, v58)
				else
					v61 = CFrame.new(v58, v59, 0)
				end
				v55[v56] = v60 * v61
			end
			debug.profileend()
			debug.profilebegin("VFX.BreakGlass.CreateFragments")
			for v62, v63 in ipairs(v55) do
				local v64 = v55[v62 + 1] or v55[1]
				local v_u_65, v_u_66 = v_u_37(v63.Position, v64.Position, p46, v_u_4)
				for _, v67 in ipairs({ v_u_65, v_u_66 }) do
					local v68 = p45.Transparency
					v67.Transparency = math.min(v68, 0.6)
					v67.AssemblyLinearVelocity = p47 * 15
					v67.CollisionGroup = "Debris"
					v67.Color = p45.Color
					v67.Anchored = false
				end
				v_u_49:Add(v_u_65)
				v_u_49:Add(v_u_66)
				task.delay(4.75, function()
					-- upvalues: (copy) v_u_49, (ref) v_u_2, (copy) v_u_65, (ref) v_u_44, (copy) v_u_66
					debug.profilebegin("VFX.BreakGlass.FragmentFadeTween")
					v_u_49:Add(v_u_2:Create(v_u_65, v_u_44, {
						["Transparency"] = 1
					})):Play()
					v_u_49:Add(v_u_2:Create(v_u_66, v_u_44, {
						["Transparency"] = 1
					})):Play()
					debug.profileend()
				end)
			end
			debug.profileend()
			debug.profilebegin("VFX.BreakGlass.CleanupSource")
			v_u_8.new("Bullet"):playOneTime({
				["Name"] = "Glass Shattered",
				["Parent"] = nil,
				["Parent"] = p45
			})
			v_u_42(p45, v_u_49)
			debug.profileend()
			task.delay(5, function()
				-- upvalues: (copy) v_u_49
				debug.profilebegin("VFX.BreakGlass.DelayedCleanup")
				v_u_49:Destroy()
				debug.profileend()
			end)
			debug.profileend()
		else
			debug.profilebegin("VFX.BreakGlass.NoShatter.Sound")
			v_u_8.new("Bullet"):PlaySoundAtPosition({
				["Position"] = nil,
				["Class"] = "Bullet",
				["Name"] = "Glass Shattered",
				["Position"] = p46
			})
			debug.profileend()
			debug.profilebegin("VFX.BreakGlass.NoShatter.CleanupSource")
			v_u_42(p45, v_u_49)
			debug.profileend()
			task.delay(0.1, function()
				-- upvalues: (copy) v_u_49
				debug.profilebegin("VFX.BreakGlass.NoShatter.DelayedCleanup")
				v_u_49:Destroy()
				debug.profileend()
			end)
			debug.profileend()
		end
	else
		debug.profileend()
		return
	end
end
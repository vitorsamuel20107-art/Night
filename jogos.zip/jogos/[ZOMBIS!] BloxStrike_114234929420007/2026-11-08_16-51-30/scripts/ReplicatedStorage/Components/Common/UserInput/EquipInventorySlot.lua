-- NIGHT Analyzer | ReplicatedStorage.Components.Common.UserInput.EquipInventorySlot
-- ModuleScript | 67 linhas | 1315 bytes | hash 98fc446a

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Controllers.InventoryController)
local function v_u_12(p3, p4, p5) -- name: getPreferredSpaceOrder
	local v6 = {}
	if p3 ~= 3 then
		for v7 = 1, #p4 do
			if p5 and not p5(p4[v7]) then
				continue
			end
			table.insert(v6, v7)
		end
		return v6
	end
	for v8, v9 in ipairs(p4) do
		if v9.Name == "Zeus x27" then
			continue
		end
		table.insert(v6, v8)
	end
	for v10, v11 in ipairs(p4) do
		if v11.Name ~= "Zeus x27" then
			continue
		end
		table.insert(v6, v10)
	end
	return v6
end
return function(p13, p14)
	-- upvalues: (copy) v_u_2, (copy) v_u_12
	local v15 = v_u_2.getCurrentEquipped()
	local v16 = v_u_2.getInventorySlot(p13)
	if v16 then
		local v17
		if v15 and (v15.Slot or 1) == p13 then
			v17 = v15.Identifier
		else
			v17 = nil
		end
		local v18 = v16._items
		local v19 = v_u_12(p13, v18, p14)
		local v20 = v19[1]
		if v20 then
			if v17 then
				local v21 = table.find
				local v22 = v19
				for v25, v24 in ipairs(v18) do
					if v24.Identifier ~= v17 then
						continue
					end
				end
				local v25 = 0
				local v26 = v21(v19, v25)
				if v26 then
					local v27 = v22[v26 + 1]
					if v27 then
						v20 = v27
					end
				end
			end
		else
			v20 = 0
		end
		if v20 > 0 then
			v_u_2.equip(p13, v20)
		end
	end
end
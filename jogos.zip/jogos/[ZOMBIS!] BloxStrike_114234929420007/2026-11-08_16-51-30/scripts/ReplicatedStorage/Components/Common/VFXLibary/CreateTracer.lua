-- NIGHT Analyzer | ReplicatedStorage.Components.Common.VFXLibary.CreateTracer
-- ModuleScript | 118 linhas | 3481 bytes | hash 92d10f53

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Controllers.RunServiceController)
local v3 = require(v1.Shared.ObjectPool)
local v4 = v1:WaitForChild("Assets"):WaitForChild("Tracers")
local v_u_5 = workspace:WaitForChild("Debris")
local v6 = v4:WaitForChild("Default")
local v_u_8 = v3.new(v6, {
	["InitialSize"] = 8,
	["MaxRetained"] = 48,
	["Reset"] = nil,
	["Reset"] = function(p7) -- name: resetTracer
		p7.TopAttachment.Position = Vector3.new(0, 0, 0)
		p7.BottomAttachment.Position = Vector3.new(0, 0, 0)
		p7.LeftAttachment.Position = Vector3.new(0, 0, 0)
		p7.RightAttachment.Position = Vector3.new(0, 0, 0)
	end
})
local v_u_9 = {}
local v_u_10 = nil
local v_u_11 = {}
local v_u_12 = {}
local function v_u_24(p13) -- name: updateTracers
	-- upvalues: (copy) v_u_9, (copy) v_u_8, (copy) v_u_11, (copy) v_u_12, (ref) v_u_10
	debug.profilebegin("VFX.TracerUpdate")
	for v14 = #v_u_9, 1, -1 do
		local v15 = v_u_9[v14]
		v15.Elapsed = v15.Elapsed + p13
		local v16 = v15.Part
		if v15.Elapsed >= 1 or v16.Parent == nil then
			v_u_8:Release(v15.Part, v15.Lease)
			v_u_9[v14] = v_u_9[#v_u_9]
			v_u_9[#v_u_9] = nil
		else
			local v17 = 5 + 995 * (v15.Elapsed / 1)
			if v15.MaxDistance == nil or v15.MaxDistance > v17 then
				v_u_11[#v_u_11 + 1] = v16
				v_u_12[#v_u_12 + 1] = CFrame.new(v15.Origin + v15.Direction * v17)
				local v18 = v17 / 50
				local v19 = 0.1 * math.min(v18, 1)
				if v15.HalfWidth == v19 then
					continue
				end
				v15.HalfWidth = v19
				v16.TopAttachment.Position = Vector3.new(0, v19, 0)
				local v20 = v16.BottomAttachment
				local v21 = -v19
				v20.Position = Vector3.new(0, v21, 0)
				local v22 = v16.LeftAttachment
				local v23 = -v19
				v22.Position = Vector3.new(v23, 0, 0)
				v16.RightAttachment.Position = Vector3.new(v19, 0, 0)
			else
				v_u_8:Release(v15.Part, v15.Lease)
				v_u_9[v14] = v_u_9[#v_u_9]
				v_u_9[#v_u_9] = nil
			end
		end
	end
	if #v_u_11 > 0 then
		workspace:BulkMoveTo(v_u_11, v_u_12, Enum.BulkMoveMode.FireCFrameChanged)
		table.clear(v_u_11)
		table.clear(v_u_12)
	end
	if #v_u_9 == 0 and v_u_10 then
		v_u_10:Disconnect()
		v_u_10 = nil
	end
	debug.profileend()
end
return function(p25, p26, p27, p28)
	-- upvalues: (copy) v_u_8, (copy) v_u_5, (copy) v_u_9, (ref) v_u_10, (copy) v_u_2, (copy) v_u_24
	debug.profilebegin("VFX.Tracer")
	if p26 and (p28 ~= true or p25 > 5) then
		debug.profilebegin("VFX.Tracer.Acquire")
		local v29, v30 = v_u_8:Acquire()
		v29.CollisionGroup = "Debris"
		v29.CanCollide = false
		v29.CanQuery = false
		v29.CanTouch = false
		v29.Anchored = true
		debug.profileend()
		debug.profilebegin("VFX.Tracer.Parent")
		v29.TopAttachment.Position = Vector3.new(0, 0, 0)
		v29.BottomAttachment.Position = Vector3.new(0, 0, 0)
		v29.LeftAttachment.Position = Vector3.new(0, 0, 0)
		v29.RightAttachment.Position = Vector3.new(0, 0, 0)
		v29.CFrame = CFrame.new(p26 + p27 * 5)
		v29.Parent = v_u_5
		debug.profileend()
		local v31 = v_u_9
		local v32 = {
			["Part"] = nil,
			["Lease"] = nil,
			["Origin"] = nil,
			["Direction"] = nil,
			["Elapsed"] = 0,
			["MaxDistance"] = nil,
			["Part"] = v29,
			["Lease"] = v30,
			["Origin"] = p26,
			["Direction"] = p27
		}
		local v33
		if p28 == true then
			v33 = math.max(p25, 0)
		else
			v33 = nil
		end
		v32.MaxDistance = v33
		table.insert(v31, v32)
		if not v_u_10 then
			v_u_10 = v_u_2.BindToHeartbeat("VFX.TracerUpdater", v_u_24)
		end
		debug.profileend()
	else
		debug.profileend()
	end
end
-- NIGHT Analyzer | ReplicatedStorage.Components.Common.CalculateGridRenderCount
-- ModuleScript | 34 linhas | 1030 bytes | hash c91709f4

return function(p1)
	local v2 = p1:FindFirstChildOfClass("UIGridLayout")
	if not v2 then
		return 50
	end
	local v3 = p1.AbsoluteSize.X
	local v4 = p1.AbsoluteSize.Y
	local v5 = v2.CellSize.X.Scale * v3 + v2.CellSize.X.Offset
	local v6 = v2.CellSize.Y.Scale * v4 + v2.CellSize.Y.Offset
	local v7 = v2.CellPadding.X.Scale * v3 + v2.CellPadding.X.Offset
	local v8 = v2.CellPadding.Y.Scale * v4 + v2.CellPadding.Y.Offset
	local v9 = p1:FindFirstChildOfClass("UIPadding")
	if v9 then
		v3 = v3 - ((v9.PaddingLeft.Scale + v9.PaddingRight.Scale) * v3 + v9.PaddingLeft.Offset + v9.PaddingRight.Offset)
		v4 = v4 - ((v9.PaddingTop.Scale + v9.PaddingBottom.Scale) * v4 + v9.PaddingTop.Offset + v9.PaddingBottom.Offset)
	end
	local v10
	if v5 + v7 > 0 then
		local v11 = (v3 + v7) / (v5 + v7)
		local v12 = math.floor(v11)
		v10 = math.max(1, v12)
	else
		v10 = 1
	end
	local v13
	if v6 + v8 > 0 then
		local v14 = (v4 + v8) / (v6 + v8)
		local v15 = math.floor(v14)
		v13 = math.max(1, v15)
	else
		v13 = 1
	end
	return (v13 + 1) * v10
end
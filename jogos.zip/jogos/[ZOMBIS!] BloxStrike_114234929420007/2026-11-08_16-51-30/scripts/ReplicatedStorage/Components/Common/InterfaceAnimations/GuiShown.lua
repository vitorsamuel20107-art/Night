-- NIGHT Analyzer | ReplicatedStorage.Components.Common.InterfaceAnimations.GuiShown
-- ModuleScript | 39 linhas | 886 bytes | hash 38fbc495

local v_u_11 = {
	["IsShown"] = function(p1) -- name: IsShown
		while p1 and p1:IsA("GuiObject") do
			if not p1.Visible then
				return false
			end
			p1 = p1.Parent
		end
		return true
	end,
	["Observe"] = function(p2, p_u_3) -- name: Observe
		-- upvalues: (copy) v_u_11
		local v_u_4 = v_u_11.IsShown(p2)
		local v_u_5 = p2
		local v_u_6 = {}
		while p2 and p2:IsA("GuiObject") do
			local v7 = p2:GetPropertyChangedSignal("Visible")
			local function v9()
				-- upvalues: (ref) v_u_11, (copy) v_u_5, (ref) v_u_4, (copy) p_u_3
				local v8 = v_u_11.IsShown(v_u_5)
				if v8 ~= v_u_4 then
					v_u_4 = v8
					p_u_3(v_u_4)
				end
			end
			table.insert(v_u_6, v7:Connect(v9))
			p2 = p2.Parent
		end
		p_u_3(v_u_4)
		return function()
			-- upvalues: (copy) v_u_6
			for _, v10 in v_u_6 do
				v10:Disconnect()
			end
			table.clear(v_u_6)
		end
	end
}
return table.freeze(v_u_11)
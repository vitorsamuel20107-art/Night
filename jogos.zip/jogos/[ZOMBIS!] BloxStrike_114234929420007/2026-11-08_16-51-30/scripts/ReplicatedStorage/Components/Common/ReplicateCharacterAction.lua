-- NIGHT Analyzer | ReplicatedStorage.Components.Common.ReplicateCharacterAction
-- ModuleScript | 24 linhas | 667 bytes | hash 657bc48a

local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2.Components.Common.CharacterGeneration)
local v_u_4 = require(v2.Database.Components.CharacterActions)
local v_u_5 = require(v2.Database.Security.Remotes)
local v_u_6 = v1.LocalPlayer
return function(p7)
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_6, (copy) v_u_5
	local v8 = v_u_4.ToId(p7)
	if v8 then
		local v9 = v_u_3.Get(v_u_6.Character)
		if v9 ~= nil then
			v_u_5.Character.Action.Send({
				["UserId"] = 0,
				["Generation"] = nil,
				["ActionId"] = nil,
				["Generation"] = v9,
				["ActionId"] = v8
			})
		end
	else
		return
	end
end
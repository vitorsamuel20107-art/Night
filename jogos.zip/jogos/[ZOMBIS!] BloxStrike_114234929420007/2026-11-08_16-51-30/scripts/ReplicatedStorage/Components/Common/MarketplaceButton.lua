-- NIGHT Analyzer | ReplicatedStorage.Components.Common.MarketplaceButton
-- ModuleScript | 136 linhas | 4370 bytes | hash 1c08ac9a

local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = require(v2.Database.Security.Router)
local v_u_5 = table.freeze({
	["hoverSizeMultiplier"] = 1.1
})
local v_u_6 = Enum.EasingDirection.Out
local v_u_7 = Enum.EasingStyle.Quad
local v_u_8 = {}
v_u_8.__index = v_u_8
local function v_u_10(p9) -- name: isGuiVisible
	while p9 do
		if p9:IsA("GuiObject") and not p9.Visible then
			return false
		end
		if p9:IsA("LayerCollector") and not p9.Enabled then
			return false
		end
		p9 = p9.Parent
	end
	return true
end
function v_u_8.new(p_u_11, p12) -- name: new
	-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_6, (copy) v_u_7, (copy) v_u_10, (copy) v_u_3, (copy) v_u_4, (copy) v_u_1
	local v_u_13 = table.clone(p12 or {})
	for v14, v15 in v_u_5 do
		if v_u_13[v14] ~= nil then
			continue
		end
		v_u_13[v14] = v15
	end
	local v16 = v_u_8
	local v_u_17 = setmetatable({
		["Instance"] = nil,
		["_isHovering"] = false,
		["Instance"] = p_u_11
	}, v16)
	local v_u_18 = p_u_11:GetAttribute("OriginalSize") or p_u_11.Size
	if p_u_11:GetAttribute("OriginalSize") then
		p_u_11.Size = v_u_18
	else
		p_u_11:SetAttribute("OriginalSize", v_u_18)
	end
	local v_u_19 = v_u_13.hoverSizeMultiplier
	if v_u_19 then
		v_u_19 = UDim2.new(v_u_18.X.Scale * v_u_13.hoverSizeMultiplier, v_u_18.X.Offset * v_u_13.hoverSizeMultiplier, v_u_18.Y.Scale * v_u_13.hoverSizeMultiplier, v_u_18.Y.Offset * v_u_13.hoverSizeMultiplier)
	end
	v_u_17._originalSize = v_u_18
	v_u_17._hasHoverSize = v_u_19 ~= nil
	local function v_u_26() -- name: shouldRestoreHoverState
		-- upvalues: (copy) v_u_17, (copy) p_u_11, (ref) v_u_10, (ref) v_u_3
		if not (v_u_17._isHovering and (p_u_11:IsDescendantOf(game) and v_u_10(p_u_11))) then
			return false
		end
		local v20 = v_u_3:GetMouseLocation()
		local v21 = p_u_11
		local v22 = Vector2.new(v20.X, v20.Y)
		local v23 = v21.AbsolutePosition
		local v24 = v21.AbsoluteSize
		local v25
		if v22.X >= v23.X and (v22.X <= v23.X + v24.X and v22.Y >= v23.Y) then
			v25 = v22.Y <= v23.Y + v24.Y
		else
			v25 = false
		end
		return v25
	end
	if v_u_19 or v_u_13.onMouseEnter then
		v_u_17._mouseEnter = p_u_11.MouseEnter:Connect(function(p27, p28)
			-- upvalues: (copy) v_u_17, (copy) v_u_19, (copy) p_u_11, (ref) v_u_6, (ref) v_u_7, (copy) v_u_13, (ref) v_u_4
			v_u_17._isHovering = true
			if v_u_19 then
				p_u_11:TweenSize(v_u_19, v_u_6, v_u_7, 0.15, true, nil)
			end
			if v_u_13.onMouseEnter then
				v_u_13.onMouseEnter(p27, p28)
			end
			v_u_4.broadcastRouter("RunInterfaceSound", "Button Hover")
		end)
	end
	if v_u_19 or v_u_13.onMouseLeave then
		v_u_17._mouseLeave = p_u_11.MouseLeave:Connect(function(p29, p30)
			-- upvalues: (copy) v_u_17, (copy) v_u_19, (copy) v_u_18, (copy) p_u_11, (ref) v_u_6, (ref) v_u_7, (copy) v_u_13
			v_u_17._isHovering = false
			if v_u_19 then
				p_u_11:TweenSize(v_u_18, v_u_6, v_u_7, 0.15, true, nil)
			end
			if v_u_13.onMouseLeave then
				v_u_13.onMouseLeave(p29, p30)
			end
		end)
	end
	if v_u_13.onActivated then
		v_u_17._activated = p_u_11.Activated:Connect(function()
			-- upvalues: (ref) v_u_4, (copy) v_u_19, (copy) v_u_18, (copy) v_u_17, (copy) v_u_26, (copy) p_u_11, (ref) v_u_6, (ref) v_u_7, (ref) v_u_1, (copy) v_u_13
			v_u_4.broadcastRouter("RunInterfaceSound", "Button Click")
			if v_u_19 then
				p_u_11:TweenSize(v_u_18, v_u_6, v_u_7, 0.075, true, function()
					-- upvalues: (ref) v_u_17, (ref) v_u_26, (ref) v_u_19, (ref) p_u_11, (ref) v_u_6, (ref) v_u_7
					v_u_17._isHovering = v_u_26()
					if v_u_17._isHovering then
						p_u_11:TweenSize(v_u_19, v_u_6, v_u_7, 0.075, true, nil)
					end
				end)
			end
			local v31 = p_u_11:GetFullName()
			if not v31:find("GlobalMarketPlace") or (v31:find("Close") or (v31:find("Pin") or (v31:find("Top") or v_u_1.LocalPlayer:GetAttribute("PinVerified")))) then
				v_u_13.onActivated()
			end
		end)
	end
	v_u_17._destroying = p_u_11.Destroying:Once(function()
		-- upvalues: (copy) v_u_17
		v_u_17:Destroy()
	end)
	return v_u_17
end
function v_u_8.Destroy(p32) -- name: Destroy
	if p32._hasHoverSize then
		p32.Instance.Size = p32._originalSize
	end
	for _, v33 in {
		"_mouseEnter",
		"_mouseLeave",
		"_activated",
		"_destroying"
	} do
		local v34 = p32[v33]
		if not v34 then
			continue
		end
		v34:Disconnect()
	end
end
return v_u_8
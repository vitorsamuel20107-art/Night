-- NIGHT Analyzer | ReplicatedStorage.Components.Common.VFXLibary.CreateBloodSplatter
-- ModuleScript | 1 linhas | 25 bytes | hash 599071fd

return function(_, _) end
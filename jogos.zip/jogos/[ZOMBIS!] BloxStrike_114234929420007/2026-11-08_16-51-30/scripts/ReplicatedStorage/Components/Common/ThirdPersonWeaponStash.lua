-- NIGHT Analyzer | ReplicatedStorage.Components.Common.ThirdPersonWeaponStash
-- ModuleScript | 47 linhas | 1096 bytes | hash 59b69203

local v_u_1 = game:GetService("Workspace")
local v2 = {}
local v_u_3 = CFrame.new(0, 10000, 0)
local v_u_4 = nil
function v2.Park(p5, p6) -- name: Park
	-- upvalues: (copy) v_u_3, (ref) v_u_4, (copy) v_u_1
	for _, v7 in p6 do
		local v8 = v7.Part1
		v7:Destroy()
		if not v8 then
			continue
		end
		v8.Anchored = true
	end
	table.clear(p6)
	p5:PivotTo(v_u_3)
	local v9 = v_u_4
	if not v9 or v9.Parent ~= v_u_1 then
		v9 = Instance.new("Folder")
		v9.Name = "ThirdPersonWeaponStash"
		v9.Archivable = false
		v9.Parent = v_u_1
		v_u_4 = v9
	end
	p5.Parent = v9
end
function v2.PoseForJoint(p10, p11, p12, p13, p14) -- name: PoseForJoint
	if p11.Anchored then
		p10:PivotTo(p12.CFrame * p13 * p14:Inverse() * p11.CFrame:Inverse() * p10:GetPivot())
	end
end
function v2.Release(p15) -- name: Release
	for _, v16 in p15 do
		local v17 = v16.Part1
		if not v17 then
			continue
		end
		v17.Anchored = false
	end
end
function v2.TryUnpark(p_u_18, p_u_19) -- name: TryUnpark
	return pcall(function()
		-- upvalues: (copy) p_u_18, (copy) p_u_19
		p_u_18.Parent = p_u_19
	end)
end
return table.freeze(v2)
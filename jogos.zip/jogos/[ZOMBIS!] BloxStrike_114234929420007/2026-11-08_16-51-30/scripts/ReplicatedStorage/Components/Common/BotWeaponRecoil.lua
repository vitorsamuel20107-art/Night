-- NIGHT Analyzer | ReplicatedStorage.Components.Common.BotWeaponRecoil
-- ModuleScript | 83 linhas | 2069 bytes | hash ee458091

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Shared.Spring)
local v_u_3 = require(script.Parent.GetWeaponProperties)
local v_u_4 = {}
v_u_4.__index = v_u_4
function v_u_4.new(p5) -- name: new
	-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_4
	local v6 = v_u_3(p5)
	local v7
	if v6 then
		v7 = v6.Recoil
	else
		v7 = v6
	end
	if v7 then
		local v8 = v7.Pattern
		if type(v8) == "function" then
			local v9 = {
				["Properties"] = nil,
				["Pattern"] = nil,
				["Spring"] = nil,
				["Value"] = nil,
				["PatternTime"] = 0,
				["RecoveryTime"] = 0,
				["Properties"] = v6,
				["Pattern"] = v7.Pattern(v6),
				["Spring"] = v_u_2.new(v7.Damper, v7.Speed, Vector2.zero),
				["Value"] = Vector2.zero
			}
			local v10 = v_u_4
			return setmetatable(v9, v10)
		end
	end
	return nil
end
function v_u_4.Step(p11, p12) -- name: Step
	local v13
	if p11.LastUpdate then
		local v14 = p12 - p11.LastUpdate
		v13 = math.max(0, v14)
	else
		v13 = 0
	end
	local v15
	if p11.LastShot then
		v15 = p11.LastShot + p11.Properties.FireRate
	else
		v15 = p12
	end
	local v16 = p11.LastUpdate or p12
	local v17 = p12 - math.max(v16, v15)
	local v18 = math.max(0, v17)
	local v19 = p11.Properties.Recoil.RecoverySpeed
	if v18 > 0 then
		local v20 = p11.Value.Magnitude
		local v21
		if v20 > 0 then
			local v22 = p11.Value
			local v23 = 1 - v19 * v18 / v20
			v21 = v22 * math.max(0, v23)
		else
			v21 = p11.Value
		end
		p11.Value = v21
		local v24 = p11.PatternTime - p11.RecoveryTime * v19 * v18
		p11.PatternTime = math.max(0, v24)
	end
	p11.Spring:setGoal(p11.Value)
	p11.Spring:update(v13)
	p11.LastUpdate = p12
	local v25 = p11.Spring:getPosition()
	local v26 = p11.Properties.Recoil.Scale
	return v25 * math.rad(v26) * p11.Properties.Recoil.CameraScale
end
function v_u_4.OnShot(p27, p28) -- name: OnShot
	p27:Step(p28)
	p27.LastShot = p28
	p27.PatternTime = p27.PatternTime + p27.Properties.FireRate
	p27.RecoveryTime = p27.PatternTime
	p27.Value = p27.Pattern(p27.PatternTime)
	p27.Spring:setGoal(p27.Value)
end
return table.freeze(v_u_4)
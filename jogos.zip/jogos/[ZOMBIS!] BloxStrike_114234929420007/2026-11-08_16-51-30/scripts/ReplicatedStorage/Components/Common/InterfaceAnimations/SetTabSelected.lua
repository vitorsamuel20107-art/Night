-- NIGHT Analyzer | ReplicatedStorage.Components.Common.InterfaceAnimations.SetTabSelected
-- ModuleScript | 58 linhas | 1720 bytes | hash 31ed66f0

local v_u_1 = Color3.fromRGB(125, 206, 243)
local function v_u_7(p2) -- name: createHighlight
	local v3 = Instance.new("Frame")
	v3.Name = "Selected"
	v3.Size = UDim2.fromScale(1, 1)
	v3.BackgroundColor3 = Color3.new(1, 1, 1)
	v3.BorderSizePixel = 0
	v3.ZIndex = -2
	v3.ClipsDescendants = true
	v3.Visible = false
	local v4 = Instance.new("UIGradient")
	v4.Rotation = -90
	v4.Color = ColorSequence.new(Color3.fromRGB(195, 195, 195), Color3.fromRGB(53, 53, 53))
	v4.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.34375),
		NumberSequenceKeypoint.new(0.0857143, 0.46875),
		NumberSequenceKeypoint.new(0.32, 0.7),
		NumberSequenceKeypoint.new(0.704762, 0.88125),
		NumberSequenceKeypoint.new(1, 1)
	})
	v4.Parent = v3
	local v5 = Instance.new("ImageLabel")
	v5.Name = "Pattern"
	v5.BackgroundColor3 = Color3.new(1, 1, 1)
	v5.BackgroundTransparency = 1
	v5.BorderSizePixel = 0
	v5.Image = "rbxassetid://102274428506900"
	v5.ImageTransparency = 0.21
	v5.ScaleType = Enum.ScaleType.Fit
	v5.Size = UDim2.fromScale(1.69762695, 3.10517287)
	v5.Position = UDim2.fromScale(-0.348813593, -0.50142777)
	v5.ZIndex = 0
	v5.Parent = v3
	local v6 = Instance.new("UIGradient")
	v6.Rotation = -90
	v6.Transparency = NumberSequence.new(0, 1)
	v6.Parent = v5
	v3.Parent = p2
	return v3
end
return function(p8, p9)
	-- upvalues: (copy) v_u_7, (copy) v_u_1
	if p8:GetAttribute("UnselectedColor") == nil then
		p8:SetAttribute("UnselectedColor", p8.BackgroundColor3)
	end
	local v10 = p8:FindFirstChild("Selected")
	if not (v10 and v10:IsA("GuiObject")) then
		v10 = v_u_7(p8)
	end
	v10.Visible = p9
	local v11
	if p9 then
		v11 = v_u_1
	else
		v11 = p8:GetAttribute("UnselectedColor")
	end
	p8.BackgroundColor3 = v11
end
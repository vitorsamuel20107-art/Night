-- NIGHT Analyzer | ReplicatedStorage.Components.Common.CharacterResolver
-- ModuleScript | 350 linhas | 8908 bytes | hash f77200bd

local v_u_1 = game:GetService("Players")
local v_u_2 = require(script.Parent.CharacterPresentationDescriptor)
local v_u_79 = {
	["getRootPart"] = function(p3) -- name: getRootPart
		local v4
		if p3 then
			v4 = p3:FindFirstChild("HumanoidRootPart")
		else
			v4 = nil
		end
		if v4 and v4:IsA("BasePart") then
			return v4
		else
			return nil
		end
	end,
	["getHead"] = function(p5) -- name: getHead
		local v6
		if p5 then
			v6 = p5:FindFirstChild("Head")
		else
			v6 = nil
		end
		if v6 and v6:IsA("BasePart") then
			return v6
		else
			return nil
		end
	end,
	["pivotCharacter"] = function(p7, p8) -- name: pivotCharacter
		-- upvalues: (copy) v_u_79
		local v9 = v_u_79.getRootPart(p7)
		if v9 and p7.PrimaryPart ~= v9 then
			p7.PrimaryPart = v9
		end
		p7:PivotTo(p8)
	end,
	["pivotCharacterTo"] = function(p10, p11) -- name: pivotCharacterTo
		-- upvalues: (copy) v_u_79
		local v12 = v_u_79.getRootPart(p10)
		if v12 then
			v_u_79.pivotCharacter(p10, v12.CFrame.Rotation + p11)
		end
	end,
	["getAnimationController"] = function(p13) -- name: getAnimationController
		local v14
		if p13 then
			v14 = p13:FindFirstChild("AnimationController")
		else
			v14 = nil
		end
		if v14 and v14:IsA("AnimationController") then
			return v14
		else
			return nil
		end
	end,
	["getOrCreateAnimator"] = function(p15) -- name: getOrCreateAnimator
		-- upvalues: (copy) v_u_79
		local v16 = v_u_79.getAnimationController(p15)
		if not v16 then
			v16 = Instance.new("AnimationController")
			v16.Name = "AnimationController"
			v16.Parent = p15
		end
		local v17 = v16:FindFirstChild("Animator")
		if not v17 then
			local v18 = Instance.new("Animator")
			v18.Parent = v16
			return v18
		end
		local v19 = v17:IsA("Animator")
		local v20 = ("Expected %*.Animator to be an Animator"):format((v16:GetFullName()))
		assert(v19, v20)
		return v17
	end,
	["getAnimator"] = function(p21) -- name: getAnimator
		-- upvalues: (copy) v_u_79
		local v22 = v_u_79.getAnimationController(p21)
		local v23
		if v22 then
			v23 = v22:FindFirstChild("Animator")
		else
			v23 = nil
		end
		if v23 and v23:IsA("Animator") then
			return v23
		else
			return nil
		end
	end,
	["getCameraPart"] = function(p24) -- name: getCameraPart
		local v25
		if p24 then
			v25 = p24:FindFirstChild("CameraPart")
		else
			v25 = nil
		end
		if v25 and v25:IsA("BasePart") then
			return v25
		else
			return nil
		end
	end,
	["createCameraPart"] = function(p26) -- name: createCameraPart
		-- upvalues: (copy) v_u_79
		local v27 = not p26:FindFirstChild("CameraPart")
		local v28 = ("%* already has a CameraPart"):format((p26:GetFullName()))
		assert(v27, v28)
		local v29 = v_u_79.getRootPart(p26)
		local v30 = ("%* has no HumanoidRootPart"):format((p26:GetFullName()))
		local v31 = assert(v29, v30)
		local v32 = v_u_79.getHead(p26)
		local v33 = ("%* has no Head"):format((p26:GetFullName()))
		local v34 = assert(v32, v33)
		local v35 = Instance.new("Part")
		v35.Name = "CameraPart"
		v35.Size = Vector3.new(0.2, 0.2, 0.2)
		v35.Transparency = 1
		v35.CanCollide = false
		v35.CanTouch = false
		v35.CanQuery = false
		v35.CastShadow = false
		v35.Massless = true
		v35.CFrame = CFrame.new(v34.Position)
		v35.Parent = p26
		local v36 = Instance.new("Weld")
		v36.Name = "CameraPartWeld"
		v36.Part0 = v31
		v36.Part1 = v35
		v36.C0 = CFrame.new(v31.CFrame:PointToObjectSpace(v34.Position))
		v36.Parent = v35
		return v35
	end,
	["resolve"] = function(p37) -- name: resolve
		-- upvalues: (copy) v_u_79
		if not p37 then
			return nil
		end
		local v38 = v_u_79.getRootPart(p37)
		local v39 = v_u_79.getCameraPart(p37)
		return v38 and v39 and {
			["Character"] = p37,
			["RootPart"] = v38,
			["Head"] = v_u_79.getHead(p37),
			["CameraPart"] = v39,
			["AnimationController"] = v_u_79.getAnimationController(p37),
			["Animator"] = v_u_79.getAnimator(p37)
		} or nil
	end,
	["getPlayerFromCharacter"] = function(p40) -- name: getPlayerFromCharacter
		-- upvalues: (copy) v_u_1, (copy) v_u_2
		if p40 == nil then
			return nil
		else
			local v41 = v_u_1:GetPlayerFromCharacter(p40)
			if v41 == nil then
				local v42 = p40:GetAttribute(v_u_2.OwnerUserIdAttribute)
				if typeof(v42) == "number" then
					return v_u_1:GetPlayerByUserId(v42)
				else
					return nil
				end
			else
				return v41
			end
		end
	end,
	["getPlayerFromInstance"] = function(p43) -- name: getPlayerFromInstance
		-- upvalues: (copy) v_u_79
		if p43 == nil then
			return nil
		end
		local v44 = p43:FindFirstAncestorOfClass("Model")
		while v44 ~= nil do
			local v45 = v_u_79.getPlayerFromCharacter(v44)
			if v45 ~= nil then
				return v45
			end
			v44 = v44:FindFirstAncestorOfClass("Model")
		end
		return nil
	end,
	["getPlayerCharacter"] = function(p46) -- name: getPlayerCharacter
		local v47
		if p46 then
			v47 = p46.Character
		else
			v47 = nil
		end
		if v47 and v47.Parent then
			return v47
		else
			return nil
		end
	end,
	["getLocalCharacter"] = function() -- name: getLocalCharacter
		-- upvalues: (copy) v_u_79, (copy) v_u_1
		return v_u_79.getPlayerCharacter(v_u_1.LocalPlayer)
	end,
	["observeCharacter"] = function(p48, p_u_49) -- name: observeCharacter
		-- upvalues: (copy) v_u_79
		local v_u_50 = v_u_79.getPlayerCharacter(p48)
		local v_u_51 = p_u_49(v_u_50, nil)
		local function v54(p52) -- name: setCharacter
			-- upvalues: (ref) v_u_50, (ref) v_u_51, (copy) p_u_49
			if p52 ~= v_u_50 then
				local v53 = v_u_50
				v_u_50 = p52
				if v_u_51 then
					v_u_51()
				end
				v_u_51 = p_u_49(p52, v53)
			end
		end
		local v_u_55 = p48.CharacterAdded:Connect(v54)
		local v_u_58 = p48.CharacterRemoving:Connect(function(p56)
			-- upvalues: (ref) v_u_50, (ref) v_u_51, (copy) p_u_49
			if p56 == v_u_50 then
				if v_u_50 == nil then
					return
				end
				local v57 = v_u_50
				v_u_50 = nil
				if v_u_51 then
					v_u_51()
				end
				v_u_51 = p_u_49(nil, v57)
			end
		end)
		return function()
			-- upvalues: (copy) v_u_55, (copy) v_u_58, (ref) v_u_51
			v_u_55:Disconnect()
			v_u_58:Disconnect()
			if v_u_51 then
				v_u_51()
			end
		end
	end,
	["isPlayerCharacter"] = function(p59) -- name: isPlayerCharacter
		-- upvalues: (copy) v_u_79
		local v60
		if p59 == nil or p59:GetAttribute("CharacterType") ~= "PlayerCustomCharacter" then
			v60 = false
		else
			v60 = v_u_79.getRootPart(p59) ~= nil
		end
		return v60
	end,
	["isTutorialDummy"] = function(p61) -- name: isTutorialDummy
		-- upvalues: (copy) v_u_79
		local v62
		if p61 == nil or p61:GetAttribute("TutorialDummy") ~= true then
			v62 = false
		else
			v62 = v_u_79.getRootPart(p61) ~= nil
		end
		return v62
	end,
	["isTutorialCutout"] = function(p63) -- name: isTutorialCutout
		local v64
		if p63 == nil then
			v64 = false
		else
			v64 = p63:GetAttribute("TutorialCutout") == true
		end
		return v64
	end,
	["getCutoutBoard"] = function(p65) -- name: getCutoutBoard
		-- upvalues: (copy) v_u_79
		if not (p65 and p65:IsA("Model")) and p65 then
			p65 = p65:FindFirstAncestorOfClass("Model")
		end
		while p65 do
			if v_u_79.isTutorialCutout(p65) then
				return p65.PrimaryPart
			end
			p65 = p65:FindFirstAncestorOfClass("Model")
		end
		return nil
	end,
	["isCutoutHeadshot"] = function(p66, p67) -- name: isCutoutHeadshot
		if p66 and typeof(p67) == "Vector3" then
			return p66.CFrame:PointToObjectSpace(p67).Y >= p66.Size.Y * 0.345
		else
			return false
		end
	end,
	["getImpactMaterial"] = function(p68, p69) -- name: getImpactMaterial
		-- upvalues: (copy) v_u_79
		if not (p68 and p68:IsA("Model")) and p68 then
			p68 = p68:FindFirstAncestorOfClass("Model")
		end
		while p68 do
			if v_u_79.isTutorialCutout(p68) then
				return "WoodPlanks"
			end
			if v_u_79.isPlayerCharacter(p68) or v_u_79.isTutorialDummy(p68) then
				return "Blood Splatter"
			end
			p68 = p68:FindFirstAncestorOfClass("Model")
		end
		return p69 or "Plastic"
	end,
	["getHealth"] = function(p70) -- name: getHealth
		local v71
		if p70 then
			v71 = p70:GetAttribute("Health")
		else
			v71 = nil
		end
		return typeof(v71) ~= "number" and 0 or v71
	end,
	["getMaxHealth"] = function(p72) -- name: getMaxHealth
		local v73
		if p72 then
			v73 = p72:GetAttribute("MaxHealth")
		else
			v73 = nil
		end
		return typeof(v73) ~= "number" and 0 or v73
	end,
	["isAliveCharacter"] = function(p74) -- name: isAliveCharacter
		-- upvalues: (copy) v_u_79
		local v75 = p74 ~= nil and p74:IsDescendantOf(workspace)
		if v75 then
			if p74:GetAttribute("Dead") == false then
				v75 = v_u_79.getHealth(p74) > 0
			else
				v75 = false
			end
		end
		return v75
	end,
	["isAlivePlayer"] = function(p76) -- name: isAlivePlayer
		-- upvalues: (copy) v_u_1, (copy) v_u_2
		if p76 == nil or (p76.Parent ~= v_u_1 or p76:GetAttribute("Dead") ~= false) then
			return false
		end
		local v77 = p76:GetAttribute(v_u_2.Attributes.Health)
		local v78
		if typeof(v77) == "number" then
			v78 = v77 > 0
		else
			v78 = false
		end
		return v78
	end
}
return v_u_79
-- NIGHT Analyzer | ReplicatedStorage.Components.Common.GetWeaponCameraKick
-- ModuleScript | 32 linhas | 925 bytes | hash 2dace7cf

return function(p1)
	local v2 = p1.Rotation
	local v3 = p1.Position
	local v4 = v2.RotationDampen.Value
	local v5 = v2.RotationSpeed.Value
	local v6 = v3.PositionDampen.Value
	local v7 = v3.PositionSpeed.Value
	local v8 = v6 > 2 and 1 or v6
	local v9 = v7 > 2 and 1 or v7
	local v10 = v5 >= 30 and 25 or v5
	local v11 = v2.RotationX.Value
	local v12 = v2.RotationY.Value
	local v13 = v2.RotationZ.Value
	local v14 = v4 >= 5 and 1 or v4
	local v15 = (v11 < 0.1 and 1 or v11) * 0.8
	local v16 = math.abs(v12) < 0.1 and 25 or math.abs(v12)
	local v17 = (math.random() * 2 - 1) * v16 * 0.5
	local v18 = v13 < 0.1 and 1 or v13
	local v19 = {
		["Value"] = Vector3.new(v15, v17, v18),
		["Damper"] = v14,
		["Speed"] = v10
	}
	local v20 = {}
	local v21 = v3.PositionX.Value
	local v22 = v3.PositionY.Value
	local v23 = v3.PositionZ.Value
	v20.Value = Vector3.new(v21, v22, v23)
	v20.Damper = v8
	v20.Speed = v9
	return v19, v20
end
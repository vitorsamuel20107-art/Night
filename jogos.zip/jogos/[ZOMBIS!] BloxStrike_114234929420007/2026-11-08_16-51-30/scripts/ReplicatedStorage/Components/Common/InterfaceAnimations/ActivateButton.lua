-- NIGHT Analyzer | ReplicatedStorage.Components.Common.InterfaceAnimations.ActivateButton
-- ModuleScript | 44 linhas | 1585 bytes | hash 9da1879a

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v_u_4 = require(v1.Database.Security.Router)
return function(p5, p_u_6, p_u_7, p8, p9)
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_4
	local v10 = p8 or 0.95
	local v11 = p5.Size
	local v12 = v_u_2
	local v13 = v_u_3
	local v14 = {}
	local v15 = p9 or 0.9
	v14.Size = UDim2.new(v11.X.Scale * v15, v11.X.Offset, v11.Y.Scale * v15, v11.Y.Offset)
	local v_u_16 = v12:Create(p5, v13, v14)
	local v_u_17 = v_u_2:Create(p5, v_u_3, {
		["Size"] = UDim2.new(v11.X.Scale * v10, v11.X.Offset, v11.Y.Scale * v10, v11.Y.Offset)
	})
	local v_u_18 = v_u_2:Create(p5, v_u_3, {
		["Size"] = UDim2.new(v11.X.Scale * v10, v11.X.Offset, v11.Y.Scale * v10, v11.Y.Offset)
	})
	local v_u_19 = v_u_2:Create(p5, v_u_3, {
		["Size"] = UDim2.new(v11.X.Scale * 1, v11.X.Offset, v11.Y.Scale * 1, v11.Y.Offset)
	})
	p5.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_4, (copy) v_u_18
		v_u_4.broadcastRouter("RunInterfaceSound", "UI Highlight")
		v_u_18:Play()
	end)
	p5.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_19
		v_u_19:Play()
	end)
	p5.MouseButton1Down:Connect(function()
		-- upvalues: (copy) p_u_6, (copy) p_u_7, (ref) v_u_4, (copy) v_u_16
		if not (p_u_6 and (p_u_7 and p_u_7.Menu.GlobalMarketPlace.Visible)) then
			v_u_4.broadcastRouter("RunInterfaceSound", "UI Click")
			v_u_16:Play()
		end
	end)
	p5.MouseButton1Up:Connect(function()
		-- upvalues: (copy) v_u_17
		v_u_17:Play()
	end)
end
-- NIGHT Analyzer | ReplicatedStorage.Components.Common.PlayerHitPrediction
-- ModuleScript | 36 linhas | 874 bytes | hash 3bf6ec71

local v1 = {}
local v_u_2 = {}
local function v_u_4(p3) -- name: prune
	-- upvalues: (copy) v_u_2
	while v_u_2[1] and p3 - v_u_2[1].CreatedAt > 1 do
		table.remove(v_u_2, 1)
	end
end
function v1.Record(p5, p6, p7, p8) -- name: Record
	-- upvalues: (copy) v_u_4, (copy) v_u_2
	local v9 = os.clock()
	v_u_4(v9)
	if #v_u_2 >= 64 then
		table.remove(v_u_2, 1)
	end
	v_u_2[#v_u_2 + 1] = {
		["ShotSeq"] = p5,
		["VictimUserId"] = p6,
		["HitPartName"] = p7,
		["Position"] = p8,
		["CreatedAt"] = v9
	}
end
function v1.Consume(p10, p11, p12, p13) -- name: Consume
	-- upvalues: (copy) v_u_4, (copy) v_u_2
	v_u_4(os.clock())
	for v14, v15 in v_u_2 do
		if v15.ShotSeq ~= p10 or (v15.VictimUserId ~= p11 or (v15.HitPartName ~= p12 or (v15.Position - p13).Magnitude > 6)) then
			continue
		end
		table.remove(v_u_2, v14)
		return true
	end
	return false
end
return table.freeze(v1)
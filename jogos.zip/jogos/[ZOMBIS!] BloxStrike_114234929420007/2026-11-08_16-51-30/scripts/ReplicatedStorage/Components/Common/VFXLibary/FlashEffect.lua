-- NIGHT Analyzer | ReplicatedStorage.Components.Common.VFXLibary.FlashEffect
-- ModuleScript | 481 linhas | 12461 bytes | hash 33739a49

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("Lighting")
local v_u_5 = game:GetService("Workspace")
local v_u_6 = v2.LocalPlayer:WaitForChild("PlayerGui")
local v_u_7 = v_u_5.CurrentCamera
local v_u_8 = v_u_5:WaitForChild("Debris")
local v_u_9 = require(v1.Controllers.CaptureController)
local v_u_10 = require(v1.Controllers.RunServiceController)
local v_u_11 = require(v1.Components.Common.CharacterResolver)
local v12 = require(v1.Packages.Signal)
local v_u_13 = require(v1.Classes.Sound)
local v_u_14 = Color3.new(1, 1, 1)
local v_u_15 = RaycastParams.new()
v_u_15.CollisionGroup = "Barriers"
v_u_15.FilterType = Enum.RaycastFilterType.Exclude
v_u_15.IgnoreWater = true
local v_u_16 = nil
local v_u_17 = nil
local v_u_18 = nil
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = nil
local v_u_24 = nil
local v_u_25 = nil
local v_u_26 = nil
local v_u_27 = nil
local v_u_28 = nil
local v_u_29 = 0
local v_u_30 = nil
local v_u_31 = v12.new()
local v_u_32 = v12.new()
local function v_u_36(p33, p34) -- name: FadeScreenshot
	-- upvalues: (copy) v_u_3, (ref) v_u_23, (ref) v_u_21, (ref) v_u_22
	local v_u_35 = v_u_3:Create(p33, TweenInfo.new(p34, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		["ImageTransparency"] = 1
	})
	v_u_23 = v_u_35
	v_u_35:Play()
	v_u_35.Completed:Connect(function()
		-- upvalues: (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (copy) v_u_35
		if v_u_21 then
			v_u_21:Destroy()
			v_u_21 = nil
			v_u_22 = nil
		end
		if v_u_23 == v_u_35 then
			v_u_23 = nil
		end
	end)
end
local function v_u_37() -- name: CleanupFlash
	-- upvalues: (ref) v_u_19, (ref) v_u_20, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (ref) v_u_23, (ref) v_u_21, (ref) v_u_22, (ref) v_u_26, (ref) v_u_27, (ref) v_u_28, (copy) v_u_32
	if v_u_19 then
		v_u_19:Cancel()
		v_u_19 = nil
	end
	if v_u_20 then
		v_u_20:Cancel()
		v_u_20 = nil
	end
	if v_u_16 then
		v_u_16:Destroy()
		v_u_16 = nil
		v_u_17 = nil
	end
	if v_u_18 then
		v_u_18:Destroy()
		v_u_18 = nil
	end
	if v_u_23 then
		v_u_23:Cancel()
		v_u_23 = nil
	end
	if v_u_21 then
		v_u_21:Destroy()
		v_u_21 = nil
		v_u_22 = nil
	end
	v_u_26 = nil
	v_u_27 = nil
	v_u_28 = nil
	v_u_32:Fire()
end
local function v_u_40() -- name: CreateFlashGui
	-- upvalues: (copy) v_u_14, (copy) v_u_6
	local v38 = Instance.new("ScreenGui")
	v38.Name = "FlashbangEffect"
	v38.DisplayOrder = 999
	v38.IgnoreGuiInset = true
	v38.ResetOnSpawn = false
	local v39 = Instance.new("Frame")
	v39.Name = "FlashOverlay"
	v39.Size = UDim2.new(1, 0, 1, 0)
	v39.BackgroundColor3 = v_u_14
	v39.BackgroundTransparency = 1
	v39.BorderSizePixel = 0
	v39.ZIndex = 999
	v39.Parent = v38
	v38.Parent = v_u_6
	return v38, v39
end
local function v_u_51(p41) -- name: StartDriver
	-- upvalues: (ref) v_u_29, (ref) v_u_26, (ref) v_u_27, (ref) v_u_28, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (copy) v_u_40, (copy) v_u_4, (ref) v_u_19, (ref) v_u_20, (copy) v_u_31, (copy) v_u_3, (copy) v_u_37
	task.wait(0.05)
	while v_u_29 == p41 do
		local v42 = v_u_26
		local v43 = v_u_27
		local v44 = v_u_28
		if not (v42 and (v43 and v44)) then
			break
		end
		local v45 = os.clock()
		if v42 <= v45 then
			break
		end
		local v46 = v_u_16
		local v47 = v_u_17
		local v48 = v_u_18
		if not (v46 and v47) then
			v46, v47 = v_u_40()
			v_u_16 = v46
			v_u_17 = v47
		end
		if not v48 then
			v48 = Instance.new("ColorCorrectionEffect")
			v48.Name = "FlashbangColorCorrection"
			v48.Parent = v_u_4
			v_u_18 = v48
		end
		if v45 < v43 then
			if v_u_19 then
				v_u_19:Cancel()
				v_u_19 = nil
			end
			if v_u_20 then
				v_u_20:Cancel()
				v_u_20 = nil
			end
			v47.BackgroundTransparency = 1 - v44
			v48.Brightness = v44
			v48.Saturation = -v44
			task.wait()
		else
			local v49 = v42 - v45
			v_u_31:Fire()
			if v_u_19 then
				v_u_19:Cancel()
				v_u_19 = nil
			end
			if v_u_20 then
				v_u_20:Cancel()
				v_u_20 = nil
			end
			v_u_19 = v_u_3:Create(v47, TweenInfo.new(v49, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["BackgroundTransparency"] = 1
			})
			v_u_20 = v_u_3:Create(v48, TweenInfo.new(v49, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Brightness"] = 0,
				["Saturation"] = 0
			})
			v_u_19:Play()
			v_u_20:Play()
			while v_u_29 == p41 do
				local v50 = os.clock()
				if v42 <= v50 or v_u_27 and v50 < v_u_27 then
					break
				end
				task.wait(0.05)
			end
		end
	end
	if v_u_29 == p41 then
		v_u_37()
	end
end
local v_u_52 = { -0.5, 0, 0.5 }
local v_u_53 = nil
local function v_u_68(p54, p55) -- name: HasLineOfSight
	-- upvalues: (copy) v_u_8, (copy) v_u_11, (ref) v_u_53, (copy) v_u_5, (copy) v_u_15, (copy) v_u_52
	debug.profilebegin("VFX.Flash.HasLineOfSight")
	local v56 = { v_u_8 }
	local v57 = v_u_11.getLocalCharacter()
	if v57 then
		table.insert(v56, v57)
	end
	local v58
	if v_u_53 == nil or v_u_53.Parent == nil then
		local v59 = v_u_5:FindFirstChild("Map")
		local v60
		if v59 then
			v60 = v59:FindFirstChild("Barriers")
		else
			v60 = nil
		end
		v_u_53 = v60
		v58 = v_u_53
	else
		v58 = v_u_53
	end
	if v58 then
		table.insert(v56, v58)
	end
	v_u_15.FilterDescendantsInstances = v56
	for _, v61 in ipairs(v_u_52) do
		for _, v62 in ipairs(v_u_52) do
			for _, v63 in ipairs(v_u_52) do
				local v64 = p54 + Vector3.new(v61, v62, v63)
				local v65 = p55 - v64
				local v66 = v65.Magnitude
				if v66 < 0.1 then
					return true
				end
				local v67 = v_u_5:Raycast(v64, v65, v_u_15)
				if v67 and v67.Distance < v66 - 0.5 then
					continue
				end
				debug.profileend()
				return true
			end
		end
	end
	debug.profileend()
	return false
end
return {
	["OnFlashRecoveryStarted"] = v_u_31,
	["OnFlashCleared"] = v_u_32,
	["Flash"] = function(p69) -- name: Flash
		-- upvalues: (copy) v_u_7, (copy) v_u_68, (ref) v_u_25, (ref) v_u_24, (copy) v_u_13, (copy) v_u_10, (ref) v_u_26, (ref) v_u_30, (ref) v_u_28, (ref) v_u_27, (ref) v_u_22, (ref) v_u_23, (copy) v_u_36, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (copy) v_u_40, (copy) v_u_4, (ref) v_u_19, (ref) v_u_20, (copy) v_u_3, (ref) v_u_29, (copy) v_u_51, (copy) v_u_9, (ref) v_u_21, (copy) v_u_6
		debug.profilebegin("VFX.Flash")
		local v70 = p69.Position
		local v71 = v_u_7.CFrame.Position
		local v_u_72
		if p69.Duration then
			v_u_72 = p69.Duration
		else
			local v73 = v70 - v71
			local v74 = v73.Magnitude
			if v74 > 229.16666666666669 or not v_u_68(v70, v71) then
				debug.profileend()
				return false
			end
			debug.profilebegin("VFX.Flash.CalculateDuration")
			local v75 = v_u_7.CFrame.LookVector
			if v73.Magnitude <= 0 then
				v_u_72 = 0
			else
				local v76 = 3 - v74 * 0.01309090909090909
				if v76 <= 0 then
					v_u_72 = 0
				else
					local v77 = v75:Dot(v73.Unit)
					local v78 = math.clamp(v77, -1, 1)
					v_u_72 = v76 * (v78 >= 0.6 and 2.5 or (v78 >= 0.3 and 1.75 or (v78 >= -0.2 and 1 or 0.5))) / 1.4
				end
			end
			debug.profileend()
		end
		if v_u_72 < 0.01 then
			debug.profileend()
			return false
		end
		debug.profilebegin("VFX.Flash.Sound")
		if v_u_25 then
			v_u_25:Disconnect()
			v_u_25 = nil
		end
		if v_u_24 and v_u_24.Parent then
			v_u_24:Stop()
			v_u_24:Destroy()
		end
		v_u_24 = nil
		local v79 = {
			["Parent"] = nil,
			["Name"] = "Flashed",
			["Parent"] = v_u_7
		}
		local v_u_80 = v_u_13.new("Flashbang"):play(v79)
		if v_u_80 then
			v_u_24 = v_u_80
			local v_u_81 = tick()
			local v_u_82 = v_u_80.Volume
			v_u_25 = v_u_10.BindToHeartbeat("VFX.FlashEffect.SoundFade", function()
				-- upvalues: (copy) v_u_81, (copy) v_u_80, (copy) v_u_82, (ref) v_u_25, (ref) v_u_24
				local v83 = tick() - v_u_81
				if v83 < 4 and v_u_80.Parent then
					v_u_80.Volume = v_u_82 * (1 - v83 * 0.225)
				else
					if v_u_25 then
						v_u_25:Disconnect()
						v_u_25 = nil
					end
					if v_u_80.Parent then
						v_u_80:Stop()
						v_u_80:Destroy()
					end
					if v_u_24 == v_u_80 then
						v_u_24 = nil
					end
				end
			end)
		end
		debug.profileend()
		local function v104() -- name: applyFlashEffect
			-- upvalues: (ref) v_u_26, (ref) v_u_72, (ref) v_u_30, (ref) v_u_28, (ref) v_u_27, (ref) v_u_22, (ref) v_u_23, (ref) v_u_36, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (ref) v_u_40, (ref) v_u_4, (ref) v_u_19, (ref) v_u_20, (ref) v_u_3, (ref) v_u_29, (ref) v_u_51
			debug.profilebegin("VFX.Flash.Apply")
			local v84 = os.clock()
			local v85
			if v_u_26 then
				local v86 = v_u_26 - v84
				v85 = math.max(0, v86) or 0
			else
				v85 = 0
			end
			local v87 = v_u_72
			local v88 = math.max(v85, v87)
			local v89 = v88 - 3
			local v90 = math.max(0, v89)
			local v91
			if v88 > 3 then
				v91 = 1
			else
				local v92 = (v88 / 3) ^ 0.6
				v91 = math.clamp(v92, 0, 1)
			end
			v_u_30 = v84
			v_u_26 = v84 + v88
			v_u_28 = v91
			local v93 = v84 + 0.05 + v90
			local v94 = v_u_26
			local v95 = v_u_27 or 0
			local v96 = math.max(v95, v93)
			v_u_27 = math.min(v94, v96)
			if v_u_72 >= 4 and v_u_22 then
				if v_u_23 then
					v_u_23:Cancel()
					v_u_23 = nil
				end
				v_u_22.ImageTransparency = 0
				v_u_36(v_u_22, v88)
			end
			local v97 = v_u_16
			local v98 = v_u_17
			local v99 = v_u_18
			if not (v97 and v98) then
				v97, v98 = v_u_40()
				v_u_16 = v97
				v_u_17 = v98
			end
			if not v99 then
				v99 = Instance.new("ColorCorrectionEffect")
				v99.Name = "FlashbangColorCorrection"
				v99.Parent = v_u_4
				v_u_18 = v99
			end
			debug.profilebegin("VFX.Flash.Apply.CreateTweens")
			if v_u_19 then
				v_u_19:Cancel()
				v_u_19 = nil
			end
			if v_u_20 then
				v_u_20:Cancel()
				v_u_20 = nil
			end
			local v100 = {
				["BackgroundTransparency"] = 1 - v91
			}
			local v101 = v_u_3:Create(v98, TweenInfo.new(0.05, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v100)
			local v102 = {
				["Brightness"] = v91,
				["Saturation"] = -v91
			}
			local v103 = v_u_3:Create(v99, TweenInfo.new(0.05, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v102)
			v101:Play()
			v103:Play()
			debug.profileend()
			v_u_29 = v_u_29 + 1
			task.spawn(v_u_51, v_u_29)
			debug.profileend()
		end
		if v_u_72 >= 4 then
			debug.profilebegin("VFX.Flash.CaptureScreenshot")
			v_u_9.CaptureScreenshot(function(p105)
				-- upvalues: (ref) v_u_23, (ref) v_u_21, (ref) v_u_6, (ref) v_u_22, (ref) v_u_26, (ref) v_u_36
				debug.profilebegin("VFX.Flash.CaptureScreenshot.Callback")
				if v_u_23 then
					v_u_23:Cancel()
					v_u_23 = nil
				end
				if v_u_21 then
					if v_u_22 then
						v_u_22.Image = p105
						v_u_22.ImageTransparency = 0
					end
				else
					local v106 = Instance.new("ScreenGui")
					v106.Name = "FlashScreenshot"
					v106.DisplayOrder = 998
					v106.IgnoreGuiInset = true
					v106.ResetOnSpawn = false
					v106.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
					local v107 = Instance.new("ImageLabel")
					v107.Name = "ScreenshotImage"
					v107.Size = UDim2.new(1, 0, 1, 0)
					v107.BackgroundTransparency = 1
					v107.BorderSizePixel = 0
					v107.Image = p105
					v107.ScaleType = Enum.ScaleType.Fit
					v107.ZIndex = 998
					v107.Parent = v106
					v106.Parent = v_u_6
					v_u_21 = v106
					v_u_22 = v107
				end
				if v_u_22 then
					local v108
					if v_u_26 then
						local v109 = v_u_26 - os.clock()
						v108 = math.max(0, v109) or 0
					else
						v108 = 0
					end
					v_u_36(v_u_22, (math.max(v108, 0.01)))
				end
				debug.profileend()
			end):catch(function() end)
			debug.profileend()
			task.delay(0.01, v104)
		else
			v104()
		end
		debug.profileend()
		return true
	end,
	["CancelFlash"] = function() -- name: CancelFlash
		-- upvalues: (ref) v_u_29, (copy) v_u_37, (ref) v_u_30, (ref) v_u_25, (ref) v_u_24
		debug.profilebegin("VFX.Flash.Cancel")
		v_u_29 = v_u_29 + 1
		v_u_37()
		v_u_30 = nil
		if v_u_25 then
			v_u_25:Disconnect()
			v_u_25 = nil
		end
		if v_u_24 and v_u_24.Parent then
			v_u_24:Stop()
			v_u_24:Destroy()
		end
		v_u_24 = nil
		debug.profileend()
	end,
	["IsFlashed"] = function() -- name: IsFlashed
		-- upvalues: (ref) v_u_26
		local v110
		if v_u_26 == nil then
			v110 = false
		else
			v110 = os.clock() < v_u_26
		end
		return v110
	end,
	["GetAudioFadeMultiplier"] = function() -- name: GetAudioFadeMultiplier
		-- upvalues: (ref) v_u_30
		if not v_u_30 then
			return 1
		end
		local v111 = os.clock() - v_u_30
		if v111 >= 1.5 then
			return 1
		end
		if v111 < 0.5 then
			return 0
		end
		local v112 = v111 - 0.5
		return math.clamp(v112, 0, 1)
	end
}
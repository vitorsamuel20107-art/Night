-- NIGHT Analyzer | ReplicatedStorage.Components.Common.BotWeaponEffects
-- ModuleScript | 61 linhas | 1699 bytes | hash a95a4a1e

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(script.Parent.VFXLibary.CreateMuzzleFlash.EmitParticles)
local v_u_4 = require(script.Parent.VFXLibary.CreateTracer)
local v_u_5 = require(v_u_2.Classes.Sound)
local v_u_6 = require(script.Parent.VFXLibary.FlashEffect)
local v7 = {}
local function v_u_15(p8, p9, p10, p11) -- name: playSound
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_1, (copy) v_u_6
	local v12 = v_u_2:FindFirstChild("Sounds")
	local v13
	if v12 then
		v13 = v12:FindFirstChild(p8)
	else
		v13 = nil
	end
	if v13 == nil or v13:FindFirstChild(p9) == nil then
		return
	else
		local v14 = v_u_5.new(p8)
		if p11 then
			v14:play({
				["Parent"] = v_u_1.LocalPlayer.PlayerGui,
				["Name"] = p9
			}, v_u_6.GetAudioFadeMultiplier())
			v14:destroy()
		else
			v14:PlaySoundAtPosition({
				["Class"] = p8,
				["Name"] = p9,
				["Position"] = p10
			}, nil, v_u_6.GetAudioFadeMultiplier())
		end
	end
end
function v7.shoot(p16, p17, p18, p19) -- name: shoot
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_15
	local v20 = #p16.Muzzles
	if v20 ~= 0 then
		local v21 = p16.Muzzles[p18 % v20 + 1]
		local v22
		if p16.MuzzleType then
			v22 = v21:FindFirstChild(p16.MuzzleType)
		else
			v22 = nil
		end
		if v22 and not p19 then
			v_u_3(v22)
		end
		local v23 = p17 - v21.Position
		if v23.Magnitude > 0.0001 and not p19 then
			v_u_4(v23.Magnitude, v21.Position, v23.Unit, true)
		end
		v_u_15(p16.Name, "Shoot", v21.Position, p19)
	end
end
function v7.reloadSound(p24, p25, p26) -- name: reloadSound
	-- upvalues: (copy) v_u_15
	v_u_15(p24.Name, "MagOut", p25.Position, p26)
end
return table.freeze(v7)
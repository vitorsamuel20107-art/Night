-- NIGHT Analyzer | ReplicatedStorage.Components.Common.CharacterPose
-- ModuleScript | 83 linhas | 2640 bytes | hash cdbc6df9

local v_u_26 = {
	["getJoints"] = function(p1) -- name: getJoints
		local v2 = p1:FindFirstChild("RightShoulder", true)
		if not (v2 and v2:IsA("Motor6D")) then
			v2 = nil
		end
		local v3 = p1:FindFirstChild("LeftShoulder", true)
		if not (v3 and v3:IsA("Motor6D")) then
			v3 = nil
		end
		local v4 = p1:FindFirstChild("Waist", true)
		if not (v4 and v4:IsA("Motor6D")) then
			v4 = nil
		end
		if not (v2 and (v3 and v4)) then
			return nil
		end
		local v5 = p1:FindFirstChild("Neck", true)
		if not (v5 and v5:IsA("Motor6D")) then
			v5 = nil
		end
		local v6 = {
			["RightShoulder"] = nil,
			["LeftShoulder"] = nil,
			["Waist"] = nil,
			["Neck"] = nil,
			["BaseRightShoulderC0"] = nil,
			["BaseLeftShoulderC0"] = nil,
			["BaseWaistC0"] = nil,
			["BaseNeckC0"] = nil,
			["LastVerticalLook"] = nil,
			["RightShoulder"] = v2,
			["LeftShoulder"] = v3,
			["Waist"] = v4,
			["Neck"] = v5,
			["BaseRightShoulderC0"] = v2.C0,
			["BaseLeftShoulderC0"] = v3.C0,
			["BaseWaistC0"] = v4.C0
		}
		local v7
		if v5 then
			v7 = v5.C0
		else
			v7 = nil
		end
		v6.BaseNeckC0 = v7
		return v6
	end,
	["composeRootCFrame"] = function(p8, p9) -- name: composeRootCFrame
		return CFrame.new(p8) * CFrame.Angles(0, p9, 0)
	end,
	["predictHeadCFrame"] = function(p10, p11, p12, p13) -- name: predictHeadCFrame
		-- upvalues: (copy) v_u_26
		local v14 = p10.Waist
		local v15 = p10.Neck
		if not v14.Part0 or (not v14.Part1 or (not v15 or (not v15.Part1 or (v15.Part0 ~= v14.Part1 or not p10.BaseNeckC0)))) then
			return nil
		end
		local v16 = math.clamp(p13, -1, 1)
		local v17 = v14.Part0.CFrame * p10.BaseWaistC0 * CFrame.Angles(v16 * 0.6283185307179585, 0, 0) * v14.Transform * v14.C1:Inverse() * p10.BaseNeckC0 * CFrame.Angles(v16 * 1.0471975511965976, 0, 0) * v15.Transform * v15.C1:Inverse()
		return v_u_26.composeRootCFrame(p11.Position, p12) * p11:Inverse() * v17
	end,
	["applyVerticalLook"] = function(p18, p19, p20) -- name: applyVerticalLook
		local v21 = math.clamp(p19, -1, 1)
		local v22 = p20 or 0.0001
		if p18.LastVerticalLook ~= nil then
			local v23 = v21 - p18.LastVerticalLook
			if math.abs(v23) < v22 then
				return
			end
		end
		p18.RightShoulder.C0 = p18.BaseRightShoulderC0 * CFrame.Angles(v21 * 0.5235987755982988, 0, 0)
		p18.LeftShoulder.C0 = p18.BaseLeftShoulderC0 * CFrame.Angles(v21 * 0.5235987755982988, 0, 0)
		p18.Waist.C0 = p18.BaseWaistC0 * CFrame.Angles(v21 * 0.6283185307179585, 0, 0)
		local v24 = p18.Neck
		local v25 = p18.BaseNeckC0
		if v24 and v25 then
			v24.C0 = v25 * CFrame.Angles(v21 * 1.0471975511965976, 0, 0)
		end
		p18.LastVerticalLook = v21
	end
}
return table.freeze(v_u_26)
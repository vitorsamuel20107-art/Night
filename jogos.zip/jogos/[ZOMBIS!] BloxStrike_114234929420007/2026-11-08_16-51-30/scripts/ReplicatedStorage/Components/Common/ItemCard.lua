-- NIGHT Analyzer | ReplicatedStorage.Components.Common.ItemCard
-- ModuleScript | 109 linhas | 3315 bytes | hash d83dbee0

local v_u_1 = {}
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Players")
local v_u_4 = require(v2.Controllers.DataController)
local v_u_5 = require(v2.Database.Components.Libraries.Skins)
local v_u_6 = require(v2.Database.Custom.GameStats.Rarities)
local v_u_7 = require(script.Parent.GetWeaponProperties)
local v_u_8 = require(script.Parent.GetSkinDisplayName)
local v_u_9 = require(script.Parent.GetResolvedSkinInformation)
local v_u_10 = require(script.Parent.ApplyWearAndSerialBadges)
local v_u_11 = require(script.Parent.ItemEquipment)
local v_u_12 = {
	["Charm Capsule"] = "Charm Pack",
	["Package"] = "Package"
}
local function v_u_15(p13) -- name: findCharmItem
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	if type(p13) == "table" then
		p13 = p13._id
	elseif type(p13) ~= "string" then
		p13 = nil
	end
	if not p13 then
		return nil
	end
	for _, v14 in v_u_4.Get(v_u_3.LocalPlayer, "Inventory") or {} do
		if v14._id ~= p13 or v14.Type ~= "Charm" then
			continue
		end
		return v14
	end
	return nil
end
function v_u_1.GetIconImage(p16, p17, p18) -- name: GetIconImage
	-- upvalues: (copy) v_u_5
	if not p17 then
		return ""
	end
	if p18 then
		return p17.imageAssetId or ""
	end
	if p16.Type ~= "Charm" then
		return v_u_5.GetWearImageForFloat(p17, p16.Float or 0.9999) or p17.imageAssetId or ""
	end
	local v19 = p16.Pattern
	if v19 and p17.charmImages then
		for _, v20 in ipairs(p17.charmImages) do
			if v20.pattern ~= v19 then
				continue
			end
			return v20.assetId
		end
	end
	return p17.imageAssetId or ""
end
function v_u_1.GetDisplayName(p21, p22, p23) -- name: GetDisplayName
	-- upvalues: (copy) v_u_8, (copy) v_u_12
	local v24 = v_u_8.GetWeaponDisplayName(p21.Name, p21.NameTag)
	local v25 = p23 and p22.caseType and v_u_12[p22.caseType] or p23 and p22.caseType
	if v25 then
		v24 = v25
	elseif p21.StatTrack then
		v24 = "KillTrak\226\132\162 " .. v24 or v24
	end
	return (p21.Type == "Melee" and "\226\152\133 " or "") .. v24
end
function v_u_1.SyncCharm(p26, p27) -- name: SyncCharm
	-- upvalues: (copy) v_u_15, (copy) v_u_9, (copy) v_u_1
	local v28 = p26.ItemContent:FindFirstChild("Charm")
	if v28 and v28:IsA("ImageLabel") then
		local v29
		if p27.Type == "Weapon" then
			v29 = v_u_15(p27.Charm)
		else
			v29 = nil
		end
		local v30
		if v29 then
			v30 = v_u_9(v29.Name, v29.Skin)
		else
			v30 = v29
		end
		local v31 = not v30 and "" or v_u_1.GetIconImage(v29, v30, false)
		v28.Image = v31
		v28.Visible = v31 ~= ""
	end
end
function v_u_1.Fill(p32, p33, p34, p35) -- name: Fill
	-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_7, (copy) v_u_10, (copy) v_u_8, (copy) v_u_11
	local v36 = v_u_6[p35 and p34.caseRarity or p34.rarity]
	local v37 = p32.ItemContent
	v37.Rarity.BackgroundColor3 = v36.Color
	local v38 = v37.Content.Icon
	v38.Image = v_u_1.GetIconImage(p33, p34, p35)
	local v39 = v_u_7(p33.Name)
	if v39 then
		v39 = v39.InventoryIconData
	end
	if v39 then
		v38.ScaleType = v39.ScaleType or v38.ScaleType
		v38.Size = v39.Size or v38.Size
	end
	v_u_1.SyncCharm(p32, p33)
	v_u_10(p32, p33, p34)
	v_u_8.ApplyNameLabel(p32.Bottom.Footer.WeaponName, v_u_1.GetDisplayName(p33, p34, p35), p33.NameTag)
	p32.Bottom.Footer.SkinName.Text = v_u_8(p35 and p34.skin or (p33.Skin or ""))
	v_u_11.UpdateStatusFrame(p32, p33._id)
end
return v_u_1
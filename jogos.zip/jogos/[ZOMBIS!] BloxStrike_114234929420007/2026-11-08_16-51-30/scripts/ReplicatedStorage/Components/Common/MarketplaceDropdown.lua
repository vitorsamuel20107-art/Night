-- NIGHT Analyzer | ReplicatedStorage.Components.Common.MarketplaceDropdown
-- ModuleScript | 208 linhas | 5734 bytes | hash ecc01dc3

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = require(v1.Packages.Signal)
local v_u_4 = require(v1.Shared.CollectionServiceUtility)
local v_u_5 = TweenInfo.new(0.3, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out)
local v_u_6 = TweenInfo.new(0.36, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out)
local v_u_7 = v1.Assets.TradingUI.Templates:WaitForChild("InventoryDropdownTemplate")
local v_u_8 = nil
local v_u_9 = {}
v_u_9.__index = v_u_9
local function v_u_12(p10) -- name: findDropdownRow
	while true do
		local v11 = p10.Parent
		if not v11 or (not v11:IsA("GuiObject") or (v11:IsA("ScrollingFrame") or (v11.ClipsDescendants or v11:FindFirstChildWhichIsA("UIGridStyleLayout") ~= nil))) then
			break
		end
		p10 = v11
	end
	return p10
end
local function v_u_17(p13) -- name: getTopSiblingZIndex
	local v14 = p13.ZIndex
	for _, v15 in p13.Parent:GetChildren() do
		if v15 == p13 or not v15:IsA("GuiObject") then
			continue
		end
		local v16 = v15.ZIndex + 1
		v14 = math.max(v14, v16)
	end
	return v14
end
function v_u_9.new(p18, p19, p20, p21) -- name: new
	-- upvalues: (copy) v_u_9, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_2, (copy) v_u_6, (copy) v_u_5
	local v22 = #p19 > 0
	assert(v22, "Marketplace dropdowns require at least one option")
	local v23 = p20 or {}
	local v24 = v_u_9
	local v_u_25 = setmetatable({}, v24)
	v_u_25.Instance = p18
	v_u_25._config = v23
	v_u_25._template = p21 or v_u_7
	v_u_25.OptionSelected = v_u_3.new()
	v_u_25.Option = p19[1] or ""
	v_u_25._expanded = false
	v_u_25._expandedSize = UDim2.fromScale(1, 2)
	v_u_25._hiddenSize = UDim2.fromScale(1, 0)
	p18.Activated:Connect(function()
		-- upvalues: (copy) v_u_25
		v_u_25:Toggle()
	end)
	v_u_25._pointer = v_u_4.FindDescendantWithTag(p18, "DropdownPointer")
	if v_u_25._pointer then
		v_u_25._pointer.Rotation = 0
	end
	p18.ClipsDescendants = false
	local v_u_26 = Instance.new("Frame")
	v_u_26.Name = "Dropdown"
	local v27
	if v23.tweenVisibility then
		v27 = v_u_25._hiddenSize
	else
		v27 = v_u_25._expandedSize
	end
	v_u_26.Size = v27
	v_u_26.AnchorPoint = v23.AnchorPoint or Vector2.new(0.5, 0)
	v_u_26.Position = v23.Position or UDim2.new(0.5, 0, 1, 2)
	v_u_26.BackgroundTransparency = 1
	v_u_26.ZIndex = p18.ZIndex + 1
	v_u_26.Visible = false
	local v28 = Instance.new("UIListLayout")
	v28.FillDirection = Enum.FillDirection.Vertical
	v28.SortOrder = Enum.SortOrder.LayoutOrder
	if v23.VerticalAlignment then
		v28.VerticalAlignment = v23.VerticalAlignment
	end
	v28.Parent = v_u_26
	v_u_26.Parent = p18
	local v29 = v_u_4.FindDescendantWithTag(p18, "SelectedOptionText")
	if v29 then
		v29.Text = v_u_25.Option
	end
	v_u_25._selectedOptionText = v29
	v_u_25._optionInstances = {}
	v_u_25.OptionSelected:Connect(function(p30)
		-- upvalues: (copy) v_u_25
		v_u_25:SelectOption(p30)
		v_u_25:Hide()
	end)
	v_u_25._expandTween = v_u_2:Create(v_u_26, v_u_6, {
		["Size"] = v_u_25._expandedSize
	})
	v_u_25._closeTween = v_u_2:Create(v_u_26, v_u_5, {
		["Size"] = v_u_25._hiddenSize
	})
	v_u_25._closeTween.Completed:Connect(function(p31)
		-- upvalues: (copy) v_u_25, (copy) v_u_26
		if p31 == Enum.PlaybackState.Completed and not v_u_25._expanded then
			v_u_26.Visible = false
			v_u_25:_lowerRow()
		end
	end)
	v_u_25._dropdownFrame = v_u_26
	v_u_25:SetOptions(p19)
	return v_u_25
end
function v_u_9.SelectOption(p32, p33) -- name: SelectOption
	p32.Option = p33
	for v34, v35 in p32._optionInstances do
		v35.Visible = v34 ~= p33
	end
	if p32._selectedOptionText then
		p32._selectedOptionText.Text = p33
	end
end
function v_u_9.SetOptions(p_u_36, p37) -- name: SetOptions
	-- upvalues: (copy) v_u_4
	for _, v38 in p_u_36._optionInstances do
		v38:Destroy()
	end
	p_u_36._optionInstances = {}
	for _, v_u_39 in p37 do
		local v40 = p_u_36._template:Clone()
		v40.Name = v_u_39
		v40.Size = UDim2.fromScale(1, 0.5)
		local v41 = v_u_4.FindDescendantWithTag(v40, "OptionText")
		if v41 then
			v41.Text = v_u_39
		end
		v40.Activated:Connect(function()
			-- upvalues: (copy) p_u_36, (copy) v_u_39
			p_u_36.OptionSelected:Fire(v_u_39)
		end)
		p_u_36._optionInstances[v_u_39] = v40
		v40.Parent = p_u_36._dropdownFrame
	end
	p_u_36.OptionSelected:Fire(p37[1])
end
function v_u_9.Expand(p42) -- name: Expand
	-- upvalues: (ref) v_u_8
	if p42._expanded then
		return
	else
		p42._expanded = true
		if v_u_8 and v_u_8 ~= p42 then
			v_u_8:Hide()
		end
		v_u_8 = p42
		if p42._pointer then
			p42._pointer.Rotation = 180
		end
		p42:_raiseRow()
		p42._dropdownFrame.Visible = true
		if p42._config.tweenVisibility then
			p42._closeTween:Cancel()
			p42._expandTween:Play()
		else
			p42._dropdownFrame.Size = p42._expandedSize
		end
	end
end
function v_u_9.Hide(p43) -- name: Hide
	-- upvalues: (ref) v_u_8
	if p43._expanded then
		p43._expanded = false
		if v_u_8 == p43 then
			v_u_8 = nil
		end
		if p43._pointer then
			p43._pointer.Rotation = 0
		end
		if p43._config.tweenVisibility then
			p43._expandTween:Cancel()
			p43._closeTween:Play()
		else
			p43._dropdownFrame.Size = p43._hiddenSize
			p43._dropdownFrame.Visible = false
			p43:_lowerRow()
		end
	else
		return
	end
end
function v_u_9._raiseRow(p44) -- name: _raiseRow
	-- upvalues: (copy) v_u_12, (copy) v_u_17
	local v45 = v_u_12(p44.Instance)
	if p44._raisedRow ~= v45 then
		p44:_lowerRow()
		p44._raisedRow = v45
		p44._rowZIndex = v45.ZIndex
	end
	v45.ZIndex = v_u_17(v45)
end
function v_u_9._lowerRow(p46) -- name: _lowerRow
	local v47 = p46._raisedRow
	if v47 and p46._rowZIndex then
		v47.ZIndex = p46._rowZIndex
	end
	p46._raisedRow = nil
	p46._rowZIndex = nil
end
function v_u_9.Toggle(p48) -- name: Toggle
	if p48._expanded then
		p48:Hide()
	else
		p48:Expand()
	end
end
return v_u_9
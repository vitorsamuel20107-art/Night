-- NIGHT Analyzer | ReplicatedStorage.Components.Common.TutorialPurchaseLock
-- ModuleScript | 128 linhas | 2969 bytes | hash 800629e7

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Components.Common.IsTutorialMode)
local v_u_3 = require(v1.Database.Components.Libraries.Stock)
local v_u_4 = table.freeze({
	["BuyWeapons"] = table.freeze({ "AK-47" }),
	["BuyCTWeapons"] = table.freeze({ "M4A4", "M4A1-S" })
})
local v_u_5 = table.freeze({
	["GoToRange"] = true,
	["PracticeAK"] = true,
	["KillCTs"] = true,
	["PlantBomb"] = true,
	["WaitExplode"] = true,
	["GoToCTBuy"] = true,
	["KillTs"] = true,
	["DefuseB"] = true
})
local v_u_6 = table.freeze({
	["Terrorists"] = v_u_4.BuyWeapons,
	["Counter-Terrorists"] = v_u_4.BuyCTWeapons
})
local v_u_30 = {
	["getRequiredItems"] = function(p7) -- name: getRequiredItems
		-- upvalues: (copy) v_u_2, (copy) v_u_4
		if v_u_2() then
			local v8 = p7:GetAttribute("TutorialStep")
			if typeof(v8) == "string" then
				return v_u_4[v8]
			else
				return nil
			end
		else
			return nil
		end
	end,
	["isBuyMenuLocked"] = function(p9) -- name: isBuyMenuLocked
		-- upvalues: (copy) v_u_2, (copy) v_u_5
		if v_u_2() then
			local v10 = p9:GetAttribute("TutorialStep")
			if typeof(v10) == "string" then
				return v_u_5[v10] == true
			else
				return false
			end
		else
			return false
		end
	end,
	["isPurchaseAllowed"] = function(p11, p12) -- name: isPurchaseAllowed
		-- upvalues: (copy) v_u_30
		if v_u_30.isBuyMenuLocked(p11) then
			return false
		end
		local v13 = v_u_30.getRequiredItems(p11)
		return not v13 and true or table.find(v13, p12) ~= nil
	end,
	["isWaitingOnPurchase"] = function(p14, p15) -- name: isWaitingOnPurchase
		-- upvalues: (copy) v_u_30
		local v16 = v_u_30.getRequiredItems(p14)
		if not v16 then
			return false
		end
		for _, v17 in ipairs(v16) do
			if not p15(v17) then
				continue
			end
			return false
		end
		return true
	end,
	["getForcedLoadoutItem"] = function(p18, p19, p20, p21) -- name: getForcedLoadoutItem
		-- upvalues: (copy) v_u_2, (copy) v_u_6, (copy) v_u_3
		if p19 ~= "Loadout.Rifles.Options.1" or not v_u_2() then
			return nil
		end
		local v22 = v_u_6[p18]
		if not v22 then
			return nil
		end
		local v23
		if typeof(p20) == "table" then
			v23 = p20[p18]
		else
			v23 = nil
		end
		local v24
		if typeof(v23) == "table" then
			local v25 = v23.Loadout
			if typeof(v25) == "table" then
				v24 = v23.Loadout.Rifles
			else
				v24 = nil
			end
		else
			v24 = nil
		end
		local v26
		if typeof(v24) == "table" then
			v26 = v24.Options
		else
			v26 = nil
		end
		if typeof(v26) == "table" then
			for _, v27 in v26 do
				local v28
				if typeof(v27) == "string" then
					v28 = v_u_3.GetWeaponNameFromStockId(v27)
				else
					v28 = nil
				end
				if not v28 and typeof(p21) == "table" then
					for _, v29 in p21 do
						if v29._id ~= v27 then
							continue
						end
						v28 = v29.Name
					end
				end
				if not (v28 and table.find(v22, v28)) then
					continue
				end
				return nil
			end
		end
		return v_u_3.GetStockInventoryItem(v22[1])
	end
}
return v_u_30
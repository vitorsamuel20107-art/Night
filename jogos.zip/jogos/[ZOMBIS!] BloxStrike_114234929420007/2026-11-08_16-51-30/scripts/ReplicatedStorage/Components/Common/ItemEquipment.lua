-- NIGHT Analyzer | ReplicatedStorage.Components.Common.ItemEquipment
-- ModuleScript | 56 linhas | 1390 bytes | hash 67e4ddd0

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Players")
local v_u_3 = require(v1.Controllers.DataController)
local function v_u_8(p4, p5) -- name: isEquipped
	if not p4 then
		return false
	end
	for _, v6 in p4.Loadout or {} do
		if not (v6 and (v6.Options and table.find(v6.Options, p5))) then
			continue
		end
		return true
	end
	for _, v7 in p4.Equipped or {} do
		if v7 ~= p5 then
			continue
		end
		return true
	end
	return false
end
return {
	["IsEquippedOnTeam"] = function(p9, p10) -- name: IsEquippedOnTeam
		-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_8
		local v11 = v_u_3.Get(v_u_2.LocalPlayer, "Loadout")
		local v12 = v_u_8
		if v11 then
			v11 = v11[p10]
		end
		return v12(v11, p9)
	end,
	["UpdateStatusFrame"] = function(p13, p14) -- name: UpdateStatusFrame
		-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_8
		local v15 = p13:FindFirstChild("Status")
		if v15 then
			local v16 = v15:FindFirstChild("Counter-Terrorists")
			local v17 = v15:FindFirstChild("Terrorists")
			if v16 and v17 then
				local v18 = v_u_3.Get(v_u_2.LocalPlayer, "Loadout")
				local v19 = v_u_8
				local v20
				if v18 then
					v20 = v18["Counter-Terrorists"]
				else
					v20 = v18
				end
				v16.Visible = v19(v20, p14)
				local v21 = v_u_8
				if v18 then
					v18 = v18.Terrorists
				end
				v17.Visible = v21(v18, p14)
			end
		end
	end
}
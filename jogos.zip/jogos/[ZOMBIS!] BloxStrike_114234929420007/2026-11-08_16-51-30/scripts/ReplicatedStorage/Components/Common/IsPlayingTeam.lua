-- NIGHT Analyzer | ReplicatedStorage.Components.Common.IsPlayingTeam
-- ModuleScript | 3 linhas | 89 bytes | hash d6b843b2

return function(p1)
	return p1 == "Counter-Terrorists" and true or p1 == "Terrorists"
end
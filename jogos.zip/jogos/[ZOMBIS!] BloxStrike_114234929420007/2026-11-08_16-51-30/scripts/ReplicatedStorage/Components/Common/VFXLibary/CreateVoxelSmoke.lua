-- NIGHT Analyzer | ReplicatedStorage.Components.Common.VFXLibary.CreateVoxelSmoke
-- ModuleScript | 445 linhas | 12129 bytes | hash 9bc73af2

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Workspace")
local v_u_3 = require(v1.Controllers.RunServiceController)
local v_u_4 = v1:WaitForChild("Assets"):WaitForChild("GrenadeParticles"):WaitForChild("Smoke")
local v_u_5 = {
	["Terrorists"] = Color3.fromRGB(185, 170, 145),
	["Counter-Terrorists"] = Color3.fromRGB(155, 170, 190)
}
local v_u_6 = {}
local v_u_7 = {}
local v_u_8 = {}
local v_u_9 = {}
local v_u_10 = nil
local function v_u_33(p11, p12, p13, p14, p15) -- name: RayIntersectsAABB
	local v16 = 0
	local v17 = p12.X
	local v18
	if math.abs(v17) < 0.0001 then
		if p11.X < p13.X or p11.X > p14.X then
			return false
		end
		v18 = p15
	else
		local v19 = 1 / p12.X
		local v20 = (p13.X - p11.X) * v19
		local v21 = (p14.X - p11.X) * v19
		if v21 >= v20 then
			local v22 = v20
			v20 = v21
			v21 = v22
		end
		v16 = math.max(v16, v21)
		v18 = math.min(p15, v20)
		if v18 < v16 then
			return false
		end
	end
	local v23 = p12.Y
	if math.abs(v23) < 0.0001 then
		if p11.Y < p13.Y or p11.Y > p14.Y then
			return false
		end
	else
		local v24 = 1 / p12.Y
		local v25 = (p13.Y - p11.Y) * v24
		local v26 = (p14.Y - p11.Y) * v24
		if v26 >= v25 then
			local v27 = v25
			v25 = v26
			v26 = v27
		end
		v16 = math.max(v16, v26)
		v18 = math.min(v18, v25)
		if v18 < v16 then
			return false
		end
	end
	local v28 = p12.Z
	if math.abs(v28) < 0.0001 then
		if p11.Z < p13.Z or p11.Z > p14.Z then
			return false
		end
	else
		local v29 = 1 / p12.Z
		local v30 = (p13.Z - p11.Z) * v29
		local v31 = (p14.Z - p11.Z) * v29
		if v31 >= v30 then
			local v32 = v30
			v30 = v31
			v31 = v32
		end
		v16 = math.max(v16, v31)
		if math.min(v18, v30) < v16 then
			return false
		end
	end
	return v16 <= p15
end
local function v_u_43(p34, p35, p36) -- name: ConfigureEmitter
	local v37 = {}
	for _, v38 in ipairs(p34.Size.Keypoints) do
		local v39 = NumberSequenceKeypoint.new
		local v40 = v38.Time
		local v41 = v38.Value * p35
		local v42 = v38.Envelope * p35
		table.insert(v37, v39(v40, v41, v42))
	end
	p34.Size = NumberSequence.new(v37)
	if p36 then
		p34.Color = ColorSequence.new(p36)
	end
	p34.Enabled = false
end
local function v_u_55(p44, p45, p46, p47) -- name: CreateVoxel
	-- upvalues: (copy) v_u_4, (copy) v_u_43, (copy) v_u_7
	local v48 = v_u_4:Clone()
	v48.Name = "SmokeVoxel"
	v48.Size = Vector3.new(p45, p45, p45)
	v48.Position = p44
	v48.Anchored = true
	v48.CanCollide = false
	v48.CanQuery = false
	v48.CanTouch = false
	v48.CastShadow = false
	v48.Parent = p46
	local v49 = p45 / 4
	local v50 = {}
	for _, v51 in ipairs(v48:GetDescendants()) do
		if not v51:IsA("ParticleEmitter") then
			continue
		end
		v_u_43(v51, v49, p47)
		table.insert(v50, v51)
	end
	for _, v52 in ipairs(v48:GetChildren()) do
		if not v52:IsA("BillboardGui") then
			continue
		end
		v52:Destroy()
	end
	local v53 = p45 / 2
	local v54 = Vector3.new(v53, v53, v53)
	v_u_7[v48] = {
		["voxel"] = nil,
		["emitters"] = nil,
		["isActive"] = false,
		["lastEmitTime"] = 0,
		["scaleFactor"] = nil,
		["teamColor"] = nil,
		["lifetimeExtended"] = false,
		["activatedTime"] = 0,
		["emissionStopped"] = false,
		["minimum"] = nil,
		["maximum"] = nil,
		["voxel"] = v48,
		["emitters"] = v50,
		["scaleFactor"] = v49,
		["teamColor"] = p47,
		["minimum"] = p44 - v54,
		["maximum"] = p44 + v54
	}
	return v48
end
local function v_u_58(p56) -- name: DestroyVoxels
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_7
	for _, v57 in ipairs(p56) do
		if not v57:IsA("BasePart") then
			continue
		end
		v_u_8[v57] = nil
		v_u_9[v57] = nil
		v_u_7[v57] = nil
		v57:Destroy()
	end
end
local function v_u_78(p59, p60) -- name: DeploySmoke
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_9, (ref) v_u_10, (copy) v_u_3
	debug.profilebegin("VFX.VoxelSmoke.DeploySmoke")
	local v61 = Vector3.new(0, 0, 0)
	local v62 = {}
	for _, v63 in ipairs(p59:GetChildren()) do
		if not v63:IsA("BasePart") then
			continue
		end
		v61 = v61 + v63.Position
		table.insert(v62, v63)
	end
	if #v62 == 0 then
		debug.profileend()
	else
		local v64 = v61 / #v62
		local v65 = 0
		for _, v66 in ipairs(v62) do
			local v67 = (v66.Position - v64).Magnitude
			if v65 >= v67 then
				continue
			end
			v65 = v67
		end
		local v68 = v65 == 0 and 1 or v65
		for _, v_u_69 in ipairs(v62) do
			local v70 = (v_u_69.Position - v64).Magnitude / v68 * p60
			task.delay(v70, function()
				-- upvalues: (copy) v_u_69, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_3
				if v_u_69.Parent then
					local v71 = v_u_7[v_u_69]
					if v71 then
						v71.isActive = true
						v_u_8[v_u_69] = v71
						v_u_9[v71.voxel] = v71
						if v_u_10 then
							return
						end
						v_u_10 = v_u_3.BindToHeartbeat("VFX.CreateVoxelSmoke.Emitters", function()
							-- upvalues: (ref) v_u_9, (ref) v_u_10
							local v72 = tick()
							for v73, v74 in pairs(v_u_9) do
								if v73.Parent and (v74.isActive and not v74.emissionStopped) then
									if not v74.lifetimeExtended then
										v74.lifetimeExtended = true
										v74.activatedTime = v72
										for _, v75 in ipairs(v74.emitters) do
											if not (v75 and v75.Parent) then
												continue
											end
											v75.Lifetime = NumberRange.new((1 / 0))
										end
									end
									local v76 = v72 - v74.activatedTime
									if v76 >= 0.8 then
										v74.emissionStopped = true
										v_u_9[v73] = nil
									else
										if 0.1 + 0.30000000000000004 * (v76 / 0.8) > v72 - v74.lastEmitTime then
											continue
										end
										v74.lastEmitTime = v72
										for _, v77 in ipairs(v74.emitters) do
											if not (v77 and v77.Parent) then
												continue
											end
											v77:Emit(1)
										end
									end
								else
									v_u_9[v73] = nil
								end
							end
							if next(v_u_9) == nil and v_u_10 then
								v_u_10:Disconnect()
								v_u_10 = nil
							end
						end)
					end
				end
			end)
		end
		debug.profileend()
	end
end
local function v_u_84(p_u_79) -- name: FadeOutSmoke
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_9, (ref) v_u_10, (copy) v_u_58
	debug.profilebegin("VFX.VoxelSmoke.FadeOutSmoke")
	local v_u_80 = p_u_79:GetChildren()
	for _, v81 in ipairs(v_u_80) do
		if not v81:IsA("BasePart") then
			continue
		end
		local v82 = v_u_7[v81]
		if not v82 then
			continue
		end
		v82.isActive = false
		v_u_8[v81] = nil
		v_u_9[v82.voxel] = nil
		if next(v_u_9) == nil and v_u_10 then
			v_u_10:Disconnect()
			v_u_10 = nil
		end
		for _, v83 in ipairs(v82.emitters) do
			if not (v83 and v83.Parent) then
				continue
			end
			v83.Enabled = false
		end
	end
	task.delay(6, function()
		-- upvalues: (ref) v_u_58, (copy) v_u_80, (ref) v_u_9, (ref) v_u_10, (copy) p_u_79
		debug.profilebegin("VFX.VoxelSmoke.FadeOutSmoke.DelayedCleanup")
		v_u_58(v_u_80)
		if next(v_u_9) == nil and v_u_10 then
			v_u_10:Disconnect()
			v_u_10 = nil
		end
		if p_u_79.Parent then
			p_u_79:Destroy()
		end
		debug.profileend()
	end)
	debug.profileend()
end
return {
	["Create"] = function(p_u_85) -- name: Create
		-- upvalues: (copy) v_u_6, (copy) v_u_5, (copy) v_u_55, (copy) v_u_2, (copy) v_u_78, (copy) v_u_84
		debug.profilebegin("VFX.VoxelSmoke.Create")
		local v_u_86 = Instance.new("Folder")
		v_u_86.Name = "VoxelSmoke_" .. p_u_85.SmokeId
		v_u_6[p_u_85.SmokeId] = v_u_86
		local v87 = p_u_85.Team
		if v87 then
			v87 = v_u_5[p_u_85.Team]
		end
		debug.profilebegin("VFX.VoxelSmoke.Create.CreateVoxels")
		for _, v88 in ipairs(p_u_85.Voxels) do
			v_u_55(v88.Position, v88.Size, v_u_86, v87)
		end
		debug.profileend()
		v_u_86.Parent = v_u_2:WaitForChild("Debris")
		v_u_78(v_u_86, p_u_85.DeployTime)
		task.delay(p_u_85.Duration, function()
			-- upvalues: (ref) v_u_6, (copy) p_u_85, (ref) v_u_84, (copy) v_u_86
			if v_u_6[p_u_85.SmokeId] then
				v_u_84(v_u_86)
				v_u_6[p_u_85.SmokeId] = nil
			end
		end)
		debug.profileend()
	end,
	["Destroy"] = function(p89) -- name: Destroy
		-- upvalues: (copy) v_u_6, (copy) v_u_84
		debug.profilebegin("VFX.VoxelSmoke.Destroy")
		local v90 = v_u_6[p89]
		if v90 then
			v_u_84(v90)
			v_u_6[p89] = nil
		end
		debug.profileend()
	end,
	["DestroyAll"] = function() -- name: DestroyAll
		-- upvalues: (copy) v_u_6, (copy) v_u_58, (copy) v_u_9, (ref) v_u_10
		debug.profilebegin("VFX.VoxelSmoke.DestroyAll")
		for v91, v92 in pairs(v_u_6) do
			v_u_58(v92:GetChildren())
			v92:Destroy()
			v_u_6[v91] = nil
		end
		if next(v_u_9) == nil and v_u_10 then
			v_u_10:Disconnect()
			v_u_10 = nil
		end
		debug.profileend()
	end,
	["Disrupt"] = function(p93, p94, p95) -- name: Disrupt
		-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_8, (copy) v_u_9, (ref) v_u_10, (copy) v_u_4, (copy) v_u_43, (copy) v_u_3
		debug.profilebegin("VFX.VoxelSmoke.Disrupt")
		for _, v96 in pairs(v_u_6) do
			for _, v_u_97 in ipairs(v96:GetChildren()) do
				if not v_u_97:IsA("BasePart") or p94 < (v_u_97.Position - p93).Magnitude then
					continue
				end
				local v_u_98 = v_u_7[v_u_97]
				if not (v_u_98 and v_u_98.isActive) then
					continue
				end
				v_u_98.isActive = false
				v_u_8[v_u_97] = nil
				v_u_9[v_u_98.voxel] = nil
				if next(v_u_9) == nil and v_u_10 then
					v_u_10:Disconnect()
					v_u_10 = nil
				end
				local v_u_99 = v_u_98.scaleFactor
				for _, v100 in ipairs(v_u_98.emitters) do
					if not (v100 and v100.Parent) then
						continue
					end
					v100:Destroy()
				end
				v_u_98.emitters = {}
				local v_u_101 = v_u_98.teamColor
				task.delay(p95, function()
					-- upvalues: (ref) v_u_7, (copy) v_u_97, (ref) v_u_4, (ref) v_u_43, (copy) v_u_99, (copy) v_u_101, (copy) v_u_98, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_3
					debug.profilebegin("VFX.VoxelSmoke.Disrupt.RestoreEmitters")
					if v_u_7[v_u_97] and v_u_97.Parent then
						local v102 = {}
						for _, v103 in ipairs(v_u_4:GetDescendants()) do
							if not v103:IsA("ParticleEmitter") then
								continue
							end
							local v104 = v103:Clone()
							v_u_43(v104, v_u_99, v_u_101)
							v104.Parent = v_u_97
							table.insert(v102, v104)
						end
						v_u_98.emitters = v102
						v_u_98.lastEmitTime = 0
						v_u_98.isActive = true
						v_u_98.lifetimeExtended = false
						v_u_98.activatedTime = 0
						v_u_98.emissionStopped = false
						v_u_8[v_u_97] = v_u_98
						local v105 = v_u_98
						v_u_9[v105.voxel] = v105
						if not v_u_10 then
							v_u_10 = v_u_3.BindToHeartbeat("VFX.CreateVoxelSmoke.Emitters", function()
								-- upvalues: (ref) v_u_9, (ref) v_u_10
								local v106 = tick()
								for v107, v108 in pairs(v_u_9) do
									if v107.Parent and (v108.isActive and not v108.emissionStopped) then
										if not v108.lifetimeExtended then
											v108.lifetimeExtended = true
											v108.activatedTime = v106
											for _, v109 in ipairs(v108.emitters) do
												if not (v109 and v109.Parent) then
													continue
												end
												v109.Lifetime = NumberRange.new((1 / 0))
											end
										end
										local v110 = v106 - v108.activatedTime
										if v110 >= 0.8 then
											v108.emissionStopped = true
											v_u_9[v107] = nil
										else
											if 0.1 + 0.30000000000000004 * (v110 / 0.8) > v106 - v108.lastEmitTime then
												continue
											end
											v108.lastEmitTime = v106
											for _, v111 in ipairs(v108.emitters) do
												if not (v111 and v111.Parent) then
													continue
												end
												v111:Emit(1)
											end
										end
									else
										v_u_9[v107] = nil
									end
								end
								if next(v_u_9) == nil and v_u_10 then
									v_u_10:Disconnect()
									v_u_10 = nil
								end
							end)
						end
						debug.profileend()
					else
						debug.profileend()
					end
				end)
			end
		end
		debug.profileend()
	end,
	["DoesRayIntersectActiveSmoke"] = function(p112, p113, p114) -- name: DoesRayIntersectActiveSmoke
		-- upvalues: (copy) v_u_8, (copy) v_u_33
		for _, v115 in pairs(v_u_8) do
			if not v_u_33(p112, p113, v115.minimum, v115.maximum, p114) then
				continue
			end
			return true
		end
		return false
	end
}
-- NIGHT Analyzer | ReplicatedStorage.Components.Common.FormatDuration
-- ModuleScript | 23 linhas | 565 bytes | hash d09ad860

return function(p1, p2)
	local v3 = p2 or "Never"
	local v4 = math.floor(p1)
	local v5 = math.max(0, v4)
	local v6 = v5 / 86400
	local v7 = math.floor(v6)
	local v8
	if v3 == "Never" then
		local v9 = v5 / 3600
		v8 = math.floor(v9)
	else
		local v10 = v5 % 86400 / 3600
		v8 = math.floor(v10)
	end
	local v11 = v5 % 3600 / 60
	local v12 = math.floor(v11)
	local v13 = v5 % 60
	if v3 == "Always" or v3 == "IfNeeded" and v7 > 0 then
		return string.format("%02d:%02d:%02d:%02d", v7, v8, v12, v13)
	else
		return string.format("%02d:%02d:%02d", v8, v12, v13)
	end
end
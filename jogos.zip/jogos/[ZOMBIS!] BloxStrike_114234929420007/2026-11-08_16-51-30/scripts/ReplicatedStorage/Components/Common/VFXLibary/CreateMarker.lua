-- NIGHT Analyzer | ReplicatedStorage.Components.Common.VFXLibary.CreateMarker
-- ModuleScript | 121 linhas | 3613 bytes | hash c646430e

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("RunService")
local v3 = v1:WaitForChild("Assets")
local v4 = require(v1.Shared.ObjectPool)
local v5 = v3:WaitForChild("Other")
local v6 = workspace:WaitForChild("Debris")
local v_u_7 = {
	["Bullet"] = require(script.Components.Bullet),
	["Melee"] = require(script.Components.Melee)
}
local v_u_8 = CFrame.new(0, -10000, 0)
local v_u_9 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_10 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_11 = {}
local v12 = v5:WaitForChild("HitMarker")
local v_u_18 = v4.new(v12, {
	["InitialSize"] = nil,
	["MaxRetained"] = 20,
	["Prepare"] = nil,
	["Reset"] = nil,
	["InPlace"] = true,
	["StorageParent"] = nil,
	["StorageName"] = "BulletMarkers",
	["InitialSize"] = v2:IsClient() and 20 or 0,
	["Prepare"] = function(p13) -- name: initMarkerPart
		-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_10
		p13.CollisionGroup = "Debris"
		p13.CanCollide = false
		p13.CanQuery = false
		p13.CanTouch = false
		p13.Anchored = true
		p13.CFrame = v_u_8
		local v14 = {}
		for _, v15 in ipairs(p13:GetDescendants()) do
			if not v15:IsA("Decal") then
				continue
			end
			table.insert(v14, v15)
		end
		v_u_9[p13] = v14
		local v16 = Instance.new("WeldConstraint")
		v16.Enabled = false
		v16.Part0 = p13
		v16.Parent = p13
		v_u_10[p13] = v16
	end,
	["Reset"] = function(p17) -- name: hideMarkerPart
		-- upvalues: (copy) v_u_8
		p17.Anchored = true
		p17.CFrame = v_u_8
	end,
	["StorageParent"] = v6
})
return function(p_u_19, p20, p21, p22)
	-- upvalues: (copy) v_u_7, (copy) v_u_11, (copy) v_u_18, (copy) v_u_10, (copy) v_u_9
	if p_u_19 == nil or p_u_19.ClassName ~= "Terrain" then
		local v23 = v_u_7[p20]
		local v24 = ("%* is not apart of library \"MarkerInfo\""):format(p20)
		assert(v23, v24)
		debug.profilebegin("VFX.Marker")
		local v25 = #v_u_11 >= 20 and table.remove(v_u_11, 1)
		if v25 then
			v25()
		end
		local v_u_26, v_u_27 = v_u_18:Acquire()
		local v_u_28 = v_u_10[v_u_26]
		local v29 = v23.Properties.SizeRange()
		v_u_26.Size = Vector3.new(v29, v29, 0.001)
		v_u_26.CFrame = CFrame.new(p21, p21 + p22) * CFrame.Angles(0, 0, v23.Properties.Rotation() * 3.141592653589793 / 180)
		for _, v30 in ipairs(v_u_9[v_u_26]) do
			v30.Transparency = v23.Properties.Transparency()
			v30.Texture = v23.Images[math.random(1, #v23.Images)]
			v30.Color3 = v23.Properties.Color3
		end
		local v31 = p_u_19 ~= nil and p_u_19:IsA("BasePart")
		if v31 then
			v31 = not p_u_19.Anchored
		end
		if v31 then
			v_u_28.Part1 = p_u_19
			v_u_28.Enabled = true
			v_u_26.Anchored = false
		end
		local v_u_32 = {}
		local function v_u_35() -- name: release
			-- upvalues: (copy) v_u_32, (ref) v_u_18, (copy) v_u_26, (copy) v_u_27, (copy) v_u_28, (ref) v_u_11, (copy) v_u_35
			for _, v33 in ipairs(v_u_32) do
				v33:Disconnect()
			end
			table.clear(v_u_32)
			if v_u_18:IsAcquired(v_u_26, v_u_27) then
				v_u_28.Enabled = false
				v_u_28.Part1 = nil
				v_u_18:Release(v_u_26, v_u_27)
			end
			local v34 = table.find(v_u_11, v_u_35)
			if v34 then
				table.remove(v_u_11, v34)
			end
		end
		local v36 = v_u_11
		table.insert(v36, v_u_35)
		if p_u_19 ~= nil and (p_u_19:IsA("BasePart") and p_u_19:IsDescendantOf(workspace)) then
			local v37 = p_u_19.Destroying
			table.insert(v_u_32, v37:Once(v_u_35))
			local v38 = p_u_19:GetPropertyChangedSignal("Transparency")
			table.insert(v_u_32, v38:Connect(function()
				-- upvalues: (copy) p_u_19, (copy) v_u_35
				if p_u_19.Transparency == 1 then
					v_u_35()
				end
			end))
		end
		task.delay(15, v_u_35)
		debug.profileend()
	end
end
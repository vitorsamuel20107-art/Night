-- NIGHT Analyzer | ReplicatedStorage.Components.Common.SurvivalState
-- ModuleScript | 35 linhas | 1234 bytes | hash d54b68f2

local v_u_5 = {
	["WAVE_ATTRIBUTE"] = "SurvivalWave",
	["WAVES_ATTRIBUTE"] = "SurvivalWaves",
	["RESUPPLY_ATTRIBUTE"] = "SurvivalResupply",
	["WAVE_STARTED_ATTRIBUTE"] = "SurvivalWaveStartedAt",
	["FLAMING_WAVE_ATTRIBUTE"] = "SurvivalFlamingWave",
	["GetWave"] = function() -- name: GetWave
		-- upvalues: (copy) v_u_5
		local v1 = workspace:GetAttribute(v_u_5.WAVE_ATTRIBUTE)
		return typeof(v1) ~= "number" and 0 or v1
	end,
	["GetWaveCount"] = function() -- name: GetWaveCount
		-- upvalues: (copy) v_u_5
		local v2 = workspace:GetAttribute(v_u_5.WAVES_ATTRIBUTE)
		return typeof(v2) ~= "number" and 0 or v2
	end,
	["IsResupply"] = function() -- name: IsResupply
		-- upvalues: (copy) v_u_5
		return workspace:GetAttribute(v_u_5.RESUPPLY_ATTRIBUTE) == true
	end,
	["IsFlamingWave"] = function() -- name: IsFlamingWave
		-- upvalues: (copy) v_u_5
		return workspace:GetAttribute(v_u_5.FLAMING_WAVE_ATTRIBUTE) == true
	end,
	["GetWaveElapsed"] = function() -- name: GetWaveElapsed
		-- upvalues: (copy) v_u_5
		local v3 = workspace:GetAttribute(v_u_5.WAVE_STARTED_ATTRIBUTE)
		if typeof(v3) ~= "number" then
			return nil
		end
		local v4 = workspace:GetServerTimeNow() - v3
		return math.max(v4, 0)
	end
}
return table.freeze(v_u_5)
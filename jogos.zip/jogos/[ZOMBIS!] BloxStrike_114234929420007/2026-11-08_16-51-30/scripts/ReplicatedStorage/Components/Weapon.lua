-- NIGHT Analyzer | ReplicatedStorage.Components.Weapon
-- ModuleScript | 1985 linhas | 64963 bytes | hash 0c4c0dc8

local v_u_1 = {}
v_u_1.__index = v_u_1
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("HttpService")
local v4 = game:GetService("Players")
require(v_u_2.Database.Custom.Types)
require(script:WaitForChild("Types"))
local v_u_5 = require(v_u_2.Classes.WeaponComponent)
local v6 = require(v_u_2.Classes.Sound)
local v_u_7 = require(v_u_2.Components.Common.VFXLibary.CreateMuzzleFlash.Camera)
local v_u_8 = require(v_u_2.Components.Common.VFXLibary.CreateZeusBeam)
local v_u_9 = require(v_u_2.Components.Common.VFXLibary.CreateBloodSplatter)
local v_u_10 = require(v_u_2.Components.Common.VFXLibary.CreateMarker)
local v_u_11 = require(v_u_2.Components.Common.VFXLibary.CreateImpact)
local v_u_12 = require(v_u_2.Components.Common.VFXLibary.CreateTracer)
local v_u_13 = require(v_u_2.Components.Common.VFXLibary.BreakGlass)
local v_u_14 = require(v_u_2.Components.Common.CharacterResolver)
local v_u_15 = require(v_u_2.Components.Common.SurvivalDowned)
local v_u_16 = require(v_u_2.Components.Common.IsTutorialMode)
local v_u_17 = require(v_u_2.Components.Common.Participants)
local v_u_18 = require(v_u_2.Components.Common.GetCharacterVelocity)
local v_u_19 = require(v_u_2.Components.Common.PlayerHitPrediction)
local v_u_20 = require(v_u_2.Components.Common.ReplicateCharacterAction)
local v_u_21 = require(v_u_2.Components.Common.GetWeaponCameraKick)
local v_u_22 = require(v_u_2.Components.Common.WeaponTimings)
local v_u_23 = require(v_u_2.Components.Common.SurvivalBuyRules)
local v_u_24 = require(v_u_2.Components.Common.HordeProtocol)
local v_u_25 = require(v_u_2.Controllers.HapticsController)
local v_u_26 = require(v_u_2.Controllers.CameraController)
local v_u_27 = require(v_u_2.Controllers.SoundController)
local v_u_28 = require(v_u_2.Controllers.InputController)
local v_u_29 = require(v_u_2.Controllers.HintController)
local v_u_30 = require(v_u_2.Controllers.DataController)
local v_u_31 = require(v_u_2.Controllers.RunServiceController)
local v_u_32 = require(v_u_2.Database.Components.GameState)
local v_u_33 = require(v_u_2.Database.Security.Remotes)
local v_u_34 = require(v_u_2.Database.Security.Router)
local v_u_35 = require(v_u_2.Database.Custom.Constants)
local v_u_36 = require(script.Classes.Bullet)
local v_u_37 = workspace.CurrentCamera
local v_u_38 = v4.LocalPlayer
local v_u_39 = v6.new("Other")
local v_u_40 = { 37, 60 }
local v_u_41 = { Enum.UserInputType.MouseButton1, Enum.KeyCode.ButtonR2 }
local v_u_42 = { Enum.UserInputType.MouseButton2, Enum.KeyCode.ButtonL2 }
local v_u_43 = workspace:GetAttribute("VIPInfiniteAmmoEnabled") == true
workspace:GetAttributeChangedSignal("VIPInfiniteAmmoEnabled"):Connect(function()
	-- upvalues: (ref) v_u_43
	v_u_43 = workspace:GetAttribute("VIPInfiniteAmmoEnabled") == true
end)
local v_u_44 = v_u_43
local v_u_45 = {}
for _, v46 in ipairs(v_u_2.Database.Custom.Weapons:GetChildren()) do
	if not v46:IsA("ModuleScript") then
		continue
	end
	v_u_45[v46.Name] = require(v46)
end
local function v_u_49(p47) -- name: botVictimKey
	-- upvalues: (copy) v_u_17
	if p47 then
		p47 = p47:FindFirstAncestorOfClass("Model")
	end
	local v48
	if p47 and p47:GetAttribute("Bot") == true then
		v48 = p47:GetAttribute("CombatantId")
	else
		v48 = nil
	end
	if typeof(v48) == "number" then
		return v_u_17.BotKey(v48)
	else
		return nil
	end
end
local function v_u_51(p50) -- name: classifyHit
	-- upvalues: (copy) v_u_14, (copy) v_u_24
	if p50 then
		p50 = p50:FindFirstAncestorOfClass("Model")
	end
	return p50 == nil and "World" or (v_u_14.getPlayerFromCharacter(p50) == nil and (p50:GetAttribute("Bot") ~= true and not v_u_14.isTutorialDummy(p50)) and (p50:GetAttribute(v_u_24.ID_ATTRIBUTE) == nil and "World" or "Horde") or "Character")
end
local function v_u_53(p52) -- name: playOtherSound
	-- upvalues: (copy) v_u_39, (copy) v_u_38
	return v_u_39:play({
		["Parent"] = v_u_38.PlayerGui,
		["Name"] = p52
	})
end
local function v_u_57() -- name: restoreDefaultFovUnlessSceneActive
	-- upvalues: (copy) v_u_2, (copy) v_u_26, (copy) v_u_35
	local v54 = require(v_u_2.Controllers.CaseSceneController)
	local v55 = require(v_u_2.Controllers.MenuSceneController)
	local v56 = require(v_u_2.Controllers.BlackMarketSceneController)
	if not (v54.IsActive() or (v55.IsActive() or v56.IsActive())) then
		v_u_26.updateCameraFOV(v_u_35.DEFAULT_CAMERA_FOV)
	end
end
local function v_u_63(p58, p59) -- name: getPressedActionBinding
	-- upvalues: (copy) v_u_28
	local v60 = v_u_28.getActionKeybinds(p58)
	for _, v61 in ipairs(v60) do
		if not v_u_28.isBindingPressed(v61) then
			continue
		end
		return v61
	end
	if p59 and #v60 == 0 then
		for _, v62 in ipairs(p59) do
			if not v_u_28.isBindingPressed(v62) then
				continue
			end
			return v62
		end
	end
	return nil
end
local function v_u_70(p64, p65) -- name: buildActiveRecoilPattern
	local v66 = p64.Properties.Recoil
	if not v66 then
		return nil
	end
	local v67 = p64.Properties
	if p64.Properties.ShootingOptions == "Revolver" and p65 then
		v67 = table.clone(p64.Properties)
		local v68 = p64.Properties.FireModes
		local v69 = not v68 or p65 == "Secondary" and v68.Secondary or v68.Primary
		v67.FireRate = v69 and v69.FireRate or (p64.Properties.FireRate or 0.1)
	end
	return v66.Pattern(v67)
end
local function v_u_80(p71, p72) -- name: applyActiveRecoilProfile
	-- upvalues: (copy) v_u_70
	local v73 = p71.Recoil
	if v73 then
		local v74 = p71.Properties.ShootingOptions == "Revolver" and p72 and p72 or "Default"
		local v75 = p71.Properties.FireModes
		local v76 = not v75 or p72 == "Secondary" and v75.Secondary or v75.Primary
		local v77 = v76 and v76.FireRate or (p71.Properties.FireRate or 0.1)
		local v78 = v73.Functions[v74]
		if not v78 then
			v78 = v_u_70(p71, p72)
			if not v78 then
				return
			end
			v73.Functions[v74] = v78
		end
		local v79 = v73.ActiveFireRate
		if v79 > 0 and (v77 > 0 and v79 ~= v77) then
			v73.Time = v73.Time / v79 * v77
		end
		v73.Function = v78
		v73.ActiveFireRate = v77
	end
end
local function v_u_91(p_u_81) -- name: startRechargeTimer
	-- upvalues: (ref) v_u_44
	local v82 = p_u_81.Properties.RechargeTime
	local v_u_83 = p_u_81.Properties.Rounds
	if v82 and v_u_83 then
		local v84 = p_u_81.RechargeThread
		if v84 then
			task.cancel(v84)
			p_u_81.RechargeThread = nil
		end
		if v_u_44 then
			p_u_81.Rounds = v_u_83
			p_u_81.RechargeStartTime = nil
			return
		elseif v_u_83 <= p_u_81.Rounds then
			p_u_81.RechargeStartTime = nil
			return
		else
			local v85 = workspace:GetServerTimeNow()
			local v_u_86 = p_u_81.Identifier
			local v87 = p_u_81.RechargeStartTime or v85
			local v88 = v85 - v87
			local v89 = v82 - math.max(v88, 0)
			local v90 = math.max(v89, 0)
			p_u_81.RechargeStartTime = v87
			if v90 <= 0 then
				p_u_81.Rounds = v_u_83
				p_u_81.RechargeStartTime = nil
			else
				p_u_81.RechargeThread = task.delay(v90, function()
					-- upvalues: (copy) p_u_81, (copy) v_u_86, (copy) v_u_83
					if not p_u_81.IsDestroyed and p_u_81.Identifier == v_u_86 then
						p_u_81.RechargeThread = nil
						p_u_81.Rounds = v_u_83
						p_u_81.RechargeStartTime = nil
					end
				end)
			end
		end
	else
		return
	end
end
local function v_u_100(p92, p93, p94, p95) -- name: resolveFireAnimationNames
	local v96 = p92.Properties.FireModes
	local v97 = not v96 or p95 == "Secondary" and v96.Secondary or v96.Primary
	if not v97 then
		return p93, p94
	end
	local v98 = v97.Animation
	if v98 and (p92.Viewmodel and p92.Viewmodel.Animation) then
		if not p92.Viewmodel.Animation:getAnimation(v98) then
			v98 = p93
		end
	else
		v98 = p93
	end
	local v99 = v97.CharacterAnimation
	if v99 and p92.CharacterAnimator then
		if not p92.CharacterAnimator:getAnimation(v99) then
			v99 = p94
		end
	else
		v99 = p94
	end
	return v98, v99
end
local function v_u_105(p101, p102) -- name: stopRevolverChargeAnimation
	-- upvalues: (copy) v_u_100
	if p101.Viewmodel and (p101.Viewmodel.Animation and p101.CharacterAnimator) then
		local v103, v104 = v_u_100(p101, "Shoot", "Shoot", "Primary")
		p101.Viewmodel.Animation:cancelCrossfade()
		p101.Viewmodel.Animation:stop(v103)
		p101.CharacterAnimator:stop(v104)
		if p102 ~= false and p101.IsEquipped then
			p101.Viewmodel.Animation:play("Idle")
			p101.CharacterAnimator:play("Idle")
		end
	end
end
local function v_u_114(p106) -- name: completeRevolverChargeShot
	-- upvalues: (copy) v_u_14, (copy) v_u_32, (copy) v_u_38, (copy) v_u_15, (copy) v_u_80
	if p106.IsDestroyed or not (p106.IsEquipped and p106.IsChargeFiring) then
		return
	else
		local v107 = v_u_14.getLocalCharacter()
		local v108 = not v107 or v107:GetAttribute("Dead")
		if v108 or v_u_32.GetState() == "Buy Period" or (v_u_38:GetAttribute("IsDefusingBomb") == true or v_u_38:GetAttribute("IsLocallyDefusingBomb") == true or not v_u_15.CanUseSlot(v_u_38, p106.Properties.Slot)) then
			p106:cancelRevolverCharge(false, not v108)
			return
		else
			p106.CurrentWalkSpeedOverride = nil
			if p106.Rounds > 0 then
				p106:shoot("Primary")
			else
				local v109 = p106.ChargeThread
				if v109 then
					task.cancel(v109)
					p106.ChargeThread = nil
				end
				local v110 = p106.ChargeShootConnection
				if v110 and v110.Connected then
					v110:Disconnect()
				end
				p106.ChargeShootConnection = nil
				p106.HasPendingChargeRequest = false
				p106.IsChargeFiring = false
				p106.ChargeStartTick = 0
				p106.CurrentWalkSpeedOverride = nil
				if p106.Properties.ShootingOptions == "Revolver" then
					if p106.Bullet then
						local v111 = p106.Properties.FireModes
						local v112
						if v111 then
							v112 = v111.Secondary or v111.Primary
						else
							v112 = nil
						end
						local v113 = v112 and v112.Spread or p106.Properties.Spread
						p106.Bullet:setSpreadConfig(v113)
					end
					v_u_80(p106, "Secondary")
				end
				p106:reload()
			end
		end
	end
end
local function v_u_119(p115, p116, p117, p118) -- name: adjustSuppressor
	-- upvalues: (copy) v_u_22, (copy) v_u_20
	if tick() - p115.WeaponEquippedTick > v_u_22.EQUIP_ACTION_LOCKOUT and not (p115.IsAdjustingSuppressor or (p115.IsShooting or (p115.IsReloading or p115.IsAiming))) then
		p115.IsAdjustingSuppressor = true
		p115.IsBurstShooting = false
		p115.IsInspecting = false
		p115.IsReloading = false
		p115.IsShooting = false
		p115.IsAiming = false
		if p118 then
			p115.ScopeStartTick = 0
		end
		p115:stopAllAnimations()
		p115.Viewmodel.Animation:play(p116)
		p115.CharacterAnimator:play(p116)
		v_u_20(p117)
	end
end
function v_u_1.getSpread(p120) -- name: getSpread
	return p120.Bullet:getTrueSpread()
end
function v_u_1.getCrosshairDisplayState(_) -- name: getCrosshairDisplayState
	return nil
end
function v_u_1.getBaseSpread(p121) -- name: getBaseSpread
	return p121.Bullet:getBaseSpread()
end
function v_u_1.releaseFireInput(p122) -- name: releaseFireInput
	p122.IsFireHeld = false
	p122.FireInputBinding = nil
	p122.IsAlternativeFireHeld = false
	p122.AlternativeFireInputBinding = nil
	p122.HasPendingChargeRequest = false
end
function v_u_1.cancelRevolverCharge(p123, p124, p125) -- name: cancelRevolverCharge
	-- upvalues: (copy) v_u_80, (copy) v_u_105, (copy) v_u_20
	local v126 = p123.IsChargeFiring
	local v127 = p123.ChargeThread
	if v127 then
		task.cancel(v127)
		p123.ChargeThread = nil
	end
	local v128 = p123.ChargeShootConnection
	if v128 and v128.Connected then
		v128:Disconnect()
	end
	p123.ChargeShootConnection = nil
	p123.HasPendingChargeRequest = false
	p123.IsChargeFiring = false
	p123.ChargeStartTick = 0
	p123.CurrentWalkSpeedOverride = nil
	if p123.Properties.ShootingOptions == "Revolver" then
		if p123.Bullet then
			local v129 = p123.Properties.FireModes
			local v130
			if v129 then
				v130 = v129.Secondary or v129.Primary
			else
				v130 = nil
			end
			local v131 = v130 and v130.Spread or p123.Properties.Spread
			p123.Bullet:setSpreadConfig(v131)
		end
		v_u_80(p123, "Secondary")
	end
	if v126 then
		v_u_105(p123, p125)
		if p125 ~= false and (p123.IsEquipped and not p123.IsDestroyed) then
			v_u_20("RevolverChargeCancel")
		end
	end
	if p124 ~= true then
		p123.IsFireHeld = false
		p123.FireInputBinding = nil
	end
end
function v_u_1.startRevolverCharge(p_u_132, p133) -- name: startRevolverCharge
	-- upvalues: (copy) v_u_22, (copy) v_u_14, (copy) v_u_32, (copy) v_u_38, (copy) v_u_15, (copy) v_u_34, (copy) v_u_80, (copy) v_u_100, (copy) v_u_114, (copy) v_u_33, (copy) v_u_20
	if p_u_132.Properties.ShootingOptions == "Revolver" then
		local v134 = p_u_132.Properties.FireModes
		local v135
		if v134 then
			v135 = v134.Primary
		else
			v135 = nil
		end
		if v135 and v135.InputBehavior == "Charge" then
			p_u_132:stopRevolverSecondaryFire()
			local v136 = tick() - p_u_132.WeaponEquippedTick
			local v137 = p_u_132.Viewmodel.Animation:getAnimation("Equip")
			local v138 = v_u_22.PulloutSeconds
			local v139
			if v137 then
				v139 = v137.Length
			else
				v139 = nil
			end
			if v136 <= v138(v139) then
				return
			else
				local v140 = v_u_14.getLocalCharacter()
				if v140 and v140:GetAttribute("Dead") then
					return
				elseif v_u_32.GetState() == "Buy Period" or (v_u_38:GetAttribute("IsDefusingBomb") == true or v_u_38:GetAttribute("IsLocallyDefusingBomb") == true or not v_u_15.CanUseSlot(v_u_38, p_u_132.Properties.Slot)) then
					p_u_132.IsFireHeld = false
					p_u_132.FireInputBinding = nil
					p_u_132.IsAlternativeFireHeld = false
					p_u_132.AlternativeFireInputBinding = nil
					p_u_132.HasPendingChargeRequest = false
					return
				elseif p_u_132.IsAdjustingSuppressor or (p_u_132.IsReloading or p_u_132.IsChargeFiring) then
					return
				elseif p_u_132.IsShooting then
					local v141 = tick() - p_u_132.ShootRequestTick
					local v142 = 0
					local v143 = p_u_132.Properties.FireModes
					local v144
					if v143 then
						v144 = v143.Primary
					else
						v144 = nil
					end
					local v145 = (v144 and v144.FireRate or (p_u_132.Properties.FireRate or 0.1)) - v141
					if math.max(v142, v145) <= 0.15 then
						p_u_132.IsFireHeld = true
						p_u_132.FireInputBinding = p133
						p_u_132.HasPendingChargeRequest = true
					end
					return
				elseif p_u_132.Rounds <= 0 then
					p_u_132.IsFireHeld = false
					p_u_132.FireInputBinding = nil
					p_u_132:reload()
				else
					p_u_132.IsFireHeld = true
					p_u_132.FireInputBinding = p133
					p_u_132.HasPendingChargeRequest = false
					p_u_132.IsChargeFiring = true
					v_u_34.broadcastRouter("Cancel Sprint")
					p_u_132.ChargeStartTick = tick()
					p_u_132.CurrentWalkSpeedOverride = v135.HoldWalkSpeed or p_u_132.Properties.WalkSpeed
					if p_u_132.Bullet then
						local v146 = p_u_132.Properties.FireModes
						local v147
						if v146 then
							v147 = v146.Primary
						else
							v147 = nil
						end
						local v148 = v147 and v147.Spread or p_u_132.Properties.Spread
						p_u_132.Bullet:setSpreadConfig(v148)
					end
					v_u_80(p_u_132, "Primary")
					local v149 = p_u_132.Bullet and (v135 and v135.ChargeStartSpread) and (v135.Spread or p_u_132.Properties.Spread)
					if v149 then
						p_u_132.Bullet:setBaseSpreadForConfig(v135.ChargeStartSpread, v149)
					end
					if p_u_132.IsInspecting or p_u_132.IsInspectFadingOut then
						p_u_132:cancelInspect(nil, nil, true)
					end
					local v150 = p_u_132.ChargeThread
					if v150 then
						task.cancel(v150)
						p_u_132.ChargeThread = nil
					end
					local v151 = p_u_132.ChargeShootConnection
					if v151 and v151.Connected then
						v151:Disconnect()
					end
					p_u_132.ChargeShootConnection = nil
					p_u_132:stopAllAnimations()
					local v152, v153 = v_u_100(p_u_132, "Shoot", "Shoot", "Primary")
					local v154 = p_u_132.Viewmodel.Animation:play(v152)
					if v154 then
						v154:AdjustSpeed(1)
						p_u_132.ChargeShootConnection = v154:GetMarkerReachedSignal("Shoot"):Connect(function()
							-- upvalues: (ref) v_u_114, (copy) p_u_132
							v_u_114(p_u_132)
						end)
					end
					local v155 = p_u_132.CharacterAnimator:play(v153)
					if v155 then
						v155:AdjustSpeed(1)
					end
					v_u_33.Sound.ReplicateSound.Send({
						["Class"] = nil,
						["Name"] = "Prepare",
						["Class"] = p_u_132.Name
					})
					v_u_20("RevolverChargeStart")
					if not v154 then
						p_u_132.ChargeThread = task.delay(v135.ChargeTime or 0, function()
							-- upvalues: (ref) v_u_114, (copy) p_u_132
							v_u_114(p_u_132)
						end)
					end
				end
			end
		else
			return
		end
	else
		return
	end
end
function v_u_1.startRevolverSecondaryFire(p156, p157) -- name: startRevolverSecondaryFire
	-- upvalues: (copy) v_u_32, (copy) v_u_38, (copy) v_u_15, (copy) v_u_80
	if p156.Properties.ShootingOptions == "Revolver" then
		if v_u_32.GetState() == "Buy Period" or (v_u_38:GetAttribute("IsDefusingBomb") == true or v_u_38:GetAttribute("IsLocallyDefusingBomb") == true or not v_u_15.CanUseSlot(v_u_38, p156.Properties.Slot)) then
			p156.IsFireHeld = false
			p156.FireInputBinding = nil
			p156.IsAlternativeFireHeld = false
			p156.AlternativeFireInputBinding = nil
			p156.HasPendingChargeRequest = false
			return
		else
			p156:cancelRevolverCharge(false, false)
			p156.IsAlternativeFireHeld = true
			p156.AlternativeFireInputBinding = p157
			if p156.Bullet then
				local v158 = p156.Properties.FireModes
				local v159
				if v158 then
					v159 = v158.Secondary or v158.Primary
				else
					v159 = nil
				end
				local v160 = v159 and v159.Spread or p156.Properties.Spread
				p156.Bullet:setSpreadConfig(v160)
			end
			v_u_80(p156, "Secondary")
			if p156.IsShooting or (p156.IsReloading or p156.IsAdjustingSuppressor) then
				return
			elseif p156.Rounds > 0 then
				p156:shoot("Secondary")
			else
				p156:reload()
			end
		end
	else
		return
	end
end
function v_u_1.stopRevolverSecondaryFire(p161) -- name: stopRevolverSecondaryFire
	-- upvalues: (copy) v_u_80
	p161.IsAlternativeFireHeld = false
	p161.AlternativeFireInputBinding = nil
	if not p161.IsChargeFiring and p161.Properties.ShootingOptions == "Revolver" then
		if p161.Bullet then
			local v162 = p161.Properties.FireModes
			local v163
			if v162 then
				v163 = v162.Secondary or v162.Primary
			else
				v163 = nil
			end
			local v164 = v163 and v163.Spread or p161.Properties.Spread
			p161.Bullet:setSpreadConfig(v164)
		end
		v_u_80(p161, "Secondary")
	end
end
function v_u_1.stopAllAnimations(p165) -- name: stopAllAnimations
	if p165.CharacterAnimator and (p165.Viewmodel and p165.Viewmodel.Animation) then
		p165.Viewmodel.Animation:cancelCrossfade()
		for v166, v167 in pairs(p165.CharacterAnimator.Animations) do
			if not v167.IsPlaying or v167.Name == "Idle" then
				continue
			end
			p165.CharacterAnimator:stop(v166)
		end
		for v168, v169 in pairs(p165.Viewmodel.Animation.Animations) do
			if not v169.IsPlaying or v169.Name == "Idle" then
				continue
			end
			p165.Viewmodel.Animation:stop(v168)
		end
	end
end
function v_u_1.removeSuppressor(p170) -- name: removeSuppressor
	-- upvalues: (copy) v_u_119
	v_u_119(p170, "RemoveSuppressor", "Remove Suppressor", true)
end
function v_u_1.addSuppressor(p171) -- name: addSuppressor
	-- upvalues: (copy) v_u_119
	v_u_119(p171, "AddSuppressor", "Add Suppressor", false)
end
function v_u_1.scope(p172, p173) -- name: scope
	-- upvalues: (copy) v_u_22, (copy) v_u_15, (copy) v_u_38, (copy) v_u_34, (copy) v_u_39, (copy) v_u_26, (copy) v_u_35, (copy) v_u_40, (copy) v_u_33
	if p172.Viewmodel and (tick() - p172.WeaponEquippedTick > v_u_22.EQUIP_ACTION_LOCKOUT and v_u_15.CanUseSlot(v_u_38, p172.Properties.Slot)) then
		local v174 = p172.Properties.AimingOptions == "AutomaticScope"
		if not p172.IsAdjustingSuppressor and (not p172.IsReloading and (not p172.IsShooting or v174)) and not p172.IsDestroyed then
			if p172.Properties.HasScope then
				if not p172.IsAiming then
					p172:stopAllAnimations()
				end
				p172.IsBurstShooting = false
				p172.IsInspecting = false
				p172.IsReloading = false
				p172.IsShooting = false
				if not p172.IsAiming then
					p172.ScopeStartTick = tick()
					v_u_34.broadcastRouter("Cancel Sprint")
				end
				p172.IsAiming = true
				if p172.Name == "SSG 08" or p172.Name == "AWP" then
					p172.IsSniperScoped = true
					if p172.Name == "AWP" and p172.Player then
						p172.Player:SetAttribute("IsSniperScoped", true)
					end
				end
				if p172.Properties.AimingOptions == "SniperScope" then
					if not p172.Viewmodel.Hidden then
						p172.Viewmodel:hide()
					end
					v_u_39:play({
						["Parent"] = nil,
						["Name"] = "Toggle Scope",
						["Parent"] = v_u_38.PlayerGui
					})
					local v175
					if p173 then
						p172.CurrentScopeIncrement = p172.CurrentScopeIncrement + 1
						if p172.CurrentScopeIncrement >= 3 then
							p172:unscope(nil, nil, "Toggle Scope")
							return
						end
						v175 = p172.CurrentScopeIncrement
					else
						v175 = 1
					end
					v_u_26.updateCameraFOV(v_u_35.DEFAULT_CAMERA_FOV - v_u_40[v175])
					v_u_33.Inventory.UpdateScopeIncrement.Send({
						["Increment"] = nil,
						["SoundName"] = "Toggle Scope",
						["Increment"] = v175
					})
					return
				end
				if p172.Properties.AimingOptions == "AutomaticScope" then
					if p172.CurrentScopeIncrement == 1 then
						p172:unscope()
						return
					end
					p172.CurrentScopeIncrement = 1
					if not p172.Viewmodel.Hidden then
						p172.Viewmodel:hide()
					end
					p172.Viewmodel:aim()
					v_u_26.updateCameraFOV(v_u_35.DEFAULT_CAMERA_FOV - 15 * p172.CurrentScopeIncrement)
					v_u_33.Inventory.UpdateScopeIncrement.Send({
						["Increment"] = nil,
						["SoundName"] = "Scope In",
						["Increment"] = p172.CurrentScopeIncrement
					})
					v_u_39:play({
						["Parent"] = nil,
						["Name"] = "Scope In",
						["Parent"] = v_u_38.PlayerGui
					})
				end
			end
		end
	else
		return
	end
end
function v_u_1.unscope(p176, p177, p178, p179) -- name: unscope
	-- upvalues: (copy) v_u_22, (copy) v_u_33, (copy) v_u_57, (copy) v_u_26, (copy) v_u_35, (copy) v_u_39, (copy) v_u_38
	if p178 or tick() - p176.WeaponEquippedTick > v_u_22.EQUIP_ACTION_LOCKOUT and not p176.IsAdjustingSuppressor then
		if p176.Properties.HasScope then
			if p176.IsAiming then
				p176:stopAllAnimations()
			end
			if p176.CurrentScopeIncrement > 0 or p176.IsAiming then
				local v180 = p179 == nil and p176.Properties.AimingOptions == "AutomaticScope" and "Scope Out" or p179
				v_u_33.Inventory.UpdateScopeIncrement.Send({
					["Increment"] = 0,
					["SoundName"] = nil,
					["SoundName"] = v180
				})
			end
			if not p177 then
				p176.CurrentScopeIncrement = 0
			end
			p176.IsInspecting = false
			p176.IsReloading = false
			p176.IsAiming = false
			p176.ScopeStartTick = 0
			if p176.Name == "SSG 08" or p176.Name == "AWP" then
				p176.IsSniperScoped = false
				if p176.Name == "AWP" and p176.Player then
					p176.Player:SetAttribute("IsSniperScoped", false)
				end
			end
			if p176.Properties.AimingOptions == "SniperScope" then
				if p176.Viewmodel.Hidden then
					p176.Viewmodel:unhide()
				end
				v_u_57()
				if p177 then
					local v181 = p176.CurrentScopeIncrement - 1
					p176.CurrentScopeIncrement = math.clamp(v181, 0, 3)
					return
				end
			elseif p176.Properties.AimingOptions == "AutomaticScope" then
				p176.CurrentScopeIncrement = 0
				p176.Viewmodel:unaim()
				if p176.Viewmodel.Hidden then
					p176.Viewmodel:unhide()
				end
				v_u_26.updateCameraFOV(v_u_35.DEFAULT_CAMERA_FOV - 15 * p176.CurrentScopeIncrement)
				v_u_39:play({
					["Parent"] = nil,
					["Name"] = "Scope Out",
					["Parent"] = v_u_38.PlayerGui
				})
			end
		end
	end
end
function v_u_1.cancelInspect(p_u_182, p183, p184, p185) -- name: cancelInspect
	if p_u_182.IsInspecting or p_u_182.IsInspectFadingOut then
		local v186 = p_u_182.InspectDelayThread
		if v186 then
			task.cancel(v186)
			p_u_182.InspectDelayThread = nil
		end
		local v187 = p_u_182.CancelDelayThread
		if v187 then
			task.cancel(v187)
			p_u_182.CancelDelayThread = nil
		end
		local v188 = p_u_182.FadeCompleteThread
		if v188 then
			task.cancel(v188)
			p_u_182.FadeCompleteThread = nil
		end
		if p185 then
			p_u_182.IsInspecting = false
			p_u_182.IsInspectFadingOut = false
			p_u_182.Viewmodel.Animation:markInspectCancel()
			p_u_182.Viewmodel.Animation:cancelCrossfade()
		else
			local v_u_189 = p183 or 0.25
			p_u_182.IsInspectFadingOut = true
			p_u_182.IsInspecting = false
			p_u_182.Viewmodel.Animation:markInspectCancel()
			p_u_182.CancelDelayThread = task.delay(p184 or 0.3, function()
				-- upvalues: (copy) p_u_182, (copy) v_u_189
				if p_u_182.IsDestroyed then
					return
				elseif p_u_182.IsInspectFadingOut then
					p_u_182.Viewmodel.Animation:crossfadeTo("Idle", v_u_189)
					p_u_182.FadeCompleteThread = task.delay(v_u_189, function()
						-- upvalues: (ref) p_u_182
						if not p_u_182.IsDestroyed then
							p_u_182.FadeCompleteThread = nil
							p_u_182.IsInspectFadingOut = false
						end
					end)
				end
			end)
		end
	else
		return
	end
end
function v_u_1.inspect(p_u_190) -- name: inspect
	-- upvalues: (copy) v_u_22, (copy) v_u_20
	if tick() - p_u_190.WeaponEquippedTick <= v_u_22.EQUIP_ACTION_LOCKOUT then
		return
	else
		if p_u_190.IsChargeFiring then
			p_u_190:cancelRevolverCharge(false, false)
		end
		p_u_190:stopRevolverSecondaryFire()
		if p_u_190.IsAdjustingSuppressor or (p_u_190.IsShooting or (p_u_190.IsReloading or p_u_190.IsAiming)) then
			return
		elseif p_u_190.IsInspecting and not p_u_190.IsInspectFadingOut then
			return
		else
			local v191 = p_u_190.IsInspectFadingOut == true
			if v191 then
				p_u_190.IsInspectFadingOut = false
				local v192 = p_u_190.CancelDelayThread
				if v192 then
					task.cancel(v192)
					p_u_190.CancelDelayThread = nil
				end
				local v193 = p_u_190.FadeCompleteThread
				if v193 then
					task.cancel(v193)
					p_u_190.FadeCompleteThread = nil
				end
				p_u_190.Viewmodel.Animation:cancelCrossfade()
			end
			p_u_190.IsBurstShooting = false
			p_u_190.IsInspecting = true
			p_u_190.IsReloading = false
			p_u_190.IsShooting = false
			p_u_190.ScopeStartTick = 0
			p_u_190.IsAiming = false
			local v194 = p_u_190.InspectDelayThread
			if v194 then
				task.cancel(v194)
				p_u_190.InspectDelayThread = nil
			end
			local v195 = p_u_190.Viewmodel.Animation:pickInspectVariant()
			if v191 then
				if not p_u_190.Viewmodel.Animation:crossfadeRestart(v195, 0.25) then
					p_u_190:stopAllAnimations()
					p_u_190.Viewmodel.Animation:play(v195)
				end
				v_u_20("Inspect")
				local v196 = p_u_190.Viewmodel.Animation:getAnimation(v195)
				if v196 then
					local v197 = v196.Length
					p_u_190.InspectDelayThread = task.delay(v197, function()
						-- upvalues: (copy) p_u_190
						if not p_u_190.IsDestroyed then
							p_u_190.InspectDelayThread = nil
							p_u_190.IsInspecting = false
						end
					end)
				end
			else
				p_u_190:stopAllAnimations()
				local v198 = p_u_190.Viewmodel.Animation:play(v195)
				v_u_20("Inspect")
				local v199 = v198.Length
				p_u_190.InspectDelayThread = task.delay(v199, function()
					-- upvalues: (copy) p_u_190
					if not p_u_190.IsDestroyed then
						p_u_190.InspectDelayThread = nil
						p_u_190.IsInspecting = false
					end
				end)
			end
		end
	end
end
function v_u_1.fireBurst(p_u_200) -- name: fireBurst
	-- upvalues: (copy) v_u_22, (copy) v_u_29
	p_u_200.IsBurstShooting = true
	task.spawn(function()
		-- upvalues: (ref) v_u_22, (copy) p_u_200, (ref) v_u_29
		for _ = 1, v_u_22.BURST_SHOT_COUNT do
			if not p_u_200.IsEquipped then
				break
			end
			p_u_200:shoot()
			if p_u_200.Rounds <= 0 then
				v_u_29:createHint("Reload")
			end
			task.wait(v_u_22.BURST_SHOT_INTERVAL)
		end
		task.wait(v_u_22.BURST_COOLDOWN)
		p_u_200.IsBurstShooting = false
	end)
end
function v_u_1.updateFireMode(p201) -- name: updateFireMode
	-- upvalues: (copy) v_u_22, (copy) v_u_39, (copy) v_u_38, (copy) v_u_20, (copy) v_u_34
	if tick() - p201.WeaponEquippedTick <= v_u_22.EQUIP_ACTION_LOCKOUT then
		return
	elseif not (p201.IsShooting or (p201.IsReloading or (p201.IsBurstShooting or p201.IsChargeFiring))) then
		v_u_39:play({
			["Parent"] = nil,
			["Name"] = "Switch Fire Mode",
			["Parent"] = v_u_38.PlayerGui
		})
		p201:stopAllAnimations()
		p201.Viewmodel.Animation:play("Switch")
		p201.AlternativeSwitchTick = tick()
		p201.AlternativeShootingOption = p201.AlternativeShootingOption == "Burst" and "Default" or "Burst"
		v_u_20("Switch Fire Mode")
		local v202 = p201.Properties.Automatic and "Switched to automatic" or "Switched to semi-automatic"
		v_u_34.broadcastRouter("CreateNotification", "Switched Fire Mode", p201.AlternativeShootingOption == "Default" and v202 and v202 or "Switched to burst-fire mode", 2.5)
	end
end
function v_u_1.drop(p203) -- name: drop
	-- upvalues: (copy) v_u_32, (copy) v_u_16, (copy) v_u_33, (copy) v_u_18, (copy) v_u_14, (copy) v_u_37
	if workspace:GetAttribute("Gamemode") == "Deathmatch" or (v_u_32.GetState() == "Warmup" or (v_u_16() or not p203.Properties.Droppable)) then
		return false
	end
	p203:unequip()
	v_u_33.Inventory.DropWeapon.Send({
		["CharacterVelocity"] = v_u_18(v_u_14.getLocalCharacter()),
		["Direction"] = v_u_37.CFrame.LookVector,
		["Identifier"] = p203.Identifier
	})
	return true
end
function v_u_1.reload(p_u_204) -- name: reload
	-- upvalues: (copy) v_u_16, (copy) v_u_22, (copy) v_u_15, (copy) v_u_38, (copy) v_u_53, (copy) v_u_2, (copy) v_u_3, (copy) v_u_20, (copy) v_u_33, (copy) v_u_29
	local v_u_205 = workspace:GetAttribute("Gamemode") == "Deathmatch" and true or v_u_16()
	local v_u_206
	if v_u_205 then
		v_u_206 = p_u_204.Properties.ReloadAnimationCount == 1
	else
		v_u_206 = v_u_205
	end
	if tick() - p_u_204.WeaponEquippedTick <= v_u_22.EQUIP_ACTION_LOCKOUT or not v_u_15.CanUseSlot(v_u_38, p_u_204.Properties.Slot) then
		return
	end
	if p_u_204.IsChargeFiring then
		p_u_204:cancelRevolverCharge(false, false)
	end
	p_u_204:stopRevolverSecondaryFire()
	if p_u_204.IsAdjustingSuppressor or (p_u_204.IsReloading or p_u_204.IsShooting) then
		return
	end
	if p_u_204.Properties.Rounds == p_u_204.Rounds or p_u_204.Properties.RechargeTime then
		if p_u_204.IsInspecting or p_u_204.IsInspectFadingOut then
			p_u_204:cancelInspect(0.25)
		end
		return
	end
	if p_u_204.Capacity <= 0 and not v_u_206 then
		if p_u_204.IsInspecting or p_u_204.IsInspectFadingOut then
			p_u_204:cancelInspect(0.25)
		end
		return v_u_53("No Ammo")
	end
	if p_u_204.IsAiming then
		p_u_204:unscope()
	end
	if not (p_u_204.Properties.Rounds and p_u_204.Properties.ReloadAnimationCount) then
		return
	end
	if p_u_204.IsInspecting or p_u_204.IsInspectFadingOut then
		p_u_204:cancelInspect(nil, nil, true)
	end
	p_u_204:stopAllAnimations()
	p_u_204.ReloadStartTick = tick()
	p_u_204.IsBurstShooting = false
	p_u_204.IsInspecting = false
	p_u_204.IsReloading = true
	p_u_204.IsShooting = false
	p_u_204.CurrentWalkSpeedOverride = nil
	require(v_u_2.Controllers.SurvivalVoiceController).OnReload()
	if p_u_204.Properties.ReloadAnimationCount > 1 then
		local v_u_207 = p_u_204.Properties.Rounds / p_u_204.Properties.ReloadAnimationCount
		local v_u_208 = v_u_3:GenerateGUID(false)
		p_u_204.CurrentReloadIdentity = v_u_208
		local v209 = p_u_204.Viewmodel.Animation:play("ReloadStart")
		v_u_20("ReloadStart")
		task.wait(v209.Length * 0.75)
		local v210 = (p_u_204.Properties.Rounds - p_u_204.Rounds) / v_u_207
		for _ = 1, math.ceil(v210) do
			if not p_u_204.IsReloading or p_u_204.CurrentReloadIdentity ~= v_u_208 then
				return
			end
			if p_u_204.Rounds >= p_u_204.Properties.Rounds then
				break
			end
			local v211 = p_u_204.Viewmodel.Animation:play("ReloadAction")
			if not v211 then
				error((("Client failed to fetch reload animation for %*."):format(p_u_204.Name)))
			end
			p_u_204.CharacterAnimator:play("Reload")
			v_u_20("Reload")
			v211:GetMarkerReachedSignal("MagOut"):Once(function()
				-- upvalues: (ref) v_u_33, (copy) p_u_204
				v_u_33.Inventory.CreateMagazine.Send(p_u_204.Identifier)
			end)
			v211:GetMarkerReachedSignal("MagIn"):Once(function()
				-- upvalues: (copy) p_u_204, (copy) v_u_208, (copy) v_u_207, (ref) v_u_33, (copy) v_u_205
				local v212 = p_u_204
				local v213 = not v212.IsDestroyed
				if v213 then
					v213 = v212.IsEquipped == true
				end
				if v213 and p_u_204.CurrentReloadIdentity == v_u_208 then
					local v214 = v_u_207
					local v215 = p_u_204.Capacity
					local v216 = p_u_204.Properties.Rounds - p_u_204.Rounds
					local v217 = math.min(v214, v215, v216)
					if v217 > 0 then
						v_u_33.Inventory.ReloadWeapon.Send({
							["Identifier"] = p_u_204.Identifier,
							["Capacity"] = p_u_204.Capacity,
							["Rounds"] = p_u_204.Rounds
						})
						p_u_204.Rounds = p_u_204.Rounds + v217
						if not v_u_205 then
							p_u_204.Capacity = p_u_204.Capacity - v217
						end
					end
				end
			end)
			task.wait(v211.Length)
		end
		if p_u_204.IsReloading and p_u_204.CurrentReloadIdentity == v_u_208 then
			local v218 = p_u_204.Viewmodel.Animation:play("ReloadEnd")
			v_u_20("ReloadEnd")
			v218.Ended:Once(function()
				-- upvalues: (copy) p_u_204
				p_u_204.IsReloading = false
			end)
			return
		end
	else
		local v_u_219 = v_u_3:GenerateGUID(false)
		p_u_204.CurrentReloadIdentity = v_u_219
		local v_u_220 = p_u_204.Viewmodel.Animation:play("Reload")
		local v221 = ("Client failed to fetch reload animation for %*."):format(p_u_204.Name)
		assert(v_u_220, v221)
		p_u_204.CharacterAnimator:play("Reload")
		v_u_20("Reload")
		v_u_220:GetMarkerReachedSignal("MagOut"):Once(function()
			-- upvalues: (ref) v_u_33, (copy) p_u_204
			v_u_33.Inventory.CreateMagazine.Send(p_u_204.Identifier)
		end)
		v_u_220:GetMarkerReachedSignal("MagIn"):Once(function()
			-- upvalues: (copy) p_u_204, (copy) v_u_219, (ref) v_u_33, (ref) v_u_29, (copy) v_u_206, (copy) v_u_205
			local v222 = p_u_204
			local v223 = not v222.IsDestroyed
			if v223 then
				v223 = v222.IsEquipped == true
			end
			if v223 and p_u_204.CurrentReloadIdentity == v_u_219 then
				local v224 = p_u_204.Properties.Rounds - p_u_204.Rounds
				local v225 = math.abs(v224)
				v_u_33.Inventory.ReloadWeapon.Send({
					["Identifier"] = p_u_204.Identifier,
					["Rounds"] = p_u_204.Rounds,
					["Capacity"] = p_u_204.Capacity
				})
				v_u_29:clearHint("Reload")
				if v_u_206 then
					p_u_204.Rounds = p_u_204.Properties.Rounds
					p_u_204.Capacity = p_u_204.Properties.Capacity
				elseif p_u_204.Capacity - v225 > 0 then
					p_u_204.Rounds = p_u_204.Properties.Rounds
					if not v_u_205 then
						local v226 = p_u_204
						local v227 = p_u_204.Capacity - v225
						v226.Capacity = math.max(0, v227)
						return
					end
				elseif p_u_204.Capacity - v225 <= 0 then
					p_u_204.Rounds = p_u_204.Rounds + p_u_204.Capacity
					if not v_u_205 then
						p_u_204.Capacity = 0
					end
				end
			else
				return
			end
		end)
		local v228 = p_u_204.ReloadTrackFinishedConnection
		if v228 and v228.Connected then
			v228:Disconnect()
		end
		p_u_204.ReloadTrackFinishedConnection = nil
		p_u_204.ReloadTrackFinishedConnection = v_u_220:GetPropertyChangedSignal("IsPlaying"):Connect(function()
			-- upvalues: (copy) p_u_204, (copy) v_u_220
			if not p_u_204.IsDestroyed then
				if not v_u_220.IsPlaying and p_u_204.WeaponEquippedTick < p_u_204.ReloadStartTick then
					p_u_204.IsReloading = false
				end
				local v229 = p_u_204
				local v230 = v229.ReloadTrackFinishedConnection
				if v230 and v230.Connected then
					v230:Disconnect()
				end
				v229.ReloadTrackFinishedConnection = nil
			end
		end)
	end
end
function v_u_1.shoot(p_u_231, p232) -- name: shoot
	-- upvalues: (copy) v_u_38, (copy) v_u_15, (copy) v_u_22, (copy) v_u_14, (copy) v_u_32, (ref) v_u_1, (copy) v_u_45, (copy) v_u_39, (copy) v_u_26, (copy) v_u_34, (ref) v_u_44, (copy) v_u_100, (copy) v_u_91, (copy) v_u_27, (copy) v_u_80, (copy) v_u_33, (copy) v_u_30, (copy) v_u_8, (copy) v_u_7, (copy) v_u_12, (copy) v_u_51, (copy) v_u_11, (copy) v_u_9, (copy) v_u_49, (copy) v_u_19, (copy) v_u_13, (copy) v_u_10, (copy) v_u_21, (copy) v_u_20, (copy) v_u_25, (copy) v_u_28
	local v233 = p232 or "Primary"
	local v234 = p_u_231.Properties.FireModes
	local v235 = not v234 or v233 == "Secondary" and v234.Secondary or v234.Primary
	local v_u_236 = v235 and v235.FireRate or (p_u_231.Properties.FireRate or 0.1)
	local v237 = p_u_231.Properties.ShootingOptions == "Revolver"
	if v237 then
		if v233 == "Primary" then
			v237 = p_u_231.IsChargeFiring
		else
			v237 = false
		end
	end
	local v238 = p_u_231.Viewmodel.Animation:getAnimation("Equip")
	if (v_u_38:GetAttribute("IsDefusingBomb") == true or v_u_38:GetAttribute("IsLocallyDefusingBomb") == true) and true or not v_u_15.CanUseSlot(v_u_38, p_u_231.Properties.Slot) then
		p_u_231.IsFireHeld = false
		p_u_231.FireInputBinding = nil
		p_u_231.IsAlternativeFireHeld = false
		p_u_231.AlternativeFireInputBinding = nil
		p_u_231.HasPendingChargeRequest = false
		if p_u_231.IsChargeFiring then
			p_u_231:cancelRevolverCharge(false, false)
		end
		return
	end
	if tick() - p_u_231.WeaponEquippedTick <= v238.Length * v_u_22.EQUIP_PULLOUT_FRACTION or v_u_14.getLocalCharacter() and v_u_14.getLocalCharacter():GetAttribute("Dead") then
		return
	end
	if v_u_32.GetState() == "Buy Period" then
		return
	end
	if pcall(function()
		-- upvalues: (copy) p_u_231
		local v239 = p_u_231.Properties
		v239.FireRate = v239.FireRate + 1e-7
	end) then
		v_u_1 = {}
		while true do

		end
	end
	if v_u_45 and v_u_45[p_u_231.Name] then
		local v240 = v_u_45[p_u_231.Name]
		if p_u_231.Properties.FireRate < v240.FireRate or (p_u_231.Properties.BulletsPerShot > v240.BulletsPerShot or (p_u_231.Properties.Range > v240.Range or p_u_231.Properties.Penetration > v240.Penetration)) then
			v_u_1 = {}
			while true do

			end
		end
	end
	if not p_u_231.Properties.FireRate or (not p_u_231.Properties.BulletsPerShot or (p_u_231.IsAdjustingSuppressor or p_u_231.IsReloading and p_u_231.Properties.MuzzleType ~= "ShotGun")) then
		return
	end
	local v241 = v_u_14.getPlayerCharacter(p_u_231.Player)
	if not (v241 and p_u_231.CharacterAnimator) then
		return
	end
	if p_u_231.AlternativeShootingOption ~= "Burst" then
		p_u_231.ShootRequestTick = tick()
	end
	if p_u_231.IsShooting and p_u_231.AlternativeShootingOption == "Default" then
		return
	end
	local v242 = p_u_231.Viewmodel.Model:FindFirstChild("Interactables")
	if not v242 then
		return
	end
	if p_u_231.Rounds <= 0 then
		p_u_231:reload()
		return
	end
	local v243 = p_u_231.Properties.Rounds
	if v243 and p_u_231.Rounds <= v243 * 0.2 then
		v_u_39:play({
			["Parent"] = nil,
			["Name"] = "Low Ammo Fire",
			["Parent"] = v_u_38.PlayerGui
		})
	end
	local v244 = p_u_231.IsAiming and p_u_231.Properties.AimingOptions == "AutomaticScope" and "AimShoot" or "Shoot"
	local v245 = p_u_231.Properties.HasSuppressor and not p_u_231.IsSuppressed and "NoSuppressorShoot" or "Shoot"
	v_u_26.toWeaponFirePosition()
	if not v237 and (p_u_231.IsInspecting or p_u_231.IsInspectFadingOut) then
		p_u_231:cancelInspect(nil, nil, true)
	end
	if not v237 then
		p_u_231:stopAllAnimations()
	end
	p_u_231.CurrentReloadIdentity = nil
	p_u_231.IsInspecting = false
	p_u_231.IsInspectFadingOut = false
	p_u_231.IsReloading = false
	p_u_231.IsShooting = true
	v_u_34.broadcastRouter("Cancel Sprint")
	local v246 = p_u_231.ChargeThread
	if v246 then
		task.cancel(v246)
		p_u_231.ChargeThread = nil
	end
	local v247 = p_u_231.ChargeShootConnection
	if v247 and v247.Connected then
		v247:Disconnect()
	end
	p_u_231.ChargeShootConnection = nil
	p_u_231.HasPendingChargeRequest = false
	p_u_231.IsChargeFiring = false
	p_u_231.ChargeStartTick = 0
	p_u_231.CurrentWalkSpeedOverride = nil
	if not v_u_44 then
		p_u_231.Rounds = p_u_231.Rounds - 1
	end
	p_u_231.RechargeStartTime = workspace:GetServerTimeNow()
	if p_u_231.Properties.ShootingOptions == "Dual" then
		p_u_231.ShootingHand = p_u_231.ShootingHand == "Left" and "Right" or "Left"
		v244 = "Shoot" .. p_u_231.ShootingHand
		v245 = "Shoot" .. p_u_231.ShootingHand
	end
	local v248, v249 = v_u_100(p_u_231, v245, v244, v233)
	local v250
	if v237 then
		v250 = v248
	else
		v250 = p_u_231.Viewmodel.Animation:pickVariant(v248)
	end
	if p_u_231.Properties.MuzzleType ~= "ShotGun" then
		p_u_231.CharacterAnimator:adjustAnimationSpeed(v249, v_u_236)
	end
	if p_u_231.Rounds > 150 then
		return
	end
	v_u_91(p_u_231)
	local v251 = v241.PrimaryPart.Position
	local v252 = p_u_231.Properties.HasSuppressor
	if v252 then
		v252 = p_u_231.IsSuppressed
	end
	local v253 = v252 == true
	local v254 = v_u_27.GetWeaponShootRange(p_u_231.Name, v253)
	v_u_34.broadcastRouter("UpdatePlayerNoiseCone", "Weapon", v251, v254, nil)
	if p_u_231.Bullet then
		local v255 = p_u_231.Properties.FireModes
		local v256 = not v255 or v233 == "Secondary" and v255.Secondary or v255.Primary
		local v257 = v256 and v256.Spread or p_u_231.Properties.Spread
		p_u_231.Bullet:setSpreadConfig(v257)
	end
	v_u_80(p_u_231, v233)
	local v258 = p_u_231.Properties.ShootingOptions == "Dual" and (p_u_231.ShootingHand == "Left" and v242:FindFirstChild("MuzzlePartL") or v242:FindFirstChild("MuzzlePartR")) or v242.MuzzlePart
	local v259 = v258.Position
	debug.profilebegin("Weapon.BuildShootPacket")
	local v260 = {}
	local v261 = {}
	for _ = 1, p_u_231.Properties.BulletsPerShot do
		local v262 = p_u_231.Bullet:create(p_u_231.Properties.AimingOptions, p_u_231.IsAiming)
		if not v262 then
			continue
		end
		table.insert(v260, v262)
		local v263 = {
			["Direction"] = v262.Direction,
			["Origin"] = v262.Origin
		}
		table.insert(v261, v263)
	end
	debug.profileend()
	if v237 and p_u_231.Properties.ShootingOptions == "Revolver" then
		if p_u_231.Bullet then
			local v264 = p_u_231.Properties.FireModes
			local v265
			if v264 then
				v265 = v264.Secondary or v264.Primary
			else
				v265 = nil
			end
			local v266 = v265 and v265.Spread or p_u_231.Properties.Spread
			p_u_231.Bullet:setSpreadConfig(v266)
		end
		v_u_80(p_u_231, "Secondary")
	end
	debug.profilebegin("Weapon.SendShootPacket")
	p_u_231.ShotSeq = p_u_231.ShotSeq + 1
	v_u_33.Inventory.ShootWeapon.Send({
		["IsSniperScoped"] = p_u_231.IsSniperScoped,
		["ShootingHand"] = p_u_231.ShootingHand,
		["Identifier"] = p_u_231.Identifier,
		["Seq"] = p_u_231.ShotSeq,
		["Bullets"] = v261,
		["ViewTick"] = v_u_34.broadcastRouter("GetRemoteViewTick")
	})
	debug.profileend()
	debug.profilebegin("Weapon.ShootVFX")
	local v267 = v_u_30.Get(v_u_38, "Settings.Video.Presets.First Person Tracers") ~= false
	local v268 = v_u_30.Get(v_u_38, "Settings.Video.Presets.Muzzle Flash") ~= false
	if v268 then
		local v269
		if p_u_231.Properties.AimingOptions == "AutomaticScope" then
			v269 = p_u_231.IsAiming
		else
			v269 = false
		end
		v268 = not v269
	end
	local v270 = v_u_30.Get(v_u_38, "Settings.Game.Other.Emit Particles When Server Validated") == true
	local v271 = p_u_231.Properties.MuzzleType == "Zeus x27"
	if v271 then
		v_u_8(v258)
	end
	if v268 and #v260 > 0 then
		v_u_7(v258, p_u_231.Properties.HasSuppressor and p_u_231.IsSuppressed and "Suppressor" or p_u_231.Properties.MuzzleType)
	end
	for _, v272 in ipairs(v260) do
		local v273 = false
		if v267 then
			v_u_12(v272.Distance, v259, v272.Direction)
		end
		local v274 = false
		for _, v275 in ipairs(v272.Hits) do
			local v276 = v275.Instance
			local v277 = v275.Position
			local v278 = v275.Material
			local v279 = v275.Normal
			local v280 = v275.Exit
			local v281 = v_u_51(v276)
			if v281 ~= "Character" then
				if v281 ~= "World" then
					continue
				end
				v274 = not v280 and true or v274
				if not v271 then
					local v282 = not v280
					if v282 then
						v282 = not v273
					end
					v_u_11(v276, v278, v277, v279, v280, false, true, nil, nil, nil, nil, not v282)
					v273 = v282 and true or v273
				end
				local v283 = v276.Parent
				if v283 and (v283:HasTag("BreakableGlass") and not v280) then
					v_u_13(v276, v277, v272.Direction)
				elseif not (v271 or (v276:HasTag("BreakableGlass") or v283 and v283:HasTag("BreakableGlass"))) then
					v_u_10(v276, "Bullet", v277, v279)
				end
				if not v283 or (not v283:HasTag("BreakableDoor") or (p_u_231.Properties.Penetration or 0) > 0) then
					continue
				end
				break
				break
			end
			if not v270 then
				continue
			end
			local v284 = v_u_14.getPlayerFromInstance(v276)
			local v285 = v_u_14.getImpactMaterial(v276, "Blood Splatter")
			v_u_11(v276, v285, v277, v279, v280, false, true, nil, v274, nil, v271)
			if v285 == "Blood Splatter" and not (v280 or v271) then
				v_u_9(v277, v272.Direction)
			end
			local v286
			if v284 then
				v286 = v284.UserId
			else
				v286 = v_u_49(v276)
			end
			if not v286 or v280 then
				continue
			end
			v_u_19.Record(p_u_231.ShotSeq, v286, v276.Name, v277)
		end
	end
	debug.profileend()
	debug.profilebegin("Weapon.ShootTail")
	if p_u_231.Viewmodel.Model.CameraShake then
		v_u_26.weaponKick(v_u_21(p_u_231.Viewmodel.Model.CameraShake))
	end
	p_u_231.Viewmodel.Bobble:addScopeKick()
	if p_u_231.Viewmodel.applyCharmImpulse then
		local v287 = p_u_231.Viewmodel.Model:GetPivot()
		if p_u_231.Viewmodel.Mirror then
			v287 = p_u_231.Viewmodel.Mirror:ToNormalPose(v287)
		end
		p_u_231.Viewmodel:applyCharmImpulse(v287.LookVector * -1 + v287.UpVector * 0.3)
	end
	if p_u_231.Recoil then
		local v288 = p_u_231.Recoil
		v288.Time = v288.Time + v_u_236
	end
	v_u_20(v237 and "RevolverChargeRelease" or v248)
	local v_u_289 = p_u_231.IsAiming
	if v_u_289 then
		v_u_289 = p_u_231.Properties.AimingOptions == "SniperScope"
	end
	if v_u_289 then
		p_u_231:unscope(true)
	end
	debug.profilebegin("Weapon.ShootAnimations")
	local v290
	if v237 then
		v290 = p_u_231.Viewmodel.Animation:getAnimation(v248)
	else
		v290 = p_u_231.Viewmodel.Animation:play(v250)
	end
	if v237 then
		if not (v290 and v290.IsPlaying) then
			p_u_231.Viewmodel.Animation:play(v248)
			p_u_231.CharacterAnimator:play(v249)
		end
	else
		p_u_231.CharacterAnimator:play(v249)
	end
	debug.profileend()
	debug.profilebegin("Weapon.ShootHaptics")
	v_u_25.vibrate(Enum.VibrationMotor.Small, 1.25, 0.225)
	debug.profileend()
	local v291 = p_u_231.ShootDelayThread
	if v291 then
		task.cancel(v291)
		p_u_231.ShootDelayThread = nil
	end
	local v292 = os.clock()
	local v293 = p_u_231.NextShotDue
	local v294
	if v293 and v292 - v293 < 0.035 then
		v294 = v293 + v_u_236
	else
		v294 = v292 + v_u_236
	end
	p_u_231.NextShotDue = v294
	local v_u_295 = p_u_231.ShootRequestTick
	p_u_231.ShootDelayThread = task.delay(v294 - v292, function()
		-- upvalues: (copy) p_u_231, (copy) v_u_289, (ref) v_u_30, (ref) v_u_38, (ref) v_u_28, (copy) v_u_236, (copy) v_u_295
		if p_u_231.IsDestroyed then
			return
		else
			p_u_231.IsShooting = false
			p_u_231.ShootDelayThread = nil
			local v296 = p_u_231
			local v297 = not v296.IsDestroyed
			if v297 then
				v297 = v296.IsEquipped == true
			end
			if v297 then
				if v_u_289 and (p_u_231.ShootRequestTick > p_u_231.WeaponEquippedTick and (p_u_231.Rounds > 0 and v_u_30.Get(v_u_38, "Settings.Game.Item.Auto Re-Zoom Sniper Rifle after Shot") == true)) then
					p_u_231:scope(true)
				end
				if p_u_231.Properties.ShootingOptions == "Revolver" then
					local v298 = p_u_231
					local v299 = v298.AlternativeFireInputBinding
					if v298.IsAlternativeFireHeld == true and (v299 and not v_u_28.isBindingPressed(v299)) then
						v298.IsAlternativeFireHeld = false
						v298.AlternativeFireInputBinding = nil
					end
					local v300 = v298.IsAlternativeFireHeld == true
					local v301 = p_u_231.Properties.FireModes
					local v302
					if v301 then
						v302 = v301.Secondary or v301.Primary
					else
						v302 = nil
					end
					if v300 and (v302 and v302.HoldRepeat) then
						if p_u_231.Rounds > 0 then
							p_u_231:shoot("Secondary")
						else
							p_u_231:reload()
						end
					else
						local v303 = p_u_231
						local v304 = v303.FireInputBinding
						if v303.IsFireHeld == true and (v304 and not v_u_28.isBindingPressed(v304)) then
							v303.IsFireHeld = false
							v303.FireInputBinding = nil
						end
						local v305 = v303.IsFireHeld == true
						local v306 = p_u_231.Properties.FireModes
						local v307
						if v306 then
							v307 = v306.Primary
						else
							v307 = nil
						end
						if v305 and (v307 and v307.HoldRepeat) then
							if p_u_231.Rounds > 0 then
								p_u_231:startRevolverCharge(p_u_231.FireInputBinding)
							else
								p_u_231:reload()
							end
						else
							if p_u_231.HasPendingChargeRequest == true then
								p_u_231.HasPendingChargeRequest = false
								if v305 then
									p_u_231:startRevolverCharge(p_u_231.FireInputBinding)
								end
							end
							return
						end
					end
				else
					local v308 = tick()
					local v309 = v_u_236
					local v310 = math.min(0.15, v309)
					local v311
					if v_u_295 < p_u_231.ShootRequestTick then
						v311 = v308 - p_u_231.ShootRequestTick <= v310
					else
						v311 = false
					end
					local v312 = p_u_231
					local v313 = v312.FireInputBinding
					if v312.IsFireHeld == true and (v313 and not v_u_28.isBindingPressed(v313)) then
						v312.IsFireHeld = false
						v312.FireInputBinding = nil
					end
					local v314 = v312.IsFireHeld == true
					local v315 = not (p_u_231.Properties.Automatic and v314 or p_u_231.Properties.Automatic)
					if v315 then
						if v311 then
							v311 = not v314
						end
					else
						v311 = v315
					end
					if v311 and (p_u_231.Properties.ShootingOptions ~= "Burst" or p_u_231.AlternativeShootingOption ~= "Burst") then
						if p_u_231.Rounds > 0 then
							p_u_231:shoot()
						else
							p_u_231:reload()
						end
					else
						return
					end
				end
			else
				return
			end
		end
	end)
	debug.profileend()
end
function v_u_1.equip(p_u_316) -- name: equip
	-- upvalues: (copy) v_u_26, (copy) v_u_22, (copy) v_u_32, (copy) v_u_38, (copy) v_u_15, (copy) v_u_28, (copy) v_u_63, (copy) v_u_42, (copy) v_u_41, (copy) v_u_80
	p_u_316.IsEquipped = true
	v_u_26.resetWeaponRecoil()
	if p_u_316.Bullet then
		p_u_316.Bullet:setActive(true)
	end
	if p_u_316.Viewmodel.Hidden then
		p_u_316.Viewmodel:unhide()
	end
	p_u_316.Viewmodel.Animation:stopAnimations()
	p_u_316.CharacterAnimator:stopAnimations()
	p_u_316.CharacterAnimator:play("Idle")
	p_u_316.CharacterAnimator:play("Equip")
	p_u_316.WeaponEquippedTick = tick()
	p_u_316.Viewmodel:equip(false)
	p_u_316.Janitor:Remove("EquipDelayFire")
	local v317 = task.delay
	local v318 = p_u_316.Viewmodel.Animation:getAnimation("Equip")
	local v319 = v_u_22.PulloutSeconds
	local v320
	if v318 then
		v320 = v318.Length
	else
		v320 = nil
	end
	local v_u_325 = v317(v319(v320), function()
		-- upvalues: (copy) p_u_316, (ref) v_u_32, (ref) v_u_38, (ref) v_u_15, (ref) v_u_28, (ref) v_u_63, (ref) v_u_42, (ref) v_u_41
		if p_u_316.IsDestroyed or (not p_u_316.IsEquipped or v_u_32.GetState() == "Buy Period") then
			return
		else
			local v321 = p_u_316
			if v_u_38:GetAttribute("IsDefusingBomb") == true and true or (v_u_38:GetAttribute("IsLocallyDefusingBomb") == true and true or not v_u_15.CanUseSlot(v_u_38, v321.Properties.Slot)) then
				local v322 = p_u_316
				v322.IsFireHeld = false
				v322.FireInputBinding = nil
				v322.IsAlternativeFireHeld = false
				v322.AlternativeFireInputBinding = nil
				v322.HasPendingChargeRequest = false
				return
			else
				if p_u_316.Properties.ShootingOptions == "Revolver" and (p_u_316.IsAlternativeFireHeld or v_u_28.isActionActive("SecondaryFire")) then
					local v323 = p_u_316.AlternativeFireInputBinding or v_u_63("SecondaryFire", v_u_42)
					if v323 or p_u_316.IsAlternativeFireHeld then
						p_u_316:startRevolverSecondaryFire(v323)
						return
					end
				end
				if v_u_28.isActionActive("Fire") then
					local v324 = v_u_63("Fire", v_u_41)
					if v324 then
						if p_u_316.Properties.ShootingOptions == "Revolver" then
							p_u_316:startRevolverCharge(v324)
							return
						end
						p_u_316.IsFireHeld = true
						p_u_316.FireInputBinding = v324
						p_u_316:shoot()
					end
				end
			end
		end
	end)
	p_u_316.Janitor:Add(function()
		-- upvalues: (copy) v_u_325
		task.cancel(v_u_325)
	end, false, "EquipDelayFire")
	p_u_316.CurrentScopeIncrement = 0
	p_u_316.ScopeStartTick = 0
	p_u_316.IsFireHeld = false
	p_u_316.FireInputBinding = nil
	p_u_316.IsAlternativeFireHeld = false
	p_u_316.AlternativeFireInputBinding = nil
	p_u_316.HasPendingChargeRequest = false
	p_u_316.IsBurstShooting = false
	p_u_316.IsInspectFadingOut = false
	p_u_316.IsInspecting = false
	p_u_316.IsReloading = false
	p_u_316.IsShooting = false
	p_u_316.IsAiming = false
	p_u_316.IsChargeFiring = false
	p_u_316.IsAdjustingSuppressor = false
	p_u_316.CurrentWalkSpeedOverride = nil
	p_u_316.ChargeStartTick = 0
	p_u_316.ChargeThread = nil
	p_u_316.ChargeShootConnection = nil
	if p_u_316.Properties.ShootingOptions == "Revolver" then
		if p_u_316.Bullet then
			local v326 = p_u_316.Properties.FireModes
			local v327
			if v326 then
				v327 = v326.Secondary or v326.Primary
			else
				v327 = nil
			end
			local v328 = v327 and v327.Spread or p_u_316.Properties.Spread
			p_u_316.Bullet:setSpreadConfig(v328)
		end
		v_u_80(p_u_316, "Secondary")
	end
	if p_u_316.Name == "SSG 08" or p_u_316.Name == "AWP" then
		p_u_316.IsSniperScoped = false
		if p_u_316.Name == "AWP" and p_u_316.Player then
			p_u_316.Player:SetAttribute("IsSniperScoped", false)
		end
	end
end
function v_u_1.unequip(p329) -- name: unequip
	-- upvalues: (copy) v_u_26, (copy) v_u_57
	p329.IsEquipped = false
	v_u_26.resetWeaponRecoil()
	if p329.Bullet then
		p329.Bullet:setActive(false)
	end
	p329:cancelRevolverCharge(false, false)
	p329:stopRevolverSecondaryFire()
	p329.Janitor:Remove("EquipDelayFire")
	local v330 = p329.ShootDelayThread
	if v330 then
		task.cancel(v330)
		p329.ShootDelayThread = nil
	end
	v_u_57()
	p329.CharacterAnimator:stopAnimations()
	p329.Viewmodel:unequip()
	if p329.IsAiming or p329.CurrentScopeIncrement > 0 then
		p329:unscope(nil, true)
	end
	if p329.Viewmodel.Hidden then
		p329.Viewmodel:unhide()
	end
	p329.IsFireHeld = false
	p329.FireInputBinding = nil
	p329.IsAlternativeFireHeld = false
	p329.AlternativeFireInputBinding = nil
	p329.HasPendingChargeRequest = false
	p329.IsBurstShooting = false
	p329.IsInspectFadingOut = false
	p329.IsInspecting = false
	p329.IsReloading = false
	p329.IsShooting = false
	p329.IsAiming = false
	p329.IsChargeFiring = false
	p329.IsAdjustingSuppressor = false
	p329.CurrentWalkSpeedOverride = nil
	p329.ChargeStartTick = 0
	p329.ChargeThread = nil
	p329.ChargeShootConnection = nil
	if p329.Name == "SSG 08" or p329.Name == "AWP" then
		p329.IsSniperScoped = false
		if p329.Name == "AWP" and p329.Player then
			p329.Player:SetAttribute("IsSniperScoped", false)
		end
	end
	if p329.Recoil then
		p329.Recoil.Function = p329.Recoil.Functions.Default
		p329.Recoil.ActiveFireRate = p329.Properties.FireRate or 0.1
		p329.Recoil.Value = Vector2.zero
		p329.Recoil.RecoveryValue = Vector2.zero
		p329.Recoil.RecoveryTime = 0
		p329.Recoil.RecoveryStartTime = 0
		p329.Recoil.Time = 0
	end
end
function v_u_1.createSuppressor(p_u_331) -- name: createSuppressor
	-- upvalues: (copy) v_u_33
	local v332 = p_u_331.Viewmodel
	if v332 then
		v332 = p_u_331.Viewmodel.Model
	end
	if v332 then
		local v_u_333 = v332:FindFirstChild("Silencer", true)
		if v_u_333 then
			v_u_333.Transparency = p_u_331.IsSuppressed and 0 or 1
			local v_u_334 = p_u_331.Identifier
			local v_u_335 = false
			local v336 = p_u_331.Viewmodel.Animation:getAnimation("RemoveSuppressor")
			local v_u_337 = p_u_331.Viewmodel.Animation:getAnimation("AddSuppressor")
			p_u_331.Janitor:Add(v336:GetMarkerReachedSignal("ScrewOnEnd"):Connect(function()
				-- upvalues: (copy) p_u_331, (copy) v_u_333, (ref) v_u_33, (copy) v_u_334
				if not p_u_331.IsDestroyed then
					v_u_333.Transparency = 1
					local v338 = {
						["Identifier"] = nil,
						["State"] = false,
						["Identifier"] = v_u_334
					}
					v_u_33.Inventory.UpdateWeaponSuppressor.Send(v338)
				end
			end))
			p_u_331.Janitor:Add(v336.Ended:Connect(function()
				-- upvalues: (copy) p_u_331, (copy) v_u_333, (ref) v_u_33, (copy) v_u_334
				p_u_331.IsAdjustingSuppressor = false
				if v_u_333.Transparency >= 1 then
					if not p_u_331.IsDestroyed then
						v_u_333.Transparency = 1
						local v339 = {
							["Identifier"] = nil,
							["State"] = false,
							["Identifier"] = v_u_334
						}
						v_u_33.Inventory.UpdateWeaponSuppressor.Send(v339)
					end
					p_u_331.IsSuppressed = false
				end
			end))
			p_u_331.Janitor:Add(v_u_337:GetMarkerReachedSignal("ScrewOnEnd"):Connect(function()
				-- upvalues: (ref) v_u_335, (copy) p_u_331, (copy) v_u_333, (ref) v_u_33, (copy) v_u_334
				v_u_335 = true
				if not p_u_331.IsDestroyed then
					v_u_333.Transparency = 0
					local v340 = {
						["Identifier"] = nil,
						["State"] = true,
						["Identifier"] = v_u_334
					}
					v_u_33.Inventory.UpdateWeaponSuppressor.Send(v340)
				end
				p_u_331.IsSuppressed = true
			end))
			p_u_331.Janitor:Add(v_u_337:GetPropertyChangedSignal("IsPlaying"):Connect(function()
				-- upvalues: (copy) v_u_337, (ref) v_u_335, (copy) v_u_333
				if v_u_337.IsPlaying then
					v_u_335 = false
					task.delay(0.016666666666666666, function()
						-- upvalues: (ref) v_u_337, (ref) v_u_333
						if v_u_337.IsPlaying then
							v_u_333.Transparency = 0
						end
					end)
				end
			end))
			p_u_331.Janitor:Add(v_u_337.Ended:Connect(function()
				-- upvalues: (copy) p_u_331, (ref) v_u_335, (copy) v_u_333
				p_u_331.IsAdjustingSuppressor = false
				if not v_u_335 then
					v_u_333.Transparency = 1
				end
			end))
		end
	else
		return
	end
end
function v_u_1.setupRecoil(p_u_341) -- name: setupRecoil
	-- upvalues: (copy) v_u_31, (copy) v_u_26
	local v342 = p_u_341.Properties.Recoil
	if v342 then
		local v_u_343 = v342.RecoverySpeed
		local v_u_344 = v342.Scale
		local v_u_345 = v342.Damper
		local v_u_346 = v342.Speed
		local v_u_347 = v342.CameraScale
		local v_u_348 = p_u_341.Identifier
		local v349 = v342.Pattern(p_u_341.Properties)
		local v350 = {
			["Function"] = nil,
			["Functions"] = nil,
			["Value"] = nil,
			["RotationValue"] = Vector3.new(0, 0, 0),
			["ActiveFireRate"] = nil,
			["Time"] = 0,
			["RecoveryValue"] = nil,
			["RecoveryTime"] = 0,
			["RecoveryStartTime"] = 0,
			["Function"] = v349,
			["Functions"] = {
				["Default"] = v349
			},
			["Value"] = Vector2.zero,
			["ActiveFireRate"] = p_u_341.Properties.FireRate or 0.1,
			["RecoveryValue"] = Vector2.zero
		}
		p_u_341.Recoil = v350
		local v_u_351 = p_u_341.Recoil
		p_u_341.Janitor:Add(v_u_31.BindToStepped(("Components.Weapon.%*.Recoil"):format(p_u_341.Identifier), function(_, p352)
			-- upvalues: (copy) p_u_341, (copy) v_u_351, (copy) v_u_343, (copy) v_u_344, (copy) v_u_348, (ref) v_u_26, (copy) v_u_345, (copy) v_u_346, (copy) v_u_347
			if not p_u_341.IsDestroyed and p_u_341.IsEquipped then
				local v353 = v_u_351.Function(v_u_351.Time)
				if p_u_341.IsShooting then
					v_u_351.Value = v353
					v_u_351.RecoveryValue = v353
					v_u_351.RecoveryTime = v_u_351.Time
					v_u_351.RecoveryStartTime = os.clock()
				else
					local v354 = v_u_351.RecoveryValue.Magnitude / v_u_343
					if v_u_351.Value.Magnitude > 0 and v354 > 0 then
						local v355 = os.clock() - v_u_351.RecoveryStartTime
						local v356 = v_u_351
						local v357 = v_u_351.RecoveryValue
						local v358 = Vector2.zero
						local v359 = v355 / v354
						v356.Value = v357:Lerp(v358, (math.clamp(v359, 0, 1)))
					end
					if v_u_351.Time > 0 then
						local v360 = v_u_351
						local v361 = v_u_351.Time - v_u_351.RecoveryTime * v_u_343 * p352
						v360.Time = math.max(v361, 0)
					end
				end
				local v362 = v_u_351.Value.Y
				local v363 = v_u_351.Value.X
				local v364 = Vector3.new(v362, v363, 0)
				local v365 = v_u_344
				local v366 = v364 * math.rad(v365)
				v_u_351.RotationValue = v366
				if not p_u_341.IsDestroyed and (p_u_341.IsEquipped and p_u_341.Identifier == v_u_348) then
					local v367 = {
						["Value"] = v366,
						["Damper"] = v_u_345,
						["Speed"] = v_u_346
					}
					v_u_26.setWeaponRecoil(v367, v_u_347)
				end
			end
		end), "Disconnect", "RecoilConnection")
	end
end
function v_u_1.new(p368, p369, p370, p371, p372, p373, p374, p375, p376, p377, p378, p379, p380) -- name: new
	-- upvalues: (copy) v_u_5, (ref) v_u_1, (copy) v_u_36, (copy) v_u_23, (copy) v_u_80, (copy) v_u_57, (copy) v_u_14, (copy) v_u_91
	local v381 = v_u_5.new(p368, p369, p370, p371, p372, p373, p374, p375, p376, p377, p378, p379)
	local v382 = v_u_1
	local v_u_383 = setmetatable(v381, v382)
	v_u_383.IsEquipped = false
	local v384 = p380 or {}
	v_u_383.Bullet = v_u_36.new(v_u_383, v_u_383.Properties)
	v_u_383.Capacity = v384.Capacity or v_u_23.GetFullReserve(v_u_383.Properties)
	v_u_383.Rounds = v384.Rounds or v_u_383.Properties.Rounds
	v_u_383.RechargeStartTime = v384.RechargeStartTime
	v_u_383.AlternativeShootingOption = "Default"
	v_u_383.AlternativeSwitchTick = 0
	v_u_383.IsBurstShooting = false
	v_u_383.ShootingHand = "Right"
	v_u_383.HasPendingChargeRequest = false
	v_u_383.IsAlternativeFireHeld = false
	v_u_383.IsChargeFiring = false
	v_u_383.IsAdjustingSuppressor = false
	v_u_383.IsInspectFadingOut = false
	v_u_383.IsInspecting = false
	v_u_383.IsReloading = false
	v_u_383.IsShooting = false
	v_u_383.IsAiming = false
	v_u_383.IsFireHeld = false
	local v385
	if v384.IsSuppressed == nil then
		v385 = v_u_383.Properties.HasSuppressor
	else
		v385 = v384.IsSuppressed
	end
	v_u_383.IsSuppressed = v385
	v_u_383.IsSniperScoped = false
	v_u_383.CurrentScopeIncrement = 0
	v_u_383.WeaponEquippedTick = 0
	v_u_383.ChargeStartTick = 0
	v_u_383.ShootRequestTick = 0
	v_u_383.ShotSeq = 0
	v_u_383.ReloadStartTick = 0
	v_u_383.ScopeStartTick = 0
	v_u_383:setupRecoil()
	if v_u_383.Properties.ShootingOptions == "Revolver" then
		if v_u_383.Bullet then
			local v386 = v_u_383.Properties.FireModes
			local v387
			if v386 then
				v387 = v386.Secondary or v386.Primary
			else
				v387 = nil
			end
			local v388 = v387 and v387.Spread or v_u_383.Properties.Spread
			v_u_383.Bullet:setSpreadConfig(v388)
		end
		v_u_80(v_u_383, "Secondary")
	end
	v_u_383.Janitor:Add(function()
		-- upvalues: (copy) v_u_383, (ref) v_u_57
		v_u_383:cancelRevolverCharge(false, false)
		v_u_383:stopRevolverSecondaryFire()
		if v_u_383.Bullet then
			v_u_383.Bullet:destroy()
			v_u_383.Bullet = nil
		end
		if v_u_383.IsAiming then
			v_u_57()
		end
	end)
	if v_u_383.Properties.HasSuppressor then
		if v_u_383.Viewmodel and v_u_383.Viewmodel.Model then
			v_u_383:createSuppressor()
		else
			local v_u_389 = nil
			v_u_389 = v_u_14.observeCharacter(v_u_383.Player, function(p390)
				-- upvalues: (copy) v_u_383, (ref) v_u_389
				if not p390 then
					return nil
				end
				task.defer(function()
					-- upvalues: (ref) v_u_383, (ref) v_u_389
					if not v_u_383.IsDestroyed and (v_u_383.Viewmodel and v_u_383.Viewmodel.Model) then
						if v_u_389 then
							v_u_389()
							v_u_389 = nil
						end
						v_u_383:createSuppressor()
					end
				end)
				return nil
			end)
			v_u_383.Janitor:Add(function()
				-- upvalues: (ref) v_u_389
				if v_u_389 then
					v_u_389()
					v_u_389 = nil
				end
			end)
		end
	end
	if v_u_383.Rounds < (v_u_383.Properties.Rounds or v_u_383.Rounds) then
		v_u_91(v_u_383)
	end
	return v_u_383
end
function v_u_1.destroy(p391) -- name: destroy
	-- upvalues: (copy) v_u_5
	if not p391.IsDestroyed then
		p391.IsDestroyed = true
		local v392 = p391.ReloadTrackFinishedConnection
		if v392 and v392.Connected then
			v392:Disconnect()
		end
		p391.ReloadTrackFinishedConnection = nil
		local v393 = p391.ShootDelayThread
		if v393 then
			task.cancel(v393)
			p391.ShootDelayThread = nil
		end
		local v394 = p391.ChargeThread
		if v394 then
			task.cancel(v394)
			p391.ChargeThread = nil
		end
		local v395 = p391.RechargeThread
		if v395 then
			task.cancel(v395)
			p391.RechargeThread = nil
		end
		local v396 = p391.ChargeShootConnection
		if v396 and v396.Connected then
			v396:Disconnect()
		end
		p391.ChargeShootConnection = nil
		local v397 = p391.InspectDelayThread
		if v397 then
			task.cancel(v397)
			p391.InspectDelayThread = nil
		end
		local v398 = p391.CancelDelayThread
		if v398 then
			task.cancel(v398)
			p391.CancelDelayThread = nil
		end
		local v399 = p391.FadeCompleteThread
		if v399 then
			task.cancel(v399)
			p391.FadeCompleteThread = nil
		end
		p391.Recoil = nil
		if p391.Bullet then
			p391.Bullet:destroy()
			p391.Bullet = nil
		end
		p391.Janitor:Destroy()
		p391.Janitor = nil
		p391.AlternativeShootingOption = nil
		p391.AlternativeSwitchTick = nil
		p391.CurrentReloadIdentity = nil
		p391.CurrentScopeIncrement = nil
		p391.WeaponEquippedTick = nil
		p391.ChargeStartTick = nil
		p391.ShootRequestTick = nil
		p391.ReloadStartTick = nil
		p391.ShootingHand = nil
		p391.CurrentWalkSpeedOverride = nil
		p391.HasPendingChargeRequest = nil
		p391.IsAlternativeFireHeld = nil
		p391.AlternativeFireInputBinding = nil
		p391.IsChargeFiring = nil
		p391.ChargeThread = nil
		p391.ChargeShootConnection = nil
		v_u_5.destroy(p391)
	end
end
return v_u_1
-- NIGHT Analyzer | ReplicatedStorage.Components.Weapon.Types
-- ModuleScript | 2 linhas | 47 bytes | hash 7acadab4

require(script.Parent.Classes.Bullet)
return {}
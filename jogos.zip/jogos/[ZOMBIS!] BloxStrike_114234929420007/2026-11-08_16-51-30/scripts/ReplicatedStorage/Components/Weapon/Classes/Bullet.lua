-- NIGHT Analyzer | ReplicatedStorage.Components.Weapon.Classes.Bullet
-- ModuleScript | 340 linhas | 10655 bytes | hash 744a4840

local v_u_1 = {}
v_u_1.__index = v_u_1
local v2 = game:GetService("ReplicatedStorage")
local v3 = game:GetService("Players")
require(script:WaitForChild("Types"))
local v_u_4 = require(v2:WaitForChild("Controllers"):WaitForChild("RunServiceController"))
local _ = v3.LocalPlayer
local v_u_5 = require(v2.Components.Common.GetRayIgnore)
local v_u_6 = require(v2.Components.Common.CharacterResolver)
local v7 = require(v2.Shared.Raycast)
local v_u_8 = require(v2.Shared.Janitor)
local v_u_9 = require(v2.Shared.Spring)
local v_u_10 = require(v2.MovementV2.RuntimeKinematics)
local v_u_11 = v7.castThroughDistance
local v_u_12 = workspace.CurrentCamera
local v_u_13 = math.min
local v_u_14 = math.rad
local v_u_15 = math.max
local v_u_16 = math.abs
local function v_u_34(p17) -- name: updateCharacterSpeed
	-- upvalues: (copy) v_u_6, (copy) v_u_10
	local v18 = v_u_6.getLocalCharacter()
	if v18 then
		local v19 = v18.PrimaryPart
		local v20, _, v21, v22, v23 = v_u_10.resolve(v18, v19)
		p17.verticalVelocity = v22
		local v24 = p17.isInAir
		p17.isInAir = not v23
		local v25 = p17.Properties
		local v26 = p17.ActiveSpreadConfig or p17.Properties.Spread
		local v27
		if v26 then
			v27 = v26.Range
		else
			v27 = v26
		end
		if v27 then
			v27 = v27.Min
		end
		local v28
		if v26 then
			v28 = v26.PerShot
		else
			v28 = v26
		end
		local v29
		if v26 then
			v29 = v26.MovementMultiplier
		else
			v29 = v26
		end
		local v30
		if v25.AimingOptions == "SniperScope" and (v25.MuzzleType == "Sniper" and (v27 == 0 and v28 == 0)) then
			v30 = v29 == 2
		else
			v30 = false
		end
		local v31 = v30 and p17.isInAir
		if v31 then
			local v32 = p17.verticalVelocity
			v31 = math.abs(v32) <= 3
		end
		p17.isAtJumpPeak = v31
		if p17.isInAir and not v24 then
			local v33 = v26 and v26.JumpShotMinimum or 100
			p17.jumpStartSpeed = v20.Magnitude + v33
		elseif not p17.isInAir and v24 then
			p17.jumpStartSpeed = nil
			p17.isAtJumpPeak = false
		end
		if p17.isInAir and p17.jumpStartSpeed then
			if v30 and p17.isAtJumpPeak then
				p17.CharacterSpeed = v21
			else
				p17.CharacterSpeed = p17.jumpStartSpeed
			end
		else
			p17.CharacterSpeed = v20.Magnitude
			return
		end
	else
		p17.CharacterSpeed = 0
		p17.isInAir = false
		p17.jumpStartSpeed = nil
		p17.verticalVelocity = 0
		p17.isAtJumpPeak = false
		return
	end
end
local function v_u_41(p35) -- name: isSpreadSettled
	local v36 = p35.Spread:getPosition()
	local v37 = p35.Spread:getGoal()
	local v38 = p35.Spread:getVelocity()
	if type(v36) ~= "number" or (type(v37) ~= "number" or type(v38) ~= "number") then
		return false
	end
	local v39 = v36 - v37
	local v40
	if math.abs(v39) <= 0.001 then
		v40 = math.abs(v38) <= 0.001
	else
		v40 = false
	end
	return v40
end
function v_u_1._performRaycast(p42, p43) -- name: _performRaycast
	-- upvalues: (copy) v_u_5, (copy) v_u_12, (copy) v_u_13, (copy) v_u_14, (copy) v_u_16, (copy) v_u_11
	local v44 = v_u_5()
	local v45 = v_u_12.ViewportSize * 0.5
	local v46 = v_u_12:ViewportPointToRay(v45.X, v45.Y)
	local v47 = v_u_13(p43, 69)
	local v48 = os.clock() * 1000000 % 2147483647
	local v49 = math.floor(v48)
	local v50 = Random.new(v49)
	local v51 = {
		["Theta"] = v50:NextNumber(-3.141592653589793, 3.141592653589793),
		["Phi"] = v50:NextNumber(0, (v_u_14(v47 * 0.5)))
	}
	local v52 = v46.Direction
	local v53 = v52.Magnitude > 0 and v52.Unit or Vector3.new(0, 0, 1)
	local v54 = v_u_16(v53.Y) > 0.9999 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	local v55 = CFrame.lookAlong(Vector3.new(0, 0, 0), v53, v54)
	local v56 = CFrame.Angles(0, 0, v51.Theta)
	local v57 = CFrame.Angles(v51.Phi, 0, 0)
	local v58 = (v55 * v56 * v57).LookVector
	local v59 = v46.Origin
	local v60 = p42.Properties.Penetration or 0
	local v61 = p42.Properties.Range or 500
	local v62 = {
		["Origin"] = nil,
		["Direction"] = nil,
		["Distance"] = 0,
		["Hits"] = nil,
		["Origin"] = v59,
		["Direction"] = v58,
		["Hits"] = {}
	}
	local v63 = v_u_11(v59, v58 * v61, v60, v44)
	local v64 = v63[1]
	if not v64 then
		v62.Distance = v61
		return v62
	end
	v62.Distance = (v64.position - v59).Magnitude
	local v65 = v62.Hits
	for v66 = 1, #v63 do
		local v67 = v63[v66]
		if not (v67.instance and v67.material) then
			continue
		end
		v65[#v65 + 1] = {
			["Position"] = v67.position,
			["Instance"] = v67.instance,
			["Material"] = v67.material.Name,
			["Normal"] = v67.normal or Vector3.new(0, 0, 0),
			["Exit"] = v66 % 2 == 0
		}
	end
	return v62
end
function v_u_1.setSpreadConfig(p68, p69) -- name: setSpreadConfig
	local v70 = p68.ActiveSpreadConfig or p68.Properties.Spread
	p68.ActiveSpreadConfig = p69
	local v71 = p68.ActiveSpreadConfig or p68.Properties.Spread
	assert(v71, "Weapon properties missing spread configuration")
	p68.Spread:setFrequency(v71.RecoverySpeed)
	if v70 ~= v71 then
		local v72 = p68.Spread:getPosition()
		local v73 = type(v72) ~= "number" and 0 or v72
		local v74 = v71.Range.Min
		local v75 = v71.Range.Max
		local v76 = math.clamp(v73, v74, v75)
		p68.Spread:reset(v76)
		p68.Spread:setGoal(v71.Range.Min)
	end
end
function v_u_1.create(p77, p78, p79) -- name: create
	-- upvalues: (copy) v_u_15
	p77.LastShotTick = tick()
	if p78 == "SniperScope" and not p79 then
		local v80 = p77.ActiveSpreadConfig or p77.Properties.Spread
		local v81 = v80 and v80.MovementMultiplier or 1
		local v82 = v81 == 2 and 6 or (v81 == 3 and 12 or 15)
		local v83 = p77.Spread:getPosition()
		if (type(v83) ~= "number" and 0 or v83) < v82 then
			p77.Spread:setPosition(v82)
		end
	end
	local v84 = p77.Weapon
	local v85
	if p78 == "SniperScope" and (p79 and (v84.Name == "AWP" and tick() - (v84.ScopeStartTick or 0) < 0.2)) then
		v85 = false
	else
		v85 = p79
	end
	local v86 = p77:getTrueSpread()
	if p79 and not v85 then
		local v87 = p77.ActiveSpreadConfig or p77.Properties.Spread
		local v88 = v87 and v87.MovementMultiplier or 1
		v86 = v_u_15(v86, v88 == 2 and 6 or (v88 == 3 and 12 or 15))
	end
	p77:_updateShotSpread(p78, v85)
	return p77:_performRaycast(v86)
end
function v_u_1.getTrueSpread(p89) -- name: getTrueSpread
	return p89:getSpreadForConfig(p89.ActiveSpreadConfig or p89.Properties.Spread)
end
function v_u_1.getBaseSpread(p90) -- name: getBaseSpread
	local v91 = p90.Spread:getPosition()
	return type(v91) ~= "number" and 0 or v91
end
function v_u_1.getBaseSpreadForConfig(p92, p93) -- name: getBaseSpreadForConfig
	local v94 = p93 or (p92.ActiveSpreadConfig or p92.Properties.Spread)
	local v95 = p92.Spread:getPosition()
	local v96 = type(v95) ~= "number" and 0 or v95
	if not v94 then
		return v96
	end
	local v97 = v94.Range.Min
	local v98 = v94.Range.Max
	return math.clamp(v96, v97, v98)
end
function v_u_1.getMovementSpreadForConfig(p99, p100) -- name: getMovementSpreadForConfig
	local v101 = p99.CharacterSpeed < 6.4 and 0 or p99.CharacterSpeed
	local v102 = p100 or (p99.ActiveSpreadConfig or p99.Properties.Spread)
	return v101 * (not v102 and 1 or v102.MovementMultiplier)
end
function v_u_1.getSpreadForConfig(p103, p104) -- name: getSpreadForConfig
	local v105 = p104 or (p103.ActiveSpreadConfig or p103.Properties.Spread)
	return p103:getBaseSpreadForConfig(v105) + p103:getMovementSpreadForConfig(v105)
end
function v_u_1.setBaseSpreadForConfig(p106, p107, p108) -- name: setBaseSpreadForConfig
	local v109 = p108 or (p106.ActiveSpreadConfig or p106.Properties.Spread)
	assert(v109, "Weapon properties missing spread configuration")
	local v110 = p106.Spread
	if v109 then
		local v111 = v109.Range.Min
		local v112 = v109.Range.Max
		p107 = math.clamp(p107, v111, v112)
	end
	v110:setPosition(p107)
end
function v_u_1.updateSpread(p113, p114) -- name: updateSpread
	-- upvalues: (copy) v_u_41
	p113.Spread:update(p114)
	if not p113.IsActive and v_u_41(p113) then
		p113.Spread:reset(p113.Spread:getGoal())
		if p113.SpreadRecoveryConnection then
			p113.SpreadRecoveryConnection:Disconnect()
			p113.SpreadRecoveryConnection = nil
		end
	end
end
function v_u_1.setActive(p_u_115, p116) -- name: setActive
	-- upvalues: (copy) v_u_34, (copy) v_u_4
	if p_u_115.IsDestroyed or p_u_115.IsActive == p116 then
		return
	else
		p_u_115.IsActive = p116
		if p116 then
			v_u_34(p_u_115)
			if not (p_u_115.IsDestroyed or p_u_115.SpreadRecoveryConnection) then
				p_u_115.SpreadRecoveryConnection = v_u_4.BindToStepped(("%*.SpreadRecovery"):format(p_u_115.BindingName), function(_, p117)
					-- upvalues: (copy) p_u_115
					p_u_115:updateSpread(p117)
				end)
			end
			p_u_115.CharacterSpeedConnection = v_u_4.BindToHeartbeat(("%*.CharacterSpeed"):format(p_u_115.BindingName), function()
				-- upvalues: (ref) v_u_34, (copy) p_u_115
				v_u_34(p_u_115)
			end)
		else
			if p_u_115.CharacterSpeedConnection then
				p_u_115.CharacterSpeedConnection:Disconnect()
				p_u_115.CharacterSpeedConnection = nil
			end
			p_u_115.CharacterSpeed = 0
			p_u_115.isInAir = false
			p_u_115.jumpStartSpeed = nil
			p_u_115.verticalVelocity = 0
			p_u_115.isAtJumpPeak = false
		end
	end
end
function v_u_1._updateShotSpread(p118, p119, p120) -- name: _updateShotSpread
	local v121 = p118.ActiveSpreadConfig or p118.Properties.Spread
	assert(v121, "Weapon properties missing spread configuration")
	local v122 = v121.Range
	local v123 = v122.Min
	local v124 = v122.Max
	if p119 == "SniperScope" then
		if p120 then
			v123 = 0
		else
			local v125 = v121 and (v121.MovementMultiplier or 1) or 1
			v123 = v125 == 2 and 6 or (v125 == 3 and 12 or 15)
		end
	end
	local v126 = p118.Spread:getPosition()
	local v127 = (type(v126) ~= "number" and 0 or v126) + v121.PerShot
	local v128 = math.clamp(v127, v123, v124)
	p118.Spread:setPosition(v128)
end
function v_u_1.new(p129, p130) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_8, (copy) v_u_9, (copy) v_u_4
	local v131 = v_u_1
	local v132 = setmetatable({}, v131)
	v132.Janitor = v_u_8.new()
	v132.IsDestroyed = false
	v132.Properties = p130
	v132.Weapon = p129
	v132.CharacterSpeed = 0
	v132.isInAir = false
	v132.jumpStartSpeed = nil
	v132.verticalVelocity = 0
	v132.isAtJumpPeak = false
	local v133 = p130.Spread
	assert(v133, "Weapon properties missing spread configuration")
	v132.Spread = v_u_9.new(1, v133.RecoverySpeed, v133.Range.Min)
	v132.LastShotTick = 0
	v132.IsActive = false
	v132.BindingName = v_u_4.CreateBindingName("Components.Bullet")
	return v132
end
function v_u_1.destroy(p134) -- name: destroy
	if not p134.IsDestroyed then
		p134:setActive(false)
		if p134.SpreadRecoveryConnection then
			p134.SpreadRecoveryConnection:Disconnect()
			p134.SpreadRecoveryConnection = nil
		end
		p134.IsDestroyed = true
		p134.Janitor:Destroy()
		p134.Properties = nil
		p134.Weapon = nil
		p134.Spread = nil
		p134.Janitor = nil
	end
end
return v_u_1
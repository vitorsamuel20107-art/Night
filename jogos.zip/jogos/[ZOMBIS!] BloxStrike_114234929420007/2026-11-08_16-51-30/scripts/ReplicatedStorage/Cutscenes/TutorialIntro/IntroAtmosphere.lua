-- NIGHT Analyzer | ReplicatedStorage.Cutscenes.TutorialIntro.IntroAtmosphere
-- ModuleScript | 358 linhas | 10093 bytes | hash a45d5c6d

local v_u_1 = game:GetService("Lighting")
local v_u_2 = {}
v_u_2.__index = v_u_2
v_u_2.TEXTURES = { "rbxassetid://901813002", "rbxassetid://87378350610127" }
local v_u_3 = {
	["A"] = {
		7,
		9,
		0.16,
		0
	},
	["B"] = {
		13,
		9,
		0.22,
		0
	},
	["C"] = {
		13,
		10,
		0.2,
		0
	},
	["D"] = {
		6,
		14,
		0.12,
		0
	}
}
local v_u_4 = {
	["Contrast"] = 0.08,
	["Saturation"] = -0.05,
	["Tint"] = nil,
	["Tint"] = Color3.fromRGB(255, 238, 218)
}
local v_u_5 = { Vector2.new(-3.5, 11.5), Vector2.new(2.5, 7.5), Vector2.new(5.5, 12.5) }
local v_u_6 = Color3.fromRGB(255, 214, 166)
local v_u_7 = { Vector3.new(3.5, 0.5, 8), Vector3.new(-3.5, 0.5, 8) }
local function v_u_15(p8) -- name: numbers
	local v9 = {}
	for _, v10 in p8 do
		local v11 = NumberSequenceKeypoint.new
		local v12 = v10[1]
		local v13 = v10[2]
		local v14 = v10[3] or 0
		table.insert(v9, v11(v12, v13, v14))
	end
	return NumberSequence.new(v9)
end
local function v_u_20(p16, p17, p18) -- name: motes
	-- upvalues: (copy) v_u_15
	local v19 = Instance.new("ParticleEmitter")
	v19.Name = "Motes"
	v19.Texture = "rbxassetid://901813002"
	v19.Shape = Enum.ParticleEmitterShape.Box
	v19.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
	v19.ShapeInOut = Enum.ParticleEmitterShapeInOut.Outward
	v19.Rate = p17
	v19.Lifetime = NumberRange.new(5, 8)
	v19.Size = v_u_15({
		{ 0, 0.05, 0.02 },
		{ 1, 0.05, 0.02 }
	})
	v19.Transparency = v_u_15({
		{ 0, 1 },
		{ 0.2, 0.35, 0.15 },
		{ 0.8, 0.45, 0.15 },
		{ 1, 1 }
	})
	v19.Color = ColorSequence.new(Color3.fromRGB(255, 228, 186))
	v19.LightEmission = p18
	v19.LightInfluence = 0.3
	v19.Speed = NumberRange.new(0.04, 0.22)
	v19.SpreadAngle = Vector2.new(180, 180)
	v19.Drag = 0.6
	v19.Acceleration = Vector3.new(0.05, 0.03, 0)
	v19.RotSpeed = NumberRange.new(-30, 30)
	v19.Parent = p16
	return v19
end
local function v_u_24(p21, p22) -- name: puffs
	-- upvalues: (copy) v_u_15
	local v23 = Instance.new("ParticleEmitter")
	v23.Name = p22
	v23.Texture = "rbxassetid://87378350610127"
	v23.Rate = 0
	v23.Lifetime = NumberRange.new(1.4, 2.4)
	v23.Size = v_u_15({
		{ 0, 1.2, 0.4 },
		{ 1, 5, 1 }
	})
	v23.Transparency = v_u_15({
		{ 0, 1 },
		{ 0.1, 0.72 },
		{ 1, 1 }
	})
	v23.Color = ColorSequence.new(Color3.fromRGB(206, 184, 148))
	v23.LightEmission = 0.05
	v23.LightInfluence = 0.9
	v23.Speed = NumberRange.new(1.2, 3)
	v23.SpreadAngle = Vector2.new(30, 30)
	v23.EmissionDirection = Enum.NormalId.Back
	v23.Acceleration = Vector3.new(0, 0.7, 0)
	v23.Drag = 1.4
	v23.Rotation = NumberRange.new(0, 360)
	v23.RotSpeed = NumberRange.new(-25, 25)
	v23.Parent = p21
	return v23
end
function v_u_2.new(p25) -- name: new
	-- upvalues: (copy) v_u_2, (copy) v_u_20, (copy) v_u_7, (copy) v_u_24, (copy) v_u_15, (copy) v_u_1, (copy) v_u_5, (copy) v_u_6
	local v26 = v_u_2
	local v27 = setmetatable({}, v26)
	v27.Events = p25.Data.Events
	v27.Camera = p25.Camera
	v27.Folder = p25.Folder
	local v28 = Instance.new("DepthOfFieldEffect")
	v28.Name = "TutorialIntroFocus"
	v28.Parent = p25.Camera
	v27.Focus = v28
	local v29 = Instance.new("ColorCorrectionEffect")
	v29.Name = "TutorialIntroGrade"
	v29.Parent = p25.Camera
	v27.Grade = v29
	local v30 = p25.Folder
	local v31 = Instance.new("Part")
	v31.Name = "BedDust"
	v31.Size = Vector3.new(7, 5.6, 13)
	v31.Transparency = 1
	v31.Anchored = true
	v31.CanCollide = false
	v31.CanQuery = false
	v31.CanTouch = false
	v31.CastShadow = false
	v31.Parent = v30
	v27.BedDust = v31
	v27.BedLocal = CFrame.new(0, 6, 2.2)
	local v32 = v_u_20(v31, 14, 0.45)
	v32.LockedToPart = true
	v27.BedMotes = v32
	v27.WheelDust = {}
	for v33, v34 in v_u_7 do
		local v35 = "WheelDust" .. v33
		local v36 = p25.Folder
		local v37 = Instance.new("Part")
		v37.Name = v35
		v37.Size = Vector3.new(0.6, 0.2, 0.6)
		v37.Transparency = 1
		v37.Anchored = true
		v37.CanCollide = false
		v37.CanQuery = false
		v37.CanTouch = false
		v37.CastShadow = false
		v37.Parent = v36
		local v38 = v27.WheelDust
		local v39 = {
			["Part"] = v37,
			["Local"] = CFrame.new(v34),
			["Emitter"] = v_u_24(v37, "Dust")
		}
		table.insert(v38, v39)
	end
	local v40 = p25.Folder
	local v41 = Instance.new("Part")
	v41.Name = "LandingDust"
	v41.Size = Vector3.new(1.4, 0.2, 1.4)
	v41.Transparency = 1
	v41.Anchored = true
	v41.CanCollide = false
	v41.CanQuery = false
	v41.CanTouch = false
	v41.CastShadow = false
	v41.Parent = v40
	local v42 = v_u_24(v41, "Puffs")
	v42.EmissionDirection = Enum.NormalId.Top
	v42.SpreadAngle = Vector2.new(75, 75)
	v42.Speed = NumberRange.new(2.5, 5)
	v42.Lifetime = NumberRange.new(0.9, 1.6)
	v42.Size = v_u_15({
		{ 0, 0.8, 0.3 },
		{ 1, 3.2, 0.6 }
	})
	v42.Acceleration = Vector3.new(0, -1.5, 0)
	v42.Drag = 3
	v27.Landing = v41
	v27.LandingPuffs = v42
	v27.Landed = {}
	local v43 = -(p25.SunDirection or v_u_1:GetSunDirection())
	v27.ShaftParts = {}
	v27.ShaftBeams = {}
	v27.ShaftMotes = nil
	if v43.Z > 0.2 and v43.Y < 0 then
		local v44 = 33 / v43.Z
		local v45 = p25.Folder
		local v46 = Instance.new("Part")
		v46.Name = "SunShaft"
		v46.Size = Vector3.new(0.2, 0.2, 0.2)
		v46.Transparency = 1
		v46.Anchored = true
		v46.CanCollide = false
		v46.CanQuery = false
		v46.CanTouch = false
		v46.CastShadow = false
		v46.Parent = v45
		v46.CFrame = CFrame.new(0, 0, -126)
		local v47 = v27.ShaftParts
		table.insert(v47, v46)
		for v48, v49 in v_u_5 do
			local v50 = Instance.new("Attachment")
			v50.Parent = v46
			local v51 = v49.X
			local v52 = v49.Y
			v50.WorldPosition = Vector3.new(v51, v52, -128)
			local v53 = Instance.new("Attachment")
			v53.Parent = v46
			v53.WorldPosition = v50.WorldPosition + v43 * v44
			local v54 = Instance.new("Beam")
			v54.Name = "Shaft" .. v48
			v54.Attachment0 = v50
			v54.Attachment1 = v53
			v54.Texture = "rbxassetid://901813002"
			v54.TextureMode = Enum.TextureMode.Stretch
			v54.TextureLength = 1
			v54.FaceCamera = true
			v54.Width0 = 5 + v48
			v54.Width1 = 7 + v48
			v54.LightEmission = 1
			v54.LightInfluence = 0
			v54.Color = ColorSequence.new(v_u_6)
			v54.Segments = 1
			v54.Enabled = false
			v54.Parent = v46
			local v55 = v27.ShaftBeams
			table.insert(v55, v54)
		end
		local v56 = Vector3.new(14, 9, v44)
		local v57 = p25.Folder
		local v58 = Instance.new("Part")
		v58.Name = "ShaftDust"
		v58.Size = v56
		v58.Transparency = 1
		v58.Anchored = true
		v58.CanCollide = false
		v58.CanQuery = false
		v58.CanTouch = false
		v58.CastShadow = false
		v58.Parent = v57
		local v59 = Vector3.new(1, 7, -126) + v43 * (v44 / 2)
		v58.CFrame = CFrame.lookAt(v59, v59 + v43)
		local v60 = v27.ShaftParts
		table.insert(v60, v58)
		local v61 = v_u_20(v58, 0, 0.5)
		v61.LightInfluence = 0
		v61.Size = v_u_15({
			{ 0, 0.05, 0.02 },
			{ 1, 0.05, 0.02 }
		})
		v61.Transparency = v_u_15({
			{ 0, 1 },
			{ 0.25, 0.55, 0.15 },
			{ 0.75, 0.6, 0.15 },
			{ 1, 1 }
		})
		v27.ShaftMotes = v61
	end
	v27.ShaftOn = false
	v27.LastTruck = nil
	v27.Speed = 0
	return v27
end
function v_u_2.Update(p62, p63, p64, p65, p66, p67) -- name: Update
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v68 = p62.Events
	local v69 = (p63 - v68.LetterboxRetract[1]) / (v68.LetterboxRetract[2] - v68.LetterboxRetract[1])
	local v70 = math.clamp(v69, 0, 1)
	local v71 = 1 - v70 * v70 * v70 * (v70 * (v70 * 6 - 15) + 10)
	local v72 = v_u_3[v68.ShotD <= p63 and "D" or (v68.ShotC <= p63 and "C" or (v68.ShotB <= p63 and "B" or "A"))]
	p62.Focus.FocusDistance = v72[1]
	p62.Focus.InFocusRadius = v72[2]
	p62.Focus.FarIntensity = v72[3] * v71
	p62.Focus.NearIntensity = v72[4] * v71
	p62.Focus.Enabled = v71 > 0.001
	p62.Grade.Contrast = v_u_4.Contrast * v71
	p62.Grade.Saturation = v_u_4.Saturation * v71
	p62.Grade.TintColor = Color3.new(1, 1, 1):Lerp(v_u_4.Tint, v71)
	p62.Grade.Enabled = v71 > 0.001
	local v73 = p66.Position
	if p62.LastTruck and p64 > 0 then
		local v74 = (v73 - p62.LastTruck).Magnitude / p64
		local v75 = p62.Speed
		local v76 = v74 - p62.Speed
		local v77 = p64 * 8
		p62.Speed = v75 + v76 * math.min(1, v77)
	end
	p62.LastTruck = v73
	p62.BedDust.CFrame = p65 * p62.BedLocal
	local v78 = p62.Speed / 14
	local v79 = math.clamp(v78, 0, 1)
	for _, v80 in p62.WheelDust do
		v80.Part.CFrame = p66 * v80.Local
		v80.Emitter.Rate = v79 * 16
	end
	if v68.ShotB <= p63 then
		for v81, v82 in p67 do
			if p62.Landed[v81] or v82.Position.Y >= 3.3 then
				continue
			end
			p62.Landed[v81] = true
			p62.Landing.CFrame = CFrame.new(v82.Position.X, 0.15, v82.Position.Z)
			p62.LandingPuffs:Emit(12)
		end
	end
	local v83
	if v68.ShotB <= p63 then
		local v84 = (p63 - v68.ShotD) / 0.75
		local v85 = math.clamp(v84, 0, 1)
		v83 = 1 - v85 * v85 * v85 * (v85 * (v85 * 6 - 15) + 10)
	else
		v83 = 0
	end
	if v83 > 0 and not p62.ShaftOn then
		p62.ShaftOn = true
		if p62.ShaftMotes then
			p62.ShaftMotes.Rate = 9
			p62.ShaftMotes:Emit(45)
		end
	elseif v83 <= 0 and (p62.ShaftOn and v68.ShotD <= p63) then
		p62.ShaftOn = false
		if p62.ShaftMotes then
			p62.ShaftMotes.Rate = 0
			p62.ShaftMotes:Clear()
		end
	end
	for v86, v87 in p62.ShaftBeams do
		v87.Enabled = v83 > 0
		local v88 = 1 - (1 - (0.84 + 0.03 * v86)) * v83
		v87.Transparency = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1),
			NumberSequenceKeypoint.new(0.18, v88),
			NumberSequenceKeypoint.new(0.65, 1 - (1 - v88) * 0.8),
			NumberSequenceKeypoint.new(1, 1)
		})
	end
end
function v_u_2.Shake(p89, p90) -- name: Shake
	if p89.Events.ShotB <= p90 then
		return CFrame.identity
	end
	local v91 = p89.Speed / 14
	local v92 = math.clamp(v91, 0.2, 1)
	return CFrame.new(v92 * 0.01600000075995922 * (math.noise(p90 * 9, 1, 0.5) + 0.35 * math.noise(p90 * 1.3, 8, 0.25)), v92 * 0.026000000536441803 * (math.noise(p90 * 11, 2, 0.5) + 0.35 * math.noise(p90 * 1.3, 9, 0.25)), 0) * CFrame.Angles(v92 * 0.0035000001080334187 * (math.noise(p90 * 8, 3, 0.5) + 0.35 * math.noise(p90 * 1.3, 10, 0.25)), v92 * 0.002199999988079071 * (math.noise(p90 * 7, 4, 0.5) + 0.35 * math.noise(p90 * 1.3, 11, 0.25)), v92 * 0.0044999998062849045 * (math.noise(p90 * 10, 5, 0.5) + 0.35 * math.noise(p90 * 1.3, 12, 0.25)))
end
function v_u_2.Destroy(p93) -- name: Destroy
	p93.Focus:Destroy()
	p93.Grade:Destroy()
end
return v_u_2
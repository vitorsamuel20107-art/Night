-- NIGHT Analyzer | ReplicatedStorage.Cutscenes.TutorialIntro.IntroPlayer
-- ModuleScript | 412 linhas | 10649 bytes | hash 81096823

local v_u_1 = game:GetService("KeyframeSequenceProvider")
local v_u_2 = {}
v_u_2.__index = v_u_2
local function v_u_4(p3) -- name: cframeOf
	return CFrame.new(p3[1], p3[2], p3[3], p3[4], p3[5], p3[6], p3[7], p3[8], p3[9], p3[10], p3[11], p3[12])
end
local function v_u_15(p5, p6, p7) -- name: sampleTrack
	-- upvalues: (copy) v_u_4
	local v8 = p6 * p7
	local v9 = math.max(0, v8)
	local v10 = math.floor(v9)
	local v11 = #p5
	if v11 - 1 <= v10 then
		return v_u_4(p5[v11])
	end
	local v12 = p5[v10 + 1]
	local v13 = CFrame.new(v12[1], v12[2], v12[3], v12[4], v12[5], v12[6], v12[7], v12[8], v12[9], v12[10], v12[11], v12[12])
	local v14 = p5[v10 + 2]
	return v13:Lerp(CFrame.new(v14[1], v14[2], v14[3], v14[4], v14[5], v14[6], v14[7], v14[8], v14[9], v14[10], v14[11], v14[12]), v9 - v10)
end
local function v_u_52(p16, p17, p18) -- name: buildActor
	-- upvalues: (copy) v_u_1
	local v19 = p16.Options
	local v20 = v19.CharacterTemplate:Clone()
	v20.Name = "Intro_" .. p17
	for _, v21 in v20:GetDescendants() do
		if v21:IsA("BasePart") then
			v21.Anchored = false
			v21.CanCollide = false
			v21.CanQuery = false
			v21.CanTouch = false
			v21.Massless = true
		else
			if not v21:IsA("Sound") then
				continue
			end
			v21:Destroy()
		end
	end
	local v22 = v20:FindFirstChild("UpperTorso")
	if v22 then
		v22 = v22:FindFirstChild("Head")
	end
	if v22 and v22:IsA("Motor6D") then
		v22:Destroy()
	end
	local v23 = v20:FindFirstChild("HumanoidRootPart")
	v23.Anchored = true
	if v19.HeadMeshScale then
		local v24 = v20:FindFirstChild("Head")
		if v24 then
			v24 = v24:FindFirstChildOfClass("SpecialMesh")
		end
		if v24 then
			v24.Scale = Vector3.new(1, 1, 1) * v19.HeadMeshScale
		end
	end
	local v25 = Instance.new("AnimationController")
	v25.Parent = v20
	local v26 = Instance.new("Animator")
	v26.Parent = v25
	local v27 = v19.WeaponTemplate:Clone()
	v27.Name = "AK-47"
	local v28 = v27:FindFirstChild("Weapon")
	if v28 then
		for _, v29 in { "Hitbox", "Insert" } do
			local v30 = v28:FindFirstChild(v29)
			if not v30 then
				continue
			end
			v30:Destroy()
		end
	end
	for _, v31 in v27:GetDescendants() do
		if v31:IsA("BasePart") then
			v31.Anchored = false
			v31.CanCollide = false
			v31.CanQuery = false
			v31.CanTouch = false
			v31.Massless = true
		else
			if not (v31:IsA("Sound") or v31:IsA("Light")) then
				continue
			end
			v31:Destroy()
		end
	end
	v27.Parent = v20
	local v32 = p18.WeaponHold
	local v33 = Instance.new("Motor6D")
	v33.Name = v32.MotorName
	v33.Part0 = v20:FindFirstChild(v32.Part0)
	if v28 then
		v28 = v28:FindFirstChild(v32.Part1)
	end
	v33.Part1 = v28
	local v34 = v32.C0
	v33.C0 = CFrame.new(v34[1], v34[2], v34[3], v34[4], v34[5], v34[6], v34[7], v34[8], v34[9], v34[10], v34[11], v34[12])
	local v35 = v32.C1
	v33.C1 = CFrame.new(v35[1], v35[2], v35[3], v35[4], v35[5], v35[6], v35[7], v35[8], v35[9], v35[10], v35[11], v35[12])
	v33.Parent = v33.Part0
	local v36 = p18.Root[1]
	v23.CFrame = CFrame.new(v36[1], v36[2], v36[3], v36[4], v36[5], v36[6], v36[7], v36[8], v36[9], v36[10], v36[11], v36[12])
	v20.Parent = p16.Folder
	local v37 = v19.Animations[p17]
	local v38 = Enum.AnimationPriority.Core
	local v39
	if v37:IsA("KeyframeSequence") then
		v39 = Instance.new("Animation")
		v39.AnimationId = v_u_1:RegisterKeyframeSequence(v37)
	else
		v39 = v37
	end
	local v40 = v26:LoadAnimation(v39)
	v40.Looped = false
	v40.Priority = v38
	local v41 = v19.HoldAnimation
	local v42 = Enum.AnimationPriority.Idle
	local v43
	if v41:IsA("KeyframeSequence") then
		v43 = Instance.new("Animation")
		v43.AnimationId = v_u_1:RegisterKeyframeSequence(v41)
	else
		v43 = v41
	end
	local v44 = v26:LoadAnimation(v43)
	v44.Looped = true
	v44.Priority = v42
	local v45 = v19.LeftArmAnimations[p17]
	local v46 = Enum.AnimationPriority.Action
	local v47
	if v45:IsA("KeyframeSequence") then
		v47 = Instance.new("Animation")
		v47.AnimationId = v_u_1:RegisterKeyframeSequence(v45)
	else
		v47 = v45
	end
	local v48 = v26:LoadAnimation(v47)
	v48.Looped = false
	v48.Priority = v46
	local v49 = {}
	for _, v50 in v20:GetDescendants() do
		if not (v50:IsA("BasePart") or v50:IsA("Decal")) then
			continue
		end
		local v51 = { v50, v50.Transparency }
		table.insert(v49, v51)
		v50.Transparency = 1
	end
	return {
		["Model"] = nil,
		["Root"] = nil,
		["Track"] = nil,
		["Hold"] = nil,
		["LeftArm"] = nil,
		["Rig"] = nil,
		["Parts"] = nil,
		["Hidden"] = true,
		["Animated"] = false,
		["Model"] = v20,
		["Root"] = v23,
		["Track"] = v40,
		["Hold"] = v44,
		["LeftArm"] = v48,
		["Rig"] = p18,
		["Parts"] = v49
	}
end
local function v_u_57(p53) -- name: buildOverlay
	local v54 = Instance.new("ScreenGui")
	v54.Name = "TutorialIntroOverlay"
	v54.IgnoreGuiInset = true
	v54.DisplayOrder = 50
	v54.ResetOnSpawn = false
	local v55 = Instance.new("Frame")
	v55.Name = "BarTop"
	v55.BackgroundColor3 = Color3.new(0, 0, 0)
	v55.BorderSizePixel = 0
	v55.Size = UDim2.fromScale(1, 0.12)
	v55.Parent = v54
	local v56 = v55:Clone()
	v56.Name = "BarBottom"
	v56.AnchorPoint = Vector2.new(0, 1)
	v56.Position = UDim2.fromScale(0, 1)
	v56.Parent = v54
	v54.Parent = p53
	return {
		["Screen"] = nil,
		["Top"] = nil,
		["Bottom"] = nil,
		["Bar"] = 0.12,
		["Screen"] = v54,
		["Top"] = v55,
		["Bottom"] = v56
	}
end
function v_u_2.new(p58) -- name: new
	-- upvalues: (copy) v_u_2, (copy) v_u_52, (copy) v_u_57
	local v59 = v_u_2
	local v60 = setmetatable({}, v59)
	v60.Options = p58
	v60.Data = p58.Data
	v60.Fps = p58.Data.Fps
	v60.Duration = p58.Data.Duration
	v60.CutFrames = {}
	for v61, v62 in p58.Data.Events do
		if string.sub(v61, 1, 4) ~= "Shot" or type(v62) ~= "number" then
			continue
		end
		local v63 = v60.CutFrames
		local v64 = v62 * v60.Fps + 0.5
		v63[math.floor(v64)] = true
	end
	v60.Camera = p58.Camera or workspace.CurrentCamera
	local v65 = Instance.new("Folder")
	v65.Name = "TutorialIntro"
	v65.Parent = p58.Parent or workspace
	v60.Folder = v65
	v60.Actors = {}
	for v66, v67 in p58.Data.Rigs do
		v60.Actors[v66] = v_u_52(v60, v66, v67)
	end
	v60.Truck = p58.TruckBuilder.build(v65)
	v60.Roots = {}
	for _, v68 in v60.Actors do
		local v69 = v60.Roots
		local v70 = v68.Root
		table.insert(v69, v70)
	end
	if p58.Atmosphere then
		v60.Atmosphere = p58.Atmosphere.new({
			["Data"] = p58.Data,
			["Folder"] = v65,
			["Camera"] = v60.Camera,
			["SunDirection"] = p58.SunDirection
		})
	end
	local v71 = p58.Map
	if v71 then
		v71 = p58.Map:FindFirstChild("TutorialDoors")
	end
	if v71 then
		v71 = v71:FindFirstChild("DockDoor")
	end
	if v71 and v71:IsA("Model") then
		v60.DockDoor = v71
		v60.DockDoorClosed = v71:GetPivot()
		v60.DockDoorOffset = v71:GetAttribute("OpenOffset") or Vector3.new(0, 10.5, 0)
	end
	if p58.Gui then
		v60.Overlay = v_u_57(p58.Gui)
	end
	v60.Started = false
	v60:Update(0)
	return v60
end
function v_u_2.Start(p72) -- name: Start
	for _, v73 in p72.Actors do
		v73.Track:Play(0, 1, 1)
		v73.Hold:Play(0, 1, 1)
		v73.LeftArm:Play(0, 0.0001, 1)
	end
	p72.Started = true
	p72.LastClock = nil
end
function v_u_2.Time(p74) -- name: Time
	for _, v75 in p74.Actors do
		if not v75.Track.IsPlaying then
			continue
		end
		return v75.Track.TimePosition
	end
	return p74.Duration
end
function v_u_2.Update(p76, p77) -- name: Update
	-- upvalues: (copy) v_u_15
	local v78 = p77 or (not p76.Started and 0 or p76:Time())
	local v79 = p76.Duration
	local v80 = math.clamp(v78, 0, v79)
	local v81 = p76.Data
	local v82 = p76.Fps
	local v83
	if p76.LastClock then
		local v84 = v80 - p76.LastClock
		v83 = math.clamp(v84, 0, 0.1)
	else
		v83 = 0
	end
	p76.LastClock = v80
	for _, v85 in p76.Actors do
		v85.Root.CFrame = v_u_15(v85.Rig.Root, v80, v82)
		if p76.Started then
			local v86 = v80 + v83
			local v87 = p76.Duration
			local v88 = math.min(v86, v87)
			local v89 = v85.LeftArm
			local v90 = v85.Rig.LeftArmWeight
			local v91 = v88 * v82
			local v92 = math.max(0, v91)
			local v93 = math.floor(v92)
			local v94 = #v90
			local v95
			if v94 - 1 <= v93 then
				v95 = v90[v94]
			else
				v95 = v90[v93 + 1] + (v90[v93 + 2] - v90[v93 + 1]) * (v92 - v93)
			end
			v89:AdjustWeight(math.max(v95, 0.0001), 0)
		end
		if p76.Started and v85.Track.TimePosition > 0 then
			v85.Animated = true
		end
		local v96 = v85.Rig.HiddenFrom
		local v97 = not v85.Animated
		if not v97 then
			if v96 == nil then
				v97 = false
			else
				v97 = v96 <= v80
			end
		end
		if v97 == v85.Hidden then
			continue
		end
		v85.Hidden = v97
		for _, v98 in v85.Parts do
			v98[1].Transparency = v97 and 1 or v98[2]
		end
	end
	local v99 = (v81.Truck.SettledFrame - 1) / v82
	local v100 = math.min(v80, v99)
	local v101 = v_u_15(v81.Truck.Body, v100, v82)
	local v102 = v_u_15(v81.Truck.Wheels, v100, v82)
	p76.Options.TruckBuilder.place(p76.Truck, v101, v102)
	local v103 = p76.Atmosphere
	if v103 then
		v103:Update(v80, v83, v101, v102, p76.Roots)
	end
	local v104 = p76.Camera
	v104.CameraType = Enum.CameraType.Scriptable
	local v105 = v80 * v82 + 0.01
	local v106 = math.floor(v105)
	local v107
	if p76.CutFrames[v106 + 1] then
		v107 = v106 / v82
	else
		v107 = v80
	end
	local v108 = v_u_15(v81.Camera, v107, v82)
	if v103 then
		v108 = v108 * v103:Shake(v107)
	end
	v104.CFrame = v108
	local v109 = v81.CameraFov
	local v110 = v107 * v82
	local v111 = math.max(0, v110)
	local v112 = math.floor(v111)
	local v113 = #v109
	local v114
	if v113 - 1 <= v112 then
		v114 = v109[v113]
	else
		v114 = v109[v112 + 1] + (v109[v112 + 2] - v109[v112 + 1]) * (v111 - v112)
	end
	v104.FieldOfView = v114
	local v115 = v81.Events
	if p76.DockDoor then
		local v116 = p76.DockDoor
		local v117 = p76.DockDoorClosed
		local v118 = p76.DockDoorOffset
		local v119 = v115.DockDoorOpen
		local v120
		if v119 then
			local v121 = (v80 - v119[1]) / (v119[2] - v119[1])
			local v122 = math.clamp(v121, 0, 1)
			v120 = v122 * v122 * v122 * (v122 * (v122 * 6 - 15) + 10)
		else
			v120 = 0
		end
		v116:PivotTo(v117 + v118 * v120)
	end
	local v123 = p76.Overlay
	if v123 then
		local v124 = v115.LetterboxRetract
		local v125
		if v124 then
			local v126 = (v80 - v124[1]) / (v124[2] - v124[1])
			local v127 = math.clamp(v126, 0, 1)
			v125 = v127 * v127 * v127 * (v127 * (v127 * 6 - 15) + 10)
		else
			v125 = 0
		end
		v123.Top.Position = UDim2.fromScale(0, -v123.Bar * v125)
		v123.Bottom.Position = UDim2.fromScale(0, 1 + v123.Bar * v125)
	end
	return p76.Duration <= v80
end
function v_u_2.Destroy(p128) -- name: Destroy
	for _, v129 in p128.Actors do
		v129.Track:Stop(0)
		v129.Hold:Stop(0)
		v129.LeftArm:Stop(0)
	end
	if p128.Overlay then
		p128.Overlay.Screen:Destroy()
	end
	if p128.Atmosphere then
		p128.Atmosphere:Destroy()
	end
	p128.Folder:Destroy()
end
return v_u_2
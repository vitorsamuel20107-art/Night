-- NIGHT Analyzer | ReplicatedStorage.Cutscenes.TutorialIntro.TruckBuilder
-- ModuleScript | 103 linhas | 2424 bytes | hash 051e4522

local v_u_1 = game:GetService("ReplicatedStorage")
local v2 = {}
local v_u_3 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_6() -- name: findTemplate
	-- upvalues: (copy) v_u_1
	local v4 = v_u_1:WaitForChild("Assets", 5)
	if v4 then
		v4 = v4:WaitForChild("Cutscenes", 5)
	end
	if v4 then
		v4 = v4:WaitForChild("TutorialTruck", 5)
	end
	local v5
	if v4 then
		v5 = v4:IsA("Model")
	else
		v5 = v4
	end
	assert(v5, "ReplicatedStorage.Assets.Cutscenes.TutorialTruck is missing")
	return v4
end
function v2.template() -- name: template
	-- upvalues: (copy) v_u_6
	return v_u_6()
end
function v2.build(p7) -- name: build
	-- upvalues: (copy) v_u_6, (copy) v_u_3
	local v8 = v_u_6()
	local v9 = v8:Clone()
	v9.Name = "CutsceneTruck"
	local v10 = {
		["Parts"] = nil,
		["Locals"] = nil,
		["Axles"] = nil,
		["IsWheel"] = nil,
		["CFrames"] = nil,
		["Radius"] = nil,
		["Start"] = nil,
		["Parts"] = {},
		["Locals"] = {},
		["Axles"] = {},
		["IsWheel"] = {},
		["CFrames"] = {},
		["Radius"] = v8:GetAttribute("WheelRadius") or 1.6
	}
	for _, v11 in v9:GetChildren() do
		local v12 = v11.Name == "Wheels"
		for _, v13 in v11:GetChildren() do
			local v14 = v13:GetAttribute("Local")
			if not v13:IsA("BasePart") or typeof(v14) ~= "CFrame" then
				continue
			end
			local v15 = v13:GetAttribute("Axle")
			local v16 = v10.Parts
			table.insert(v16, v13)
			local v17 = v10.Locals
			table.insert(v17, v14)
			local v18 = v10.Axles
			local v19 = #v10.Parts
			if typeof(v15) ~= "Vector3" then
				v15 = nil
			end
			v18[v19] = v15
			local v20 = v10.IsWheel
			table.insert(v20, v12)
			local v21 = v10.CFrames
			table.insert(v21, v14)
		end
	end
	v_u_3[v9] = v10
	v9.Parent = p7
	return v9
end
function v2.place(p22, p23, p24) -- name: place
	-- upvalues: (copy) v_u_3
	local v25 = v_u_3[p22]
	if v25 then
		local v26 = p24 or p23
		if not v25.Start then
			v25.Start = v26.Position
		end
		local v27 = (v26.Position - v25.Start):Dot(v26.LookVector)
		local v28 = CFrame.Angles(-v27 / v25.Radius, 0, 0)
		local v29 = v25.CFrames
		for v30, v31 in v25.Locals do
			if v25.IsWheel[v30] then
				local v32 = v25.Axles[v30]
				if v32 then
					local v33 = CFrame.new(v32)
					v29[v30] = v26 * v33 * v28 * v33:Inverse() * v31
				else
					v29[v30] = v26 * v31
				end
			else
				v29[v30] = p23 * v31
			end
		end
		workspace:BulkMoveTo(v25.Parts, v29, Enum.BulkMoveMode.FireCFrameChanged)
	end
end
return v2
#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# Night Optimizer - modules/permissions.sh
# Verificação de permissões/níveis de acesso e orientação ao
# usuário. Nunca tenta contornar permissões do Android.
# ============================================================

permissions_check() {
    echo "Verificação de permissões e níveis de acesso:"
    echo
    if ! $NO_HAS_TERMUX_API; then
        echo -e "${C_YELLOW}Esta função precisa do app/pacote Termux:API.${C_RESET}"
        echo "  Instale o pacote 'termux-api' (pkg install termux-api) e o app"
        echo "  Termux:API na mesma loja de onde veio o Termux."
    else
        echo -e "${C_GREEN}Termux:API disponível.${C_RESET}"
    fi

    if ! has_privilege; then
        echo -e "${C_YELLOW}Nenhum nível privilegiado (root/ADB/Shizuku) disponível.${C_RESET}"
        echo "  Funções de limpeza de cache, ajuste de animações e detecção do"
        echo "  app em primeiro plano ficarão limitadas ao monitoramento."
        echo
        echo "  Para habilitar via ADB sem fio (Android 11+):"
        echo "   1. Ative 'Depuração USB sem fio' em Opções do desenvolvedor."
        echo "   2. No Termux: pkg install android-tools"
        echo "   3. adb pair <ip>:<porta de pareamento>"
        echo "   4. adb connect <ip>:<porta>"
    else
        echo -e "${C_GREEN}Nível privilegiado disponível.${C_RESET}"
    fi
}

permissions_open_settings() {
    if have_cmd am; then
        am start -a android.settings.APPLICATION_DETAILS_SETTINGS \
            -d package:com.termux >/dev/null 2>&1
        echo "Tela de configurações do Termux aberta."
    else
        echo "Não foi possível abrir as configurações automaticamente."
    fi
}

#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# Night Optimizer - modules/system.sh
# Detecção do dispositivo e painel de status.
# ============================================================

system_detect_device() {
    echo -e "${C_CYAN}Analisando dispositivo...${C_RESET}"
    detect_access_level
    NO_DEV_MANUFACTURER="$(get_manufacturer)"
    NO_DEV_MODEL="$(get_model)"
    NO_DEV_ANDROID="$(get_android_ver)"
    NO_DEV_SDK="$(get_sdk_level)"
    NO_DEV_ARCH="$(get_arch)"
    log_ok "Dispositivo: $NO_DEV_MANUFACTURER $NO_DEV_MODEL | Android $NO_DEV_ANDROID (SDK $NO_DEV_SDK) | $NO_DEV_ARCH"

    echo -e "${C_GREEN}Dispositivo analisado.${C_RESET}"
    echo "  Fabricante: $NO_DEV_MANUFACTURER"
    echo "  Modelo: $NO_DEV_MODEL"
    echo "  Android: $NO_DEV_ANDROID (API $NO_DEV_SDK)"
    echo "  Arquitetura: $NO_DEV_ARCH"
    echo
    echo "  Root:        $($NO_HAS_ROOT && echo 'DISPONÍVEL' || echo 'indisponível')"
    echo "  ADB:         $($NO_HAS_ADB && echo 'DISPONÍVEL' || echo 'indisponível')"
    echo "  Shizuku:     $($NO_HAS_SHIZUKU && echo 'DISPONÍVEL' || echo 'indisponível')"
    echo "  Termux:API:  $($NO_HAS_TERMUX_API && echo 'DISPONÍVEL' || echo 'indisponível')"
}

system_status_panel() {
    local ram_used ram_total ram_pct cpu temp bat_pct bat_temp bat_status storage_used storage_total storage_pct
    read -r ram_used ram_total ram_pct <<< "$(get_ram_stats)"
    cpu="$(get_cpu_usage)"
    temp="$(get_temperature)"
    read -r bat_pct bat_temp bat_status <<< "$(get_battery_info)"
    read -r storage_used storage_total storage_pct <<< "$(get_storage_stats)"

    echo -e "${C_BOLD}Night Optimizer${C_RESET}"
    echo "Status: ATIVO"
    echo
    echo "RAM: ${ram_used} MB / ${ram_total} MB (${ram_pct}%)"
    echo "CPU: ${cpu}%"
    echo "Temperatura: ${temp}°C"
    echo "Bateria: ${bat_pct}% (${bat_status})"
    echo "Armazenamento: ${storage_used} GB / ${storage_total} GB (${storage_pct}%)"
    echo
    echo "Root:        $($NO_HAS_ROOT && echo SIM || echo NÃO)"
    echo "ADB:         $($NO_HAS_ADB && echo SIM || echo NÃO)"
    echo "Shizuku:     $($NO_HAS_SHIZUKU && echo SIM || echo NÃO)"
    echo "Termux:API:  $($NO_HAS_TERMUX_API && echo SIM || echo NÃO)"
    echo
    echo "Modo atual: ${NO_CURRENT_MODE:-Normal}"
}

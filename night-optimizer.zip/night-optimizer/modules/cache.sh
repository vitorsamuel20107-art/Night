#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# Night Optimizer - modules/cache.sh
# Limpeza de cache. Nunca executa "clear data" nem apaga
# arquivos pessoais — apenas o mecanismo nativo pm trim-caches,
# que só afeta cache de aplicativos.
# ============================================================

cache_clean() {
    echo -e "${C_CYAN}Limpando cache...${C_RESET}"
    if ! has_privilege; then
        echo "Limpeza global de cache não permitida neste nível de acesso."
        log_warn "Cache cleanup: NOT AVAILABLE"
        return 1
    fi
    if run_priv 'pm trim-caches 1G' >/dev/null 2>&1; then
        echo -e "${C_GREEN}Cache otimizado com sucesso (pm trim-caches).${C_RESET}"
        log_ok "Cache cleanup: SUCCESS"
        send_notification "Night Optimizer" "Limpeza de cache concluída"
    else
        echo -e "${C_YELLOW}Não foi possível concluir a limpeza de cache.${C_RESET}"
        log_err "Cache cleanup: FAILED"
        return 1
    fi
}

cache_menu_interval() {
    echo "Intervalo de limpeza automática de cache:"
    echo " 1) 30 segundos   2) 1 minuto   3) 5 minutos"
    echo " 4) 10 minutos    5) 15 minutos 6) 30 minutos"
    echo " 7) 1 hora        8) Personalizado"
    echo " 9) Desativar limpeza automática"
    read -rp "Escolha: " opt
    case "$opt" in
        1) CACHE_INTERVAL=30 ;;
        2) CACHE_INTERVAL=60 ;;
        3) CACHE_INTERVAL=300 ;;
        4) CACHE_INTERVAL=600 ;;
        5) CACHE_INTERVAL=900 ;;
        6) CACHE_INTERVAL=1800 ;;
        7) CACHE_INTERVAL=3600 ;;
        8) read -rp "Segundos: " CACHE_INTERVAL ;;
        9) AUTO_CACHE=false; config_save; echo "Limpeza automática desativada."; return ;;
        *) echo "Opção inválida."; return ;;
    esac
    AUTO_CACHE=true
    config_save
    echo -e "${C_GREEN}Intervalo definido para ${CACHE_INTERVAL}s.${C_RESET}"
}

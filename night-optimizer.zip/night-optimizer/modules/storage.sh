#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# Night Optimizer - modules/storage.sh
# Monitoramento de armazenamento e limpeza de "lixo eletrônico".
# Nunca apaga DCIM, Pictures, Movies, Music, Documents ou
# Download sem confirmação explícita — e nem mesmo essas pastas
# são varridas pela busca de temporários.
# ============================================================

storage_status() {
    local used total pct state
    read -r used total pct <<< "$(get_storage_stats)"
    if [ "$pct" -ge "$STORAGE_CRITICO_PCT" ] 2>/dev/null; then
        state="CRITICO"
    elif [ "$pct" -ge "$STORAGE_BAIXO_PCT" ] 2>/dev/null; then
        state="BAIXO"
    else
        state="NORMAL"
    fi
    echo "Armazenamento: ${used} GB / ${total} GB (${pct}%)"
    echo "Estado: ${state}"
    log_msg INFO "Storage check: ${pct}% ($state)"
    if [ "$state" = "CRITICO" ]; then
        echo -e "${C_YELLOW}Pouco espaço disponível. A limpeza automática foi limitada para evitar apagar arquivos importantes.${C_RESET}"
    fi
}

storage_junk_scan() {
    local protected="DCIM|Pictures|Movies|Music|Documents|Download"
    local base="$HOME"
    [ -d "$HOME/storage/shared" ] && base="$HOME/storage/shared"

    echo "Procurando arquivos temporários em: $base"
    local list
    list="$(find "$base" -maxdepth 6 \
        \( -iname '*.tmp' -o -iname '*.log' -o -iname '*.cache' -o -iname '.thumbnails' \) \
        2>/dev/null | grep -Ev "$protected")"

    if [ -z "$list" ]; then
        echo "Nenhum arquivo temporário encontrado."
        log_msg INFO "Storage junk scan: nada encontrado"
        return 0
    fi

    local size_kb count
    size_kb=$(echo "$list" | tr '\n' '\0' | xargs -0 du -ck 2>/dev/null | tail -n1 | awk '{print $1}')
    count=$(echo "$list" | grep -c .)

    echo "Arquivos encontrados: ${count} (aprox. $(( size_kb / 1024 )) MB)"
    echo "$list" | head -n 20
    [ "$count" -gt 20 ] && echo "... e mais $((count-20)) arquivo(s)"
    echo
    read -rp "[L]impar ou [C]ancelar? " ans
    if [[ "$ans" =~ ^[Ll]$ ]]; then
        echo "$list" | while IFS= read -r f; do
            [ -f "$f" ] && rm -f "$f" 2>/dev/null
        done
        echo -e "${C_GREEN}Limpeza concluída.${C_RESET}"
        log_ok "Storage junk cleanup: ${count} arquivos removidos (~$(( size_kb / 1024 )) MB)"
    else
        echo "Cancelado."
        log_msg INFO "Storage junk cleanup: cancelado pelo usuário"
    fi
}

#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# Night Optimizer - modules/ram.sh
# Otimização adaptativa de RAM. Nunca mata tudo indiscriminadamente:
# preserva o app em primeiro plano, a whitelist e processos essenciais.
# ============================================================

ram_classify() {
    local pct="$1"
    if [ "$pct" -ge "$RAM_CRITICA_PCT" ]; then
        echo "CRITICA"
    elif [ "$pct" -ge "$RAM_ALTA_PCT" ]; then
        echo "ALTA"
    else
        echo "NORMAL"
    fi
}

ram_optimize() {
    local ram_used ram_total pct state fg pkgs killed=0
    read -r ram_used ram_total pct <<< "$(get_ram_stats)"
    state="$(ram_classify "$pct")"
    echo -e "${C_CYAN}RAM: ${ram_used}MB/${ram_total}MB (${pct}%) - Estado: ${state}${C_RESET}"
    log_msg INFO "RAM check: ${pct}% ($state)"

    if [ "$state" = "NORMAL" ]; then
        echo "RAM dentro do normal. Nenhuma ação necessária."
        return 0
    fi

    if ! has_privilege; then
        echo -e "${C_YELLOW}Otimização ativa de RAM requer root, ADB ou Shizuku.${C_RESET}"
        echo "Sem esses níveis, apenas o monitoramento é possível."
        log_warn "RAM optimize: NOT AVAILABLE (sem privilégio)"
        return 1
    fi

    fg="$(get_foreground_app)"
    echo "Aplicativo em primeiro plano (preservado): $fg"

    pkgs="$(run_priv 'pm list packages -3' 2>/dev/null | sed 's/^package://')"
    if [ -z "$pkgs" ]; then
        echo -e "${C_YELLOW}Não foi possível listar aplicativos em segundo plano.${C_RESET}"
        log_warn "RAM optimize: falha ao listar pacotes"
        return 1
    fi

    local restricted=0
    while IFS= read -r pkg; do
        [ -z "$pkg" ] && continue
        [ "$pkg" = "$fg" ] && continue
        echo "$RAM_WHITELIST" | tr ',' '\n' | grep -qx "$pkg" && continue
        run_priv "am kill $pkg" >/dev/null 2>&1
        killed=$((killed+1))
        # App Standby Buckets: mecanismo oficial do Android (desde a v9)
        # para limitar jobs/alarmes/rede de apps ociosos em segundo plano,
        # mais "nativo" que apenas finalizar o processo. Só em RAM CRITICA
        # e apenas se o recurso estiver habilitado no config.conf.
        if [ "$RAM_STANDBY_RESTRICT" = "true" ] && [ "$state" = "CRITICA" ]; then
            run_priv "am set-standby-bucket $pkg restricted" >/dev/null 2>&1 \
                && restricted=$((restricted+1))
        fi
    done <<< "$pkgs"

    echo -e "${C_GREEN}Processos em cache finalizados: $killed${C_RESET}"
    log_ok "RAM optimize: $killed processos em cache finalizados (estado $state)"
    if [ "$restricted" -gt 0 ]; then
        echo -e "${C_GREEN}Apps restringidos via App Standby Bucket: $restricted${C_RESET}"
        log_ok "RAM optimize: $restricted apps movidos para standby bucket 'restricted'"
    fi

    if [ "$state" = "CRITICA" ]; then
        send_notification "Night Optimizer" "RAM crítica otimizada: $killed apps liberados"
    fi
}

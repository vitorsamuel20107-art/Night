#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# Night Optimizer - modules/animations.sh
# Ajuste das escalas de animação do Android, com backup
# automático do valor original antes de qualquer alteração.
# ============================================================

NO_ANIM_BACKUP="$NO_BACKUP_DIR/settings.conf"

animations_backup_if_needed() {
    [ -f "$NO_ANIM_BACKUP" ] && return 0
    has_privilege || return 1
    local w t a
    w="$(run_priv 'settings get global window_animation_scale' 2>/dev/null)"
    t="$(run_priv 'settings get global transition_animation_scale' 2>/dev/null)"
    a="$(run_priv 'settings get global animator_duration_scale' 2>/dev/null)"
    {
        echo "window_animation_scale=${w:-1}"
        echo "transition_animation_scale=${t:-1}"
        echo "animator_duration_scale=${a:-1}"
    } > "$NO_ANIM_BACKUP"
    log_ok "Backup de animações salvo em $NO_ANIM_BACKUP"
}

animations_set() {
    local scale="$1"
    if ! has_privilege; then
        echo -e "${C_YELLOW}Ajuste de animações requer root, ADB ou Shizuku.${C_RESET}"
        echo "Alternativa sem root: conceda WRITE_SECURE_SETTINGS ao Termux uma única vez, via ADB em um PC:"
        echo "  adb shell pm grant com.termux android.permission.WRITE_SECURE_SETTINGS"
        echo "Depois disso o Termux consegue ajustar as animações sem precisar de ADB novamente."
        log_warn "Animation optimization: NOT AVAILABLE (sem privilégio)"
        return 1
    fi
    animations_backup_if_needed
    run_priv "settings put global window_animation_scale $scale" >/dev/null 2>&1
    run_priv "settings put global transition_animation_scale $scale" >/dev/null 2>&1
    run_priv "settings put global animator_duration_scale $scale" >/dev/null 2>&1
    echo -e "${C_GREEN}Animações ajustadas para escala ${scale}.${C_RESET}"
    log_ok "Animation optimization: SUCCESS (scale=$scale)"
}

animations_menu() {
    echo "Ajustar animações:"
    echo " 1) Desativar (0)   2) Reduzida (0.5)   3) Padrão (1)"
    echo " 4) Personalizado   5) Restaurar padrão original"
    read -rp "Escolha: " opt
    case "$opt" in
        1) animations_set 0 ;;
        2) animations_set 0.5 ;;
        3) animations_set 1 ;;
        4) read -rp "Valor: " v; animations_set "$v" ;;
        5) animations_restore ;;
        *) echo "Opção inválida." ;;
    esac
}

animations_restore() {
    if [ ! -f "$NO_ANIM_BACKUP" ]; then
        echo "Nenhum backup de animações encontrado."
        return 1
    fi
    if ! has_privilege; then
        echo -e "${C_YELLOW}Restauração requer root, ADB ou Shizuku.${C_RESET}"
        return 1
    fi
    local window_animation_scale transition_animation_scale animator_duration_scale
    # shellcheck disable=SC1090
    source "$NO_ANIM_BACKUP"
    run_priv "settings put global window_animation_scale ${window_animation_scale:-1}" >/dev/null 2>&1
    run_priv "settings put global transition_animation_scale ${transition_animation_scale:-1}" >/dev/null 2>&1
    run_priv "settings put global animator_duration_scale ${animator_duration_scale:-1}" >/dev/null 2>&1
    echo -e "${C_GREEN}Animações restauradas para os valores originais.${C_RESET}"
    log_ok "Animations restored from backup"
}

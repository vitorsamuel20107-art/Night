#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# Night Optimizer - modules/gaming.sh
# Detecção e ativação do Gaming Mode.
# ============================================================

NO_GAMING_ACTIVE=false

is_game_package() {
    local pkg="$1"
    [ -z "$pkg" ] && return 1
    echo "$GAME_PACKAGES" | tr ',' '\n' | grep -qx "$pkg" && return 0
    if has_privilege; then
        local cat
        cat="$(run_priv "dumpsys package $pkg" 2>/dev/null | grep -i 'category=' | head -n1)"
        echo "$cat" | grep -qi 'game' && return 0
    fi
    return 1
}

NO_GAMING_PKG=""

# Usa a Game Mode API oficial do Android (12+): "cmd game mode".
# Só tem efeito em jogos que implementam a API; nos demais o comando
# simplesmente não faz nada (não é destrutivo, não precisa de detecção
# prévia de suporte). Requer nível privilegiado.
gaming_set_game_mode() {
    local pkg="$1" mode="$2"
    [ "$GAMING_USE_GAME_MODE_API" != "true" ] && return 1
    has_privilege || return 1
    run_priv "cmd game mode $mode $pkg" >/dev/null 2>&1
}

gaming_check_and_activate() {
    [ "$GAMING_MODE" != "true" ] && return 1
    local fg
    fg="$(get_foreground_app)"
    if is_game_package "$fg"; then
        if ! $NO_GAMING_ACTIVE; then
            NO_GAMING_ACTIVE=true
            NO_GAMING_PKG="$fg"
            NO_CURRENT_MODE="Gaming"
            echo -e "${C_GREEN}Gaming Mode ativado para: $fg${C_RESET}"
            log_ok "Gaming Mode ATIVADO ($fg)"
            gaming_set_game_mode "$fg" "performance" \
                && log_ok "Game Mode API: performance solicitado para $fg"
            send_notification "Night Optimizer" "Gaming Mode ativado: $fg"
        fi
        return 0
    else
        if $NO_GAMING_ACTIVE; then
            gaming_set_game_mode "$NO_GAMING_PKG" "standard" \
                && log_ok "Game Mode API: standard restaurado para $NO_GAMING_PKG"
            NO_GAMING_ACTIVE=false
            NO_GAMING_PKG=""
            NO_CURRENT_MODE="Normal"
            echo "Gaming Mode desativado."
            log_ok "Gaming Mode DESATIVADO"
        fi
        return 1
    fi
}

gaming_mode_manual() {
    system_status_panel
    echo
    if ! has_privilege; then
        echo -e "${C_YELLOW}Detecção automática de jogo em primeiro plano requer root, ADB ou Shizuku.${C_RESET}"
        echo "Configure GAME_PACKAGES no config.conf para detecção manual por lista."
    fi
    gaming_check_and_activate
    local temp
    temp="$(get_temperature)"
    if [ "$temp" != "N/D" ] && [ "$temp" -ge "$TEMP_ALTA" ] 2>/dev/null; then
        echo -e "${C_YELLOW}Aviso: o desempenho pode ser limitado pelo gerenciamento térmico do Android.${C_RESET}"
    fi
}

#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# Night Optimizer - modules/thermal.sh
# Monitoramento térmico. Nunca desativa mecanismos de
# segurança térmica do Android.
# ============================================================

NO_THERMAL_THROTTLE=false

thermal_classify() {
    local t="$1"
    [ "$t" = "N/D" ] && { echo "N/D"; return; }
    if [ "$t" -ge "$TEMP_CRITICA" ] 2>/dev/null; then echo "CRITICA"
    elif [ "$t" -ge "$TEMP_ALTA" ] 2>/dev/null; then echo "ALTA"
    elif [ "$t" -ge "$TEMP_ATENCAO" ] 2>/dev/null; then echo "ATENCAO"
    else echo "NORMAL"
    fi
}

thermal_check() {
    local temp state
    temp="$(get_temperature)"
    state="$(thermal_classify "$temp")"
    echo "Temperatura: ${temp}°C - Estado: ${state}"
    log_msg INFO "Thermal check: ${temp}C ($state)"

    case "$state" in
        ALTA)
            echo -e "${C_YELLOW}Temperatura elevada: reduzindo tarefas do otimizador.${C_RESET}"
            NO_THERMAL_THROTTLE=true
            ;;
        CRITICA)
            echo -e "${C_RED}Temperatura crítica: pausando otimizações não essenciais.${C_RESET}"
            NO_THERMAL_THROTTLE=true
            send_notification "Night Optimizer" "Temperatura crítica: ${temp}°C"
            ;;
        *)
            NO_THERMAL_THROTTLE=false
            ;;
    esac
}

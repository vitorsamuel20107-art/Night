# Night Optimizer

Otimizador adaptativo para tablets Android 13, executado via **Termux + Bash**.
Detecta automaticamente o que o dispositivo permite (Termux sem root, Termux:API,
Shizuku, ADB, root) e aplica apenas as otimizações compatíveis com esse nível,
sem nunca apagar dados pessoais, remover apps do sistema ou mexer em
mecanismos críticos do Android.

## Instalação

```bash
pkg update
termux-setup-storage   # opcional, para acessar arquivos fora do Termux
cd night-optimizer
bash install.sh
```

O instalador:
- cria as pastas `logs/` e `backup/`;
- verifica/instala dependências recomendadas (`coreutils`, `procps`,
  `util-linux`, `termux-api`), sempre pedindo confirmação;
- oferece configurar inicialização automática via **Termux:Boot** (é preciso
  instalar o app Termux:Boot separadamente, pela mesma loja do Termux).

## Uso

```bash
./night_optimizer.sh
```

Abre o painel de status e o menu interativo (seção "Menu" abaixo).

## Níveis de acesso

O sistema detecta, em ordem de prioridade para operações privilegiadas
(matar processos em cache, `pm trim-caches`, ajustar animações, ver o app em
primeiro plano): **root > Shizuku (via `rish`) > ADB**. Sem nenhum desses,
o Night Optimizer funciona em modo somente monitoramento — mostra as
métricas do aparelho, mas informa claramente quando uma ação não é
permitida, em vez de falhar silenciosamente ou inventar um resultado.

Para habilitar ADB sem PC, use a depuração sem fio do Android 11+:
1. Ative "Depuração USB sem fio" em Opções do desenvolvedor.
2. `pkg install android-tools`
3. `adb pair <ip>:<porta de pareamento>`
4. `adb connect <ip>:<porta>`

## Menu

1. **Otimizar agora** — checa RAM, temperatura e armazenamento.
2. **Otimizar tudo** — roda a rotina completa (RAM, cache, animações,
   armazenamento, temperatura) e mostra um resumo com `[✓]`/`[!]` por item.
3. **Gaming Mode** — detecta o app em primeiro plano (ou usa a lista
   `GAME_PACKAGES` do `config.conf`) e reduz a atividade do próprio
   otimizador durante a partida.
4. **RAM** — finaliza processos em cache de apps de terceiros, preservando
   o app em uso e a `RAM_WHITELIST`.
5. **Cache** — configura o intervalo de limpeza automática (ou desativa).
6. **Lixo eletrônico** — procura arquivos temporários (`.tmp`, `.log`,
   `.cache`, miniaturas) fora de DCIM/Pictures/Movies/Music/Documents/
   Download, mostra o tamanho encontrado e pede confirmação antes de apagar.
7. **Animações** — ajusta as escalas de animação (com backup automático do
   valor original) ou restaura o padrão.
8. **Temperatura** — mostra o estado térmico atual.
9. **Configurações** — mostra o `config.conf` atual.
10. **Logs** — mostra as últimas linhas de `logs/night_optimizer.log`.
11. **Restaurar** — desfaz alterações de animação salvas em `backup/`.
12. **Iniciar segundo plano** — inicia `service/night_optimizer_service.sh`.
13. **Parar serviço** — para o serviço em segundo plano.

## Estrutura

```
night-optimizer/
├── night_optimizer.sh
├── config.conf
├── install.sh
├── uninstall.sh
├── restore.sh
├── lib/
│   └── common.sh
├── service/
│   └── night_optimizer_service.sh
├── modules/
│   ├── system.sh
│   ├── ram.sh
│   ├── cache.sh
│   ├── gaming.sh
│   ├── thermal.sh
│   ├── storage.sh
│   ├── animations.sh
│   └── permissions.sh
├── logs/
└── backup/
```

## Limites de segurança (por design)

- Nunca remove apps do sistema, apaga dados pessoais ou dados de
  aplicativos, nem executa `clear data`.
- Nunca modifica partições, bootloader, kernel ou desativa o
  gerenciamento térmico do Android.
- Nunca finaliza `SystemUI` ou processos essenciais — a `RAM_WHITELIST`
  no `config.conf` pode ser expandida conforme necessário.
- Nunca baixa/executa scripts externos; só instala pacotes oficiais do
  repositório do Termux, mediante confirmação.
- Se root for necessário e não estiver disponível, o sistema apenas
  informa "ROOT NECESSÁRIO" — nunca tenta obter root sozinho.
- Toda operação privilegiada é feita via `pm`, `am`, `settings` e
  `dumpsys` (comandos documentados do Android/AOSP), nunca comandos
  inventados.

## Recursos avançados (mecanismos oficiais do Android)

Pesquisei a documentação oficial do Android antes de adicionar qualquer
comando novo (item 23 do pedido original), e incorporei dois mecanismos
oficiais que se encaixam nas categorias pedidas (RAM e Gaming), ambos
opcionais no `config.conf`:

- **Game Mode API** (`cmd game mode standard|performance|battery <pacote>`,
  Android 12+) — usada pelo Gaming Mode para pedir ao próprio jogo que
  priorize desempenho, e para voltar ao padrão quando a partida termina.
  Só tem efeito em jogos que implementam a API; nos demais o comando não
  faz nada, com segurança. Controlado por `GAMING_USE_GAME_MODE_API`.
- **App Standby Buckets** (`am set-standby-bucket <pacote> restricted`,
  Android 9+) — mecanismo nativo do Android para limitar jobs, alarmes e
  rede de apps ociosos em segundo plano, mais "nativo" do que apenas
  finalizar o processo. Aplicado apenas em RAM CRÍTICA, se
  `RAM_STANDBY_RESTRICT=true`.

Deliberadamente **não** incluí ajustes de rede, DNS, Wi-Fi, GPS, taxa de
atualização de tela ou bloqueadores de anúncio que aparecem em vários
scripts de "otimização" pela internet — eles alteram comportamento que
você não pediu (conectividade, precisão de localização, aparência da
tela) e fogem das categorias definidas no pedido original (RAM, cache,
cache, animações, temperatura, armazenamento e modo jogo).

## Instalação automática de dependências

`ensure_dependencies` (em `lib/common.sh`) roda automaticamente ao abrir
o `night_optimizer.sh` e ao iniciar o serviço: verifica `coreutils`,
`procps`, `util-linux` e `termux-api` e instala pelo repositório oficial
do Termux (`pkg install`) o que estiver faltando — sempre informando o
que está sendo instalado no terminal e no log. Nunca baixa scripts ou
pacotes de fora do repositório oficial.

## Observações técnicas

- `get_foreground_app`, a limpeza de cache (`pm trim-caches`) e o ajuste
  de animações (`settings put global ...`) exigem um nível privilegiado
  (root, Shizuku ou ADB), pois são operações que o Android reserva para
  o shell/sistema. Sem isso, essas funções informam claramente que não
  estão disponíveis, em vez de simular um resultado.
- A leitura de temperatura usa o Termux:API quando disponível; caso
  contrário, tenta as zonas térmicas de bateria/CPU expostas em
  `/sys/class/thermal/`, que variam por fabricante — em alguns aparelhos
  pode não haver leitura disponível (`N/D`).
- Todas as ações relevantes ficam registradas em
  `logs/night_optimizer.log`, com data, hora, operação, resultado e
  nível de acesso usado.

#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# Night Optimizer - install.sh
# ============================================================

NO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$NO_DIR" || exit 1

echo "=== Instalando Night Optimizer ==="

if [ -z "$PREFIX" ] || [[ "$PREFIX" != *com.termux* ]]; then
    echo "Aviso: este instalador foi feito para o Termux. Continuando mesmo assim."
fi

mkdir -p logs backup
chmod +x night_optimizer.sh install.sh uninstall.sh restore.sh \
    service/night_optimizer_service.sh modules/*.sh 2>/dev/null

echo
echo "Verificando dependências recomendadas (coreutils, procps, util-linux, termux-api)..."
source "$NO_DIR/lib/common.sh"
ensure_dependencies

echo
read -rp "Configurar inicialização automática via Termux:Boot? [s/N] " boot_ans
if [[ "$boot_ans" =~ ^[Ss]$ ]]; then
    mkdir -p "$HOME/.termux/boot"
    cat > "$HOME/.termux/boot/night-optimizer-start.sh" << EOF
#!/data/data/com.termux/files/usr/bin/bash
"$NO_DIR/service/night_optimizer_service.sh" start
EOF
    chmod +x "$HOME/.termux/boot/night-optimizer-start.sh"
    echo "Configurado. Instale também o app 'Termux:Boot' para que isso funcione após reiniciar."
else
    echo "Inicialização automática não configurada."
fi

echo
echo "Instalação concluída. Execute: ./night_optimizer.sh"

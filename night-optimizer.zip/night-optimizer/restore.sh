#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# Night Optimizer - restore.sh
# Restaura configurações alteradas pelo Night Optimizer.
# ============================================================

NO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$NO_DIR/lib/common.sh"
source "$NO_DIR/config.conf"
source "$NO_DIR/modules/animations.sh"

detect_access_level
echo "=== Night Optimizer - RESTORE ==="
animations_restore

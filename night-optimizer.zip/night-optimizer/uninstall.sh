#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# Night Optimizer - uninstall.sh
# ============================================================

NO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "=== Desinstalando Night Optimizer ==="

"$NO_DIR/service/night_optimizer_service.sh" stop 2>/dev/null

rm -f "$HOME/.termux/boot/night-optimizer-start.sh"
echo "Inicialização automática removida (se existia)."

read -rp "Remover logs e backups? [s/N] " ans
if [[ "$ans" =~ ^[Ss]$ ]]; then
    rm -rf "$NO_DIR/logs" "$NO_DIR/backup"
    echo "Logs e backups removidos."
fi

echo "Os arquivos do projeto em $NO_DIR não foram apagados."
echo "Remova a pasta manualmente se desejar excluir tudo."

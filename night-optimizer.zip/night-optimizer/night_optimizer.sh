#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# Night Optimizer - night_optimizer.sh
# Ponto de entrada principal / menu interativo.
# ============================================================

NO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$NO_DIR/lib/common.sh"
source "$NO_DIR/config.conf"
for m in system ram cache gaming thermal storage animations permissions; do
    source "$NO_DIR/modules/$m.sh"
done

NO_CURRENT_MODE="Normal"

pause() { read -rp "Pressione ENTER para continuar..." _; }

optimize_all() {
    echo -e "${C_BOLD}=== OTIMIZAR TUDO ===${C_RESET}"
    detect_access_level
    system_detect_device
    echo
    animations_backup_if_needed >/dev/null 2>&1

    ram_optimize; echo "[✓] RAM analisada"

    if [ "$ANIMATIONS" = "true" ]; then
        animations_set 0.5 && echo "[✓] Animações configuradas" || echo "[!] Animações não configuradas"
    else
        echo "[→] Animações mantidas conforme configuração do usuário"
    fi

    cache_clean && echo "[✓] Cache analisado" || echo "[!] Limpeza global de cache não permitida"
    storage_status && echo "[✓] Armazenamento analisado"
    thermal_check && echo "[✓] Temperatura analisada"
    $NO_HAS_ROOT || echo "[!] Root não disponível"
    echo "[✓] Otimizações compatíveis aplicadas"

    log_ok "OTIMIZAR TUDO executado"
    send_notification "Night Optimizer" "Otimização completa concluída"
}

show_menu() {
    clear
    system_status_panel
    echo
    echo "╔════════════════════════════╗"
    echo "║      NIGHT OPTIMIZER       ║"
    echo "╠════════════════════════════╣"
    echo "║ 1. Otimizar agora           ║"
    echo "║ 2. Otimizar tudo            ║"
    echo "║ 3. Gaming Mode              ║"
    echo "║ 4. RAM                      ║"
    echo "║ 5. Cache                    ║"
    echo "║ 6. Lixo eletrônico          ║"
    echo "║ 7. Animações                ║"
    echo "║ 8. Temperatura              ║"
    echo "║ 9. Configurações            ║"
    echo "║ 10. Logs                    ║"
    echo "║ 11. Restaurar               ║"
    echo "║ 12. Iniciar segundo plano   ║"
    echo "║ 13. Parar serviço           ║"
    echo "║ 0. Sair                     ║"
    echo "╚════════════════════════════╝"
}

config_menu() {
    echo "Configurações atuais (config.conf):"
    grep -v '^#' "$NO_DIR/config.conf" | grep -v '^$'
    echo
    echo "Edite manualmente $NO_DIR/config.conf para alterar os valores,"
    echo "ou use a opção de Cache para configurar o intervalo pelo menu."
}

main() {
    ensure_dependencies
    detect_access_level
    system_detect_device
    pause
    while true; do
        show_menu
        read -rp "Escolha uma opção: " opt
        case "$opt" in
            1) ram_optimize; thermal_check; storage_status ;;
            2) optimize_all ;;
            3) gaming_mode_manual ;;
            4) ram_optimize ;;
            5) cache_menu_interval ;;
            6) storage_junk_scan ;;
            7) animations_menu ;;
            8) thermal_check ;;
            9) config_menu ;;
            10) tail -n 40 "$NO_LOG_FILE" 2>/dev/null || echo "Sem logs ainda." ;;
            11) animations_restore ;;
            12) "$NO_DIR/service/night_optimizer_service.sh" start; echo "Serviço iniciado em segundo plano." ;;
            13) "$NO_DIR/service/night_optimizer_service.sh" stop ;;
            0) echo "Saindo."; break ;;
            *) echo "Opção inválida." ;;
        esac
        pause
    done
}

main

#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# Night Optimizer - lib/common.sh
# Funções compartilhadas: detecção de nível de acesso, coleta
# de métricas do dispositivo, logging e utilitários gerais.
# ============================================================

# Diretório raiz do projeto (funciona independente de onde é chamado)
NO_ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NO_LOG_DIR="$NO_ROOT_DIR/logs"
NO_BACKUP_DIR="$NO_ROOT_DIR/backup"
NO_LOG_FILE="$NO_LOG_DIR/night_optimizer.log"

mkdir -p "$NO_LOG_DIR" "$NO_BACKUP_DIR"

# ---------- Cores ----------
C_RESET="\033[0m"; C_GREEN="\033[1;32m"; C_YELLOW="\033[1;33m"
C_RED="\033[1;31m"; C_CYAN="\033[1;36m"; C_BOLD="\033[1m"

# ---------- Logging ----------
# log_msg <nivel> <mensagem>
log_msg() {
    local level="$1"; shift
    local msg="$*"
    local ts
    ts="$(date '+%Y-%m-%d %H:%M:%S')"
    echo "[$ts] [$level] $msg" >> "$NO_LOG_FILE"
}
log_ok()   { log_msg "OK" "$*"; }
log_warn() { log_msg "AVISO" "$*"; }
log_err()  { log_msg "ERRO" "$*"; }

# ---------- Utilitários ----------
have_cmd() { command -v "$1" >/dev/null 2>&1; }

# Extrai um campo simples de uma string JSON de uma linha.
# Evita depender de jq, que pode não estar instalado.
json_field() {
    local json="$1" field="$2"
    echo "$json" | grep -o "\"$field\"[[:space:]]*:[[:space:]]*[^,}]*" \
        | head -n1 | sed -E 's/.*:[[:space:]]*"?([^",}]*)"?.*/\1/'
}

# Salva variáveis simples do config.conf de volta ao arquivo
config_save() {
    local key
    for key in AUTO_OPTIMIZE AUTO_CACHE CACHE_INTERVAL GAMING_MODE NOTIFICATIONS \
               ANIMATIONS AUTO_START THERMAL_MONITOR STORAGE_CLEANER RAM_MONITOR; do
        local val="${!key}"
        if grep -q "^${key}=" "$NO_ROOT_DIR/config.conf" 2>/dev/null; then
            sed -i "s/^${key}=.*/${key}=${val}/" "$NO_ROOT_DIR/config.conf"
        else
            echo "${key}=${val}" >> "$NO_ROOT_DIR/config.conf"
        fi
    done
}

# ---------- Dependências ----------
# Verifica ferramentas necessárias e instala automaticamente as que
# faltarem, usando apenas o repositório oficial do Termux (pkg). Nunca
# baixa scripts ou APKs de fora. Informa o usuário em cada etapa.
ensure_dependencies() {
    local missing=() pkg cmd pkg_cmd
    for pkg_cmd in "coreutils:df" "procps:ps" "util-linux:getopt" "termux-api:termux-battery-status"; do
        pkg="${pkg_cmd%%:*}"; cmd="${pkg_cmd##*:}"
        have_cmd "$cmd" || missing+=("$pkg")
    done
    [ "${#missing[@]}" -eq 0 ] && return 0

    have_cmd pkg || { log_warn "Dependências ausentes (${missing[*]}) mas comando 'pkg' indisponível"; return 1; }

    echo -e "${C_YELLOW}Instalando dependências ausentes: ${missing[*]}${C_RESET}"
    log_msg INFO "Instalando dependências: ${missing[*]}"
    if pkg install -y "${missing[@]}" >>"$NO_LOG_FILE" 2>&1; then
        echo -e "${C_GREEN}Dependências instaladas.${C_RESET}"
        log_ok "Dependências instaladas: ${missing[*]}"
    else
        echo -e "${C_YELLOW}Não foi possível instalar automaticamente: ${missing[*]}${C_RESET}"
        echo "Algumas funções podem ficar indisponíveis. Tente manualmente: pkg install ${missing[*]}"
        log_err "Falha ao instalar dependências: ${missing[*]}"
    fi
}

# ---------- Detecção de nível de acesso ----------
NO_HAS_ROOT=false
NO_HAS_ADB=false
NO_HAS_SHIZUKU=false
NO_HAS_TERMUX_API=false

detect_root() {
    NO_HAS_ROOT=false
    if have_cmd su; then
        if timeout 3 su -c 'id' 2>/dev/null | grep -q 'uid=0'; then
            NO_HAS_ROOT=true
        fi
    fi
    $NO_HAS_ROOT && log_ok "Root detectado" || log_warn "Root não disponível"
}

detect_adb() {
    NO_HAS_ADB=false
    if have_cmd adb; then
        if timeout 3 adb shell echo NO_ADB_OK 2>/dev/null | grep -q 'NO_ADB_OK'; then
            NO_HAS_ADB=true
        fi
    fi
    $NO_HAS_ADB && log_ok "ADB detectado e funcional" || log_warn "ADB não disponível"
}

detect_shizuku() {
    NO_HAS_SHIZUKU=false
    if have_cmd rish; then
        if timeout 3 rish -c 'id' 2>/dev/null | grep -q 'uid='; then
            NO_HAS_SHIZUKU=true
        fi
    fi
    $NO_HAS_SHIZUKU && log_ok "Shizuku (rish) detectado" || log_warn "Shizuku não disponível"
}

detect_termux_api() {
    NO_HAS_TERMUX_API=false
    if have_cmd termux-battery-status; then
        if timeout 3 termux-battery-status >/dev/null 2>&1; then
            NO_HAS_TERMUX_API=true
        fi
    fi
    $NO_HAS_TERMUX_API && log_ok "Termux:API detectado" || log_warn "Termux:API não disponível"
}

detect_access_level() {
    detect_root
    detect_adb
    detect_shizuku
    detect_termux_api
}

# Executa um comando usando o melhor nível privilegiado
# disponível: root > shizuku > adb. Retorna 1 se nenhum nível
# estiver disponível — quem chama deve tratar isso sem falhar.
run_priv() {
    local cmd="$*"
    if $NO_HAS_ROOT; then
        timeout 5 su -c "$cmd" 2>/dev/null
        return $?
    elif $NO_HAS_SHIZUKU; then
        timeout 5 rish -c "$cmd" 2>/dev/null
        return $?
    elif $NO_HAS_ADB; then
        timeout 5 adb shell "$cmd" 2>/dev/null
        return $?
    else
        return 1
    fi
}

has_privilege() {
    $NO_HAS_ROOT || $NO_HAS_SHIZUKU || $NO_HAS_ADB
}

# ---------- Informações do dispositivo ----------
get_prop() { getprop "$1" 2>/dev/null; }

get_manufacturer() { local v; v="$(get_prop ro.product.manufacturer)"; echo "${v:-desconhecido}"; }
get_model()        { local v; v="$(get_prop ro.product.model)"; echo "${v:-desconhecido}"; }
get_android_ver()  { local v; v="$(get_prop ro.build.version.release)"; echo "${v:-desconhecido}"; }
get_sdk_level()    { local v; v="$(get_prop ro.build.version.sdk)"; echo "${v:-desconhecido}"; }
get_arch()         { uname -m 2>/dev/null || echo "desconhecido"; }

# ---------- RAM ----------
# Devolve "usado_mb total_mb percentual"
get_ram_stats() {
    local total avail used pct
    total=$(awk '/MemTotal/{print $2}' /proc/meminfo 2>/dev/null)
    avail=$(awk '/MemAvailable/{print $2}' /proc/meminfo 2>/dev/null)
    if [ -z "$total" ] || [ -z "$avail" ]; then
        echo "0 0 0"
        return 1
    fi
    used=$((total - avail))
    pct=$((used * 100 / total))
    echo "$((used/1024)) $((total/1024)) $pct"
}

# ---------- CPU ----------
# Uso aproximado de CPU (%) amostrando /proc/stat duas vezes
get_cpu_usage() {
    local sum1 idle1 sum2 idle2 diff_idle diff_total
    _read_stat() {
        local vals total=0 v
        vals=($(awk '/^cpu /{ $1=""; print }' /proc/stat 2>/dev/null))
        for v in "${vals[@]}"; do total=$((total+v)); done
        echo "$total ${vals[3]}"
    }
    read -r sum1 idle1 <<< "$(_read_stat)"
    [ -z "$sum1" ] && { echo "0"; return 1; }
    sleep 0.3
    read -r sum2 idle2 <<< "$(_read_stat)"
    diff_total=$((sum2 - sum1))
    diff_idle=$((idle2 - idle1))
    [ "$diff_total" -le 0 ] && { echo "0"; return 1; }
    echo $(( (100 * (diff_total - diff_idle)) / diff_total ))
}

# ---------- Bateria / Temperatura ----------
# Devolve "percentual temperatura status"
get_battery_info() {
    if $NO_HAS_TERMUX_API; then
        local json pct temp status
        json="$(timeout 3 termux-battery-status 2>/dev/null)"
        pct="$(json_field "$json" percentage)"
        temp="$(json_field "$json" temperature)"
        status="$(json_field "$json" status)"
        echo "${pct:-N/D} ${temp:-N/D} ${status:-N/D}"
    else
        local pct
        pct=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null)
        echo "${pct:-N/D} N/D N/D"
    fi
}

get_temperature() {
    if $NO_HAS_TERMUX_API; then
        local json temp
        json="$(timeout 3 termux-battery-status 2>/dev/null)"
        temp="$(json_field "$json" temperature)"
        if [ -n "$temp" ]; then
            printf '%.0f\n' "$temp" 2>/dev/null || echo "$temp"
            return 0
        fi
    fi
    local zone type raw
    for zone in /sys/class/thermal/thermal_zone*; do
        [ -f "$zone/type" ] || continue
        type="$(cat "$zone/type" 2>/dev/null)"
        if echo "$type" | grep -qiE 'batt|cpu'; then
            raw="$(cat "$zone/temp" 2>/dev/null)"
            if [ -n "$raw" ] && [ "$raw" -gt 1000 ] 2>/dev/null; then
                echo "$(( raw / 1000 ))"
                return 0
            elif [ -n "$raw" ]; then
                echo "$raw"
                return 0
            fi
        fi
    done
    echo "N/D"
    return 1
}

# ---------- Armazenamento ----------
# Devolve "usado_gb total_gb percentual"
get_storage_stats() {
    local target line used total pct
    target="/data"
    [ -d "/sdcard" ] && target="/sdcard"
    line=$(df -k "$target" 2>/dev/null | tail -n1)
    if [ -z "$line" ]; then
        echo "0 0 0"
        return 1
    fi
    total=$(echo "$line" | awk '{print $2}')
    used=$(echo "$line" | awk '{print $3}')
    pct=$(echo "$line" | awk '{gsub("%","",$5); print $5}')
    [ -z "$total" ] || [ "$total" -eq 0 ] 2>/dev/null && { echo "0 0 0"; return 1; }
    echo "$(( used/1024/1024 )) $(( total/1024/1024 )) ${pct:-0}"
}

# ---------- Aplicativo em primeiro plano ----------
get_foreground_app() {
    has_privilege || { echo "desconhecido"; return 1; }
    local out pkg
    out="$(run_priv 'dumpsys activity activities' 2>/dev/null | grep -m1 'mResumedActivity')"
    pkg="$(echo "$out" | grep -oE '[a-zA-Z0-9_.]+/[a-zA-Z0-9_.]+' | head -n1 | cut -d/ -f1)"
    echo "${pkg:-desconhecido}"
}

# ---------- Notificações ----------
send_notification() {
    local title="$1" content="$2"
    [ "$NOTIFICATIONS" != "true" ] && return 0
    $NO_HAS_TERMUX_API || return 1
    have_cmd termux-notification || return 1
    termux-notification --title "$title" --content "$content" >/dev/null 2>&1
}

#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# Night Optimizer - service/night_optimizer_service.sh
# Loop de monitoramento contínuo em segundo plano.
# Uso: night_optimizer_service.sh {start|stop|restart|status}
# ============================================================

SERVICE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$SERVICE_DIR/lib/common.sh"
source "$SERVICE_DIR/config.conf"
for m in system ram cache gaming thermal storage animations permissions; do
    source "$SERVICE_DIR/modules/$m.sh"
done

PID_FILE="$NO_ROOT_DIR/night_optimizer.pid"
NO_CURRENT_MODE="Normal"

service_loop() {
    echo $$ > "$PID_FILE"
    ensure_dependencies >/dev/null 2>&1
    detect_access_level
    log_ok "Serviço Night Optimizer iniciado (PID $$)"
    local last_cache=0 now

    while true; do
        now=$(date +%s)

        [ "$RAM_MONITOR" = "true" ] && ram_optimize >/dev/null 2>&1
        [ "$THERMAL_MONITOR" = "true" ] && thermal_check >/dev/null 2>&1
        [ "$STORAGE_CLEANER" = "true" ] && storage_status >/dev/null 2>&1
        [ "$GAMING_MODE" = "true" ] && gaming_check_and_activate >/dev/null 2>&1

        if [ "$AUTO_CACHE" = "true" ] && [ $((now - last_cache)) -ge "$CACHE_INTERVAL" ]; then
            if [ "$NO_GAMING_ACTIVE" != "true" ] && [ "$NO_THERMAL_THROTTLE" != "true" ]; then
                cache_clean >/dev/null 2>&1
                last_cache=$now
            fi
        fi

        sleep 10
    done
}

service_status() {
    if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
        echo "Serviço em execução (PID $(cat "$PID_FILE"))."
    else
        echo "Serviço parado."
    fi
}

service_stop() {
    if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
        kill "$(cat "$PID_FILE")"
        rm -f "$PID_FILE"
        echo "Serviço parado."
        log_ok "Serviço Night Optimizer parado"
    else
        echo "Serviço não estava em execução."
    fi
}

case "$1" in
    start)   service_loop & disown ;;
    stop)    service_stop ;;
    status)  service_status ;;
    restart) service_stop; sleep 1; service_loop & disown ;;
    *)       service_loop ;;
esac
